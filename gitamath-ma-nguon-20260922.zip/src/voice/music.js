'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  NHẠC LÝ — cao độ, trường độ, và đọc tệp MIDI thật
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế gốc nhận "midiPath" rồi chuyển thẳng cho một tiến trình Python.
 *  Làm vậy thì hệ thống không biết gì về bản nhạc: không kiểm được lời có khớp
 *  nốt không, không báo được bài dài bao lâu, không phát hiện được nốt vượt
 *  quãng giọng của giảng viên. Ở đây tệp MIDI được ĐỌC THẲNG bằng JavaScript
 *  (chuẩn SMF 0/1: MThd, MTrk, số biến độ dài, note-on/off, meta tempo), nên
 *  mọi kiểm tra đều làm được trước khi hát một nốt nào.
 *
 *  Kèm theo: ký âm chữ dễ gõ cho người soạn bài —
 *      "đô4:1 rê4:1 mi4:2"   hoặc   "C4:1 D4:1 E4:2"
 *  (tên nốt + quãng tám + dấu hai chấm + số phách)
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round, clamp } = require('../utils');

/** Tên nốt phương Tây và tên Việt. C4 = đô giữa = MIDI 60. */
const SEMITONE = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const VI_NOTE = { 'đô': 'C', 'do': 'C', 'rê': 'D', 're': 'D', 'mi': 'E', 'fa': 'F', 'pha': 'F', 'sol': 'G', 'son': 'G', 'la': 'A', 'si': 'B', 'ti': 'B' };
const NAME_OF = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const VI_NAME_OF = ['đô', 'đô thăng', 'rê', 'rê thăng', 'mi', 'fa', 'fa thăng', 'sol', 'sol thăng', 'la', 'la thăng', 'si'];

/** Quãng giọng thông dụng — dùng để cảnh báo nốt ngoài tầm. */
const RANGES = {
  bass: { name: 'Nam trầm', lo: 41, hi: 64 },
  baritone: { name: 'Nam trung', lo: 45, hi: 67 },
  tenor: { name: 'Nam cao', lo: 48, hi: 72 },
  alto: { name: 'Nữ trầm', lo: 53, hi: 77 },
  mezzo: { name: 'Nữ trung', lo: 55, hi: 79 },
  soprano: { name: 'Nữ cao', lo: 60, hi: 84 },
};

const midiToFreq = (n) => 440 * Math.pow(2, (n - 69) / 12);
const freqToMidi = (f) => 69 + 12 * Math.log2(f / 440);
const midiName = (n) => `${NAME_OF[((n % 12) + 12) % 12]}${Math.floor(n / 12) - 1}`;
const midiNameVi = (n) => `${VI_NAME_OF[((n % 12) + 12) % 12]} quãng ${Math.floor(n / 12) - 1}`;

/**
 * "C4", "F#3", "Eb3", "đô4", "rê4", "sol#3" → số MIDI.
 * Tên Việt (đô rê mi fa sol la si) phải thử TRƯỚC tên phương Tây: "si" mà đem
 * so với bảng một chữ cái thì thành "s" — không có nốt nào tên vậy.
 */
function noteToMidi(token) {
  const t = String(token).trim().toLowerCase().replace(/\s+/g, '');
  const m = t.match(/^([a-zđôêơư]+)([#♯]?)(-?\d+)$/);
  if (!m) return null;
  let letters = m[1];
  let accidental = (m[2] === '#' || m[2] === '♯') ? 1 : 0;
  const octave = parseInt(m[3], 10);

  // Dấu giáng viết bằng chữ "b" ở cuối ("eb4", "sib3") — nhưng "b4" thì chữ b
  // chính là tên nốt, không phải dấu giáng.
  if (!accidental && letters.length > 1 && letters.endsWith('b')) {
    const head = letters.slice(0, -1);
    if (VI_NOTE[head] || head.length === 1) { letters = head; accidental = -1; }
  }

  let letter = VI_NOTE[letters] || (letters.length === 1 ? letters.toUpperCase() : null);
  if (!letter) return null;
  letter = letter.toUpperCase();
  if (!(letter in SEMITONE)) return null;
  return (octave + 1) * 12 + SEMITONE[letter] + accidental;
}

/**
 * Ký âm chữ → danh sách nốt.
 *   "đô4:1 rê4:1 mi4:2 -:1 fa4:1"   ( "-" là dấu lặng )
 * @param {string} text
 * @param {object} o {bpm, beatMs}
 */
function parseMelody(text, { bpm = 90 } = {}) {
  const beatMs = 60000 / bpm;
  const notes = [];
  const errors = [];
  let at = 0;
  for (const raw of String(text || '').trim().split(/\s+/).filter(Boolean)) {
    const [head, beatsRaw] = raw.split(':');
    const beats = beatsRaw ? Number(beatsRaw) : 1;
    if (!Number.isFinite(beats) || beats <= 0) { errors.push(`trường độ sai: ${raw}`); continue; }
    const ms = Math.round(beats * beatMs);
    if (head === '-' || head === '_') {
      notes.push({ rest: true, midi: null, ms, at, beats });
    } else {
      const midi = noteToMidi(head);
      if (midi == null) { errors.push(`không hiểu nốt: ${head}`); continue; }
      notes.push({ rest: false, midi, freq: round(midiToFreq(midi), 2), name: midiName(midi), ms, at, beats });
    }
    at += ms;
  }
  return { ok: errors.length === 0, notes, errors, bpm, totalMs: at, beats: round(at / beatMs, 2) };
}

/** ── Đọc tệp MIDI chuẩn (SMF) ────────────────────────────────────────────── */

/** Số biến độ dài — kiểu mã hoá đặc trưng của MIDI, 7 bit mỗi byte. */
function readVarInt(buf, pos) {
  let value = 0;
  let n = 0;
  for (;;) {
    if (pos + n >= buf.length) return { value, next: pos + n };
    const b = buf[pos + n];
    n++;
    value = (value << 7) | (b & 0x7f);
    if (!(b & 0x80)) break;
    if (n > 4) break;
  }
  return { value, next: pos + n };
}

/**
 * Đọc tệp MIDI thành danh sách nốt có thời điểm và trường độ tính bằng ms.
 * Hỗ trợ format 0 và 1, chia nhịp theo ticks-per-quarter (không hỗ trợ SMPTE).
 */
function parseMidi(buffer) {
  const buf = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  if (buf.length < 14 || buf.toString('ascii', 0, 4) !== 'MThd') {
    return { ok: false, error: 'KHÔNG_PHẢI_TỆP_MIDI' };
  }
  const format = buf.readUInt16BE(8);
  const trackCount = buf.readUInt16BE(10);
  const division = buf.readUInt16BE(12);
  if (division & 0x8000) return { ok: false, error: 'CHƯA_HỖ_TRỢ_CHIA_NHỊP_SMPTE' };
  const tpq = division;

  let pos = 8 + buf.readUInt32BE(4);
  const tempos = [{ tick: 0, usPerQuarter: 500000 }];   // mặc định 120 bpm
  const raw = [];                                       // {tick, type, ch, note, vel, track}

  for (let t = 0; t < trackCount && pos + 8 <= buf.length; t++) {
    if (buf.toString('ascii', pos, pos + 4) !== 'MTrk') break;
    const len = buf.readUInt32BE(pos + 4);
    let p = pos + 8;
    const end = Math.min(buf.length, p + len);
    let tick = 0;
    let running = 0;

    while (p < end) {
      const v = readVarInt(buf, p);
      tick += v.value;
      p = v.next;
      if (p >= end) break;
      let status = buf[p];
      if (status & 0x80) { p++; running = status; } else { status = running; }   // running status
      const type = status & 0xf0;
      const ch = status & 0x0f;

      if (status === 0xff) {                       // meta
        const metaType = buf[p]; p++;
        const lv = readVarInt(buf, p); p = lv.next;
        if (metaType === 0x51 && lv.value === 3) {
          tempos.push({ tick, usPerQuarter: (buf[p] << 16) | (buf[p + 1] << 8) | buf[p + 2] });
        }
        p += lv.value;
      } else if (status === 0xf0 || status === 0xf7) {   // sysex
        const lv = readVarInt(buf, p); p = lv.next; p += lv.value;
      } else if (type === 0x80 || type === 0x90) {
        const note = buf[p]; const vel = buf[p + 1]; p += 2;
        raw.push({ tick, type: (type === 0x90 && vel > 0) ? 'on' : 'off', ch, note, vel, track: t });
      } else if (type === 0xa0 || type === 0xb0 || type === 0xe0) {
        p += 2;
      } else if (type === 0xc0 || type === 0xd0) {
        p += 1;
      } else {
        p++;   // byte lạ: bước qua, đừng để kẹt vòng lặp
      }
    }
    pos = pos + 8 + len;
  }

  // Quy tick → ms, có tính tới mọi lần đổi nhịp độ.
  tempos.sort((a, b) => a.tick - b.tick);
  const tickToMs = (tick) => {
    let ms = 0;
    let last = 0;
    let us = tempos[0].usPerQuarter;
    for (const tp of tempos) {
      if (tp.tick >= tick) break;
      ms += ((tp.tick - last) / tpq) * (us / 1000);
      last = tp.tick;
      us = tp.usPerQuarter;
    }
    return ms + ((tick - last) / tpq) * (us / 1000);
  };

  // Ghép note-on với note-off để ra trường độ.
  raw.sort((a, b) => a.tick - b.tick || (a.type === 'off' ? -1 : 1));
  const open = new Map();
  const notes = [];
  for (const e of raw) {
    const key = `${e.track}:${e.ch}:${e.note}`;
    if (e.type === 'on') {
      open.set(key, e);
    } else {
      const start = open.get(key);
      if (!start) continue;
      open.delete(key);
      const at = tickToMs(start.tick);
      const ms = Math.max(1, tickToMs(e.tick) - at);
      notes.push({
        rest: false, midi: e.note, freq: round(midiToFreq(e.note), 2), name: midiName(e.note),
        at: Math.round(at), ms: Math.round(ms), velocity: start.vel, track: start.track, channel: start.ch,
      });
    }
  }
  notes.sort((a, b) => a.at - b.at || a.midi - b.midi);

  const bpm = tempos.length ? round(60000000 / tempos[tempos.length - 1].usPerQuarter, 1) : 120;
  return {
    ok: true, format, tracks: trackCount, ticksPerQuarter: tpq, bpm,
    tempoChanges: tempos.length - 1,
    notes,
    totalMs: notes.length ? Math.max(...notes.map((n) => n.at + n.ms)) : 0,
  };
}

/**
 * Giai điệu nhiều bè → một bè hát: mỗi thời điểm lấy nốt cao nhất.
 * Tệp MIDI của bài hát thường có cả đệm; hát cả chùm hợp âm là ra tiếng ồn.
 */
function extractLeadLine(notes, { track = null, channel = null } = {}) {
  let list = notes.filter((n) => !n.rest);
  if (track != null) list = list.filter((n) => n.track === track);
  if (channel != null) list = list.filter((n) => n.channel === channel);
  if (!list.length) return [];

  const byStart = new Map();
  for (const n of list) {
    const k = Math.round(n.at / 10) * 10;                 // gom nốt lệch dưới 10ms
    const cur = byStart.get(k);
    if (!cur || n.midi > cur.midi) byStart.set(k, n);
  }
  const lead = [...byStart.values()].sort((a, b) => a.at - b.at);

  // Cắt đuôi nốt trước khi nốt sau bắt đầu, để không chồng tiếng.
  for (let i = 0; i < lead.length - 1; i++) {
    const gap = lead[i + 1].at - lead[i].at;
    if (lead[i].ms > gap) lead[i] = { ...lead[i], ms: gap };
  }
  return lead;
}

/** Chèn dấu lặng vào chỗ trống giữa các nốt — lời hát cần biết chỗ nghỉ lấy hơi. */
function withRests(lead, { minGapMs = 120 } = {}) {
  const out = [];
  let prevEnd = 0;
  for (const n of lead) {
    const gap = n.at - prevEnd;
    if (gap >= minGapMs) out.push({ rest: true, midi: null, at: prevEnd, ms: gap });
    out.push(n);
    prevEnd = n.at + n.ms;
  }
  return out;
}

/** Dịch giọng cho vừa quãng của người hát. Trả số nửa cung cần dịch. */
function fitToRange(notes, rangeId = 'alto') {
  const r = RANGES[rangeId] || RANGES.alto;
  const pitched = notes.filter((n) => !n.rest && n.midi != null);
  if (!pitched.length) return { shift: 0, ok: true, outOfRange: 0 };
  const lo = Math.min(...pitched.map((n) => n.midi));
  const hi = Math.max(...pitched.map((n) => n.midi));
  const span = hi - lo;
  if (span > r.hi - r.lo) {
    return {
      shift: 0, ok: false, error: 'BÀI_RỘNG_HƠN_QUÃNG_GIỌNG',
      span, rangeSpan: r.hi - r.lo, range: r.name,
      detail: `Bài rộng ${span} nửa cung, quãng ${r.name} chỉ có ${r.hi - r.lo}. Cần đổi giọng hát hoặc sửa bản nhạc.`,
    };
  }
  // Dịch theo quãng tám cho gần giữa quãng giọng nhất.
  const centerWant = (r.lo + r.hi) / 2;
  const centerHave = (lo + hi) / 2;
  const shift = (Math.round((centerWant - centerHave) / 12) * 12) || 0;
  const after = pitched.map((n) => n.midi + shift);
  const outOfRange = after.filter((m) => m < r.lo || m > r.hi).length;
  return { shift, ok: true, outOfRange, range: r.name, lo: midiName(lo + shift), hi: midiName(hi + shift) };
}

/** Số biến độ dài — chiều ngược lại của readVarInt. */
function writeVarInt(value) {
  const bytes = [value & 0x7f];
  value >>= 7;
  while (value > 0) { bytes.unshift((value & 0x7f) | 0x80); value >>= 7; }
  return Buffer.from(bytes);
}

/**
 * Ghi danh sách nốt ra tệp MIDI chuẩn (format 0).
 * Có cái này thì giai điệu soạn bằng ký âm chữ xuất được sang phần mềm nhạc,
 * và vòng đọc–ghi kiểm chứng được lẫn nhau.
 */
function writeMidi(notes, { bpm = 120, tpq = 480 } = {}) {
  const msPerTick = (60000 / bpm) / tpq;
  const events = [];
  for (const n of notes) {
    if (n.rest || n.midi == null) continue;
    events.push({ tick: Math.round(n.at / msPerTick), type: 0x90, note: n.midi, vel: n.velocity || 96 });
    events.push({ tick: Math.round((n.at + n.ms) / msPerTick), type: 0x80, note: n.midi, vel: 0 });
  }
  events.sort((a, b) => a.tick - b.tick || (a.type === 0x80 ? -1 : 1));

  const chunks = [];
  // meta: nhịp độ
  const us = Math.round(60000000 / bpm);
  chunks.push(writeVarInt(0), Buffer.from([0xff, 0x51, 0x03, (us >> 16) & 0xff, (us >> 8) & 0xff, us & 0xff]));
  let last = 0;
  for (const e of events) {
    chunks.push(writeVarInt(Math.max(0, e.tick - last)), Buffer.from([e.type, e.note, e.vel]));
    last = e.tick;
  }
  chunks.push(writeVarInt(0), Buffer.from([0xff, 0x2f, 0x00]));   // kết thúc rãnh

  const track = Buffer.concat(chunks);
  const head = Buffer.alloc(14);
  head.write('MThd', 0);
  head.writeUInt32BE(6, 4);
  head.writeUInt16BE(0, 8);      // format 0
  head.writeUInt16BE(1, 10);     // 1 rãnh
  head.writeUInt16BE(tpq, 12);
  const trkHead = Buffer.alloc(8);
  trkHead.write('MTrk', 0);
  trkHead.writeUInt32BE(track.length, 4);
  return Buffer.concat([head, trkHead, track]);
}

module.exports = {
  SEMITONE, VI_NOTE, NAME_OF, RANGES,
  writeMidi, writeVarInt,
  midiToFreq, freqToMidi, midiName, midiNameVi, noteToMidi,
  parseMelody, parseMidi, readVarInt, extractLeadLine, withRests, fitToRange,
};
