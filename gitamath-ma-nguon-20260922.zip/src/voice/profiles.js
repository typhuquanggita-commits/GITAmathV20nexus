'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HỒ SƠ GIỌNG GIẢNG VIÊN
 * ═══════════════════════════════════════════════════════════════════════════
 *  500 agent là 500 giảng viên. Mỗi người cần một giọng RIÊNG và ỔN ĐỊNH:
 *  học viên nghe quen giọng thầy dạy Toán thì buổi sau vẫn phải là giọng đó.
 *
 *  Giọng được suy ra TẤT ĐỊNH từ mã agent — không lưu bảng, không ngẫu nhiên,
 *  nên dựng lại hệ thống bao nhiêu lần giọng vẫn y nguyên.
 *
 *  Mỗi khối có một "chất giọng" nền khác nhau, vì vai trò khác nhau:
 *    · Toán học   — trầm, chậm, rõ từng bước
 *    · Gia sư     — ấm, vừa phải, gần gũi
 *    · Ngôn ngữ   — sáng, chuẩn âm, nhịp đều
 *    · Nghiên cứu — bình thản, hơi chậm
 *    · Kỹ thuật   — gọn, nhanh hơn một chút
 *    · Kinh doanh — dứt khoát, năng lượng cao
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { fnv1a, round, clamp } = require('../utils');
const { DIVISIONS } = require('../agents/taxonomy');

/** Chất giọng nền theo khối. */
const DIVISION_VOICE = {
  MATH: { name: 'Trầm, chậm, rõ từng bước', f0: 108, rate: 0.92, breathiness: 0.05, timbre: 0.97, f0Range: 0.14 },
  TUTOR: { name: 'Ấm, gần gũi, khuyến khích', f0: 138, rate: 0.98, breathiness: 0.09, timbre: 1.02, f0Range: 0.20 },
  VIETNAMESE: { name: 'Sáng, chuẩn âm, nhịp đều', f0: 152, rate: 1.00, breathiness: 0.07, timbre: 1.05, f0Range: 0.18 },
  RESEARCH: { name: 'Bình thản, mạch lạc', f0: 116, rate: 0.90, breathiness: 0.06, timbre: 0.99, f0Range: 0.12 },
  CODE: { name: 'Gọn, nhanh, chính xác', f0: 124, rate: 1.06, breathiness: 0.04, timbre: 1.00, f0Range: 0.13 },
  BUSINESS: { name: 'Dứt khoát, năng lượng cao', f0: 132, rate: 1.04, breathiness: 0.05, timbre: 1.03, f0Range: 0.22 },
};

/** Quãng f0 nền của bảng DIVISION_VOICE — dùng để quy về vị trí tương đối. */
const F0_SPAN = { lo: 108, hi: 152 };

/** Hai loại giọng cơ bản. Khoảng cao độ lấy theo giọng người Việt trưởng thành. */
const GENDERS = {
  nam: { label: 'nam', f0Min: 95, f0Max: 145, timbreShift: 0.96 },
  nữ: { label: 'nữ', f0Min: 175, f0Max: 245, timbreShift: 1.12 },
};

/** Cấp bậc ảnh hưởng tới cách nói, không ảnh hưởng tới chất giọng. */
const RANK_STYLE = {
  PLANNER: { rateMul: 0.97, f0RangeMul: 1.10, note: 'chậm rãi, dẫn dắt' },
  CRITIC: { rateMul: 0.95, f0RangeMul: 0.85, note: 'nghiêm, ít lên xuống' },
  GUARDIAN: { rateMul: 0.94, f0RangeMul: 0.80, note: 'dứt khoát, đều' },
  COACH: { rateMul: 1.00, f0RangeMul: 1.25, note: 'nhiều nhấn nhá, động viên' },
  RESEARCHER: { rateMul: 0.93, f0RangeMul: 0.95, note: 'điềm đạm' },
  WORKER: { rateMul: 1.00, f0RangeMul: 1.00, note: 'trung tính' },
};

/**
 * Dựng hồ sơ giọng cho một agent. Tất định theo mã agent.
 * @param {object} agent {id, division, rank, divisionName, rankName}
 */
function profileFor(agent) {
  if (!agent || !agent.id) return null;
  const h = fnv1a(agent.id);
  const base = DIVISION_VOICE[agent.division] || DIVISION_VOICE.VIETNAMESE;
  const style = RANK_STYLE[agent.rank] || RANK_STYLE.WORKER;

  // Giới tính giọng: chia đều trong mỗi khối, tất định theo mã.
  const gender = (h % 2 === 0) ? GENDERS.nam : GENDERS.nữ;

  // Lệch cá nhân trong khoảng hẹp để 500 giọng không giống hệt nhau
  // nhưng vẫn giữ được chất giọng chung của khối.
  const jitterA = ((h >>> 3) % 1000) / 1000;      // 0..1
  const jitterB = ((h >>> 13) % 1000) / 1000;
  const jitterC = ((h >>> 23) % 1000) / 1000;

  // Chất giọng của khối cho biết "sáng hay trầm" so với các khối khác; con số
  // tuyệt đối thì phải nằm trong quãng của giọng nam / giọng nữ. Nếu lấy thẳng
  // f0 của khối cho cả hai giới thì mọi giọng nam khối Ngôn ngữ đều bị kẹp về
  // đúng 145 Hz — 40 giảng viên chung một cao độ. Vì vậy quy về vị trí tương
  // đối rồi mới trải ra trong quãng của giới.
  const span = F0_SPAN.hi - F0_SPAN.lo;
  const pos = clamp((base.f0 - F0_SPAN.lo) / span, 0, 1);
  const gSpan = gender.f0Max - gender.f0Min;
  const f0Center = gender.f0Min + gSpan * 0.18 + pos * gSpan * 0.64;
  const f0 = clamp(round(f0Center + (jitterA - 0.5) * 16, 1), gender.f0Min, gender.f0Max);
  const rate = round(clamp(base.rate * style.rateMul + (jitterB - 0.5) * 0.08, 0.72, 1.28), 3);
  const timbre = round(clamp(base.timbre * gender.timbreShift + (jitterC - 0.5) * 0.06, 0.85, 1.25), 3);

  return {
    voiceId: `gv-${agent.id.toLowerCase()}`,
    agentId: agent.id,
    displayName: `${agent.rankName || agent.rank} ${agent.id}`,
    division: agent.division,
    divisionName: agent.divisionName || DIVISIONS[agent.division]?.name || agent.division,
    rank: agent.rank,
    gender: gender.label,
    character: `${base.name} · ${style.note}`,
    params: {
      f0,
      rate,
      timbre,
      breathiness: round(clamp(base.breathiness + (jitterA - 0.5) * 0.03, 0.02, 0.16), 3),
      f0Range: round(clamp(base.f0Range * style.f0RangeMul, 0.06, 0.30), 3),
      jitter: round(0.008 + jitterC * 0.010, 4),
      gain: 0.62,
      seed: `voice|${agent.id}`,
    },
    source: 'OFFLINE_FORMANT',
    quality: 'rõ tiếng, đúng thanh điệu — không phải giọng studio',
  };
}

/** Vài giọng chung không gắn với agent nào — dùng cho hệ thống nói chung. */
const SYSTEM_VOICES = {
  'he-thong-nu': {
    voiceId: 'he-thong-nu', displayName: 'Giọng hệ thống (nữ)', gender: 'nữ',
    character: 'Trung tính, rõ ràng, dùng cho thông báo',
    params: { f0: 205, rate: 1.0, timbre: 1.10, breathiness: 0.07, f0Range: 0.16, jitter: 0.010, gain: 0.62, seed: 'voice|he-thong-nu' },
  },
  'he-thong-nam': {
    voiceId: 'he-thong-nam', displayName: 'Giọng hệ thống (nam)', gender: 'nam',
    character: 'Trung tính, trầm, dùng cho thông báo',
    params: { f0: 118, rate: 1.0, timbre: 0.98, breathiness: 0.06, f0Range: 0.15, jitter: 0.010, gain: 0.62, seed: 'voice|he-thong-nam' },
  },
  'giang-bai-cham': {
    voiceId: 'giang-bai-cham', displayName: 'Giọng giảng bài chậm', gender: 'nữ',
    character: 'Chậm hơn 20%, dành cho học viên tầng thấp và bài khó',
    params: { f0: 196, rate: 0.80, timbre: 1.08, breathiness: 0.08, f0Range: 0.20, jitter: 0.011, gain: 0.62, seed: 'voice|cham' },
  },
};

class VoiceProfileRegistry {
  constructor({ agents = [] } = {}) {
    this.byVoiceId = new Map();
    this.byAgentId = new Map();
    for (const a of agents) {
      const p = profileFor(a);
      if (!p) continue;
      this.byVoiceId.set(p.voiceId, p);
      this.byAgentId.set(a.id, p);
    }
    for (const [id, v] of Object.entries(SYSTEM_VOICES)) {
      this.byVoiceId.set(id, { ...v, source: 'OFFLINE_FORMANT', quality: 'rõ tiếng, đúng thanh điệu — không phải giọng studio' });
    }
  }

  get(voiceId) { return this.byVoiceId.get(voiceId) || null; }
  forAgent(agentId) { return this.byAgentId.get(agentId) || null; }

  /** Chọn giọng phù hợp cho một việc dạy học cụ thể. */
  pick({ agentId = null, division = null, level = null, prefer = null } = {}) {
    if (prefer && this.byVoiceId.has(prefer)) return this.byVoiceId.get(prefer);
    if (agentId && this.byAgentId.has(agentId)) return this.byAgentId.get(agentId);
    // Học viên tầng thấp hoặc bài khó: dùng giọng đọc chậm.
    if (level != null && level <= 1) return this.byVoiceId.get('giang-bai-cham');
    if (division) {
      const first = [...this.byAgentId.values()].find((p) => p.division === division);
      if (first) return first;
    }
    return this.byVoiceId.get('he-thong-nu');
  }

  list({ division = null, gender = null, limit = 50, offset = 0 } = {}) {
    let all = [...this.byVoiceId.values()];
    if (division) all = all.filter((p) => p.division === division);
    if (gender) all = all.filter((p) => p.gender === gender);
    all.sort((a, b) => a.voiceId.localeCompare(b.voiceId));
    return { total: all.length, offset, limit, items: all.slice(offset, offset + limit) };
  }

  /** Thống kê để kiểm tra 500 giọng có thật sự khác nhau không. */
  stats() {
    const agents = [...this.byAgentId.values()];
    const byDivision = {};
    const byGender = {};
    for (const p of agents) {
      byDivision[p.division] = (byDivision[p.division] || 0) + 1;
      byGender[p.gender] = (byGender[p.gender] || 0) + 1;
    }
    const f0s = agents.map((p) => p.params.f0);
    const uniqueSignatures = new Set(agents.map((p) =>
      `${p.params.f0}|${p.params.rate}|${p.params.timbre}`)).size;
    return {
      total: this.byVoiceId.size,
      agentVoices: agents.length,
      systemVoices: Object.keys(SYSTEM_VOICES).length,
      byDivision,
      byGender,
      f0Min: Math.min(...f0s),
      f0Max: Math.max(...f0s),
      uniqueSignatures,
      distinctRatio: agents.length ? round(uniqueSignatures / agents.length, 3) : 0,
    };
  }
}

module.exports = { VoiceProfileRegistry, profileFor, DIVISION_VOICE, GENDERS, RANK_STYLE, SYSTEM_VOICES };
