'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ÂM VỊ HỌC TIẾNG ANH — phiên âm IPA để dạy phát âm và để máy đọc
 * ═══════════════════════════════════════════════════════════════════════════
 *  Tiếng Việt và tiếng Anh khác nhau ở CHỖ GỐC, nên không thể dùng chung bộ
 *  máy phát âm:
 *
 *    tiếng Việt          │ tiếng Anh
 *    ────────────────────┼──────────────────────────────────────────────────
 *    đơn âm tiết         │ đa âm tiết, có TRỌNG ÂM
 *    có thanh điệu       │ không thanh điệu, thay vào đó là ngữ điệu câu
 *    âm cuối ít, không bật│ âm cuối bắt buộc bật rõ, có cả cụm 3–4 phụ âm
 *    chữ viết gần như    │ chữ viết cách âm rất xa: "ough" đọc được 6 kiểu
 *    khớp một–một với âm │
 *
 *  Vì chữ viết tiếng Anh không khớp với âm, bộ này đi theo HAI ĐƯỜNG và luôn
 *  NÓI RÕ đã đi đường nào:
 *
 *    1. TỪ ĐIỂN  — phiên âm chép tay cho từ hay gặp và từ bất quy tắc.
 *                  Đây là nguồn đúng chắc chắn.
 *    2. LUẬT     — bộ luật chữ–âm có xét NGỮ CẢNH TRÁI VÀ PHẢI của từng chữ
 *                  cái. Dùng khi từ không có trong từ điển.
 *
 *  Mỗi kết quả trả về đều kèm trường `nguon` để người dùng biết dòng phiên âm
 *  đó là chắc chắn hay là suy ra. KHÔNG BAO GIỜ đoán mà không khai báo.
 *
 *  Trọng tâm sư phạm: bộ này sinh ra được CẶP TỐI THIỂU (minimal pair) và
 *  CHẨN ĐOÁN LỖI NGƯỜI VIỆT — hai thứ quyết định việc học phát âm có tiến bộ
 *  hay không. Người Việt sai tiếng Anh theo những kiểu rất đều, đoán trước
 *  được, nên chẩn đoán được bằng luật chứ không cần nghe.
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── BẢNG ÂM VỊ ──────────────────────────────────────────────────────────────
// ms: độ dài cơ sở khi đọc bình thường, dùng cho bộ tổng hợp giọng.
// khoMieng / viTri: mô tả cách cấu âm, dùng để sinh hướng dẫn cho người học.

const NGUYEN_AM_DON = {
  'iː': { loai: 'dài', moi: 'dẹt', luoi: 'trước cao', ms: 190, viet: 'i dài — kéo dài và căng môi như đang cười' },
  'ɪ': { loai: 'ngắn', moi: 'thả lỏng', luoi: 'trước hơi cao', ms: 105, viet: 'i ngắn — buông lỏng, KHÔNG kéo dài' },
  'e': { loai: 'ngắn', moi: 'hé', luoi: 'trước giữa', ms: 115, viet: 'e ngắn như "e" tiếng Việt nhưng gọn hơn' },
  'æ': { loai: 'ngắn', moi: 'mở rộng', luoi: 'trước thấp', ms: 140, viet: 'a bẹt — hàm hạ thấp, giữa "e" và "a"' },
  'ɑː': { loai: 'dài', moi: 'mở tròn nhẹ', luoi: 'sau thấp', ms: 200, viet: 'a dài, lưỡi lùi về sau' },
  'ɒ': { loai: 'ngắn', moi: 'tròn', luoi: 'sau thấp', ms: 115, viet: 'o ngắn, môi tròn, hàm mở' },
  'ɔː': { loai: 'dài', moi: 'tròn chặt', luoi: 'sau giữa', ms: 200, viet: 'o dài, môi tròn và đẩy ra trước' },
  'ʊ': { loai: 'ngắn', moi: 'tròn lỏng', luoi: 'sau cao', ms: 105, viet: 'u ngắn, môi tròn lỏng' },
  'uː': { loai: 'dài', moi: 'tròn chụm', luoi: 'sau cao', ms: 190, viet: 'u dài, môi chụm nhỏ và đẩy xa' },
  'ʌ': { loai: 'ngắn', moi: 'thả lỏng', luoi: 'giữa thấp', ms: 110, viet: 'â ngắn, gọn, không tròn môi' },
  'ɜː': { loai: 'dài', moi: 'thả lỏng', luoi: 'giữa', ms: 200, viet: 'ơ dài, lưỡi giữa miệng, giữ đều' },
  'ə': { loai: 'giảm', moi: 'thả lỏng', luoi: 'giữa', ms: 75, viet: 'ơ mờ — âm của âm tiết KHÔNG có trọng âm' },
  // Hai âm dưới đây không căng cũng không hẳn ngắn — chúng đứng ở âm tiết cuối
  // không mang trọng âm: "happy" /ˈhæpi/, "situation" /ˌsɪtʃuˈeɪʃn/. Từ điển
  // hiện đại ghi riêng chứ không gộp vào /iː/ hay /ɪ/.
  i: { loai: 'không căng', moi: 'dẹt', luoi: 'trước cao', ms: 95, viet: 'i nhẹ ở cuối từ, ngắn hơn /iː/ nhưng rõ hơn /ɪ/' },
  u: { loai: 'không căng', moi: 'tròn lỏng', luoi: 'sau cao', ms: 95, viet: 'u nhẹ, không nhấn' },
};

const NGUYEN_AM_DOI = {
  'eɪ': { tu: 'e', den: 'ɪ', ms: 210, viet: 'ê rồi lướt sang i' },
  'aɪ': { tu: 'a', den: 'ɪ', ms: 215, viet: 'a rồi lướt sang i' },
  'ɔɪ': { tu: 'ɔ', den: 'ɪ', ms: 215, viet: 'o rồi lướt sang i' },
  'aʊ': { tu: 'a', den: 'ʊ', ms: 215, viet: 'a rồi lướt sang u' },
  'əʊ': { tu: 'ə', den: 'ʊ', ms: 210, viet: 'ơ rồi lướt sang u (giọng Anh)' },
  'oʊ': { tu: 'o', den: 'ʊ', ms: 210, viet: 'ô rồi lướt sang u (giọng Mỹ)' },
  'ɪə': { tu: 'ɪ', den: 'ə', ms: 210, viet: 'i rồi lướt sang ơ' },
  'eə': { tu: 'e', den: 'ə', ms: 210, viet: 'e rồi lướt sang ơ' },
  'ʊə': { tu: 'ʊ', den: 'ə', ms: 210, viet: 'u rồi lướt sang ơ' },
};

const PHU_AM = {
  p: { loai: 'tắc', keu: false, viTri: 'hai môi', bat: true, ms: 70, viet: 'p bật hơi mạnh ở đầu từ' },
  b: { loai: 'tắc', keu: true, viTri: 'hai môi', bat: false, ms: 65, viet: 'b rung dây thanh' },
  t: { loai: 'tắc', keu: false, viTri: 'lợi', bat: true, ms: 70, viet: 't đầu lưỡi chạm lợi, bật hơi' },
  d: { loai: 'tắc', keu: true, viTri: 'lợi', bat: false, ms: 65, viet: 'd đầu lưỡi chạm lợi, rung thanh' },
  k: { loai: 'tắc', keu: false, viTri: 'ngạc mềm', bat: true, ms: 72, viet: 'k gốc lưỡi chạm ngạc mềm, bật hơi' },
  'ɡ': { loai: 'tắc', keu: true, viTri: 'ngạc mềm', bat: false, ms: 66, viet: 'g gốc lưỡi chạm ngạc mềm, rung thanh' },
  'tʃ': { loai: 'tắc xát', keu: false, viTri: 'lợi ngạc', bat: false, ms: 95, viet: 'ch bật rồi xát, như "ch" nhưng dài hơi hơn' },
  'dʒ': { loai: 'tắc xát', keu: true, viTri: 'lợi ngạc', bat: false, ms: 92, viet: 'gi bật rồi xát, rung thanh' },
  f: { loai: 'xát', keu: false, viTri: 'môi răng', bat: false, ms: 95, viet: 'ph — răng trên chạm môi dưới' },
  v: { loai: 'xát', keu: true, viTri: 'môi răng', bat: false, ms: 90, viet: 'v — răng trên chạm môi dưới, rung thanh' },
  'θ': { loai: 'xát', keu: false, viTri: 'răng', bat: false, ms: 100, viet: 'đầu lưỡi ĐẶT GIỮA hai hàm răng, thổi hơi' },
  'ð': { loai: 'xát', keu: true, viTri: 'răng', bat: false, ms: 92, viet: 'đầu lưỡi giữa hai hàm răng, rung thanh' },
  s: { loai: 'xát', keu: false, viTri: 'lợi', bat: false, ms: 100, viet: 'x — hơi thoát qua rãnh giữa lưỡi' },
  z: { loai: 'xát', keu: true, viTri: 'lợi', bat: false, ms: 95, viet: 'giống s nhưng rung dây thanh' },
  'ʃ': { loai: 'xát', keu: false, viTri: 'lợi ngạc', bat: false, ms: 105, viet: 's uốn — lưỡi lùi sau, môi hơi tròn' },
  'ʒ': { loai: 'xát', keu: true, viTri: 'lợi ngạc', bat: false, ms: 98, viet: 'giống ʃ nhưng rung dây thanh' },
  h: { loai: 'xát', keu: false, viTri: 'thanh hầu', bat: false, ms: 70, viet: 'h — chỉ là luồng hơi' },
  m: { loai: 'mũi', keu: true, viTri: 'hai môi', bat: false, ms: 85, viet: 'm — ngậm môi, hơi thoát qua mũi' },
  n: { loai: 'mũi', keu: true, viTri: 'lợi', bat: false, ms: 85, viet: 'n — đầu lưỡi chạm lợi, hơi qua mũi' },
  'ŋ': { loai: 'mũi', keu: true, viTri: 'ngạc mềm', bat: false, ms: 90, viet: 'ng — gốc lưỡi chạm ngạc mềm' },
  l: { loai: 'bên', keu: true, viTri: 'lợi', bat: false, ms: 85, viet: 'l — đầu lưỡi chạm lợi, hơi thoát hai bên' },
  r: { loai: 'tiếp cận', keu: true, viTri: 'sau lợi', bat: false, ms: 85, viet: 'r — lưỡi cong lên, KHÔNG rung như "r" tiếng Việt' },
  w: { loai: 'lướt', keu: true, viTri: 'môi ngạc mềm', bat: false, ms: 70, viet: 'w — môi chụm tròn rồi mở ra' },
  j: { loai: 'lướt', keu: true, viTri: 'ngạc cứng', bat: false, ms: 65, viet: 'i lướt, như "d" trong "duyên" giọng Nam' },
};

const LA_NGUYEN_AM = (p) => Object.hasOwn(NGUYEN_AM_DON, p) || Object.hasOwn(NGUYEN_AM_DOI, p);
const VO_THANH = new Set(['p', 't', 'k', 'f', 'θ', 's', 'ʃ', 'tʃ', 'h']);
const XUYT = new Set(['s', 'z', 'ʃ', 'ʒ', 'tʃ', 'dʒ']);


// ── TÁCH CHUỖI IPA THÀNH TỪNG ÂM VỊ ─────────────────────────────────────────
// Phiên âm viết liền như "ˈhæpi" phải tách được thành [h, æ, p, i]. Vì có âm
// vị hai ký tự (iː, tʃ, əʊ…) nên phải khớp DÀI TRƯỚC NGẮN SAU, nếu không
// "iː" sẽ bị đọc thành "ɪ" rồi thừa một dấu kéo dài.
const MOI_AM_VI = [...Object.keys(NGUYEN_AM_DOI), ...Object.keys(NGUYEN_AM_DON), ...Object.keys(PHU_AM)]
  .sort((a, b) => b.length - a.length);

function tachIPA(chuoi) {
  const s = String(chuoi || '');
  const am = [];
  let trongAm = 0;          // vị trí âm vị mở đầu âm tiết mang trọng âm chính
  let phuTrongAm = -1;
  let i = 0;
  const khong = [];
  while (i < s.length) {
    const c = s[i];
    if (c === 'ˈ') { trongAm = am.length; i++; continue; }
    if (c === 'ˌ') { phuTrongAm = am.length; i++; continue; }
    if (c === '.' || c === ' ') { i++; continue; }
    let khop = null;
    for (const p of MOI_AM_VI) { if (s.startsWith(p, i)) { khop = p; break; } }
    if (!khop) { khong.push({ vt: i, ky: c }); i++; continue; }
    am.push(khop);
    i += khop.length;
  }
  return { am, trongAm, phuTrongAm, khong };
}

// ── TỪ ĐIỂN PHIÊN ÂM ────────────────────────────────────────────────────────
// Chép tay theo giọng Anh - Anh (RP). Ưu tiên ba nhóm:
//   1. từ chức năng (the, of, to…) — chiếm phần lớn số lượt xuất hiện trong
//      văn bản thật, và hầu hết đều bất quy tắc;
//   2. từ bất quy tắc hay gặp (one, two, said, women…);
//   3. từ vựng chương trình phổ thông có chữ viết đánh lừa.
// Từ nào không nằm ở đây sẽ được suy ra bằng bộ luật phía dưới, và kết quả
// luôn ghi rõ nguồn là "luật" chứ không nhận là chắc chắn.
const TU_DIEN = {
  // — từ chức năng —
  a: 'ə', an: 'ən', the: 'ðə', and: 'ænd', or: 'ɔː', but: 'bʌt', of: 'ɒv', to: 'tuː',
  in: 'ɪn', on: 'ɒn', at: 'æt', by: 'baɪ', for: 'fɔː', from: 'frɒm', with: 'wɪð',
  as: 'æz', is: 'ɪz', are: 'ɑː', was: 'wɒz', were: 'wɜː', be: 'biː', been: 'biːn',
  am: 'æm', do: 'duː', does: 'dʌz', did: 'dɪd', done: 'dʌn', have: 'hæv', has: 'hæz',
  had: 'hæd', will: 'wɪl', would: 'wʊd', shall: 'ʃæl', should: 'ʃʊd', can: 'kæn',
  could: 'kʊd', may: 'meɪ', might: 'maɪt', must: 'mʌst', i: 'aɪ', you: 'juː',
  he: 'hiː', she: 'ʃiː', it: 'ɪt', we: 'wiː', they: 'ðeɪ', me: 'miː', him: 'hɪm',
  her: 'hɜː', us: 'ʌs', them: 'ðem', my: 'maɪ', your: 'jɔː', his: 'hɪz', its: 'ɪts',
  our: 'aʊə', their: 'ðeə', this: 'ðɪs', that: 'ðæt', these: 'ðiːz', those: 'ðəʊz',
  there: 'ðeə', here: 'hɪə', where: 'weə', when: 'wen', what: 'wɒt', who: 'huː',
  whose: 'huːz', which: 'wɪtʃ', why: 'waɪ', how: 'haʊ', not: 'nɒt', no: 'nəʊ',
  yes: 'jes', all: 'ɔːl', any: 'ˈeni', some: 'sʌm', many: 'ˈmeni', much: 'mʌtʃ',
  more: 'mɔː', most: 'məʊst', other: 'ˈʌðə', another: 'əˈnʌðə', such: 'sʌtʃ',
  than: 'ðæn', then: 'ðen', too: 'tuː', very: 'ˈveri', also: 'ˈɔːlsəʊ', only: 'ˈəʊnli',
  just: 'dʒʌst', now: 'naʊ', again: 'əˈɡen', ever: 'ˈevə', never: 'ˈnevə',
  always: 'ˈɔːlweɪz', often: 'ˈɒfn', once: 'wʌns', because: 'bɪˈkɒz', if: 'ɪf',
  so: 'səʊ', up: 'ʌp', down: 'daʊn', out: 'aʊt', over: 'ˈəʊvə', under: 'ˈʌndə',
  about: 'əˈbaʊt', after: 'ˈɑːftə', before: 'bɪˈfɔː', between: 'bɪˈtwiːn',
  through: 'θruː', during: 'ˈdjʊərɪŋ', into: 'ˈɪntuː', off: 'ɒf', 

  // — số đếm —
  one: 'wʌn', two: 'tuː', three: 'θriː', four: 'fɔː', five: 'faɪv', six: 'sɪks',
  seven: 'ˈsevn', eight: 'eɪt', nine: 'naɪn', ten: 'ten', eleven: 'ɪˈlevn',
  twelve: 'twelv', thirteen: 'ˌθɜːˈtiːn', twenty: 'ˈtwenti', thirty: 'ˈθɜːti',
  forty: 'ˈfɔːti', fifty: 'ˈfɪfti', hundred: 'ˈhʌndrəd', thousand: 'ˈθaʊznd',
  million: 'ˈmɪljən', first: 'fɜːst', second: 'ˈsekənd', third: 'θɜːd',

  // — động từ bất quy tắc và từ chữ viết đánh lừa —
  said: 'sed', says: 'sez', come: 'kʌm', came: 'keɪm', go: 'ɡəʊ',
  goes: 'ɡəʊz', went: 'went', gone: 'ɡɒn', give: 'ɡɪv', gave: 'ɡeɪv', get: 'ɡet',
  got: 'ɡɒt', make: 'meɪk', made: 'meɪd', take: 'teɪk', took: 'tʊk', taken: 'ˈteɪkən',
  know: 'nəʊ', knew: 'njuː', known: 'nəʊn', think: 'θɪŋk', thought: 'θɔːt',
  see: 'siː', saw: 'sɔː', seen: 'siːn', look: 'lʊk', find: 'faɪnd', found: 'faʊnd',
  want: 'wɒnt', use: 'juːz', used: 'juːzd', work: 'wɜːk', call: 'kɔːl', try: 'traɪ',
  ask: 'ɑːsk', need: 'niːd', feel: 'fiːl', felt: 'felt', leave: 'liːv', left: 'left',
  put: 'pʊt', mean: 'miːn', meant: 'ment', keep: 'kiːp', kept: 'kept', let: 'let',
  begin: 'bɪˈɡɪn', began: 'bɪˈɡæn', begun: 'bɪˈɡʌn', seem: 'siːm', help: 'help',
  talk: 'tɔːk', turn: 'tɜːn', start: 'stɑːt', show: 'ʃəʊ', hear: 'hɪə', heard: 'hɜːd',
  play: 'pleɪ', run: 'rʌn', ran: 'ræn', move: 'muːv', live: 'lɪv', believe: 'bɪˈliːv',
  bring: 'brɪŋ', brought: 'brɔːt', write: 'raɪt', wrote: 'rəʊt', written: 'ˈrɪtn',
  read: 'riːd', sit: 'sɪt', sat: 'sæt', stand: 'stænd', stood: 'stʊd', lose: 'luːz',
  lost: 'lɒst', pay: 'peɪ', paid: 'peɪd', meet: 'miːt', met: 'met', learn: 'lɜːn',
  change: 'tʃeɪndʒ', watch: 'wɒtʃ', follow: 'ˈfɒləʊ', stop: 'stɒp', create: 'kriˈeɪt',
  speak: 'spiːk', spoke: 'spəʊk', spoken: 'ˈspəʊkən', eat: 'iːt', ate: 'et',
  buy: 'baɪ', bought: 'bɔːt', build: 'bɪld', built: 'bɪlt', teach: 'tiːtʃ',
  taught: 'tɔːt', catch: 'kætʃ', caught: 'kɔːt', choose: 'tʃuːz', chose: 'tʃəʊz',
  break: 'breɪk', broke: 'brəʊk', draw: 'drɔː', drew: 'druː', drive: 'draɪv',
  drove: 'drəʊv', fall: 'fɔːl', fell: 'fel', fly: 'flaɪ', flew: 'fluː',
  grow: 'ɡrəʊ', grew: 'ɡruː', hold: 'həʊld', held: 'held', sing: 'sɪŋ', sang: 'sæŋ',
  swim: 'swɪm', swam: 'swæm', wear: 'weə', wore: 'wɔː', win: 'wɪn', won: 'wʌn',
  sleep: 'sliːp', slept: 'slept', send: 'send', sent: 'sent', spend: 'spend',
  spent: 'spent', lie: 'laɪ', die: 'daɪ', tie: 'taɪ',

  // — danh từ, tính từ hay gặp mà chữ viết đánh lừa —
  people: 'ˈpiːpl', woman: 'ˈwʊmən', women: 'ˈwɪmɪn', man: 'mæn', men: 'men',
  child: 'tʃaɪld', children: 'ˈtʃɪldrən', friend: 'frend', family: 'ˈfæməli',
  school: 'skuːl', student: 'ˈstjuːdnt', teacher: 'ˈtiːtʃə', class: 'klɑːs',
  lesson: 'ˈlesn', book: 'bʊk', word: 'wɜːd', language: 'ˈlæŋɡwɪdʒ',
  english: 'ˈɪŋɡlɪʃ', science: 'ˈsaɪəns', mathematics: 'ˌmæθəˈmætɪks',
  question: 'ˈkwestʃən', answer: 'ˈɑːnsə', example: 'ɪɡˈzɑːmpl', number: 'ˈnʌmbə',
  water: 'ˈwɔːtə', food: 'fuːd', bread: 'bred', heart: 'hɑːt', head: 'hed',
  health: 'helθ', earth: 'ɜːθ', early: 'ˈɜːli', 
  hour: 'aʊə', honest: 'ˈɒnɪst', island: 'ˈaɪlənd', business: 'ˈbɪznəs',
  minute: 'ˈmɪnɪt', money: 'ˈmʌni', colour: 'ˈkʌlə', color: 'ˈkʌlə',
  country: 'ˈkʌntri', county: 'ˈkaʊnti', young: 'jʌŋ', enough: 'ɪˈnʌf',
  though: 'ðəʊ', although: 'ɔːlˈðəʊ', thorough: 'ˈθʌrə',
  laugh: 'lɑːf', cough: 'kɒf', rough: 'rʌf', tough: 'tʌf', daughter: 'ˈdɔːtə',
  height: 'haɪt', weight: 'weɪt', neighbour: 'ˈneɪbə',
  machine: 'məˈʃiːn', chemistry: 'ˈkemɪstri', character: 'ˈkærəktə',
  christmas: 'ˈkrɪsməs', stomach: 'ˈstʌmək',
  sure: 'ʃɔː', sugar: 'ˈʃʊɡə', vision: 'ˈvɪʒn', usual: 'ˈjuːʒuəl',
  measure: 'ˈmeʒə', pleasure: 'ˈpleʒə', treasure: 'ˈtreʒə',
  nation: 'ˈneɪʃn', station: 'ˈsteɪʃn', education: 'ˌedʒuˈkeɪʃn',
  information: 'ˌɪnfəˈmeɪʃn', important: 'ɪmˈpɔːtnt', interest: 'ˈɪntrəst',
  develop: 'dɪˈveləp', government: 'ˈɡʌvnmənt', company: 'ˈkʌmpəni',
  photograph: 'ˈfəʊtəɡrɑːf', photography: 'fəˈtɒɡrəfi', comfortable: 'ˈkʌmftəbl',
  vegetable: 'ˈvedʒtəbl', restaurant: 'ˈrestrɒnt', chocolate: 'ˈtʃɒklət',
  temperature: 'ˈtemprətʃə', favourite: 'ˈfeɪvərɪt', favorite: 'ˈfeɪvərɪt',
  wednesday: 'ˈwenzdeɪ', february: 'ˈfebruəri', library: 'ˈlaɪbrəri',
  something: 'ˈsʌmθɪŋ', nothing: 'ˈnʌθɪŋ', anything: 'ˈeniθɪŋ', everything: 'ˈevriθɪŋ',
  everyone: 'ˈevriwʌn', someone: 'ˈsʌmwʌn', anyone: 'ˈeniwʌn', everybody: 'ˈevribɒdi',
  birthday: 'ˈbɜːθdeɪ', healthy: 'ˈhelθi', method: 'ˈmeθəd', author: 'ˈɔːθə',
  father: 'ˈfɑːðə', mother: 'ˈmʌðə', brother: 'ˈbrʌðə', sister: 'ˈsɪstə',
  weather: 'ˈweðə', together: 'təˈɡeðə', whether: 'ˈweðə', either: 'ˈaɪðə',
  neither: 'ˈnaɪðə', computer: 'kəmˈpjuːtə', picture: 'ˈpɪktʃə',
  nature: 'ˈneɪtʃə', future: 'ˈfjuːtʃə', culture: 'ˈkʌltʃə',
  music: 'ˈmjuːzɪk', unit: 'ˈjuːnɪt', human: 'ˈhjuːmən', duty: 'ˈdjuːti',
  university: 'ˌjuːnɪˈvɜːsəti', museum: 'mjuˈziːəm', stupid: 'ˈstjuːpɪd',
  tube: 'tjuːb', cube: 'kjuːb', pupil: 'ˈpjuːpl', menu: 'ˈmenjuː',
  study: 'ˈstʌdi', hungry: 'ˈhʌŋɡri', angry: 'ˈæŋɡri',
  listen: 'ˈlɪsn', castle: 'ˈkɑːsl', fasten: 'ˈfɑːsn', whistle: 'ˈwɪsl',
  clothes: 'kləʊðz', receipt: 'rɪˈsiːt', debt: 'det', doubt: 'daʊt',
  climb: 'klaɪm', thumb: 'θʌm', lamb: 'læm', comb: 'kəʊm',
  knife: 'naɪf', knee: 'niː', knock: 'nɒk', wrong: 'rɒŋ',
  walk: 'wɔːk', half: 'hɑːf', calm: 'kɑːm', palm: 'pɑːm',
  busy: 'ˈbɪzi', guide: 'ɡaɪd', guess: 'ɡes', guest: 'ɡest',
  tongue: 'tʌŋ', league: 'liːɡ', unique: 'juˈniːk', antique: 'ænˈtiːk',
  beautiful: 'ˈbjuːtɪfl', beauty: 'ˈbjuːti', queue: 'kjuː',
  sheep: 'ʃiːp', ship: 'ʃɪp', slip: 'slɪp', beat: 'biːt',
  bit: 'bɪt', seat: 'siːt', fill: 'fɪl',
  reach: 'riːtʃ', rich: 'rɪtʃ', least: 'liːst',
  list: 'lɪst', green: 'ɡriːn', grin: 'ɡrɪn', deep: 'diːp', dip: 'dɪp',
  cheap: 'tʃiːp', chip: 'tʃɪp', heel: 'hiːl', hill: 'hɪl', peak: 'piːk',
  pick: 'pɪk', team: 'tiːm', week: 'wiːk', wick: 'wɪk',
  each: 'iːtʃ', itch: 'ɪtʃ', bean: 'biːn', bin: 'bɪn',
  keen: 'kiːn', kin: 'kɪn', meal: 'miːl', mill: 'mɪl', wheel: 'wiːl',
  steal: 'stiːl', still: 'stɪl', scene: 'siːn', sin: 'sɪn',
};

// ── BỘ LUẬT CHỮ → ÂM ────────────────────────────────────────────────────────
// Mỗi luật gồm bốn phần, đọc như một câu: "khi bên TRÁI là …, chữ ĐANG XÉT là
// …, bên PHẢI là …, thì đọc thành …".
//
//   t   ngữ cảnh trái  — biểu thức chính quy khớp phần đứng TRƯỚC, neo cuối ($)
//   c   chữ đang xét   — khớp nguyên văn, có thể nhiều chữ cái
//   p   ngữ cảnh phải  — khớp phần đứng SAU, neo đầu (^)
//   a   dãy âm vị      — mảng rỗng nghĩa là chữ câm
//
// Luật xếp theo thứ tự ưu tiên: luật hẹp đứng trước luật rộng. Luật cuối cùng
// của mỗi chữ cái luôn là luật mặc định, nên không bao giờ có chữ nào rơi ra
// ngoài — mọi từ đều phiên âm được, dù có thể chưa chuẩn.
//
// Từ được xử lý ở dạng CHỮ THƯỜNG có thêm dấu cách hai đầu, nên "^ " nghĩa là
// đầu từ và " $" nghĩa là cuối từ.

const NA = '[aeiouy]';                 // chữ nguyên âm
const PA = '[bcdfghjklmnpqrstvwxz]';   // chữ phụ âm
const TRUOC = '[eiy]';                 // nguyên âm hàng trước — quyết định c/g mềm
// Phụ âm KHÔNG phải âm xuýt. Luật "e câm" chỉ được áp dụng khi phụ âm đứng
// trước "e" không phải âm xuýt, nếu không "boxes" sẽ bị đọc như "bokes".
const PA_KHONG_XUYT = '[bcdfgklmnpqrtvw]';

const LUAT = [
  // ═══ A ═══
  { c: 'a', t: ` $`, p: ` $`, a: ['ə'] },
  { c: 'air', p: '', a: ['eə'] },
  { c: 'are', p: ` $`, a: ['ɑː'] },
  { c: 'ai', p: '', a: ['eɪ'] },
  { c: 'ay', p: '', a: ['eɪ'] },
  { c: 'au', p: '', a: ['ɔː'] },
  { c: 'aw', p: '', a: ['ɔː'] },
  { c: 'all', p: '', a: ['ɔː', 'l'] },
  { c: 'al', p: `[kmf]`, a: ['ɑː'] },
  { c: 'ar', p: `${NA}`, a: ['eə', 'r'] },
  { c: 'ar', p: '', a: ['ɑː'] },
  { c: 'a', p: `${PA}e $`, a: ['eɪ'] },
  { c: 'a', p: `${PA_KHONG_XUYT}e[sd] $`, a: ['eɪ'] },
  { c: 'a', p: `nge`, a: ['eɪ'] },
  { c: 'a', p: `tion`, a: ['eɪ'] },
  { c: 'a', p: `sion`, a: ['eɪ'] },
  { c: 'a', p: `ble $`, a: ['eɪ'] },
  { c: 'a', p: '', a: ['æ'] },

  // ═══ E ═══
  { c: 'eau', p: '', a: ['juː'] },
  { c: 'ee', p: `r`, a: ['ɪə'] },
  { c: 'ee', p: '', a: ['iː'] },
  { c: 'ear', p: ` $`, a: ['ɪə'] },
  { c: 'ear', p: `${PA}`, a: ['ɜː'] },
  { c: 'ea', p: '', a: ['iː'] },
  { c: 'ei', p: '', a: ['eɪ'] },
  { c: 'eu', p: '', a: ['juː'] },
  { c: 'ew', p: '', a: ['juː'] },
  { c: 'ey', p: ` $`, a: ['i'] },
  { c: 'er', p: ` $`, a: ['ə'] },
  { c: 'er', p: `${PA}`, a: ['ɜː'] },
  // Đuôi "-ed" của quá khứ đọc ba kiểu, phụ thuộc âm đứng ngay trước nó. Đây
  // là chỗ người Việt sai gần như tuyệt đối: đọc đều thành "ét" cho cả ba.
  { c: 'ed', t: `^ .*${NA}.*[td]`, p: ` $`, a: ['ɪ', 'd'] },
  { c: 'ed', t: `^ .*${NA}.*[pkfsxc]`, p: ` $`, a: ['t'] },
  { c: 'ed', t: `^ .*${NA}.*${PA}`, p: ` $`, a: ['d'] },
  { c: 'ed', t: `^ .*${NA}`, p: ` $`, a: ['d'] },
  // Đuôi "-es" sau âm xuýt phải thêm hẳn một âm tiết /ɪz/.
  { c: 'es', t: `^ .*${NA}.*(?:[sxz]|ch|sh)`, p: ` $`, a: ['ɪ', 'z'] },
  { c: 'e', p: `${PA}e $`, a: ['iː'] },
  // "e" cuối từ là chữ câm khi trước nó đã có nguyên âm rồi phụ âm: "make",
  // "write". Từ hai chữ cái như "be", "he" không thoả điều kiện đó nên không
  // bị coi là chữ câm.
  { c: 'e', t: `^ .*${NA}${PA}+`, p: ` $`, a: [] },
  { c: 'e', t: `^ .*${NA}${PA}+`, p: `[sd] $`, a: [] },
  { c: 'e', p: '', a: ['e'] },

  // ═══ I ═══
  { c: 'igh', p: '', a: ['aɪ'] },
  { c: 'ir', p: '', a: ['ɜː'] },
  { c: 'ie', p: ` $`, a: ['aɪ'] },
  { c: 'ie', p: '', a: ['iː'] },
  { c: 'i', p: `nd $`, a: ['aɪ'] },
  { c: 'i', p: `ld $`, a: ['aɪ'] },
  { c: 'i', p: `${PA}e $`, a: ['aɪ'] },
  { c: 'i', p: `${PA_KHONG_XUYT}e[sd] $`, a: ['aɪ'] },
  { c: 'i', p: `on `, a: ['ɪ'] },
  { c: 'i', p: '', a: ['ɪ'] },

  // ═══ O ═══
  { c: 'ook', p: '', a: ['ʊ', 'k'] },
  { c: 'oo', p: `[dk]`, a: ['ʊ'] },
  { c: 'oo', p: '', a: ['uː'] },
  { c: 'ou', p: `r $`, a: ['ʊə'] },
  { c: 'ou', p: '', a: ['aʊ'] },
  { c: 'ow', p: ` $`, a: ['əʊ'] },
  { c: 'ow', p: `${PA}`, a: ['aʊ'] },
  { c: 'ow', p: '', a: ['əʊ'] },
  { c: 'oi', p: '', a: ['ɔɪ'] },
  { c: 'oy', p: '', a: ['ɔɪ'] },
  { c: 'oa', p: '', a: ['əʊ'] },
  { c: 'oe', p: ` $`, a: ['əʊ'] },
  { c: 'or', p: `${NA}`, a: ['ɒ', 'r'] },
  { c: 'or', p: '', a: ['ɔː'] },
  { c: 'o', p: `ld`, a: ['əʊ'] },
  { c: 'o', p: `st $`, a: ['əʊ'] },
  { c: 'o', p: `${PA}e $`, a: ['əʊ'] },
  { c: 'o', p: `${PA_KHONG_XUYT}e[sd] $`, a: ['əʊ'] },
  { c: 'o', p: ` $`, a: ['əʊ'] },
  { c: 'o', p: '', a: ['ɒ'] },

  // ═══ U ═══
  { c: 'ur', p: '', a: ['ɜː'] },
  { c: 'ue', p: ` $`, a: ['uː'] },
  { c: 'ui', p: '', a: ['uː'] },
  // Sau l, r, j thì "u" dài KHÔNG có âm lướt /j/: rule /ruːl/ chứ không /rjuːl/.
  { c: 'u', t: `[lrj]`, p: `${PA}e $`, a: ['uː'] },
  { c: 'u', p: `${PA}e $`, a: ['j', 'uː'] },
  { c: 'u', t: `[lrj]`, p: ` $`, a: ['uː'] },
  { c: 'u', p: '', a: ['ʌ'] },

  // ═══ Y ═══
  { c: 'y', t: `^ `, p: `${NA}`, a: ['j'] },
  { c: 'y', t: `^ ${PA}+`, p: ` $`, a: ['aɪ'] },
  { c: 'y', p: ` $`, a: ['i'] },
  { c: 'y', p: '', a: ['ɪ'] },

  // ═══ PHỤ ÂM ═══
  { c: 'tion', p: '', a: ['ʃ', 'ə', 'n'] },
  { c: 'ture', p: ` $`, a: ['tʃ', 'ə'] },
  { c: 'tious', p: '', a: ['ʃ', 'ə', 's'] },
  { c: 'cious', p: '', a: ['ʃ', 'ə', 's'] },
  { c: 'ssion', p: '', a: ['ʃ', 'ə', 'n'] },
  { c: 'sion', t: `${NA}`, p: '', a: ['ʒ', 'ə', 'n'] },
  { c: 'sion', p: '', a: ['ʃ', 'ə', 'n'] },
  { c: 'tch', p: '', a: ['tʃ'] },
  { c: 'ch', p: '', a: ['tʃ'] },
  { c: 'ck', p: '', a: ['k'] },
  { c: 'c', p: `${TRUOC}`, a: ['s'] },
  { c: 'c', p: '', a: ['k'] },

  // Phụ âm viết đôi chỉ đọc MỘT lần: "happy" là /ˈhæpi/, không phải /ˈhæppi/.
  { c: 'bb', p: '', a: ['b'] },
  { c: 'cc', p: `${TRUOC}`, a: ['k', 's'] },
  { c: 'cc', p: '', a: ['k'] },
  { c: 'dd', p: '', a: ['d'] },
  { c: 'ff', p: '', a: ['f'] },
  { c: 'll', p: '', a: ['l'] },
  { c: 'mm', p: '', a: ['m'] },
  { c: 'nn', p: '', a: ['n'] },
  { c: 'pp', p: '', a: ['p'] },
  { c: 'rr', p: '', a: ['r'] },
  { c: 'tt', p: '', a: ['t'] },
  { c: 'zz', p: '', a: ['z'] },

  { c: 'dge', p: '', a: ['dʒ'] },
  { c: 'd', p: '', a: ['d'] },

  { c: 'gh', t: `^ `, p: '', a: ['ɡ'] },
  { c: 'gh', p: '', a: [] },
  { c: 'gg', p: '', a: ['ɡ'] },
  { c: 'gn', t: `^ `, p: '', a: ['n'] },
  { c: 'gn', p: ` $`, a: ['n'] },
  { c: 'g', p: `${TRUOC}`, a: ['dʒ'] },
  { c: 'g', p: '', a: ['ɡ'] },

  { c: 'kn', t: `^ `, p: '', a: ['n'] },
  { c: 'k', p: '', a: ['k'] },

  { c: 'mb', p: ` $`, a: ['m'] },
  { c: 'm', p: '', a: ['m'] },

  { c: 'ng', p: ` $`, a: ['ŋ'] },
  { c: 'nk', p: '', a: ['ŋ', 'k'] },
  { c: 'n', p: '', a: ['n'] },

  { c: 'ph', p: '', a: ['f'] },
  { c: 'p', p: '', a: ['p'] },

  { c: 'qu', p: '', a: ['k', 'w'] },
  { c: 'q', p: '', a: ['k'] },

  { c: 'sh', p: '', a: ['ʃ'] },
  { c: 'ss', p: '', a: ['s'] },
  { c: 's', p: '', a: ['s'] },

  // Ngoại lệ của luật ngay dưới: "-thing" là một từ ghép (some+thing), nên
  // "th" ở đây vẫn ĐIẾC dù đứng giữa hai nguyên âm.
  { c: 'thing', p: ` $`, a: ['θ', 'ɪ', 'ŋ'] },
  // "th" giữa hai nguyên âm gần như luôn KÊU: father, mother, weather, other.
  { c: 'th', t: `${NA}`, p: `${NA}`, a: ['ð'] },
  { c: 'th', p: '', a: ['θ'] },
  { c: 't', p: '', a: ['t'] },

  // "wor" + phụ âm luôn là /wɜː/: word, work, world, worth, worse.
  { c: 'wor', p: `${PA}`, a: ['w', 'ɜː'] },
  { c: 'wh', p: '', a: ['w'] },
  { c: 'wr', t: `^ `, p: '', a: ['r'] },
  { c: 'w', p: '', a: ['w'] },

  { c: 'x', t: `^ `, p: '', a: ['z'] },
  { c: 'x', p: '', a: ['k', 's'] },

  { c: 'b', p: '', a: ['b'] },
  { c: 'f', p: '', a: ['f'] },
  { c: 'h', p: '', a: ['h'] },
  { c: 'j', p: '', a: ['dʒ'] },
  { c: 'l', p: '', a: ['l'] },
  { c: 'r', p: '', a: ['r'] },
  { c: 'v', p: '', a: ['v'] },
  { c: 'z', p: '', a: ['z'] },
  { c: "'", p: '', a: [] },
  { c: '-', p: '', a: [] },
];

// Biên dịch sẵn biểu thức chính quy một lần, để phiên âm cả trang không phải
// dựng lại hàng nghìn lần.
const LUAT_THEO_CHU = new Map();
for (const r of LUAT) {
  const d = r.c[0];
  if (!LUAT_THEO_CHU.has(d)) LUAT_THEO_CHU.set(d, []);
  LUAT_THEO_CHU.get(d).push({
    ...r,
    reT: r.t ? new RegExp(`${r.t}$`) : null,
    reP: r.p ? new RegExp(`^${r.p}`) : null,
  });
}

/**
 * Phiên âm một từ bằng bộ luật. Trả về dãy âm vị và danh sách luật đã dùng —
 * người soạn bài nhìn vào là biết vì sao máy đọc như vậy.
 */
function theoLuat(tu) {
  const s = ` ${String(tu).toLowerCase()} `;
  const am = [];
  const vet = [];
  let i = 1;
  while (i < s.length - 1) {
    const ds = LUAT_THEO_CHU.get(s[i]);
    let xong = false;
    if (ds) {
      for (const r of ds) {
        if (!s.startsWith(r.c, i)) continue;
        if (r.reT && !r.reT.test(s.slice(0, i))) continue;
        if (r.reP && !r.reP.test(s.slice(i + r.c.length))) continue;
        am.push(...r.a);
        vet.push({ chu: r.c, am: r.a.join(''), tai: i - 1 });
        i += r.c.length;
        xong = true;
        break;
      }
    }
    if (!xong) { vet.push({ chu: s[i], am: '?', tai: i - 1, khongCoLuat: true }); i++; }
  }
  return { am: dongHoaDuoiS(am, s.trim()), vet };
}

/**
 * Đuôi "-s" đọc /s/ hay /z/ là do ÂM đứng ngay trước nó quyết định, không
 * phải do chữ cái. "makes" có chữ "e" đứng trước nhưng chữ đó câm, âm thật
 * đứng trước là /k/ nên đuôi đọc /s/. Vì vậy phải quyết định SAU khi đã ra âm.
 * Đây đúng là chỗ người Việt bỏ sót nhiều nhất khi nói tiếng Anh.
 */
function dongHoaDuoiS(am, tu) {
  if (am.length < 2) return am;
  if (!/[^s]s$/.test(tu)) return am;
  if (am[am.length - 1] !== 's') return am;
  const truoc = am[am.length - 2];
  if (XUYT.has(truoc)) { am[am.length - 1] = 'ɪ'; am.push('z'); return am; }
  if (!VO_THANH.has(truoc)) am[am.length - 1] = 'z';
  return am;
}

// ── TÁCH ÂM TIẾT ────────────────────────────────────────────────────────────
// Số âm tiết bằng số nguyên âm. Chỗ cắt lấy theo NGUYÊN TẮC ĐẦU ÂM TỐI ĐA:
// cụm phụ âm giữa hai nguyên âm được dồn hết về âm tiết SAU, miễn là cụm đó
// đứng đầu từ được trong tiếng Anh. Phần thừa rơi lại làm âm cuối của âm tiết
// trước. Đây là lý do "a-ˈbout" chứ không phải "ab-ˈout".
const DAU_AM_HOP_LE = new Set([
  'pl', 'bl', 'kl', 'ɡl', 'fl', 'sl', 'pr', 'br', 'tr', 'dr', 'kr', 'ɡr', 'fr', 'θr', 'ʃr',
  'tw', 'dw', 'kw', 'sw', 'θw', 'sp', 'st', 'sk', 'sm', 'sn', 'sf',
  'spl', 'spr', 'str', 'skr', 'skw', 'spj', 'stj', 'skj',
  'pj', 'bj', 'kj', 'ɡj', 'fj', 'vj', 'mj', 'nj', 'hj', 'lj',
]);

// Phụ âm có thể TỰ LÀM HẠT NHÂN âm tiết khi đứng sau một phụ âm tắc/xát và
// không có nguyên âm nào bên cạnh: "button" /ˈbʌtn̩/, "little" /ˈlɪtl̩/. Nếu
// không tính chúng thì số âm tiết sai, kéo theo trọng âm đặt sai.
const CAN_SONORANT = new Set(['l', 'n', 'm', 'r', 'ŋ', 'w', 'j']);
const TU_LAM_HAT_NHAN = new Set(['n', 'l']);

function laHatNhan(am, i) {
  const p = am[i];
  if (LA_NGUYEN_AM(p)) return true;
  if (!TU_LAM_HAT_NHAN.has(p)) return false;
  const truoc = am[i - 1];
  if (!truoc || LA_NGUYEN_AM(truoc) || CAN_SONORANT.has(truoc)) return false;
  return true;
}

function tachAmTiet(am) {
  const viTriNguyenAm = [];
  am.forEach((p, i) => { if (laHatNhan(am, i)) viTriNguyenAm.push(i); });
  if (!viTriNguyenAm.length) return [{ tu: 0, den: am.length, nhan: 0 }];

  const cat = [0];
  for (let k = 0; k < viTriNguyenAm.length - 1; k++) {
    const a = viTriNguyenAm[k];
    const b = viTriNguyenAm[k + 1];
    const cum = am.slice(a + 1, b);
    if (cum.length === 0) { cat.push(b); continue; }
    if (cum.length === 1) { cat.push(b - 1); continue; }
    // Thử dồn tối đa về sau, cắt bớt dần cho tới khi đầu âm hợp lệ.
    let batDau = b - cum.length;
    for (let lay = cum.length; lay >= 1; lay--) {
      const thu = am.slice(b - lay, b).join('');
      if (lay === 1 || DAU_AM_HOP_LE.has(thu)) { batDau = b - lay; break; }
    }
    cat.push(batDau);
  }
  cat.push(am.length);

  const at = [];
  for (let i = 0; i < cat.length - 1; i++) at.push({ tu: cat[i], den: cat[i + 1] });
  return at;
}

// ── TRỌNG ÂM ────────────────────────────────────────────────────────────────
// Tiếng Anh là ngôn ngữ TRỌNG ÂM: đặt sai trọng âm thì người bản ngữ nghe
// không ra từ, kể cả khi từng âm đều đúng. Tiếng Việt không có hiện tượng này
// nên người học phải được chỉ rõ từng từ.
//
// Ba nhóm hậu tố dưới đây phủ phần lớn từ nhiều âm tiết trong sách giáo khoa.
const HAU_TO_KEO_TRUOC = ['tion', 'sion', 'cion', 'ity', 'ical', 'ically', 'ic', 'ial', 'ian', 'ious', 'ious', 'eous', 'uous', 'ify', 'ity', 'logy', 'graphy', 'metry', 'nomy', 'cracy'];
const HAU_TO_TU_NHAN = ['ee', 'eer', 'ese', 'ette', 'esque', 'oon', 'ain'];
const TIEN_TO_KHONG_NHAN = ['a', 'be', 'con', 'com', 'de', 'dis', 'em', 'en', 'ex', 'in', 'im', 'ir', 'mis', 'ob', 'per', 'pre', 'pro', 're', 'sub', 'sur', 'un', 'under'];

function datTrongAm(tu, soAmTiet) {
  const w = String(tu).toLowerCase();
  if (soAmTiet <= 1) return 0;
  for (const h of HAU_TO_TU_NHAN) if (w.endsWith(h)) return soAmTiet - 1;
  for (const h of HAU_TO_KEO_TRUOC) {
    if (!w.endsWith(h)) continue;
    // Hậu tố nhóm này chiếm âm tiết cuối (hoặc hai âm tiết cuối), trọng âm rơi
    // vào âm tiết ngay TRƯỚC nó.
    const chiem = /tion|sion|cion|ical|ically|ious|eous|uous|logy|graphy|metry|nomy|cracy|ity/.test(h) ? 2 : 1;
    return Math.max(0, soAmTiet - chiem);
  }
  if (soAmTiet === 2) {
    for (const t of TIEN_TO_KHONG_NHAN) {
      if (w.startsWith(t) && w.length > t.length + 2) return 1;
    }
    return 0;
  }
  // Từ ba âm tiết trở lên: mặc định rơi vào âm tiết thứ ba tính từ cuối.
  return soAmTiet - 3 >= 0 ? soAmTiet - 3 : 0;
}

// ── GIẢM ÂM VỀ /ə/ ──────────────────────────────────────────────────────────
// Âm tiết KHÔNG mang trọng âm trong tiếng Anh bị nuốt lại thành /ə/ hoặc /ɪ/.
// Người Việt đọc đều tăm tắp mọi âm tiết nên nghe rất "cứng"; đây là thứ phải
// dạy sớm. Chỉ giảm những nguyên âm ngắn — nguyên âm dài và nguyên âm đôi giữ
// nguyên vì chúng vẫn nghe rõ ở âm tiết không nhấn.
const GIAM_DUOC = new Set(['æ', 'e', 'ɒ', 'ʌ']);

function giamAm(am, amTiet, nhan) {
  const ra = am.slice();
  amTiet.forEach((at, k) => {
    if (k === nhan) return;
    for (let i = at.tu; i < at.den; i++) {
      if (GIAM_DUOC.has(ra[i])) ra[i] = 'ə';
    }
  });
  return ra;
}

// ── HÌNH THÁI HỌC: TÁCH HẬU TỐ ──────────────────────────────────────────────
// "teachers" không có trong từ điển nhưng "teacher" thì có. Tách hậu tố rồi
// ghép lại cho kết quả chắc chắn hơn nhiều so với đoán cả từ bằng luật.
const HAU_TO_DEU = [
  { viet: 'ing', bo: 3, am: ['ɪ', 'ŋ'], themE: true },
  { viet: 'ly', bo: 2, am: ['l', 'i'] },
  { viet: 'ness', bo: 4, am: ['n', 'ə', 's'] },
  { viet: 'ful', bo: 3, am: ['f', 'l'] },
  { viet: 'less', bo: 4, am: ['l', 'ə', 's'] },
  { viet: 'es', bo: 2, am: null, laS: true },
  { viet: 's', bo: 1, am: null, laS: true },
  { viet: 'ed', bo: 2, am: null, laED: true },
  { viet: 'er', bo: 2, am: ['ə'] },
  { viet: 'est', bo: 3, am: ['ɪ', 's', 't'] },
  { viet: 'th', bo: 2, am: ['θ'] },
];

/** Ghép đuôi -s / -es vào dãy âm gốc theo đúng luật đồng hoá. */
function themS(am) {
  const cuoi = am[am.length - 1];
  if (XUYT.has(cuoi)) return [...am, 'ɪ', 'z'];
  return [...am, VO_THANH.has(cuoi) ? 's' : 'z'];
}

/** Ghép đuôi -ed vào dãy âm gốc theo đúng luật đồng hoá. */
function themED(am) {
  const cuoi = am[am.length - 1];
  if (cuoi === 't' || cuoi === 'd') return [...am, 'ɪ', 'd'];
  return [...am, VO_THANH.has(cuoi) ? 't' : 'd'];
}

// ── PHIÊN ÂM MỘT TỪ ─────────────────────────────────────────────────────────

/** Giọng Mỹ khác giọng Anh ở vài chỗ đều đặn, đổi được bằng luật. */
function sangGiongMy(am, tu) {
  const ra = [];
  for (let i = 0; i < am.length; i++) {
    let p = am[i];
    if (p === 'ɒ') p = 'ɑː';
    else if (p === 'əʊ') p = 'oʊ';
    ra.push(p);
  }
  // Giọng Mỹ đọc /r/ ở mọi vị trí, kể cả cuối từ — giọng Anh thì không.
  const w = String(tu).toLowerCase();
  if (/r$/.test(w) && ra[ra.length - 1] === 'ə') ra.push('r');
  return ra;
}

/**
 * Phiên âm một từ tiếng Anh.
 * @returns {{ok, tu, ipa, am, amTiet, nhan, soAmTiet, nguon, vet}}
 *   nguon: 'từ điển' | 'từ điển + hậu tố' | 'luật'
 *   Trường `nguon` luôn có mặt để người dùng biết dòng phiên âm này là chắc
 *   chắn hay là suy ra — bộ này không bao giờ đoán mà giấu.
 */
function phienAm(tu, { giong = 'Anh' } = {}) {
  const goc = String(tu || '').trim();
  const w = goc.toLowerCase().replace(/[^a-z'-]/g, '');
  if (!w) return { ok: false, error: 'TỪ_RỖNG', tu: goc };

  let am = null;
  let nhanTuDien = -1;
  let nhanTuDienPhu = -1;
  let nguon = 'luật';
  let vet = [];

  if (Object.hasOwn(TU_DIEN, w)) {
    const t = tachIPA(TU_DIEN[w]);
    am = t.am;
    nhanTuDien = t.trongAm;
    nhanTuDienPhu = t.phuTrongAm;
    nguon = t.khong.length ? `từ điển (CÓ KÝ HIỆU LẠ: ${t.khong.map((x) => x.ky).join('')})` : 'từ điển';
  } else {
    // Thử tách hậu tố đều rồi tra gốc trong từ điển.
    for (const h of HAU_TO_DEU) {
      if (!w.endsWith(h.viet) || w.length <= h.viet.length + 1) continue;
      // Dựng các ứng viên gốc theo đúng luật chính tả khi thêm hậu tố, và
      // CHỈ những luật có thật. Trước đây danh sách này thử cả "mak" → "may",
      // khiến "makes" bị tra thành "may" + -s rồi đọc sai đuôi thành /z/.
      const than = w.slice(0, -h.bo);
      const canGoc = [than];
      if (than.endsWith('i')) canGoc.push(`${than.slice(0, -1)}y`);          // carries ← carry
      canGoc.push(`${than}e`);                                              // makes ← make, liked ← like
      if (than.length > 2 && than.at(-1) === than.at(-2)) canGoc.push(than.slice(0, -1)); // stopped ← stop
      for (const g of canGoc) {
        if (!Object.hasOwn(TU_DIEN, g)) continue;
        const t = tachIPA(TU_DIEN[g]);
        am = h.laS ? themS(t.am) : h.laED ? themED(t.am) : [...t.am, ...h.am];
        nhanTuDien = t.trongAm;
        nguon = `từ điển + hậu tố "-${h.viet}"`;
        break;
      }
      if (am) break;
    }
  }

  if (!am) { const r = theoLuat(w); am = r.am; vet = r.vet; }
  if (!am.length) return { ok: false, error: 'KHÔNG_PHIÊN_ÂM_ĐƯỢC', tu: goc };

  // Đổi giọng TRƯỚC khi chia âm tiết: giọng Mỹ thêm hẳn một âm /r/ ở cuối từ,
  // chia âm tiết xong mới thêm thì âm đó rơi ra ngoài mọi âm tiết.
  if (giong === 'Mỹ') am = sangGiongMy(am, w);

  let amTiet = tachAmTiet(am);
  let nhan;
  if (nhanTuDien >= 0 && nguon.startsWith('từ điển')) {
    // Dấu trọng âm trong từ điển đứng trước âm vị mở đầu âm tiết mang trọng âm.
    nhan = Math.max(0, amTiet.findIndex((at) => at.tu >= nhanTuDien));
    if (nhan < 0) nhan = 0;
  } else {
    nhan = datTrongAm(w, amTiet.length);
    am = giamAm(am, amTiet, nhan);        // chỉ giảm âm cho từ suy ra bằng luật
    amTiet = tachAmTiet(am);
    if (nhan >= amTiet.length) nhan = amTiet.length - 1;
  }

  const phu = nguon.startsWith('từ điển') && nhanTuDienPhu >= 0
    ? amTiet.findIndex((at) => at.tu >= nhanTuDienPhu) : -1;
  const ipa = amTiet.map((at, k) => (k === nhan ? 'ˈ' : k === phu ? 'ˌ' : '') + am.slice(at.tu, at.den).join('')).join('');
  return {
    ok: true,
    tu: goc,
    ipa: `/${ipa}/`,
    am,
    amTiet: amTiet.map((at, k) => ({ am: am.slice(at.tu, at.den), nhan: k === nhan })),
    nhan,
    soAmTiet: amTiet.length,
    giong,
    nguon,
    vet,
  };
}

// ── NỐI VÀO BỘ TỔNG HỢP FORMANT ─────────────────────────────────────────────
// Bộ tổng hợp giọng của hệ thống dựng tiếng bằng ba cộng hưởng F1, F2, F3 —
// đúng cách khoang miệng người lọc âm thanh. Muốn nó đọc được tiếng Anh thì
// phải cấp cho nó TẦN SỐ FORMANT của từng nguyên âm tiếng Anh. Bảng dưới lấy
// theo số đo ngữ âm giọng Anh chuẩn (giọng nam trưởng thành), đơn vị Hz.
const FORMANT = {
  'iː': [280, 2250, 2890], 'ɪ': [360, 2100, 2770], e: [480, 1900, 2550],
  'æ': [690, 1660, 2490], 'ɑː': [710, 1100, 2540], 'ɒ': [560, 920, 2560],
  'ɔː': [450, 640, 2590], 'ʊ': [380, 950, 2440], 'uː': [310, 940, 2320],
  'ʌ': [720, 1240, 2540], 'ɜː': [580, 1380, 2440], 'ə': [500, 1500, 2500],
  i: [300, 2200, 2850], u: [330, 1000, 2350],
};

// Nguyên âm đôi là một chuyển động, không phải một điểm: phải cấp formant của
// CHỖ BẮT ĐẦU và CHỖ KẾT THÚC rồi để bộ tổng hợp trượt giữa hai chỗ đó.
const FORMANT_DOI = {
  'eɪ': [[480, 1900, 2550], [360, 2100, 2770]],
  'aɪ': [[760, 1300, 2540], [360, 2100, 2770]],
  'ɔɪ': [[450, 640, 2590], [360, 2100, 2770]],
  'aʊ': [[760, 1300, 2540], [380, 950, 2440]],
  'əʊ': [[500, 1500, 2500], [380, 950, 2440]],
  'oʊ': [[450, 800, 2500], [380, 950, 2440]],
  'ɪə': [[360, 2100, 2770], [500, 1500, 2500]],
  'eə': [[480, 1900, 2550], [500, 1500, 2500]],
  'ʊə': [[380, 950, 2440], [500, 1500, 2500]],
};

// Bộ tổng hợp dùng thuật ngữ tiếng Anh cho kiểu và vị trí cấu âm; bảng âm vị
// ở trên dùng tiếng Việt cho người dạy đọc. Hai bảng dịch qua lại ở đây.
const KIEU_SANG_SYNTH = {
  'tắc': 'stop', 'xát': 'fricative', 'tắc xát': 'affricate',
  'mũi': 'nasal', 'bên': 'liquid', 'tiếp cận': 'liquid', 'lướt': 'glide',
};
const VITRI_SANG_SYNTH = {
  'hai môi': 'labial', 'môi răng': 'labial', 'lợi': 'alveolar', 'răng': 'dental',
  'lợi ngạc': 'postalveolar', 'ngạc mềm': 'velar', 'ngạc cứng': 'palatal',
  'thanh hầu': 'glottal', 'sau lợi': 'postalveolar', 'môi ngạc mềm': 'labial',
};
// Vệt formant thứ hai của phụ âm (locus) — thứ quyết định tai nghe ra phụ âm
// nào, vì phụ âm phần lớn được nhận ra qua chỗ NỐI với nguyên âm bên cạnh.
const LOCUS_F2 = { labial: 800, dental: 1700, alveolar: 1700, postalveolar: 2000, palatal: 2300, velar: 1300, glottal: 1500 };

/** Dịch một phụ âm tiếng Anh sang đúng bộ trường mà bộ tổng hợp cần. */
function phuAmSangSynth(ky) {
  const mo = PHU_AM[ky];
  if (!mo) return null;
  const place = VITRI_SANG_SYNTH[mo.viTri] || 'alveolar';
  return {
    type: KIEU_SANG_SYNTH[mo.loai] || 'fricative',
    voiced: mo.keu,
    aspirated: !!mo.bat,
    place,
    f1: mo.loai === 'mũi' ? 280 : 400,
    f2: LOCUS_F2[place],
    f3: 2500,
  };
}

// ── DỰNG ĐOẠN ÂM CHO BỘ TỔNG HỢP GIỌNG ──────────────────────────────────────
// Trả về cùng dạng dữ liệu với bộ âm vị tiếng Việt, để bộ tổng hợp dùng chung
// một đường: {kind, key, ipa, ms, ...}. Khác biệt nằm ở chỗ tiếng Anh không
// có thanh điệu mà có trọng âm, nên điều chỉnh độ dài và cao độ theo trọng âm.
function doanAm(tu, { rate = 1.0, giong = 'Anh' } = {}) {
  const p = phienAm(tu, { giong });
  if (!p.ok) return p;
  const scale = 1 / Math.max(0.5, Math.min(2, rate));
  const segs = [];

  p.amTiet.forEach((at, k) => {
    const manh = at.nhan;
    const cuoiTu = k === p.amTiet.length - 1;
    at.am.forEach((ky, j) => {
      const dauAmTiet = j === 0;
      // ── Nguyên âm đôi: hai chặng, chặng đầu dài hơn vì trọng tâm nằm ở đó.
      if (Object.hasOwn(NGUYEN_AM_DOI, ky)) {
        const mo = NGUYEN_AM_DOI[ky];
        const tong = mo.ms * (manh ? 1.25 : 0.82) * (cuoiTu ? 1.10 : 1.0) * scale;
        const [dau, cuoi] = FORMANT_DOI[ky] || [[500, 1500, 2500], [500, 1500, 2500]];
        [[dau, 0.58], [cuoi, 0.42]].forEach(([F, ti], idx) => {
          segs.push({
            kind: 'vowel', role: idx === 0 ? 'nucleus' : 'offglide',
            key: ky, ipa: ky, viet: mo.viet,
            ms: Math.round(tong * ti), nhan: manh, voiced: true,
            f1: F[0], f2: F[1], f3: F[2],
            f0: manh ? 1.15 : 0.95,
          });
        });
        return;
      }
      // ── Nguyên âm đơn.
      if (Object.hasOwn(NGUYEN_AM_DON, ky)) {
        const mo = NGUYEN_AM_DON[ky];
        const F = FORMANT[ky] || [500, 1500, 2500];
        segs.push({
          kind: 'vowel', role: 'nucleus', key: ky, ipa: ky, viet: mo.viet,
          ms: Math.round(mo.ms * (manh ? 1.25 : 0.82) * (cuoiTu ? 1.10 : 1.0) * scale),
          nhan: manh, voiced: true, f1: F[0], f2: F[1], f3: F[2],
          f0: manh ? 1.15 : 0.95, loai: mo.loai,
        });
        return;
      }
      // ── Âm tắc xát /tʃ/, /dʒ/: thật ra là hai chặng — bật rồi xát. Dựng
      //    thành hai đoạn thì tai nghe ra đúng, gộp một đoạn thì nghe như /ʃ/.
      if (ky === 'tʃ' || ky === 'dʒ') {
        const keu = ky === 'dʒ';
        const tong = PHU_AM[ky].ms * scale;
        segs.push({ kind: 'consonant', role: dauAmTiet ? 'onset' : 'coda', key: ky, ipa: ky, ms: Math.round(tong * 0.35), type: 'stop', voiced: keu, place: 'postalveolar', f1: 400, f2: 2000, f3: 2500, nhan: manh, f0: manh ? 1.15 : 0.95 });
        segs.push({ kind: 'consonant', role: 'release', key: ky, ipa: ky, ms: Math.round(tong * 0.65), type: 'fricative', voiced: keu, place: 'postalveolar', f1: 400, f2: 2000, f3: 2500, nhan: manh, f0: manh ? 1.15 : 0.95 });
        return;
      }
      // ── Phụ âm thường.
      const mo = PHU_AM[ky];
      if (!mo) return;
      const sy = phuAmSangSynth(ky);
      segs.push({
        kind: 'consonant', role: dauAmTiet ? 'onset' : 'coda',
        key: ky, ipa: ky, viet: mo.viet,
        ms: Math.round(mo.ms * scale), nhan: manh,
        f0: manh ? 1.15 : 0.95,
        ...sy,
      });
    });
  });

  return { ...p, segments: segs, estimatedMs: segs.reduce((s, x) => s + x.ms, 0) };
}

// ── CHẨN ĐOÁN LỖI PHÁT ÂM CỦA NGƯỜI VIỆT ────────────────────────────────────
// Người Việt sai tiếng Anh theo những kiểu rất đều, vì hệ âm tiếng Việt thiếu
// đúng những âm đó. Biết trước được thì chỉ ra trước được, không cần nghe.
// Mỗi mục nêu: âm khó · người Việt hay đọc thành gì · cách sửa cụ thể.
const LOI_NGUOI_VIET = {
  'θ': { thanh: '/t/ hoặc /th/ tiếng Việt', sua: 'Đặt đầu lưỡi RA GIỮA hai hàm răng rồi thổi hơi. Nhìn gương: phải thấy đầu lưỡi.', do: 5 },
  'ð': { thanh: '/d/ hoặc /z/', sua: 'Cùng vị trí với /θ/ nhưng rung dây thanh. Đặt tay lên cổ, phải thấy rung.', do: 5 },
  'z': { thanh: '/s/ — mất hẳn tiếng rung', sua: 'Giữ nguyên miệng như /s/ rồi bật thanh quản. So "sip" với "zip".', do: 4 },
  'ʒ': { thanh: '/z/ hoặc /gi/', sua: 'Lưỡi lùi về sau như /ʃ/, môi hơi tròn, đồng thời rung thanh.', do: 4 },
  'ʃ': { thanh: '/s/', sua: 'Lùi lưỡi về sau và tròn môi. So "see" với "she".', do: 3 },
  'dʒ': { thanh: '/z/ hoặc /gi/', sua: 'Phải có phần BẬT trước rồi mới xát: /d/ + /ʒ/ dính liền.', do: 4 },
  'r': { thanh: '/z/ giọng Bắc hoặc /r/ rung giọng Trung', sua: 'Lưỡi CONG LÊN nhưng KHÔNG chạm vào đâu cả, và không rung.', do: 4 },
  'v': { thanh: '/v/ tiếng Việt (gần như /j/ ở một số vùng)', sua: 'Răng trên phải chạm môi dưới, giữ hơi xát.', do: 2 },
  'iː': { thanh: '/i/ ngắn — mất hẳn thế đối lập dài–ngắn', sua: 'Kéo dài gần gấp đôi và căng môi. Luyện theo cặp: sheep – ship.', do: 4 },
  'æ': { thanh: '/e/ hoặc /a/', sua: 'Hạ hàm dưới xuống, miệng mở rộng theo chiều ngang. Luyện: bad – bed.', do: 4 },
  'ɜː': { thanh: '/ơ/ ngắn', sua: 'Giữ nguyên khẩu hình ở giữa miệng và KÉO DÀI, không trượt sang âm khác.', do: 3 },
  'ə': { thanh: 'đọc rõ thành nguyên âm đầy đủ', sua: 'Âm tiết không có trọng âm phải NHẸ và NGẮN lại, gần như nuốt đi.', do: 5 },
  'ʊ': { thanh: '/u/ dài', sua: 'Buông lỏng môi và rút ngắn. So "full" với "fool".', do: 3 },
};

const AM_CUOI_KHO = new Set(['s', 'z', 'f', 'v', 'θ', 'ð', 'ʃ', 'ʒ', 'tʃ', 'dʒ', 'l', 'p', 'b', 't', 'd', 'k', 'ɡ']);

/**
 * Soát một từ và chỉ ra trước những chỗ người Việt sẽ đọc sai.
 * Đây không phải chấm điểm phát âm bằng tai — đây là DỰ BÁO lỗi từ cấu trúc
 * âm của từ, để người dạy biết cần nhấn vào đâu trước khi học viên mở miệng.
 */
function chanDoan(tu, { giong = 'Anh' } = {}) {
  const p = phienAm(tu, { giong });
  if (!p.ok) return p;
  const canh = [];
  const da = new Set();

  for (const a of p.am) {
    if (LOI_NGUOI_VIET[a] && !da.has(a)) {
      da.add(a);
      canh.push({ am: a, ...LOI_NGUOI_VIET[a], loai: 'âm khó' });
    }
  }

  // Âm cuối: tiếng Việt chỉ có 8 âm cuối và đều không bật hơi, nên mọi âm cuối
  // tiếng Anh nằm ngoài nhóm đó đều có nguy cơ bị nuốt mất.
  const cuoi = p.am[p.am.length - 1];
  if (AM_CUOI_KHO.has(cuoi)) {
    canh.push({
      am: cuoi, loai: 'âm cuối', do: 5,
      thanh: 'bị nuốt mất',
      sua: `Âm cuối /${cuoi}/ phải nghe thấy được. Tiếng Việt không có âm cuối này nên rất dễ bỏ quên — đọc chậm lại và bật rõ ở cuối từ.`,
    });
  }

  // Cụm phụ âm: tiếng Việt không có cụm phụ âm nào, nên cụm nào cũng bị giản lược.
  let cum = [];
  for (let i = 0; i <= p.am.length; i++) {
    const a = p.am[i];
    if (a && !LA_NGUYEN_AM(a)) { cum.push(a); continue; }
    if (cum.length >= 2) {
      canh.push({
        am: cum.join(''), loai: 'cụm phụ âm', do: cum.length >= 3 ? 5 : 3,
        thanh: 'bị bớt bớt một âm hoặc chèn thêm nguyên âm vào giữa',
        sua: `Cụm /${cum.join('')}/ phải phát liền một hơi, đủ ${cum.length} âm, KHÔNG chèn "ơ" vào giữa.`,
      });
    }
    cum = [];
  }

  // Trọng âm: tiếng Việt không có trọng âm từ, nên đây luôn là điểm phải dạy.
  if (p.soAmTiet >= 2) {
    canh.push({
      loai: 'trọng âm', do: 5, am: `âm tiết ${p.nhan + 1}`,
      thanh: 'đọc đều tất cả các âm tiết',
      sua: `Nhấn vào âm tiết thứ ${p.nhan + 1} (/${p.amTiet[p.nhan].am.join('')}/): đọc TO hơn, DÀI hơn và CAO hơn. Các âm tiết còn lại nhẹ và ngắn lại.`,
    });
  }

  canh.sort((a, b) => b.do - a.do);
  return {
    ok: true, tu: p.tu, ipa: p.ipa, nguon: p.nguon, soAmTiet: p.soAmTiet, nhan: p.nhan,
    soCanhBao: canh.length,
    doKho: canh.length === 0 ? 1 : Math.min(5, Math.round(canh.reduce((s, c) => s + c.do, 0) / canh.length)),
    canhBao: canh,
  };
}

// ── CẶP TỐI THIỂU ───────────────────────────────────────────────────────────
// Cặp tối thiểu là hai từ CHỈ khác nhau ĐÚNG MỘT âm — công cụ mạnh nhất để dạy
// phân biệt hai âm dễ lẫn. Ở đây cặp được TÌM RA từ chính từ điển bằng cách so
// từng dãy âm, chứ không phải chép sẵn một danh sách. Nhờ vậy từ điển lớn thêm
// thì kho cặp tự lớn theo, và không bao giờ có cặp sai.
let _khoCap = null;

function khoCapToiThieu() {
  if (_khoCap) return _khoCap;
  const banG = [];
  for (const [w, ipa] of Object.entries(TU_DIEN)) {
    banG.push({ tu: w, am: tachIPA(ipa).am });
  }
  const cap = [];
  for (let i = 0; i < banG.length; i++) {
    for (let j = i + 1; j < banG.length; j++) {
      const A = banG[i]; const B = banG[j];
      if (A.am.length !== B.am.length) continue;
      let lech = -1; let so = 0;
      for (let k = 0; k < A.am.length; k++) {
        if (A.am[k] !== B.am[k]) { so++; lech = k; if (so > 1) break; }
      }
      if (so !== 1) continue;
      const x = A.am[lech]; const y = B.am[lech];
      // Hai âm phải cùng loại (cùng là nguyên âm hoặc cùng là phụ âm) thì mới
      // là bài luyện có ích; khác loại thường chỉ là trùng hợp chính tả.
      if (LA_NGUYEN_AM(x) !== LA_NGUYEN_AM(y)) continue;
      cap.push({ a: A.tu, b: B.tu, amA: x, amB: y, viTri: lech, loai: LA_NGUYEN_AM(x) ? 'nguyên âm' : 'phụ âm' });
    }
  }
  _khoCap = cap;
  return cap;
}

/** Lấy các cặp luyện cho đúng một thế đối lập, ví dụ /iː/ với /ɪ/. */
function capCho(am1, am2, { soLuong = 12 } = {}) {
  const ra = khoCapToiThieu().filter((c) => (c.amA === am1 && c.amB === am2) || (c.amA === am2 && c.amB === am1));
  // Cặp gồm hai từ có nghĩa dạy tốt hơn cặp có từ chức năng: từ chức năng khi
  // nói nhanh bị nuốt thành dạng yếu, học viên luyện xong lại không dùng được.
  const diem = (c) => (Object.hasOwn(DANG_YEU, c.a) ? 1 : 0) + (Object.hasOwn(DANG_YEU, c.b) ? 1 : 0);
  ra.sort((x, y) => diem(x) - diem(y) || (x.a.length + x.b.length) - (y.a.length + y.b.length) || x.a.localeCompare(y.a));
  return ra.slice(0, soLuong).map((c) => {
    const thuan = c.amA === am1 ? c : { ...c, a: c.b, b: c.a, amA: c.amB, amB: c.amA };
    return {
      am1, am2,
      tu1: thuan.a, ipa1: phienAm(thuan.a).ipa,
      tu2: thuan.b, ipa2: phienAm(thuan.b).ipa,
      loai: c.loai,
    };
  });
}

/** Các thế đối lập có sẵn cặp luyện, xếp theo số cặp tìm được. */
function cacTheDoiLap({ toiThieu = 2 } = {}) {
  const dem = new Map();
  for (const c of khoCapToiThieu()) {
    const khoa = [c.amA, c.amB].sort().join(' – ');
    if (!dem.has(khoa)) dem.set(khoa, { am: khoa, loai: c.loai, so: 0, viDu: [] });
    const m = dem.get(khoa);
    m.so++;
    if (m.viDu.length < 3) m.viDu.push(`${c.a} – ${c.b}`);
  }
  return [...dem.values()].filter((m) => m.so >= toiThieu).sort((a, b) => b.so - a.so);
}

// ── PHIÊN ÂM CẢ CÂU ─────────────────────────────────────────────────────────
// Ở mức câu mới xuất hiện hai hiện tượng mà đọc từng từ rời không thấy được:
//   · DẠNG YẾU  — từ chức năng bị nuốt thành /ə/ khi nói nhanh: "can" → /kən/
//   · NỐI ÂM    — phụ âm cuối nối sang nguyên âm đầu của từ sau: "an apple"
// Đây chính là lý do người Việt nghe người bản ngữ nói nhanh thì không ra chữ.
const DANG_YEU = {
  a: 'ə', an: 'ən', the: 'ðə', and: 'ən', but: 'bət', of: 'əv', to: 'tə', for: 'fə',
  from: 'frəm', as: 'əz', at: 'ət', that: 'ðət', than: 'ðən', can: 'kən',
  must: 'məst', was: 'wəz', were: 'wə', are: 'ə', am: 'əm', do: 'də', does: 'dəz',
  has: 'həz', have: 'həv', had: 'həd', will: 'wəl', would: 'wəd', shall: 'ʃəl',
  should: 'ʃəd', could: 'kəd', some: 'səm', them: 'ðəm', us: 'əs', your: 'jə',
  he: 'hi', she: 'ʃi', we: 'wi', you: 'jə', him: 'ɪm', her: 'ə',
};

function tachTu(text) {
  const out = [];
  const re = /([A-Za-z][A-Za-z'-]*)|([0-9]+)|([,;:.!?…—–])|(\s+)/g;
  let m;
  while ((m = re.exec(String(text || ''))) !== null) {
    if (m[1]) out.push({ type: 'word', text: m[1] });
    else if (m[2]) out.push({ type: 'number', text: m[2] });
    else if (m[3]) out.push({ type: 'punct', text: m[3] });
  }
  return out;
}

/**
 * Phiên âm cả một câu hoặc đoạn.
 * @param {object} opts
 *   nhanh  — true thì áp dụng dạng yếu của từ chức năng (lối nói tự nhiên);
 *            false thì đọc dạng mạnh (lối đọc chậm để học viên nghe rõ).
 */
function phienAmCau(text, { giong = 'Anh', nhanh = true, rate = 1.0 } = {}) {
  const tokens = tachTu(text);
  const items = [];
  const chuaBiet = [];
  // Từ chức năng KHÔNG bị nuốt khi đứng đầu hoặc đứng cuối câu — "Are you a
  // student?" vẫn đọc rõ "Are", còn "Yes, I am." đọc rõ "am". Bỏ qua luật này
  // thì máy đọc ra một chuỗi /ə/ không ai nghe được.
  const viTriTu = tokens.map((t, i) => i).filter((i) => tokens[i].type === 'word');
  const dauCau = new Set([viTriTu[0], viTriTu[viTriTu.length - 1]]);
  for (let vt = 0; vt < tokens.length; vt++) {
    const t = tokens[vt];
    if (t.type === 'punct') {
      items.push({ type: 'pause', ms: /[.!?…]/.test(t.text) ? 380 : 200, mark: t.text });
      continue;
    }
    if (t.type === 'number') { chuaBiet.push({ text: t.text, ly: 'SỐ_CHƯA_ĐỌC_THÀNH_CHỮ' }); continue; }
    const w = t.text.toLowerCase();
    if (nhanh && !dauCau.has(vt) && Object.hasOwn(DANG_YEU, w)) {
      const am = tachIPA(DANG_YEU[w]).am;
      const amTiet = tachAmTiet(am);
      items.push({
        type: 'word', tu: t.text, ipa: `/${am.join('')}/`, am, soAmTiet: amTiet.length,
        nhan: -1, nguon: 'dạng yếu', yeu: true,
        segments: am.map((k) => {
          const mo = NGUYEN_AM_DON[k] || NGUYEN_AM_DOI[k] || PHU_AM[k] || {};
          return { kind: LA_NGUYEN_AM(k) ? 'vowel' : 'consonant', key: k, ipa: k, ms: Math.round((mo.ms || 80) * 0.7), nhan: false, f0: 0.92, ...mo };
        }),
      });
      continue;
    }
    const d = doanAm(t.text, { rate, giong });
    if (!d.ok) { chuaBiet.push({ text: t.text, ly: d.error }); continue; }
    items.push({ type: 'word', ...d });
  }

  // Nối âm: phụ âm cuối từ trước gặp nguyên âm đầu từ sau thì đọc liền.
  const noi = [];
  const tu = items.filter((x) => x.type === 'word');
  for (let i = 0; i < tu.length - 1; i++) {
    const a = tu[i]; const b = tu[i + 1];
    const cuoi = a.am[a.am.length - 1];
    const dau = b.am[0];
    if (!LA_NGUYEN_AM(cuoi) && LA_NGUYEN_AM(dau)) {
      noi.push({ truoc: a.tu, sau: b.tu, am: cuoi, cach: `Đọc liền: "${a.tu}_${b.tu}" — âm /${cuoi}/ chuyển sang làm âm đầu của "${b.tu}".` });
    }
  }

  const ipa = items.map((x) => (x.type === 'pause' ? x.mark : x.ipa.replace(/^\/|\/$/g, ''))).join(' ');
  const totalMs = items.reduce((s, x) => s + (x.type === 'pause' ? x.ms : x.estimatedMs || 0), 0);
  return {
    ok: true,
    text: String(text),
    ipa: `/${ipa}/`,
    items,
    tu: tu.length,
    amTiet: tu.reduce((s, x) => s + (x.soAmTiet || 0), 0),
    noiAm: noi,
    chuaBiet,
    giong,
    nhanh,
    estimatedMs: Math.round(totalMs),
  };
}

// ── BÀI HỌC PHÁT ÂM ─────────────────────────────────────────────────────────
/**
 * Dựng một bài học cho MỘT thế đối lập âm, đủ bốn phần như một tiết dạy thật:
 * nghe phân biệt · cấu âm · luyện cặp · đưa vào câu.
 * Toàn bộ ví dụ lấy từ từ điển đã phiên âm, không bịa từ.
 */
function baiHocAm(am1, am2, { soCap = 8 } = {}) {
  const cap = capCho(am1, am2, { soLuong: soCap });
  if (!cap.length) return { ok: false, error: 'CHƯA_CÓ_CẶP_LUYỆN', am1, am2 };
  const ta = (a) => NGUYEN_AM_DON[a] || NGUYEN_AM_DOI[a] || PHU_AM[a] || {};
  const l1 = LOI_NGUOI_VIET[am1];
  const l2 = LOI_NGUOI_VIET[am2];
  return {
    ok: true,
    tieuDe: `Phân biệt /${am1}/ và /${am2}/`,
    moTa: {
      [am1]: ta(am1).viet || '',
      [am2]: ta(am2).viet || '',
    },
    viSaoKho: [
      l1 ? `Người Việt thường đọc /${am1}/ thành ${l1.thanh}.` : null,
      l2 ? `Người Việt thường đọc /${am2}/ thành ${l2.thanh}.` : null,
      'Tiếng Việt không có thế đối lập này nên tai chưa quen phân biệt — phải luyện nghe trước khi luyện nói.',
    ].filter(Boolean),
    cauAm: [
      l1 ? `/${am1}/: ${l1.sua}` : `/${am1}/: ${ta(am1).viet || ''}`,
      l2 ? `/${am2}/: ${l2.sua}` : `/${am2}/: ${ta(am2).viet || ''}`,
    ],
    luyenCap: cap,
    // Khung câu phải đúng ngữ pháp với BẤT KỲ cặp từ nào, kể cả khi hai từ
    // khác từ loại. Khung trích dẫn dưới đây thoả điều kiện đó, và quan trọng
    // hơn: nó là việc người dạy thật sự làm trên lớp.
    cauLuyen: cap.slice(0, 3).flatMap((c) => [
      { cau: `Say "${c.tu1}", not "${c.tu2}".`, ipa: phienAmCau(`Say "${c.tu1}", not "${c.tu2}".`, { nhanh: false }).ipa },
      { cau: `Listen: "${c.tu1}" — "${c.tu2}". Which one did you hear?`, ipa: phienAmCau(`Listen: "${c.tu1}" — "${c.tu2}". Which one did you hear?`, { nhanh: false }).ipa },
    ]),
    tuKiemTra: `Đọc lần lượt hai từ trong mỗi cặp và tự hỏi: hai lần đọc có KHÁC NHAU không? Nếu nghe giống nhau thì chưa đạt.`,
  };
}

module.exports = {
  NGUYEN_AM_DON, NGUYEN_AM_DOI, PHU_AM, LA_NGUYEN_AM, VO_THANH, XUYT,
  TU_DIEN, LUAT, LOI_NGUOI_VIET, DANG_YEU,
  tachIPA, theoLuat, tachAmTiet, datTrongAm,
  phienAm, doanAm, chanDoan,
  khoCapToiThieu, capCho, cacTheDoiLap, baiHocAm,
  tachTu, phienAmCau,
  FORMANT, FORMANT_DOI, phuAmSangSynth,
};
