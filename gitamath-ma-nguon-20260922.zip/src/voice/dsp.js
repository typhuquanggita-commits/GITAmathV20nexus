'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  XỬ LÝ HẬU KỲ CHUẨN PHÒNG THU — viết thẳng bằng JavaScript
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế gốc dùng chuỗi filter của FFmpeg. Nhưng máy chủ này KHÔNG có
 *  ffmpeg, và cả hệ thống có một luật bất di bất dịch: không phụ thuộc chạy
 *  thật. Nếu hậu kỳ phải gọi tiến trình ngoài thì lớp "chất lượng phòng thu"
 *  chỉ là lời hứa — cài thiếu một gói là im tiếng.
 *
 *  Nên toàn bộ chuỗi được viết lại bằng DSP thật trong tiến trình:
 *
 *    lọc rumble → EQ → de-esser → nén song song → bão hoà hài
 *    → hồi âm → chuẩn độ vang (BS.1770) → giới hạn đỉnh
 *
 *  Mỗi khâu là thuật toán có tên tuổi, không phải "nhân hệ số cho có":
 *    · Biquad theo sổ tay RBJ (Robert Bristow-Johnson)
 *    · Nén có attack/release theo hằng số thời gian thật
 *    · Đo độ vang theo ITU-R BS.1770-4: lọc K, khối 400ms, cổng −70 LUFS
 *      tuyệt đối và −10 LU tương đối
 *    · Giới hạn đỉnh có nhìn trước (lookahead), không cắt ngọn sóng
 *
 *  Ai có ffmpeg thì vẫn dùng được — xem FFmpegChain ở cuối tệp. Nhưng mặc
 *  định là bản JavaScript, vì nó luôn chạy.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round, clamp } = require('../utils');

const SAMPLE_RATE_DEFAULT = 22050;

/** ── Biquad (sổ tay RBJ) ─────────────────────────────────────────────────── */
class Biquad {
  constructor() { this.b0 = 1; this.b1 = 0; this.b2 = 0; this.a1 = 0; this.a2 = 0; this.reset(); }
  reset() { this.x1 = 0; this.x2 = 0; this.y1 = 0; this.y2 = 0; }

  /**
   * Tần số cắt phải nằm dưới tần số Nyquist. Đặt EQ 12 kHz trên tín hiệu
   * 22,05 kHz là w > π — hệ số bộ lọc hoá NaN và cả tệp câm. Giới hạn ở
   * 0,45·sr để còn chỗ cho bộ lọc hoạt động đúng.
   */
  static _fc(fc, sr) { return Math.min(Math.max(10, fc), sr * 0.45); }

  _norm(b0, b1, b2, a0, a1, a2) {
    this.b0 = b0 / a0; this.b1 = b1 / a0; this.b2 = b2 / a0;
    this.a1 = a1 / a0; this.a2 = a2 / a0;
    return this;
  }

  highpass(fc, sr, q = 0.7071) {
    fc = Biquad._fc(fc, sr);
    const w = 2 * Math.PI * fc / sr, c = Math.cos(w), s = Math.sin(w), al = s / (2 * q);
    return this._norm((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
  }

  lowpass(fc, sr, q = 0.7071) {
    fc = Biquad._fc(fc, sr);
    const w = 2 * Math.PI * fc / sr, c = Math.cos(w), s = Math.sin(w), al = s / (2 * q);
    return this._norm((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al);
  }

  bandpass(fc, sr, q = 1) {
    fc = Biquad._fc(fc, sr);
    const w = 2 * Math.PI * fc / sr, c = Math.cos(w), s = Math.sin(w), al = s / (2 * q);
    return this._norm(al, 0, -al, 1 + al, -2 * c, 1 - al);
  }

  /** EQ chuông: nâng/hạ một dải quanh fc. gainDb âm là cắt. */
  peaking(fc, sr, gainDb, q = 1) {
    fc = Biquad._fc(fc, sr);
    const A = Math.pow(10, gainDb / 40);
    const w = 2 * Math.PI * fc / sr, c = Math.cos(w), s = Math.sin(w), al = s / (2 * q);
    return this._norm(1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
  }

  highShelf(fc, sr, gainDb, q = 0.7071) {
    fc = Biquad._fc(fc, sr);
    const A = Math.pow(10, gainDb / 40);
    const w = 2 * Math.PI * fc / sr, c = Math.cos(w), s = Math.sin(w);
    const al = s / 2 * Math.sqrt((A + 1 / A) * (1 / q - 1) + 2);
    const sq = 2 * Math.sqrt(A) * al;
    return this._norm(
      A * ((A + 1) + (A - 1) * c + sq), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - sq),
      (A + 1) - (A - 1) * c + sq, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - sq,
    );
  }

  step(x) {
    const y = this.b0 * x + this.b1 * this.x1 + this.b2 * this.x2 - this.a1 * this.y1 - this.a2 * this.y2;
    this.x2 = this.x1; this.x1 = x;
    this.y2 = this.y1; this.y1 = y;
    return y;
  }

  /** Lọc cả mảng. Trả mảng mới, không sửa đầu vào. */
  run(input) {
    this.reset();
    const out = new Float32Array(input.length);
    for (let i = 0; i < input.length; i++) out[i] = this.step(input[i]);
    return out;
  }
}

const dbToLin = (db) => Math.pow(10, db / 20);
const linToDb = (x) => 20 * Math.log10(Math.max(1e-12, Math.abs(x)));

/** ── Nén (compressor) có attack/release thật ─────────────────────────────── */
function compress(input, sr, { thresholdDb = -18, ratio = 4, attackMs = 3, releaseMs = 50, makeupDb = 0, kneeDb = 6 } = {}) {
  const out = new Float32Array(input.length);
  const aA = Math.exp(-1 / (sr * attackMs / 1000));
  const aR = Math.exp(-1 / (sr * releaseMs / 1000));
  const makeup = dbToLin(makeupDb);
  let env = 0;      // bao hình mức tín hiệu, đơn vị tuyến tính
  let gr = 0;       // độ giảm ích hiện tại (dB, ≤ 0)
  let maxGr = 0;

  for (let i = 0; i < input.length; i++) {
    const x = Math.abs(input[i]);
    env = x > env ? aA * env + (1 - aA) * x : aR * env + (1 - aR) * x;
    const lvl = linToDb(env);

    // Đầu gối mềm: chuyển dần vào tỉ lệ nén thay vì gãy khúc ở đúng ngưỡng.
    let want = 0;
    const over = lvl - thresholdDb;
    if (over > kneeDb / 2) want = over - over / ratio;
    else if (over > -kneeDb / 2) {
      const t = over + kneeDb / 2;
      want = (1 - 1 / ratio) * t * t / (2 * kneeDb);
    }
    gr = -want;
    if (gr < maxGr) maxGr = gr;
    out[i] = input[i] * dbToLin(gr) * makeup;
  }
  return { samples: out, maxReductionDb: round(maxGr, 2) };
}

/**
 * Nén SONG SONG: trộn tín hiệu gốc với bản nén mạnh.
 * Đây là điểm mấu chốt để giọng máy có "sức" mà không mất biên độ động —
 * nén thẳng tay lên tín hiệu gốc thì câu nào cũng đều đều như đọc máy.
 */
function parallelCompress(input, sr, { mix = 0.45, thresholdDb = -24, ratio = 6, attackMs = 2, releaseMs = 80, makeupDb = 4 } = {}) {
  const c = compress(input, sr, { thresholdDb, ratio, attackMs, releaseMs, makeupDb });
  const out = new Float32Array(input.length);
  const dry = 1 - mix;
  for (let i = 0; i < input.length; i++) out[i] = input[i] * dry + c.samples[i] * mix;
  return { samples: out, maxReductionDb: c.maxReductionDb, mix };
}

/**
 * De-esser: chỉ hạ âm gió/xì (s, x, ch) khi chúng thật sự chói, bằng cách
 * dò mức ở dải 5–9 kHz rồi hạ đúng dải đó. Hạ đều cả dải cao thì mất luôn
 * độ trong của giọng.
 */
function deEss(input, sr, { thresholdDb = -28, ratio = 4, freq = 6500 } = {}) {
  const band = new Biquad().bandpass(freq, sr, 1.2).run(input);
  const high = new Biquad().highShelf(freq * 0.8, sr, 0, 0.7).run(input); // giữ chỗ pha
  const out = new Float32Array(input.length);
  const aA = Math.exp(-1 / (sr * 0.001));
  const aR = Math.exp(-1 / (sr * 0.030));
  let env = 0; let acted = 0;

  for (let i = 0; i < input.length; i++) {
    const x = Math.abs(band[i]);
    env = x > env ? aA * env + (1 - aA) * x : aR * env + (1 - aR) * x;
    const lvl = linToDb(env);
    let g = 1;
    if (lvl > thresholdDb) {
      const over = lvl - thresholdDb;
      g = dbToLin(-(over - over / ratio));
      acted++;
    }
    // Chỉ dải xì bị hạ; phần còn lại của tín hiệu giữ nguyên.
    out[i] = input[i] - band[i] * (1 - g);
    void high;
  }
  return { samples: out, actedSamples: acted, actedRatio: round(acted / Math.max(1, input.length), 4) };
}

/**
 * Bão hoà hài: thêm hài bậc 2 và 3 cho giọng dày lên.
 * Giọng tổng hợp thiếu đúng thứ này — phổ quá sạch nên nghe "phẳng".
 */
function saturate(input, { drive = 0.35, even = 0.6 } = {}) {
  // Hài LẺ sinh ra từ hàm méo đối xứng lẻ (tanh): nghe "chắc", kiểu băng từ.
  // Hài CHẴN phải sinh từ hàm KHÔNG đối xứng lẻ — x·|x| trông có vẻ được
  // nhưng nó vẫn là hàm lẻ, nên chỉ ra thêm hài lẻ. Hài chẵn thật sự nằm ở
  // x², kèm theo một thành phần một chiều phải trừ đi, nếu không cả tệp bị
  // lệch trục và loa kêu "bụp" ở đầu.
  const n = input.length;
  const out = new Float32Array(n);
  const k = 1 + drive * 3;
  const norm = Math.tanh(k);

  let sq = 0;
  for (let i = 0; i < n; i++) sq += input[i] * input[i];
  const dc = n ? sq / n : 0;                       // trung bình của x² — chính là thành phần một chiều

  for (let i = 0; i < n; i++) {
    const x = clamp(input[i], -1, 1);
    const odd = Math.tanh(x * k) / norm;
    const evenH = (x * x - dc) * 1.6;              // x² đã bỏ một chiều → hài bậc 2
    const wet = odd * (1 - even * 0.5) + evenH * even * 0.5;
    out[i] = x * (1 - drive) + wet * drive;
  }
  return out;
}

/** ── Hồi âm Schroeder: 4 comb song song + 2 allpass nối tiếp ─────────────── */
function reverb(input, sr, { amount = 0.18, roomMs = 45, damping = 0.35 } = {}) {
  if (amount <= 0) return input;
  const combDelays = [roomMs, roomMs * 1.17, roomMs * 1.41, roomMs * 1.67].map((m) => Math.max(1, Math.round(m / 1000 * sr)));
  const combFeed = [0.78, 0.76, 0.74, 0.72];
  const apDelays = [Math.round(0.005 * sr), Math.round(0.0017 * sr)];

  const wet = new Float32Array(input.length);
  for (let c = 0; c < combDelays.length; c++) {
    const n = combDelays[c];
    const buf = new Float32Array(n);
    let p = 0; let store = 0;
    for (let i = 0; i < input.length; i++) {
      const y = buf[p];
      store = y * (1 - damping) + store * damping;       // hút bớt tần số cao
      buf[p] = input[i] + store * combFeed[c];
      wet[i] += y * 0.25;
      p = (p + 1) % n;
    }
  }
  let cur = wet;
  for (const n of apDelays) {
    const buf = new Float32Array(n);
    const out = new Float32Array(cur.length);
    let p = 0;
    for (let i = 0; i < cur.length; i++) {
      const y = buf[p];
      const v = cur[i] + y * 0.5;
      buf[p] = v;
      out[i] = y - v * 0.5;
      p = (p + 1) % n;
    }
    cur = out;
  }
  const out = new Float32Array(input.length);
  for (let i = 0; i < input.length; i++) out[i] = input[i] * (1 - amount) + cur[i] * amount;
  return out;
}

/**
 * Đo độ vang tích hợp theo ITU-R BS.1770-4.
 * Không phải đo biên độ đỉnh — tai người nghe theo độ vang, nên chuẩn hoá
 * theo đỉnh sẽ cho ra bài to bài nhỏ dù cùng một hệ thống.
 */
function measureLoudness(input, sr) {
  // Lọc K: tầng 1 high-shelf, tầng 2 high-pass
  const s1 = new Biquad().highShelf(1681.97, sr, 3.999, 0.7071).run(input);
  const s2 = new Biquad().highpass(38.13, sr, 0.5).run(s1);

  const blockN = Math.max(1, Math.round(0.4 * sr));          // khối 400ms
  const hopN = Math.max(1, Math.round(0.1 * sr));            // trượt 75%
  const blocks = [];
  for (let start = 0; start + blockN <= s2.length; start += hopN) {
    let sum = 0;
    for (let i = start; i < start + blockN; i++) sum += s2[i] * s2[i];
    const ms = sum / blockN;
    blocks.push(-0.691 + 10 * Math.log10(Math.max(1e-12, ms)));
  }
  if (!blocks.length) return { lufs: -70, blocks: 0, peakDb: round(linToDb(peakOf(input)), 2) };

  // Cổng tuyệt đối −70 LUFS
  const abs = blocks.filter((b) => b > -70);
  if (!abs.length) return { lufs: -70, blocks: blocks.length, gated: 0, peakDb: round(linToDb(peakOf(input)), 2) };
  const meanOf = (arr) => 10 * Math.log10(arr.reduce((s, b) => s + Math.pow(10, (b + 0.691) / 10), 0) / arr.length) - 0.691;
  // Cổng tương đối −10 LU so với mức trung bình sau cổng tuyệt đối
  const rel = meanOf(abs) - 10;
  const gated = abs.filter((b) => b > rel);
  const lufs = gated.length ? meanOf(gated) : meanOf(abs);
  return { lufs: round(lufs, 2), blocks: blocks.length, gated: gated.length, peakDb: round(linToDb(peakOf(input)), 2) };
}

/**
 * Biên độ tại ĐÚNG một tần số, bằng thuật toán Goertzel.
 * Dùng để đo hài: bộ lọc băng rò tần số cơ bản sang bin hài nên đo sai.
 * Cửa sổ được cắt về số nguyên chu kỳ, nếu không thì rò phổ làm lệch kết quả.
 */
function magnitudeAt(x, hz, sr = SAMPLE_RATE_DEFAULT) {
  const periods = Math.floor((x.length * hz) / sr);
  const n = Math.min(x.length, Math.round(sr / hz) * periods);
  if (n < 16 || periods < 2) return 0;
  const k = Math.round((n * hz) / sr);
  const coeff = 2 * Math.cos((2 * Math.PI * k) / n);
  let s0 = 0; let s1 = 0; let s2 = 0;
  for (let i = 0; i < n; i++) { s0 = x[i] + coeff * s1 - s2; s2 = s1; s1 = s0; }
  const v = s1 * s1 + s2 * s2 - coeff * s1 * s2;
  return v > 0 ? Math.sqrt(v) / (n / 2) : 0;
}

function peakOf(x) { let p = 0; for (let i = 0; i < x.length; i++) p = Math.max(p, Math.abs(x[i])); return p; }

/** Kéo về đúng mức độ vang mục tiêu (mặc định −14 LUFS, chuẩn phát trực tuyến). */
function normalizeLoudness(input, sr, { targetLufs = -14, maxGainDb = 18 } = {}) {
  const m = measureLoudness(input, sr);
  if (m.lufs <= -70) return { samples: input, applied: 0, before: m };
  const gainDb = clamp(targetLufs - m.lufs, -maxGainDb, maxGainDb);
  const g = dbToLin(gainDb);
  const out = new Float32Array(input.length);
  for (let i = 0; i < input.length; i++) out[i] = input[i] * g;
  return { samples: out, applied: round(gainDb, 2), before: m };
}

/**
 * Giới hạn đỉnh có nhìn trước: hạ ích TRƯỚC khi đỉnh tới, nên không cắt ngọn
 * sóng. Cắt thẳng (hard clip) sinh hài méo nghe rè trên loa nhỏ.
 */
function limit(input, sr, { ceilingDb = -1.0, lookaheadMs = 5, releaseMs = 50 } = {}) {
  const ceiling = dbToLin(ceilingDb);
  const la = Math.max(1, Math.round(sr * lookaheadMs / 1000));
  const aR = Math.exp(-1 / (sr * releaseMs / 1000));
  const out = new Float32Array(input.length);
  let gain = 1;
  let reduced = 0;

  for (let i = 0; i < input.length; i++) {
    // Đỉnh cao nhất trong cửa sổ nhìn trước
    let peak = 0;
    const end = Math.min(input.length, i + la);
    for (let j = i; j < end; j++) peak = Math.max(peak, Math.abs(input[j]));
    const want = peak > ceiling ? ceiling / peak : 1;
    if (want < gain) { gain = want; reduced++; } else gain = aR * gain + (1 - aR) * want;
    out[i] = clamp(input[i] * gain, -ceiling, ceiling);
  }
  return { samples: out, limitedSamples: reduced };
}

/** ── Cài đặt sẵn theo loại nội dung ──────────────────────────────────────── */
const PRESETS = {
  'giang-bai': {
    name: 'Giảng bài', note: 'Rõ lời, không mệt tai khi nghe cả buổi',
    highpass: 90, eq: [[220, -2.0, 1.0], [2800, 2.5, 0.9], [9000, 1.5, 0.7]],
    deEss: { thresholdDb: -26, ratio: 4 }, parallel: { mix: 0.35, ratio: 5 },
    saturate: { drive: 0.22, even: 0.6 }, reverb: { amount: 0.10, roomMs: 32 },
    targetLufs: -16, ceilingDb: -1.5,
  },
  'phat-thanh': {
    name: 'Phát thanh', note: 'To đều, nghe được trên loa điện thoại',
    highpass: 100, eq: [[250, -2.5, 1.0], [3200, 3.5, 0.9], [11000, 2.0, 0.7]],
    deEss: { thresholdDb: -28, ratio: 5 }, parallel: { mix: 0.55, ratio: 6 },
    saturate: { drive: 0.30, even: 0.5 }, reverb: { amount: 0.06, roomMs: 25 },
    targetLufs: -14, ceilingDb: -1.0,
  },
  'hat-pop': {
    name: 'Hát pop', note: 'Giọng hát nổi trên nền nhạc',
    highpass: 80, eq: [[200, -2.0, 1.0], [3000, 3.0, 0.9], [12000, 3.0, 0.7]],
    deEss: { thresholdDb: -30, ratio: 5 }, parallel: { mix: 0.5, ratio: 6, makeupDb: 5 },
    saturate: { drive: 0.35, even: 0.65 }, reverb: { amount: 0.22, roomMs: 52 },
    targetLufs: -12, ceilingDb: -1.0,
  },
  'hat-ballad': {
    name: 'Hát ballad', note: 'Rộng, có không gian, giữ hơi thở',
    highpass: 75, eq: [[180, -1.5, 1.0], [2600, 2.0, 0.9], [13000, 2.5, 0.7]],
    deEss: { thresholdDb: -32, ratio: 4 }, parallel: { mix: 0.38, ratio: 4 },
    saturate: { drive: 0.25, even: 0.7 }, reverb: { amount: 0.34, roomMs: 78, damping: 0.30 },
    targetLufs: -14, ceilingDb: -1.0,
  },
  'moc': {
    name: 'Mộc', note: 'Chỉ chuẩn độ vang và chặn đỉnh — dùng để so sánh',
    highpass: 0, eq: [], deEss: null, parallel: null, saturate: null, reverb: null,
    targetLufs: -16, ceilingDb: -1.0,
  },
};

/** ── Chuỗi hậu kỳ ────────────────────────────────────────────────────────── */
class StudioChain {
  /**
   * @param {Float32Array} input mẫu −1..1
   * @param {number} sr tần số lấy mẫu
   * @param {object} opts {preset, ...ghi đè từng khâu}
   */
  static process(input, sr, opts = {}) {
    const presetName = opts.preset || 'giang-bai';
    const p = PRESETS[presetName] || PRESETS['giang-bai'];
    const steps = [];
    const t0 = Date.now();
    let x = input;

    const before = measureLoudness(x, sr);

    if (opts.highpass !== 0 && (opts.highpass || p.highpass)) {
      x = new Biquad().highpass(opts.highpass || p.highpass, sr, 0.707).run(x);
      steps.push({ step: 'lọc rumble', detail: `cắt dưới ${opts.highpass || p.highpass} Hz` });
    }

    const eq = opts.eq || p.eq || [];
    for (const [f, g, q] of eq) {
      x = new Biquad().peaking(f, sr, g, q).run(x);
    }
    if (eq.length) steps.push({ step: 'EQ', detail: eq.map(([f, g]) => `${f}Hz ${g > 0 ? '+' : ''}${g}dB`).join(' · ') });

    const de = opts.deEss === null ? null : (opts.deEss || p.deEss);
    if (de) {
      const r = deEss(x, sr, de);
      x = r.samples;
      steps.push({ step: 'de-esser', detail: `can thiệp ${(r.actedRatio * 100).toFixed(1)}% số mẫu` });
    }

    const par = opts.parallel === null ? null : (opts.parallel || p.parallel);
    if (par) {
      const r = parallelCompress(x, sr, par);
      x = r.samples;
      steps.push({ step: 'nén song song', detail: `trộn ${Math.round(r.mix * 100)}% · giảm tối đa ${r.maxReductionDb}dB` });
    }

    const sat = opts.saturate === null ? null : (opts.saturate || p.saturate);
    if (sat) {
      x = saturate(x, sat);
      steps.push({ step: 'bão hoà hài', detail: `độ lái ${sat.drive} · hài chẵn ${sat.even}` });
    }

    const rev = opts.reverb === null ? null : (opts.reverb || p.reverb);
    if (rev && rev.amount > 0) {
      x = reverb(x, sr, rev);
      steps.push({ step: 'hồi âm', detail: `${Math.round(rev.amount * 100)}% · phòng ${rev.roomMs}ms` });
    }

    const targetLufs = opts.targetLufs != null ? opts.targetLufs : p.targetLufs;
    const norm = normalizeLoudness(x, sr, { targetLufs });
    x = norm.samples;
    steps.push({ step: 'chuẩn độ vang', detail: `${before.lufs} → mục tiêu ${targetLufs} LUFS (bù ${norm.applied > 0 ? '+' : ''}${norm.applied}dB)` });

    const lim = limit(x, sr, { ceilingDb: opts.ceilingDb != null ? opts.ceilingDb : p.ceilingDb });
    x = lim.samples;
    steps.push({ step: 'giới hạn đỉnh', detail: `trần ${opts.ceilingDb != null ? opts.ceilingDb : p.ceilingDb} dBTP · chạm ${lim.limitedSamples} mẫu` });

    const after = measureLoudness(x, sr);
    return {
      ok: true,
      samples: x,
      sampleRate: sr,
      preset: presetName,
      presetName: p.name,
      steps,
      before: { lufs: before.lufs, peakDb: before.peakDb },
      after: { lufs: after.lufs, peakDb: after.peakDb },
      ms: Date.now() - t0,
      engine: 'JS_DSP',
    };
  }

  static presets() {
    return Object.entries(PRESETS).map(([id, p]) => ({ id, name: p.name, note: p.note, targetLufs: p.targetLufs }));
  }
}

module.exports = {
  Biquad, StudioChain, PRESETS,
  compress, parallelCompress, deEss, saturate, reverb,
  measureLoudness, normalizeLoudness, limit, peakOf, magnitudeAt,
  dbToLin, linToDb,
};
