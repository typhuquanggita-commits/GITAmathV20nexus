'use strict';
/**
 * PIPELINE 1 — GIỌNG NÓI TIẾNG VIỆT
 *
 * Chọn bộ tổng hợp theo MỤC ĐÍCH chứ không theo sở thích:
 *   · trực tiếp (realtime)  → bộ nhanh nhất còn đáp ứng được
 *   · bài dài / podcast     → bộ chất lượng cao, có cảm xúc
 *   · đọc chính xác         → bộ có WER thấp nhất
 * Bộ nào chưa cài thì bỏ qua, cuối hàng luôn là bộ formant nội bộ — nên
 * không có đường nào dẫn tới "không có tiếng".
 *
 * Hậu kỳ phòng thu bật cho nội dung ghi sẵn, TẮT cho phát trực tiếp: chuỗi
 * DSP cần cả câu mới đo được độ vang, mà trực tiếp thì không chờ được.
 */

const cfg = require('../../config');
const { StudioChain } = require('../dsp');
const { toSpeech } = require('../speech-text');
const { fromWav, toWav } = require('../synth');
const { round } = require('../../utils');

/** Thứ tự ưu tiên theo mục đích. Bộ nội bộ luôn đứng cuối làm lưới đỡ. */
const PURPOSE = {
  'truc-tiep': { name: 'Phát trực tiếp', order: ['zerotts', 'piper', 'offline'], studio: false, preset: null },
  // Giảng bài ưu tiên bộ xuất WAV, vì đường tiếng còn phải ghép vào video và
  // đóng dấu chìm — cả hai việc đó làm trên mẫu PCM. edge-tts xuất MP3 nên
  // không đứng đầu hàng ở đây, dù chất giọng của nó hay hơn.
  'giang-bai': { name: 'Giảng bài', order: ['vieneu', 'zerotts', 'piper', 'offline'], studio: true, preset: 'giang-bai' },
  'bai-dai': { name: 'Bài dài · podcast', order: ['vieneu', 'gomnivoice', 'offline'], studio: true, preset: 'phat-thanh' },
  'chinh-xac': { name: 'Đọc chính xác (đề thi, thông báo)', order: ['gomnivoice', 'zerotts', 'offline'], studio: true, preset: 'giang-bai' },
  'thong-bao': { name: 'Thông báo hệ thống', order: ['zerotts', 'offline'], studio: true, preset: 'phat-thanh' },
  // Tệp tiếng rời gửi cho người nghe: lấy giọng hay nhất, không cần PCM.
  'tep-roi': { name: 'Tệp tiếng rời (chất giọng tốt nhất)', order: ['edge-tts', 'vieneu', 'zerotts', 'offline'], studio: false, preset: null },
};

class VietnameseSpeechPipeline {
  constructor({ providers, compliance = null }) {
    this.providers = providers;
    this.compliance = compliance;
    this.stats = { calls: 0, byPurpose: Object.create(null), byProvider: Object.create(null), studioMs: 0, fellBack: 0 };
  }

  /** Bộ nào sẽ thật sự chạy cho mục đích này. */
  plan(purpose = 'giang-bai', { prefer = null } = {}) {
    const p = PURPOSE[purpose] || PURPOSE['giang-bai'];
    const order = prefer ? [prefer, ...p.order.filter((x) => x !== prefer)] : p.order;
    const chain = order
      .map((id) => this.providers.get(id))
      .filter(Boolean)
      .map((pr) => ({ id: pr.id, name: pr.name, ...pr.available() }));
    const chosen = chain.find((c) => c.ok);
    return {
      purpose, purposeName: p.name, studio: p.studio, preset: p.preset,
      chain, chosen: chosen ? chosen.id : null,
      skipped: chain.filter((c) => !c.ok).map((c) => ({ id: c.id, reason: c.reason, fix: c.fix })),
    };
  }

  /**
   * @param {string} text chữ cần đọc (chưa qua bộ đọc toán)
   * @param {object} profile hồ sơ giọng
   */
  async synthesize(text, profile, { purpose = 'giang-bai', prefer = null, rate = null, emotion = 'neutral', studio = null, preset = null, referenceAudio = null } = {}) {
    this.stats.calls++;
    this.stats.byPurpose[purpose] = (this.stats.byPurpose[purpose] || 0) + 1;

    const p = PURPOSE[purpose] || PURPOSE['giang-bai'];
    const pl = this.plan(purpose, { prefer });
    if (!pl.chosen) return { ok: false, error: 'KHÔNG_NHÀ_CUNG_CẤP_NÀO_CHẠY', plan: pl };

    const t = toSpeech(text);
    const spoken = t.ok ? t.text : String(text);
    const effRate = rate != null ? Number(rate) : (profile.params || profile).rate || 1;
    const prof = { ...profile, params: { ...(profile.params || profile), rate: effRate } };

    let out = null;
    const tried = [];
    for (const c of pl.chain) {
      if (!c.ok) { tried.push({ provider: c.id, error: c.reason }); continue; }
      const pr = this.providers.get(c.id);
      const r = await pr.synthesize(spoken, prof, { rate: effRate, emotion, referenceAudio });
      if (r.ok) { out = r; break; }
      tried.push({ provider: c.id, error: r.error });
    }
    if (!out) return { ok: false, error: 'TẤT_CẢ_NHÀ_CUNG_CẤP_ĐỀU_HỎNG', tried };
    if (tried.length) this.stats.fellBack++;
    this.stats.byProvider[out.provider] = (this.stats.byProvider[out.provider] || 0) + 1;

    // ── Hậu kỳ phòng thu ──
    const wantStudio = studio != null ? studio : (p.studio && cfg.VOICE.studioEnabled);
    let studioReport = null;
    let wav = out.wav;
    if (wantStudio && (!out.mime || out.mime === 'audio/wav')) {
      const pcm = fromWav(out.wav);
      if (pcm) {
        const s = StudioChain.process(pcm.samples, pcm.sampleRate, { preset: preset || p.preset || cfg.VOICE.studioPreset });
        wav = toWav(s.samples, s.sampleRate);
        studioReport = { preset: s.preset, presetName: s.presetName, steps: s.steps, before: s.before, after: s.after, ms: s.ms };
        this.stats.studioMs += s.ms;
      } else {
        studioReport = { skipped: 'NGUỒN_KHÔNG_PHẢI_WAV' };
      }
    }

    return {
      ok: true,
      wav,
      mime: out.mime || 'audio/wav',
      sampleRate: out.sampleRate || 22050,
      ms: out.ms || Math.round(((wav.length - 44) / 2 / (out.sampleRate || 22050)) * 1000),
      provider: out.provider,
      purpose, purposeName: p.name,
      spoken,
      chars: spoken.length,
      rate: effRate,
      studio: studioReport,
      fellBackFrom: tried.map((x) => x.provider),
    };
  }

  status() {
    return {
      purposes: Object.entries(PURPOSE).map(([id, p]) => ({
        id, name: p.name, studio: p.studio, preset: p.preset,
        effective: this.plan(id).chosen,
      })),
      stats: { ...this.stats, byPurpose: { ...this.stats.byPurpose }, byProvider: { ...this.stats.byProvider } },
      studioEnabled: cfg.VOICE.studioEnabled,
      studioPresets: StudioChain.presets(),
    };
  }
}

module.exports = { VietnameseSpeechPipeline, PURPOSE };
