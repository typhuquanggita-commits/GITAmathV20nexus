'use strict';
/**
 * PIPELINE 3 — CHUYỂN ĐỔI GIỌNG HÁT (SVC)
 *
 * Nhận bản thu giọng hát THẬT của một người rồi đổi sang chất giọng khác.
 * Đây là phần NGUY HIỂM NHẤT của cả hệ thống về mặt pháp lý: nó chạm vào
 * giọng của hai con người thật. Luật An ninh mạng 116/2025/QH15 cấm dùng AI
 * giả mạo giọng người khác.
 *
 * Nên ở đây cổng pháp lý KHÔNG phải tuỳ chọn:
 *   · người hát gốc phải có phiếu VOICE_RECORD còn hiệu lực
 *   · chủ giọng đích phải có phiếu VOICE_CLONE có mã hồ sơ văn bản
 *   · thiếu một trong hai → từ chối, không có cách bỏ qua
 *
 * Không có bản "nội bộ luôn chạy" cho SVC — và đó là cố ý. Đổi giọng người
 * thật mà không có mô hình đã huấn luyện thì chỉ ra tiếng méo; còn làm được
 * thì lại là thứ dễ bị lạm dụng nhất. Chưa cài mô hình thì hệ thống nói thẳng
 * là chưa làm được.
 */

const cfg = require('../../config');
const { StudioChain } = require('../dsp');
const { toWav, fromWav } = require('../synth');
const { sha256 } = require('../../utils');

class ConversionPipeline {
  constructor({ neural = {}, compliance = null }) {
    this.soVits = neural.soVits || null;
    this.compliance = compliance;
    this.stats = { requests: 0, denied: 0, converted: 0, failed: 0 };
  }

  engines() {
    const list = [];
    if (this.soVits) {
      const a = this.soVits.available();
      list.push({ id: this.soVits.id, name: this.soVits.name, available: a.ok, reason: a.reason, fix: a.fix, note: this.soVits.note });
    }
    return list;
  }

  /**
   * Cổng pháp lý. Trả {ok:false, …} là dừng, không có đường vòng.
   * @param {string} singerId người hát bản gốc
   * @param {string} targetOwnerId chủ của giọng đích
   */
  authorize(singerId, targetOwnerId) {
    if (!this.compliance) return { ok: false, error: 'CHƯA_GẮN_LỚP_PHÁP_LÝ' };
    if (!singerId) return { ok: false, error: 'THIẾU_NGƯỜI_HÁT_GỐC', need: ['singerId'] };
    if (!targetOwnerId) return { ok: false, error: 'THIẾU_CHỦ_GIỌNG_ĐÍCH', need: ['targetOwnerId'] };

    const a = this.compliance.consents.check(singerId, 'VOICE_RECORD');
    if (!a.ok) {
      return { ok: false, error: 'NGƯỜI_HÁT_GỐC_CHƯA_ĐỒNG_Ý', reason: a.error, subjectId: singerId,
        howToFix: 'POST /voice/consent với kind=VOICE_RECORD' };
    }
    const b = this.compliance.consents.check(targetOwnerId, 'VOICE_CLONE');
    if (!b.ok) {
      return { ok: false, error: 'CHỦ_GIỌNG_ĐÍCH_CHƯA_ĐỒNG_Ý', reason: b.error, subjectId: targetOwnerId,
        howToFix: 'POST /voice/consent với kind=VOICE_CLONE, bắt buộc có documentRef' };
    }
    return { ok: true, singerConsent: a.consent.consentId, targetConsent: b.consent.consentId };
  }

  async convert({ sourceWav, singerId, targetOwnerId, targetVoice = '', pitchShift = 0, studio = true, preset = 'hat-pop' }) {
    this.stats.requests++;
    if (!sourceWav || !sourceWav.length) return { ok: false, error: 'THIẾU_BẢN_THU_GỐC' };

    const gate = this.authorize(singerId, targetOwnerId);
    if (!gate.ok) {
      this.stats.denied++;
      this.compliance?.audit.append('TỪ_CHỐI_ĐỔI_GIỌNG_HÁT', {
        subjectId: singerId, targetOwnerId, reason: gate.error,
      });
      return gate;
    }

    if (!this.soVits) return { ok: false, error: 'CHƯA_CÓ_BỘ_ĐỔI_GIỌNG' };
    const av = this.soVits.available();
    if (!av.ok) {
      return { ok: false, error: 'BỘ_ĐỔI_GIỌNG_CHƯA_SẴN_SÀNG', reason: av.reason, fix: av.fix,
        note: 'Hệ thống không có bản thay thế nội bộ cho việc này — đổi giọng người thật bắt buộc phải có mô hình đã huấn luyện.' };
    }

    const r = await this.soVits.convert(sourceWav, { targetVoice, pitchShift });
    if (!r.ok) { this.stats.failed++; return r; }

    let wav = r.wav;
    let studioReport = null;
    if (studio && cfg.VOICE.studioEnabled) {
      const pcm = fromWav(wav);
      if (pcm) {
        const s = StudioChain.process(pcm.samples, pcm.sampleRate, { preset });
        wav = toWav(s.samples, s.sampleRate);
        studioReport = { preset: s.preset, steps: s.steps, before: s.before, after: s.after };
      }
    }

    this.stats.converted++;
    const entry = this.compliance?.audit.append('ĐỔI_GIỌNG_HÁT', {
      subjectId: singerId, targetOwnerId, targetVoice,
      sourceHash: sha256(sourceWav.toString('base64').slice(0, 4096)).slice(0, 16),
      singerConsent: gate.singerConsent, targetConsent: gate.targetConsent,
      provider: r.provider, pitchShift,
    });

    return {
      ok: true, wav, provider: r.provider, mode: 'svc',
      studio: studioReport, auditId: entry ? entry.id : null,
      consents: { singer: gate.singerConsent, target: gate.targetConsent },
    };
  }

  status() {
    return { engines: this.engines(), stats: { ...this.stats },
      rule: 'Bắt buộc có phiếu đồng ý của CẢ người hát gốc (VOICE_RECORD) lẫn chủ giọng đích (VOICE_CLONE).' };
  }
}

module.exports = { ConversionPipeline };
