'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỘ TỔNG HỢP GIỌNG NÓI CHẠY NGOẠI TUYẾN
 * ═══════════════════════════════════════════════════════════════════════════
 *  Vì sao tự viết thay vì gọi dịch vụ ngoài:
 *
 *   · Tài liệu gốc đề xuất dùng endpoint Google Translate TTS. Đó là endpoint
 *     KHÔNG CHÍNH THỨC — chính tài liệu cũng ghi "có thể bị chặn". Đặt cả sản
 *     phẩm giáo dục lên một endpoint không cam kết là tự đặt mìn dưới chân.
 *   · Bản cài trên máy giáo viên phải đọc được bài khi lớp mất mạng.
 *   · Không gửi nội dung bài giảng ra máy chủ bên ngoài khi chưa có nhu cầu.
 *
 *  Cách làm: TỔNG HỢP FORMANT. Nguồn thanh (dây thanh) là chuỗi xung tuần hoàn
 *  theo cao độ F0; nguồn nhiễu (xát) là nhiễu trắng. Cả hai đi qua các bộ lọc
 *  cộng hưởng mô phỏng khoang miệng (formant F1, F2, F3). Thay đổi formant
 *  theo thời gian thì ra nguyên âm; thay đổi F0 theo thời gian thì ra THANH ĐIỆU
 *  — thứ bắt buộc phải đúng trong tiếng Việt.
 *
 *  Chất lượng: rõ tiếng, nghe ra chữ, đúng thanh điệu — KHÔNG phải giọng
 *  studio. Muốn giọng tự nhiên thì cắm nhà cung cấp thật qua lớp providers.
 *  Hệ thống nói thẳng mức chất lượng của từng nguồn, không tô vẽ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { phonemize } = require('./phonemizer');
const { seededRandom } = require('../utils');

const SAMPLE_RATE = 22050;
const BITS = 16;

/** Bộ lọc cộng hưởng hai cực — mô phỏng một formant của khoang miệng. */
function makeResonator(freq, bandwidth, sr = SAMPLE_RATE) {
  const r = Math.exp(-Math.PI * bandwidth / sr);
  const theta = 2 * Math.PI * freq / sr;
  const a1 = 2 * r * Math.cos(theta);
  const a2 = -(r * r);
  const gain = (1 - a1 - a2);
  let y1 = 0;
  let y2 = 0;
  return {
    step(x) {
      const y = gain * x + a1 * y1 + a2 * y2;
      y2 = y1; y1 = y;
      return y;
    },
    reset() { y1 = 0; y2 = 0; },
    retune(f, bw) {
      const rr = Math.exp(-Math.PI * bw / sr);
      const th = 2 * Math.PI * f / sr;
      // Cập nhật hệ số tại chỗ để formant trượt mượt khi chuyển âm.
      this._a1 = 2 * rr * Math.cos(th);
      this._a2 = -(rr * rr);
    },
  };
}

/**
 * Bộ lọc formant có thể đổi tần số liên tục — cần cho nguyên âm đôi và
 * chỗ nối phụ âm với nguyên âm (formant transition), vốn là thứ giúp tai
 * người phân biệt "ba" với "ga".
 */
function makeGlidingResonator(sr = SAMPLE_RATE) {
  let y1 = 0;
  let y2 = 0;
  return {
    step(x, freq, bw) {
      const r = Math.exp(-Math.PI * bw / sr);
      const theta = 2 * Math.PI * freq / sr;
      const a1 = 2 * r * Math.cos(theta);
      const a2 = -(r * r);
      const gain = 1 - a1 - a2;
      const y = gain * x + a1 * y1 + a2 * y2;
      y2 = y1; y1 = y;
      return y;
    },
    reset() { y1 = 0; y2 = 0; },
  };
}

/** Nội suy tuyến tính trên đường cong thanh điệu (4 mốc). */
function toneAt(contour, t) {
  const n = contour.length - 1;
  const x = Math.max(0, Math.min(1, t)) * n;
  const i = Math.min(n - 1, Math.floor(x));
  const f = x - i;
  return contour[i] * (1 - f) + contour[i + 1] * f;
}

class VoiceSynth {
  /**
   * @param {object} profile Hồ sơ giọng: cao độ nền, tốc độ, độ khàn…
   */
  constructor(profile = {}) {
    this.p = {
      f0: 118,            // cao độ nền (Hz) — nam ~110-130, nữ ~200-230
      f0Range: 0.16,      // biên độ lên xuống của giai điệu câu
      rate: 1.0,          // tốc độ đọc
      breathiness: 0.06,  // độ hơi trong giọng
      timbre: 1.0,        // hệ số dịch formant: <1 giọng trầm/to, >1 giọng thanh
      jitter: 0.012,      // dao động nhỏ của cao độ — giọng không rung thì nghe như máy
      gain: 0.62,
      ...profile,
    };
    this.rnd = seededRandom(profile.seed || 'gita-voice');
  }

  /** Nguồn thanh: xung tam giác mượt, giống dạng sóng dây thanh hơn sóng vuông. */
  _glottalPulse(phase) {
    // Mô hình Rosenberg rút gọn: mở nhanh, đóng chậm.
    if (phase < 0.6) {
      const x = phase / 0.6;
      return 3 * x * x - 2 * x * x * x;
    }
    const x = (phase - 0.6) / 0.4;
    return 1 - x * x;
  }

  /**
   * Dựng sóng cho một danh sách đoạn âm (một âm tiết).
   * @returns {Float32Array}
   */
  /**
   * @param {Array} segments các đoạn âm của một âm tiết
   * @param {object} o
   * @param {number} o.f0Base cao độ nền
   * @param {function} [o.f0At] (t 0..1, ms, seg) → cao độ Hz. Khi HÁT thì cao độ do
   *   nốt nhạc quyết định chứ không phải đường thanh điệu, nên lớp hát truyền
   *   hàm này vào để thay hoàn toàn phần cao độ của lời nói.
   */
  renderSegments(segments, { f0Base, f0At = null }) {
    const sr = SAMPLE_RATE;
    const total = segments.reduce((s, x) => s + x.ms, 0);
    const n = Math.max(1, Math.round((total / 1000) * sr));
    const out = new Float32Array(n);

    const r1 = makeGlidingResonator(sr);
    const r2 = makeGlidingResonator(sr);
    const r3 = makeGlidingResonator(sr);
    const rn = makeGlidingResonator(sr);   // formant mũi

    let idx = 0;
    let phase = 0;
    const contour = segments[0]?.toneContour || [1, 1, 1, 1];

    // Mốc thời gian của từng đoạn, để nội suy formant giữa các đoạn.
    let elapsed = 0;
    const marks = segments.map((seg) => {
      const start = elapsed;
      elapsed += seg.ms;
      return { seg, start, end: elapsed };
    });

    const targetAt = (ms) => {
      // Tìm đoạn hiện tại và đoạn kế để trượt formant giữa hai đoạn.
      let cur = marks[marks.length - 1];
      for (const m of marks) if (ms >= m.start && ms < m.end) { cur = m; break; }
      const i = marks.indexOf(cur);
      const nxt = marks[i + 1] || cur;
      const local = (ms - cur.start) / Math.max(1, cur.end - cur.start);
      const pick = (s) => ({
        f1: s.f1 ?? (s.type === 'nasal' ? 280 : 500),
        f2: s.f2 ?? (s.place === 'velar' ? 1000 : s.place === 'labial' ? 900 : 1700),
        f3: s.f3 ?? 2500,
      });
      const a = pick(cur.seg);
      const b = pick(nxt.seg);
      // Chỉ trượt ở 30% cuối mỗi đoạn — đó là vùng chuyển tiếp thật trong lời nói.
      const w = local > 0.7 ? (local - 0.7) / 0.3 : 0;
      return {
        f1: a.f1 * (1 - w) + b.f1 * w,
        f2: a.f2 * (1 - w) + b.f2 * w,
        f3: a.f3 * (1 - w) + b.f3 * w,
        seg: cur.seg,
        local,
      };
    };

    for (let i = 0; i < n; i++) {
      const ms = (i / sr) * 1000;
      const { f1, f2, f3, seg, local } = targetAt(ms);
      const t = ms / Math.max(1, total);

      // ── Cao độ theo đường thanh điệu ──
      const jitter = 1 + (this.rnd() - 0.5) * 2 * this.p.jitter;
      let f0;
      if (f0At) {
        // Truyền cả đoạn đang dựng: tiếng Anh cần biết đoạn này có nằm trong
        // âm tiết mang trọng âm hay không để nâng cao độ đúng chỗ.
        f0 = f0At(t, ms, seg) * jitter;
      } else {
        f0 = f0Base * toneAt(contour, t) * jitter;
        if (seg.glottal && local > 0.72) f0 *= 0.82;   // thanh ngã/nặng có chỗ nghẽn
      }

      // ── Nguồn âm ──
      let src = 0;
      const voiced = seg.kind === 'vowel' || seg.kind === 'glide' || seg.voiced === true
        || seg.type === 'nasal' || seg.type === 'liquid';

      if (voiced) {
        phase += f0 / sr;
        if (phase >= 1) phase -= 1;
        src = this._glottalPulse(phase) - 0.5;
        src += (this.rnd() - 0.5) * this.p.breathiness;
      }
      if (seg.type === 'fricative' || seg.aspirated) {
        // Âm xát: nhiễu trắng, mạnh hơn ở giữa đoạn.
        const env = Math.sin(Math.PI * Math.min(1, local));
        src += (this.rnd() - 0.5) * 1.8 * env * (seg.voiced ? 0.5 : 1);
      }
      if (seg.type === 'stop') {
        // Âm tắc: im lặng rồi bật ra. Tiếng bật nằm ở 25% cuối đoạn.
        if (local < 0.72) src *= 0.05;
        else src += (this.rnd() - 0.5) * 2.2 * (seg.voiced ? 0.6 : 1);
      }

      // ── Khoang miệng ──
      const tm = this.p.timbre;
      let y = r1.step(src, f1 * tm, 70) * 1.0
        + r2.step(src, f2 * tm, 110) * 0.55
        + r3.step(src, f3 * tm, 170) * 0.22;

      // Âm mũi: thêm một cộng hưởng thấp và hút bớt formant 1.
      if (seg.type === 'nasal') {
        y = y * 0.55 + rn.step(src, 270, 120) * 0.9;
      }

      // ── Bao biên độ: vào êm, ra êm, không có tiếng "cắt" ──
      let amp = 1;
      const fadeMs = 8;
      const segStart = marks.find((m) => ms >= m.start && ms < m.end) || marks[marks.length - 1];
      const inSeg = ms - segStart.start;
      const segLen = segStart.end - segStart.start;
      if (inSeg < fadeMs) amp *= inSeg / fadeMs;
      if (segLen - inSeg < fadeMs) amp *= Math.max(0, (segLen - inSeg) / fadeMs);
      if (seg.kind === 'consonant' && seg.role === 'coda' && seg.type === 'stop') {
        amp *= 0.55;   // âm cuối tắc trong tiếng Việt không bật hơi
      }

      out[idx++] = y * amp * this.p.gain;
    }

    return out;
  }

  /** Khoảng lặng. */
  silence(ms) {
    return new Float32Array(Math.max(0, Math.round((ms / 1000) * SAMPLE_RATE)));
  }

  /**
   * Đọc cả một đoạn văn bản (đã chuẩn hoá) thành sóng âm.
   * @returns {{samples: Float32Array, ms: number, syllables: number, unknown: Array}}
   */
  render(text, { rate = null } = {}) {
    const r = rate ?? this.p.rate;
    const ph = phonemize(text, { rate: r });
    const chunks = [];
    let syllableIndex = 0;
    const totalSyll = ph.syllables || 1;

    for (const item of ph.items) {
      if (item.type === 'pause') {
        chunks.push(this.silence(item.ms / r));
        continue;
      }
      // Giai điệu câu: cao độ hạ dần về cuối câu, nhấn nhẹ ở đầu.
      const pos = syllableIndex / totalSyll;
      const declination = 1 + this.p.f0Range * (0.5 - pos) * 0.8;
      const f0 = this.p.f0 * declination;
      chunks.push(this.renderSegments(item.segments, { f0Base: f0 }));
      // Khe hở rất ngắn giữa các âm tiết để tai tách được từng tiếng.
      chunks.push(this.silence(18 / r));
      syllableIndex++;
    }

    const total = chunks.reduce((s, c) => s + c.length, 0);
    const out = new Float32Array(total);
    let o = 0;
    for (const c of chunks) { out.set(c, o); o += c.length; }

    // Chuẩn hoá biên độ về mức an toàn, tránh vỡ tiếng.
    let peak = 0;
    for (let i = 0; i < out.length; i++) peak = Math.max(peak, Math.abs(out[i]));
    if (peak > 0) {
      const k = 0.89 / peak;
      for (let i = 0; i < out.length; i++) out[i] *= k;
    }

    return {
      samples: out,
      ms: Math.round((out.length / SAMPLE_RATE) * 1000),
      syllables: ph.syllables,
      unknown: ph.unknown,
      sampleRate: SAMPLE_RATE,
    };
  }
}

/**
 * Đóng gói mẫu PCM thành tệp WAV 16-bit đơn kênh.
 * Nhận cả Float32Array (-1..1) lẫn Int16Array (đã lượng tử hoá sẵn). Phân biệt
 * hai loại là bắt buộc: lớp đóng dấu chìm sửa trực tiếp bit thấp nhất của mẫu
 * Int16, nếu ở đây cứ nhân 32767 thêm lần nữa thì dấu mất sạch và mọi mẫu đều
 * bị kẹp biên.
 */
function toWav(samples, sampleRate = SAMPLE_RATE) {
  if (samples instanceof Int16Array) return int16ToWav(samples, sampleRate);
  const n = samples.length;
  const dataSize = n * 2;
  const buf = Buffer.alloc(44 + dataSize);
  buf.write('RIFF', 0);
  buf.writeUInt32LE(36 + dataSize, 4);
  buf.write('WAVE', 8);
  buf.write('fmt ', 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);              // PCM
  buf.writeUInt16LE(1, 22);              // 1 kênh
  buf.writeUInt32LE(sampleRate, 24);
  buf.writeUInt32LE(sampleRate * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(BITS, 34);
  buf.write('data', 36);
  buf.writeUInt32LE(dataSize, 40);
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  return buf;
}

/** Đóng gói mẫu đã là Int16 — giữ nguyên từng bit, không lượng tử hoá lại. */
function int16ToWav(samples, sampleRate = SAMPLE_RATE) {
  const n = samples.length;
  const dataSize = n * 2;
  const buf = Buffer.alloc(44 + dataSize);
  buf.write('RIFF', 0);
  buf.writeUInt32LE(36 + dataSize, 4);
  buf.write('WAVE', 8);
  buf.write('fmt ', 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(sampleRate, 24);
  buf.writeUInt32LE(sampleRate * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(BITS, 34);
  buf.write('data', 36);
  buf.writeUInt32LE(dataSize, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(samples[i], 44 + i * 2);
  return buf;
}

/** Đọc lại tệp WAV thành mẫu — dùng để kiểm tra và đóng dấu. */
function fromWav(buffer) {
  if (buffer.length < 44 || buffer.toString('ascii', 0, 4) !== 'RIFF') return null;
  const sampleRate = buffer.readUInt32LE(24);
  const bits = buffer.readUInt16LE(34);
  if (bits !== 16) return null;
  // Tìm khối 'data' — không phải tệp WAV nào cũng đặt nó ngay sau 'fmt '.
  let off = 12;
  while (off + 8 <= buffer.length) {
    const id = buffer.toString('ascii', off, off + 4);
    const size = buffer.readUInt32LE(off + 4);
    if (id === 'data') {
      const n = Math.floor(size / 2);
      const s = new Float32Array(n);
      const raw = new Int16Array(n);
      for (let i = 0; i < n; i++) {
        const v = buffer.readInt16LE(off + 8 + i * 2);
        raw[i] = v;
        s[i] = v / 32767;
      }
      // `int16` là mẫu nguyên bản: lớp đóng dấu chìm đọc bit thấp nhất ở đây,
      // không đi vòng qua số thực (một lần quy đổi là một lần mất bit).
      return { samples: s, int16: raw, sampleRate };
    }
    off += 8 + size + (size % 2);
  }
  return null;
}

module.exports = { VoiceSynth, toWav, int16ToWav, fromWav, SAMPLE_RATE };
