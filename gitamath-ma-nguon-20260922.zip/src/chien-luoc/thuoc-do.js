'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  THƯỚC ĐO — VÀ LUẬT CẤM ĐẶT CHỈ TIÊU CHO THỨ CHƯA ĐO ĐƯỢC
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Một thẻ điểm hỏng theo bốn cách, và cả bốn đều bị máy canh ở đây:
 *
 *  1. TOÀN CHỈ BÁO KẾT QUẢ. Doanh thu, tỉ lệ giữ chân, số mốc đã qua — tất cả
 *     đều nói chuyện đã rồi. Đọc xong không làm gì được nữa. Mỗi mục tiêu phải
 *     có ít nhất một CHỈ BÁO DẪN DẮT: thứ động đậy TRƯỚC, còn kịp can thiệp.
 *
 *  2. ĐẶT CHỈ TIÊU CHO THỨ CHƯA ĐO ĐƯỢC. Đây là cách nhanh nhất biến một thẻ
 *     điểm thành văn bản trang trí: "giữ chân 85%" trong khi hệ thống chưa có
 *     khái niệm "đang là khách hàng". Con số ấy không sai — nó vô nghĩa, và
 *     tệ hơn là nó làm người đọc tưởng có ai đó đang theo dõi.
 *     Luật ở đây: `chuaNoiNguon: true` thì TRƯỜNG `chiTieu` PHẢI để trống.
 *
 *  3. THƯỚC ĐO VÔ CHỦ. Không ai chịu thì không ai làm. Mỗi thước đo ghi rõ ai.
 *
 *  4. THƯỚC ĐO KHÔNG NÓI LẤY SỐ TỪ ĐÂU. Không có nguồn thì con số ấy hoặc là
 *     gõ tay, hoặc là bịa — và sáu tháng sau không ai phân biệt được nữa.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { MT_INDEX } = require('./ban-do');

/**
 *  loai   'dan-dat'  — động đậy trước, còn kịp can thiệp
 *         'ket-qua'  — xác nhận chuyện đã rồi
 */
const THUOC_DO = [
  // ── HH1 · đội trợ lý sẵn sàng ─────────────────────────────────────────
  { ma: 'D01', mucTieu: 'HH1', ten: 'Tỉ lệ trợ lý AI chuyên môn sẵn sàng', loai: 'dan-dat',
    nguon: 'src/agents/runtime.js — trạng thái đội hình', chiTieu: '≥ 99%',
    ai: 'Trực hệ thống', nhip: 'mỗi lượt thanh tra' },
  { ma: 'D02', mucTieu: 'HH1', ten: 'Số buổi học bị gián đoạn vì trợ lý treo', loai: 'ket-qua',
    nguon: 'telemetry SESSION_END bất thường + biên bản thanh tra', chiTieu: '0 buổi mỗi tuần',
    ai: 'Trực hệ thống', nhip: 'tuần' },

  // ── HH2 · học liệu có bằng chứng ──────────────────────────────────────
  { ma: 'D03', mucTieu: 'HH2', ten: 'Tỉ lệ bài trong kho có bằng chứng xác minh', loai: 'dan-dat',
    nguon: 'src/content/ + mục soi TT06', chiTieu: '100%',
    ai: 'Quản trị học liệu', nhip: 'mỗi lượt thanh tra' },
  { ma: 'D04', mucTieu: 'HH2', ten: 'Số bài sai đáp số lọt tới học viên', loai: 'ket-qua',
    nguon: 'tình huống TH26 + nhật ký gỡ bài', chiTieu: '0 bài mỗi quý',
    ai: 'Quản trị học liệu', nhip: 'quý' },

  // ── HH3 · dữ liệu bền vững và riêng tư ────────────────────────────────
  { ma: 'D05', mucTieu: 'HH3', ten: 'Mục soi bền vững dữ liệu đạt ở mọi lượt', loai: 'dan-dat',
    nguon: 'tổ thanh tra TT01', chiTieu: '10/10 lượt mỗi ngày',
    ai: 'Quản trị hệ thống', nhip: 'ngày' },
  { ma: 'D06', mucTieu: 'HH3', ten: 'Số bản ghi tâm lý chứa câu trả lời thô', loai: 'dan-dat',
    nguon: 'tổ thanh tra TT09 + src/khao-sat/kho.js', chiTieu: '0 bản ghi',
    ai: 'Quản trị hệ thống', nhip: 'ngày' },
  { ma: 'D07', mucTieu: 'HH3', ten: 'Số lần mất dữ liệu có ảnh hưởng học viên', loai: 'ket-qua',
    nguon: 'biên bản kịch bản KB01', chiTieu: '0 lần',
    ai: 'Quản trị hệ thống', nhip: 'quý' },

  // ── HH4 · người trực biết việc ────────────────────────────────────────
  { ma: 'D08', mucTieu: 'HH4', ten: 'Tỉ lệ tình huống có kịch bản đầy đủ bốn mục', loai: 'dan-dat',
    nguon: 'src/trai-nghiem/tinh-huong.js + src/quy-trinh/so-tay.js', chiTieu: '100%',
    ai: 'Người phụ trách vận hành', nhip: 'quý' },
  { ma: 'D09', mucTieu: 'HH4', ten: 'Số việc mức đỏ xử quá hạn cam kết', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — chưa có nhật ký ghi thời điểm nhận và thời điểm xử xong từng tình huống', chiTieu: null,
    ai: 'Người phụ trách vận hành', nhip: 'tháng', chuaNoiNguon: true },

  // ── QT1 · đo đúng ─────────────────────────────────────────────────────
  { ma: 'D10', mucTieu: 'QT1', ten: 'Số lần công cụ tự khai vượt quyền bị luật đo chặn', loai: 'dan-dat',
    nguon: 'src/khao-sat/hien-phap-do.js — nhật ký từ chối', chiTieu: 'mọi lần xin đều bị chặn đúng',
    ai: 'Người phụ trách chuyên môn', nhip: 'tháng' },
  { ma: 'D11', mucTieu: 'QT1', ten: 'Tỉ lệ hồ sơ có dấu vết nguồn cho mọi kết luận', loai: 'ket-qua',
    nguon: 'src/khao-sat/lo-trinh-ca-nhan.js — vetNguon', chiTieu: '100%',
    ai: 'Người phụ trách chuyên môn', nhip: 'quý' },

  // ── QT2 · dạy đúng chỗ hổng ───────────────────────────────────────────
  { ma: 'D12', mucTieu: 'QT2', ten: 'Tỉ lệ buổi học nhắm đúng phần yếu đã đo', loai: 'dan-dat',
    nguon: 'telemetry + mastery.weakest', chiTieu: '≥ 70%',
    ai: 'Giáo viên phụ trách', nhip: 'tuần' },
  { ma: 'D13', mucTieu: 'QT2', ten: 'Số học viên đứng yên một cấp quá 21 ngày', loai: 'dan-dat',
    nguon: 'lưới 50 ô + tình huống TH13', chiTieu: 'giảm dần theo quý',
    ai: 'Giáo viên phụ trách', nhip: 'tuần' },

  // ── QT3 · chạm đúng lúc ───────────────────────────────────────────────
  { ma: 'D14', mucTieu: 'QT3', ten: 'Tỉ lệ tình huống mức đỏ và cam được chạm trong hạn', loai: 'dan-dat',
    nguon: 'CHƯA CÓ — lưới điểm chạm mới là bản đồ việc phải làm, chưa ghi lại việc ĐÃ làm', chiTieu: null,
    ai: 'Cố vấn đồng hành', nhip: 'tuần', chuaNoiNguon: true },
  { ma: 'D15', mucTieu: 'QT3', ten: 'Số nhà im lặng trên 30 ngày không ai gọi', loai: 'dan-dat',
    nguon: 'phiên đăng nhập tài khoản phụ huynh + tình huống TH23', chiTieu: '0 nhà',
    ai: 'Cố vấn đồng hành', nhip: 'tuần' },

  // ── QT4 · bắt lỗi trước khi thành sự cố ───────────────────────────────
  { ma: 'D16', mucTieu: 'QT4', ten: 'Số lượt thanh tra chạy đủ trong ngày', loai: 'dan-dat',
    nguon: 'src/thanh-tra/to-thanh-tra.js — biên bản ngày', chiTieu: '10/10 lượt',
    ai: 'Trực hệ thống', nhip: 'ngày' },
  { ma: 'D17', mucTieu: 'QT4', ten: 'Tỉ lệ lỗi bị bắt TRƯỚC khi chạm tới học viên', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — chưa nối biên bản thanh tra với sổ sự cố chạm tới học viên', chiTieu: null,
    ai: 'Người phụ trách vận hành', nhip: 'quý', chuaNoiNguon: true },

  // ── QT5 · phục hồi tử tế ──────────────────────────────────────────────
  { ma: 'D18', mucTieu: 'QT5', ten: 'Tỉ lệ vụ việc đi đủ mười bước phục hồi', loai: 'dan-dat',
    nguon: 'CHƯA CÓ — bộ đếm bước tính trong bộ nhớ, chưa lưu hồ sơ vụ việc', chiTieu: null,
    ai: 'Người phụ trách vận hành', nhip: 'tháng', chuaNoiNguon: true },
  { ma: 'D19', mucTieu: 'QT5', ten: 'Số vụ việc đóng hồ sơ mà không có thay đổi hệ thống nào', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — chưa có hồ sơ vụ việc để đối chiếu bước 10', chiTieu: null,
    ai: 'Người phụ trách vận hành', nhip: 'quý', chuaNoiNguon: true },

  // Chỉ báo dẫn dắt của QT5 phải là thứ đo được TRƯỚC khi có sự cố. Đo mức
  // SẴN SÀNG chứ không đo lần phục hồi — vì lần phục hồi thì đã muộn rồi.
  { ma: 'D35', mucTieu: 'QT5', ten: 'Tỉ lệ tình huống nhóm sự cố đã gắn sẵn kịch bản trực', loai: 'dan-dat',
    nguon: 'src/trai-nghiem/tinh-huong.js — trường kichBanSuCo, đối chiếu src/quy-trinh/so-tay.js',
    chiTieu: '100% tình huống nhóm SU_CO',
    ai: 'Người phụ trách vận hành', nhip: 'quý' },

  // ── KH1 · học viên tiến bộ ────────────────────────────────────────────
  { ma: 'D20', mucTieu: 'KH1', ten: 'Số mốc CỨNG đạt được mỗi chặng', loai: 'ket-qua',
    nguon: 'lưới 50 ô — chỉ mốc cứng', chiTieu: '≥ 2 mốc mỗi chặng',
    ai: 'Giáo viên phụ trách', nhip: 'chặng' },
  { ma: 'D21', mucTieu: 'KH1', ten: 'Tỉ lệ dạng bài từ yếu lên thạo và GIỮ được sau 14 ngày', loai: 'dan-dat',
    nguon: 'mastery + ôn giãn cách', chiTieu: '≥ 80%',
    ai: 'Giáo viên phụ trách', nhip: 'tuần' },

  // ── KH2 · gia đình tin số liệu ────────────────────────────────────────
  { ma: 'D22', mucTieu: 'KH2', ten: 'Tỉ lệ gia đình mở xem bài làm thật của con', loai: 'dan-dat',
    nguon: 'phiên đăng nhập phụ huynh + trang đã mở', chiTieu: '≥ 60% mỗi tháng',
    ai: 'Cố vấn đồng hành', nhip: 'tháng' },
  { ma: 'D23', mucTieu: 'KH2', ten: 'Số lần gia đình nói số liệu không khớp thực tế', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — chưa có sổ ghi lần gia đình phản hồi về số liệu', chiTieu: null,
    ai: 'Người phụ trách lớp', nhip: 'quý', chuaNoiNguon: true },

  // ── KH3 · gia đình ở lại ──────────────────────────────────────────────
  { ma: 'D24', mucTieu: 'KH3', ten: 'Tỉ lệ học viên giữ được nhịp ≥ 3 buổi/tuần', loai: 'dan-dat',
    nguon: 'telemetry.sessions', chiTieu: '≥ 70%',
    ai: 'Cố vấn đồng hành', nhip: 'tuần' },
  { ma: 'D25', mucTieu: 'KH3', ten: 'Tỉ lệ quay lại sau một đợt vắng ≥ 7 ngày', loai: 'dan-dat',
    nguon: 'telemetry.sessions + tình huống TH06', chiTieu: '≥ 60%',
    ai: 'Cố vấn đồng hành', nhip: 'tháng' },
  { ma: 'D26', mucTieu: 'KH3', ten: 'Tỉ lệ giữ chân theo kỳ', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — hệ thống không có khái niệm "đang là khách hàng"', chiTieu: null,
    ai: 'Người phụ trách lớp', nhip: 'quý', chuaNoiNguon: true },

  // ── KH4 · gia đình giới thiệu ─────────────────────────────────────────
  { ma: 'D27', mucTieu: 'KH4', ten: 'Số nhà mới nói được ai giới thiệu mình', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — chưa có trường ghi nguồn giới thiệu lúc tạo hồ sơ', chiTieu: null,
    ai: 'Người phụ trách lớp', nhip: 'quý', chuaNoiNguon: true },

  // Chỉ báo dẫn dắt của KH4. Nói rõ nó đo CÁI GÌ: số nhà có đủ căn cứ để
  // giới thiệu, không phải số nhà đã giới thiệu. Hai thứ khác nhau, và gọi
  // nhầm tên là cách một thước đo bắt đầu nói dối.
  { ma: 'D36', mucTieu: 'KH4', ten: 'Số nhà có đủ căn cứ để giới thiệu (đã qua mốc cứng và đi đều ≥ 8 tuần)', loai: 'dan-dat',
    nguon: 'lưới 50 ô + telemetry.sessions', chiTieu: 'tăng theo quý',
    ai: 'Người phụ trách lớp', nhip: 'quý' },

  // ── TC1 · chi phí trong trần ──────────────────────────────────────────
  { ma: 'D28', mucTieu: 'TC1', ten: 'Chi phí gọi mô hình so với trần ngày', loai: 'dan-dat',
    nguon: 'src/dong-tien/so-cai.js', chiTieu: '≤ 100% trần, không lần nào chạm trần',
    ai: 'Quản trị hệ thống', nhip: 'ngày' },
  { ma: 'D29', mucTieu: 'TC1', ten: 'Số lần khoản chi bị sổ cái CHẶN vì vượt trần', loai: 'ket-qua',
    nguon: 'src/dong-tien/so-cai.js — xinTieu', chiTieu: '0 lần mỗi tháng',
    ai: 'Quản trị hệ thống', nhip: 'tháng' },

  // ── TC2 · doanh thu ───────────────────────────────────────────────────
  { ma: 'D30', mucTieu: 'TC2', ten: 'Doanh thu từ gia đình', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — sổ cái khai doanh thu là khoản chưa nối nguồn', chiTieu: null,
    ai: 'Quản lý phụ trách', nhip: 'tháng', chuaNoiNguon: true },

  // ── TC3 · biên lợi nhuận ──────────────────────────────────────────────
  { ma: 'D31', mucTieu: 'TC3', ten: 'Biên lợi nhuận', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — thiếu cả doanh thu lẫn chi phí nhân sự và hạ tầng', chiTieu: null,
    ai: 'Quản lý phụ trách', nhip: 'quý', chuaNoiNguon: true },

  // ── TC4 · không mất tiền vì sự cố ─────────────────────────────────────
  { ma: 'D32', mucTieu: 'TC4', ten: 'Số mục soi mức CHẶN không đạt trong ngày', loai: 'dan-dat',
    nguon: 'tổ thanh tra — năm phép soi mức chặn', chiTieu: '0 mục',
    ai: 'Quản trị hệ thống', nhip: 'ngày' },
  { ma: 'D33', mucTieu: 'TC4', ten: 'Số nghĩa vụ pháp lý chưa có người ký nhận', loai: 'dan-dat',
    nguon: 'src/chien-luoc/an-toan-phap-ly.js', chiTieu: '0 nghĩa vụ',
    ai: 'Người có thẩm quyền pháp lý', nhip: 'quý' },
  { ma: 'D34', mucTieu: 'TC4', ten: 'Tổn thất thực tế vì sự cố, phạt, mất dữ liệu', loai: 'ket-qua',
    nguon: 'CHƯA CÓ — chưa nối sổ kế toán', chiTieu: null,
    ai: 'Quản lý phụ trách', nhip: 'quý', chuaNoiNguon: true },
];

const TD_INDEX = new Map(THUOC_DO.map((d) => [d.ma, d]));

/** Thước đo của một mục tiêu. */
function cuaMucTieu(maMucTieu) {
  return THUOC_DO.filter((d) => d.mucTieu === String(maMucTieu).toUpperCase());
}

/**
 * Soi bộ thước đo theo bốn luật ở đầu tệp.
 */
function soiThuocDo() {
  const loi = [];

  for (const d of THUOC_DO) {
    if (!MT_INDEX.has(d.mucTieu)) loi.push(`${d.ma} gắn vào mục tiêu "${d.mucTieu}" không tồn tại`);
    if (!['dan-dat', 'ket-qua'].includes(d.loai)) loi.push(`${d.ma} không khai là chỉ báo dẫn dắt hay chỉ báo kết quả`);
    if (!d.ai || d.ai.length < 4) loi.push(`${d.ma} là thước đo vô chủ`);
    if (!d.nguon || d.nguon.length < 8) loi.push(`${d.ma} không nói lấy số từ đâu`);
    if (!d.nhip) loi.push(`${d.ma} không nói đo theo nhịp nào`);
    // Luật 2 — luật quan trọng nhất của tệp này.
    if (d.chuaNoiNguon && d.chiTieu) {
      loi.push(`${d.ma} đặt chỉ tiêu "${d.chiTieu}" cho thứ CHƯA ĐO ĐƯỢC — con số ấy không sai, nó vô nghĩa`);
    }
    if (!d.chuaNoiNguon && !d.chiTieu) {
      loi.push(`${d.ma} đo được mà không có chỉ tiêu — đo để biết thì được, nhưng đừng gọi nó là thước đo chiến lược`);
    }
    if (!d.chuaNoiNguon && /CHƯA CÓ/.test(d.nguon)) {
      loi.push(`${d.ma} khai nguồn là "CHƯA CÓ" nhưng không đánh dấu chuaNoiNguon`);
    }
  }

  // Luật 1: mỗi mục tiêu phải có ít nhất một chỉ báo DẪN DẮT đo được.
  for (const m of MT_INDEX.values()) {
    const ds = cuaMucTieu(m.ma);
    if (!ds.length) { loi.push(`${m.ma} không có thước đo nào`); continue; }
    const dan = ds.filter((d) => d.loai === 'dan-dat' && !d.chuaNoiNguon);
    if (!dan.length && !m.chuaNoiNguon) {
      loi.push(`${m.ma} chỉ có chỉ báo kết quả — đọc xong thì chuyện đã rồi, không can thiệp được nữa`);
    }
  }

  const doDuoc = THUOC_DO.filter((d) => !d.chuaNoiNguon);
  return {
    tong: THUOC_DO.length,
    doDuocNgay: doDuoc.length,
    chuaNoiNguon: THUOC_DO.length - doDuoc.length,
    danDat: THUOC_DO.filter((d) => d.loai === 'dan-dat').length,
    ketQua: THUOC_DO.filter((d) => d.loai === 'ket-qua').length,
    loi,
    ok: loi.length === 0,
  };
}

/** Bảng thước đo, xếp theo mục tiêu; phần chưa đo được nêu riêng. */
function bangThuocDo() {
  const soi = soiThuocDo();
  return {
    ...soi,
    theoMucTieu: [...MT_INDEX.keys()].map((ma) => ({ mucTieu: ma, thuocDo: cuaMucTieu(ma) })),
    chuaDoDuoc: THUOC_DO.filter((d) => d.chuaNoiNguon).map((d) => ({
      ma: d.ma, ten: d.ten, mucTieu: d.mucTieu, thieu: d.nguon,
    })),
    nhac: `${soi.chuaNoiNguon}/${soi.tong} thước đo CHƯA nối được nguồn và vì thế KHÔNG có chỉ tiêu. `
      + 'Đặt chỉ tiêu cho thứ chưa đo được là cách nhanh nhất biến thẻ điểm thành văn bản trang trí.',
  };
}

module.exports = { THUOC_DO, TD_INDEX, cuaMucTieu, soiThuocDo, bangThuocDo };
