'use strict';
/**
 * THẺ ĐIỂM — GỘP CẢ TẦNG CHIẾN LƯỢC LẠI MỘT CHỖ
 *
 * Thứ tự các phần ở đây có chủ ý và giống luật của sổ cái dòng tiền: phần
 * CHƯA BIẾT đứng trước phần đã biết. Người đọc phải biết thẻ điểm này chưa
 * thấy gì trước khi tin những gì nó thấy.
 */

const BD = require('./ban-do');
const TD = require('./thuoc-do');
const RR = require('./rui-ro');
const AT = require('./an-toan');
const RS = require('./ra-soat');

function theDiem() {
  const banDo = BD.banDo();
  const thuocDo = TD.bangThuocDo();
  const ruiRo = RR.soiRuiRo();
  const anToan = AT.anToan();
  const raSoat = RS.nhipRaSoat();

  const chuaBiet = [
    ...thuocDo.chuaDoDuoc.map((d) => `${d.ma} ${d.ten} — ${d.thieu}`),
    ...anToan.taiChinh.khongNoiDuoc,
    ...(anToan.phapLy.chuaCoNguoiKy.length
      ? [`${anToan.phapLy.chuaCoNguoiKy.length} nghĩa vụ pháp lý chưa có người ký nhận`] : []),
    ...(raSoat.theoDoiDuoc ? [] : ['Chưa theo dõi được các cuộc rà soát đã diễn ra hay chưa']),
    ...ruiRo.khongCoMucSoi.map((r) => `${r.ma} ${r.ten} — không có mục soi tự động nào canh`),
  ];

  return {
    chuaBiet,
    banDo, thuocDo, ruiRo, anToan, raSoat,
    tomTat: {
      mucTieu: banDo.soi.soMucTieu,
      canhNhanQua: banDo.soi.soCanh,
      canhPhongTonThat: banDo.soi.soCanhPhongTonThat,
      thuocDo: thuocDo.tong,
      thuocDoDoDuoc: thuocDo.doDuocNgay,
      thuocDoChuaNoiNguon: thuocDo.chuaNoiNguon,
      ruiRo: ruiRo.tong,
      ruiRoCoMucSoi: ruiRo.coMucSoiTuDong,
      cuaChanTaiChinh: anToan.taiChinh.soCuaChanCung,
      nghiaVuPhapLy: anToan.phapLy.tong,
      nghiaVuDaKy: anToan.phapLy.daCoNguoiKy,
    },
    ok: banDo.soi.ok && thuocDo.ok && ruiRo.ok,
    ketLuan: `${chuaBiet.length} chỗ hệ thống CHƯA BIẾT, nêu tên ở trên. `
      + `Phần biết được: ${banDo.soi.soMucTieu} mục tiêu nối thành ${banDo.soi.soChuoi} chuỗi nhân quả, `
      + `${thuocDo.doDuocNgay}/${thuocDo.tong} thước đo có nguồn thật, `
      + `${ruiRo.coMucSoiTuDong}/${ruiRo.tong} rủi ro có mục soi tự động canh, `
      + `${anToan.taiChinh.soCuaChanCung} cửa chặn cứng ở phía chi.`,
  };
}

module.exports = { theDiem };
