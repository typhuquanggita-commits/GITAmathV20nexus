'use strict';
/**
 * NHỊP RÀ SOÁT — CHỖ THẺ ĐIỂM THÀNH HỆ THỐNG QUẢN TRỊ, HOẶC THÀNH GIẤY
 *
 * Thẻ điểm không tự làm gì cả. Thứ biến nó thành hệ thống quản trị là NHỊP
 * RÀ SOÁT: đều đặn ngồi xuống, so thực tế với giả thuyết, và sửa GIẢ THUYẾT
 * khi số liệu nói nó sai — chứ không chỉ sửa người.
 *
 * Ba nhịp, ba câu hỏi khác hẳn nhau. Trộn chúng vào một cuộc họp là cách chắc
 * chắn nhất để chỉ còn lại câu hỏi dễ nhất: "tháng này số có đẹp không".
 */

const NHIP = [
  {
    ma: 'RS-NGAY', ten: 'Rà soát ngày', chuKy: 'mỗi ngày, tự động',
    cauHoi: 'Có gì đang hỏng ngay bây giờ không?',
    ai: 'Tổ thanh tra 10 trợ lý AI chuyên môn — máy chạy, không cần họp',
    xem: ['10 lượt thanh tra', 'mục soi mức chặn', 'chi phí so với trần ngày'],
    raQuyetDinh: 'Dừng việc nếu có mục soi mức chặn không đạt.',
    camLam: 'CẤM coi lượt không chạy là lượt sạch.',
  },
  {
    ma: 'RS-THANG', ten: 'Rà soát tháng', chuKy: 'mỗi tháng',
    cauHoi: 'Các chỉ báo DẪN DẮT đang đi hướng nào?',
    ai: 'Người phụ trách vận hành và các chủ thước đo',
    xem: ['21 chỉ báo dẫn dắt', 'tình huống mức đỏ và cam trong tháng', 'rủi ro nào suýt xảy ra'],
    raQuyetDinh: 'Đổi cách làm ở tầng quy trình. KHÔNG đổi chiến lược ở nhịp này.',
    camLam: 'CẤM lấy chỉ báo kết quả ra làm trọng tâm ở đây — chúng nói chuyện đã rồi.',
  },
  {
    ma: 'RS-QUY', ten: 'Rà soát quý', chuKy: 'mỗi quý',
    cauHoi: 'GIẢ THUYẾT NHÂN QUẢ của ta có còn đúng không?',
    ai: 'Người có thẩm quyền cao nhất, cùng chủ các mục tiêu',
    xem: ['bản đồ chiến lược và từng mũi tên của nó', 'chỉ báo kết quả', 'sổ rủi ro', 'nghĩa vụ pháp lý chưa có người ký'],
    raQuyetDinh: 'Sửa BẢN ĐỒ khi số liệu nói một mũi tên là sai. Đây là nhịp duy nhất được sửa bản đồ.',
    camLam: 'CẤM giữ một mũi tên chỉ vì nó đã nằm đó từ đầu. Giả thuyết sai mà giữ thì cả chuỗi phía sau sai theo.',
  },
];

/**
 * Câu hỏi bắt buộc của rà soát quý. Đây là phần hay bị bỏ nhất, vì nó đòi
 * người chủ trì thừa nhận một giả thuyết của chính mình có thể sai.
 */
const CAU_HOI_QUY = [
  'Mũi tên nào trong bản đồ mà ba tháng qua KHÔNG có số liệu nào ủng hộ?',
  'Chỉ báo dẫn dắt nào đã cải thiện mà chỉ báo kết quả phía sau KHÔNG nhúc nhích? '
    + '(Nếu có: giả thuyết nhân quả giữa chúng sai, hoặc độ trễ dài hơn ta nghĩ — phải nói ra ta chọn cách hiểu nào.)',
  'Thước đo nào quý này vẫn chưa nối được nguồn, và ai đang chịu việc nối nó?',
  'Rủi ro nào suýt xảy ra mà không có mục soi nào bắt được?',
  'Nghĩa vụ pháp lý nào vẫn chưa có người ký nhận sau ba tháng?',
  'Ta đã sửa cái gì vì học được từ dữ liệu, hay quý này chỉ báo cáo lại dữ liệu?',
];

/**
 * Trạng thái rà soát. Không có kho lưu biên bản nên hàm này KHÔNG nói được
 * "đã rà soát đúng nhịp chưa" — nó chỉ nói lịch và nói thẳng là chưa theo dõi được.
 */
function nhipRaSoat() {
  return {
    nhip: NHIP,
    cauHoiQuy: CAU_HOI_QUY,
    theoDoiDuoc: false,
    viSao: 'Chưa có kho lưu biên bản rà soát, nên hệ thống KHÔNG biết một cuộc rà soát đã diễn ra hay chưa. '
      + 'Nó chỉ nói được lịch phải làm. Đây là chỗ thiếu, và nó được ghi ra thay vì được che đi.',
    vongLap: 'CHIẾN LƯỢC → BẢN ĐỒ → MỤC TIÊU → THƯỚC ĐO → CHỈ TIÊU → SÁNG KIẾN → HÀNH ĐỘNG '
      + '→ ĐO → RÀ SOÁT → HỌC → SỬA BẢN ĐỒ → quay lại CHIẾN LƯỢC.',
    nhac: 'Vòng lặp trên chỉ khép lại ở bước SỬA BẢN ĐỒ. Rà soát mà không bao giờ sửa bản đồ '
      + 'thì đó là báo cáo, không phải quản trị chiến lược.',
  };
}

module.exports = { NHIP, CAU_HOI_QUY, nhipRaSoat };
