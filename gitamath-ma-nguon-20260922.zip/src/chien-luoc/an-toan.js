'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  AN TOÀN TÀI CHÍNH VÀ AN TOÀN PHÁP LÝ
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  HAI PHẦN NÀY KHÁC NHAU VỀ BẢN CHẤT, VÀ TRỘN CHÚNG LÀ MỘT SAI LẦM.
 *
 *  An toàn TÀI CHÍNH: máy kiểm được. Trần chi là một con số, khoản chi là một
 *  con số, so được. Chỗ nào chưa nối nguồn thì nói thẳng là chưa biết.
 *
 *  An toàn PHÁP LÝ: máy KHÔNG kiểm được, và tệp này không giả vờ ngược lại.
 *
 *  ĐÂY LÀ ĐIỀU QUAN TRỌNG NHẤT CỦA CẢ TỆP: một hệ thống phần mềm không thể
 *  tự chứng nhận mình tuân thủ pháp luật. Nó chỉ làm được hai việc —
 *
 *    1. Liệt kê những NGHĨA VỤ mà chính nó đã tự đặt ra trong mã, kèm chỗ
 *       trong mã thực hiện nghĩa vụ ấy.
 *    2. Đòi mỗi nghĩa vụ có TÊN MỘT NGƯỜI đã xác nhận, và chừng nào chưa có
 *       tên thì trạng thái là CHƯA_CÓ_NGƯỜI_KÝ — không phải "đạt".
 *
 *  Các số hiệu văn bản pháp luật nhắc trong mã này là do người dựng hệ thống
 *  khai, KHÔNG phải do hệ thống tra cứu và xác minh. Chúng phải được người có
 *  chuyên môn pháp lý đối chiếu với văn bản gốc còn hiệu lực trước khi dùng
 *  cho bất kỳ mục đích nào. Ghi sai một số hiệu rồi đem đi báo cáo còn tệ hơn
 *  không ghi gì.
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── PHẦN 1: AN TOÀN TÀI CHÍNH ──────────────────────────────────────────────

/**
 * Ba cửa chặn tổn thất tài chính. Mỗi cửa nói rõ nó CHẶN hay chỉ CẢNH BÁO —
 * hai thứ đó khác nhau rất xa lúc 3 giờ sáng.
 */
const CUA_TAI_CHINH = [
  {
    ma: 'TC-C1', ten: 'Trần chi gọi mô hình theo ngày và theo tháng',
    kieu: 'chan-cung',
    o: 'src/dong-tien/so-cai.js — xinTieu()',
    y: 'Khoản chi vượt trần bị TỪ CHỐI tại chỗ. Không ghi cảnh báo rồi cho qua.',
    viSao: 'Một vòng lặp gọi mô hình tiêu hết ngân sách tháng trong vài giờ, vào lúc không ai ngồi trước màn hình. '
      + 'Cái giá của việc chặn nhầm rẻ hơn cái giá của một đêm như thế.',
  },
  {
    ma: 'TC-C2', ten: 'Từ chối ghi vào khoản chưa nối nguồn',
    kieu: 'chan-cung',
    o: 'src/dong-tien/so-cai.js — ghi()',
    y: 'Ba khoản (doanh thu, nhân sự, hạ tầng) chưa nối nguồn thì sổ cái KHÔNG cho ghi số vào.',
    viSao: 'Một con số bịa trong bảng tài chính nguy hiểm hơn một ô trống, vì ô trống thì người đọc biết mình chưa biết.',
  },
  {
    ma: 'TC-C3', ten: 'Trần chi cho một phim và cổng xác nhận trước khi tiêu',
    kieu: 'chan-cung',
    o: 'src/film/ — FILM_MAX_USD, FILM_REQUIRE_CONFIRM',
    y: 'Không dựng video thật khi chưa có xác nhận tay và khi dự toán vượt trần.',
    viSao: 'Sinh video là cổng tốn tiền nhất trong hệ thống, và nó dễ chạy nhầm nhiều lần nhất.',
  },
];

/** Chỗ mù tài chính — nêu tên trước, cùng luật với sổ cái. */
function anToanTaiChinh() {
  const soCai = require('../dong-tien/so-cai');
  const chuaNoi = Object.values(soCai.KHOAN)
    .filter((k) => k.tinCay === 'chua-co')
    .map((k) => ({ ten: k.ten, thieu: k.thieu }));

  // Rủi ro tập trung: chỉ nói được khi đã nối doanh thu. Chưa nối thì nói thẳng.
  const tapTrung = chuaNoi.length
    ? {
      doDuoc: false,
      lyDo: 'Chưa nối dữ liệu thanh toán nên không biết doanh thu đến từ bao nhiêu nguồn, '
        + 'và vì thế KHÔNG nói được hệ thống có đang phụ thuộc vào một nguồn duy nhất hay không.',
    }
    : { doDuoc: true };

  return {
    cua: CUA_TAI_CHINH,
    soCuaChanCung: CUA_TAI_CHINH.filter((c) => c.kieu === 'chan-cung').length,
    chuaNoiNguon: chuaNoi,
    ruiRoTapTrung: tapTrung,
    khongNoiDuoc: [
      'Số tháng còn trụ được nếu ngừng thu (runway) — cần doanh thu và chi phí nhân sự.',
      'Biên lợi nhuận — cần cả doanh thu lẫn chi phí đầy đủ.',
      'Chi phí phục vụ một khách — cần sổ giờ chăm sóc theo từng nhà.',
    ],
    ketLuan: chuaNoi.length
      ? `An toàn tài chính hiện CHỈ bảo đảm được ở phía CHI: ${CUA_TAI_CHINH.length} cửa chặn cứng đang chạy. `
        + `Phía THU còn ${chuaNoi.length} khoản chưa nối nguồn, nên mọi câu hỏi về lãi, về runway, `
        + 'về rủi ro tập trung đều chưa trả lời được — và không được ước lượng để trả lời cho có.'
      : 'Đã nối đủ nguồn hai phía.',
  };
}

// ── PHẦN 2: AN TOÀN PHÁP LÝ ────────────────────────────────────────────────

/**
 * Nghĩa vụ pháp lý mà hệ thống TỰ ĐẶT RA cho mình.
 *
 *   canCu      — số hiệu văn bản do NGƯỜI DỰNG khai. Hệ thống không xác minh.
 *   lamODau    — chỗ trong mã thực hiện nghĩa vụ này.
 *   nguoiXacNhan — null nghĩa là CHƯA CÓ NGƯỜI KÝ. Không phải "đạt".
 */
const NGHIA_VU = [
  {
    ma: 'PL01', ten: 'Dữ liệu cá nhân của trẻ em chỉ dùng đúng mục đích đã nói và chỉ người có quyền được đọc',
    canCu: 'Luật Bảo vệ dữ liệu cá nhân 91/2025/QH15 (số hiệu do người dựng khai, cần đối chiếu văn bản gốc)',
    lamODau: ['src/khao-sat/kho.js — luật riêng tư từng công cụ', 'src/api/cong-quyen.js — bảng phân quyền'],
    kiemBangMay: 'TT09 soi bản ghi tâm lý không chứa câu trả lời thô; TT02 soi bảng phân quyền',
    nguoiXacNhan: null,
  },
  {
    ma: 'PL02', ten: 'Nội dung do AI tạo ra phải được đánh dấu',
    canCu: 'Luật AI VN 134/2025/QH15 (số hiệu do người dựng khai, cần đối chiếu văn bản gốc)',
    lamODau: ['src/voice/compliance.js — dấu AI trên tệp âm thanh', 'giao diện lớp nghe giảng — nhãn "Giọng AI"'],
    kiemBangMay: 'mục kiểm bắt tệp âm thanh chưa đóng dấu phải ghi rõ vào nhật ký, không im lặng cho qua',
    nguoiXacNhan: null,
  },
  {
    ma: 'PL03', ten: 'Không nhân bản giọng người thật khi chưa có văn bản đồng ý',
    canCu: 'Luật An ninh mạng 116/2025/QH15 (số hiệu do người dựng khai, cần đối chiếu văn bản gốc)',
    lamODau: ['src/voice/pipelines/conversion.js — cổng pháp lý hai phiếu đồng ý'],
    kiemBangMay: 'cổng từ chối khi thiếu mã hồ sơ đồng ý; không có đường vòng',
    nguoiXacNhan: null,
  },
  {
    ma: 'PL04', ten: 'Gia đình có quyền yêu cầu xoá dữ liệu và được xác nhận đã xoá',
    canCu: 'quyền của chủ thể dữ liệu theo pháp luật bảo vệ dữ liệu cá nhân',
    lamODau: ['src/trai-nghiem/tinh-huong.js — TH25', 'src/quy-trinh/so-tay.js — KB07'],
    kiemBangMay: 'chưa có mục soi tự động; hiện dựa vào quy trình trực',
    nguoiXacNhan: null,
  },
  {
    ma: 'PL05', ten: 'Giữ được nhật ký kiểm toán không sửa được cho các hành vi nhạy cảm',
    canCu: 'yêu cầu chung về truy vết trong quản trị dữ liệu',
    lamODau: ['src/governance/audit-chain.js — nhật ký móc xích'],
    kiemBangMay: 'mục kiểm đối chiếu chuỗi băm còn nguyên vẹn sau toàn bộ hoạt động',
    nguoiXacNhan: null,
  },
  {
    ma: 'PL06', ten: 'Không hứa kết quả học tập bằng con số điểm',
    canCu: 'quy định về quảng cáo dịch vụ giáo dục và nguyên tắc không gây hiểu nhầm',
    lamODau: ['src/nha/cay-gia-tri.js', 'src/matran/cay-50.js', 'src/trai-nghiem/tinh-huong.js'],
    kiemBangMay: 'mục kiểm quét mọi quả của lưới 50 ô và mọi kịch bản, bắt câu nào hứa bằng điểm số',
    nguoiXacNhan: null,
  },
];

/**
 * Trạng thái pháp lý. KHÔNG trả về "đạt" cho bất cứ nghĩa vụ nào chưa có người ký.
 */
function anToanPhapLy() {
  const fs = require('node:fs');
  const path = require('node:path');
  const ROOT = path.join(__dirname, '..', '..');
  const loi = [];
  for (const n of NGHIA_VU) {
    for (const f of n.lamODau) {
      const duong = f.split(' — ')[0].trim();
      if (duong.startsWith('src/') && !fs.existsSync(path.join(ROOT, duong))) {
        loi.push(`${n.ma} khai thực hiện ở "${duong}" — tệp không tồn tại`);
      }
    }
  }
  const chuaKy = NGHIA_VU.filter((n) => !n.nguoiXacNhan);
  return {
    tong: NGHIA_VU.length,
    daCoNguoiKy: NGHIA_VU.length - chuaKy.length,
    chuaCoNguoiKy: chuaKy.map((n) => ({ ma: n.ma, ten: n.ten })),
    loiDuongDan: loi,
    tuChungNhan: false,
    canhBao: 'HỆ THỐNG NÀY KHÔNG TỰ CHỨNG NHẬN TUÂN THỦ PHÁP LUẬT, và không có chế độ nào để bật việc đó. '
      + 'Bảng trên chỉ liệt kê nghĩa vụ mà chính hệ thống tự đặt ra cùng chỗ trong mã thực hiện chúng. '
      + `${chuaKy.length}/${NGHIA_VU.length} nghĩa vụ CHƯA CÓ NGƯỜI KÝ NHẬN — trạng thái của chúng là chưa xác nhận, không phải đạt.`,
    soHieuVanBan: 'Các số hiệu văn bản pháp luật trong bảng là do người dựng hệ thống khai, '
      + 'KHÔNG do hệ thống tra cứu. Phải để người có chuyên môn pháp lý đối chiếu với văn bản gốc còn hiệu lực. '
      + 'Ghi sai một số hiệu rồi đem đi báo cáo còn tệ hơn không ghi gì.',
  };
}

/** Cả hai phần, tài chính trước vì nó kiểm được, pháp lý sau vì nó cần người. */
function anToan() {
  return { taiChinh: anToanTaiChinh(), phapLy: anToanPhapLy() };
}

module.exports = { CUA_TAI_CHINH, NGHIA_VU, anToanTaiChinh, anToanPhapLy, anToan };
