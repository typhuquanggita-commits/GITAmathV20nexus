'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  JPEG — giải mã và mã hoá baseline, viết thẳng bằng JavaScript
 * ═══════════════════════════════════════════════════════════════════════════
 *  Gần như mọi dịch vụ tạo ảnh đều trả JPEG. Không giải mã được JPEG thì hệ
 *  thống chỉ biết "có một tệp" chứ không đụng được vào điểm ảnh nào: không
 *  phóng to, không chỉnh màu, không đo chất lượng, không tăng chi tiết.
 *
 *  Nên ở đây có đủ hai chiều:
 *    · GIẢI MÃ — tách khối, Huffman, giải lượng tử, IDCT, nội suy màu, quy
 *      YCbCr về RGB. Hỗ trợ baseline tuần tự (SOF0/SOF1), báo rõ khi gặp
 *      JPEG lũy tiến thay vì trả ảnh rác.
 *    · MÃ HOÁ — DCT, lượng tử theo bảng chuẩn IJG có hệ số chất lượng, mã
 *      Huffman với bảng chuẩn. Dùng để xuất bản giao hàng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const ZIGZAG = new Int32Array([
  0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5,
  12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28,
  35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51,
  58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63,
]);

/** Bảng lượng tử chuẩn IJG. */
const Q_SANG = new Int32Array([
  16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55,
  14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62,
  18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92,
  49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99,
]);
const Q_MAU = new Int32Array([
  17, 18, 24, 47, 99, 99, 99, 99, 18, 21, 26, 66, 99, 99, 99, 99,
  24, 26, 56, 99, 99, 99, 99, 99, 47, 66, 99, 99, 99, 99, 99, 99,
  99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99,
  99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99,
]);

/** Bảng Huffman chuẩn (Phụ lục K của chuẩn JPEG). */
const HUFF = {
  dcSang: { bits: [0, 0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0], vals: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] },
  dcMau: { bits: [0, 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0], vals: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] },
  acSang: {
    bits: [0, 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d],
    vals: [
      0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07,
      0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1, 0x08, 0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0,
      0x24, 0x33, 0x62, 0x72, 0x82, 0x09, 0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28,
      0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49,
      0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69,
      0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
      0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7,
      0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5,
      0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2,
      0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
      0xf9, 0xfa,
    ],
  },
  acMau: {
    bits: [0, 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 0x77],
    vals: [
      0x00, 0x01, 0x02, 0x03, 0x11, 0x04, 0x05, 0x21, 0x31, 0x06, 0x12, 0x41, 0x51, 0x07, 0x61, 0x71,
      0x13, 0x22, 0x32, 0x81, 0x08, 0x14, 0x42, 0x91, 0xa1, 0xb1, 0xc1, 0x09, 0x23, 0x33, 0x52, 0xf0,
      0x15, 0x62, 0x72, 0xd1, 0x0a, 0x16, 0x24, 0x34, 0xe1, 0x25, 0xf1, 0x17, 0x18, 0x19, 0x1a, 0x26,
      0x27, 0x28, 0x29, 0x2a, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
      0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68,
      0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
      0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5,
      0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3,
      0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda,
      0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
      0xf9, 0xfa,
    ],
  },
};

/** Dựng cây tra Huffman từ bảng (số mã theo độ dài, rồi danh sách giá trị). */
function dungBangHuff(bits, vals) {
  const ma = [];
  let code = 0;
  let k = 0;
  for (let len = 1; len <= 16; len++) {
    for (let i = 0; i < bits[len]; i++) { ma.push({ len, code, val: vals[k++] }); code++; }
    code <<= 1;
  }
  const tra = new Map();
  for (const m of ma) tra.set(`${m.len}:${m.code}`, m.val);
  return { tra, ma };
}

/**
 * Bảng cô-sin và hệ số dùng chung cho cả DCT lẫn IDCT.
 * Tính một lần khi nạp mô-đun. Trước đó bảng được dựng lại trong mỗi lần gọi,
 * nghĩa là 8.192 lần Math.cos cho MỖI khối 8×8 — mã hoá một tấm 6MP mất gần
 * 18 giây, gần hết thời gian là gọi cô-sin lặp lại y hệt nhau.
 */
const COS = new Float32Array(64);
for (let x = 0; x < 8; x++) {
  for (let u = 0; u < 8; u++) COS[x * 8 + u] = Math.cos(((2 * x + 1) * u * Math.PI) / 16);
}
const HE_SO = new Float32Array(8);
for (let i = 0; i < 8; i++) HE_SO[i] = i === 0 ? Math.SQRT1_2 : 1;

/** IDCT 8×8 tách trục — tách hai chiều để còn 2×8×8×8 phép nhân thay vì 8⁴. */
function idct8x8(khoi, ra) {
  const tmp = new Float32Array(64);
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      let s = 0;
      for (let u = 0; u < 8; u++) s += HE_SO[u] * khoi[y * 8 + u] * COS[x * 8 + u];
      tmp[y * 8 + x] = s / 2;
    }
  }
  for (let x = 0; x < 8; x++) {
    for (let y = 0; y < 8; y++) {
      let s = 0;
      for (let v = 0; v < 8; v++) s += HE_SO[v] * tmp[v * 8 + x] * COS[y * 8 + v];
      const gt = Math.round(s / 2) + 128;
      ra[y * 8 + x] = gt < 0 ? 0 : gt > 255 ? 255 : gt;
    }
  }
}

/** ── GIẢI MÃ ─────────────────────────────────────────────────────────────── */
function docJPEG(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8) {
    return { ok: false, error: 'KHÔNG_PHẢI_TỆP_JPEG' };
  }
  let p = 2;
  const qt = {};
  const huffDC = {};
  const huffAC = {};
  let frame = null;
  let resetInterval = 0;

  while (p < buf.length - 1) {
    if (buf[p] !== 0xff) { p++; continue; }
    const marker = buf[p + 1];
    p += 2;
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
    if (marker === 0xd9) break;
    if (p + 2 > buf.length) break;
    const len = buf.readUInt16BE(p);
    const than = buf.subarray(p + 2, p + len);

    if (marker === 0xdb) {                                   // DQT
      let q = 0;
      while (q < than.length) {
        const pq = than[q] >> 4; const tq = than[q] & 15; q++;
        const bang = new Int32Array(64);
        for (let i = 0; i < 64; i++) { bang[ZIGZAG[i]] = pq ? than.readUInt16BE(q + i * 2) : than[q + i]; }
        q += pq ? 128 : 64;
        qt[tq] = bang;
      }
    } else if (marker === 0xc4) {                            // DHT
      let q = 0;
      while (q < than.length) {
        const tc = than[q] >> 4; const th = than[q] & 15; q++;
        const bits = [0];
        let tong = 0;
        for (let i = 1; i <= 16; i++) { bits.push(than[q + i - 1]); tong += than[q + i - 1]; }
        q += 16;
        const vals = [];
        for (let i = 0; i < tong; i++) vals.push(than[q + i]);
        q += tong;
        const b = dungBangHuff(bits, vals);
        if (tc === 0) huffDC[th] = b; else huffAC[th] = b;
      }
    } else if (marker === 0xc0 || marker === 0xc1) {         // SOF0/SOF1 — baseline
      const cao = than.readUInt16BE(1);
      const rong = than.readUInt16BE(3);
      const soTP = than[5];
      const tp = [];
      for (let i = 0; i < soTP; i++) {
        const o = 6 + i * 3;
        tp.push({ id: than[o], h: than[o + 1] >> 4, v: than[o + 1] & 15, tq: than[o + 2] });
      }
      frame = { rong, cao, tp };
    } else if (marker === 0xc2) {
      return { ok: false, error: 'CHƯA_HỖ_TRỢ_JPEG_LŨY_TIẾN', goi: 'Yêu cầu nhà cung cấp trả JPEG baseline hoặc PNG.' };
    } else if (marker === 0xdd) {                            // DRI
      resetInterval = than.readUInt16BE(0);
    } else if (marker === 0xda) {                            // SOS
      if (!frame) return { ok: false, error: 'JPEG_THIẾU_KHUNG_SOF' };
      const soTP = than[0];
      const chon = [];
      for (let i = 0; i < soTP; i++) {
        const cs = than[1 + i * 2];
        const td = than[2 + i * 2] >> 4;
        const ta = than[2 + i * 2] & 15;
        const c = frame.tp.find((x) => x.id === cs);
        if (!c) return { ok: false, error: 'JPEG_SOS_TRỎ_THÀNH_PHẦN_LẠ' };
        chon.push({ ...c, td, ta });
      }
      return _giaiMaQuet(buf, p + len, frame, chon, qt, huffDC, huffAC, resetInterval);
    }
    p += len;
  }
  return { ok: false, error: 'JPEG_KHÔNG_CÓ_DỮ_LIỆU_QUÉT' };
}

function _giaiMaQuet(buf, batDau, frame, tp, qt, huffDC, huffAC, resetInterval) {
  const hMax = Math.max(...tp.map((c) => c.h));
  const vMax = Math.max(...tp.map((c) => c.v));
  const mcuW = hMax * 8;
  const mcuH = vMax * 8;
  const mcuX = Math.ceil(frame.rong / mcuW);
  const mcuY = Math.ceil(frame.cao / mcuH);

  for (const c of tp) {
    c.rong = mcuX * c.h * 8;
    c.cao = mcuY * c.v * 8;
    c.px = new Uint8Array(c.rong * c.cao);
    c.dcTruoc = 0;
  }

  // Bộ đọc bit: JPEG nhồi 0x00 sau mỗi 0xFF trong dòng dữ liệu.
  let bp = batDau;
  let bit = 0;
  let byte = 0;
  const docBit = () => {
    if (bit === 0) {
      if (bp >= buf.length) return 0;
      byte = buf[bp++];
      if (byte === 0xff) {
        const kt = buf[bp];
        if (kt === 0x00) bp++;
        else if (kt >= 0xd0 && kt <= 0xd7) { bp++; byte = buf[bp++] ?? 0; }
        else return -1;
      }
      bit = 8;
    }
    bit--;
    return (byte >> bit) & 1;
  };
  const docHuff = (bang) => {
    let code = 0;
    for (let len = 1; len <= 16; len++) {
      const b = docBit();
      if (b < 0) return -1;
      code = (code << 1) | b;
      const v = bang.tra.get(`${len}:${code}`);
      if (v !== undefined) return v;
    }
    return -1;
  };
  const docSo = (n) => {
    if (n === 0) return 0;
    let v = 0;
    for (let i = 0; i < n; i++) { const b = docBit(); if (b < 0) return 0; v = (v << 1) | b; }
    return v < (1 << (n - 1)) ? v - (1 << n) + 1 : v;
  };

  const khoiHS = new Int32Array(64);
  const raKhoi = new Uint8Array(64);
  let mcuDem = 0;

  for (let my = 0; my < mcuY; my++) {
    for (let mx = 0; mx < mcuX; mx++) {
      if (resetInterval && mcuDem > 0 && mcuDem % resetInterval === 0) {
        bit = 0;
        while (bp < buf.length - 1 && !(buf[bp] === 0xff && buf[bp + 1] >= 0xd0 && buf[bp + 1] <= 0xd7)) bp++;
        if (bp < buf.length - 1) bp += 2;
        for (const c of tp) c.dcTruoc = 0;
      }
      mcuDem++;

      for (const c of tp) {
        for (let by = 0; by < c.v; by++) {
          for (let bx = 0; bx < c.h; bx++) {
            khoiHS.fill(0);
            const t = docHuff(huffDC[c.td]);
            if (t < 0) { my = mcuY; mx = mcuX; break; }
            c.dcTruoc += docSo(t);
            khoiHS[0] = c.dcTruoc * qt[c.tq][0];
            let k = 1;
            while (k < 64) {
              const rs = docHuff(huffAC[c.ta]);
              if (rs < 0) break;
              const r = rs >> 4; const s = rs & 15;
              if (s === 0) { if (r === 15) { k += 16; continue; } break; }
              k += r;
              if (k > 63) break;
              khoiHS[ZIGZAG[k]] = docSo(s) * qt[c.tq][ZIGZAG[k]];
              k++;
            }
            idct8x8(khoiHS, raKhoi);
            const ox = (mx * c.h + bx) * 8;
            const oy = (my * c.v + by) * 8;
            for (let y = 0; y < 8; y++) {
              const d = (oy + y) * c.rong + ox;
              for (let x = 0; x < 8; x++) c.px[d + x] = raKhoi[y * 8 + x];
            }
          }
        }
      }
    }
  }

  // Nội suy màu + quy YCbCr về RGB
  const { rong, cao } = frame;
  const data = Buffer.alloc(rong * cao * 4);
  const lay = (c, x, y) => {
    const sx = Math.min(c.rong - 1, (x * c.h / hMax) | 0);
    const sy = Math.min(c.cao - 1, (y * c.v / vMax) | 0);
    return c.px[sy * c.rong + sx];
  };
  const kep = (v) => (v < 0 ? 0 : v > 255 ? 255 : v | 0);

  for (let y = 0; y < cao; y++) {
    for (let x = 0; x < rong; x++) {
      const i = (y * rong + x) * 4;
      if (tp.length === 1) {
        const g = lay(tp[0], x, y);
        data[i] = g; data[i + 1] = g; data[i + 2] = g;
      } else {
        const Y = lay(tp[0], x, y);
        const Cb = lay(tp[1], x, y) - 128;
        const Cr = lay(tp[2], x, y) - 128;
        data[i] = kep(Y + 1.402 * Cr + 0.5);
        data[i + 1] = kep(Y - 0.344136 * Cb - 0.714136 * Cr + 0.5);
        data[i + 2] = kep(Y + 1.772 * Cb + 0.5);
      }
      data[i + 3] = 255;
    }
  }
  return { ok: true, width: rong, height: cao, data, thanhPhan: tp.length, layMauMau: `${hMax}x${vMax}` };
}

/** ── MÃ HOÁ ──────────────────────────────────────────────────────────────── */
function _bangQ(chatLuong) {
  const q = Math.max(1, Math.min(100, chatLuong));
  const scale = q < 50 ? 5000 / q : 200 - q * 2;
  const lam = (goc) => {
    const ra = new Int32Array(64);
    for (let i = 0; i < 64; i++) ra[i] = Math.max(1, Math.min(255, Math.floor((goc[i] * scale + 50) / 100)));
    return ra;
  };
  return { sang: lam(Q_SANG), mau: lam(Q_MAU) };
}

/** DCT thuận 8×8, cũng tách hai trục và dùng chung bảng cô-sin. */
function fdct8x8(vao, ra) {
  const tmp = new Float32Array(64);
  for (let y = 0; y < 8; y++) {
    for (let v = 0; v < 8; v++) {
      let s = 0;
      for (let x = 0; x < 8; x++) s += (vao[y * 8 + x] - 128) * COS[x * 8 + v];
      tmp[y * 8 + v] = s;
    }
  }
  for (let v = 0; v < 8; v++) {
    for (let u = 0; u < 8; u++) {
      let s = 0;
      for (let y = 0; y < 8; y++) s += tmp[y * 8 + v] * COS[y * 8 + u];
      ra[u * 8 + v] = (HE_SO[u] * HE_SO[v] * s) / 4;
    }
  }
}

class BoGhiBit {
  constructor() { this.bytes = []; this.dem = 0; this.giu = 0; }
  ghi(ma, dai) {
    for (let i = dai - 1; i >= 0; i--) {
      this.giu = (this.giu << 1) | ((ma >> i) & 1);
      this.dem++;
      if (this.dem === 8) {
        this.bytes.push(this.giu & 0xff);
        if ((this.giu & 0xff) === 0xff) this.bytes.push(0x00);   // nhồi byte
        this.dem = 0; this.giu = 0;
      }
    }
  }
  ketThuc() { while (this.dem) this.ghi(1, 1); return Buffer.from(this.bytes); }
}

function _maHuff(bang) {
  const ra = new Map();
  let code = 0;
  let k = 0;
  for (let len = 1; len <= 16; len++) {
    for (let i = 0; i < bang.bits[len]; i++) { ra.set(bang.vals[k++], { code, len }); code++; }
    code <<= 1;
  }
  return ra;
}

function _hang(v) {
  let a = Math.abs(v);
  let n = 0;
  while (a) { n++; a >>= 1; }
  return n;
}

/**
 * Ghi ảnh RGBA thành JPEG baseline 4:4:4.
 * Không lấy mẫu màu thưa: ảnh đã qua chỉnh màu mà còn giảm độ phân giải màu
 * thì viền màu bị nhoè, uổng cả chuỗi xử lý phía trước.
 */
function ghiJPEG(anh, { chatLuong = 92 } = {}) {
  const { width: W, height: H, data } = anh;
  const q = _bangQ(chatLuong);
  const dcS = _maHuff(HUFF.dcSang); const acS = _maHuff(HUFF.acSang);
  const dcC = _maHuff(HUFF.dcMau); const acC = _maHuff(HUFF.acMau);

  const dau = [];
  dau.push(Buffer.from([0xff, 0xd8]));                        // SOI
  const jfif = Buffer.from([0x4a, 0x46, 0x49, 0x46, 0x00, 1, 1, 0, 0, 1, 0, 1, 0, 0]);
  dau.push(Buffer.concat([Buffer.from([0xff, 0xe0]), _u16(jfif.length + 2), jfif]));

  const dqt = [];
  for (const [id, bang] of [[0, q.sang], [1, q.mau]]) {
    const b = Buffer.alloc(65);
    b[0] = id;
    for (let i = 0; i < 64; i++) b[1 + i] = bang[ZIGZAG[i]];
    dqt.push(b);
  }
  dau.push(Buffer.concat([Buffer.from([0xff, 0xdb]), _u16(dqt[0].length + dqt[1].length + 2), dqt[0], dqt[1]]));

  const sof = Buffer.alloc(15);
  sof[0] = 8; sof.writeUInt16BE(H, 1); sof.writeUInt16BE(W, 3); sof[5] = 3;
  sof[6] = 1; sof[7] = 0x11; sof[8] = 0;
  sof[9] = 2; sof[10] = 0x11; sof[11] = 1;
  sof[12] = 3; sof[13] = 0x11; sof[14] = 1;
  dau.push(Buffer.concat([Buffer.from([0xff, 0xc0]), _u16(sof.length + 2), sof]));

  const dht = [];
  for (const [tc, th, b] of [[0, 0, HUFF.dcSang], [1, 0, HUFF.acSang], [0, 1, HUFF.dcMau], [1, 1, HUFF.acMau]]) {
    const t = Buffer.alloc(17 + b.vals.length);
    t[0] = (tc << 4) | th;
    for (let i = 1; i <= 16; i++) t[i] = b.bits[i];
    Buffer.from(b.vals).copy(t, 17);
    dht.push(t);
  }
  const dhtThan = Buffer.concat(dht);
  dau.push(Buffer.concat([Buffer.from([0xff, 0xc4]), _u16(dhtThan.length + 2), dhtThan]));

  const sos = Buffer.from([3, 1, 0x00, 2, 0x11, 3, 0x11, 0, 63, 0]);
  dau.push(Buffer.concat([Buffer.from([0xff, 0xda]), _u16(sos.length + 2), sos]));

  // Quét: 4:4:4, mỗi MCU là một khối 8×8 cho mỗi kênh
  const bw = new BoGhiBit();
  const Ykhoi = new Float32Array(64); const Cbkhoi = new Float32Array(64); const Crkhoi = new Float32Array(64);
  const hs = new Float32Array(64);
  const dcTruoc = [0, 0, 0];

  for (let by = 0; by < Math.ceil(H / 8); by++) {
    for (let bx = 0; bx < Math.ceil(W / 8); bx++) {
      for (let y = 0; y < 8; y++) {
        const sy = Math.min(H - 1, by * 8 + y);
        for (let x = 0; x < 8; x++) {
          const sx = Math.min(W - 1, bx * 8 + x);
          const i = (sy * W + sx) * 4;
          const r = data[i]; const g = data[i + 1]; const b = data[i + 2];
          Ykhoi[y * 8 + x] = 0.299 * r + 0.587 * g + 0.114 * b;
          Cbkhoi[y * 8 + x] = -0.168736 * r - 0.331264 * g + 0.5 * b + 128;
          Crkhoi[y * 8 + x] = 0.5 * r - 0.418688 * g - 0.081312 * b + 128;
        }
      }
      for (const [idx, khoiNguon, bangQ, dcT, acT] of [
        [0, Ykhoi, q.sang, dcS, acS], [1, Cbkhoi, q.mau, dcC, acC], [2, Crkhoi, q.mau, dcC, acC],
      ]) {
        fdct8x8(khoiNguon, hs);
        const zz = new Int32Array(64);
        for (let i = 0; i < 64; i++) zz[i] = Math.round(hs[ZIGZAG[i]] / bangQ[ZIGZAG[i]]);
        const dc = zz[0] - dcTruoc[idx];
        dcTruoc[idx] = zz[0];
        const sDC = _hang(dc);
        const mDC = dcT.get(sDC);
        bw.ghi(mDC.code, mDC.len);
        if (sDC) bw.ghi(dc < 0 ? dc + (1 << sDC) - 1 : dc, sDC);

        let run = 0;
        for (let k = 1; k < 64; k++) {
          if (zz[k] === 0) { run++; continue; }
          while (run > 15) { const m = acT.get(0xf0); bw.ghi(m.code, m.len); run -= 16; }
          const s = _hang(zz[k]);
          const m = acT.get((run << 4) | s);
          bw.ghi(m.code, m.len);
          bw.ghi(zz[k] < 0 ? zz[k] + (1 << s) - 1 : zz[k], s);
          run = 0;
        }
        if (run > 0) { const m = acT.get(0x00); bw.ghi(m.code, m.len); }
      }
    }
  }

  return Buffer.concat([...dau, bw.ketThuc(), Buffer.from([0xff, 0xd9])]);
}

function _u16(n) { const b = Buffer.alloc(2); b.writeUInt16BE(n, 0); return b; }

module.exports = { docJPEG, ghiJPEG, ZIGZAG, Q_SANG, Q_MAU };
