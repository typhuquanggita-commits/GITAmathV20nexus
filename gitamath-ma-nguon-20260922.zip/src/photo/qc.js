'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SOÁT CHẤT LƯỢNG ẢNH — chấm bằng số đo trên chính điểm ảnh
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế chấm điểm bằng ba con số lấy từ `signalstats` của ffmpeg và
 *  cộng thành 100. Thiếu hai thứ quan trọng nhất: ĐỘ NÉT (ảnh mờ vẫn đạt
 *  điểm tối đa) và CHÁY SÁNG (vùng trắng mất chi tiết không bị phát hiện).
 *
 *  Ở đây bảy phép đo, mỗi phép có ngưỡng nói rõ vì sao, và mỗi lỗi kèm cách
 *  sửa bằng đúng tham số của tầng hậu kỳ — không phải lời khuyên chung chung.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { doAnh, chinhMau, apDuongTong } = require('./image');
const { round, clamp } = require('../utils');

/**
 * Chất màu mà hồ sơ máy ảnh + giả lập phim CỐ Ý tạo ra, đo trên một mảng
 * xám 18% — tấm xám chuẩn của nhiếp ảnh. Đây là mốc để chấm cân bằng trắng:
 * lệch so với chủ ý mới là lỗi, lệch so với trung tính thì không.
 */
function lechDuKien(mayAnh, phim) {
  const { layMayAnh, layPhim, duongPhim } = require('./profiles');
  const n = 16;
  const xam = { width: n, height: n, data: Buffer.alloc(n * n * 4) };
  for (let i = 0; i < xam.data.length; i += 4) {
    xam.data[i] = 118; xam.data[i + 1] = 118; xam.data[i + 2] = 118; xam.data[i + 3] = 255;
  }
  const ma = layMayAnh(mayAnh);
  let a = Object.keys(ma.mau || {}).length ? chinhMau(xam, ma.mau) : xam;
  const ph = layPhim(phim);
  if (ph.diem) {
    a = apDuongTong(a, duongPhim(phim));
    if (ph.baoHoaThem !== undefined && ph.baoHoaThem !== 1) a = chinhMau(a, { baoHoa: ph.baoHoaThem });
  }
  return round(doAnh(a).canBangTrang.lechRB, 1);
}

/** Bảy trục chấm. Trọng số cộng lại bằng 100. */
const TRUC = [
  {
    id: 'phoiSang', ten: 'Phơi sáng', trong: 18,
    do: (m) => m.doSang,
    cham: (v) => (v >= 95 && v <= 155 ? 1 : v >= 75 && v <= 180 ? 0.6 : v >= 55 && v <= 205 ? 0.3 : 0),
    dat: '95–155 (trên thang 0–255)',
    sua: (v) => (v < 95 ? `Ảnh tối (${v}). Tăng doSang khoảng +${round((118 - v) / 255, 3)}.`
      : `Ảnh sáng quá (${v}). Giảm doSang khoảng ${round((118 - v) / 255, 3)}.`),
  },
  {
    id: 'tuongPhan', ten: 'Tương phản', trong: 16,
    do: (m) => m.doLechChuan,
    cham: (v) => (v >= 45 ? 1 : v >= 32 ? 0.7 : v >= 22 ? 0.4 : 0.1),
    dat: 'độ lệch chuẩn ≥ 45',
    sua: (v) => `Ảnh bẹt (lệch chuẩn ${v}). Tăng tuongPhan lên ${round(1 + (48 - v) / 100, 2)}.`,
  },
  {
    id: 'daiTong', ten: 'Dải tông', trong: 12,
    do: (m) => m.dai,
    cham: (v) => (v >= 200 ? 1 : v >= 160 ? 0.7 : v >= 120 ? 0.4 : 0.1),
    dat: 'khoảng cách phân vị 1%–99% ≥ 200',
    sua: (v) => `Dải tông hẹp (${v}/255) — ảnh thiếu cả đen sâu lẫn trắng sạch.`,
  },
  {
    id: 'doNet', ten: 'Độ nét', trong: 22,
    do: (m) => m.doNet,
    cham: (v) => (v >= 120 ? 1 : v >= 60 ? 0.75 : v >= 25 ? 0.45 : v >= 8 ? 0.2 : 0),
    dat: 'phương sai Laplace ≥ 120',
    sua: (v) => `Ảnh mềm (phương sai Laplace ${v}). Tăng lamSac.cuongDo, hoặc phóng to bằng Lanczos rồi làm sắc lại.`,
  },
  {
    id: 'chaySang', ten: 'Cháy sáng', trong: 12,
    do: (m) => m.chaySang,
    cham: (v) => (v <= 0.5 ? 1 : v <= 2 ? 0.6 : v <= 5 ? 0.25 : 0),
    dat: '≤ 0,5% số điểm ảnh chạm trắng',
    sua: (v) => `${v}% điểm ảnh cháy trắng, mất hẳn chi tiết. Giảm doSang hoặc giảm tuongPhan.`,
  },
  {
    id: 'bepToi', ten: 'Bẹp tối', trong: 10,
    do: (m) => m.bepToi,
    cham: (v) => (v <= 0.5 ? 1 : v <= 2 ? 0.6 : v <= 5 ? 0.25 : 0),
    dat: '≤ 0,5% số điểm ảnh chạm đen',
    sua: (v) => `${v}% điểm ảnh đen tuyệt đối. Nâng vai tối bằng đường tông giả lập phim.`,
  },
  {
    id: 'canBangTrang', ten: 'Cân bằng trắng', trong: 10,
    // Đo LỆCH SO VỚI CHỦ Ý, không phải lệch so với trung tính. Hồ sơ Fujifilm
    // cố tình ngả ấm; chấm nó là "sai cân bằng trắng" thì chính tầng chất màu
    // bị trừ điểm vì đã làm đúng việc của nó.
    do: (m, ctx) => round(Math.abs(m.canBangTrang.lechRB - (ctx.mucTieuRB || 0)), 1),
    cham: (v) => (v <= 12 ? 1 : v <= 25 ? 0.65 : v <= 45 ? 0.3 : 0),
    dat: 'lệch đỏ–lam so với chủ ý của hồ sơ ≤ 12',
    sua: (v, ctx) => `Lệch ${v} mức so với chất màu dự kiến`
      + `${ctx.mucTieuRB ? ` (hồ sơ nhắm R−B ≈ ${ctx.mucTieuRB})` : ''}. Chỉnh kelvin, hoặc kiểm lại nguồn sáng khi chụp.`,
  },
];

/**
 * @param {object} anh ảnh RGBA
 * @param {object} o {muc: 'chan-dung'|... , megapixelMucTieu}
 */
function soat(anh, { canhMucTieu = null, mucTieuRB = null, mayAnh = null, phim = null } = {}) {
  if (mucTieuRB == null && mayAnh) mucTieuRB = lechDuKien(mayAnh, phim || 'Khong');
  const m = doAnh(anh);
  const chiTiet = [];
  const loi = [];
  let diem = 0;

  const ctx = { mucTieuRB: mucTieuRB ?? 0 };
  for (const t of TRUC) {
    const v = t.do(m, ctx);
    const he = t.cham(v);
    const d = round(t.trong * he, 1);
    diem += d;
    chiTiet.push({ id: t.id, ten: t.ten, giaTri: v, chuan: t.dat, diem: d, toiDa: t.trong, dat: he >= 0.75 });
    if (he < 0.75) {
      loi.push({
        truc: t.id, ten: t.ten, giaTri: v, chuan: t.dat,
        muc: he < 0.35 ? 'NẶNG' : 'NHẸ',
        sua: t.sua(v, ctx),
      });
    }
  }

  // Độ phân giải chấm theo CẠNH DÀI, không theo megapixel: một tấm 3:2 và
  // một tấm vuông cùng cạnh dài thì lệch nhau gần 30% megapixel, nên lấy
  // megapixel làm chuẩn sẽ đánh trượt oan mọi tấm không vuông.
  if (canhMucTieu) {
    const canhDai = Math.max(m.rong, m.cao);
    if (canhDai < canhMucTieu * 0.95) {
      loi.push({
        truc: 'doPhanGiai', ten: 'Độ phân giải', giaTri: canhDai, chuan: `cạnh dài ≥ ${canhMucTieu}px`,
        muc: 'NẶNG',
        sua: `Cạnh dài mới ${canhDai}px (${m.megapixel}MP), chưa đạt ${canhMucTieu}px. Tăng mức chất lượng hoặc số lần phóng to.`,
      });
    }
  }

  diem = round(clamp(diem, 0, 100), 1);
  const nang = loi.filter((x) => x.muc === 'NẶNG').length;
  return {
    ok: nang === 0,
    diem,
    xep: diem >= 88 ? 'TỐT' : diem >= 72 ? 'DÙNG ĐƯỢC' : diem >= 55 ? 'CẦN SỬA' : 'PHẢI SỬA',
    doDuoc: m,
    chiTiet,
    loi,
    nang,
    nhe: loi.length - nang,
    ketLuan: nang === 0
      ? (loi.length ? `Dùng được, còn ${loi.length} điểm nên chỉnh.` : 'Đạt cả bảy phép đo.')
      : `Còn ${nang} lỗi nặng — xem cột "sửa" để biết chỉnh tham số nào.`,
  };
}

/** So hai ảnh trước và sau hậu kỳ — để thấy hậu kỳ làm được gì, bằng số. */
function soSanh(truoc, sau, ctx = {}) {
  // Ảnh TRƯỚC hậu kỳ chưa mang chất màu nào, nên chấm nó ở mốc trung tính;
  // ảnh SAU mới chấm theo chủ ý của hồ sơ. So sai mốc là so nhầm.
  const a = soat(truoc);
  const b = soat(sau, ctx);
  const bang = a.chiTiet.map((x, i) => ({
    truc: x.ten, truoc: x.giaTri, sau: b.chiTiet[i].giaTri,
    diemTruoc: x.diem, diemSau: b.chiTiet[i].diem,
    doi: round(b.chiTiet[i].diem - x.diem, 1),
  }));
  return { diemTruoc: a.diem, diemSau: b.diem, doi: round(b.diem - a.diem, 1), bang };
}

module.exports = { soat, soSanh, lechDuKien, TRUC };
