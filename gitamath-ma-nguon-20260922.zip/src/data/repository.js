'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LƯU TRỮ BỀN VỮNG — dữ liệu sống sót qua tắt máy, không cần hạ tầng ngoài
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mô hình: ảnh chụp nén + nhật ký ghi trước (write-ahead log).
 *
 *    <tên>.snap.json   toàn bộ bộ sưu tập tại một thời điểm
 *    <tên>.log         từng thay đổi sau ảnh chụp, mỗi dòng một JSON
 *
 *  Mở lên: nạp ảnh chụp → phát lại nhật ký → có trạng thái đúng tới thay đổi
 *  cuối cùng đã ghi xuống đĩa. Dòng cuối bị cụt do mất điện giữa chừng sẽ bị
 *  bỏ qua chứ không làm hỏng cả tệp — đó là lý do dùng một-dòng-một-bản-ghi.
 *
 *  Ghi nguyên tử: luôn ghi ra tệp tạm rồi đổi tên đè lên. Đổi tên là thao tác
 *  nguyên tử của hệ tệp, nên không bao giờ tồn tại tệp ảnh chụp ghi dở.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');
const L = require('../logger');

const OP = { PUT: 'p', DEL: 'd' };

class Repository {
  /**
   * @param {object} o
   * @param {string} o.name        tên bộ sưu tập (learners, items, users, …)
   * @param {string} o.dir         thư mục lưu
   * @param {string} o.idField     tên trường khoá chính
   * @param {string[]} o.indexes   các trường cần tra cứu nhanh
   * @param {number} o.compactEvery  bao nhiêu thay đổi thì gộp nhật ký vào ảnh chụp
   * @param {boolean} o.sync       fsync sau mỗi lần ghi (chậm hơn, an toàn tuyệt đối)
   */
  constructor({ name, dir, idField = 'id', indexes = [], compactEvery = 500, sync = false, autoLoad = true }) {
    if (!name || !/^[a-z0-9_-]+$/i.test(name)) throw new Error(`Tên bộ sưu tập không hợp lệ: ${name}`);
    this.name = name;
    this.dir = dir;
    this.idField = idField;
    this.compactEvery = compactEvery;
    this.sync = sync;

    this.docs = new Map();                 // id -> document
    this.indexes = new Map();              // field -> Map(value -> Set(id))
    for (const f of indexes) this.indexes.set(f, new Map());

    this.snapFile = path.join(dir, `${name}.snap.json`);
    this.logFile = path.join(dir, `${name}.log`);
    this.stats = { loaded: 0, replayed: 0, writes: 0, deletes: 0, compactions: 0, corruptLines: 0, diskErrors: 0 };
    this._pending = 0;
    this._logFd = null;

    if (autoLoad) this.load();
  }

  // ── Nạp từ đĩa ────────────────────────────────────────────────────────────

  load() {
    this.docs.clear();
    for (const m of this.indexes.values()) m.clear();

    // 1) Ảnh chụp
    if (fs.existsSync(this.snapFile)) {
      try {
        const snap = JSON.parse(fs.readFileSync(this.snapFile, 'utf8'));
        for (const d of snap.docs || []) this._indexPut(d);
        this.stats.loaded = this.docs.size;
      } catch (e) {
        L.warn(`Repo ${this.name}: ảnh chụp hỏng (${e.message}) — thử khôi phục từ nhật ký`);
      }
    }

    // 2) Phát lại nhật ký
    if (fs.existsSync(this.logFile)) {
      const raw = fs.readFileSync(this.logFile, 'utf8');
      for (const line of raw.split('\n')) {
        if (!line.trim()) continue;
        let rec;
        try { rec = JSON.parse(line); } catch { this.stats.corruptLines++; continue; } // dòng cụt vì mất điện
        if (rec.o === OP.PUT && rec.d) { this._indexPut(rec.d); this.stats.replayed++; }
        else if (rec.o === OP.DEL && rec.i != null) { this._indexDel(rec.i); this.stats.replayed++; }
      }
    }
    return this;
  }

  // ── Chỉ mục trong bộ nhớ ─────────────────────────────────────────────────

  _indexPut(doc) {
    const id = doc[this.idField];
    if (id == null) return;
    const old = this.docs.get(id);
    if (old) this._unindex(old);
    this.docs.set(id, doc);
    for (const [field, map] of this.indexes) {
      const v = this._keyOf(doc[field]);
      if (v === undefined) continue;
      if (!map.has(v)) map.set(v, new Set());
      map.get(v).add(id);
    }
  }

  _unindex(doc) {
    const id = doc[this.idField];
    for (const [field, map] of this.indexes) {
      const v = this._keyOf(doc[field]);
      const set = map.get(v);
      if (set) { set.delete(id); if (!set.size) map.delete(v); }
    }
  }

  _indexDel(id) {
    const d = this.docs.get(id);
    if (!d) return false;
    this._unindex(d);
    return this.docs.delete(id);
  }

  _keyOf(v) {
    if (v === undefined || v === null) return undefined;
    return typeof v === 'object' ? JSON.stringify(v) : String(v);
  }

  // ── Ghi xuống đĩa ────────────────────────────────────────────────────────

  _ensureDir() {
    try { fs.mkdirSync(this.dir, { recursive: true }); return true; }
    catch (e) { this.stats.diskErrors++; L.warn(`Repo ${this.name}: không tạo được ${this.dir}`, e.message); return false; }
  }

  _append(rec) {
    if (!this._ensureDir()) return;
    try {
      if (this._logFd === null) this._logFd = fs.openSync(this.logFile, 'a');
      fs.writeSync(this._logFd, JSON.stringify(rec) + '\n');
      if (this.sync) fs.fsyncSync(this._logFd);
      this._pending++;
      if (this._pending >= this.compactEvery) this.compact();
    } catch (e) {
      this.stats.diskErrors++;
      L.warn(`Repo ${this.name}: ghi nhật ký thất bại`, e.message);
    }
  }

  /**
   * Gộp nhật ký vào ảnh chụp rồi xoá nhật ký.
   *
   * THỨ TỰ Ở ĐÂY LÀ THỨ TỰ CHỐNG MẤT DỮ LIỆU, không được đổi cho gọn.
   *
   * Bản trước làm: ghi tệp tạm → đổi tên → XOÁ NHẬT KÝ. Đổi tên đúng là thao
   * tác nguyên tử, nhưng nó chỉ nguyên tử về TÊN. Nội dung tệp tạm lúc ấy vẫn
   * còn nằm trong bộ đệm của hệ điều hành. Mất điện ngay sau lệnh đổi tên thì
   * ảnh chụp mới có tên đúng mà ruột rỗng, trong khi nhật ký — bản sao duy
   * nhất còn lại — đã bị xoá. Kết quả: mất trắng cả bảng, không cách nào dựng
   * lại. Cửa sổ ấy nhỏ, nhưng mất dữ liệu khách hàng thì nhỏ hay lớn cũng thế.
   *
   * Thứ tự đúng, năm bước:
   *   1. ghi tệp tạm
   *   2. fsync TỆP TẠM        — ruột đã nằm trên đĩa
   *   3. đổi tên              — nguyên tử
   *   4. fsync THƯ MỤC        — cái tên mới cũng đã nằm trên đĩa
   *   5. chỉ tới lúc này mới được xoá nhật ký
   */
  compact() {
    if (!this._ensureDir()) return { ok: false };
    const tmp = `${this.snapFile}.tmp`;
    let fd = null;
    try {
      const body = JSON.stringify({
        name: this.name, at: Date.now(), count: this.docs.size, docs: [...this.docs.values()],
      });
      // 1 + 2: ghi rồi ép xuống đĩa trước khi đổi tên.
      fd = fs.openSync(tmp, 'w');
      fs.writeFileSync(fd, body);
      fs.fsyncSync(fd);
      fs.closeSync(fd);
      fd = null;
      // 3: đổi tên — nguyên tử.
      fs.renameSync(tmp, this.snapFile);
      // 4: ép cả THƯ MỤC xuống đĩa, để cái tên mới cũng bền.
      this._fsyncDir();
      // 5: tới đây ảnh chụp mới thật sự an toàn, mới được bỏ nhật ký.
      if (this._logFd !== null) { fs.closeSync(this._logFd); this._logFd = null; }
      fs.writeFileSync(this.logFile, '');
      this._pending = 0;
      this.stats.compactions++;
      return { ok: true, docs: this.docs.size, bytes: Buffer.byteLength(body) };
    } catch (e) {
      this.stats.diskErrors++;
      if (fd !== null) { try { fs.closeSync(fd); } catch { /* đã đóng */ } }
      // Gộp hỏng thì GIỮ NGUYÊN nhật ký. Nhật ký còn thì dựng lại được.
      try { fs.existsSync(tmp) && fs.unlinkSync(tmp); } catch { /* dọn được thì dọn */ }
      L.warn(`Repo ${this.name}: gộp nhật ký thất bại`, e.message);
      return { ok: false, error: e.message };
    }
  }

  /**
   * Ép thư mục xuống đĩa. Trên Linux đây là bước bắt buộc sau khi đổi tên:
   * thiếu nó thì cái tên mới có thể chưa bền dù ruột tệp đã bền.
   * Một số hệ tệp không cho fsync thư mục — lúc đó bỏ qua, không làm đổ việc.
   */
  _fsyncDir() {
    let dfd = null;
    try { dfd = fs.openSync(this.dir, 'r'); fs.fsyncSync(dfd); }
    catch { /* hệ tệp không hỗ trợ thì thôi */ }
    finally { if (dfd !== null) { try { fs.closeSync(dfd); } catch { /* đã đóng */ } } }
  }

  // ── API đọc ghi ──────────────────────────────────────────────────────────

  put(doc) {
    const id = doc?.[this.idField];
    if (id == null || id === '') return { ok: false, error: 'MISSING_ID', need: this.idField };
    const now = Date.now();
    const prev = this.docs.get(id);
    const rec = { ...doc, createdAt: prev?.createdAt ?? doc.createdAt ?? now, updatedAt: now };
    this._indexPut(rec);
    this._append({ o: OP.PUT, d: rec });
    this.stats.writes++;
    return { ok: true, id, created: !prev, doc: rec };
  }

  /** Cập nhật một phần; không có bản ghi thì báo lỗi chứ không âm thầm tạo mới. */
  patch(id, changes) {
    const cur = this.docs.get(id);
    if (!cur) return { ok: false, error: 'NOT_FOUND', id };
    return this.put({ ...cur, ...changes, [this.idField]: id });
  }

  get(id) { return this.docs.get(id) || null; }
  has(id) { return this.docs.has(id); }
  count() { return this.docs.size; }

  delete(id) {
    if (!this._indexDel(id)) return { ok: false, error: 'NOT_FOUND', id };
    this._append({ o: OP.DEL, i: id });
    this.stats.deletes++;
    return { ok: true, id };
  }

  /** Tra theo trường đã đánh chỉ mục — O(1), không quét toàn bộ. */
  by(field, value) {
    const map = this.indexes.get(field);
    if (!map) return this.filter((d) => this._keyOf(d[field]) === this._keyOf(value));
    const ids = map.get(this._keyOf(value));
    return ids ? [...ids].map((i) => this.docs.get(i)).filter(Boolean) : [];
  }

  filter(pred) { return [...this.docs.values()].filter(pred); }
  find(pred) { return [...this.docs.values()].find(pred) || null; }
  all() { return [...this.docs.values()]; }

  /** Trang dữ liệu có sắp xếp tất định — cùng đầu vào cho cùng thứ tự. */
  page({ offset = 0, limit = 50, sort = null, desc = false, where = null } = {}) {
    let arr = where ? this.filter(where) : [...this.docs.values()];
    const key = sort || this.idField;
    arr.sort((a, b) => {
      const x = a[key], y = b[key];
      if (x === y) return String(a[this.idField]).localeCompare(String(b[this.idField]));
      if (x === undefined || x === null) return 1;
      if (y === undefined || y === null) return -1;
      return (typeof x === 'number' && typeof y === 'number') ? x - y : String(x).localeCompare(String(y), 'vi');
    });
    if (desc) arr.reverse();
    return { total: arr.length, offset, limit, items: arr.slice(offset, offset + limit) };
  }

  clear() {
    this.docs.clear();
    for (const m of this.indexes.values()) m.clear();
    this.compact();
    return { ok: true };
  }

  flush() { return this.compact(); }

  close() {
    // Ép nhật ký xuống đĩa TRƯỚC khi gộp. Nếu gộp hỏng giữa chừng thì nhật ký
    // đã bền vẫn dựng lại được mọi thứ; không ép thì cả hai cùng mất.
    this.fsyncLog();
    this.compact();
    if (this._logFd !== null) { try { fs.closeSync(this._logFd); } catch { /* đã đóng */ } this._logFd = null; }
  }

  /** Ép nhật ký đang mở xuống đĩa. Gọi được bất cứ lúc nào, kể cả khi sync=false. */
  fsyncLog() {
    if (this._logFd === null) return { ok: true, boQua: 'nhật ký chưa mở' };
    try { fs.fsyncSync(this._logFd); return { ok: true }; }
    catch (e) { this.stats.diskErrors++; return { ok: false, error: e.message }; }
  }

  status() {
    return {
      name: this.name,
      docs: this.docs.size,
      indexes: [...this.indexes.keys()],
      pendingLog: this._pending,
      ...this.stats,
    };
  }
}

// ═══ Tập hợp các bộ sưu tập ═════════════════════════════════════════════════

class Database {
  constructor({ dir, sync = false } = {}) {
    this.dir = dir || path.join(__dirname, '..', '..', 'data', 'db');
    this.sync = sync;
    this.repos = new Map();
  }

  collection(name, opts = {}) {
    if (this.repos.has(name)) return this.repos.get(name);
    const r = new Repository({ name, dir: this.dir, sync: this.sync, ...opts });
    this.repos.set(name, r);
    return r;
  }

  /** Toàn bộ dữ liệu, dùng cho ảnh chụp hệ thống theo phiên bản. */
  export() {
    const out = {};
    for (const [name, r] of this.repos) out[name] = r.all();
    return out;
  }

  /** Nạp lại toàn bộ từ một ảnh chụp — dùng khi khôi phục hệ thống. */
  import(data) {
    let restored = 0;
    for (const [name, docs] of Object.entries(data || {})) {
      const r = this.repos.get(name);
      if (!r || !Array.isArray(docs)) continue;
      r.docs.clear();
      for (const m of r.indexes.values()) m.clear();
      for (const d of docs) { r._indexPut(d); restored++; }
      r.compact();
    }
    return { ok: true, collections: Object.keys(data || {}).length, docs: restored };
  }

  flushAll() {
    const out = {};
    for (const [name, r] of this.repos) out[name] = r.flush();
    return out;
  }

  close() { for (const r of this.repos.values()) r.close(); }

  /** Ép nhật ký của MỌI bộ sưu tập xuống đĩa. Dùng cho nhịp ép định kỳ. */
  fsyncAll() {
    const ra = {};
    for (const [ten, r] of this.repos) ra[ten] = r.fsyncLog();
    return ra;
  }

  status() {
    return {
      dir: this.dir,
      collections: this.repos.size,
      totalDocs: [...this.repos.values()].reduce((s, r) => s + r.count(), 0),
      byCollection: Object.fromEntries([...this.repos].map(([n, r]) => [n, r.count()])),
    };
  }
}

module.exports = { Repository, Database, OP };
