'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐỊNH TUYẾN MẶT TRONG — /nha
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mặt trong khác mặt ngoài ở chỗ nó CÓ TRẠNG THÁI và CÓ DANH TÍNH. Nên định
 *  tuyến ở đây phải làm ba việc mà trang công khai không phải làm:
 *
 *  1. ĐỌC DANH TÍNH TỪ PHIÊN ĐĂNG NHẬP, không đọc từ đường dẫn. Cho phép chỉ
 *     định người dùng qua đường dẫn nghĩa là ai cũng xem được nhà người khác.
 *  2. NHẬN BIỂU MẪU GỬI LÊN rồi chuyển hướng về trang xem. Nộp xong mà giữ
 *     nguyên phương thức gửi thì bấm nạp lại trang là nộp thêm lần nữa.
 *  3. TỪ CHỐI KHI SAI VAI, và lời từ chối không hé một chữ nào về nội dung
 *     bên trong phòng.
 *
 *  VAI TRONG NHÀ LẤY TỪ VAI TÀI KHOẢN.
 *  Hệ thống tài khoản đã có sẵn bốn vai. Ánh xạ thẳng sang vai trong nhà chứ
 *  không dựng bảng vai thứ hai — hai bảng vai song song là nguồn lệch quyền
 *  sớm muộn cũng xảy ra.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const NgoiNha = require('../nha/dong-bo');
const { PHONG_INDEX, VAI_INDEX } = require('../nha/ban-do');
const trang = require('./nha-trang');
const ks = require('../khao-sat/mat-trong-nha');

/** Vai tài khoản → vai trong nhà. Vai lạ thì không vào được, không đoán bừa. */
const VAI_THEO_TAI_KHOAN = {
  PARENT: 'phu-huynh',
  LEARNER: 'hoc-vien',
  TEACHER: 'giao-vien',
  ADMIN: 'co-van',
};

/** Đọc một cookie theo tên, không kéo thêm thư viện nào. */
function docCookie(header, ten) {
  if (!header) return null;
  for (const phan of String(header).split(';')) {
    const i = phan.indexOf('=');
    if (i < 0) continue;
    if (phan.slice(0, i).trim() === ten) return decodeURIComponent(phan.slice(i + 1).trim());
  }
  return null;
}

/**
 * Xác định người đang gõ cửa.
 * Không có phiên hợp lệ thì trả về null — và trang sẽ mời đăng nhập chứ không
 * dựng sẵn một nhà giả để xem cho có.
 */
function nguoiGoCua(N, req) {
  const cookie = docCookie(req && req.headers && req.headers.cookie, 'gita_token');
  const bearer = String((req && req.headers && req.headers.authorization) || '').replace(/^Bearer\s+/i, '');
  const token = cookie || bearer || null;
  if (!token || !N || !N.accounts || typeof N.accounts.session !== 'function') return null;
  const s = N.accounts.session(token);
  if (!s) return null;
  const vaiId = VAI_THEO_TAI_KHOAN[s.role];
  if (!vaiId || !VAI_INDEX.has(vaiId)) return null;
  const u = s.user || {};
  return {
    // Mỗi tài khoản là một nhà, trừ khi tổ chức khai rõ nhà chung. Ánh xạ
    // nhiều thành viên vào một nhà cần dữ liệu tổ chức, chưa có thì không bịa.
    nhaId: u.householdId || u.id,
    thanhVienId: u.id,
    vaiId,
    ten: u.fullName || u.username || u.id,
    vaiTen: (VAI_INDEX.get(vaiId) || {}).ten || vaiId,
    nhaTen: u.householdName || '',
    // Token phiên đi kèm để tính vé chống giả mạo biểu mẫu. Giữ ở đây chứ
    // KHÔNG đưa vào đối tượng `nguoi` truyền sang tầng dựng trang: tầng ấy
    // ghép chuỗi HTML, mà token phiên thì không bao giờ được lọt vào HTML.
    tokenPhien: token,
  };
}

/** Trang mời đăng nhập — không dựng dữ liệu giả để lấp chỗ trống. */
function trangMoiDangNhap(nonce) {
  return trang.trangChuaDung({
    tieuDe: 'Ngôi nhà thịnh vượng',
    duongDan: '/nha',
    canGi: [
      'Một phiên đăng nhập hợp lệ — ngôi nhà là chỗ riêng của từng gia đình.',
      'Tài khoản thuộc vai Phụ huynh hoặc Học viên để đi được các phòng.',
      'Tài khoản vai Giáo viên hoặc Cố vấn dùng để đồng hành, không đi thay.',
    ],
    nguoi: null,
    nonce,
  });
}

class MatTrongNha {
  constructor({ nexus = null, kho = null, nhatKy = null } = {}) {
    this.N = nexus;
    this.nha = new NgoiNha({ kho, nhatKy });
  }

  /** Nhận yêu cầu xem trang. Trả `{html}` hoặc null khi không phải đường của mình. */
  xemTrang(duongDan, truyVan, { req = null, nonce = null } = {}) {
    const d = String(duongDan || '').replace(/\/+$/, '') || '/nha';
    if (d !== '/nha' && !d.startsWith('/nha/')) return null;

    // Xét đường dẫn có thật hay không TRƯỚC khi xét danh tính. Làm ngược lại
    // thì mọi đường gõ sai đều trả trang mời đăng nhập với mã 200, và người
    // gõ nhầm tưởng mình vào đúng chỗ, còn nhật ký máy chủ thì mất dấu lỗi.
    // Danh sách phòng không phải bí mật — nó nằm ngay trên bản đồ; thứ phải
    // giấu là NỘI DUNG bên trong phòng, và thứ đó vẫn được giấu nguyên.
    const KHU_CO_DINH = ['/nha', '/nha/chang-duong', '/nha/ma-tran', '/nha/cay-gia-tri',
      '/nha/lo-trinh-ca-nhan', '/nha/khao-sat', '/nha/hom-nay', '/nha/nguoi-dong-hanh'];
    const laPhong = d.startsWith('/nha/') && PHONG_INDEX.has(d.slice('/nha/'.length));
    const boKhaoSat = d.startsWith('/nha/khao-sat/') ? d.slice('/nha/khao-sat/'.length) : null;
    const laKhaoSat = boKhaoSat != null && !!ks.BO[boKhaoSat];
    if (!KHU_CO_DINH.includes(d) && !laPhong && !laKhaoSat) return null;

    const ng = nguoiGoCua(this.N, req);
    if (!ng) return { html: trangMoiDangNhap(nonce) };
    // `ve` là thứ DUY NHẤT liên quan tới phiên được phép đi vào tầng dựng
    // trang. Nó là HMAC của token phiên, không lần ngược ra được token.
    const nguoi = {
      ten: ng.ten, vaiTen: ng.vaiTen, nhaTen: ng.nhaTen,
      ve: require('./chong-gia-mao').veCua(ng.tokenPhien),
    };

    if (d === '/nha') {
      const bd = this.nha.banDo(ng.nhaId, ng.thanhVienId, ng.vaiId);
      return { html: trang.trangBanDo(bd, nguoi, nonce) };
    }

    if (d === '/nha/chang-duong') {
      const bd = this.nha.banDo(ng.nhaId, ng.thanhVienId, ng.vaiId);
      const do_ = this.nha.dangODau(ng.nhaId, ng.thanhVienId);
      return { html: trang.trangChangDuong(bd, do_, nguoi, nonce) };
    }

    if (d === '/nha/ma-tran') {
      const maTran = require('../matran/ma-tran');
      const thanhTra = require('../matran/thanh-tra');
      // Tầng hiện tại lấy từ hồ sơ học viên nếu có; chưa có thì không tô dòng
      // nào, chứ không đoán bừa một tầng để bảng nhìn cho sinh động.
      let tang = null;
      try { tang = this.N?.profiles?.get?.(ng.thanhVienId)?.currentLevel ?? null; } catch { tang = null; }
      return { html: trang.trangMaTran(maTran.toanBo(), thanhTra.bienBan(), tang, nguoi, nonce) };
    }

    if (d === '/nha/cay-gia-tri') {
      const { cayGiaTri, tangHienTai } = require('../nha/cay-gia-tri');
      // Ba nguồn, cả ba là số ĐÃ ĐO. Thiếu nguồn nào thì trang nói "chưa đủ
      // căn cứ" chứ không đoán một tầng cho bảng nhìn có vẻ đầy đủ.
      let metrics = null;
      let mastery = null;
      let tienDo = null;
      try { metrics = this.N?.telemetry?.metrics?.(ng.thanhVienId) ?? null; } catch { metrics = null; }
      try { mastery = this.N?.mastery?.summary?.(ng.thanhVienId) ?? null; } catch { mastery = null; }
      try { tienDo = this.nha.dangODau(ng.nhaId, ng.thanhVienId) ?? null; } catch { tienDo = null; }
      const dangO = tangHienTai({ tienDoTruc: tienDo, metrics, mastery });
      return { html: trang.trangCayGiaTri(cayGiaTri(), dangO, nguoi, nonce) };
    }

    if (d === '/nha/khao-sat') {
      const { luatDo } = require('../khao-sat/hien-phap-do');
      const daLam = this.N?.khaoSat
        ? this.N.khaoSat.moiNhat(ng.thanhVienId, { laChinhChu: true }).ketQua
        : {};
      return { html: trang.trangKhaoSat(ks.danhSach({ daLam }), luatDo(), nguoi, nonce) };
    }

    if (laKhaoSat) {
      const bo = ks.deBai(boKhaoSat);
      return { html: trang.trangLamKhaoSat(bo, nguoi, nonce, truyVan && truyVan.loi ? String(truyVan.loi) : null) };
    }

    if (d === '/nha/lo-trinh-ca-nhan') {
      const { dungHoSo } = require('../khao-sat/ho-so');
      const { dungLoTrinh } = require('../khao-sat/lo-trinh-ca-nhan');
      const { luatDo } = require('../khao-sat/hien-phap-do');
      // Kết quả khảo sát KHÔNG được lưu xuống đĩa (xem src/api/router.js), nên
      // trang này chỉ dựng được lộ trình khi phiên hiện tại có kết quả. Chưa
      // có thì trang nói thẳng là chưa có, chứ không dựng một lộ trình mẫu
      // rồi để gia đình tưởng đó là của con mình.
      let lop = null;
      try { lop = this.N?.profiles?.get?.(ng.thanhVienId)?.grade ?? null; } catch { lop = null; }
      // Đọc kết quả THẬT của chính chủ. Trước bản rà soát chỗ này truyền
      // ketQua rỗng cứng, nên trang vĩnh viễn hiện "CHƯA_ĐỦ_CĂN_CỨ" cho mọi
      // tài khoản — một trang không bao giờ chạy được.
      const ban = this.N?.khaoSat
        ? this.N.khaoSat.moiNhat(ng.thanhVienId, { laChinhChu: true, vaiNguoiDoc: ng.vaiId }).ketQua
        : {};
      const ketQua = {};
      for (const [ma, b] of Object.entries(ban)) ketQua[ma] = b.ketQua;
      const hoSo = dungHoSo({ hocVienId: ng.thanhVienId, hoTen: ng.ten, lop, ketQua });
      const lt = dungLoTrinh({ hoSo, lop });
      return { html: trang.trangLoTrinhCaNhan(lt, luatDo(), nguoi, nonce) };
    }

    // Hai khu còn lại chưa có dữ liệu thật để hiện. Nói thẳng còn thiếu gì,
    // thay vì dựng màn hình rỗng nhìn như đã xong.
    const CHUA_DUNG = {
      '/nha/hom-nay': {
        tieuDe: 'Luyện hôm nay',
        canGi: [
          'Lịch luyện do chính học viên chốt ở phòng Chọn đích.',
          'Cách nhắc mà gia đình đồng ý nhận, để hệ thống không tự ý gửi thông báo.',
        ],
      },
      '/nha/nguoi-dong-hanh': {
        tieuDe: 'Người đồng hành',
        canGi: [
          'Bảng phân công cố vấn và giáo viên cho từng học viên.',
          'Sự đồng ý của gia đình về việc ai được nhìn thấy tiến độ.',
        ],
      },
    };
    if (CHUA_DUNG[d]) {
      return { html: trang.trangChuaDung({ ...CHUA_DUNG[d], duongDan: d, nguoi, nonce }) };
    }

    const phongId = d.slice('/nha/'.length);

    const mo = this.nha.moPhong(ng.nhaId, ng.thanhVienId, ng.vaiId, phongId);
    if (!mo.ok) {
      return {
        html: trang.trangChuaDung({
          tieuDe: PHONG_INDEX.get(phongId).ten,
          duongDan: d,
          canGi: [mo.vi || 'Phòng này chưa mở được cho vai hiện tại.'],
          nguoi, nonce,
        }),
      };
    }
    const loi = truyVan && truyVan.loi ? String(truyVan.loi) : null;
    return { html: trang.trangTruc(mo.boiCanh, nguoi, nonce, loi) };
  }

  /**
   * Nhận một bài khảo sát đã làm: đọc biểu mẫu, chấm, lưu theo luật riêng tư,
   * rồi TRẢ THẲNG trang kết quả.
   *
   * Khác với nộp một bước (chuyển hướng 303 rồi xem), chỗ này trả thẳng trang
   * kết quả: kết quả khảo sát không có đường dẫn riêng để xem lại, và cố tạo
   * ra một đường dẫn như thế là tạo ra một trang ai có link cũng mở được.
   */
  _nopKhaoSat(boId, duLieu, req, nonce = null) {
    const ng = nguoiGoCua(this.N, req);
    if (!ng) return { chuyenToi: '/nha' };
    if (!ks.BO[boId]) return { chuyenToi: '/nha/khao-sat' };
    const nguoi = { ten: ng.ten, vaiTen: ng.vaiTen, nhaTen: ng.nhaTen };
    const bo = ks.deBai(boId);

    // ── CỔNG TUỔI ────────────────────────────────────────────────────
    // Bộ khảo sát chạm dữ liệu của một đứa trẻ, nên nó phải qua cổng như mọi
    // tính năng khác. Ở mức TRONG NHÀ, cổng đòi có NGƯỜI PHỤ TRÁCH xác định
    // danh tính — và ở đây điều kiện ấy có thật: `nguoiGoCua` vừa xác thực
    // xong một phiên thuộc một trong bốn vai đã khai.
    //
    // Gọi cổng ở đây, dù hôm nay nó luôn cho qua, KHÔNG phải hình thức: ngày
    // ai đó thêm một bộ khảo sát mức chạm người lạ, cổng đã nằm sẵn trên
    // đường đi chứ không phải chờ người nhớ ra mà cắm vào.
    const congTuoi = require('../an-toan/cong-tuoi').choVao({
      maTinhNang: 'KHAO_SAT',
      coNguoiPhuTrach: true,
    });
    if (!congTuoi.ok) {
      return { html: trang.trangLamKhaoSat(bo, nguoi, nonce, `${congTuoi.lyDo} ${congTuoi.canGi || ''}`) };
    }

    const doc = ks.docBieuMau(boId, duLieu || {});
    if (!doc.ok) return { chuyenToi: '/nha/khao-sat' };
    if (doc.thieu.length) {
      // Thiếu câu thì KHÔNG chấm. Trả lại chính trang làm bài kèm lý do, chứ
      // không chấm phần đã làm rồi coi như xong — một hồ sơ dựng trên nửa bài
      // trông y hệt hồ sơ dựng trên cả bài.
      const loi = `Còn ${doc.thieu.length}/${doc.tongCau} câu chưa trả lời (câu ${doc.thieu.slice(0, 8).join(', ')}${doc.thieu.length > 8 ? '…' : ''}).`;
      return { html: trang.trangLamKhaoSat(bo, nguoi, nonce, loi) };
    }

    let metrics = null;
    try { metrics = this.N?.telemetry?.metrics?.(ng.thanhVienId) ?? null; } catch { metrics = null; }
    const kq = ks.cham(boId, doc.traLoi, { metrics });
    const tt = ks.tomTat(boId, kq);

    let khongLuuCauTho = false;
    if (this.N && this.N.khaoSat) {
      const l = this.N.khaoSat.luu({
        hocVienId: ng.thanhVienId, congCu: bo.maCongCu,
        ketQua: kq, cauTraLoi: doc.traLoi, nguoiLam: ng.thanhVienId,
      });
      khongLuuCauTho = !!l.khongLuuCauTho;
    }
    return { html: trang.trangKetQuaKhaoSat(bo, { ...tt, khongLuuCauTho }, nguoi, nonce) };
  }

  /**
   * Nhận biểu mẫu nộp một bước.
   * Trả về `{chuyenToi}` để máy chủ chuyển hướng — nộp xong phải đổi sang xem,
   * nếu không thì nạp lại trang là nộp thêm lần nữa.
   */
  nhanNop(duongDan, duLieu, { req = null, nonce = null } = {}) {
    // Nộp một bài khảo sát đi trước, vì đường dẫn của nó dài hơn và sẽ bị
    // biểu thức của phần nộp bước bắt nhầm nếu để sau.
    const ksNop = String(duongDan || '').match(/^\/nha\/khao-sat\/([a-z-]+)\/nop$/);
    if (ksNop) return this._nopKhaoSat(ksNop[1], duLieu, req, nonce);

    // Khai lớp: con số này quyết định phạm vi kiến thức của cả sáu chặng, và
    // trước bản rà soát thì khu riêng KHÔNG có đường nào ghi được nó vào hồ sơ
    // học viên — nên trang lộ trình vĩnh viễn không dựng được cho mọi tài khoản.
    if (String(duongDan || '') === '/nha/lo-trinh-ca-nhan/khai-lop') {
      const ng2 = nguoiGoCua(this.N, req);
      if (!ng2) return { chuyenToi: '/nha' };
      const lop = Number((duLieu && duLieu.lop) || 0);
      if (!Number.isInteger(lop) || lop < 1 || lop > 12) return { chuyenToi: '/nha/lo-trinh-ca-nhan' };
      try {
        const cu = this.N && this.N.profiles ? this.N.profiles.get(ng2.thanhVienId) : null;
        if (cu) this.N.profiles.register(ng2.thanhVienId, { ...cu, grade: lop });
        else this.N.profiles.register(ng2.thanhVienId, { fullName: ng2.ten, grade: lop });
      } catch { /* không ghi được thì trang sau vẫn hỏi lại, không làm đổ máy chủ */ }
      return { chuyenToi: '/nha/lo-trinh-ca-nhan' };
    }

    const m = String(duongDan || '').match(/^\/nha\/([a-z0-9-]+)\/nop$/);
    if (!m) return null;
    const phongId = m[1];
    const ng = nguoiGoCua(this.N, req);
    if (!ng) return { chuyenToi: '/nha' };
    if (!PHONG_INDEX.has(phongId)) return { chuyenToi: '/nha' };

    const tho = duLieu && duLieu.dauRa;
    const phong = PHONG_INDEX.get(phongId);
    const bc = this.nha.boiCanh(ng.nhaId, ng.thanhVienId, ng.vaiId, phongId);
    if (!bc || !bc.chang.hienTai) return { chuyenToi: `/nha/${phongId}` };

    // Ô nhập nhiều dòng gửi lên một chuỗi; bước đòi danh sách thì tách theo dòng.
    let dauRa = tho;
    const kieu = bc.chang.hienTai.dauRa.kieu;
    if (kieu === 'danh-sach') dauRa = String(tho || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
    if (kieu === 'dau-tich') dauRa = tho === 'co' || tho === 'on' || tho === true;
    if (kieu === 'so') dauRa = Number(tho);

    const r = this.nha.nopBuoc(ng.nhaId, ng.thanhVienId, ng.vaiId, phongId, dauRa);
    if (!r.ok) {
      const vi = encodeURIComponent(r.vi || 'Chưa nộp được, xem lại phần đã điền.');
      return { chuyenToi: `/nha/${phongId}?loi=${vi}` };
    }
    void phong;
    return { chuyenToi: `/nha/${phongId}` };
  }

  trangThai() { return this.nha.trangThaiHeThong(); }
}

module.exports = MatTrongNha;
module.exports.VAI_THEO_TAI_KHOAN = VAI_THEO_TAI_KHOAN;
module.exports.docCookie = docCookie;
