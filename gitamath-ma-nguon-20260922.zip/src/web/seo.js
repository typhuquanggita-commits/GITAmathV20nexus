'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TẦNG SEO — dựng thẻ chuẩn, và TỰ CHẤM lại trang mình vừa dựng
 * ═══════════════════════════════════════════════════════════════════════════
 *  Phần lớn hướng dẫn SEO là lời khuyên; ở đây chúng được viết thành LUẬT
 *  KIỂM ĐƯỢC. Mỗi trang do hệ thống sinh ra đều phải qua soat() trước khi
 *  được coi là xong, và bộ kiểm định chạy soat() trên toàn bộ trang công khai
 *  nên không thể có chuyện "quên đặt thẻ mô tả" lọt ra ngoài.
 *
 *  Vì sao không dùng thư viện SEO: mọi thứ cần thiết đều là chuỗi HTML và một
 *  ít JSON-LD. Thêm phụ thuộc chỉ để nối chuỗi là đánh đổi tồi.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const cfg = require('../config');

/** Ngưỡng của các công cụ tìm kiếm lớn, tính bằng ký tự hiển thị. */
const NGUONG = {
  tieuDeMin: 20, tieuDeMax: 62,
  moTaMin: 70, moTaMax: 165,
  h1: 1,
  tuKhoaToiDa: 12,
};

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);

/** Địa chỉ gốc của trang công khai — đổi được bằng biến môi trường. */
const goc = () => String(cfg.WEB.diaChiGoc || '').replace(/\/+$/, '');

/** Đường dẫn tuyệt đối, dùng cho canonical và sitemap. */
const tuyetDoi = (duongDan) => `${goc()}${duongDan.startsWith('/') ? '' : '/'}${duongDan}`;

/**
 * Dựng phần <head> đầy đủ thẻ.
 * @param {object} t {tieuDe, moTa, duongDan, loai, jsonLd, tuKhoa, ngayCapNhat}
 */
function dungHead(t) {
  const url = tuyetDoi(t.duongDan);
  // Mỗi khối mã trong trang mang một nonce dùng một lần, nhờ đó chính sách bảo
  // mật nội dung KHÔNG phải mở 'unsafe-inline' — thứ vô hiệu hoá gần hết tác
  // dụng chặn mã lạ của chính sách đó.
  const nonce = t.nonce ? ` nonce="${esc(t.nonce)}"` : '';
  const ld = (t.jsonLd || []).map((j) => `<script type="application/ld+json"${nonce}>${JSON.stringify(j)}</script>`).join('');
  return `<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(t.tieuDe)}</title>
<meta name="description" content="${esc(t.moTa)}">
<link rel="canonical" href="${esc(url)}">
<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large">
<meta name="author" content="${esc(cfg.WEB.tenToChuc)}">
<meta property="og:type" content="${esc(t.loai || 'website')}">
<meta property="og:site_name" content="${esc(cfg.WEB.tenToChuc)}">
<meta property="og:locale" content="vi_VN">
<meta property="og:title" content="${esc(t.tieuDe)}">
<meta property="og:description" content="${esc(t.moTa)}">
<meta property="og:url" content="${esc(url)}">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="${esc(t.tieuDe)}">
<meta name="twitter:description" content="${esc(t.moTa)}">
<meta name="theme-color" content="#0d1117">
${t.ngayCapNhat ? `<meta property="article:modified_time" content="${esc(t.ngayCapNhat)}">` : ''}
<link rel="alternate" hreflang="vi" href="${esc(url)}">
<link rel="icon" href="/ui/icon.png" type="image/png">
<link rel="manifest" href="/manifest.webmanifest">
${ld}`;
}

/** Tổ chức phát hành — dùng lại ở mọi trang. */
function toChuc() {
  return {
    '@context': 'https://schema.org',
    '@type': 'EducationalOrganization',
    name: cfg.WEB.tenToChuc,
    url: goc() || undefined,
    description: cfg.WEB.moTaToChuc,
    inLanguage: 'vi-VN',
  };
}

/** Vụn đường dẫn — công cụ tìm kiếm hiển thị thành đường mòn dưới tiêu đề. */
function vunDuongDan(cac) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: cac.map((x, i) => ({
      '@type': 'ListItem', position: i + 1, name: x.ten, item: tuyetDoi(x.duongDan),
    })),
  };
}

/** Một dạng bài mô tả theo chuẩn Course. */
function khoaHoc({ ma, ten, moTa, duongDan, capDo }) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Course',
    name: ten,
    description: moTa,
    courseCode: ma,
    url: tuyetDoi(duongDan),
    inLanguage: 'vi-VN',
    educationalLevel: capDo,
    provider: { '@type': 'EducationalOrganization', name: cfg.WEB.tenToChuc },
    isAccessibleForFree: true,
  };
}

/** Khối hỏi đáp — trang nào có mục hỏi đáp thì khai báo để được hiển thị mở rộng. */
function hoiDap(cac) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: cac.map((x) => ({
      '@type': 'Question', name: x.hoi,
      acceptedAnswer: { '@type': 'Answer', text: x.dap },
    })),
  };
}

/** Trang chủ khai báo ô tìm kiếm để công cụ tìm kiếm hiện thanh tìm riêng. */
function trangGoc() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: cfg.WEB.tenToChuc,
    url: goc() || undefined,
    inLanguage: 'vi-VN',
    potentialAction: {
      '@type': 'SearchAction',
      target: `${goc()}/chuong-trinh?tim={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
  };
}

// ── Tự chấm lại trang vừa dựng ─────────────────────────────────────────────

/**
 * Đo độ dài như công cụ tìm kiếm nhìn thấy: sau khi giải mã thực thể HTML.
 * Đếm trên chuỗi thô thì "&#39;" tính thành năm ký tự, và thẻ mô tả vừa khung
 * lại bị báo là quá dài.
 */
const GIAI_MA = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'" };
const giaiMa = (s) => String(s || '').replace(/&(amp|lt|gt|quot|#39);/g, (m) => GIAI_MA[m]);
const demChu = (s) => [...giaiMa(s)].length;

/**
 * Soát một trang HTML theo danh sách yêu cầu kiểm được.
 * Trả về từng mục đạt hay không, kèm số đo — để sửa được chứ không chỉ để biết.
 */
function soat(html, { duongDan = '/' } = {}) {
  const s = String(html || '');
  const muc = [];
  const them = (ma, dat, moTa, soDo) => muc.push({ ma, dat, moTa, soDo: soDo ?? null });

  const tieuDe = (s.match(/<title>([^<]*)<\/title>/) || [])[1] || '';
  const moTa = (s.match(/<meta name="description" content="([^"]*)"/) || [])[1] || '';
  const h1 = s.match(/<h1[\s>]/g) || [];
  const canonical = (s.match(/<link rel="canonical" href="([^"]*)"/) || [])[1] || '';
  const lang = (s.match(/<html lang="([^"]*)"/) || [])[1] || '';
  const ld = s.match(/<script type="application\/ld\+json"[^>]*>/g) || [];
  const anh = s.match(/<img\b[^>]*>/g) || [];
  const anhThieuAlt = anh.filter((a) => !/\salt="/.test(a));
  const ngoai = (s.match(/(?:src|href)="https?:\/\/[^"]+"/g) || [])
    .filter((u) => !u.includes('schema.org') && !u.includes(goc() || '\u0000'));

  them('TIEU_DE', demChu(tieuDe) >= NGUONG.tieuDeMin && demChu(tieuDe) <= NGUONG.tieuDeMax,
    `Tiêu đề dài ${demChu(tieuDe)} ký tự (chuẩn ${NGUONG.tieuDeMin}–${NGUONG.tieuDeMax})`, demChu(tieuDe));
  them('MO_TA', demChu(moTa) >= NGUONG.moTaMin && demChu(moTa) <= NGUONG.moTaMax,
    `Thẻ mô tả dài ${demChu(moTa)} ký tự (chuẩn ${NGUONG.moTaMin}–${NGUONG.moTaMax})`, demChu(moTa));
  them('MOT_H1', h1.length === NGUONG.h1, `Có ${h1.length} thẻ h1 (phải đúng 1)`, h1.length);
  them('CANONICAL', !!canonical, `Thẻ canonical: ${canonical || 'CHƯA CÓ'}`);
  them('NGON_NGU', lang === 'vi', `Thuộc tính lang="${lang}" (phải là vi)`);
  them('DU_LIEU_CO_CAU_TRUC', ld.length >= 1, `${ld.length} khối JSON-LD`, ld.length);
  them('OG', /property="og:title"/.test(s) && /property="og:description"/.test(s), 'Thẻ chia sẻ mạng xã hội');
  them('ANH_CO_ALT', anhThieuAlt.length === 0, `${anh.length} ảnh, ${anhThieuAlt.length} ảnh thiếu thuộc tính alt`);
  them('KHONG_GOI_RA_NGOAI', ngoai.length === 0, `${ngoai.length} tài nguyên tải từ tên miền khác`, ngoai.length);
  them('CO_NOI_DUNG', (s.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().length) >= 300,
    `Phần chữ đọc được dài ${s.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().length} ký tự (tối thiểu 300)`);
  them('CO_LIEN_KET_NOI_BO', (s.match(/href="\/[^"]*"/g) || []).length >= 3,
    `${(s.match(/href="\/[^"]*"/g) || []).length} liên kết nội bộ`);
  them('BO_QUA_NAVIGATION', /<a class="bo-qua"|<a href="#noi-dung"/.test(s), 'Có liên kết bỏ qua thanh điều hướng (trợ năng)');
  them('CO_THE_DOC_KHONG_CAN_JS', !/<body[^>]*>\s*<div id="root"><\/div>/.test(s), 'Nội dung có sẵn trong HTML, không chờ JavaScript');
  them('CO_MANIFEST', /rel="manifest"/.test(s), 'Khai báo tệp mô tả ứng dụng để cài được lên màn hình chính');
  const khoiMa = (s.match(/<(script|style)\b[^>]*>/gi) || []);
  them('MOI_KHOI_MA_CO_NONCE', khoiMa.every((t) => /\snonce="/.test(t)),
    `${khoiMa.length} khối mã trong trang, ${khoiMa.filter((t) => !/\snonce="/.test(t)).length} khối chưa có nonce`);

  const dat = muc.filter((m) => m.dat).length;
  return {
    ok: dat === muc.length,
    duongDan,
    dat, tong: muc.length,
    diem: Math.round((dat / muc.length) * 100),
    muc,
    hong: muc.filter((m) => !m.dat),
  };
}

/**
 * Ghép tiêu đề cho vừa khung hiển thị của công cụ tìm kiếm.
 * Phần đuôi (tên thương hiệu) luôn được giữ; phần chính bị cắt nếu quá dài,
 * cắt ở ranh giới từ để không đứt giữa chữ.
 */
function tieuDeVua(chinh, duoi = cfg.WEB.tenToChuc, { toiDa = NGUONG.tieuDeMax } = {}) {
  const noi = ' | ';
  const con = toiDa - demChu(duoi) - noi.length;
  let c = String(chinh).trim();
  if (demChu(c) > con) {
    const cat = [...c].slice(0, con).join('');
    const khoang = cat.lastIndexOf(' ');
    c = (khoang > con * 0.5 ? cat.slice(0, khoang) : cat).replace(/[\s,–—-]+$/, '');
  }
  return `${c}${noi}${duoi}`;
}

/** Cắt thẻ mô tả cho vừa khung, cắt ở ranh giới câu hoặc từ. */
function moTaVua(chu, { toiDa = NGUONG.moTaMax, toiThieu = NGUONG.moTaMin } = {}) {
  let s = String(chu).replace(/\s+/g, ' ').trim();
  if (demChu(s) <= toiDa) return s;
  const cat = [...s].slice(0, toiDa - 1).join('');
  const cham = Math.max(cat.lastIndexOf('. '), cat.lastIndexOf('; '));
  if (cham > toiThieu) return cat.slice(0, cham + 1);
  const khoang = cat.lastIndexOf(' ');
  return `${(khoang > toiThieu ? cat.slice(0, khoang) : cat).replace(/[\s,–—-]+$/, '')}…`;
}

module.exports = {
  dungHead, soat, esc, tuyetDoi, goc, NGUONG, tieuDeVua, moTaVua,
  toChuc, vunDuongDan, khoaHoc, hoiDap, trangGoc,
};
