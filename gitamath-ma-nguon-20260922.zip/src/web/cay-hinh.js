'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  VẼ CÂY GIÁ TRỊ — SVG THUẦN, KHÔNG JAVASCRIPT, KHÔNG TỆP NGOÀI
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Cây này KHÔNG phải hình minh hoạ. Mỗi nét trên hình đọc ra từ lưới 50 ô:
 *
 *      thân        con đường chung, đi từ dưới lên
 *      5 nhánh lớn 5 tầng giá trị — nhánh 5 là TÁN, vì đó là đích
 *      10 nhánh nhỏ 10 cấp trong một tầng
 *      lá          nhiệm vụ học viên làm ở cấp ấy
 *      quả         thứ gia đình nhận được khi cấp ấy xong
 *
 *  QUẢ CHÍN VÀ QUẢ NON — chỗ này là chỗ dễ nói dối nhất, nên nói rõ:
 *  cấp 3 · 6 · 10 của mỗi tầng có MỐC CỨNG đo được bằng máy, vẽ thành quả
 *  chín. Bảy cấp còn lại là mốc mềm, vẽ thành quả non. Một cái cây mà quả nào
 *  cũng chín đều là cái cây vẽ cho đẹp; ở đây 15 quả chín và 35 quả non, đúng
 *  bằng số mốc cứng và mốc mềm thật trong lưới.
 *
 *  KHÔNG có một số ngẫu nhiên nào trong tệp này. Mọi toạ độ tính bằng công
 *  thức, nên hai lần vẽ ra hai ảnh giống hệt nhau tới từng chữ số — có mục
 *  kiểm đối chiếu hai lần vẽ để chắc điều đó.
 *
 *  KHÔNG dùng JavaScript: khu riêng chạy với `script-src 'none'`. Chữ của
 *  từng quả nằm trong <title> của SVG nên trình duyệt tự hiện khi rê chuột,
 *  và nằm đầy đủ trong bảng chữ ngay dưới hình cho người đọc bằng màn hình
 *  đọc hoặc bằng điện thoại.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { esc } = require('./nha-giao-dien');

// ── Khung hình ──────────────────────────────────────────────────────────────
const W = 1200;
const H = 1440;
const X = 600;                 // trục thân
const DAT = 1360;              // mặt đất
const NGON = { x: X, y: 620 }; // chỗ thân chia làm ba cành chính của tán

/**
 * Bốn tầng dưới mọc thành nhánh, xen kẽ hai bên. Nhánh DƯỚI DÀI HƠN nhánh
 * trên — đó là hình dáng của cây thật, và nó cũng nói đúng một điều: tầng
 * dưới rộng hơn vì nó đỡ tất cả các tầng trên.
 */
const NHANH = [
  { tang: 1, y: 1215, ben: 1, dai: 452, cao: 210 },
  { tang: 2, y: 1055, ben: -1, dai: 424, cao: 196 },
  { tang: 3, y: 900, ben: 1, dai: 392, cao: 182 },
  { tang: 4, y: 745, ben: -1, dai: 356, cao: 168 },
];

// Tán: một vòm, không phải một nan quạt. Mười cấp đậu dọc theo vòm ấy.
const TAN = { x: X, y: 360, rx: 336, ry: 236 };

const lam = (n) => Math.round(n * 10) / 10;   // một chữ số thập phân: đủ mượt, và ổn định

/** Điểm trên đường Bézier bậc ba. */
function bezier3(p0, p1, p2, p3, t) {
  const u = 1 - t;
  return {
    x: lam(u * u * u * p0.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * p3.x),
    y: lam(u * u * u * p0.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * p3.y),
  };
}

/**
 * Hình học của một nhánh lớn.
 * Nhánh vươn ra rồi HƠI CHÚI XUỐNG ở đoạn cuối, như cành mang nặng quả — chứ
 * không phải một cái nan thẳng đâm ra khỏi cột.
 */
function hinhNhanh(n) {
  const p0 = { x: X + n.ben * 22, y: n.y };
  const p1 = { x: X + n.ben * n.dai * 0.34, y: n.y - n.cao * 0.52 };
  const p2 = { x: X + n.ben * n.dai * 0.72, y: n.y - n.cao * 0.98 };
  const p3 = { x: X + n.ben * n.dai, y: n.y - n.cao * 0.82 };
  const diem = [];
  for (let c = 1; c <= 10; c++) {
    const t = 0.14 + (c - 1) * (0.97 - 0.14) / 9;
    diem.push({ cap: c, ...bezier3(p0, p1, p2, p3, t) });
  }
  return { p0, p1, p2, p3, diem, ben: n.ben };
}

/** Hình học của tán: mười chỗ đậu dọc theo vòm, hai đầu thấp, giữa cao. */
function hinhTan() {
  const diem = [];
  for (let c = 1; c <= 10; c++) {
    // 190° → 350°: đi từ mép trái vòm sang mép phải, mắt người đọc trái sang phải.
    const goc = (203 + (c - 1) * (337 - 203) / 9) * Math.PI / 180;
    // Chỗ đậu quả nằm TRONG tán, sát mép dưới. Để nó ra ngoài mép thì hai quả
    // đầu và hai quả cuối thòng ra khoảng trắng, trông như bị rụng nửa chừng.
    diem.push({
      cap: c,
      x: lam(TAN.x + TAN.rx * 0.74 * Math.cos(goc)),
      y: lam(TAN.y + TAN.ry * 0.54 * Math.sin(goc) + 84),
    });
  }
  return { diem };
}

/** Một chiếc lá hình giọt, gốc tại (x,y), ngả theo góc `goc` (độ). */
function veLa(x, y, dai, goc, lop) {
  const r = goc * Math.PI / 180;
  const ux = Math.cos(r);
  const uy = Math.sin(r);
  const gx = lam(x + ux * dai);
  const gy = lam(y + uy * dai);
  const rong = dai * 0.40;
  const nx = -uy;
  const ny = ux;
  return `<path class="${lop}" d="M${x},${y} `
    + `C${lam(x + nx * rong)},${lam(y + ny * rong)} ${lam(gx + nx * rong * 0.4)},${lam(gy + ny * rong * 0.4)} ${gx},${gy} `
    + `C${lam(gx - nx * rong * 0.4)},${lam(gy - ny * rong * 0.4)} ${lam(x - nx * rong)},${lam(y - ny * rong)} ${x},${y}Z"/>`;
}

/**
 * Trạng thái của một ô so với chỗ học viên đang đứng.
 * Không có căn cứ thì TẤT CẢ đều 'chua-biet' — cây vẫn hiện đủ năm mươi quả,
 * nhưng không quả nào được tô như đã hái. Tô sẵn vài quả cho hình đỡ trống là
 * cách nhanh nhất để mất lòng tin vào cả năm mươi quả còn lại.
 */
function trangThai(tang, cap, dangO) {
  if (!dangO || !dangO.duCanCu || !dangO.tang) return 'chua-biet';
  const soDa = (dangO.tang - 1) * 10 + (dangO.cap || 10);
  const soNay = (tang - 1) * 10 + cap;
  if (soNay < soDa) return 'da-qua';
  if (soNay === soDa) return 'dang-o';
  return 'chua-toi';
}

/**
 * Vẽ cả cây.
 *   luoi  — kết quả của require('../matran/cay-50').luoi()
 *   dangO — { tang, cap, duCanCu } hoặc null khi chưa đủ căn cứ
 */
function veCay({ luoi, dangO = null } = {}) {
  if (!luoi || !Array.isArray(luoi.o) || luoi.o.length !== 50) {
    throw new Error('veCay: cần đúng lưới 50 ô — vẽ một cái cây không khớp lưới là vẽ một lời nói dối.');
  }
  const oCua = new Map(luoi.o.map((x) => [x.ma, x]));
  const cung = (t, c) => (oCua.get(`T${t}C${c}`).bangChung.loai === 'moc-cung');

  const nen = [];        // tán lá phía sau, vẽ trước để nằm dưới
  const go = [];         // thân và nhánh
  const tren = [];       // lá, quả, chữ

  // ── Đất và thân ───────────────────────────────────────────────────────
  nen.push(`<ellipse class="bong-dat" cx="${X}" cy="${DAT + 26}" rx="330" ry="26"/>`);
  // Thân thon nhanh ở phần gốc rồi thon chậm lên ngọn, và lệch nhẹ sang phải
  // rồi trở lại — thân thẳng tắp đều răm rắp là thân cột, không phải thân cây.
  go.push(`<path class="than" d="M${X - 40},${DAT} `
    + `C${X - 26},${DAT - 190} ${X - 22},${DAT - 410} ${X - 15},${DAT - 600} `
    + `C${X - 11},${DAT - 690} ${X - 13},${DAT - 730} ${X - 9},${NGON.y} `
    + `L${X + 9},${NGON.y} `
    + `C${X + 13},${DAT - 730} ${X + 12},${DAT - 690} ${X + 18},${DAT - 600} `
    + `C${X + 25},${DAT - 410} ${X + 28},${DAT - 190} ${X + 40},${DAT}Z"/>`);
  go.push(`<path class="re" d="M${X - 36},${DAT - 4} C${X - 96},${DAT + 8} ${X - 134},${DAT + 26} ${X - 168},${DAT + 40}`
    + `M${X + 36},${DAT - 4} C${X + 96},${DAT + 8} ${X + 134},${DAT + 26} ${X + 168},${DAT + 40}`
    + `M${X - 14},${DAT + 2} C${X - 26},${DAT + 18} ${X - 36},${DAT + 30} ${X - 44},${DAT + 44}`
    + `M${X + 14},${DAT + 2} C${X + 26},${DAT + 18} ${X + 36},${DAT + 30} ${X + 44},${DAT + 44}"/>`);

  // ── Bốn nhánh lớn ─────────────────────────────────────────────────────
  for (const n of NHANH) {
    const g = hinhNhanh(n);
    const t = luoi.o.find((x) => x.tang === n.tang);

    // Vòm lá phía sau nhánh, để nhánh không trơ ra như một cái nan.
    for (let k = 0; k < 3; k++) {
      const d = g.diem[2 + k * 3];
      nen.push(`<ellipse class="vom vom-t${n.tang}" cx="${lam(d.x + n.ben * 10)}" cy="${lam(d.y - 26)}" `
        + `rx="${lam(104 - k * 9)}" ry="${lam(62 - k * 5)}"/>`);
    }

    go.push(`<path class="nhanh nhanh-t${n.tang}" d="M${g.p0.x},${g.p0.y} `
      + `C${g.p1.x},${g.p1.y} ${g.p2.x},${g.p2.y} ${g.p3.x},${g.p3.y}"/>`);

    // Tên tầng đặt TRÊN nhánh, ngay quãng giữa: luôn nằm trong khung hình, và
    // không đè lên tán. Câu dài của tầng nằm ở bảng chữ phía dưới trang.
    const giua = g.diem[4];
    tren.push(`<text class="ten-tang" x="${lam(giua.x + n.ben * 6)}" y="${lam(giua.y - 96)}" text-anchor="middle">`
      + `<tspan class="so-tang">Tầng ${n.tang}</tspan> <tspan>${esc(t.tenTang)}</tspan></text>`);

    for (const d of g.diem) tren.push(motCap(n.tang, d, cung(n.tang, d.cap), dangO, oCua, n.ben));
  }

  // ── Tán: tầng 5 ───────────────────────────────────────────────────────
  // Tầng 5 không vẽ thành nhánh đâm ngang mà thành TÁN, vì nó là đích: đi hết
  // bốn tầng dưới thì thứ nhận được là cái tán che cho cả cây.
  const tan = hinhTan();
  const t5 = luoi.o.find((x) => x.tang === 5);
  // Một vòm lớn cộng bốn vòm phụ chờm lên nhau. Chờm lên nhau chứ không đặt
  // cạnh nhau: đặt cạnh nhau thì thấy rõ từng hình bầu dục, và tán trông như
  // mấy đám mây xếp hàng.
  nen.push(`<ellipse class="vom vom-t5 vom-lon" cx="${TAN.x}" cy="${TAN.y}" rx="${TAN.rx}" ry="${TAN.ry}"/>`);
  nen.push(`<ellipse class="vom vom-t5" cx="${lam(TAN.x - 146)}" cy="${lam(TAN.y + 36)}" rx="190" ry="152"/>`);
  nen.push(`<ellipse class="vom vom-t5" cx="${lam(TAN.x + 146)}" cy="${lam(TAN.y + 36)}" rx="190" ry="152"/>`);
  nen.push(`<ellipse class="vom vom-t5" cx="${lam(TAN.x - 62)}" cy="${lam(TAN.y - 66)}" rx="206" ry="140"/>`);
  nen.push(`<ellipse class="vom vom-t5" cx="${lam(TAN.x + 62)}" cy="${lam(TAN.y - 66)}" rx="206" ry="140"/>`);

  // BA cành chính chia ra từ ngọn thân, rồi mỗi cành chia tiếp thành nhánh con
  // mang quả. Mười nan toả từ đúng một điểm ra thành cái quạt, không thành tán.
  const CANH_CHINH = [
    { den: { x: lam(X - 196), y: 452 }, cap: [1, 2, 3] },
    { den: { x: lam(X + 14), y: 370 }, cap: [4, 5, 6, 7] },
    { den: { x: lam(X + 200), y: 452 }, cap: [8, 9, 10] },
  ];
  const diem5 = new Map(tan.diem.map((d) => [d.cap, d]));
  for (const canh of CANH_CHINH) {
    const cx = lam(X + (canh.den.x - X) * 0.42);
    const cy = lam(NGON.y - (NGON.y - canh.den.y) * 0.58);
    go.push(`<path class="nhanh nhanh-t5" d="M${X},${NGON.y} Q${cx},${cy} ${canh.den.x},${canh.den.y}"/>`);
    for (const c of canh.cap) {
      const d = diem5.get(c);
      const gx = lam(canh.den.x + (d.x - canh.den.x) * 0.45);
      const gy = lam(canh.den.y + (d.y - canh.den.y) * 0.72);
      go.push(`<path class="nhanh nhanh-t5 nhanh-con" d="M${canh.den.x},${canh.den.y} Q${gx},${gy} ${d.x},${d.y}"/>`);
      tren.push(motCap(5, d, cung(5, c), dangO, oCua, d.x >= X ? 1 : -1));
    }
  }
  tren.push(`<text class="ten-tang tan-ten" x="${X}" y="${lam(TAN.y - TAN.ry - 26)}" text-anchor="middle">`
    + `<tspan class="so-tang">Tầng 5</tspan> <tspan>${esc(t5.tenTang)}</tspan></text>`);
  tren.push(`<text class="viec-tang" x="${X}" y="${lam(TAN.y - TAN.ry - 4)}" text-anchor="middle">đích của cả cây</text>`);

  const dat = `<path class="dat" d="M60,${DAT + 44} C320,${DAT + 20} 880,${DAT + 20} ${W - 60},${DAT + 44}"/>`;

  const moTa = 'Cây giá trị: một thân chung, bốn nhánh lớn là bốn tầng đầu và một tán là tầng năm. '
    + 'Mỗi tầng có mười cấp; mỗi cấp một chiếc lá là nhiệm vụ phải làm và một quả là thứ gia đình '
    + `nhận được. ${luoi.soMocCung} quả chín có bằng chứng đo bằng máy, ${luoi.soMocMem} quả non là mốc mềm.`;

  const svg = `<svg class="cay-hinh" viewBox="0 0 ${W} ${H}" role="img" `
    + `aria-labelledby="cay-ten cay-mo-ta" preserveAspectRatio="xMidYMid meet">`
    + `<title id="cay-ten">Cây giá trị năm tầng, mỗi tầng mười cấp</title>`
    + `<desc id="cay-mo-ta">${esc(moTa)}</desc>`
    + dat + nen.join('') + go.join('') + tren.join('')
    + '</svg>';

  return { svg, moTa };
}

/**
 * Một cấp: chùm lá (nhiệm vụ) + quả TREO XUỐNG (kết quả).
 * Quả treo xuống chứ không đâm ngang: quả nặng thì rủ xuống, và mắt người đọc
 * nhận ra ngay đó là quả chứ không phải một cái nút bấm.
 */
function motCap(tang, d, laCung, dangO, oCua, ben) {
  const o = oCua.get(`T${tang}C${d.cap}`);
  const tt = trangThai(tang, d.cap, dangO);
  const loaiQua = laCung ? 'chin' : 'non';
  const r = laCung ? 15 : 10;
  const cuong = laCung ? 24 : 20;
  const qx = lam(d.x + ben * 2);
  const qy = lam(d.y + cuong + r);

  const chu = `Tầng ${tang} · cấp ${d.cap} — ${o.tenCap}\n`
    + `LÁ (nhiệm vụ): ${o.la}\n`
    + `QUẢ (nhận được): ${o.qua}\n`
    + (laCung ? `Bằng chứng CỨNG: ${o.bangChung.chung}` : 'Mốc mềm: thấy mình đang nhích, không dùng để báo đã đạt.');

  // Ba lá mọc lên trên quanh chỗ đậu, ngả ba hướng khác nhau — tính bằng công
  // thức từ số cấp nên lần vẽ nào cũng ra đúng chỗ ấy.
  // Năm lá, toả từ -150° tới -30°, lệch theo số cấp và dài ngắn khác nhau.
  // Búi nào cũng y hệt búi nào thì nhìn ra ngay là máy rải, không phải cây mọc.
  const lech = (d.cap % 4 - 1.5) * 7;
  const la = [-150, -120, -90, -60, -30].map((a, i) => {
    const dai = 34 - Math.abs(i - 2) * 6 + (d.cap % 3) * 2;
    return veLa(lam(d.x + (i - 2) * 6), lam(d.y - 2), dai, a + lech, 'la');
  }).join('');

  return `<g class="o o-${tt} qua-${loaiQua}" data-o="${o.ma}">`
    + `<title>${esc(chu)}</title>`
    + la
    + `<path class="cuong" d="M${d.x},${d.y} Q${lam(qx + ben * 3)},${lam(d.y + cuong * 0.6)} ${qx},${lam(qy - r)}"/>`
    + `<circle class="qua" cx="${qx}" cy="${qy}" r="${r}"/>`
    + (laCung ? `<circle class="qua-loi" cx="${lam(qx - r * 0.32)}" cy="${lam(qy - r * 0.34)}" r="${lam(r * 0.26)}"/>` : '')
    + `<text class="so-cap" x="${qx}" y="${lam(qy + 4)}" text-anchor="middle">${d.cap}</text>`
    + '</g>';
}

module.exports = { veCay, trangThai, hinhNhanh, hinhTan, W, H };
