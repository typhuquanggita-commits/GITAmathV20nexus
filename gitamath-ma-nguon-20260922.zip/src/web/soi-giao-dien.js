'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SOI GIAO DIỆN — bắt lỗi "gọi API xong dùng thẳng dữ liệu"
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  LỖI NÀY CÓ THẬT, VÀ NÓ HỎNG RẤT ÊM. Hàm api() của giao diện xử lý lỗi
 *  đúng: nó KHÔNG ném, mà trả về {ok:false, error:…}. Nhưng chỗ gọi lại dùng
 *  thẳng dữ liệu:
 *
 *      const layers = await api('/superadmin/layers');
 *      layerStrip.innerHTML = layers.layers.map(…)
 *
 *  Máy chủ trả 401 thì layers.layers là undefined, `.map` ném lỗi, và lỗi ấy
 *  giết luôn phần còn lại của hàm. Trang mở lên TRÔNG NHƯ BÌNH THƯỜNG, chỉ
 *  thiếu một nửa nội dung, và người dùng không thấy một lời nào — lỗi nằm
 *  trong bảng điều khiển trình duyệt, nơi họ không bao giờ mở ra xem.
 *
 *  Bắt được khi lái thử tám trang bằng trình duyệt thật. Không bộ kiểm nào
 *  phía máy chủ nhìn thấy nó, vì phía máy chủ trả 401 là ĐÚNG.
 *
 *  BỘ SOI NÀY LÀM GÌ. Đọc từng tệp giao diện, tìm mẫu:
 *
 *      const <tên> = await api(…)      hoặc  G.api(…)
 *      … <tên>.<thuộc tính>            mà chưa qua một cửa kiểm nào
 *
 *  Cửa kiểm được chấp nhận, vì mỗi cửa đều thật sự chặn:
 *      · if (!<tên>.ok) …                 hỏi thẳng
 *      · if (!G.can(<tên>, …)) return     hàm kiểm dùng chung
 *      · <tên> && <tên>.x                 kiểm trước khi đọc
 *      · Array.isArray(<tên>.x)           kiểm hình dạng
 *      · (<tên>.x || [])                  có lối lui
 *      · <tên>?.x                         toán tử đọc an toàn
 *
 *  KHÔNG ĐẶT Ở scripts/verify.js MÀ ĐẶT Ở ĐÂY, vì đây là luật về giao diện
 *  chứ không phải một mục kiểm rời: mục kiểm và bộ kiểm thử đều gọi vào đây,
 *  nên chỉ có MỘT định nghĩa về thế nào là an toàn.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');

/** Bắt `const x = await api(...)` và `const x = await G.api(...)`. */
const GOI_MOT = /(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*await\s+(?:G\.)?api\s*\(/g;

/** Bắt `const [a, b] = await Promise.all([...api(...)...])`. */
const GOI_NHIEU = /(?:const|let|var)\s*\[([^\]]+)\]\s*=\s*await\s+Promise\.all\s*\(/g;

/** Thuộc tính do chính hàm api() luôn đặt — đọc chúng không bao giờ ném. */
const LUON_CO = new Set(['ok', 'error', 'message', '_status', '_chuaDangNhap', '_khongDuQuyen', 'raw']);

function soiMotTep(duongDan, noiDung) {
  const phat = [];
  const dong = noiDung.split('\n');

  const bienDaGoi = [];
  let m;
  GOI_MOT.lastIndex = 0;
  while ((m = GOI_MOT.exec(noiDung)) !== null) {
    bienDaGoi.push({ ten: m[1], tai: m.index });
  }
  GOI_NHIEU.lastIndex = 0;
  while ((m = GOI_NHIEU.exec(noiDung)) !== null) {
    // Chỉ tính khi trong Promise.all thật sự có lượt gọi api
    const sau = noiDung.slice(m.index, m.index + 600);
    if (!/(?:G\.)?api\s*\(/.test(sau)) continue;
    for (const t of m[1].split(',')) {
      const ten = t.trim();
      if (/^[A-Za-z_$][\w$]*$/.test(ten)) bienDaGoi.push({ ten, tai: m.index });
    }
  }

  for (const { ten, tai } of bienDaGoi) {
    const phanSau = noiDung.slice(tai);
    // Cửa kiểm nào xuất hiện sau lượt gọi thì coi như biến ấy đã được canh.
    const daCanh = new RegExp(
      `(?:!\\s*${ten}\\s*\\.\\s*ok`
      + `|${ten}\\s*\\.\\s*ok\\s*(?:===|!==|\\?|&&|\\))`
      + `|can\\s*\\(\\s*${ten}\\b`
      + `|${ten}\\s*&&`
      + `|${ten}\\s*\\?\\.`
      + `|Array\\.isArray\\s*\\(\\s*${ten}\\b`
      + `|${ten}\\s*\\.[\\w$]+\\s*\\|\\|`
      + `|\\(\\s*${ten}\\s*\\.[\\w$]+\\s*\\|\\|)`,
    ).test(phanSau);
    if (daCanh) continue;

    // Chưa canh: tìm lần ĐẦU TIÊN đọc một thuộc tính không thuộc nhóm luôn có.
    const doc = new RegExp(`\\b${ten}\\s*\\.\\s*([A-Za-z_$][\\w$]*)`, 'g');
    let d;
    while ((d = doc.exec(phanSau)) !== null) {
      if (LUON_CO.has(d[1])) continue;
      const viTri = tai + d.index;
      const soDong = noiDung.slice(0, viTri).split('\n').length;
      phat.push({
        tep: duongDan,
        dong: soDong,
        bien: ten,
        thuocTinh: d[1],
        trich: (dong[soDong - 1] || '').trim().slice(0, 110),
      });
      break;
    }
  }
  return phat;
}

/** Soi cả thư mục giao diện. */
function soiThuMuc(thuMuc) {
  const phat = [];
  const tep = [];
  const di = (d) => {
    for (const m of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, m.name);
      if (m.isDirectory()) di(p);
      else if (/\.(js|html)$/.test(m.name)) tep.push(p);
    }
  };
  if (!fs.existsSync(thuMuc)) return { dat: true, phat, soTep: 0 };
  di(thuMuc);
  for (const t of tep) {
    // common.js ĐỊNH NGHĨA api() và can(), nên nó không phải chỗ gọi.
    if (path.basename(t) === 'common.js') continue;
    phat.push(...soiMotTep(path.relative(thuMuc, t), fs.readFileSync(t, 'utf8')));
  }
  return { dat: phat.length === 0, phat, soTep: tep.length };
}

module.exports = { soiThuMuc, soiMotTep, LUON_CO };

// ═══════════════════════════════════════════════════════════════════════════
//  SOI MÀU GHI CỨNG — chữ tối trên nền tối ở chế độ sáng
// ═══════════════════════════════════════════════════════════════════════════
//
//  LỖI NÀY CŨNG CHỈ THẤY BẰNG MẮT. Tệp styles.css dựng đúng: mọi màu đi qua
//  biến, và khối @media (prefers-color-scheme: light) đổi bộ biến ấy sang
//  bảng màu sáng. Nhưng bốn trang tự viết thêm kiểu riêng và GHI CỨNG màu nền
//  tối cho ô nhập:
//
//      input,select,textarea{ background:#0d1117; color:inherit; ... }
//
//  Ở chế độ tối thì trông bình thường. Ở chế độ sáng, nền trang thành sáng,
//  chữ kế thừa màu tối của chủ đề sáng — nhưng ô nhập vẫn tối cứng. Kết quả:
//  CHỮ TỐI TRÊN NỀN TỐI, người dùng gõ mà gần như không đọc được mình gõ gì.
//
//  Bắt được khi chụp màn hình xưởng bài giảng và nhìn. Không mục kiểm nào
//  trước đó nhìn thấy, vì tất cả đều đọc HTML chứ không đọc MÀU.
//
//  Luật: trong ui/, màu nền và màu chữ phải đi qua biến chủ đề. Muốn một màu
//  cố định thật thì khai trong :root của styles.css để cả hai chế độ cùng
//  thấy, đừng chôn vào một trang.

/** Mã màu tối ghi cứng: #0xxxxx, #1xxxxx, #2xxxxx — đủ tối để nuốt chữ sáng. */
const MAU_TOI = /background\s*:\s*(#[0-2][0-9a-f]{5}\b)/gi;

/** Thuộc tính màu chỉ được nhận biến, không nhận mã màu ghi cứng. */
function soiMauMotTep(duongDan, noiDung) {
  const phat = [];
  const dong = noiDung.split('\n');
  for (let i = 0; i < dong.length; i++) {
    MAU_TOI.lastIndex = 0;
    let m;
    while ((m = MAU_TOI.exec(dong[i])) !== null) {
      phat.push({
        tep: duongDan, dong: i + 1, mau: m[1],
        trich: dong[i].trim().slice(0, 100),
      });
    }
  }
  return phat;
}

/**
 * Soi màu cả thư mục giao diện.
 *
 * styles.css ĐƯỢC MIỄN vì nó là nơi khai bảng màu: khối :root của nó phải
 * ghi mã màu thật, và khối @media bên dưới đổi chúng cho chế độ sáng. Miễn
 * đúng một tệp ấy, không miễn tệp nào khác.
 */
function soiMauThuMuc(thuMuc) {
  const phat = [];
  const tep = [];
  const di = (d) => {
    for (const m of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, m.name);
      if (m.isDirectory()) di(p);
      else if (/\.(html|css)$/.test(m.name)) tep.push(p);
    }
  };
  if (!fs.existsSync(thuMuc)) return { dat: true, phat, soTep: 0 };
  di(thuMuc);
  for (const t of tep) {
    if (path.basename(t) === 'styles.css') continue;
    phat.push(...soiMauMotTep(path.relative(thuMuc, t), fs.readFileSync(t, 'utf8')));
  }
  return { dat: phat.length === 0, phat, soTep: tep.length };
}

module.exports.soiMauThuMuc = soiMauThuMuc;
module.exports.soiMauMotTep = soiMauMotTep;
