'use strict';
/**
 * VÉ CHỐNG GIẢ MẠO BIỂU MẪU (CSRF) CHO KHU RIÊNG
 *
 * Khu riêng /nha xác thực bằng COOKIE. Trình duyệt gửi cookie kèm MỌI yêu cầu
 * tới gốc này — kể cả yêu cầu do một trang web lạ bắn sang. Không chặn thì một
 * trang bất kỳ có thể nộp hộ bài sàng lọc tâm lý của một đứa trẻ đang đăng
 * nhập, hoặc đẩy lộ trình học của em đi tiếp mấy bước.
 *
 * Hệ thống chặn bằng HAI lớp, và hai lớp này hỏng theo hai cách khác nhau —
 * đó mới là lý do có hai lớp:
 *
 *   Lớp 1 — dấu vết nguồn (Sec-Fetch-Site / Origin). Nằm ở src/index.js.
 *           Không cần đụng vào biểu mẫu, chặn được cả yêu cầu không phải
 *           biểu mẫu. Nhưng nó tin vào việc trình duyệt có gửi tiêu đề ấy.
 *
 *   Lớp 2 — VÉ trong biểu mẫu, chính là tệp này. Mỗi biểu mẫu mang một chuỗi
 *           mà chỉ phiên đang đăng nhập mới tính ra được. Trang lạ không đọc
 *           được cookie của gốc khác nên không tính được vé, dù nó có bắn
 *           được yêu cầu đi nữa.
 *
 * Vé là HMAC-SHA256 của CHÍNH token phiên. Hệ quả có chủ ý:
 *
 *   · Không cần lưu thêm gì. Không có bảng vé để rò, để hết hạn lệch, để đầy.
 *   · Vé chết đúng lúc phiên chết. Đăng xuất là mọi vé đã phát vô hiệu ngay.
 *   · Vé KHÔNG lần ngược ra được token phiên, nên nhúng vé vào HTML không
 *     phải là để lộ phiên.
 *
 * Bí mật ký vé lấy từ CSRF_SECRET nếu có; không có thì sinh ngẫu nhiên mỗi
 * lần khởi động. Sinh mới KHÔNG phải là lỗi ở đây: bảng phiên cũng nằm trong
 * bộ nhớ tiến trình, nên khởi động lại là mọi phiên đã mất — vé cũ không còn
 * gì để bảo vệ. Chỉ khi nào phiên được lưu xuống đĩa hoặc chạy nhiều tiến
 * trình thì CSRF_SECRET mới thành bắt buộc, và lúc ấy mục kiểm dưới đây phải
 * được siết lại theo.
 */
const crypto = require('node:crypto');

const TEN_O = 've';                       // tên ô ẩn trong biểu mẫu

// Ưu tiên khoá khai trong môi trường; khoá quá ngắn thì coi như không có, vì
// một khoá 6 ký tự cho cảm giác an toàn mà không cho sự an toàn.
//
// KHOÁ Ở ĐÂY ĐƯỢC DẪN XUẤT, KHÔNG DÙNG THẲNG. Bản trước lấy nguyên CSRF_SECRET
// làm khoá HMAC. Lúc ấy hệ thống chỉ có một việc cần khoá nên chưa thấy hại;
// nhưng ngày có việc thứ hai, cách viết ấy dẫn thẳng tới lỗi đã bắt được khi
// soi một bản thiết kế khác: một bí mật gánh hai việc, lộ một nơi mất cả hai.
//
// Dẫn xuất ngay từ bây giờ thì việc thứ hai không có cớ dùng ké. Xem
// src/an-toan/khoa-rieng.js — mỗi việc một nhãn, HKDF tách chúng ra.
const KR = require('../an-toan/khoa-rieng');

const KHAI = String(process.env.CSRF_SECRET || '');
const DU = KR.kiemBiMatGoc(KHAI).ok;
const TU_SINH = !DU;
// Bí mật gốc không đạt thì sinh một bí mật ngẫu nhiên đủ mạnh RỒI MỚI dẫn
// xuất — không đệm, không cắt, không dùng thẳng.
const GOC = DU ? KHAI : crypto.randomBytes(48).toString('base64url');
const BI_MAT = KR.khoaCho('VE_BIEU_MAU', GOC);

/**
 * Vé của một phiên. Không có phiên thì không có vé — và cũng không cần: chưa
 * đăng nhập thì không có gì để giả mạo hộ.
 */
function veCua(tokenPhien) {
  if (!tokenPhien) return null;
  return crypto.createHmac('sha256', BI_MAT).update(String(tokenPhien)).digest('base64url');
}

/**
 * Đối chiếu vé nhận được với vé đúng của phiên.
 *
 * So sánh bằng timingSafeEqual chứ không bằng `===`. So bằng `===` thì thời
 * gian trả lời phụ thuộc vào việc hai chuỗi giống nhau tới ký tự thứ mấy, và
 * người kiên nhẫn dò được từng ký tự một.
 */
function kiemVe(tokenPhien, veNhan) {
  const dung = veCua(tokenPhien);
  if (!dung || !veNhan) return false;
  const a = Buffer.from(String(veNhan), 'utf8');
  const b = Buffer.from(dung, 'utf8');
  // Khác độ dài thì timingSafeEqual ném lỗi, nên phải chặn trước. Độ dài vé là
  // cố định nên việc lộ "sai độ dài" không nói thêm được gì cho người dò.
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

/** Ô ẩn để nhúng thẳng vào biểu mẫu. Không có vé thì không nhúng ô rỗng. */
function oAn(ve) {
  if (!ve) return '';
  // Vé là base64url nên chỉ gồm A-Z a-z 0-9 - _ ; vẫn lọc lần nữa, vì một ngày
  // nào đó cách sinh vé có thể đổi, còn chỗ nhúng này thì không ai nhớ ra.
  const sach = String(ve).replace(/[^A-Za-z0-9_-]/g, '');
  return `<input type="hidden" name="${TEN_O}" value="${sach}">`;
}

/** Trạng thái để mục kiểm và lệnh chẩn đoán đọc — không in ra bí mật. */
function trangThai() {
  return {
    tenO: TEN_O,
    daiVe: veCua('mau-de-do-dai').length,
    cachDanKhoa: 'HKDF-SHA256 với nhãn việc VE_BIEU_MAU — không dùng thẳng bí mật gốc',
    nguonBiMat: TU_SINH ? 'sinh-moi-moi-lan-khoi-dong' : 'CSRF_SECRET',
    ghiChu: TU_SINH
      ? 'Bảng phiên cũng nằm trong bộ nhớ tiến trình, nên vé chết cùng lúc với phiên.'
      : 'Vé ký bằng khoá khai trong môi trường, sống qua lần khởi động lại.',
  };
}

module.exports = { TEN_O, veCua, kiemVe, oAn, trangThai };
