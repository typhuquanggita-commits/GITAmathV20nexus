'use strict';
/**
 * NĂM KÊNH CHẠM TỚI KHÁCH HÀNG
 *
 * Cùng một việc, nói qua kênh khác nhau thì thành hai việc khác nhau. Báo tin
 * "con vừa qua mốc" bằng tin nhắn là một lời thông báo; gọi điện nói đúng câu
 * ấy là một cuộc trò chuyện. Ngược lại, báo "sàng lọc tâm lý có dấu hiệu nặng"
 * qua tin nhắn là một sai lầm nghiêm trọng, dù nội dung có đúng tới đâu.
 *
 * Nên mỗi kênh ở đây khai rõ NÓ HỢP VỚI MỨC KHẨN NÀO. Bảng điểm chạm dùng đúng
 * khai báo ấy để CHẶN những ô không được dùng, chứ không chỉ gợi ý.
 */

const KENH = [
  {
    ma: 'K1', ten: 'Trong buổi học',
    ai: 'Hệ thống, ngay trên màn hình học viên',
    khiNao: 'Tức thì, đúng lúc việc xảy ra',
    doDai: 'Một tới hai câu',
    nguoiNhan: 'hoc-vien',
    hopVoiMuc: ['XANH', 'VANG'],
    manh: 'Đúng lúc. Lời khen cách sự việc ba ngày thì không còn là lời khen.',
    yeu: 'Không nói được chuyện của người lớn, và không ai nghe được giọng em.',
    camLam: [
      'CẤM nói chuyện tâm lý, chuyện tiền, chuyện gia đình qua kênh này.',
      'CẤM dừng buổi học để chen một thông báo không gấp.',
    ],
  },
  {
    ma: 'K2', ten: 'Tin nhắn cho gia đình',
    ai: 'Cố vấn đồng hành',
    khiNao: 'Trong ngày, trong giờ hành chính',
    doDai: 'Ba tới năm câu, có một việc cụ thể để nhà quan sát',
    nguoiNhan: 'gia-dinh',
    hopVoiMuc: ['XANH', 'VANG', 'CAM'],
    manh: 'Gia đình đọc được lúc rảnh và giữ lại được.',
    yeu: 'Không nghe được phản ứng. Tin nhắn mang tin xấu thường bị hiểu nặng hơn thực tế.',
    camLam: [
      'CẤM gửi kết quả sàng lọc tâm lý.',
      'CẤM gửi tin xấu kèm lời mời chào bất cứ thứ gì.',
      'CẤM gửi ngoài giờ, trừ việc mức đỏ.',
    ],
  },
  {
    ma: 'K3', ten: 'Cuộc gọi',
    ai: 'Cố vấn đồng hành hoặc người phụ trách lớp',
    khiNao: 'Trong 2 giờ với việc đỏ, trong ngày với việc cam',
    doDai: 'Năm tới mười phút, có chuẩn bị trước',
    nguoiNhan: 'gia-dinh',
    hopVoiMuc: ['CAM', 'DO'],
    manh: 'Nghe được giọng. Việc khó chỉ giải quyết được ở đây.',
    yeu: 'Làm phiền nếu gọi sai lúc, và không để lại bản ghi cho gia đình đọc lại.',
    camLam: [
      'CẤM gọi khi chưa có phương án. Cuộc gọi không có phương án thành ra đòi nợ.',
      'CẤM gọi để thông báo một tin vui nhỏ — việc ấy thuộc kênh tin nhắn.',
      'CẤM kết thúc mà không nhắn lại một dòng tóm tắt điều đã thống nhất.',
    ],
  },
  {
    ma: 'K4', ten: 'Buổi gặp',
    ai: 'Người phụ trách lớp, có giáo viên khi cần',
    khiNao: 'Hẹn trước, khi việc cần cả nhà cùng ngồi',
    doDai: 'Hai mươi tới bốn mươi phút',
    nguoiNhan: 'gia-dinh',
    hopVoiMuc: ['CAM', 'DO'],
    manh: 'Xem được bài làm thật cùng nhau, và chốt được điều cả nhà cùng làm.',
    yeu: 'Tốn thời gian của gia đình. Gọi họp cho việc nhỏ là tiêu lòng tin.',
    camLam: [
      'CẤM họp mà không có bài làm cụ thể mở ra xem.',
      'CẤM có mặt em nhỏ trong buổi bàn về áp lực gia đình.',
    ],
  },
  {
    ma: 'K5', ten: 'Báo cáo theo chặng',
    ai: 'Hệ thống dựng, người phụ trách lớp duyệt trước khi gửi',
    khiNao: 'Cuối mỗi chặng của lộ trình',
    doDai: 'Một trang, mốc cứng trước, phần chưa đạt sau',
    nguoiNhan: 'gia-dinh',
    hopVoiMuc: ['XANH', 'VANG'],
    manh: 'Cho thấy cả quãng đường, thứ mà tin nhắn hằng ngày không cho thấy.',
    yeu: 'Chậm. Không dùng được cho việc đang xảy ra.',
    camLam: [
      'CẤM để báo cáo thay cho một cuộc gọi đang cần.',
      'CẤM đưa mốc mềm lên phần đầu báo cáo.',
      'CẤM gửi báo cáo chưa có người đọc lại.',
    ],
  },
];

const INDEX = new Map(KENH.map((k) => [k.ma, k]));

/** Kênh này có dùng được cho mức khẩn kia không, và vì sao không. */
function dungDuoc(maKenh, maMuc) {
  const k = INDEX.get(String(maKenh).toUpperCase());
  if (!k) return { ok: false, lyDo: `Không có kênh "${maKenh}".` };
  if (k.hopVoiMuc.includes(String(maMuc).toUpperCase())) return { ok: true };
  return {
    ok: false,
    lyDo: `Kênh "${k.ten}" không hợp với việc mức ${maMuc}: ${k.yeu}`,
    dungKenhNao: KENH.filter((x) => x.hopVoiMuc.includes(String(maMuc).toUpperCase())).map((x) => x.ma),
  };
}

module.exports = { KENH, INDEX, dungDuoc };
