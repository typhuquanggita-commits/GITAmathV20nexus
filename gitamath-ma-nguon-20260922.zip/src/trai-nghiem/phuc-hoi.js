'use strict';
/**
 * PHỤC HỒI SAU SỰ CỐ — MƯỜI BƯỚC, VÀ THỨ TỰ LÀ BẮT BUỘC
 *
 * Khách hàng gặp sự cố rồi được xử lý tử tế thường trung thành hơn khách chưa
 * từng gặp sự cố. Nhưng điều đó CHỈ đúng khi làm đủ và đúng thứ tự. Nhảy sang
 * bước giải pháp khi khách chưa thấy mình được nghe thì giải pháp đúng cũng
 * bị từ chối — vì lúc ấy khách đang cần được công nhận, chưa cần được sửa.
 *
 * Bộ đếm ở đây không phải để đẹp biên bản. `buocKeTiep()` TỪ CHỐI cho nhảy
 * bước, vì bước bị bỏ là bước không ai quay lại làm.
 */

const BUOC = [
  { thu: 1, ten: 'Nghe hết', mucTieu: 'Khách nói xong điều họ cần nói',
    lam: 'Không ngắt lời, không giải thích xen vào, kể cả khi khách nói sai một chi tiết.',
    camLam: 'CẤM sửa chi tiết sai ngay lúc họ đang nói. Sửa sau, khi đã nghe hết.',
    xongKhi: 'Khách dừng lại và không thêm gì nữa' },
  { thu: 2, ten: 'Nhắc lại', mucTieu: 'Chắc là mình hiểu đúng',
    lam: 'Nhắc lại vấn đề bằng lời của mình và hỏi có đúng không.',
    camLam: 'CẤM nhắc lại theo kiểu thu nhỏ vấn đề.',
    xongKhi: 'Khách xác nhận đúng' },
  { thu: 3, ten: 'Công nhận cảm xúc', mucTieu: 'Khách thấy mình không vô lý',
    lam: 'Nói rõ chuyện này đáng bực, ở vị trí họ mình cũng vậy.',
    camLam: 'CẤM nói "em hiểu" rồi chuyển ngay sang giải thích. Đó là không hiểu.',
    xongKhi: 'Giọng khách hạ xuống' },
  { thu: 4, ten: 'Nhận việc', mucTieu: 'Có một người chịu trách nhiệm',
    lam: 'Nói tên mình và nói mình sẽ theo việc này tới khi xong.',
    camLam: 'CẤM chuyển khách sang bộ phận khác ở bước này.',
    xongKhi: 'Khách biết ai đang lo việc của họ' },
  { thu: 5, ten: 'Xin lỗi', mucTieu: 'Thừa nhận trải nghiệm chưa tốt',
    lam: 'Xin lỗi về đúng việc đã xảy ra, không xin lỗi chung chung.',
    camLam: 'CẤM xin lỗi kiểu "nếu có gì bất tiện". Câu đó nghĩa là chưa chắc có gì sai.',
    xongKhi: 'Lời xin lỗi đã nói ra, cụ thể' },
  { thu: 6, ten: 'Giải pháp', mucTieu: 'Vấn đề trước mắt được xử lý',
    lam: 'Đưa phương án kèm thời hạn cụ thể. Có từ hai phương án thì để khách chọn.',
    camLam: 'CẤM hứa thời hạn mình không chắc giữ được.',
    xongKhi: 'Khách đồng ý một phương án' },
  { thu: 7, ten: 'Bù đắp', mucTieu: 'Khôi phục phần giá trị đã mất',
    lam: 'Bù bằng thứ đúng với thứ họ mất: mất buổi thì bù buổi, mất công thì bù công.',
    camLam: 'CẤM bù bằng tiền khi chưa có người có thẩm quyền xác nhận — quyền Q08 hiện còn treo.',
    xongKhi: 'Việc bù đã làm xong, không phải đã hứa', canQuyen: 'Q08' },
  { thu: 8, ten: 'Theo tới cùng', mucTieu: 'Không bỏ khách sau khi xử lý',
    lam: 'Quay lại sau 3–7 ngày hỏi việc đã ổn chưa.',
    camLam: 'CẤM coi việc đã xong khi mình làm xong phần của mình.',
    xongKhi: 'Có một lần liên hệ lại và khách xác nhận' },
  { thu: 9, ten: 'Tìm gốc', mucTieu: 'Biết vì sao chuyện này xảy ra',
    lam: 'Tìm nguyên nhân trong hệ thống, không tìm người có lỗi.',
    camLam: 'CẤM dừng ở "do sơ suất". Sơ suất là triệu chứng, không phải nguyên nhân.',
    xongKhi: 'Có một nguyên nhân nêu được bằng một câu và sửa được' },
  { thu: 10, ten: 'Sửa hệ thống', mucTieu: 'Không tái diễn',
    lam: 'Cập nhật quy trình hoặc mã, và ghi lại lần sự cố này làm căn cứ.',
    camLam: 'CẤM đóng hồ sơ khi chưa có thay đổi nào được ghi lại. Không có thay đổi thì nó sẽ xảy ra lại.',
    xongKhi: 'Có một thay đổi cụ thể được ghi lại' },
];

/**
 * Bước kế tiếp. TỪ CHỐI cho nhảy bước — bước bị bỏ là bước không ai quay lại làm.
 */
function buocKeTiep(daXong = []) {
  const xong = new Set(daXong.map(Number));
  const thieu = BUOC.filter((b) => !xong.has(b.thu)).map((b) => b.thu);
  if (!thieu.length) return { xongHet: true, nhac: 'Đủ mười bước. Hồ sơ đóng được.' };
  const keTiep = BUOC.find((b) => b.thu === thieu[0]);
  const nhayCoc = [...xong].filter((n) => n > keTiep.thu);
  return {
    xongHet: false,
    buoc: keTiep,
    conThieu: thieu,
    canhBao: nhayCoc.length
      ? `Đã làm bước ${nhayCoc.join(', ')} trong khi bước ${keTiep.thu} (${keTiep.ten}) chưa xong. `
        + 'Nhảy bước ở đây làm giải pháp đúng vẫn bị từ chối, vì khách chưa thấy mình được nghe.'
      : null,
  };
}

module.exports = { BUOC, buocKeTiep };
