'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HỘP CÔNG CỤ CỦA TRỢ LÝ TRÒ CHUYỆN — đọc dữ liệu THẬT, hoặc nói "chưa có"
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Mười hai công cụ. Mỗi công cụ đọc thẳng một kho dữ liệu đang chạy của hệ
 *  này. Không công cụ nào sinh số, không công cụ nào đắp thêm cho đẹp câu trả
 *  lời, và khi kho rỗng thì nó nói KHO RỖNG chứ không trả về một con số 0
 *  trông như đã đếm.
 *
 *  Phân biệt ấy quan trọng hơn vẻ ngoài của nó: "chưa có dữ liệu" và "có dữ
 *  liệu và bằng không" là hai câu trả lời khác hẳn nhau với một phụ huynh
 *  đang hỏi con mình tuần này học được bao nhiêu.
 *
 *  ── MỖI CÔNG CỤ KHAI PHẠM VI, VÀ PHẠM VI ẤY ĐƯỢC CƯỠNG CHẾ ──────────────
 *
 *  Công cụ khai `chamAi`; khiên việc so nó với việc đang hỏi; lính gác canh
 *  không cho phạm vi rộng ra giữa chừng. Ba chỗ cùng đọc một khai báo — nới
 *  một chỗ mà quên hai chỗ kia thì không đi qua được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');

/** Trả lời chuẩn khi kho chưa có gì. Không bao giờ đắp số. */
const khoRong = (nguon, goi) => ({
  ok: true, coDuLieu: false, nguon,
  noi: `Chưa có dữ liệu trong ${nguon}.`,
  goi: goi || 'Chưa dùng tới phần này thì chưa có gì để xem — đây không phải lỗi.',
});

/**
 * PHẠM VI của từng công cụ, khai TĨNH.
 *
 * Tách ra khỏi thân công cụ vì một lý do cụ thể: bảng việc ở khiên việc phải
 * đối chiếu được với bảng này MÀ KHÔNG cần dựng cả hệ thống lên. Để phạm vi
 * nằm lẫn trong thân hàm thì phép đối chiếu ấy chỉ chạy được lúc hệ đã khởi
 * động xong — tức là quá muộn, vì lúc ấy một việc khai sai đã có thể chạy rồi.
 *
 * Lỗi CÓ THẬT mà cách tách này bắt được: việc "hỏi về chương trình học" khai
 * phạm vi "chung" nhưng lại liệt công cụ đọc lộ trình — thứ chạm dữ liệu
 * riêng của một học viên. Lính gác chặn đúng, nhưng nó chặn một câu hỏi công
 * khai hoàn toàn vô can, vì cái sai nằm ở BẢNG chứ không ở câu hỏi.
 */
const PHAM_VI_CONG_CU = {
  'doc-trang-cong-khai': 'chung',
  'doc-chuong-trinh': 'chung',
  'doc-lo-trinh': 'minh',
  'doc-so-do-tu-duy': 'chung',
  'doc-tien-do': 'minh',
  'doc-bai-da-lam': 'minh',
  'doc-bao-cao': 'pham-vi',
  'doc-lop': 'pham-vi',
  'doc-hoc-lieu': 'pham-vi',
  'doc-suc-khoe': 'chung',
  'doc-bang-gia-cong-khai': 'chung',
  'ghi-phieu-ho-tro': 'minh',
};

/**
 * Bảng công cụ. `chamAi` lấy thẳng từ PHAM_VI_CONG_CU — một nguồn duy nhất,
 * nên không thể có chuyện thân công cụ khai một đằng, bảng đối chiếu một nẻo.
 */
function dungHop(N) {
  const hop = {
    'doc-trang-cong-khai': {
      ten: 'Đọc trang giới thiệu công khai',
      chay: () => {
        const web = require('../web/site');
        const t = typeof web.status === 'function' ? web.status() : null;
        return t ? { ok: true, coDuLieu: true, trang: t } : khoRong('trang công khai');
      },
    },
    'doc-chuong-trinh': {
      ten: 'Đọc chương trình học',
      chay: ({ ma = null } = {}) => {
        const H = require('../curriculum/hierarchy');
        if (ma) {
          const f = H.FORM_INDEX.get(ma);
          return f
            ? { ok: true, coDuLieu: true, dang: { ma: f.code, ten: f.name, tang: f.levelRange, canTruoc: f.prereq || [], soBay: (f.traps || []).length } }
            : { ok: true, coDuLieu: false, noi: `Không có dạng "${ma}" trong chương trình.` };
        }
        return { ok: true, coDuLieu: true, soDang: H.FORMS.length, soTang: H.LEVELS.length, soKhoi: H.BLOCKS.length };
      },
    },
    'doc-lo-trinh': {
      ten: 'Đọc lộ trình học',
      chay: ({ nguoiHocId = null } = {}) => {
        if (!nguoiHocId || !N.roadmap) return khoRong('lộ trình', 'Cần biết học viên nào mới đọc được lộ trình.');
        const r = N.roadmap.get(nguoiHocId);
        if (!r || !r.ok) return khoRong('lộ trình của học viên này', 'Học viên chưa được dựng lộ trình.');
        return { ok: true, coDuLieu: true, loTrinh: { tuan: r.currentWeek || null, tong: r.weeks ? r.weeks.length : null } };
      },
    },
    'doc-so-do-tu-duy': {
      ten: 'Đọc sơ đồ tư duy ba chiều',
      chay: ({ goc = null } = {}) => {
        const S = require('../so-do-tu-duy/so-do');
        const s = goc ? S.dung({ kieu: 'duong-di', goc }) : S.dung({ kieu: 'toan-canh' });
        if (!s.ok) return { ok: true, coDuLieu: false, noi: s.lyDo || s.loi };
        return { ok: true, coDuLieu: true, soNut: s.thongKe.soNut, soCanh: s.thongKe.soCanh, kieu: s.kieu };
      },
    },
    'doc-tien-do': {
      ten: 'Đọc tiến độ học',
      chay: ({ nguoiHocId = null } = {}) => {
        if (!nguoiHocId || !N.mastery) return khoRong('tiến độ', 'Cần biết học viên nào.');
        const s = N.mastery.summary(nguoiHocId);
        if (!s || !s.total) return khoRong('tiến độ của học viên này', 'Em này chưa làm bài nào nên chưa có gì để đo.');
        return { ok: true, coDuLieu: true, tienDo: { soDang: s.total, thanhThao: s.mastered ?? null, dangHoc: s.learning ?? null } };
      },
    },
    'doc-bai-da-lam': {
      ten: 'Đọc bài đã làm',
      chay: ({ nguoiHocId = null } = {}) => {
        if (!nguoiHocId || !N.attempts) return khoRong('bài đã làm', 'Cần biết học viên nào.');
        const q = typeof N.attempts.query === 'function'
          ? N.attempts.query({ learnerId: nguoiHocId, limit: 20 }) : null;
        const ds = (q && (q.items || q)) || [];
        if (!ds.length) return khoRong('bài đã làm của học viên này');
        const dung = ds.filter((a) => a.correct).length;
        return { ok: true, coDuLieu: true, soBai: ds.length, soDung: dung, tiLe: round(dung / ds.length, 3) };
      },
    },
    'doc-bao-cao': {
      ten: 'Đọc báo cáo',
      chay: ({ nguoiHocId = null } = {}) => {
        if (!nguoiHocId || !N.reports) return khoRong('báo cáo', 'Cần biết học viên nào.');
        const r = N.reports.learner(nguoiHocId);
        if (!r || r.ok === false) return khoRong('báo cáo của học viên này');
        return { ok: true, coDuLieu: true, baoCao: { tong: r.summary || null } };
      },
    },
    'doc-lop': {
      ten: 'Đọc thông tin lớp',
      chay: ({ lopId = null } = {}) => {
        if (!N.classes) return khoRong('danh sách lớp');
        if (lopId) {
          const l = N.classes.get(lopId);
          return l ? { ok: true, coDuLieu: true, lop: { id: l.id, ten: l.name, siSo: (l.learnerIds || []).length } }
            : { ok: true, coDuLieu: false, noi: `Không có lớp "${lopId}".` };
        }
        const n = N.classes.count();
        return n ? { ok: true, coDuLieu: true, soLop: n } : khoRong('danh sách lớp');
      },
    },
    'doc-hoc-lieu': {
      ten: 'Đọc kho học liệu',
      chay: () => {
        if (!N.bank) return khoRong('kho học liệu');
        const s = N.bank.status();
        return s && s.total ? { ok: true, coDuLieu: true, kho: { tong: s.total, daXuatBan: s.published ?? null } }
          : khoRong('kho học liệu');
      },
    },
    'doc-suc-khoe': {
      ten: 'Đọc tình trạng hệ thống',
      chay: () => ({ ok: true, coDuLieu: true, heThong: { phienBan: N.cfg.VERSION, chayDuoc: true } }),
    },
    'doc-bang-gia-cong-khai': {
      ten: 'Đọc bảng giá công khai',
      chay: () => {
        // Sổ cái dòng tiền là kho NỘI BỘ. Công cụ này chỉ lấy phần bảng giá
        // đã được công bố; số liệu điều hành không đi qua đây.
        if (!N.soCai || typeof N.soCai.status !== 'function') return khoRong('bảng giá công khai');
        const s = N.soCai.status();
        const g = s && s.bangGia;
        return g ? { ok: true, coDuLieu: true, bangGia: g }
          : khoRong('bảng giá công khai', 'Bảng giá chưa được công bố. Không suy ra từ sổ nội bộ.');
      },
    },
    'ghi-phieu-ho-tro': {
      ten: 'Ghi một phiếu hỗ trợ', ghi: true,
      chay: ({ noiDung = '', nguoiGui = null } = {}) => {
        if (!N.crm || !N.crm.kho) {
          return { ok: true, coDuLieu: false, noi: 'Ban hỗ trợ chưa sẵn sàng nên em chưa ghi phiếu được.' };
        }
        const t = String(noiDung).trim();
        if (t.length < 10) {
          return { ok: false, error: 'NOI_DUNG_QUA_NGAN',
            noi: 'Anh/chị mô tả giúp em rõ hơn một chút để em ghi phiếu đúng ạ.' };
        }
        const p = N.crm.kho.them('yeu-cau', { noiDung: t, nguoiGui, nguon: 'tro-chuyen', giaiDoan: 'moi' });
        return { ok: true, coDuLieu: true, phieu: { id: p.id || p, daGhi: true } };
      },
    },
  };

  // Đóng dấu phạm vi từ bảng TĨNH. Công cụ nào không có trong bảng thì đây là
  // lỗi lập trình, không phải trường hợp cần đoán — nên ném ra ngay lúc dựng
  // chứ không để nó lặng lẽ thành `undefined` rồi qua mặt lính gác.
  for (const [ma, c] of Object.entries(hop)) {
    if (!PHAM_VI_CONG_CU[ma]) throw new Error(`Công cụ "${ma}" chưa khai phạm vi trong PHAM_VI_CONG_CU`);
    c.chamAi = PHAM_VI_CONG_CU[ma];
  }
  for (const ma of Object.keys(PHAM_VI_CONG_CU)) {
    if (!hop[ma]) throw new Error(`PHAM_VI_CONG_CU khai công cụ "${ma}" mà hộp không có`);
  }
  return hop;
}

/** Danh sách công cụ để in ra cho người quản trị đọc. */
function danhSach(N) {
  return Object.entries(dungHop(N)).map(([ma, c]) => ({
    ma, ten: c.ten, chamAi: c.chamAi, ghi: !!c.ghi,
  }));
}

module.exports = { dungHop, danhSach, khoRong, PHAM_VI_CONG_CU };
