'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LỚP 3 — KHIÊN VIỆC  (Task Shield)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Lớp này đổi câu hỏi phòng thủ từ "hành động này có HẠI không" sang "hành
 *  động này có PHỤC VỤ điều người dùng đang hỏi không". Đổi câu hỏi là điểm
 *  mấu chốt: kẻ chèn lệnh không cần làm việc gì trông có vẻ xấu — nó chỉ cần
 *  khiến trợ lý làm một việc mà người dùng KHÔNG hỏi.
 *
 *      Phụ huynh hỏi:  "Con tôi tuần này học thế nào?"
 *      Trợ lý định làm: đọc hồ sơ tâm lý của một học viên khác
 *
 *  Việc thứ hai không "xấu" theo bất kỳ danh sách từ cấm nào. Nó chỉ đơn giản
 *  KHÔNG phải việc vừa được hỏi. Và đó là tất cả những gì cần để chặn.
 *
 *  ── VÌ SAO KHAI BẢNG THAY VÌ HỎI MÔ HÌNH ────────────────────────────────
 *
 *  Bản gốc hỏi một mô hình ngôn ngữ "ALIGNED hay DEVIATED". Ở đây không làm
 *  thế, vì ba lý do đều là lý do thật:
 *
 *  1. Mô hình trả lời KHÔNG TẤT ĐỊNH. Cùng một hành động, hôm nay ALIGNED,
 *     mai DEVIATED. Một bức tường đổi ý theo ngày thì không phải bức tường.
 *  2. Chính mô hình ấy là thứ đang bị tấn công. Nhờ nó gác cửa cho chính nó
 *     là nhờ người đang bị lừa tự kiểm tra xem mình có bị lừa không.
 *  3. Bảng khai được ĐỌC ĐƯỢC. Người quản trị mở ra xem việc nào chạm được
 *     công cụ nào; hỏi mô hình thì không ai xem được gì.
 *
 *  Bảng này cùng lối với bảng định tuyến của ban quan hệ gia đình, và cũng
 *  cùng một luật cứng: VIỆC CHƯA KHAI thì KHÔNG công cụ nào được gọi.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/**
 * Bảng việc. Mỗi việc khai rõ:
 *   ten      đọc được, để in ra cho người quản trị
 *   congCu   công cụ được phép gọi — ngoài danh sách này là chặn
 *   chamAi   phạm vi dữ liệu: 'minh' chỉ của chính mình, 'pham-vi' phần được
 *            giao (lớp mình dạy, con mình), 'chung' dữ liệu công khai
 *   vaiToiThieu  vai thấp nhất được hỏi việc này
 */
const { PHAM_VI_CONG_CU } = require('./cong-cu');

const BANG_VIEC = {
  'hoi-chung': {
    ten: 'Hỏi chung về hệ thống',
    congCu: ['doc-trang-cong-khai', 'doc-chuong-trinh'],
    chamAi: 'chung', vaiToiThieu: 'GUEST',
  },
  'hoi-chuong-trinh': {
    ten: 'Hỏi về chương trình học',
    // KHÔNG có doc-lo-trinh ở đây. Bản đầu có, và nó là một lỗi thật: lộ
    // trình là của MỘT học viên cụ thể, còn câu hỏi "chương trình có những
    // dạng nào" là câu hỏi công khai bất kỳ ai cũng hỏi được. Một việc công
    // khai mà liệt một công cụ chạm dữ liệu riêng thì hoặc là việc ấy phải
    // đóng lại, hoặc là công cụ ấy không thuộc về nó. Ở đây là vế sau.
    congCu: ['doc-chuong-trinh', 'doc-so-do-tu-duy'],
    chamAi: 'chung', vaiToiThieu: 'GUEST',
  },
  'hoi-tien-do-minh': {
    ten: 'Hỏi tiến độ học của chính mình',
    congCu: ['doc-tien-do', 'doc-bai-da-lam', 'doc-lo-trinh'],
    chamAi: 'minh', vaiToiThieu: 'LEARNER',
  },
  'hoi-tien-do-con': {
    ten: 'Phụ huynh hỏi tiến độ của con',
    congCu: ['doc-tien-do', 'doc-bai-da-lam', 'doc-bao-cao'],
    chamAi: 'pham-vi', vaiToiThieu: 'PARENT',
  },
  'hoi-lop': {
    ten: 'Giáo viên hỏi về lớp mình dạy',
    congCu: ['doc-lop', 'doc-tien-do', 'doc-bao-cao', 'doc-hoc-lieu'],
    chamAi: 'pham-vi', vaiToiThieu: 'TEACHER',
  },
  'xin-goi-y-hoc': {
    ten: 'Xin gợi ý nên học gì tiếp',
    congCu: ['doc-tien-do', 'doc-lo-trinh', 'doc-so-do-tu-duy'],
    chamAi: 'minh', vaiToiThieu: 'LEARNER',
  },
  'bao-truc-trac': {
    ten: 'Báo trục trặc kỹ thuật',
    congCu: ['doc-suc-khoe', 'ghi-phieu-ho-tro'],
    chamAi: 'minh', vaiToiThieu: 'LEARNER',
  },
  'hoi-hoc-phi': {
    ten: 'Hỏi về học phí và gói',
    congCu: ['doc-bang-gia-cong-khai'],
    chamAi: 'chung', vaiToiThieu: 'GUEST',
  },
};

/**
 * Công cụ KHÔNG BAO GIỜ được một lượt trò chuyện gọi, dù việc nào.
 *
 * Đây không phải "chưa khai" — đây là khai thẳng rằng CẤM. Hai thứ khác nhau:
 * chưa khai là sót, cấm là quyết định. Viết ra để không ai vô tình thêm vào
 * bảng trên rồi nghĩ mình chỉ đang mở thêm một việc nhỏ.
 */
const CAM_TUYET_DOI = {
  'doc-tam-ly': 'Dữ liệu sàng lọc tâm lý của một em nhỏ. Không một cuộc trò chuyện nào được chạm vào.',
  'doc-cay-tien': 'Phân loại nội bộ về khả năng chi trả của gia đình. Khách hàng không được thấy.',
  'gui-thu': 'Nhắn ra ngoài hệ thống. Luôn phải có người duyệt, không bao giờ do máy tự làm.',
  'xoa-du-lieu': 'Không lùi lại được. Ảnh chụp hệ thống lui về được tới ba mươi ngày, '
    + 'nhưng thứ xoá sau lần chụp cuối thì mất hẳn — và dữ liệu học tập của một em nhỏ '
    + 'không dựng lại được từ đâu cả.',
  'cap-quyen': 'Một lệnh sai lan ra toàn hệ.',
  'doi-mat-khau': 'Đi qua cổng việc nguy hiểm, không đi qua khung chat.',
};

const THU_BAC_VAI = { GUEST: 0, LEARNER: 1, PARENT: 1, TEACHER: 2, ADMIN: 3 };

/** Độ rộng của phạm vi dữ liệu. Phải trùng với thang của lính gác. */
const RONG = { chung: 0, minh: 1, 'pham-vi': 2 };

class KhienViec {
  constructor() {
    this.soChan = 0;
    this.theoLyDo = new Map();
  }

  /** Việc này có trong bảng không, và vai ấy có được hỏi không. */
  nhanViec(maViec, vai) {
    const v = BANG_VIEC[maViec];
    if (!v) {
      return { dat: false, ma: 'viec-chua-khai',
        vi: `Việc "${maViec}" chưa có trong bảng. Việc chưa khai thì không công cụ nào được gọi — `
          + 'đây là mặc định ĐÓNG, không phải lỗi.' };
    }
    const can = THU_BAC_VAI[v.vaiToiThieu] ?? 3;
    const co = THU_BAC_VAI[vai] ?? 0;
    if (co < can) {
      return { dat: false, ma: 'vai-khong-du',
        vi: 'Việc này không mở cho vai đang hỏi.' };
    }
    return { dat: true, viec: v };
  }

  /**
   * Hành động sắp làm có phục vụ đúng việc đang hỏi không.
   *
   * @returns {{dat:boolean, ma:string, vi:string}}
   */
  soiHanhDong(maViec, congCu, { vai = 'GUEST' } = {}) {
    if (CAM_TUYET_DOI[congCu]) {
      return this._chan('cam-tuyet-doi',
        `Công cụ "${congCu}" bị cấm trong mọi cuộc trò chuyện. ${CAM_TUYET_DOI[congCu]}`);
    }
    const n = this.nhanViec(maViec, vai);
    if (!n.dat) return this._chan(n.ma, n.vi);
    if (!n.viec.congCu.includes(congCu)) {
      return this._chan('lech-viec',
        `Việc "${n.viec.ten}" không dùng tới công cụ "${congCu}". `
        + 'Một hành động không phục vụ điều vừa được hỏi là dấu hiệu có lệnh chèn vào giữa chừng.');
    }
    return { dat: true, ma: 'dung-viec', vi: '' };
  }

  /** Lọc cả một mẻ hành động, giữ lại những cái đúng việc. */
  loc(maViec, dsCongCu, o = {}) {
    const giu = [];
    const bo = [];
    for (const c of dsCongCu) {
      const r = this.soiHanhDong(maViec, c, o);
      (r.dat ? giu : bo).push({ congCu: c, ...r });
    }
    return { giu: giu.map((x) => x.congCu), bo };
  }

  _chan(ma, vi) {
    this.soChan += 1;
    this.theoLyDo.set(ma, (this.theoLyDo.get(ma) || 0) + 1);
    return { dat: false, ma, vi };
  }

  /** Soi chính bảng: mọi công cụ khai ra phải không nằm trong danh sách cấm. */
  static soiBang() {
    const loi = [];
    for (const [ma, v] of Object.entries(BANG_VIEC)) {
      if (!v.ten || !v.congCu.length) loi.push(`việc ${ma} khai thiếu`);
      if (!(v.vaiToiThieu in THU_BAC_VAI)) loi.push(`việc ${ma} khai vai lạ: ${v.vaiToiThieu}`);
      if (!['minh', 'pham-vi', 'chung'].includes(v.chamAi)) loi.push(`việc ${ma} khai phạm vi lạ`);
      for (const c of v.congCu) {
        if (CAM_TUYET_DOI[c]) loi.push(`việc ${ma} khai công cụ đã bị cấm tuyệt đối: ${c}`);
      }
      // Việc chạm dữ liệu riêng mà mở cho khách là một lỗ thủng.
      if (v.chamAi !== 'chung' && v.vaiToiThieu === 'GUEST') {
        loi.push(`việc ${ma} chạm dữ liệu riêng mà lại mở cho khách chưa đăng nhập`);
      }
      // ── Phép đối chiếu bắt được lỗi CÓ THẬT của bản đầu ──
      //
      // Việc khai phạm vi X mà liệt một công cụ có phạm vi RỘNG HƠN X thì
      // lính gác sẽ chặn ngay bước ấy — và nó chặn một câu hỏi vô can, vì
      // cái sai nằm ở bảng này chứ không ở câu hỏi. Bắt tại đây, lúc soi
      // bảng, thì người sửa biết ngay phải sửa chỗ nào.
      for (const c of v.congCu) {
        const pv = PHAM_VI_CONG_CU[c];
        if (!pv) { loi.push(`việc ${ma} gọi công cụ "${c}" chưa khai phạm vi`); continue; }
        if ((RONG[pv] ?? 9) > (RONG[v.chamAi] ?? 0)) {
          loi.push(`việc ${ma} khai phạm vi "${v.chamAi}" mà công cụ "${c}" chạm tới "${pv}" — rộng hơn`);
        }
      }
    }
    return { dat: loi.length === 0, loi, soViec: Object.keys(BANG_VIEC).length, soCam: Object.keys(CAM_TUYET_DOI).length };
  }

  status() {
    return {
      soViec: Object.keys(BANG_VIEC).length,
      soCongCuCam: Object.keys(CAM_TUYET_DOI).length,
      soChan: this.soChan,
      theoLyDo: Object.fromEntries(this.theoLyDo),
      tatDinh: true,
    };
  }
}

module.exports = KhienViec;
module.exports.BANG_VIEC = BANG_VIEC;
module.exports.CAM_TUYET_DOI = CAM_TUYET_DOI;
