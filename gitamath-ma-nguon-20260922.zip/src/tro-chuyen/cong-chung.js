'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SỔ CÔNG CHỨNG — ký từng dòng, móc xích vào nhau
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Hệ này đã có một cuốn nhật ký móc xích. Cuốn ấy chứng minh được rằng KHÔNG
 *  AI SỬA GIỮA CHỪNG: đổi một dòng cũ là mọi mã băm sau đó lệch hết.
 *
 *  Nhưng nó KHÔNG chứng minh được một điều khác, và điều ấy mới là điều cần
 *  khi có tranh chấp: dòng này do CHÍNH HỆ THỐNG NÀY ghi, chứ không phải ai
 *  đó dựng lại cả cuốn sổ từ đầu. Một chuỗi băm thì người có quyền ghi đè cả
 *  tệp vẫn dựng lại được sạch sẽ — vì băm không cần bí mật nào.
 *
 *  Chữ ký Ed25519 bịt đúng chỗ ấy. Ai cũng KIỂM được bằng khoá công khai,
 *  nhưng chỉ chỗ giữ khoá riêng mới KÝ được. Dựng lại cả cuốn sổ mà không có
 *  khoá riêng thì mọi dòng đều không kiểm được.
 *
 *  ── VÌ SAO Ed25519 VÀ VÌ SAO KHÔNG THÊM GÓI NÀO ─────────────────────────
 *
 *  node:crypto có sẵn Ed25519 từ Node 12. Không cài gì thêm. Chữ ký 64 byte,
 *  ký nhanh, và không có tham số nào để đặt sai — khác hẳn RSA hay ECDSA,
 *  nơi một lựa chọn sai lặng lẽ làm hỏng cả chữ ký.
 *
 *  ── ĐIỀU SỔ NÀY KHÔNG LÀM, NÓI THẲNG ────────────────────────────────────
 *
 *  Nó KHÔNG chứng minh được nội dung ghi vào là ĐÚNG SỰ THẬT. Nó chỉ chứng
 *  minh được rằng nội dung ấy do hệ thống này ghi, vào thứ tự ấy, và không ai
 *  sửa sau đó. Một lời nói dối được ký vẫn là một lời nói dối — chỉ là một
 *  lời nói dối không chối được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const crypto = require('node:crypto');

/** Băm ổn định: khoá sắp theo thứ tự, để cùng dữ liệu ra cùng chuỗi. */
function chuoiOnDinh(x) {
  if (x === null || typeof x !== 'object') return JSON.stringify(x);
  if (Array.isArray(x)) return `[${x.map(chuoiOnDinh).join(',')}]`;
  return `{${Object.keys(x).sort().map((k) => `${JSON.stringify(k)}:${chuoiOnDinh(x[k])}`).join(',')}}`;
}

class SoCongChung {
  /**
   * @param {object} o
   * @param {string} o.khoaRieng  khoá riêng dạng PEM. Không có thì tự sinh —
   *                              tiện cho lúc chạy thử, nhưng khoá ấy mất theo
   *                              tiến trình nên bản chạy thật phải khai vào.
   * @param {number} o.giuToiDa   giữ bao nhiêu dòng trong bộ nhớ
   */
  constructor({ khoaRieng = null, giuToiDa = 5000, bayGio = () => Date.now() } = {}) {
    if (khoaRieng) {
      this.khoa = crypto.createPrivateKey(khoaRieng);
      this.tuSinh = false;
    } else {
      this.khoa = crypto.generateKeyPairSync('ed25519').privateKey;
      this.tuSinh = true;
    }
    this.khoaCong = crypto.createPublicKey(this.khoa);
    this.giuToiDa = giuToiDa;
    this.bayGio = bayGio;
    this.soDong = [];
    this.bamCuoi = 'khoi-nguyen';
    this.tong = 0;
  }

  /** Ghi một dòng và ký nó. */
  ghi(viec) {
    const than = {
      viec,
      luc: new Date(this.bayGio()).toISOString(),
      soThuTu: this.tong,
      bamTruoc: this.bamCuoi,
    };
    const byte = Buffer.from(chuoiOnDinh(than), 'utf8');
    const bam = crypto.createHash('sha256').update(byte).digest('hex');
    const chuKy = crypto.sign(null, byte, this.khoa).toString('base64');

    const dong = { than, bam, chuKy };
    this.soDong.push(dong);
    if (this.soDong.length > this.giuToiDa) this.soDong.shift();
    this.bamCuoi = bam;
    this.tong += 1;
    return dong;
  }

  /** Kiểm một dòng: chữ ký có đúng khoá này ký không, băm có khớp không. */
  kiem(dong) {
    if (!dong || !dong.than || !dong.chuKy) return { dat: false, vi: 'dòng thiếu phần' };
    const byte = Buffer.from(chuoiOnDinh(dong.than), 'utf8');
    const bam = crypto.createHash('sha256').update(byte).digest('hex');
    if (bam !== dong.bam) {
      return { dat: false, vi: 'mã băm không khớp nội dung — dòng đã bị sửa sau khi ghi' };
    }
    let ky = false;
    try {
      ky = crypto.verify(null, byte, this.khoaCong, Buffer.from(dong.chuKy, 'base64'));
    } catch { ky = false; }
    if (!ky) return { dat: false, vi: 'chữ ký không phải do hệ thống này ký' };
    return { dat: true };
  }

  /** Kiểm cả cuốn: từng dòng, VÀ mối nối giữa các dòng. */
  kiemCaCuon() {
    const loi = [];
    for (const [i, d] of this.soDong.entries()) {
      const r = this.kiem(d);
      if (!r.dat) loi.push(`dòng ${d.than.soThuTu}: ${r.vi}`);
      if (i > 0 && d.than.bamTruoc !== this.soDong[i - 1].bam) {
        loi.push(`dòng ${d.than.soThuTu}: mối nối đứt — có dòng bị rút ra hoặc chèn vào`);
      }
    }
    return { dat: loi.length === 0, loi, soDong: this.soDong.length, tong: this.tong };
  }

  /** Khoá công khai, để nơi khác tự kiểm mà không cần hỏi hệ thống này. */
  khoaCongKhai() {
    return this.khoaCong.export({ type: 'spki', format: 'pem' }).toString();
  }

  ganDay({ gioiHan = 50 } = {}) {
    return this.soDong.slice(-gioiHan).map((d) => ({
      soThuTu: d.than.soThuTu, luc: d.than.luc, viec: d.than.viec, bam: d.bam.slice(0, 16),
    }));
  }

  status() {
    return {
      thuatToan: 'Ed25519',
      tong: this.tong,
      dangGiu: this.soDong.length,
      khoaTuSinh: this.tuSinh,
      canhBao: this.tuSinh
        ? 'Khoá riêng đang TỰ SINH theo tiến trình — khởi động lại là mọi chữ ký cũ không kiểm được nữa. '
          + 'Bản chạy thật phải khai CHU_KY_SO_KHOA_RIENG.'
        : null,
      khongLamGi: 'Sổ này chứng minh dòng do hệ thống này ghi và không ai sửa. '
        + 'Nó KHÔNG chứng minh nội dung ghi vào là đúng sự thật.',
    };
  }
}

module.exports = SoCongChung;
module.exports.chuoiOnDinh = chuoiOnDinh;
