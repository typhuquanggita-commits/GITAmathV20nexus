'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐIỀU PHỐI TRÒ CHUYỆN — chín cửa cho một lượt hỏi
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Một lượt trò chuyện đi qua chín cửa, theo đúng thứ tự này, và KHÔNG cửa
 *  nào bỏ qua được:
 *
 *      1. Lọc đầu vào          hình dạng tấn công
 *      2. Hàng rào nhắc lại    lệnh giấu trong câu
 *      3. Đọc ý → kế hoạch     khai TRƯỚC sẽ gọi những gì
 *      4. Khiên việc           mỗi công cụ có phục vụ đúng việc không
 *      5. Mở lượt cho lính gác ghi kế hoạch xuống để về sau so
 *      6. Chạy từng bước       lính gác soi từng bước một
 *      7. Soạn câu trả lời     CHỈ từ dữ liệu vừa đọc được
 *      8. Canh đường ra        che số riêng, chặn hứa hẹn và chẩn đoán
 *      9. Ký vào sổ công chứng cả lượt, không chối được
 *
 *  ── ĐIỀU QUAN TRỌNG NHẤT, NÓI THẲNG ─────────────────────────────────────
 *
 *  Trợ lý này KHÔNG bịa. Câu trả lời được soạn TỪ kết quả công cụ trả về; kho
 *  rỗng thì nó nói rỗng. Nếu về sau ai nối một mô hình ngôn ngữ vào để câu
 *  chữ mượt hơn, mô hình ấy vẫn phải đi qua cửa 8, và dữ liệu vẫn phải đến từ
 *  cửa 6 — mô hình được phép đổi CÁCH NÓI, không được phép đổi ĐIỀU NÓI.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const LocVao = require('./loc-vao');
const HangRao = require('./hang-rao');
const KhienViec = require('./khien-viec');
const CanhRa = require('./canh-ra');
const LinhGac = require('./linh-gac');
const SoCongChung = require('./cong-chung');
const { dungKeHoach } = require('./ke-hoach');
const { dungHop } = require('./cong-cu');
const { id: newId } = require('../utils');

class DieuPhoiTroChuyen {
  constructor({ N, nhacLai = null, khoaRieng = null }) {
    this.N = N;
    this.loc = new LocVao();
    this.hangRao = new HangRao({ nhacLai });
    this.khien = new KhienViec();
    this.canh = new CanhRa();
    this.gac = new LinhGac();
    this.so = new SoCongChung({ khoaRieng });
    this.hop = dungHop(N);
    this.thongKe = { luot: 0, chan: 0, theoCua: {} };
  }

  _chan(cua, ket, phien) {
    this.thongKe.chan += 1;
    this.thongKe.theoCua[cua] = (this.thongKe.theoCua[cua] || 0) + 1;
    const dong = this.so.ghi({ loai: 'chan', cua, ma: ket.ma, phienId: phien });
    return {
      ok: true, biChan: true, cua, ma: ket.ma, lyDo: ket.vi,
      traLoi: cua === 'canh-ra' ? this.canh.loiThay(ket) : this.loc.loiTuChoi(ket),
      phienId: phien, chuKy: dong.bam.slice(0, 16),
    };
  }

  /**
   * Chạy một lượt.
   *
   * @param {object} o
   * @param {string} o.cauHoi
   * @param {string} o.vai        vai của người đang hỏi
   * @param {string} o.nguoiHocId học viên mà câu hỏi nói tới, nếu có
   */
  async hoi({ cauHoi, vai = 'GUEST', nguoiHocId = null, phienId = null } = {}) {
    const t0 = Date.now();
    const phien = phienId || newId('tc');
    this.thongKe.luot += 1;

    // ── Cửa 1 ──
    const c1 = this.loc.soi(cauHoi);
    if (!c1.dat) return this._chan('loc-vao', c1, phien);

    // ── Cửa 2 ──
    const c2 = await this.hangRao.soi(cauHoi);
    if (!c2.dat) return this._chan('hang-rao', c2, phien);

    // ── Cửa 3 ──
    const kh = dungKeHoach(cauHoi, { vai });
    if (!kh.ok) return this._chan('ke-hoach', { ma: kh.loi, vi: 'Không dựng được kế hoạch cho câu này.' }, phien);

    // ── Cửa 4 ──
    const nhan = this.khien.nhanViec(kh.viec, vai);
    if (!nhan.dat) return this._chan('khien-viec', nhan, phien);
    const loc = this.khien.loc(kh.viec, kh.congCu, { vai });
    if (loc.bo.length) return this._chan('khien-viec', loc.bo[0], phien);

    // ── Cửa 5 ──
    const luot = this.gac.moLuot(kh);

    // ── Cửa 6 ──
    const ketCongCu = [];
    let viecCho = null;
    for (const b of kh.buoc) {
      const cc = this.hop[b.congCu];
      if (!cc) return this._chan('cong-cu-khong-co', { ma: 'cong-cu-khong-co', vi: `Không có công cụ "${b.congCu}".` }, phien);

      const g = this.gac.ghiBuoc(luot, { congCu: b.congCu, chamAi: cc.chamAi });
      if (!g.dat) return this._chan('linh-gac', g, phien);

      if (b.dungLaiHoiNguoi) {
        // Việc ghi KHÔNG chạy trong lượt. Nó thành một việc chờ người duyệt.
        viecCho = { congCu: b.congCu, ten: cc.ten, trangThai: 'cho-nguoi-duyet' };
        ketCongCu.push({ congCu: b.congCu, ten: cc.ten, hoan: true,
          vi: 'Việc này ghi vào sổ nhà nên luôn chờ người duyệt, không do máy tự làm.' });
        continue;
      }

      let r;
      try {
        r = cc.chay({ nguoiHocId, cauHoi });
      } catch (e) {
        r = { ok: false, error: 'CONG_CU_HONG', noi: `Công cụ "${cc.ten}" gặp lỗi: ${e.message}` };
      }
      ketCongCu.push({ congCu: b.congCu, ten: cc.ten, ...r });
    }
    const dong = this.gac.dongLuot(luot);

    // ── Cửa 7 ──
    const traLoiTho = this._soan(kh, ketCongCu, { viecCho });

    // ── Cửa 8 ──
    const c8 = this.canh.soi(traLoiTho, { vai });
    if (!c8.dat) return this._chan('canh-ra', c8, phien);

    // ── Cửa 9 ──
    const buttoan = this.so.ghi({
      loai: 'luot', phienId: phien, viec: kh.viec, vai,
      congCuDaGoi: ketCongCu.map((k) => k.congCu),
      coDuLieu: ketCongCu.filter((k) => k.coDuLieu).length,
      canNguoiDuyet: !!viecCho,
    });

    return {
      ok: true, biChan: false, phienId: phien,
      viec: kh.viec, tenViec: kh.tenViec,
      docYChacChan: kh.docYChacChan,
      cheDoHangRao: c2.cheDo,
      traLoi: c8.chu,
      daCheSoRieng: c8.daChe.length,
      congCuDaGoi: ketCongCu.map((k) => ({ congCu: k.congCu, coDuLieu: !!k.coDuLieu, hoan: !!k.hoan })),
      soCongCuCoDuLieu: ketCongCu.filter((k) => k.coDuLieu).length,
      canNguoiDuyet: !!viecCho, viecCho,
      duongDi: dong,
      chuKy: buttoan.bam.slice(0, 16),
      ms: Date.now() - t0,
    };
  }

  /**
   * Soạn câu trả lời TỪ kết quả công cụ.
   *
   * Không một câu nào ở đây nói điều mà công cụ không trả về. Chỗ nào kho
   * rỗng thì câu trả lời nói rỗng — và nói luôn rằng rỗng không phải là lỗi.
   */
  _soan(kh, ket, { viecCho }) {
    const co = ket.filter((k) => k.coDuLieu);
    const rong = ket.filter((k) => k.ok !== false && !k.coDuLieu && !k.hoan);

    if (!co.length && !viecCho) {
      const nguon = rong.map((r) => r.ten).join(', ');
      return `Dạ, em tra ${nguon || 'các nguồn liên quan'} nhưng chưa có dữ liệu nào ạ. `
        + 'Chưa dùng tới phần này thì chưa có gì để xem — đây không phải lỗi của anh/chị. '
        + 'Khi nào có số liệu em báo lại ngay ạ.';
    }

    const y = [];
    for (const k of co) {
      if (k.soDang) y.push(`chương trình hiện có ${k.soDang} dạng toán chia theo ${k.soTang} tầng`);
      if (k.dang) y.push(`dạng ${k.dang.ma} — ${k.dang.ten}, cần biết trước ${k.dang.canTruoc.length} dạng`);
      if (k.tienDo) y.push(`đã chạm ${k.tienDo.soDang} dạng`
        + (k.tienDo.thanhThao != null ? `, thành thạo ${k.tienDo.thanhThao}` : ''));
      if (k.soBai) y.push(`hai mươi bài gần nhất làm đúng ${k.soDung}/${k.soBai}`);
      if (k.loTrinh) y.push(`lộ trình đang ở tuần ${k.loTrinh.tuan ?? '—'}`);
      if (k.soNut) y.push(`sơ đồ tư duy có ${k.soNut} dạng và ${k.soCanh} quan hệ tiên quyết`);
      if (k.soLop) y.push(`hệ thống đang có ${k.soLop} lớp`);
      if (k.lop) y.push(`lớp ${k.lop.ten} có ${k.lop.siSo} học viên`);
      if (k.kho) y.push(`kho học liệu có ${k.kho.tong} bài`);
      if (k.bangGia) y.push('bảng giá công khai đã có, em gửi anh/chị xem ạ');
      if (k.heThong) y.push(`hệ thống đang chạy bản ${k.heThong.phienBan}`);
      if (k.trang) y.push('trang giới thiệu đang mở bình thường');
    }

    let s = y.length ? `Dạ, em tra được: ${y.join('; ')}.` : 'Dạ, em đã tra xong ạ.';
    if (rong.length) {
      s += ` Riêng ${rong.map((r) => r.ten.toLowerCase()).join(' và ')} thì chưa có dữ liệu.`;
    }
    if (viecCho) {
      s += ' Em đã ghi lại việc này và chuyển cho người phụ trách duyệt — em không tự gửi đi được ạ.';
    }
    return s;
  }

  status() {
    return {
      cua: 9,
      lop: {
        'loc-vao': this.loc.status(),
        'hang-rao': this.hangRao.status(),
        'khien-viec': this.khien.status(),
        'canh-ra': this.canh.status(),
        'linh-gac': this.gac.status(),
      },
      soCongChung: this.so.status(),
      soCongCu: Object.keys(this.hop).length,
      thongKe: this.thongKe,
    };
  }
}

module.exports = DieuPhoiTroChuyen;
