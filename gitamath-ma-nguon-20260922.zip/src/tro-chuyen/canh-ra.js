'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LỚP 4 — CANH ĐƯỜNG RA
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Ba lớp trước canh đường VÀO. Lớp này canh đường RA, và nó cần thiết vì một
 *  lý do đơn giản: ba lớp kia có thể bỏ sót, còn chỗ này là chỗ cuối cùng
 *  trước khi chữ rời khỏi hệ thống và tới mắt một người.
 *
 *  BỐN THỨ KHÔNG ĐƯỢC PHÉP ĐI RA:
 *
 *  1. SỐ ĐIỆN THOẠI, EMAIL, CĂN CƯỚC của người khác. Trợ lý đọc dữ liệu thật
 *     nên nó hoàn toàn có thể vô tình đọc to lên số của một phụ huynh khác.
 *  2. PHÂN LOẠI NỘI BỘ về gia đình. Đây là bức tường đã có sẵn của hệ này —
 *     lớp này gọi lại đúng bức tường ấy chứ không dựng bức tường thứ hai.
 *  3. LỜI HỨA KẾT QUẢ. "Học hai tuần là con giỏi toán" là câu không ai được
 *     phép nói, kể cả khi người dùng vừa xin đúng một câu như thế.
 *  4. CHẨN ĐOÁN. Trợ lý không được nói một đứa trẻ "bị" gì.
 *
 *  ── CHE SỐ CHỨ KHÔNG BỎ CÂU ─────────────────────────────────────────────
 *
 *  Với số riêng tư, lớp này CHE chứ không chặn cả câu: người dùng vẫn nhận
 *  được câu trả lời, chỉ là chỗ số bị thay bằng nhãn. Chặn cả câu vì một dãy
 *  số là phạt người hỏi vì lỗi của máy.
 *
 *  Với bốn nhóm còn lại thì CHẶN, vì không có cách nào che một lời hứa sai.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const tuong = require('../cay-tien/buc-tuong');

/**
 * Số riêng tư. Viết riêng cho Việt Nam, không bê nguyên mẫu nước ngoài:
 *   · số di động bắt đầu bằng 0 hoặc +84, 9–10 chữ số sau
 *   · căn cước 12 số (từ 2021) và chứng minh 9 số (bản cũ vẫn còn dùng)
 */
const SO_RIENG = [
  { ma: 'SỐ_ĐIỆN_THOẠI', re: /(?:\+84|0)\d{9}\b/g },
  { ma: 'EMAIL', re: /\b[\w.+-]+@[\w-]+\.[\w.]{2,}\b/g },
  { ma: 'CĂN_CƯỚC', re: /\b\d{12}\b/g },
  { ma: 'CHỨNG_MINH', re: /\b\d{9}\b/g },
];

/**
 * Lời hứa kết quả. Bắt HÌNH DẠNG "trong <số> <đơn vị> ... <kết quả tốt>",
 * vì đó là khuôn mà mọi lời hứa sai đều rơi vào.
 */
const HUA_KET_QUA = [
  { re: /(trong|chỉ|sau)\s+\d+\s*(ngày|tuần|tháng|buổi)[^.!?]{0,80}(giỏi|thành\s*thạo|đứng\s*đầu|điểm\s*(10|mười)|ngoan|nghe\s*lời|hết\s*(mất\s*gốc|dốt))/i,
    vi: 'Câu hứa một kết quả trong một khoảng thời gian. Không ai biết trước được, và ba mẹ sẽ tin.' },
  { re: /(cam\s*kết|bảo\s*đảm|đảm\s*bảo|chắc\s*chắn)\s+[^.!?]{0,40}(giỏi|tiến\s*bộ|đạt|lên\s*lớp|đỗ)/i,
    vi: 'Câu cam kết một kết quả học tập. Hệ thống này không cam kết kết quả của một con người.' },
  { re: /(100\s*%|tuyệt\s*đối)\s+[^.!?]{0,30}(hiệu\s*quả|thành\s*công|tiến\s*bộ)/i,
    vi: 'Con số tuyệt đối về hiệu quả học tập là con số không có thật.' },
];

/** Chẩn đoán. Trợ lý không được nói một em nhỏ "bị" gì. */
const CHAN_DOAN = [
  // `\w` là lớp ký tự ASCII, nên "nhà mình" KHÔNG khớp — chữ "ì" rơi ra
  // ngoài. Bản đầu vì thế bỏ lọt đúng câu thường gặp nhất: "Cháu nhà mình bị
  // tăng động". Dùng \p{L} với cờ u để nhận cả chữ Việt có dấu.
  { re: /(bé|con|em|cháu|học\s*viên)\s+(nhà\s+[\p{L}]+\s+)?(bị|mắc)\s+(tăng\s*động|tự\s*kỷ|ADHD|khó\s*đọc|chậm\s*phát\s*triển|rối\s*loạn|trầm\s*cảm|lo\s*âu)/iu,
    vi: 'Đây là chẩn đoán y tế. Chỉ người có chuyên môn và có mặt trực tiếp mới được nói.' },
  { re: /(chẩn\s*đoán|kết\s*luận)\s+(là\s+)?(cháu|bé|con|em)\s+/iu,
    vi: 'Trợ lý không chẩn đoán.' },
];

class CanhRa {
  constructor({ tuongRoRi = tuong } = {}) {
    this.tuong = tuongRoRi;
    this.soChe = 0;
    this.soChan = 0;
    this.theoLyDo = new Map();
  }

  /**
   * @returns {{dat:boolean, chu:string, daChe:Array, ma?:string, vi?:string}}
   */
  soi(text, { vai = 'GUEST' } = {}) {
    const goc = String(text == null ? '' : text);

    for (const h of HUA_KET_QUA) {
      if (h.re.test(goc)) return this._chan('hua-ket-qua', h.vi);
    }
    for (const c of CHAN_DOAN) {
      if (c.re.test(goc)) return this._chan('chan-doan', c.vi);
    }

    // Bức tường phân loại nội bộ — gọi lại đúng bức tường đã có của hệ này.
    const roRi = this.tuong.soiRoRi(goc);
    if (!roRi.sach) {
      return this._chan('lo-phan-loai-noi-bo',
        'Câu trả lời mang theo cách hệ thống phân loại gia đình trong nội bộ. '
        + `Cụm bị bắt: ${(roRi.roRi || []).slice(0, 2).map((r) => r.cum || r).join(', ')}`);
    }

    // Che số riêng tư — che chứ không chặn.
    let chu = goc;
    const daChe = [];
    for (const s of SO_RIENG) {
      chu = chu.replace(s.re, (m) => { daChe.push({ ma: s.ma, dai: m.length }); return `[${s.ma}_ĐÃ_CHE]`; });
    }
    if (daChe.length) this.soChe += daChe.length;

    return { dat: true, chu, daChe };
  }

  _chan(ma, vi) {
    this.soChan += 1;
    this.theoLyDo.set(ma, (this.theoLyDo.get(ma) || 0) + 1);
    return { dat: false, chu: '', daChe: [], ma, vi };
  }

  /** Câu nói thay khi bị chặn. Không đổ lỗi người hỏi, và mở một lối khác. */
  loiThay(ket) {
    if (ket.ma === 'hua-ket-qua') {
      return 'Em không nói trước được kết quả học của một em nhỏ ạ — điều đó phụ thuộc vào rất nhiều '
        + 'thứ mà không ai đoán được. Em kể anh/chị nghe hệ thống theo dõi tiến bộ thế nào nhé?';
    }
    if (ket.ma === 'chan-doan') {
      return 'Em không được phép nói một em nhỏ đang gặp vấn đề gì về sức khoẻ ạ. '
        + 'Việc ấy cần người có chuyên môn gặp trực tiếp. Em hỗ trợ anh/chị về phần học được không ạ?';
    }
    return 'Câu trả lời vừa rồi em giữ lại để soát thêm ạ. Anh/chị hỏi lại giúp em theo cách khác nhé.';
  }

  status() {
    return {
      soKhuonHua: HUA_KET_QUA.length,
      soKhuonChanDoan: CHAN_DOAN.length,
      soLoaiSoRieng: SO_RIENG.length,
      soLanChe: this.soChe,
      soChan: this.soChan,
      theoLyDo: Object.fromEntries(this.theoLyDo),
    };
  }
}

module.exports = CanhRa;
module.exports.SO_RIENG = SO_RIENG;
module.exports.HUA_KET_QUA = HUA_KET_QUA;
module.exports.CHAN_DOAN = CHAN_DOAN;
