'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CBOR — bộ đọc tối thiểu, đủ cho WebAuthn và KHÔNG hơn một byte
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  WebAuthn gói dữ liệu chứng thực bằng CBOR (RFC 8949). Hệ này không phụ
 *  thuộc một gói ngoài nào, nên phải tự đọc.
 *
 *  BỘ ĐỌC NÀY CỐ TÌNH HẸP. Nó chỉ hiểu đúng những kiểu WebAuthn dùng: số
 *  nguyên, số nguyên âm, chuỗi byte, chuỗi chữ, mảng, bảng ánh xạ. Mọi kiểu
 *  khác — số thực, thẻ ngữ nghĩa, độ dài bất định — đều bị TỪ CHỐI chứ không
 *  bỏ qua.
 *
 *  Vì sao hẹp lại là an toàn hơn: đây là mã đọc dữ liệu từ bên ngoài, trong
 *  đường đăng nhập. Một bộ đọc "hiểu mọi thứ" là một bề mặt tấn công rộng;
 *  mỗi kiểu thừa là một nhánh mã chưa ai soi mà kẻ tấn công được phép gọi
 *  tới. Từ chối sớm thì nhánh ấy không tồn tại.
 *
 *  BỐN HÀNG RÀO chống dữ liệu độc:
 *    · Độ dài khai báo phải nằm trong phần dữ liệu còn lại — không tin số khai
 *    · Độ sâu lồng nhau có trần, chống dữ liệu đệ quy làm tràn ngăn xếp
 *    · Số phần tử của mảng và bảng có trần
 *    · Đọc xong phải hết byte, thừa một byte là từ chối — dữ liệu thừa phía
 *      sau là một mẹo cũ để nhét thêm nội dung mà bộ kiểm không nhìn tới
 * ═══════════════════════════════════════════════════════════════════════════
 */

const SAU_TOI_DA = 16;
const PHAN_TU_TOI_DA = 1000;
const CHUOI_TOI_DA = 64 * 1024;

class LoiCbor extends Error {}

function doc(buf) {
  if (!Buffer.isBuffer(buf)) throw new LoiCbor('CBOR: cần một Buffer');
  const tt = { i: 0, buf };
  const ra = _giaTri(tt, 0);
  if (tt.i !== buf.length) {
    throw new LoiCbor(`CBOR: còn thừa ${buf.length - tt.i} byte sau khi đọc xong`);
  }
  return ra;
}

/** Đọc có mang theo vị trí kết thúc — WebAuthn cần biết authData dừng ở đâu. */
function docMotPhan(buf, tuViTri = 0) {
  const tt = { i: tuViTri, buf };
  const ra = _giaTri(tt, 0);
  return { giaTri: ra, den: tt.i };
}

function _byte(tt) {
  if (tt.i >= tt.buf.length) throw new LoiCbor('CBOR: hết dữ liệu giữa chừng');
  return tt.buf[tt.i++];
}

function _doc(tt, soByte) {
  if (tt.i + soByte > tt.buf.length) throw new LoiCbor('CBOR: hết dữ liệu giữa chừng');
  const b = tt.buf.subarray(tt.i, tt.i + soByte);
  tt.i += soByte;
  return b;
}

/** Đọc phần "độ dài" của một mục. Từ chối độ dài bất định. */
function _doDai(tt, phu) {
  if (phu < 24) return phu;
  if (phu === 24) return _byte(tt);
  if (phu === 25) return _doc(tt, 2).readUInt16BE(0);
  if (phu === 26) return _doc(tt, 4).readUInt32BE(0);
  if (phu === 27) {
    const n = _doc(tt, 8).readBigUInt64BE(0);
    // Số lớn hơn khoảng an toàn của JavaScript thì mọi phép so sánh sau đó
    // đều không còn đáng tin. Từ chối, đừng làm tròn.
    if (n > BigInt(Number.MAX_SAFE_INTEGER)) throw new LoiCbor('CBOR: số vượt khoảng an toàn');
    return Number(n);
  }
  if (phu === 31) throw new LoiCbor('CBOR: độ dài bất định không được phép');
  throw new LoiCbor(`CBOR: mã độ dài ${phu} không hợp lệ`);
}

function _giaTri(tt, sau) {
  if (sau > SAU_TOI_DA) throw new LoiCbor('CBOR: lồng nhau quá sâu');
  const dau = _byte(tt);
  const loai = dau >> 5;
  const phu = dau & 0x1f;

  switch (loai) {
    case 0: return _doDai(tt, phu);                     // số nguyên không âm
    case 1: return -1 - _doDai(tt, phu);                // số nguyên âm
    case 2: {                                           // chuỗi byte
      const n = _doDai(tt, phu);
      if (n > CHUOI_TOI_DA) throw new LoiCbor('CBOR: chuỗi byte quá dài');
      return Buffer.from(_doc(tt, n));
    }
    case 3: {                                           // chuỗi chữ
      const n = _doDai(tt, phu);
      if (n > CHUOI_TOI_DA) throw new LoiCbor('CBOR: chuỗi chữ quá dài');
      return _doc(tt, n).toString('utf8');
    }
    case 4: {                                           // mảng
      const n = _doDai(tt, phu);
      if (n > PHAN_TU_TOI_DA) throw new LoiCbor('CBOR: mảng quá nhiều phần tử');
      const ra = [];
      for (let k = 0; k < n; k++) ra.push(_giaTri(tt, sau + 1));
      return ra;
    }
    case 5: {                                           // bảng ánh xạ
      const n = _doDai(tt, phu);
      if (n > PHAN_TU_TOI_DA) throw new LoiCbor('CBOR: bảng quá nhiều mục');
      const ra = new Map();
      for (let k = 0; k < n; k++) {
        const khoa = _giaTri(tt, sau + 1);
        if (typeof khoa !== 'string' && typeof khoa !== 'number') {
          throw new LoiCbor('CBOR: khoá bảng phải là chuỗi hoặc số');
        }
        // Khoá trùng là dấu hiệu dữ liệu bị dựng để đánh lừa: bộ đọc này lấy
        // giá trị nào, bộ đọc khác lấy giá trị nào — hai bên hiểu khác nhau.
        if (ra.has(khoa)) throw new LoiCbor(`CBOR: khoá "${khoa}" xuất hiện hai lần`);
        ra.set(khoa, _giaTri(tt, sau + 1));
      }
      return ra;
    }
    case 7: {                                           // giá trị đơn giản
      if (phu === 20) return false;
      if (phu === 21) return true;
      if (phu === 22) return null;
      throw new LoiCbor(`CBOR: giá trị đơn giản ${phu} không được phép`);
    }
    default:
      throw new LoiCbor(`CBOR: kiểu ${loai} không được phép trong WebAuthn`);
  }
}

module.exports = { doc, docMotPhan, LoiCbor, SAU_TOI_DA, PHAN_TU_TOI_DA };
