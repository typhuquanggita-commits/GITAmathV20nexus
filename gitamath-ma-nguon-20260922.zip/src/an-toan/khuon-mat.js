'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐĂNG NHẬP BẰNG KHUÔN MẶT THẬT — và vì sao KHÔNG so khớp ở máy chủ
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  YÊU CẦU: nhận diện khuôn mặt THẬT, không qua ảnh.
 *
 *  CÓ HAI CÁCH LÀM, VÀ CHÚNG KHÁC NHAU VỀ BẢN CHẤT.
 *
 *  ── Cách thứ nhất: máy chủ tự so khớp khuôn mặt ────────────────────────
 *
 *  Trình duyệt chụp ảnh, gửi lên, máy chủ trích đặc trưng và so với đặc trưng
 *  đã lưu. Muốn chống ảnh giả thì thêm "kiểm tra sống": bảo người dùng chớp
 *  mắt, quay đầu, cười.
 *
 *  Cách này hỏng ở ba chỗ, và cả ba đều nặng:
 *
 *  1. KIỂM TRA SỐNG KIỂU ẤY KHÔNG CHỐNG ĐƯỢC ẢNH. Nó chống được ảnh in, còn
 *     một đoạn VIDEO quay sẵn trên điện thoại thì chớp mắt, quay đầu và cười
 *     đủ cả. Camera thường chỉ thấy màu, không thấy chiều sâu, nên không phân
 *     biệt được mặt người với màn hình phát lại mặt người. Kết quả là một lớp
 *     bảo vệ TRÔNG NHƯ THẬT mà không thật — thứ nguy hiểm hơn không có gì,
 *     vì người ta tin vào nó.
 *
 *  2. NÓ BẮT HỆ THỐNG GIỮ SINH TRẮC HỌC CỦA TRẺ EM. Đặc trưng khuôn mặt là
 *     dữ liệu sinh trắc học, và Nghị định 13/2023/NĐ-CP xếp nó vào nhóm dữ
 *     liệu cá nhân NHẠY CẢM. Của trẻ em thì nhạy cảm gấp đôi. Mật khẩu lộ thì
 *     đổi được; khuôn mặt lộ thì không đổi được, và đứa trẻ mang hậu quả ấy
 *     suốt đời. Một kho như vậy là một kho rò rỉ đang chờ ngày xảy ra.
 *
 *  3. NÓ CẦN MỘT MÔ HÌNH HỌC MÁY. Hệ này không phụ thuộc một gói ngoài nào —
 *     đó là luật, không phải sở thích.
 *
 *  ── Cách thứ hai: để phần cứng của máy làm, đây là cách được chọn ───────
 *
 *  WebAuthn với bộ xác thực CÓ SẴN TRONG MÁY: Windows Hello Face, Touch ID,
 *  Face ID.
 *
 *  · Windows Hello Face dùng camera HỒNG NGOẠI đo chiều sâu. Ảnh in không
 *    qua được. Màn hình điện thoại phát video cũng không qua được — vì nó
 *    phẳng, và cảm biến hồng ngoại thấy điều đó. Đây đúng là "khuôn mặt thật,
 *    không phải ảnh", và nó thật ở TẦNG PHẦN CỨNG chứ không ở một đoạn mã
 *    đoán xem người dùng có chớp mắt hay không.
 *
 *  · Đặc trưng khuôn mặt KHÔNG BAO GIỜ rời khỏi máy người dùng. Nó nằm trong
 *    vùng bảo mật của con chip. Máy chủ chỉ nhận một KHOÁ CÔNG KHAI — thứ lộ
 *    ra cũng không làm gì được. Không có kho sinh trắc học nào để rò.
 *
 *  · Không cần một gói phụ thuộc nào. Trình duyệt và hệ điều hành đã có sẵn.
 *
 *  · Đây là tiêu chuẩn ngân hàng đang dùng.
 *
 *  ── BA ĐIỀU KIỆN BẮT BUỘC, VÀ MÁY CHỦ TỰ KIỂM LẠI CẢ BA ────────────────
 *
 *  Trình duyệt được YÊU CẦU ba điều, nhưng yêu cầu không phải bảo đảm — kẻ
 *  tấn công gửi thẳng gói tin thì không có trình duyệt nào để mà yêu cầu. Nên
 *  máy chủ kiểm lại từ dữ liệu đã ký:
 *
 *    1. Cờ UV (đã xác minh người dùng) phải bật. Đây là chỗ phân biệt SINH
 *       TRẮC HỌC với một mã PIN — không có cờ này thì có thể chỉ là gõ PIN.
 *    2. Bộ xác thực phải là loại GẮN TRONG MÁY, không phải khoá cắm rời.
 *    3. Bộ đếm lần ký phải TĂNG. Không tăng nghĩa là có bản sao của khoá.
 *
 *  ── ĐIỀU HỆ THỐNG NÀY KHÔNG LÀM, NÓI THẲNG ────────────────────────────
 *
 *  Máy chủ KHÔNG biết khuôn mặt ai. Nó chỉ biết: một bộ xác thực gắn trong
 *  máy, đã xác minh người dùng bằng sinh trắc học, và giữ khoá riêng khớp với
 *  khoá công khai đã đăng ký. Cụ thể là vân tay hay khuôn mặt thì do người
 *  dùng chọn lúc cài Windows Hello, và máy chủ không được biết — đó là điều
 *  đúng đắn, không phải thiếu sót.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const crypto = require('node:crypto');
const { doc: docCbor, docMotPhan } = require('./cbor');

/** Thách thức sống bao lâu. Ngắn có chủ ý: đủ để người dùng chạm, không đủ để ai đó mang đi. */
const THACH_THUC_SONG_MS = 120_000;

/** Thuật toán chữ ký được nhận. Số âm là mã COSE. */
const THUAT_TOAN = {
  '-7': { ten: 'ES256', kieu: 'ec', duong: 'prime256v1', bam: 'sha256' },
  '-257': { ten: 'RS256', kieu: 'rsa', bam: 'sha256' },
};

/** Cờ trong authData. */
const CO = { UP: 0x01, UV: 0x04, BE: 0x08, BS: 0x10, AT: 0x40, ED: 0x80 };

const b64url = (b) => Buffer.from(b).toString('base64url');
const tuB64url = (s) => Buffer.from(String(s), 'base64url');

/** So hai chuỗi bằng thời gian không đổi. */
function bangNhau(a, b) {
  const x = Buffer.from(String(a), 'utf8');
  const y = Buffer.from(String(b), 'utf8');
  if (x.length !== y.length) return false;
  return crypto.timingSafeEqual(x, y);
}

// ═══════════════════════════════════════════════════════════════════════════
//  ĐỌC authData
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Tách authData.
 *
 * Bố cục cố định: 32 byte băm định danh máy chủ, 1 byte cờ, 4 byte bộ đếm,
 * rồi phần dữ liệu khoá nếu cờ AT bật.
 */
function docAuthData(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 37) {
    throw new Error('authData quá ngắn — không phải dữ liệu WebAuthn hợp lệ');
  }
  const rpIdHash = buf.subarray(0, 32);
  const co = buf[32];
  const boDem = buf.readUInt32BE(33);
  const ra = {
    rpIdHash,
    co,
    coMat: !!(co & CO.UP),              // người dùng có mặt
    daXacMinh: !!(co & CO.UV),          // đã xác minh bằng sinh trắc học hoặc PIN
    coKhoa: !!(co & CO.AT),
    boDem,
  };
  if (!ra.coKhoa) return ra;

  if (buf.length < 55) throw new Error('authData khai có khoá nhưng không đủ dữ liệu');
  ra.aaguid = buf.subarray(37, 53);
  const dai = buf.readUInt16BE(53);
  // Mốc 1023 là trần chuẩn WebAuthn đặt cho mã định danh khoá. Tin vào số
  // khai mà không chặn thì một số lớn cắt luôn ra ngoài vùng dữ liệu.
  if (dai === 0 || dai > 1023 || 55 + dai > buf.length) {
    throw new Error(`Độ dài mã khoá không hợp lệ: ${dai}`);
  }
  ra.maKhoa = buf.subarray(55, 55 + dai);
  const { giaTri, den } = docMotPhan(buf, 55 + dai);
  ra.khoaCose = giaTri;
  // Phần mở rộng đứng sau khoá; không dùng, nhưng phải đọc đúng biên.
  if (!(co & CO.ED) && den !== buf.length) {
    throw new Error('authData có byte thừa sau khoá công khai');
  }
  return ra;
}

/** Dựng khoá công khai dùng được từ bảng COSE. */
function dungKhoaCong(cose) {
  if (!(cose instanceof Map)) throw new Error('Khoá công khai không phải bảng COSE');
  const kty = cose.get(1);
  const alg = cose.get(3);
  const spec = THUAT_TOAN[String(alg)];
  if (!spec) throw new Error(`Thuật toán ký ${alg} không được nhận`);

  if (spec.kieu === 'ec') {
    if (kty !== 2) throw new Error('Khoá ES256 phải thuộc họ đường cong elliptic');
    if (cose.get(-1) !== 1) throw new Error('ES256 phải dùng đường cong P-256');
    const x = cose.get(-2);
    const y = cose.get(-3);
    if (!Buffer.isBuffer(x) || !Buffer.isBuffer(y) || x.length !== 32 || y.length !== 32) {
      throw new Error('Toạ độ khoá elliptic không hợp lệ');
    }
    const khoa = crypto.createPublicKey({
      key: { kty: 'EC', crv: 'P-256', x: b64url(x), y: b64url(y) },
      format: 'jwk',
    });
    return { khoa, spec };
  }

  if (kty !== 3) throw new Error('Khoá RS256 phải thuộc họ RSA');
  const n = cose.get(-1);
  const e = cose.get(-2);
  if (!Buffer.isBuffer(n) || !Buffer.isBuffer(e)) throw new Error('Tham số khoá RSA không hợp lệ');
  if (n.length < 256) throw new Error('Khoá RSA ngắn hơn 2048 bit — không nhận');
  const khoa = crypto.createPublicKey({
    key: { kty: 'RSA', n: b64url(n), e: b64url(e) },
    format: 'jwk',
  });
  return { khoa, spec };
}

/** Kiểm clientDataJSON — phần trình duyệt ký cùng. */
function kiemClientData(chuoiB64, kieuMongDoi, thachThuc, cacGocChoPhep) {
  let j;
  try {
    j = JSON.parse(tuB64url(chuoiB64).toString('utf8'));
  } catch {
    throw new Error('clientDataJSON không đọc được');
  }
  if (j.type !== kieuMongDoi) throw new Error(`Kiểu thao tác sai: mong "${kieuMongDoi}", nhận "${j.type}"`);
  if (!bangNhau(j.challenge, thachThuc)) throw new Error('Thách thức không khớp — có thể là gói tin phát lại');
  if (!cacGocChoPhep.includes(j.origin)) {
    throw new Error(`Gốc "${j.origin}" không nằm trong danh sách cho phép`);
  }
  // Cờ này nghĩa là trình duyệt nghi có người đứng giữa. Tin nó.
  if (j.tokenBinding && j.tokenBinding.status === 'present' && !j.tokenBinding.id) {
    throw new Error('Ràng buộc kênh khai là có mà không có mã — nghi có người đứng giữa');
  }
  return j;
}

// ═══════════════════════════════════════════════════════════════════════════
//  BỘ GIỮ THÁCH THỨC
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Thách thức dùng MỘT LẦN rồi bỏ.
 *
 * Giữ trong bộ nhớ tiến trình, không ghi xuống đĩa: thách thức sống hai phút,
 * còn ghi xuống đĩa thì nó sống qua cả lần khởi động lại — đúng thứ không nên
 * sống lâu. Đổi lại, chạy nhiều tiến trình thì phải chuyển sang kho dùng
 * chung; ghi rõ ở đây để ngày ấy không ai phải đoán.
 */
class KhoThachThuc {
  constructor({ songMs = THACH_THUC_SONG_MS, bayGio = () => Date.now() } = {}) {
    this.songMs = songMs;
    this.bayGio = bayGio;
    this.kho = new Map();
  }

  phat(boiCanh = {}) {
    this._don();
    const t = crypto.randomBytes(32).toString('base64url');
    this.kho.set(t, { luc: this.bayGio(), het: this.bayGio() + this.songMs, ...boiCanh });
    return t;
  }

  /** Nhận và XOÁ. Một thách thức chỉ dùng được đúng một lần. */
  nhan(t) {
    this._don();
    if (!t || !this.kho.has(t)) return null;
    const v = this.kho.get(t);
    this.kho.delete(t);
    if (v.het < this.bayGio()) return null;
    return v;
  }

  _don() {
    const n = this.bayGio();
    for (const [k, v] of this.kho) if (v.het < n) this.kho.delete(k);
  }

  status() { return { dangCho: this.kho.size, songGiay: Math.round(this.songMs / 1000) }; }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ĐĂNG KÝ VÀ ĐĂNG NHẬP
// ═══════════════════════════════════════════════════════════════════════════

class KhuonMat {
  /**
   * @param {object} o
   * @param {string} o.tenMay       định danh máy chủ (rpId), ví dụ "gitamath.vn"
   * @param {string[]} o.cacGoc     các gốc được phép, ví dụ ["https://gitamath.vn"]
   * @param {string} o.tenHienThi   tên hiện trên hộp thoại của hệ điều hành
   */
  constructor({ tenMay, cacGoc, tenHienThi = 'GITAmath', kho = null, bayGio = () => Date.now() } = {}) {
    if (!tenMay) throw new Error('KhuonMat cần tên máy chủ (rpId)');
    if (!Array.isArray(cacGoc) || !cacGoc.length) throw new Error('KhuonMat cần danh sách gốc được phép');
    this.tenMay = tenMay;
    this.cacGoc = cacGoc;
    this.tenHienThi = tenHienThi;
    this.thachThuc = kho || new KhoThachThuc({ bayGio });
    this.bayGio = bayGio;
    this.rpIdHash = crypto.createHash('sha256').update(tenMay).digest();
    this.dem = { dangKy: 0, dangNhap: 0, tuChoi: 0, tuChoiVi: Object.create(null) };
  }

  _tuChoi(vi) {
    this.dem.tuChoi++;
    this.dem.tuChoiVi[vi] = (this.dem.tuChoiVi[vi] || 0) + 1;
    return { ok: false, loi: vi };
  }

  /**
   * Tuỳ chọn gửi cho trình duyệt khi ĐĂNG KÝ khuôn mặt.
   *
   * Ba tham số dưới đây là chỗ nói với trình duyệt rằng ta muốn sinh trắc học
   * gắn trong máy, không phải khoá cắm rời và không phải mã PIN:
   *
   *   authenticatorAttachment: 'platform'   chỉ nhận bộ xác thực gắn trong máy
   *   userVerification: 'required'          bắt buộc xác minh người dùng
   *   residentKey: 'preferred'              để lần sau không phải gõ tên
   */
  tuyChonDangKy({ nguoiDungId, tenDangNhap, tenDayDu, maKhoaDaCo = [] }) {
    const t = this.thachThuc.phat({ viec: 'dang-ky', nguoiDungId });
    return {
      thachThuc: t,
      tuyChon: {
        challenge: t,
        rp: { id: this.tenMay, name: this.tenHienThi },
        user: {
          id: b64url(Buffer.from(String(nguoiDungId), 'utf8')),
          name: tenDangNhap,
          displayName: tenDayDu || tenDangNhap,
        },
        pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
        timeout: this.thachThuc.songMs,
        attestation: 'none',
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'required',
          residentKey: 'preferred',
        },
        excludeCredentials: maKhoaDaCo.map((id) => ({ type: 'public-key', id })),
      },
    };
  }

  /**
   * Kiểm kết quả đăng ký.
   * @returns {{ok:true, khoa:object} | {ok:false, loi:string}}
   */
  kiemDangKy({ thachThuc, id, clientDataJSON, attestationObject, gan = null }) {
    const ve = this.thachThuc.nhan(thachThuc);
    if (!ve) return this._tuChoi('THACH_THUC_HET_HAN_HOAC_DA_DUNG');
    if (ve.viec !== 'dang-ky') return this._tuChoi('THACH_THUC_SAI_VIEC');

    try {
      kiemClientData(clientDataJSON, 'webauthn.create', thachThuc, this.cacGoc);
    } catch (e) {
      return this._tuChoi(`CLIENT_DATA_SAI: ${e.message}`);
    }

    let att;
    try {
      att = docCbor(tuB64url(attestationObject));
    } catch (e) {
      return this._tuChoi(`ATTESTATION_KHONG_DOC_DUOC: ${e.message}`);
    }
    const authData = att instanceof Map ? att.get('authData') : null;
    if (!Buffer.isBuffer(authData)) return this._tuChoi('ATTESTATION_THIEU_AUTHDATA');

    let ad;
    try { ad = docAuthData(authData); } catch (e) { return this._tuChoi(`AUTHDATA_SAI: ${e.message}`); }

    if (!ad.rpIdHash.equals(this.rpIdHash)) return this._tuChoi('SAI_MAY_CHU');
    if (!ad.coMat) return this._tuChoi('NGUOI_DUNG_KHONG_CO_MAT');

    // ĐÂY LÀ CỬA QUAN TRỌNG NHẤT. Không có cờ này thì không có gì chứng minh
    // người dùng đã xác minh bằng sinh trắc học — có thể chỉ là một lần chạm.
    if (!ad.daXacMinh) return this._tuChoi('CHUA_XAC_MINH_SINH_TRAC_HOC');

    if (!ad.coKhoa || !ad.maKhoa) return this._tuChoi('THIEU_KHOA_CONG_KHAI');

    // Trình duyệt được yêu cầu bộ xác thực gắn trong máy, nhưng yêu cầu không
    // phải bảo đảm. Kiểm lại ở đây; trình duyệt cũ không khai thì không chặn,
    // nhưng ghi lại để người quản trị biết mà siết.
    const ganTrongMay = gan == null ? null : gan === 'platform';
    if (ganTrongMay === false) return this._tuChoi('KHONG_PHAI_BO_XAC_THUC_GAN_TRONG_MAY');

    let khoa;
    try { khoa = dungKhoaCong(ad.khoaCose); } catch (e) { return this._tuChoi(`KHOA_CONG_SAI: ${e.message}`); }

    this.dem.dangKy++;
    return {
      ok: true,
      khoa: {
        maKhoa: b64url(ad.maKhoa),
        khoaCong: khoa.khoa.export({ type: 'spki', format: 'pem' }),
        thuatToan: khoa.spec.ten,
        boDem: ad.boDem,
        aaguid: ad.aaguid ? ad.aaguid.toString('hex') : null,
        ganTrongMay,
        dangKyLuc: this.bayGio(),
        dungLanCuoi: null,
      },
    };
  }

  /** Tuỳ chọn gửi cho trình duyệt khi ĐĂNG NHẬP. */
  tuyChonDangNhap({ maKhoaChoPhep = [], nguoiDungId = null } = {}) {
    const t = this.thachThuc.phat({ viec: 'dang-nhap', nguoiDungId });
    return {
      thachThuc: t,
      tuyChon: {
        challenge: t,
        rpId: this.tenMay,
        timeout: this.thachThuc.songMs,
        userVerification: 'required',
        allowCredentials: maKhoaChoPhep.map((id) => ({ type: 'public-key', id })),
      },
    };
  }

  /**
   * Kiểm kết quả đăng nhập.
   *
   * @param {object} o
   * @param {object} o.khoaDaLuu bản ghi khoá đã đăng ký
   * @returns {{ok:true, boDemMoi:number} | {ok:false, loi:string}}
   */
  kiemDangNhap({ thachThuc, clientDataJSON, authenticatorData, signature, khoaDaLuu, gan = null }) {
    const ve = this.thachThuc.nhan(thachThuc);
    if (!ve) return this._tuChoi('THACH_THUC_HET_HAN_HOAC_DA_DUNG');
    if (ve.viec !== 'dang-nhap') return this._tuChoi('THACH_THUC_SAI_VIEC');
    if (!khoaDaLuu || !khoaDaLuu.khoaCong) return this._tuChoi('KHONG_CO_KHOA_DA_DANG_KY');

    let cd;
    try {
      cd = kiemClientData(clientDataJSON, 'webauthn.get', thachThuc, this.cacGoc);
    } catch (e) {
      return this._tuChoi(`CLIENT_DATA_SAI: ${e.message}`);
    }

    const authData = tuB64url(authenticatorData);
    let ad;
    try { ad = docAuthData(authData); } catch (e) { return this._tuChoi(`AUTHDATA_SAI: ${e.message}`); }

    if (!ad.rpIdHash.equals(this.rpIdHash)) return this._tuChoi('SAI_MAY_CHU');
    if (!ad.coMat) return this._tuChoi('NGUOI_DUNG_KHONG_CO_MAT');
    if (!ad.daXacMinh) return this._tuChoi('CHUA_XAC_MINH_SINH_TRAC_HOC');
    if (gan != null && gan !== 'platform') return this._tuChoi('KHONG_PHAI_BO_XAC_THUC_GAN_TRONG_MAY');

    // Chữ ký phủ lên authData nối với băm của clientDataJSON. Nối sai thứ tự
    // là chữ ký luôn sai — và luôn sai thì không ai đăng nhập được, nên lỗi
    // kiểu ấy lộ ra ngay.
    const duLieuKy = Buffer.concat([
      authData,
      crypto.createHash('sha256').update(tuB64url(clientDataJSON)).digest(),
    ]);

    let dung;
    try {
      const v = crypto.createVerify('sha256');
      v.update(duLieuKy);
      v.end();
      dung = v.verify(khoaDaLuu.khoaCong, tuB64url(signature));
    } catch (e) {
      return this._tuChoi(`KHONG_KIEM_DUOC_CHU_KY: ${e.message}`);
    }
    if (!dung) return this._tuChoi('CHU_KY_SAI');

    // BỘ ĐẾM PHẢI TĂNG. Không tăng nghĩa là có bản sao của khoá riêng đang
    // chạy song song — dấu hiệu nghiêm trọng nhất mà WebAuthn cho phép thấy.
    // Bộ xác thực nào không đếm thì báo 0 ở cả hai lần; đó là hợp lệ theo
    // chuẩn, nên chỉ chặn khi CẢ HAI đều khác 0.
    const cu = Number(khoaDaLuu.boDem) || 0;
    if (ad.boDem !== 0 && cu !== 0 && ad.boDem <= cu) {
      return this._tuChoi('BO_DEM_KHONG_TANG_NGHI_CO_BAN_SAO');
    }

    this.dem.dangNhap++;
    return { ok: true, boDemMoi: ad.boDem, goc: cd.origin, luc: this.bayGio() };
  }

  status() {
    return {
      tenMay: this.tenMay,
      cacGoc: this.cacGoc,
      thachThuc: this.thachThuc.status(),
      dem: { ...this.dem, tuChoiVi: { ...this.dem.tuChoiVi } },
      cachLam: 'WebAuthn với bộ xác thực gắn trong máy (Windows Hello Face, Touch ID, Face ID). '
        + 'Đặc trưng khuôn mặt KHÔNG rời khỏi máy người dùng; máy chủ chỉ giữ khoá công khai.',
      batBuoc: [
        'Cờ đã-xác-minh-người-dùng phải bật — đây là chỗ phân biệt sinh trắc học với mã PIN.',
        'Bộ xác thực phải gắn trong máy, không nhận khoá cắm rời.',
        'Bộ đếm lần ký phải tăng — không tăng là nghi có bản sao khoá.',
        'Thách thức dùng một lần, sống hai phút.',
      ],
      khongLam: 'Máy chủ KHÔNG giữ ảnh, KHÔNG giữ đặc trưng khuôn mặt, và KHÔNG biết '
        + 'người dùng đã xác minh bằng khuôn mặt hay vân tay — đó là việc của máy họ.',
    };
  }
}

module.exports = KhuonMat;
module.exports.KhoThachThuc = KhoThachThuc;
module.exports.docAuthData = docAuthData;
module.exports.dungKhoaCong = dungKhoaCong;
module.exports.kiemClientData = kiemClientData;
module.exports.CO = CO;
module.exports.THUAT_TOAN = THUAT_TOAN;
module.exports.THACH_THUC_SONG_MS = THACH_THUC_SONG_MS;
