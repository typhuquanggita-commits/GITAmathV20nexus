'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SOI NỀN MÓNG — MÔ-ĐUN ĐƯỢC GỌI KHẮP NƠI MÀ KHÔNG AI VIẾT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  BỆNH NÀY ĐƯỢC TÌM RA BẰNG MÁY, KHÔNG PHẢI BẰNG LINH CẢM.
 *
 *  Một bản thiết kế 1,18 triệu ký tự, 47 mô-đun tính năng viết đầy đủ tới
 *  từng câu SQL, được quét tự động để đối chiếu danh sách `import` với danh
 *  sách định nghĩa. Kết quả: 18 đường dẫn được import mà không tệp nào định
 *  nghĩa, tổng 265 chỗ gọi. Trong đó bảy mô-đun GÁNH AN TOÀN:
 *
 *      utils/crypto           46 chỗ gọi    KHÔNG có định nghĩa
 *      middleware/auth        39 chỗ gọi    KHÔNG có định nghĩa
 *      utils/error            38 chỗ gọi    KHÔNG có định nghĩa
 *      middleware/rateLimit   15 chỗ gọi    KHÔNG có định nghĩa
 *      services/costGuard     10 chỗ gọi    KHÔNG có định nghĩa
 *      services/jobQueue       5 chỗ gọi    KHÔNG có định nghĩa
 *      utils/logger            3 chỗ gọi    KHÔNG có định nghĩa
 *                            ───
 *                            156 chỗ gọi
 *
 *  (Còn `types/content` 84 chỗ — tệp khai kiểu, tách riêng vì nó không gánh
 *  hành vi; và mười mô-đun nhỏ khác, tổng 25 chỗ.)
 *
 *  Bảy mô-đun ấy không phải bảy mô-đun bất kỳ. Chúng đúng là bảy thứ GÁNH AN
 *  TOÀN: mật mã, xác thực, xử lý lỗi, giới hạn tần suất, trần chi phí, hàng
 *  đợi, nhật ký. Bốn mươi bảy tầng lầu được vẽ chi tiết tới từng viên gạch,
 *  còn móng thì chưa ai đổ.
 *
 *  GHI LẠI MỘT LẦN ĐẾM SAI, VÌ NÓ ĐÚNG LÀ BÀI HỌC CỦA TỆP NÀY. Bản báo cáo
 *  đầu tiên viết "7 mô-đun, 163 chỗ gọi". Con số ấy dựng từ lần đếm đầu, khi
 *  người đếm dừng lại ở bảy cái nhìn thấy trước và cộng nhầm một mô-đun. Đếm
 *  lại bằng một biểu thức duy nhất quét mọi câu import cho ra 18 và 265 —
 *  NHIỀU HƠN, không phải ít hơn. Bài học không phải "hãy cẩn thận": nó là
 *  đừng đếm bằng mắt rồi ghi vào báo cáo. Đó chính là việc tệp này làm.
 *
 *  Và bệnh này KHÔNG tự lộ ra. Đọc bất kỳ mô-đun nào cũng thấy nó gọi
 *  `assertBudget()` rồi yên tâm rằng ngân sách đang được canh. Chỉ khi quét
 *  cả kho mã và so hai danh sách mới thấy `assertBudget` chưa từng tồn tại.
 *
 *  Nên tệp này quét CHÍNH KHO MÃ NÀY, mỗi lần chạy kiểm định. Không phải vì
 *  nghi ngờ ai, mà vì đây là loại lỗi mà đọc từng tệp không bao giờ bắt được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');

const GOC = path.join(__dirname, '..', '..');

/**
 * Bỏ chú thích trước khi quét.
 *
 * Bản quét đầu tiên của tệp này báo ba mô-đun thiếu: `./x`, `../x/y` và `...`.
 * Cả ba nằm trong chính phần chú thích ở đầu tệp này, nơi mô tả bệnh bằng ví
 * dụ. Một bộ soi tự báo động vì chính lời mình viết thì lần sau không ai tin
 * nó nữa — nên nó phải đọc MÃ, không đọc văn.
 */
function boChuThich(ma) {
  return ma
    .replace(/\/\*[\s\S]*?\*\//g, ' ')      // khối /* … */
    .replace(/(^|[^:'"\\])\/\/[^\n]*/g, '$1 ');  // dòng // … , tránh cắt nhầm "http://"
}

/** Đi hết cây thư mục, trả về mọi tệp .js. */
function quetTep(thuMuc, boQua = new Set(['node_modules', '.git', 'data', 'coverage'])) {
  const ra = [];
  const di = (d) => {
    let muc;
    try { muc = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const m of muc) {
      if (boQua.has(m.name)) continue;
      const p = path.join(d, m.name);
      if (m.isDirectory()) di(p);
      else if (m.name.endsWith('.js')) ra.push(p);
    }
  };
  di(thuMuc);
  return ra;
}

/**
 * Soi một cây thư mục: mọi require('./x') hoặc require('../x/y') có trỏ vào
 * tệp tồn tại thật không.
 *
 * Chỉ xét require TƯƠNG ĐỐI. Gói ngoài không xét vì kho này không có phụ
 * thuộc runtime nào — và nếu một ngày có, mục kiểm đóng gói sẽ nói.
 */
function soiNenMong({ goc = GOC, thuMuc = ['src', 'scripts', 'bin', 'test'] } = {}) {
  const tep = [];
  for (const t of thuMuc) {
    const d = path.join(goc, t);
    if (fs.existsSync(d)) tep.push(...quetTep(d));
  }

  const thieu = [];
  const demGoi = new Map();     // đường dẫn đã giải → số lần được gọi
  let soRequire = 0;

  for (const f of tep) {
    let ma;
    try { ma = boChuThich(fs.readFileSync(f, 'utf8')); } catch { continue; }
    // require(…) và require(path.join(ROOT, …)) đều bắt.
    const re = /require\(\s*(?:path\.join\([^)]*?,\s*)?['"]([^'"]+)['"]/g;
    let m;
    while ((m = re.exec(ma)) !== null) {
      const duong = m[1];
      // Bỏ qua gói lõi của Node và gói ngoài.
      if (!duong.startsWith('.') && !duong.startsWith('src/')) continue;
      soRequire++;
      const goc2 = duong.startsWith('src/') ? goc : path.dirname(f);
      const thu = [
        path.resolve(goc2, duong),
        path.resolve(goc2, `${duong}.js`),
        path.resolve(goc2, duong, 'index.js'),
      ];
      const co = thu.find((p) => { try { return fs.statSync(p).isFile(); } catch { return false; } });
      if (co) demGoi.set(co, (demGoi.get(co) || 0) + 1);
      else {
        thieu.push({
          goiTu: path.relative(goc, f),
          dong: ma.slice(0, m.index).split('\n').length,
          goi: duong,
        });
      }
    }
  }

  // Gom theo đường dẫn bị thiếu, để thấy cái nào được gọi nhiều nhất — đó
  // chính là hình dạng của căn bệnh: gọi càng nhiều, tưởng càng chắc.
  const gom = new Map();
  for (const t of thieu) {
    const k = t.goi;
    if (!gom.has(k)) gom.set(k, { goi: k, soLanGoi: 0, choGoi: [] });
    const g = gom.get(k);
    g.soLanGoi++;
    if (g.choGoi.length < 5) g.choGoi.push(`${t.goiTu}:${t.dong}`);
  }
  const thieuGom = [...gom.values()].sort((a, b) => b.soLanGoi - a.soLanGoi);

  return {
    soTep: tep.length,
    soRequireTuongDoi: soRequire,
    soMoDunDuocGoi: demGoi.size,
    thieu: thieuGom,
    ok: thieuGom.length === 0,
    ketLuan: thieuGom.length
      ? `${thieuGom.length} mô-đun được gọi mà KHÔNG tồn tại: `
        + thieuGom.slice(0, 5).map((t) => `${t.goi} (${t.soLanGoi} chỗ)`).join(', ')
      : `${tep.length} tệp · ${soRequire} lần gọi mô-đun trong kho · mọi lời gọi đều trỏ vào tệp có thật.`,
    viSao: 'Đây là loại lỗi mà đọc từng tệp không bao giờ bắt được: tệp nào đọc cũng thấy hợp lý. '
      + 'Chỉ khi quét cả kho và so hai danh sách mới thấy móng chưa đổ.',
  };
}

/**
 * Soi mô-đun CÔ ĐỘC: tệp nằm trong src/ mà không tệp nào gọi tới và cũng
 * không phải điểm vào. Mặt trái của bệnh trên — mã chết nằm lại, và ngày nào
 * đó có người đọc nó rồi tưởng nó đang chạy.
 */
function soiCoDoc({ goc = GOC } = {}) {
  const src = path.join(goc, 'src');
  const tep = quetTep(src);
  const duocGoi = new Set();
  const moiTep = [...tep, ...quetTep(path.join(goc, 'bin')), ...quetTep(path.join(goc, 'scripts')), ...quetTep(path.join(goc, 'test'))];
  for (const f of moiTep) {
    let ma;
    try { ma = boChuThich(fs.readFileSync(f, 'utf8')); } catch { continue; }
    const re = /require\(\s*(?:path\.join\([^)]*?,\s*)?['"]([^'"]+)['"]/g;
    let m;
    while ((m = re.exec(ma)) !== null) {
      const duong = m[1];
      if (!duong.startsWith('.') && !duong.startsWith('src/')) continue;
      const goc2 = duong.startsWith('src/') ? goc : path.dirname(f);
      for (const p of [path.resolve(goc2, duong), path.resolve(goc2, `${duong}.js`), path.resolve(goc2, duong, 'index.js')]) {
        try { if (fs.statSync(p).isFile()) { duocGoi.add(p); break; } } catch { /* bỏ qua */ }
      }
    }
  }
  const coDoc = tep.filter((f) => !duocGoi.has(f) && path.basename(f) !== 'index.js')
    .map((f) => path.relative(goc, f));
  return { soTep: tep.length, coDoc, ok: coDoc.length === 0 };
}

module.exports = { boChuThich, quetTep, soiNenMong, soiCoDoc };
