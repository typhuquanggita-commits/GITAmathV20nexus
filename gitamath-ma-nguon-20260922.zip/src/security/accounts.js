'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TÀI KHOẢN & PHÂN QUYỀN — 5 vai, một bảng quyền duy nhất
 * ═══════════════════════════════════════════════════════════════════════════
 *  Super Admin đứng ngoài hệ này (đã có két 15 tầng riêng ở superadmin-vault).
 *  Ở đây là những người dùng hằng ngày của GITAmath.
 *
 *  Nguyên tắc:
 *   · Quyền tra theo BẢNG, không rải if/else khắp nơi — sửa một chỗ, đúng mọi chỗ.
 *   · Phụ huynh chỉ thấy đúng con mình. Giáo viên chỉ thấy đúng lớp mình dạy.
 *     Ràng buộc này kiểm ở tầng quyền (scope), không phụ thuộc giao diện.
 *   · Sai mật khẩu bị khoá theo thang tăng dần, đếm theo tài khoản.
 *   · Mật khẩu băm scrypt, không bao giờ trả ra ngoài dù chỉ một lần.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const C = require('./crypto');
const bus = require('../kernel/eventbus');
const { round, viKey } = require('../utils');

const ROLES = {
  ADMIN: {
    id: 'ADMIN', name: 'Quản trị hệ thống', rank: 90,
    desc: 'Điều hành toàn hệ thống dưới quyền Super Admin',
    minPasswordLen: 12,
  },
  TEACHER: {
    id: 'TEACHER', name: 'Giáo viên', rank: 60,
    desc: 'Dạy lớp được phân công, giao bài, theo dõi từng học viên',
    minPasswordLen: 10,
  },
  PARENT: {
    id: 'PARENT', name: 'Phụ huynh', rank: 30,
    desc: 'Theo dõi tiến độ của con mình',
    minPasswordLen: 8,
  },
  LEARNER: {
    id: 'LEARNER', name: 'Học viên', rank: 20,
    desc: 'Luyện tập, làm bài, xem tiến độ của chính mình',
    minPasswordLen: 8,
  },
  GUEST: {
    id: 'GUEST', name: 'Khách', rank: 0,
    desc: 'Chỉ xem được thông tin công khai',
    minPasswordLen: 8,
  },
};

/**
 * Bảng quyền. `own` = chỉ trên dữ liệu của chính mình,
 * `scope` = chỉ trên phạm vi được gán (lớp mình dạy, con mình).
 */
const PERMISSIONS = {
  ADMIN: [
    'user.create', 'user.read', 'user.update', 'user.disable', 'user.reset_password',
    'school.*', 'class.*', 'learner.*', 'item.*', 'exam.*', 'practice.read',
    'report.*', 'agents.read', 'mission.run', 'curriculum.read', 'import.*', 'export.*',
  ],
  TEACHER: [
    'class.read:scope', 'class.update:scope',
    'learner.read:scope', 'learner.create:scope', 'learner.update:scope',
    'item.read', 'item.create', 'item.review',
    'exam.assign:scope', 'exam.read:scope',
    'practice.read:scope', 'report.read:scope', 'report.export:scope',
    'curriculum.read', 'import.learners:scope', 'export.class:scope',
  ],
  PARENT: [
    'learner.read:scope', 'practice.read:scope', 'report.read:scope',
    'exam.read:scope', 'curriculum.read',
  ],
  LEARNER: [
    'learner.read:own', 'practice.start:own', 'practice.answer:own', 'practice.read:own',
    'exam.take:own', 'exam.read:own', 'report.read:own', 'item.read:assigned', 'curriculum.read',
  ],
  GUEST: ['curriculum.read'],
};

const SESSION_TTL_MS = 8 * 3600_000;          // 8 giờ
const LEARNER_SESSION_TTL_MS = 4 * 3600_000;  // học viên ngắn hơn, máy hay dùng chung
const LOCKOUT_LADDER = [60_000, 300_000, 900_000, 3_600_000];
const MAX_ATTEMPTS = 5;

/** Mật khẩu: yêu cầu theo vai, vai càng cao càng ngặt. */
function passwordCheck(password, role = 'LEARNER') {
  const p = String(password || '');
  const min = ROLES[role]?.minPasswordLen ?? 8;
  const problems = [];
  if (p.length < min) problems.push(`phải từ ${min} ký tự trở lên`);
  const classes = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^A-Za-z0-9]/].filter((re) => re.test(p)).length;
  const needClasses = ROLES[role]?.rank >= 60 ? 3 : 2;
  if (classes < needClasses) problems.push(`phải có ít nhất ${needClasses} nhóm ký tự (thường, hoa, số, ký hiệu)`);
  if (/^(.)\1+$/.test(p)) problems.push('không được là một ký tự lặp lại');
  const k = viKey(p);
  for (const bad of ['gita', 'matkhau', 'password', '123456', 'qwerty', 'admin', 'hocsinh', 'giaovien']) {
    if (k.includes(bad)) { problems.push(`không được chứa "${bad}"`); break; }
  }
  // Entropy thô: log2(kho ký tự) × độ dài
  const pool = (/[a-z]/.test(p) ? 26 : 0) + (/[A-Z]/.test(p) ? 26 : 0)
    + (/[0-9]/.test(p) ? 10 : 0) + (/[^A-Za-z0-9]/.test(p) ? 33 : 0);
  const entropy = pool ? round(p.length * Math.log2(pool), 1) : 0;
  const needEntropy = ROLES[role]?.rank >= 60 ? 50 : 36;
  if (entropy < needEntropy) problems.push(`độ phức tạp ${entropy} bit, cần ≥ ${needEntropy} bit`);
  return { ok: problems.length === 0, problems, entropy, classes };
}

class AccountService {
  /**
   * @param {object} o
   * @param {import('../data/repository').Repository} o.users
   * @param {import('../data/repository').Repository} o.learners
   * @param {import('../data/repository').Repository} o.classes
   * @param {object} o.audit
   */
  constructor({ users, learners, classes, audit = null, khuonMat = null, chongLuaDao = null }) {
    this.users = users;
    this.learners = learners;
    this.classes = classes;
    this.audit = audit;
    // Đăng nhập bằng khuôn mặt. Null thì hệ chạy y như trước — đây là lối vào
    // THÊM, không thay lối cũ. Mất camera, hỏng cảm biến, đổi máy: vẫn còn
    // mật khẩu. Một hệ chỉ có đúng một cách vào là một hệ khoá được người
    // dùng ra ngoài.
    this.khuonMat = khuonMat;
    // Lớp chống lừa đảo. Null thì hệ chạy y như trước.
    this.chongLuaDao = chongLuaDao;
    this.sessions = new Map();   // token -> {userId, role, at, exp, ip}
    this.failures = new Map();   // username -> {count, lockedUntil, lastAt}
    this.stats = { created: 0, logins: 0, failedLogins: 0, lockouts: 0, denied: 0, granted: 0 };
    this._gc = setInterval(() => this._sweep(), 300_000);
    if (this._gc.unref) this._gc.unref();
  }

  _sweep() {
    const now = Date.now();
    for (const [t, s] of this.sessions) if (s.exp < now) this.sessions.delete(t);
    for (const [u, f] of this.failures) if (now - f.lastAt > 86_400_000) this.failures.delete(u);
  }

  _log(action, detail, verdict = 'ALLOW', severity = 0) {
    this.audit?.record({ actor: detail.actor || 'system', actorRole: detail.role || 'SYSTEM', action, verdict, severity, detail });
  }

  // ── Tạo và quản lý tài khoản ─────────────────────────────────────────────

  /**
   * Tạo tài khoản. Trả về bản ghi KHÔNG chứa mật khẩu.
   * @param {object} o {username, password, role, fullName, email, createdBy, scope}
   */
  create({ username, password, role, fullName, email = '', phone = '', createdBy = 'system', scope = {} } = {}) {
    if (!username || !/^[a-zA-Z0-9._-]{3,40}$/.test(username)) {
      return { ok: false, error: 'INVALID_USERNAME', hint: '3–40 ký tự, chỉ chữ, số và . _ -' };
    }
    if (!ROLES[role] || role === 'GUEST') return { ok: false, error: 'INVALID_ROLE', roles: Object.keys(ROLES).filter((r) => r !== 'GUEST') };
    if (this.users.find((u) => u.username.toLowerCase() === username.toLowerCase())) {
      return { ok: false, error: 'USERNAME_TAKEN' };
    }
    const pw = passwordCheck(password, role);
    if (!pw.ok) return { ok: false, error: 'WEAK_PASSWORD', problems: pw.problems, entropy: pw.entropy };

    const id = `U-${role.slice(0, 3)}-${String(this.users.count() + 1).padStart(5, '0')}`;
    const doc = {
      id,
      username,
      role,
      fullName: fullName || username,
      email,
      phone,
      passwordHash: C.hashPassword(password),
      passwordSetAt: Date.now(),
      mustChangePassword: false,
      active: true,
      scope: {
        classIds: Array.isArray(scope.classIds) ? [...new Set(scope.classIds)] : [],
        learnerIds: Array.isArray(scope.learnerIds) ? [...new Set(scope.learnerIds)] : [],
        schoolId: scope.schoolId || null,
      },
      createdBy,
      lastLoginAt: null,
      loginCount: 0,
    };
    this.users.put(doc);
    this.stats.created++;
    this._log('account.create', { actor: createdBy, target: id, role, username });
    bus.safeEmit('account:created', { id, role });
    return { ok: true, user: this.view(doc) };
  }

  /** Bản ghi cho bên ngoài — không bao giờ kèm băm mật khẩu. */
  view(u) {
    if (!u) return null;
    const { passwordHash, ...rest } = u;
    return { ...rest, roleName: ROLES[u.role]?.name, permissions: PERMISSIONS[u.role] || [] };
  }

  get(userId) { return this.view(this.users.get(userId)); }

  list({ role = null, limit = 100, offset = 0 } = {}) {
    const page = this.users.page({ offset, limit, sort: 'username', where: role ? (u) => u.role === role : null });
    return { ...page, items: page.items.map((u) => this.view(u)) };
  }

  setActive(userId, active, by = 'system') {
    const u = this.users.get(userId);
    if (!u) return { ok: false, error: 'NOT_FOUND' };
    this.users.patch(userId, { active: !!active });
    if (!active) for (const [t, s] of this.sessions) if (s.userId === userId) this.sessions.delete(t);
    this._log('account.set_active', { actor: by, target: userId, active: !!active }, active ? 'ALLOW' : 'DENY', active ? 0 : 1);
    return { ok: true, userId, active: !!active };
  }

  changePassword(userId, oldPassword, newPassword) {
    const u = this.users.get(userId);
    if (!u) return { ok: false, error: 'NOT_FOUND' };
    if (!C.verifyPassword(oldPassword, u.passwordHash)) return { ok: false, error: 'INVALID_CREDENTIALS' };
    const pw = passwordCheck(newPassword, u.role);
    if (!pw.ok) return { ok: false, error: 'WEAK_PASSWORD', problems: pw.problems };
    if (C.verifyPassword(newPassword, u.passwordHash)) return { ok: false, error: 'PASSWORD_REUSED' };
    this.users.patch(userId, { passwordHash: C.hashPassword(newPassword), passwordSetAt: Date.now(), mustChangePassword: false });
    for (const [t, s] of this.sessions) if (s.userId === userId) this.sessions.delete(t); // buộc đăng nhập lại
    this._log('account.change_password', { actor: userId, target: userId });
    return { ok: true };
  }

  /** Quản trị đặt lại mật khẩu: sinh mật khẩu tạm, bắt đổi ngay lần đăng nhập sau. */
  resetPassword(userId, by = 'admin') {
    const u = this.users.get(userId);
    if (!u) return { ok: false, error: 'NOT_FOUND' };
    const temp = `Gt${C.randomToken(6)}#${Math.floor(Date.now() % 97) + 10}`;
    this.users.patch(userId, { passwordHash: C.hashPassword(temp), passwordSetAt: Date.now(), mustChangePassword: true });
    this.failures.delete(u.username.toLowerCase());
    for (const [t, s] of this.sessions) if (s.userId === userId) this.sessions.delete(t);
    this._log('account.reset_password', { actor: by, target: userId }, 'ALLOW', 1);
    return { ok: true, userId, temporaryPassword: temp, note: 'Mật khẩu tạm chỉ hiện một lần. Người dùng phải đổi ngay khi đăng nhập.' };
  }

  // ── Đăng nhập ────────────────────────────────────────────────────────────

  _lockState(key) {
    const f = this.failures.get(key);
    if (!f || !f.lockedUntil || f.lockedUntil < Date.now()) return null;
    return { until: f.lockedUntil, remainMs: f.lockedUntil - Date.now() };
  }

  _fail(key) {
    const f = this.failures.get(key) || { count: 0, lockedUntil: 0, lastAt: 0 };
    f.count++;
    f.lastAt = Date.now();
    if (f.count >= MAX_ATTEMPTS) {
      const step = Math.min(Math.floor(f.count / MAX_ATTEMPTS) - 1, LOCKOUT_LADDER.length - 1);
      f.lockedUntil = Date.now() + LOCKOUT_LADDER[step];
      this.stats.lockouts++;
    }
    this.failures.set(key, f);
    this.stats.failedLogins++;
    return f;
  }

  login({ username, password, ip = 'unknown', userAgent = '' } = {}) {
    const key = String(username || '').toLowerCase();
    const lock = this._lockState(key);
    if (lock) {
      return { ok: false, error: 'LOCKED_OUT', remainMs: lock.remainMs, remainMin: Math.ceil(lock.remainMs / 60_000) };
    }
    const u = this.users.find((x) => x.username.toLowerCase() === key);
    // Luôn chạy một lần băm dù không có tài khoản — không để lộ tài khoản nào tồn tại qua thời gian phản hồi.
    const valid = u ? C.verifyPassword(password, u.passwordHash) : C.verifyPassword(password, C.hashPassword('khong-co-tai-khoan-nay'));
    if (!u || !valid) {
      const f = this._fail(key);
      // Cùng một nguồn thử nhiều TÊN khác nhau là hình dạng của việc dò xem
      // tài khoản nào có thật — khác hẳn một người gõ sai mật khẩu nhiều lần.
      if (this.chongLuaDao) {
        this.chongLuaDao.ghiThuTen(`${ip}|${userAgent}`, key);
        if (u) this.chongLuaDao.ghiThuHong(u.id);
      }
      this._log('account.login_failed', { actor: key, ip, attempts: f.count }, 'DENY', 1);
      return { ok: false, error: 'INVALID_CREDENTIALS', attemptsLeft: Math.max(0, MAX_ATTEMPTS - f.count) };
    }
    if (!u.active) {
      this._log('account.login_disabled', { actor: u.id, ip }, 'DENY', 1);
      return { ok: false, error: 'ACCOUNT_DISABLED' };
    }

    this.failures.delete(key);
    const ttl = u.role === 'LEARNER' ? LEARNER_SESSION_TTL_MS : SESSION_TTL_MS;
    const token = C.randomToken(32);
    this.sessions.set(token, { userId: u.id, role: u.role, at: Date.now(), exp: Date.now() + ttl, ip, userAgent });
    this.users.patch(u.id, { lastLoginAt: Date.now(), loginCount: (u.loginCount || 0) + 1 });
    // Vào bằng MẬT KHẨU thì KHÔNG cấp vé xác thực lại: việc nguy hiểm vẫn
    // phải quét mặt. Đây chính là chỗ chặn kẻ đã lừa được mật khẩu.
    let mayMk = null;
    if (this.chongLuaDao) {
      mayMk = this.chongLuaDao.ghiMay(u.id, { userAgent, ip });
      if (mayMk.la) this.chongLuaDao.ghiDauHieu('MAY_LA', { nguoiDungId: u.id, cachVao: 'mat-khau' });
    }
    this.stats.logins++;
    this._log('account.login', { actor: u.id, role: u.role, ip });
    bus.safeEmit('account:login', { userId: u.id, role: u.role });

    return {
      ok: true, token, expiresAt: Date.now() + ttl,
      cachVao: 'mat-khau',
      mayLa: !!(mayMk && mayMk.la),
      mustChangePassword: !!u.mustChangePassword,
      user: this.view(this.users.get(u.id)),
    };
  }

  /**
   * Cổng chung cho mọi việc nguy hiểm.
   *
   * ĐẶT MỘT CHỖ, KHÔNG RẢI RA TỪNG HÀM. Rải ra thì hàm thứ mười một quên gọi,
   * và không ai biết cho tới ngày có chuyện — đúng cách mà lỗ thủng cổng quyền
   * ngày trước đã xảy ra.
   */
  choLamViecNguyHiem(token, maViec) {
    if (!this.chongLuaDao) return { cho: true, vi: 'Chưa bật lớp chống lừa đảo.' };
    if (!this.session(token)) return { cho: false, canGi: 'Phiên đã hết hạn. Đăng nhập lại.' };
    return this.chongLuaDao.choLamViec(token, maViec);
  }

  /**
   * Đổi mật khẩu QUA CỔNG việc nguy hiểm.
   *
   * Vì sao đây là việc nguy hiểm: kẻ chiếm được phiên mà đổi được mật khẩu
   * thì nó khoá luôn chủ nhà ra ngoài, và từ đó tài khoản là của nó.
   */
  doiMatKhauCoCanh(token, oldPassword, newPassword) {
    const phien = this.session(token);
    if (!phien) return { ok: false, error: 'INVALID_SESSION' };
    const cho = this.choLamViecNguyHiem(token, 'doi-mat-khau');
    if (!cho.cho) return { ok: false, error: 'CAN_XAC_THUC_LAI', ...cho };
    return this.changePassword(phien.userId, oldPassword, newPassword);
  }

  // ── ĐĂNG NHẬP BẰNG KHUÔN MẶT ─────────────────────────────────────────────
  //
  // Xem src/an-toan/khuon-mat.js để biết vì sao KHÔNG so khớp khuôn mặt ở máy
  // chủ. Tóm tắt: ở đây phần cứng của máy người dùng làm việc nhận diện bằng
  // camera hồng ngoại đo chiều sâu — ảnh in và video phát lại đều không qua
  // được — còn đặc trưng khuôn mặt thì không bao giờ rời khỏi máy họ.

  _khoaCua(u) { return Array.isArray(u && u.khoaKhuonMat) ? u.khoaKhuonMat : []; }

  /**
   * Xin tuỳ chọn để ĐĂNG KÝ khuôn mặt.
   *
   * PHẢI ĐANG ĐĂNG NHẬP. Không có lối nào đăng ký khuôn mặt từ con số không:
   * tin cậy phải bắt nguồn từ một lần xác thực đã có, nếu không thì ai cũng
   * gắn được khuôn mặt của mình vào tài khoản của người khác.
   */
  xinDangKyKhuonMat(token) {
    if (!this.khuonMat) return { ok: false, error: 'CHUA_BAT_DANG_NHAP_KHUON_MAT' };
    const phien = this.session(token);
    if (!phien) return { ok: false, error: 'INVALID_SESSION' };
    const u = this.users.get(phien.userId);
    if (!u) return { ok: false, error: 'NOT_FOUND' };

    const r = this.khuonMat.tuyChonDangKy({
      nguoiDungId: u.id,
      tenDangNhap: u.username,
      tenDayDu: u.fullName,
      maKhoaDaCo: this._khoaCua(u).map((k) => k.maKhoa),
    });
    this._log('account.face.register_challenge', { actor: u.id, role: u.role });
    return { ok: true, ...r };
  }

  /**
   * Ghi nhận khuôn mặt vừa đăng ký.
   *
   * VỚI NGƯỜI CHƯA THÀNH NIÊN, PHẢI CÓ NGƯỜI GIÁM HỘ ĐỒNG Ý. Đặc trưng khuôn
   * mặt là dữ liệu sinh trắc học; Nghị định 13/2023/NĐ-CP xếp nó vào nhóm dữ
   * liệu cá nhân nhạy cảm. Dù ở cách làm này máy chủ không giữ đặc trưng ấy,
   * việc gắn thân thể một đứa trẻ vào một tài khoản vẫn là quyết định của
   * người lớn chịu trách nhiệm cho em, không phải của em.
   */
  ghiKhuonMat(token, goi, { dongYGiamHo = null, ip = 'unknown' } = {}) {
    if (!this.khuonMat) return { ok: false, error: 'CHUA_BAT_DANG_NHAP_KHUON_MAT' };
    const phien = this.session(token);
    if (!phien) return { ok: false, error: 'INVALID_SESSION' };
    const u = this.users.get(phien.userId);
    if (!u) return { ok: false, error: 'NOT_FOUND' };

    const chuaThanhNien = u.role === 'LEARNER';
    if (chuaThanhNien) {
      const CT = require('../an-toan/cong-tuoi');
      const d = CT.kiemDongY(dongYGiamHo);
      if (!d.ok) {
        this._log('account.face.register_denied', { actor: u.id, role: u.role, vi: d.lyDo }, 'DENY', 1);
        return {
          ok: false, error: 'THIEU_DONG_Y_NGUOI_GIAM_HO',
          reason: d.lyDo,
          canGi: 'Tài khoản học viên gắn khuôn mặt thì phải có người giám hộ đồng ý, '
            + 'ghi rõ họ tên, quan hệ với em, thời điểm đồng ý, và xác nhận rằng đồng ý này rút lại được.',
        };
      }
    }

    const cho = this.choLamViecNguyHiem(token, 'gan-khuon-mat');
    if (!cho.cho) return { ok: false, error: 'CAN_XAC_THUC_LAI', ...cho };

    const r = this.khuonMat.kiemDangKy(goi);
    if (!r.ok) {
      this._log('account.face.register_failed', { actor: u.id, role: u.role, vi: r.loi, ip }, 'DENY', 1);
      return { ok: false, error: r.loi };
    }

    const ds = this._khoaCua(u);
    if (ds.some((k) => k.maKhoa === r.khoa.maKhoa)) {
      return { ok: false, error: 'KHOA_NAY_DA_DANG_KY' };
    }
    // Trần năm khoá: mỗi khoá là một máy mở được tài khoản này. Không có trần
    // thì danh sách phình ra và không ai còn rà lại được nó.
    if (ds.length >= 5) return { ok: false, error: 'QUA_NAM_MAY_DA_DANG_KY', hint: 'Gỡ bớt một máy cũ trước.' };

    const khoa = {
      ...r.khoa,
      dongYGiamHo: chuaThanhNien
        ? { ten: dongYGiamHo.ten, quanHe: dongYGiamHo.quanHe, luc: dongYGiamHo.luc, coTheRutLai: true }
        : null,
    };
    this.users.patch(u.id, { khoaKhuonMat: [...ds, khoa] });
    this._log('account.face.registered', {
      actor: u.id, role: u.role, ip,
      maKhoa: khoa.maKhoa.slice(0, 12), ganTrongMay: khoa.ganTrongMay,
      coDongYGiamHo: !!khoa.dongYGiamHo,
    }, 'ALLOW', 1);
    return { ok: true, maKhoa: khoa.maKhoa, soMayDaDangKy: ds.length + 1 };
  }

  /** Xin tuỳ chọn để ĐĂNG NHẬP bằng khuôn mặt. */
  xinDangNhapKhuonMat({ username = null } = {}) {
    if (!this.khuonMat) return { ok: false, error: 'CHUA_BAT_DANG_NHAP_KHUON_MAT' };
    let maKhoaChoPhep = [];
    let nguoiDungId = null;
    if (username) {
      const u = this.users.find((x) => x.username.toLowerCase() === String(username).toLowerCase());
      // KHÔNG nói tài khoản có tồn tại hay không: trả danh sách rỗng y như
      // khi tài khoản có thật mà chưa gắn khuôn mặt. Nói ra là cho người lạ
      // một cách dò xem ai có tài khoản ở đây.
      if (u) { maKhoaChoPhep = this._khoaCua(u).map((k) => k.maKhoa); nguoiDungId = u.id; }
    }
    return { ok: true, ...this.khuonMat.tuyChonDangNhap({ maKhoaChoPhep, nguoiDungId }) };
  }

  /**
   * Đăng nhập bằng khuôn mặt.
   *
   * Đi qua ĐÚNG những hàng rào mà đăng nhập bằng mật khẩu đi qua: khoá tài
   * khoản sau nhiều lần sai, nhật ký kiểm toán, thời hạn phiên theo vai. Một
   * lối vào mới mà bỏ qua hàng rào cũ thì chính nó là lỗ thủng.
   */
  dangNhapKhuonMat({ maKhoa, thachThuc, clientDataJSON, authenticatorData, signature, gan = null, ip = 'unknown', userAgent = '' } = {}) {
    if (!this.khuonMat) return { ok: false, error: 'CHUA_BAT_DANG_NHAP_KHUON_MAT' };
    if (!maKhoa) return { ok: false, error: 'THIEU_MA_KHOA' };

    const u = this.users.find((x) => this._khoaCua(x).some((k) => k.maKhoa === maKhoa));
    if (!u) {
      this._log('account.face.login_failed', { actor: 'khong-ro', vi: 'KHOA_LA', ip }, 'DENY', 1);
      return { ok: false, error: 'INVALID_CREDENTIALS' };
    }

    const key = u.username.toLowerCase();
    const lock = this._lockState(key);
    if (lock) return { ok: false, error: 'LOCKED_OUT', remainMs: lock.remainMs, remainMin: Math.ceil(lock.remainMs / 60_000) };
    if (!u.active) {
      this._log('account.face.login_disabled', { actor: u.id, ip }, 'DENY', 1);
      return { ok: false, error: 'ACCOUNT_DISABLED' };
    }

    const khoa = this._khoaCua(u).find((k) => k.maKhoa === maKhoa);
    const r = this.khuonMat.kiemDangNhap({
      thachThuc, clientDataJSON, authenticatorData, signature, gan, khoaDaLuu: khoa,
    });
    if (!r.ok) {
      const f = this._fail(key);
      this.stats.failedLogins++;
      this._log('account.face.login_failed', { actor: u.id, role: u.role, vi: r.loi, ip, attempts: f.count }, 'DENY',
        r.loi === 'BO_DEM_KHONG_TANG_NGHI_CO_BAN_SAO' ? 2 : 1);
      if (this.chongLuaDao) {
        // Hai lỗi này KHÔNG phải người dùng gõ nhầm — chúng là dấu vết tấn công.
        if (r.loi === 'BO_DEM_KHONG_TANG_NGHI_CO_BAN_SAO') {
          this.chongLuaDao.ghiDauHieu('BAN_SAO_KHOA', { nguoiDungId: u.id, maKhoa: String(maKhoa).slice(0, 12) });
        } else if (/CLIENT_DATA_SAI[\s\S]*[Gg]ốc/.test(r.loi)) {
          this.chongLuaDao.ghiDauHieu('GOC_SAI', { nguoiDungId: u.id, chiTiet: r.loi.slice(0, 160) });
        }
        this.chongLuaDao.ghiThuHong(u.id);
      }
      return { ok: false, error: 'INVALID_CREDENTIALS', reason: r.loi, attemptsLeft: Math.max(0, MAX_ATTEMPTS - f.count) };
    }

    // Ghi lại bộ đếm mới: đây là thứ phát hiện bản sao khoá ở lần sau.
    this.users.patch(u.id, {
      khoaKhuonMat: this._khoaCua(u).map((k) => (k.maKhoa === maKhoa
        ? { ...k, boDem: r.boDemMoi, dungLanCuoi: Date.now() } : k)),
      lastLoginAt: Date.now(),
      loginCount: (u.loginCount || 0) + 1,
    });

    this.failures.delete(key);
    const ttl = u.role === 'LEARNER' ? LEARNER_SESSION_TTL_MS : SESSION_TTL_MS;
    const token = C.randomToken(32);
    this.sessions.set(token, { userId: u.id, role: u.role, at: Date.now(), exp: Date.now() + ttl, ip, userAgent, cachVao: 'khuon-mat' });
    // Vừa quét mặt xong thì việc nguy hiểm làm được ngay trong năm phút —
    // không bắt quét lại khi vừa quét cách đây ba giây.
    let may = null;
    if (this.chongLuaDao) {
      this.chongLuaDao.ghiXacThucLai(token, { bangKhuonMat: true });
      may = this.chongLuaDao.ghiMay(u.id, { userAgent, ip });
      if (may.la) this.chongLuaDao.ghiDauHieu('MAY_LA', { nguoiDungId: u.id, cachVao: 'khuon-mat' });
    }
    this.stats.logins++;
    this._log('account.face.login', { actor: u.id, role: u.role, ip, maKhoa: maKhoa.slice(0, 12) });
    bus.safeEmit('account:login', { userId: u.id, role: u.role, cachVao: 'khuon-mat' });

    return {
      ok: true, token, expiresAt: Date.now() + ttl,
      cachVao: 'khuon-mat',
      mayLa: !!(may && may.la),
      mustChangePassword: !!u.mustChangePassword,
      user: this.view(this.users.get(u.id)),
    };
  }

  /** Danh sách máy đã gắn khuôn mặt. KHÔNG trả khoá công khai ra ngoài. */
  dsKhuonMat(token) {
    const phien = this.session(token);
    if (!phien) return { ok: false, error: 'INVALID_SESSION' };
    const u = this.users.get(phien.userId);
    return {
      ok: true,
      soMay: this._khoaCua(u).length,
      may: this._khoaCua(u).map((k) => ({
        maKhoa: k.maKhoa,
        thuatToan: k.thuatToan,
        ganTrongMay: k.ganTrongMay,
        dangKyLuc: k.dangKyLuc,
        dungLanCuoi: k.dungLanCuoi,
        coDongYGiamHo: !!k.dongYGiamHo,
      })),
    };
  }

  /**
   * Gỡ một máy.
   *
   * Luôn gỡ được, không cần điều kiện gì ngoài việc đang đăng nhập. Với tài
   * khoản học viên, đây cũng chính là đường rút lại đồng ý của người giám hộ
   * — và một đồng ý không rút lại được thì không phải đồng ý.
   */
  goKhuonMat(token, maKhoa) {
    const phien = this.session(token);
    if (!phien) return { ok: false, error: 'INVALID_SESSION' };
    const u = this.users.get(phien.userId);
    const cho = this.choLamViecNguyHiem(token, 'go-khuon-mat');
    if (!cho.cho) return { ok: false, error: 'CAN_XAC_THUC_LAI', ...cho };

    const ds = this._khoaCua(u);
    const conLai = ds.filter((k) => k.maKhoa !== maKhoa);
    if (conLai.length === ds.length) return { ok: false, error: 'NOT_FOUND' };
    this.users.patch(u.id, { khoaKhuonMat: conLai });
    this._log('account.face.removed', { actor: u.id, role: u.role, maKhoa: String(maKhoa).slice(0, 12) }, 'ALLOW', 1);
    return { ok: true, conLai: conLai.length };
  }

  logout(token) {
    if (this.chongLuaDao) this.chongLuaDao.quenVe(token);
    const s = this.sessions.get(token);
    if (!s) return { ok: false, error: 'INVALID_SESSION' };
    this.sessions.delete(token);
    this._log('account.logout', { actor: s.userId });
    return { ok: true };
  }

  session(token) {
    const s = this.sessions.get(token);
    if (!s) return null;
    if (s.exp < Date.now()) { this.sessions.delete(token); return null; }
    const u = this.users.get(s.userId);
    if (!u || !u.active) { this.sessions.delete(token); return null; }
    return { ...s, user: this.view(u) };
  }

  // ── Kiểm quyền ───────────────────────────────────────────────────────────

  /** Quyền có trong bảng của vai không (bỏ qua hậu tố phạm vi). */
  hasPermission(role, permission) {
    const list = PERMISSIONS[role] || [];
    const base = permission.split(':')[0];
    const [group] = base.split('.');
    return list.some((p) => {
      const pBase = p.split(':')[0];
      return pBase === base || p === `${group}.*` || pBase === `${group}.*`;
    });
  }

  /** Hậu tố phạm vi của quyền trong bảng: 'own' | 'scope' | 'assigned' | null. */
  scopeOf(role, permission) {
    const base = permission.split(':')[0];
    const [group] = base.split('.');
    const hit = (PERMISSIONS[role] || []).find((p) => {
      const pBase = p.split(':')[0];
      return pBase === base || p === `${group}.*` || pBase === `${group}.*`;
    });
    if (!hit) return null;
    const parts = hit.split(':');
    return parts.length > 1 ? parts[1] : null;
  }

  /**
   * Quyết định cho phép hay không, có tính cả phạm vi dữ liệu.
   * @param {string} token
   * @param {string} permission ví dụ 'learner.read'
   * @param {object} target {learnerId?, classId?, userId?}
   */
  authorize(token, permission, target = {}) {
    const s = this.session(token);
    if (!s) { this.stats.denied++; return { ok: false, error: 'INVALID_SESSION' }; }
    const { role, user } = s;

    if (!this.hasPermission(role, permission)) {
      this.stats.denied++;
      this._log('account.denied', { actor: user.id, role, permission, target }, 'DENY', 1);
      return { ok: false, error: 'PERMISSION_DENIED', role, permission };
    }

    const scope = this.scopeOf(role, permission);
    if (scope) {
      const allowed = this._inScope(user, scope, target);
      if (!allowed.ok) {
        this.stats.denied++;
        this._log('account.out_of_scope', { actor: user.id, role, permission, target }, 'DENY', 2);
        return { ok: false, error: 'OUT_OF_SCOPE', reason: allowed.reason, permission };
      }
    }

    this.stats.granted++;
    return { ok: true, userId: user.id, role, scope: scope || 'all', user };
  }

  /** Người này có được đụng vào đối tượng này không. */
  _inScope(user, scope, target) {
    const { learnerId = null, classId = null, userId = null } = target;

    if (scope === 'own') {
      if (userId && userId !== user.id) return { ok: false, reason: 'Chỉ thao tác trên tài khoản của chính mình' };
      if (learnerId) {
        const ln = this.learners.get(learnerId);
        if (!ln || ln.userId !== user.id) return { ok: false, reason: 'Chỉ xem được hồ sơ của chính mình' };
      }
      return { ok: true };
    }

    if (scope === 'assigned') return { ok: true }; // học liệu được giao — lọc ở tầng phát bài

    if (scope === 'scope') {
      const myClasses = new Set(user.scope?.classIds || []);
      const myLearners = new Set(user.scope?.learnerIds || []);

      if (user.role === 'TEACHER') {
        // Giáo viên: lớp mình dạy (lấy cả từ bảng lớp, không chỉ từ scope đã gán).
        const taught = new Set([...myClasses, ...this.classes.by('teacherId', user.id).map((c) => c.id)]);
        if (classId && !taught.has(classId)) return { ok: false, reason: 'Không phải lớp bạn phụ trách' };
        if (learnerId) {
          const ln = this.learners.get(learnerId);
          if (!ln) return { ok: false, reason: 'Không tìm thấy học viên' };
          if (!taught.has(ln.classId)) return { ok: false, reason: 'Học viên không thuộc lớp bạn phụ trách' };
        }
        if (!classId && !learnerId && taught.size === 0) return { ok: false, reason: 'Bạn chưa được phân công lớp nào' };
        return { ok: true };
      }

      if (user.role === 'PARENT') {
        if (learnerId && !myLearners.has(learnerId)) return { ok: false, reason: 'Chỉ xem được con của mình' };
        if (classId) return { ok: false, reason: 'Phụ huynh không xem dữ liệu cả lớp' };
        if (!learnerId && myLearners.size === 0) return { ok: false, reason: 'Chưa gắn học viên nào với tài khoản này' };
        return { ok: true };
      }
    }

    return { ok: true };
  }

  // ── Gán phạm vi ──────────────────────────────────────────────────────────

  /** Gắn con vào tài khoản phụ huynh. */
  linkLearner(parentUserId, learnerId, by = 'admin') {
    const u = this.users.get(parentUserId);
    if (!u) return { ok: false, error: 'NOT_FOUND' };
    if (u.role !== 'PARENT') return { ok: false, error: 'WRONG_ROLE', need: 'PARENT' };
    if (!this.learners.has(learnerId)) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    const ids = new Set(u.scope?.learnerIds || []);
    ids.add(learnerId);
    this.users.patch(parentUserId, { scope: { ...u.scope, learnerIds: [...ids] } });
    this._log('account.link_learner', { actor: by, target: parentUserId, learnerId });
    return { ok: true, parentUserId, learnerIds: [...ids] };
  }

  /** Phân công lớp cho giáo viên. */
  assignClass(teacherUserId, classId, by = 'admin') {
    const u = this.users.get(teacherUserId);
    if (!u) return { ok: false, error: 'NOT_FOUND' };
    if (u.role !== 'TEACHER') return { ok: false, error: 'WRONG_ROLE', need: 'TEACHER' };
    if (!this.classes.has(classId)) return { ok: false, error: 'CLASS_NOT_FOUND' };
    const ids = new Set(u.scope?.classIds || []);
    ids.add(classId);
    this.users.patch(teacherUserId, { scope: { ...u.scope, classIds: [...ids] } });
    this._log('account.assign_class', { actor: by, target: teacherUserId, classId });
    return { ok: true, teacherUserId, classIds: [...ids] };
  }

  stop() { clearInterval(this._gc); }

  status() {
    const byRole = {};
    for (const u of this.users.all()) byRole[u.role] = (byRole[u.role] || 0) + 1;
    const now = Date.now();
    return {
      users: this.users.count(),
      byRole,
      activeSessions: [...this.sessions.values()].filter((s) => s.exp > now).length,
      lockedAccounts: [...this.failures.values()].filter((f) => f.lockedUntil > now).length,
      roles: Object.values(ROLES).map((r) => ({ ...r, permissions: (PERMISSIONS[r.id] || []).length })),
      ...this.stats,
    };
  }
}

module.exports = AccountService;
module.exports.ROLES = ROLES;
module.exports.PERMISSIONS = PERMISSIONS;
module.exports.passwordCheck = passwordCheck;
module.exports.SESSION_TTL_MS = SESSION_TTL_MS;
