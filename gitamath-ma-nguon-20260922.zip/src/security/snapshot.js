'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢO LƯU THEO PHIÊN BẢN & THỜI ĐIỂM
 * ═══════════════════════════════════════════════════════════════════════════
 *  · Ảnh chụp tự động theo chu kỳ + ảnh chụp thủ công có nhãn
 *  · Đánh phiên bản v20.<seq>, kèm mốc thời gian chính xác
 *  · Băm toàn vẹn móc xích: sửa một ảnh là phát hiện được ngay
 *  · Chính sách giữ: phút gần · giờ gần · ngày gần (kiểu ông–cha–con)
 *  · Ghi ra đĩa để sống sót qua khởi động lại tiến trình
 *  · Khôi phục về BẤT KỲ ảnh nào còn giữ
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');
const bus = require('../kernel/eventbus');
const L = require('../logger');
const { round } = require('../utils');
const C = require('./crypto');

const GENESIS = '0'.repeat(64);

/**
 * Chính sách giữ kiểu ông–cha–con.
 *
 * BẢN TRƯỚC MANG ĐÚNG CÁI TÊN NÀY MÀ KHÔNG LÀM ĐÚNG VIỆC ẤY, và lượt thanh
 * tra tìm ra bằng cách mô phỏng ba mươi ngày chụp mỗi mười lăm phút:
 *
 *     chụp 2.881 ảnh trong 30 ngày  →  dọn xong còn 30 ảnh
 *     ảnh CŨ NHẤT còn giữ: 7,3 giờ trước
 *     sổ tay vận hành hứa: 30 ngày
 *
 * Nguyên nhân: mỗi tầng giữ N ảnh MỚI NHẤT nằm trong cửa sổ của nó, mà ba cửa
 * sổ lồng vào nhau — cửa sổ 30 ngày chứa trọn hai cửa sổ kia. Nên hợp của ba
 * tầng chỉ còn là "30 ảnh mới nhất", và ở nhịp 15 phút thì 30 ảnh mới nhất
 * trải đúng bảy tiếng rưỡi.
 *
 * Hậu quả không nằm ở con số: một hỏng dữ liệu phát hiện sau hai ngày thì
 * KHÔNG CÒN GÌ để lui về, trong khi người vận hành đọc sổ tay và tin mình có
 * ba mươi ngày. Cơ chế an toàn sai theo hướng này nguy hiểm hơn không có.
 *
 * Ông–cha–con thật là giữ MỘT ảnh cho MỖI CHU KỲ, không phải N ảnh mới nhất:
 *   · con  — 12 ảnh gần nhất, không chia chu kỳ (nhìn được vài giờ vừa rồi)
 *   · cha  — một ảnh mỗi GIỜ, trong 24 giờ
 *   · ông  — một ảnh mỗi NGÀY, trong 30 ngày
 */
const RETENTION = [
  { name: 'con', kieu: 'moi-nhat', maxAgeMs: 60 * 60_000, keep: 12 },
  { name: 'cha', kieu: 'moi-chu-ky', chuKyMs: 3600_000, maxAgeMs: 27 * 3600_000, keep: 27 },
  { name: 'ong', kieu: 'moi-chu-ky', chuKyMs: 86400_000, maxAgeMs: 34 * 86400_000, keep: 34 },
];

/**
 * Chiều sâu lui về mà chính sách trên CAM KẾT, tính bằng ngày.
 *
 * Cửa sổ khai ở RETENTION rộng hơn con số này có chủ ý. Lý do: giữ MỘT ảnh
 * cho mỗi chu kỳ thì ảnh được giữ là ảnh MỚI NHẤT của chu kỳ ấy, nên ảnh cũ
 * nhất còn lại bao giờ cũng trẻ hơn mép cửa sổ chừng một chu kỳ. Khai cửa sổ
 * đúng bằng 30 ngày thì chiều sâu thật chỉ còn 28 ngày — lại đúng kiểu sai
 * mà bản trước mắc, chỉ nhẹ hơn.
 *
 * Con số dưới đây là thứ được đem đi hứa trong sổ tay, và có mục kiểm mô
 * phỏng 35 ngày để bắt hệ thống chứng minh nó giữ được lời hứa ấy.
 */
const CHIEU_SAU_CAM_KET_NGAY = 30;

class SnapshotStore {
  /**
   * @param {object} opts
   * @param {function} opts.collect  () => ({subsystem: serializableState})
   * @param {function} opts.apply    (data) => appliedSummary
   * @param {string}   opts.dir      thư mục ghi ra đĩa
   */
  constructor({ collect, apply, dir = null, intervalMs = 15 * 60_000, autoStart = false }) {
    this.collect = collect;
    this.apply = apply;
    this.dir = dir || path.join(__dirname, '..', '..', 'data', 'snapshots');
    this.intervalMs = intervalMs;
    this.snapshots = [];
    this.seq = 0;
    this.head = GENESIS;
    this.stats = { taken: 0, restored: 0, pruned: 0, verifyFails: 0, diskWrites: 0 };
    this._timer = null;
    this._loadFromDisk();
    if (autoStart) this.start();
  }

  _ensureDir() {
    try { fs.mkdirSync(this.dir, { recursive: true }); return true; }
    catch (e) { L.warn(`Snapshot: không tạo được thư mục ${this.dir}`, e.message); return false; }
  }

  _loadFromDisk() {
    try {
      if (!fs.existsSync(this.dir)) return;
      const files = fs.readdirSync(this.dir).filter((f) => f.endsWith('.json')).sort();
      for (const f of files) {
        try {
          const snap = JSON.parse(fs.readFileSync(path.join(this.dir, f), 'utf8'));
          this.snapshots.push(snap);
          this.seq = Math.max(this.seq, snap.seq || 0);
          this.head = snap.hash;
        } catch { /* bỏ qua file hỏng */ }
      }
      if (this.snapshots.length) L.ok(`Snapshot: nạp ${this.snapshots.length} ảnh từ đĩa`);
    } catch (e) {
      L.warn('Snapshot: không nạp được từ đĩa', e.message);
    }
  }

  start() {
    if (this._timer) return this;
    this._timer = setInterval(() => { this.take({ label: 'auto', auto: true }).catch(() => {}); }, this.intervalMs);
    if (this._timer.unref) this._timer.unref();

    // CHỤP NGAY MỘT ẢNH KHI KHỞI ĐỘNG, nếu ảnh mới nhất đã quá một chu kỳ
    // (hoặc chưa có ảnh nào). Không có dòng này thì bộ hẹn giờ chỉ hứa suông
    // trong hai trường hợp thật:
    //
    //   · Vừa khởi động xong: suốt một chu kỳ đầu tiên không có gì để lui về,
    //     đúng lúc hệ dễ hỏng nhất — ngay sau khi đổi mã, đổi cấu hình.
    //   · Khởi động lại dày hơn chu kỳ: máy chủ dựng lại mỗi 10 phút trong khi
    //     chu kỳ là 15 phút thì bộ hẹn giờ KHÔNG BAO GIỜ tới lượt chạy, và số
    //     ảnh đứng yên ở 0 vĩnh viễn dù nhật ký vẫn báo "tự động mỗi 15 phút".
    //
    // Tổ thanh tra bắt được đúng chỗ này: TT01 báo "chưa có ảnh chụp nào để
    // lui về" ngay sau khi bộ hẹn giờ được bật. Bộ hẹn giờ chạy không có
    // nghĩa là đường lui đã có.
    const ds = this.snapshots || [];
    const moiNhat = ds.length ? Math.max(...ds.map((x) => x.at || 0)) : 0;
    if (Date.now() - moiNhat >= this.intervalMs) {
      this.take({ label: 'khoi-dong', auto: true }).catch(() => {});
    }

    L.ok(`Snapshot: tự động mỗi ${round(this.intervalMs / 60000, 1)} phút`);
    return this;
  }

  stop() { if (this._timer) { clearInterval(this._timer); this._timer = null; } }

  /** Chụp ảnh trạng thái hiện tại. */
  async take({ label = 'manual', auto = false, note = null } = {}) {
    const data = await this.collect();
    this.seq++;
    const at = Date.now();
    const version = `v20.${String(this.seq).padStart(5, '0')}`;

    const summary = {};
    for (const [k, v] of Object.entries(data)) {
      summary[k] = Array.isArray(v) ? v.length
        : v && typeof v === 'object' ? Object.keys(v).length : 1;
    }

    const body = JSON.stringify(data);
    const snap = {
      id: `SNAP-${version}`,
      seq: this.seq,
      version,
      at,
      iso: new Date(at).toISOString(),
      label,
      auto,
      note,
      prev: this.head,
      bytes: Buffer.byteLength(body),
      summary,
      dataHash: C.sha256hex(body),
      data,
    };
    snap.hash = C.sha256hex(`${snap.seq}|${snap.prev}|${snap.at}|${snap.dataHash}`);
    this.head = snap.hash;

    this.snapshots.push(snap);
    this.stats.taken++;
    this._writeToDisk(snap);
    this.prune();

    bus.safeEmit('snapshot:taken', { id: snap.id, version, label, bytes: snap.bytes });
    return { ok: true, id: snap.id, version, at, iso: snap.iso, label, bytes: snap.bytes, summary, prev: snap.prev, hash: snap.hash };
  }

  _writeToDisk(snap) {
    if (!this._ensureDir()) return;
    try {
      fs.writeFileSync(path.join(this.dir, `${snap.version}.json`), JSON.stringify(snap));
      this.stats.diskWrites++;
    } catch (e) {
      L.warn('Snapshot: ghi đĩa thất bại', e.message);
    }
  }

  /** Chọn ảnh theo phiên bản, thời điểm, hoặc id. Thời điểm lấy ảnh GẦN NHẤT TRƯỚC mốc đó. */
  resolve(sel = {}) {
    if (sel.snapshotId) return this.snapshots.find((s) => s.id === sel.snapshotId) || null;
    if (sel.version) return this.snapshots.find((s) => s.version === sel.version) || null;
    if (sel.at) {
      const t = typeof sel.at === 'string' ? Date.parse(sel.at) : Number(sel.at);
      const before = this.snapshots.filter((s) => s.at <= t);
      return before.length ? before[before.length - 1] : null;
    }
    if (sel.latest !== false && this.snapshots.length) return this.snapshots[this.snapshots.length - 1];
    return null;
  }

  /** Kiểm tra toàn vẹn: băm dữ liệu và móc xích với ảnh trước. */
  verify(snapshotId = null) {
    if (snapshotId) {
      const s = this.snapshots.find((x) => x.id === snapshotId);
      if (!s) return { ok: false, error: 'NOT_FOUND' };
      const dataHash = C.sha256hex(JSON.stringify(s.data));
      const hash = C.sha256hex(`${s.seq}|${s.prev}|${s.at}|${dataHash}`);
      const ok = dataHash === s.dataHash && hash === s.hash;
      if (!ok) this.stats.verifyFails++;
      return { ok, snapshotId, dataHashMatch: dataHash === s.dataHash, chainHashMatch: hash === s.hash };
    }
    // Kiểm tra toàn chuỗi
    let prev = this.snapshots.length ? this.snapshots[0].prev : GENESIS;
    for (const s of this.snapshots) {
      const dataHash = C.sha256hex(JSON.stringify(s.data));
      const hash = C.sha256hex(`${s.seq}|${prev}|${s.at}|${dataHash}`);
      if (dataHash !== s.dataHash || hash !== s.hash || s.prev !== prev) {
        this.stats.verifyFails++;
        return { ok: false, brokenAt: s.version, expected: hash, got: s.hash };
      }
      prev = s.hash;
    }
    return { ok: true, snapshots: this.snapshots.length, head: this.head };
  }

  /** Khôi phục — gọi hàm apply() do hệ thống cung cấp. */
  restore(snapshotId) {
    const s = this.snapshots.find((x) => x.id === snapshotId);
    if (!s) return { ok: false, error: 'NOT_FOUND' };
    const v = this.verify(snapshotId);
    if (!v.ok) return { ok: false, error: 'INTEGRITY_FAILED', detail: v };
    const applied = this.apply(s.data);
    this.stats.restored++;
    bus.safeEmit('snapshot:restored', { id: s.id, version: s.version });
    return { ok: true, snapshotId, version: s.version, iso: s.iso, applied };
  }

  /** Áp dụng chính sách giữ — luôn giữ ảnh thủ công có nhãn. */
  prune() {
    const now = Date.now();
    const keep = new Set();
    for (const s of this.snapshots) if (!s.auto) keep.add(s.id); // ảnh thủ công: giữ

    for (const tier of RETENTION) {
      const inTier = this.snapshots.filter((s) => now - s.at <= tier.maxAgeMs);
      if (tier.kieu === 'moi-nhat') {
        // Tầng "con": giữ thẳng N ảnh mới nhất — đây là chỗ cần dày.
        for (const s of inTier.slice(-tier.keep)) keep.add(s.id);
        continue;
      }
      // Tầng "cha" và "ông": MỘT ảnh cho MỖI chu kỳ, lấy ảnh mới nhất của chu
      // kỳ ấy. Đây là chỗ bản trước làm sai, và là chỗ quyết định chiều sâu
      // lui về có đúng như sổ tay hứa hay không.
      const theoChuKy = new Map();
      for (const s of inTier) {
        const o = Math.floor(s.at / tier.chuKyMs);
        const cu = theoChuKy.get(o);
        if (!cu || s.at > cu.at) theoChuKy.set(o, s);
      }
      const cacO = [...theoChuKy.keys()].sort((a, b) => a - b).slice(-tier.keep);
      for (const o of cacO) keep.add(theoChuKy.get(o).id);
    }

    const before = this.snapshots.length;
    const removed = this.snapshots.filter((s) => !keep.has(s.id));
    this.snapshots = this.snapshots.filter((s) => keep.has(s.id));
    this.stats.pruned += before - this.snapshots.length;

    for (const s of removed) {
      try { fs.unlinkSync(path.join(this.dir, `${s.version}.json`)); } catch { /* không có thì thôi */ }
    }
    return { removed: before - this.snapshots.length, kept: this.snapshots.length };
  }

  list({ limit = 30 } = {}) {
    return this.snapshots.slice(-limit).reverse().map((s) => ({
      id: s.id, version: s.version, iso: s.iso, ageMinutes: round((Date.now() - s.at) / 60000, 1),
      label: s.label, auto: s.auto, bytes: s.bytes, summary: s.summary, hash: s.hash.slice(0, 12),
    }));
  }

  /** Điểm khôi phục khả dụng gần các mốc thời gian thường dùng. */
  timeline() {
    const now = Date.now();
    const marks = [
      { name: '15 phút trước', at: now - 15 * 60_000 },
      { name: '1 giờ trước', at: now - 3600_000 },
      { name: '6 giờ trước', at: now - 6 * 3600_000 },
      { name: '24 giờ trước', at: now - 86400_000 },
      { name: '7 ngày trước', at: now - 7 * 86400_000 },
    ];
    return marks.map((m) => {
      const s = this.resolve({ at: m.at });
      return { ...m, iso: new Date(m.at).toISOString(), snapshot: s ? { id: s.id, version: s.version, iso: s.iso } : null };
    });
  }

  status() {
    const oldest = this.snapshots[0];
    const newest = this.snapshots[this.snapshots.length - 1];
    return {
      count: this.snapshots.length,
      head: this.head,
      seq: this.seq,
      autoIntervalMin: round(this.intervalMs / 60000, 1),
      running: !!this._timer,
      dir: this.dir,
      retention: RETENTION,
      oldest: oldest ? { version: oldest.version, iso: oldest.iso } : null,
      newest: newest ? { version: newest.version, iso: newest.iso } : null,
      totalBytes: this.snapshots.reduce((s, x) => s + x.bytes, 0),
      chainIntegrity: this.verify().ok ? 'INTACT' : 'BROKEN',
      stats: { ...this.stats },
    };
  }
}

module.exports = SnapshotStore;
module.exports.RETENTION = RETENTION;
module.exports.CHIEU_SAU_CAM_KET_NGAY = CHIEU_SAU_CAM_KET_NGAY;
