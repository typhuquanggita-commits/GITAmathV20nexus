'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  VÒNG CẢI TIẾN HỢP NHẤT — trò chuyện dạy cho nội dung, nội dung dạy lại
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Đây là chỗ duy nhất hai phần THỰC SỰ hợp nhất. Không có vòng này thì
 *  "hợp nhất" chỉ là hai mô-đun nằm chung một thư mục.
 *
 *      Chat → Nội dung   Câu nào phụ huynh hỏi đi hỏi lại trong khung chat
 *                        mà trang giới thiệu không trả lời? Trang thiếu.
 *
 *      Nội dung → Chat   Mảng nội dung nào người đọc phản hồi xấu, hoặc
 *                        không ai trích dẫn? Chat đang nói theo cách ấy thì
 *                        cũng đang nói sai cách.
 *
 *  ── LUẬT CỨNG: VÒNG NÀY KHÔNG TỰ SỬA TRANG ──────────────────────────────
 *
 *  Nó ĐỀ XUẤT. Người duyệt. Lý do không phải sự thận trọng chung chung mà là
 *  một lý do cụ thể: một vòng tự sửa trang theo số liệu sẽ trôi dần về phía
 *  câu chữ nào được bấm nhiều nhất — và câu được bấm nhiều nhất trong ngành
 *  này thường là câu hứa nhiều nhất. Vòng tối ưu theo lượt bấm sẽ TỰ ĐI TỚI
 *  chỗ hứa hẹn, không cần ai cố ý.
 *
 *  Nên cửa cuối cùng luôn là một con người. Máy chỉ ra chỗ thiếu; người quyết
 *  định viết gì vào chỗ ấy.
 *
 *  ── VÀ NÓ KHAI LUÔN CHỖ NÓ KHÔNG ĐO ĐƯỢC ────────────────────────────────
 *
 *  Chưa có ai ghi nhận việc một mô hình ngôn ngữ ngoài trích dẫn trang này.
 *  Nên chỉ số trích dẫn ở đây LUÔN bằng không, và vòng cải tiến nói thẳng
 *  rằng nó bằng không vì CHƯA NỐI NGUỒN, chứ không phải vì trang dở.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');

/** Hỏi bao nhiêu lần trở lên thì coi là câu hỏi lặp. */
const LAP_DANG_KE = 3;

/** Chỉ số CHƯA nối nguồn — khai ra, không in số 0 như thể đã đo. */
const CHUA_NOI_NGUON = {
  'trich-dan-mo-hinh-ngoai': 'Chưa có cách ghi nhận khi một mô hình ngôn ngữ bên ngoài trích dẫn trang này. '
    + 'Muốn đo thì phải có nhật ký máy chủ của bên ấy — hệ này không có.',
  'thu-hang-tim-kiem': 'Chưa nối với công cụ quản trị tìm kiếm nào.',
  'thoi-gian-doc-trang': 'Chưa đặt mã đo trên trang công khai.',
};

class VongCaiTien {
  constructor({ doThi, choDuyet = [] } = {}) {
    this.doThi = doThi;
    this.choDuyet = choDuyet;
    this.lanChay = 0;
  }

  /**
   * Gom câu hỏi từ nhật ký trò chuyện.
   *
   * @param {Array} nhatKyChat  các dòng {viec, biChan, soCongCuCoDuLieu}
   */
  docTuChat(nhatKyChat = []) {
    const theoViec = new Map();
    let chan = 0;
    let rong = 0;
    for (const d of nhatKyChat) {
      if (d.biChan) { chan += 1; continue; }
      const v = d.viec || 'khong-ro';
      const t = theoViec.get(v) || { viec: v, lan: 0, lanRong: 0 };
      t.lan += 1;
      if (!d.soCongCuCoDuLieu) { t.lanRong += 1; rong += 1; }
      theoViec.set(v, t);
    }
    return {
      soLuot: nhatKyChat.length,
      soChan: chan,
      soLuotKhongCoDuLieu: rong,
      theoViec: [...theoViec.values()].sort((a, b) => b.lan - a.lan),
    };
  }

  /** Đọc hiệu quả nội dung từ đồ thị. */
  docTuNoiDung() {
    const mang = this.doThi ? this.doThi.theoLoai('mang-noi-dung') : [];
    return mang.map((m) => ({
      id: m.id,
      ten: m.ten || m.id,
      soTrichDan: this.doThi.soLanTrichDan(m.id),
      soPhanHoi: this.doThi.phanHoiCua(m.id).length,
      soPhanHoiXau: this.doThi.phanHoiCua(m.id).filter((p) => p.sacThai === 'xau').length,
      gapYDinh: this.doThi.diNguoc(m.id, 'tao-ra').length,
    }));
  }

  /**
   * Tìm chỗ lệch giữa hai bên. Mỗi chỗ lệch nói rõ BẰNG CHỨNG nào dẫn tới nó.
   */
  timChoLech(chat, noiDung) {
    const lech = [];

    // Lệch 1 — câu hỏi lặp mà công cụ không có dữ liệu để trả lời.
    for (const v of chat.theoViec) {
      if (v.lan >= LAP_DANG_KE && v.lanRong / v.lan > 0.5) {
        lech.push({
          loai: 'hoi-nhieu-ma-khong-co-du-lieu',
          viec: v.viec,
          bangChung: `${v.lan} lượt hỏi, ${v.lanRong} lượt không công cụ nào có dữ liệu.`,
          deXuat: `Kiểm xem việc "${v.viec}" có thiếu công cụ đọc, hay kho phía sau thật sự chưa có gì.`,
          tuSuaDuoc: false,
        });
      }
    }

    // Lệch 2 — mảng nội dung không gắn với ý định nào.
    for (const m of noiDung) {
      if (!m.gapYDinh) {
        lech.push({
          loai: 'noi-dung-khong-tra-loi-cau-hoi-nao',
          mang: m.id,
          bangChung: `Mảng "${m.ten}" không nối với ý định nào trong đồ thị.`,
          deXuat: 'Hoặc nối nó với câu hỏi mà nó trả lời, hoặc bỏ nó khỏi trang.',
          tuSuaDuoc: false,
        });
      }
      if (m.soPhanHoi >= LAP_DANG_KE && m.soPhanHoiXau / m.soPhanHoi > 0.5) {
        lech.push({
          loai: 'nguoi-doc-phan-hoi-xau',
          mang: m.id,
          bangChung: `${m.soPhanHoiXau}/${m.soPhanHoi} phản hồi là xấu.`,
          deXuat: `Đọc lại mảng "${m.ten}" — và soi luôn cách trợ lý trò chuyện nói về phần này.`,
          tuSuaDuoc: false,
        });
      }
    }

    // Lệch 3 — lượt bị chặn nhiều bất thường.
    if (chat.soLuot >= 10 && chat.soChan / chat.soLuot > 0.3) {
      lech.push({
        loai: 'chan-qua-nhieu',
        bangChung: `${chat.soChan}/${chat.soLuot} lượt bị chặn.`,
        deXuat: 'Đọc nhật ký xem lớp nào chặn. Chặn nhiều thường là bảng việc còn thiếu, '
          + 'chứ hiếm khi là có nhiều người tấn công đến thế.',
        tuSuaDuoc: false,
      });
    }

    return lech;
  }

  /** Chạy một vòng. Kết quả luôn là ĐỀ XUẤT, không bao giờ là thay đổi. */
  chay({ nhatKyChat = [] } = {}) {
    this.lanChay += 1;
    const chat = this.docTuChat(nhatKyChat);
    const noiDung = this.docTuNoiDung();
    const lech = this.timChoLech(chat, noiDung);
    for (const l of lech) this.choDuyet.push({ ...l, luc: new Date().toISOString(), trangThai: 'cho-nguoi-duyet' });
    return {
      ok: true,
      lanChay: this.lanChay,
      chat, noiDung, lech,
      soDeXuat: lech.length,
      tuApDung: 0,
      vi: 'Vòng này KHÔNG tự sửa trang. Mọi đề xuất đều vào hàng chờ người duyệt — '
        + 'vì một vòng tối ưu theo lượt bấm sẽ tự đi tới chỗ hứa hẹn mà không cần ai cố ý.',
      chuaNoiNguon: CHUA_NOI_NGUON,
    };
  }

  status() {
    return {
      lanChay: this.lanChay,
      dangCho: this.choDuyet.length,
      tuSuaDuoc: false,
      soChiSoChuaNoiNguon: Object.keys(CHUA_NOI_NGUON).length,
      chuaNoiNguon: CHUA_NOI_NGUON,
    };
  }
}

module.exports = VongCaiTien;
module.exports.CHUA_NOI_NGUON = CHUA_NOI_NGUON;
