'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỰNG TRANG TĨNH CHO CLOUDFLARE PAGES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ── NÓI THẲNG ĐIỀU GÌ CHẠY ĐƯỢC TRÊN CLOUDFLARE VÀ ĐIỀU GÌ KHÔNG ────────
 *
 *  Cloudflare Pages phục vụ TỆP TĨNH. Nó không chạy một tiến trình Node lâu
 *  dài, không có hệ tệp ghi được, không giữ trạng thái giữa hai yêu cầu.
 *  GITAmathV20nexus thì ngược lại: một máy chủ Node chạy liên tục, ghi xuống
 *  đĩa, giữ 500 trợ lý trong bộ nhớ, dựng video vào thư mục.
 *
 *  Nên nói cho rõ, vì đây là chỗ dễ hứa quá tay nhất:
 *
 *      LÊN ĐƯỢC Cloudflare Pages:
 *        · Toàn bộ trang giới thiệu — dựng sẵn thành HTML lúc build, số liệu
 *          đóng băng tại thời điểm dựng, không gọi API nào
 *        · Sơ đồ tư duy ba chiều dạng ảnh SVG tĩnh
 *        · Kịch bản lời đọc của 36 video hướng dẫn
 *        · Mọi tệp giao diện
 *
 *      KHÔNG LÊN ĐƯỢC, cần máy chủ Node thật:
 *        · Đăng nhập, tài khoản, phiên
 *        · Trợ lý trò chuyện (đọc dữ liệu học viên thật)
 *        · Dựng video, dựng bài giảng
 *        · Mọi thứ ghi xuống đĩa
 *
 *  Cách nối hai phần: Cloudflare phục vụ phần tĩnh; phần động trỏ về máy chủ
 *  Node qua một tên miền con, và Cloudflare Tunnel đưa máy chủ ấy ra mà không
 *  cần mở cổng. Tệp _redirects dựng sẵn đúng đường ấy.
 *
 *  ── SỐ LIỆU ĐÓNG BĂNG, VÀ NÓI RA NGÀY ĐÓNG BĂNG ─────────────────────────
 *
 *  Trang tĩnh mang số liệu của lúc dựng. Nên mỗi trang in rõ ngày dựng. Một
 *  con số không ghi ngày là một con số không kiểm lại được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const xuong = require('./xuong-noi-dung');
const luat = require('./luat-noi-dung');

const thoat = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

/**
 * Chính sách nội dung. Chặt hết mức trang này chịu được:
 * không kịch bản ngoài, không khung nhúng, không gửi biểu mẫu đi đâu.
 */
const CSP = [
  "default-src 'self'",
  "script-src 'none'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data:",
  "font-src 'self'",
  "connect-src 'self'",
  "frame-ancestors 'none'",
  "form-action 'none'",
  "base-uri 'none'",
  "object-src 'none'",
].join('; ');

function kieuChu() {
  return `:root{--nen:#f6f8fc;--the:#fff;--chu:#16233a;--nhat:#5a6a86;--vien:#d7e0ee;--nhan:#2b5fab}
@media(prefers-color-scheme:dark){:root:not([data-theme="light"]){--nen:#0d1522;--the:#152033;--chu:#e8eef7;--nhat:#a3b1c6;--vien:#26344a}}
:root[data-theme="dark"]{--nen:#0d1522;--the:#152033;--chu:#e8eef7;--nhat:#a3b1c6;--vien:#26344a}
*{box-sizing:border-box}
body{margin:0;background:var(--nen);color:var(--chu);font:16px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif}
.khung{max-width:880px;margin:0 auto;padding:32px 16px 72px}
h1{font-size:30px;line-height:1.25;margin:0 0 10px}
h2{font-size:21px;margin:36px 0 12px}
h3{font-size:17px;margin:20px 0 6px}
p{margin:0 0 12px}
.phu{color:var(--nhat)}
.the{background:var(--the);border:1px solid var(--vien);border-radius:14px;padding:18px 20px;margin:14px 0}
ul{margin:8px 0 12px;padding-left:20px}
li{margin:5px 0}
.nut{display:inline-block;background:var(--nhan);color:#fff;text-decoration:none;border-radius:10px;padding:11px 20px;font-weight:700;margin-top:8px}
.o{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}
.chan{margin-top:48px;padding-top:18px;border-top:1px solid var(--vien);color:var(--nhat);font-size:13px}
.nguon{font-size:12px;color:var(--nhat);margin-top:6px}
table{border-collapse:collapse;width:100%;font-size:14px}
th,td{text-align:left;padding:7px 9px;border-bottom:1px solid var(--vien)}
th{color:var(--nhat);font-weight:600}
@media(max-width:600px){.khung{padding:20px 16px 56px}h1{font-size:25px}}`;
}

function veMang(m) {
  const c = m.chu;
  let than = '';
  if (c.tieu) than += `<h2>${thoat(c.tieu)}</h2>`;
  if (c.phu) than += `<p>${thoat(c.phu)}</p>`;
  if (c.y) than += `<ul>${c.y.map((x) => `<li>${thoat(x)}</li>`).join('')}</ul>`;
  if (c.muc) than += `<div class="o">${c.muc.map((x) => `<div class="the"><h3>${thoat(x.ten)}</h3><p class="phu">${thoat(x.y)}</p></div>`).join('')}</div>`;
  if (c.buoc) than += `<ul>${c.buoc.map((x) => `<li>${thoat(x)}</li>`).join('')}</ul>`;
  if (c.hoi) than += c.hoi.map((x) => `<div class="the"><h3>${thoat(x.h)}</h3><p class="phu">${thoat(x.d)}</p></div>`).join('');
  if (c.nut) than += `<a class="nut" href="/so-do.html">${thoat(c.nut)}</a>`;
  const ng = (m.nguonSo || []).map((n) => `${n.so} = ${n.giaTri} (${n.nguon})`).join(' · ');
  if (ng) than += `<p class="nguon">Nguồn số liệu: ${thoat(ng)}</p>`;
  return `<section>${than}</section>`;
}

function trangChu(trang, { ngayDung, banSvg = null, tieuDe = null, moTa = null }) {
  // Tiêu đề và mô tả PHẢI đặt được riêng. Bản đầu viết cứng tiêu đề trang
  // chủ vào đây, nên trang hướng dẫn dựng bằng cùng hàm này mang tiêu đề
  // "Học toán theo đúng thứ tự kiến thức" — sai hẳn nội dung, và đó là dòng
  // chữ hiện trên thẻ trình duyệt lẫn kết quả tìm kiếm.
  const tieu = tieuDe || 'GITAmath — Học toán theo đúng thứ tự kiến thức';
  const mo = moTa || `Chương trình ${trang.soLieu.soDang} dạng toán xếp theo ${trang.soLieu.soTang} tầng. `
    + 'Mỗi dạng chỉ mở ra khi những dạng cần biết trước đã học xong.';
  return `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${thoat(tieu)}</title>
<meta name="description" content="${thoat(mo)}">
<style>${kieuChu()}</style>
</head>
<body>
<div class="khung">
<h1>${thoat(tieu.replace(/^GITAmath — /, '') === tieu ? 'GITAmath' : 'GITAmath')}</h1>
<p class="phu">Trang này dựng sẵn thành tệp tĩnh. Mọi con số dưới đây đọc từ hệ thống đang chạy lúc dựng — ${thoat(ngayDung)}.</p>
${trang.mang.map(veMang).join('\n')}
${banSvg ? `<h2>Sơ đồ chương trình</h2><div class="the">${banSvg}</div>` : ''}
<div class="chan">
  <p>GITAmath · bản ${thoat(trang.soLieu.phienBan || '')}. Trang tĩnh dựng ngày ${thoat(ngayDung)}.</p>
  <p>Phần đăng nhập, trò chuyện và dựng bài giảng chạy trên máy chủ riêng, không nằm trên trang này.</p>
</div>
</div>
</body>
</html>`;
}

function trangSoDo(svg, { ngayDung }) {
  return `<!DOCTYPE html>
<html lang="vi">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>GITAmath — Sơ đồ chương trình</title>
<meta name="description" content="Sơ đồ tư duy ba chiều của toàn bộ chương trình toán.">
<style>${kieuChu()}</style></head>
<body><div class="khung">
<h1>Sơ đồ chương trình</h1>
<p class="phu">Ảnh tĩnh dựng ngày ${thoat(ngayDung)}. Bản xoay được bằng chuột nằm trong ứng dụng, cần đăng nhập.</p>
<div class="the">${svg}</div>
<p class="nguon">Mỗi chấm là một dạng toán có thật trong chương trình; mỗi đường là một quan hệ "cần biết trước" đã khai.</p>
<p><a class="nut" href="/">Về trang chủ</a></p>
</div></body></html>`;
}

function trangKichBan(danhMuc, { ngayDung }) {
  return `<!DOCTYPE html>
<html lang="vi">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>GITAmath — Kịch bản video hướng dẫn</title>
<meta name="description" content="Danh mục kịch bản lời đọc của bộ video hướng dẫn theo vai.">
<style>${kieuChu()}</style></head>
<body><div class="khung">
<h1>Kịch bản video hướng dẫn</h1>
<p class="phu">${danhMuc.soMan} màn hình × ${danhMuc.soVai} vai = ${danhMuc.soVideo} video. Danh mục dựng ngày ${thoat(ngayDung)}.</p>
<p>Mỗi kịch bản gồm tám chương. Chương thứ ba — quyền của vai người xem trên màn ấy — đọc thẳng từ bảng cổng quyền của hệ thống, không khai tay.</p>
<table><thead><tr><th>Màn hình</th><th>Vai</th><th>Quyền màn</th><th>Đủ quyền</th><th>Chương</th><th>Ước chừng</th></tr></thead><tbody>
${danhMuc.muc.map((m) => `<tr><td>${thoat(m.ten)}</td><td>${thoat(m.tenVai)}</td><td>${thoat(m.mucQuyenMan)}</td><td>${m.duQuyen ? 'có' : 'chưa'}</td><td>${m.soChuong}</td><td>${m.giayUocTinh}s</td></tr>`).join('\n')}
</tbody></table>
<p class="nguon">Giọng đọc dựng tại máy bằng bộ tổng hợp tiếng Việt của hệ thống — không gọi dịch vụ ngoài, chi phí bằng không. Ai có bản thu người thật thì nạp vào đúng chương.</p>
<p><a class="nut" href="/">Về trang chủ</a></p>
</div></body></html>`;
}

/** Soi tệp đã dựng: bắt đúng những thứ làm hỏng một trang tĩnh. */
function soiTrangTinh(html, { tenTep }) {
  const loi = [];
  if (/<script/i.test(html)) loi.push(`${tenTep}: có thẻ script — chính sách nội dung cấm`);
  if (/\son\w+\s*=/i.test(html)) loi.push(`${tenTep}: có thuộc tính bắt sự kiện`);
  const ngoai = (html.match(/https?:\/\/[^"' )]+/g) || []).filter((u) => u !== 'http://www.w3.org/2000/svg');
  if (ngoai.length) loi.push(`${tenTep}: gọi ra ngoài: ${ngoai.slice(0, 2).join(', ')}`);
  if (!/<title>/i.test(html)) loi.push(`${tenTep}: thiếu tiêu đề`);
  if (!/name="description"/i.test(html)) loi.push(`${tenTep}: thiếu mô tả`);
  if (!/lang="vi"/.test(html)) loi.push(`${tenTep}: thiếu khai ngôn ngữ`);
  // Luật nội dung chạy HAI lượt, vì hai loại chữ khác nhau:
  //   · cả trang, KHÔNG đo nhồi — bắt hứa hẹn, chẩn đoán, lộ phân loại
  //   · riêng phần văn xuôi (bỏ bảng), CÓ đo nhồi
  // Gộp một lượt thì bảng dữ liệu làm phép đo văn xuôi báo đỏ oan.
  const chu = html.replace(/<[^>]+>/g, ' ');
  const vanXuoi = html.replace(/<table[\s\S]*?<\/table>/gi, ' ').replace(/<[^>]+>/g, ' ');
  const kCa = luat.soi(chu, { tenTrang: tenTep, doNhoi: false });
  if (!kCa.dat) loi.push(`${tenTep}: không qua luật nội dung — ${kCa.loi.map((x) => x.ma).join(', ')}`);
  const kVan = luat.soi(vanXuoi, { tenTrang: tenTep, doNhoi: true });
  const chiNhoi = kVan.loi.filter((x) => x.ma === 'nhoi-tu-khoa');
  if (chiNhoi.length) loi.push(`${tenTep}: văn xuôi nhồi từ khoá — ${chiNhoi[0].chiTiet}`);
  return loi;
}

module.exports = { trangChu, trangSoDo, trangKichBan, soiTrangTinh, kieuChu, CSP, thoat };
