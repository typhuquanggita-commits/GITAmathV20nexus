'use strict';
/**
 * Roster — sinh danh sách 500 agent TẤT ĐỊNH từ bảng phân công.
 * Cùng một đầu ra sau mỗi lần khởi động: cùng id, cùng tổ, cùng quyền, cùng công suất.
 */

const { DIVISIONS, RANKS, ALLOCATION, SQUAD_SIZE, scopePermission, validateTaxonomy } = require('./taxonomy');
const { pad } = require('../utils');

/** Thứ tự xếp chỗ trong tổ: chỉ huy trước, để mỗi tổ chắc chắn có người đứng đầu. */
const SEAT_ORDER = ['PLANNER', 'CRITIC', 'GUARDIAN', 'COACH', 'RESEARCHER', 'WORKER'];

function buildRoster() {
  const check = validateTaxonomy();
  if (!check.ok) {
    throw new Error(`Bảng phân công không hợp lệ:\n - ${check.errors.join('\n - ')}`);
  }

  const agents = [];
  const squads = [];

  for (const divId of Object.keys(DIVISIONS)) {
    const div = DIVISIONS[divId];
    const row = ALLOCATION[divId];
    const squadCount = div.size / SQUAD_SIZE;

    // 1) Dựng danh sách cấp bậc của khối theo thứ tự chỗ ngồi
    const ranksFlat = [];
    for (const rankId of SEAT_ORDER) {
      for (let i = 0; i < (row[rankId] || 0); i++) ranksFlat.push(rankId);
    }

    // 2) Chia vòng tròn vào các tổ → chỉ huy phân bổ đều, mỗi tổ đúng SQUAD_SIZE người
    const buckets = Array.from({ length: squadCount }, () => []);
    ranksFlat.forEach((rankId, i) => buckets[i % squadCount].push(rankId));

    buckets.forEach((members, sIdx) => {
      const squadName = div.squads[sIdx];
      const squadId = `${div.code}-S${sIdx + 1}`;
      const seats = [];

      members.forEach((rankId, seatIdx) => {
        const rank = RANKS[rankId];
        const seq = agents.length + 1;
        const agentId = `${div.code}-${pad(seq, 3)}`;
        const tier = rank.tierOverride || div.defaultTier;

        const agent = {
          id: agentId,
          seq,
          // ── Tổ chức ──
          division: divId,
          divisionName: div.name,
          squad: squadId,
          squadName,
          seat: seatIdx + 1,
          // ── Vai trò & chức năng ──
          rank: rankId,
          rankName: rank.name,
          duty: rank.duty,
          specialty: div.specialty,
          mission: div.mission,
          systemPrompt: div.systemPrompt,
          // ── Quyền hạn ──
          permissions: [...rank.permissions, scopePermission(divId)],
          scope: div.scope,
          tier,
          // ── Công suất ──
          capacity: { ...rank.capacity },
          // ── Ngưỡng KPI ──
          kpiTargets: { ...rank.kpi },
          // ── Trạng thái vận hành ──
          state: 'IDLE',
          suspendedUntil: 0,
        };

        agents.push(agent);
        seats.push({ agentId, rank: rankId });
      });

      squads.push({
        id: squadId,
        name: squadName,
        division: divId,
        divisionName: div.name,
        size: members.length,
        lead: seats.find((s) => s.rank === 'PLANNER')?.agentId
          || seats.find((s) => s.rank === 'CRITIC')?.agentId
          || seats[0].agentId,
        composition: members.reduce((m, r) => { m[r] = (m[r] || 0) + 1; return m; }, {}),
        members: seats.map((s) => s.agentId),
      });
    });
  }

  return { agents, squads, check };
}

/** Bảng tổng hợp phân công, dùng cho API /agents/assignment và scripts/roster-table.js */
function assignmentTable(agents) {
  const byDivision = {};
  for (const a of agents) {
    const d = (byDivision[a.division] ??= {
      division: a.division,
      name: a.divisionName,
      specialty: a.specialty,
      scope: a.scope,
      mission: a.mission,
      total: 0,
      ranks: {},
      squads: {},
      capacity: { concurrent: 0, tokensPerMin: 0, tasksPerHour: 0 },
    });
    d.total++;
    d.ranks[a.rank] = (d.ranks[a.rank] || 0) + 1;
    d.squads[a.squadName] = (d.squads[a.squadName] || 0) + 1;
    d.capacity.concurrent += a.capacity.maxConcurrent;
    d.capacity.tokensPerMin += a.capacity.tokensPerMin;
    d.capacity.tasksPerHour += a.capacity.tasksPerHour;
  }

  const byRank = {};
  for (const a of agents) {
    const r = (byRank[a.rank] ??= {
      rank: a.rank, name: a.rankName, duty: a.duty, total: 0,
      permissions: a.permissions.filter((p) => !p.endsWith('.*') || p.split('.')[0].length > 4),
      capacity: { ...a.capacity }, kpiTargets: { ...a.kpiTargets }, divisions: {},
    });
    r.total++;
    r.divisions[a.division] = (r.divisions[a.division] || 0) + 1;
  }

  const totals = agents.reduce((t, a) => {
    t.concurrent += a.capacity.maxConcurrent;
    t.tokensPerMin += a.capacity.tokensPerMin;
    t.tasksPerHour += a.capacity.tasksPerHour;
    return t;
  }, { concurrent: 0, tokensPerMin: 0, tasksPerHour: 0 });

  return {
    total: agents.length,
    byDivision: Object.values(byDivision),
    byRank: Object.values(byRank),
    capacityTotals: totals,
  };
}

module.exports = { buildRoster, assignmentTable, SEAT_ORDER };
