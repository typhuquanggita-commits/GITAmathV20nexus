'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHO DỮ LIỆU CRM — tám bộ sưu tập, đều bền vững qua tắt máy
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  VÌ SAO CRM PHẢI CÓ KHO RIÊNG. Bản thiết kế gốc để các công cụ trả về dữ
 *  liệu giả lập: "Công ty ABC, 500 triệu, đang thương lượng". Chạy thì đẹp,
 *  nhưng ngày cắm vào việc thật thì hệ thống đang phục vụ những con số chưa
 *  bao giờ tồn tại. Hệ này có một luật đã thành nếp: KHÔNG BỊA SỐ. Sổ cái dòng
 *  tiền từ chối ghi khoản chưa nối nguồn thay vì điền đại cho đủ bảng.
 *
 *  Nên thay vì giả lập, CRM tự cầm sổ của mình. Kho rỗng là kho rỗng — công cụ
 *  nói thẳng "chưa có bản ghi nào", và đó là một câu trả lời thật. Một con số
 *  bịa ra thì không.
 *
 *  TÁM BỘ SƯU TẬP, và mỗi bộ trả lời một câu hỏi riêng:
 *
 *      gia-dinh    gia đình nào đang ở đâu trên đường đồng hành
 *      hoc-phi     kỳ học phí nào đã thu, còn thiếu, tới hạn khi nào
 *      yeu-cau     gia đình đang cần hệ thống làm gì
 *      chien-dich  nguồn nào đưa gia đình tới, và đo được bao nhiêu
 *      tuong-tac   đã nói gì với ai, lúc nào
 *      duyet       việc nào đang chờ người thật gật đầu
 *      tin-hieu    mỗi lượt chạy để lại gì cho lần sau
 *      diem        điểm mức quan tâm, mức gắn bó, mức nguy cơ
 *
 *  NỐI VỚI DỮ LIỆU ĐÃ CÓ, KHÔNG CHÉP LẠI. Hồ sơ học tập của em nhỏ nằm ở kho
 *  learners, tài khoản nằm ở kho users. CRM giữ KHOÁ trỏ sang, không sao chép
 *  — chép là có hai bản sự thật, và hai bản sự thật thì luôn có một bản sai.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { id: newId } = require('../utils');

/** Chặng trên đường đồng hành. Thứ tự là thứ tự thật, dùng để đo tồn chặng. */
const CHANG = [
  { ma: 'biet-toi', ten: 'Biết tới hệ thống', thu: 1 },
  { ma: 'quan-tam', ten: 'Đã để lại liên lạc', thu: 2 },
  { ma: 'da-khao-sat', ten: 'Đã làm bài khảo sát', thu: 3 },
  { ma: 'da-tu-van', ten: 'Đã nghe tư vấn lộ trình', thu: 4 },
  { ma: 'dang-hoc', ten: 'Đang học', thu: 5 },
  { ma: 'da-dung', ten: 'Đã dừng học', thu: 6 },
];
const CHANG_INDEX = new Map(CHANG.map((c) => [c.ma, c]));

/** Trạng thái một kỳ học phí. */
const TRANG_THAI_HOC_PHI = ['chua-toi-han', 'toi-han', 'qua-han', 'da-thu', 'da-mien'];

/** Trạng thái một yêu cầu hỗ trợ. */
const TRANG_THAI_YEU_CAU = ['moi', 'dang-xu-ly', 'cho-gia-dinh', 'xong', 'dong'];

/** Loại điểm. Mỗi loại một thang, không dùng chung một con số cho mọi việc. */
const LOAI_DIEM = {
  'muc-quan-tam': { ten: 'Mức quan tâm', min: 0, max: 100 },
  'muc-gan-bo': { ten: 'Mức gắn bó', min: 0, max: 100 },
  'nguy-co-dung': { ten: 'Nguy cơ dừng học', min: 0, max: 100 },
};

class KhoCRM {
  /**
   * @param {object} o
   * @param {object} o.db        Database của hệ thống (src/data/repository.js)
   * @param {object} o.nhatKy    AuditChain — mọi lần ghi đều để lại vết
   * @param {function} o.bayGio  đồng hồ, tách ra để mục kiểm điều khiển được
   */
  constructor({ db, nhatKy = null, bayGio = () => Date.now() } = {}) {
    if (!db) throw new Error('KhoCRM cần một Database');
    this.nhatKy = nhatKy;
    this.bayGio = bayGio;

    this.giaDinh = db.collection('crm-gia-dinh', { indexes: ['chang', 'nguoiDungId', 'hocVienId'] });
    this.hocPhi = db.collection('crm-hoc-phi', { indexes: ['giaDinhId', 'trangThai', 'ky'] });
    this.yeuCau = db.collection('crm-yeu-cau', { indexes: ['giaDinhId', 'trangThai', 'nhom'] });
    this.chienDich = db.collection('crm-chien-dich', { indexes: ['kenh', 'trangThai'] });
    this.tuongTac = db.collection('crm-tuong-tac', { indexes: ['giaDinhId', 'phienId', 'troLyMa'] });
    this.duyet = db.collection('crm-duyet', { indexes: ['trangThai', 'phienId', 'troLyMa'] });
    this.tinHieu = db.collection('crm-tin-hieu', { indexes: ['phienId', 'troLyMa'] });
    this.diem = db.collection('crm-diem', { indexes: ['giaDinhId', 'loai'] });
  }

  _vet(hanhDong, dich, chiTiet) {
    if (!this.nhatKy) return;
    // Không chờ: nhật ký hỏng không được phép làm hỏng việc nghiệp vụ, nhưng
    // cũng không được nuốt lặng — nó tự ghi lỗi của chính nó ở tầng dưới.
    Promise.resolve(this.nhatKy.record({
      actor: 'crm', action: hanhDong, target: dich, verdict: 'ALLOW', detail: chiTiet,
    })).catch(() => {});
  }

  // ── GIA ĐÌNH ────────────────────────────────────────────────────────────

  /**
   * Mở hồ sơ một gia đình. Không nhận tên học viên hay số điện thoại làm khoá
   * — khoá là mã tài khoản đã có trong hệ thống, vì tên thì trùng còn số thì đổi.
   */
  moGiaDinh({ nguoiDungId = null, hocVienId = null, tenGoi = null, chang = 'quan-tam', nguon = null } = {}) {
    if (!nguoiDungId && !hocVienId) {
      return { ok: false, loi: 'THIEU_KHOA', lyDo: 'Hồ sơ gia đình phải nối được về một tài khoản hoặc một học viên đã có.' };
    }
    if (!CHANG_INDEX.has(chang)) {
      return { ok: false, loi: 'CHANG_LA', lyDo: `Chặng "${chang}" không có trong đường đồng hành.` };
    }
    const daCo = this.timGiaDinh({ nguoiDungId, hocVienId });
    if (daCo) return { ok: true, giaDinh: daCo, daCo: true };

    const luc = this.bayGio();
    const gd = {
      id: newId('GD'),
      nguoiDungId, hocVienId,
      tenGoi: tenGoi || null,
      chang,
      nguon: nguon || null,
      moLuc: luc, capNhatLuc: luc,
      lichSuChang: [{ chang, luc }],
    };
    this.giaDinh.put(gd);
    this._vet('crm.gia-dinh.mo', gd.id, { chang, nguon });
    return { ok: true, giaDinh: gd, daCo: false };
  }

  timGiaDinh({ nguoiDungId = null, hocVienId = null } = {}) {
    if (nguoiDungId) {
      const ds = this.giaDinh.by('nguoiDungId', nguoiDungId);
      if (ds.length) return ds[0];
    }
    if (hocVienId) {
      const ds = this.giaDinh.by('hocVienId', hocVienId);
      if (ds.length) return ds[0];
    }
    return null;
  }

  /**
   * Chuyển chặng. Đường đồng hành đi tới, không đi lui — trừ một lối duy nhất
   * là quay lại sau khi đã dừng, vì gia đình quay lại là chuyện có thật và
   * đáng mừng. Mọi bước lui khác là dấu hiệu dữ liệu sai, nên chặn tại đây.
   */
  chuyenChang(giaDinhId, changMoi, { boi = 'he-thong' } = {}) {
    const gd = this.giaDinh.get(giaDinhId);
    if (!gd) return { ok: false, loi: 'KHONG_CO_GIA_DINH' };
    const moi = CHANG_INDEX.get(changMoi);
    if (!moi) return { ok: false, loi: 'CHANG_LA' };
    const cu = CHANG_INDEX.get(gd.chang);
    const quayLai = cu && cu.ma === 'da-dung';
    if (cu && moi.thu < cu.thu && !quayLai) {
      return {
        ok: false, loi: 'LUI_CHANG',
        lyDo: `Không lùi từ "${cu.ten}" về "${moi.ten}". Nếu đúng là gia đình đã dừng rồi quay lại thì chuyển qua chặng "Đã dừng học" trước.`,
      };
    }
    const luc = this.bayGio();
    gd.chang = changMoi;
    gd.capNhatLuc = luc;
    gd.lichSuChang = [...(gd.lichSuChang || []), { chang: changMoi, luc, boi }];
    this.giaDinh.put(gd);
    this._vet('crm.gia-dinh.chuyen-chang', giaDinhId, { tu: cu && cu.ma, toi: changMoi, boi });
    return { ok: true, giaDinh: gd };
  }

  // ── HỌC PHÍ ─────────────────────────────────────────────────────────────

  /**
   * Ghi một kỳ học phí. Số tiền là số có thật trên một thoả thuận đã ký, nên
   * hàm này KHÔNG tự tính ra số — nó chỉ nhận và giữ. Tính giá là việc khác,
   * của một trợ lý khác, và kết quả tính ấy phải qua người duyệt trước khi
   * thành một dòng ở đây.
   */
  ghiKyHocPhi({ giaDinhId, ky, soTien, hanLuc, trangThai = 'chua-toi-han', ghiChu = null } = {}) {
    if (!this.giaDinh.get(giaDinhId)) return { ok: false, loi: 'KHONG_CO_GIA_DINH' };
    if (!ky || !/^\d{4}-\d{2}$/.test(String(ky))) {
      return { ok: false, loi: 'KY_SAI', lyDo: 'Kỳ ghi theo dạng năm-tháng, ví dụ 2026-09.' };
    }
    if (!Number.isFinite(soTien) || soTien < 0) {
      return { ok: false, loi: 'SO_TIEN_SAI', lyDo: 'Số tiền phải là một số không âm.' };
    }
    if (!TRANG_THAI_HOC_PHI.includes(trangThai)) return { ok: false, loi: 'TRANG_THAI_LA' };
    const d = {
      id: newId('HP'), giaDinhId, ky, soTien,
      hanLuc: hanLuc || null, trangThai, ghiChu: ghiChu || null,
      taoLuc: this.bayGio(), thuLuc: trangThai === 'da-thu' ? this.bayGio() : null,
    };
    this.hocPhi.put(d);
    this._vet('crm.hoc-phi.ghi', d.id, { giaDinhId, ky, trangThai });
    return { ok: true, kyHocPhi: d };
  }

  /** Cập nhật trạng thái một kỳ. Thu rồi thì không quay về chưa thu. */
  capNhatHocPhi(id, trangThai, { boi = 'he-thong' } = {}) {
    const d = this.hocPhi.get(id);
    if (!d) return { ok: false, loi: 'KHONG_CO_KY' };
    if (!TRANG_THAI_HOC_PHI.includes(trangThai)) return { ok: false, loi: 'TRANG_THAI_LA' };
    if (d.trangThai === 'da-thu' && trangThai !== 'da-thu') {
      return { ok: false, loi: 'DA_THU_KHONG_LUI', lyDo: 'Kỳ đã thu thì không quay về trạng thái chưa thu. Ghi một dòng hoàn trả nếu cần.' };
    }
    d.trangThai = trangThai;
    if (trangThai === 'da-thu' && !d.thuLuc) d.thuLuc = this.bayGio();
    this.hocPhi.put(d);
    this._vet('crm.hoc-phi.cap-nhat', id, { trangThai, boi });
    return { ok: true, kyHocPhi: d };
  }

  /** Công nợ của một gia đình, hoặc của toàn hệ nếu không nêu gia đình. */
  congNo({ giaDinhId = null, luc = null } = {}) {
    const bayGio = luc == null ? this.bayGio() : luc;
    const ds = giaDinhId ? this.hocPhi.by('giaDinhId', giaDinhId) : this.hocPhi.all();
    const chuaThu = ds.filter((d) => d.trangThai !== 'da-thu' && d.trangThai !== 'da-mien');
    const quaHan = chuaThu.filter((d) => d.hanLuc && d.hanLuc < bayGio);
    return {
      soKy: ds.length,
      chuaThu: chuaThu.length,
      tienChuaThu: chuaThu.reduce((t, d) => t + d.soTien, 0),
      quaHan: quaHan.length,
      tienQuaHan: quaHan.reduce((t, d) => t + d.soTien, 0),
      daThu: ds.filter((d) => d.trangThai === 'da-thu').length,
      tienDaThu: ds.filter((d) => d.trangThai === 'da-thu').reduce((t, d) => t + d.soTien, 0),
    };
  }

  // ── YÊU CẦU HỖ TRỢ ──────────────────────────────────────────────────────

  moYeuCau({ giaDinhId = null, nhom = 'chung', noiDung, khan = false } = {}) {
    if (!noiDung || String(noiDung).trim().length < 5) {
      return { ok: false, loi: 'NOI_DUNG_QUA_NGAN' };
    }
    const d = {
      id: newId('YC'), giaDinhId: giaDinhId || null, nhom, khan: !!khan,
      noiDung: String(noiDung).slice(0, 4000),
      trangThai: 'moi', moLuc: this.bayGio(),
      traLoiDauLuc: null, xongLuc: null, buocPhucHoi: [],
    };
    this.yeuCau.put(d);
    this._vet('crm.yeu-cau.mo', d.id, { nhom, khan: d.khan });
    return { ok: true, yeuCau: d };
  }

  /**
   * Ghi một bước phục hồi.
   *
   * MƯỜI BƯỚC, KHÔNG PHẢI BỐN. Bản đầu của tệp này viết "bốn bước" vì tôi nhớ
   * theo khuôn quen của ngành dịch vụ. Hệ thống có sẵn mười bước ở
   * src/trai-nghiem/phuc-hoi.js, và mười bước ấy được viết ra từ việc thật.
   * Đã sửa theo dữ liệu của hệ, không sửa dữ liệu cho vừa trí nhớ của tôi.
   *
   * Mười bước là một TRÌNH TỰ, không phải một thực đơn chọn món: bước "xin
   * lỗi" trước khi "nghe hết" thì lời xin lỗi ấy nói về một việc chưa ai nghe.
   * Vì vậy hàm này chặn nhảy cóc ngay tại chỗ ghi.
   */
  ghiBuocPhucHoi(yeuCauId, buocThu, { ghiChu = null } = {}) {
    const d = this.yeuCau.get(yeuCauId);
    if (!d) return { ok: false, loi: 'KHONG_CO_YEU_CAU' };
    const { BUOC } = require('../trai-nghiem/phuc-hoi');
    const thu = Number(buocThu);
    const buoc = BUOC.find((b) => b.thu === thu);
    if (!buoc) {
      return { ok: false, loi: 'BUOC_LA', lyDo: `Quy trình phục hồi có ${BUOC.length} bước, đánh số 1 tới ${BUOC.length}.` };
    }
    const daCo = d.buocPhucHoi || [];
    const thuCuoi = daCo.length ? daCo[daCo.length - 1].thu : 0;
    if (thu !== thuCuoi + 1) {
      const can = BUOC.find((b) => b.thu === thuCuoi + 1);
      return {
        ok: false, loi: 'NHAY_BUOC',
        lyDo: can
          ? `Phải làm bước ${can.thu} "${can.ten}" trước khi làm bước ${thu} "${buoc.ten}".`
          : `Cả ${BUOC.length} bước đã xong.`,
      };
    }
    d.buocPhucHoi = [...daCo, { thu, ten: buoc.ten, luc: this.bayGio(), ghiChu }];
    if (!d.traLoiDauLuc) d.traLoiDauLuc = this.bayGio();
    if (thu === BUOC.length) { d.trangThai = 'xong'; d.xongLuc = this.bayGio(); }
    else if (d.trangThai === 'moi') d.trangThai = 'dang-xu-ly';
    this.yeuCau.put(d);
    this._vet('crm.yeu-cau.buoc-phuc-hoi', yeuCauId, { thu, ten: buoc.ten });
    return { ok: true, yeuCau: d, duBuoc: thu === BUOC.length, conLai: BUOC.length - thu };
  }

  // ── CHIẾN DỊCH ──────────────────────────────────────────────────────────

  /**
   * Mở một chiến dịch tuyển sinh. Chi phí phải khai NGUỒN, đúng như sổ cái
   * dòng tiền đòi: không có nguồn thì không tính được hiệu quả, và một tỷ số
   * tính từ chi phí đoán mò còn hại hơn là không có tỷ số nào.
   */
  moChienDich({ ten, kenh, batDau = null, chiPhiUsd = null, nguonChiPhi = null } = {}) {
    if (!ten || !kenh) return { ok: false, loi: 'THIEU_TEN_HOAC_KENH' };
    if (chiPhiUsd != null && !nguonChiPhi) {
      return { ok: false, loi: 'CHI_PHI_CHUA_NOI_NGUON', lyDo: 'Khai chi phí thì phải khai luôn lấy con số ấy ở đâu ra.' };
    }
    const d = {
      id: newId('CD'), ten, kenh,
      batDau: batDau || this.bayGio(), ketThuc: null,
      chiPhiUsd: chiPhiUsd == null ? null : chiPhiUsd,
      nguonChiPhi: nguonChiPhi || null,
      trangThai: 'dang-chay',
      taoLuc: this.bayGio(),
    };
    this.chienDich.put(d);
    this._vet('crm.chien-dich.mo', d.id, { kenh, coChiPhi: chiPhiUsd != null });
    return { ok: true, chienDich: d };
  }

  /** Hiệu quả một chiến dịch — hoặc lý do KHÔNG tính được. */
  hieuQuaChienDich(id) {
    const cd = this.chienDich.get(id);
    if (!cd) return { ok: false, loi: 'KHONG_CO_CHIEN_DICH' };
    const tu = this.giaDinh.filter((g) => g.nguon === id);
    const dangHoc = tu.filter((g) => g.chang === 'dang-hoc').length;
    if (cd.chiPhiUsd == null) {
      return {
        ok: true, tinhDuoc: false,
        lyDo: 'Chiến dịch chưa khai chi phí nên không có mẫu số. Đếm được số gia đình, không tính được hiệu quả.',
        giaDinhDuaVe: tu.length, dangHoc,
      };
    }
    if (tu.length === 0) {
      return {
        ok: true, tinhDuoc: false,
        lyDo: 'Chưa có gia đình nào ghi nhận đến từ chiến dịch này nên chưa có tử số.',
        giaDinhDuaVe: 0, dangHoc: 0, chiPhiUsd: cd.chiPhiUsd,
      };
    }
    return {
      ok: true, tinhDuoc: true,
      giaDinhDuaVe: tu.length, dangHoc,
      chiPhiUsd: cd.chiPhiUsd,
      chiPhiMoiGiaDinh: cd.chiPhiUsd / tu.length,
      chiPhiMoiNguoiHoc: dangHoc ? cd.chiPhiUsd / dangHoc : null,
      congThuc: 'chi phí chiến dịch ÷ số gia đình ghi nhận đến từ chiến dịch ấy',
      nguonChiPhi: cd.nguonChiPhi,
    };
  }

  // ── ĐIỂM ────────────────────────────────────────────────────────────────

  /**
   * Chấm điểm một gia đình. Điểm phải kèm DẤU HIỆU đã dùng — không có dấu hiệu
   * thì không nhận. Một con số không giải thích được là một con số không cãi
   * lại được, và thứ không cãi lại được thì không sửa được khi nó sai.
   */
  chamDiem({ giaDinhId, loai, giaTri, dauHieu = [], boi = 'he-thong' } = {}) {
    if (!this.giaDinh.get(giaDinhId)) return { ok: false, loi: 'KHONG_CO_GIA_DINH' };
    const thang = LOAI_DIEM[loai];
    if (!thang) return { ok: false, loi: 'LOAI_DIEM_LA', lyDo: `Loại điểm "${loai}" không có trong bảng.` };
    if (!Number.isFinite(giaTri) || giaTri < thang.min || giaTri > thang.max) {
      return { ok: false, loi: 'NGOAI_THANG', lyDo: `${thang.ten} nằm trong khoảng ${thang.min}–${thang.max}.` };
    }
    if (!Array.isArray(dauHieu) || dauHieu.length === 0) {
      return { ok: false, loi: 'THIEU_DAU_HIEU', lyDo: 'Điểm phải chỉ ra được dựa trên dấu hiệu quan sát được nào.' };
    }
    const cu = this.diem.find((d) => d.giaDinhId === giaDinhId && d.loai === loai);
    const d = {
      id: cu ? cu.id : newId('DM'),
      giaDinhId, loai, giaTri,
      dauHieu: dauHieu.map(String).slice(0, 20),
      boi, luc: this.bayGio(),
      truocDo: cu ? cu.giaTri : null,
    };
    this.diem.put(d);
    this._vet('crm.diem.cham', giaDinhId, { loai, giaTri, soDauHieu: d.dauHieu.length });
    return { ok: true, diem: d };
  }

  diemCua(giaDinhId) {
    const ds = this.diem.by('giaDinhId', giaDinhId);
    return Object.fromEntries(ds.map((d) => [d.loai, { giaTri: d.giaTri, dauHieu: d.dauHieu, luc: d.luc }]));
  }

  // ── TỔNG QUAN ───────────────────────────────────────────────────────────

  tongQuan() {
    const gd = this.giaDinh.all();
    const theoChang = Object.fromEntries(CHANG.map((c) => [c.ma, gd.filter((g) => g.chang === c.ma).length]));
    const yc = this.yeuCau.all();
    return {
      giaDinh: gd.length,
      theoChang,
      hocPhi: this.congNo({}),
      yeuCau: {
        tong: yc.length,
        dangMo: yc.filter((y) => y.trangThai !== 'xong' && y.trangThai !== 'dong').length,
        khan: yc.filter((y) => y.khan && y.trangThai !== 'xong' && y.trangThai !== 'dong').length,
      },
      chienDich: {
        tong: this.chienDich.count(),
        dangChay: this.chienDich.filter((c) => c.trangThai === 'dang-chay').length,
        khaiChiPhi: this.chienDich.filter((c) => c.chiPhiUsd != null).length,
      },
      tuongTac: this.tuongTac.count(),
      choDuyet: this.duyet.filter((d) => d.trangThai === 'cho').length,
    };
  }

  status() {
    return {
      boSuuTap: 8,
      soBanGhi: {
        giaDinh: this.giaDinh.count(), hocPhi: this.hocPhi.count(),
        yeuCau: this.yeuCau.count(), chienDich: this.chienDich.count(),
        tuongTac: this.tuongTac.count(), duyet: this.duyet.count(),
        tinHieu: this.tinHieu.count(), diem: this.diem.count(),
      },
    };
  }
}

module.exports = KhoCRM;
module.exports.CHANG = CHANG;
module.exports.CHANG_INDEX = CHANG_INDEX;
module.exports.TRANG_THAI_HOC_PHI = TRANG_THAI_HOC_PHI;
module.exports.TRANG_THAI_YEU_CAU = TRANG_THAI_YEU_CAU;
module.exports.LOAI_DIEM = LOAI_DIEM;
