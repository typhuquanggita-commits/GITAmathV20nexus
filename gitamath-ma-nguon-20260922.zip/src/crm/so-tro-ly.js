'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SỔ TRỢ LÝ CRM — 30 trợ lý AI chuyên môn quản trị quan hệ gia đình học viên
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  VỊ TRÍ CỦA BAN NÀY TRONG HỆ THỐNG. Nexus đã có 500 trợ lý AI chia theo sáu
 *  ban chuyên môn (Toán, Tiếng Việt, Kèm cặp, Nghiên cứu, Mã, Nghiệp vụ) và
 *  sáu cấp bậc. Ba mươi trợ lý trong tệp này KHÔNG phải là 30 trợ lý nữa cộng
 *  vào 500 — đó sẽ là trùng lặp. Đây là TẦNG QUYẾT ĐỊNH của mảng quan hệ gia
 *  đình: họ đọc dữ liệu thật, cân nhắc, và GIAO VIỆC XUỐNG lực lượng 500 khi
 *  việc cần sức làm. Xem src/crm/hop-tac.js — cây cầu ấy có thật, không phải
 *  một dòng mô tả.
 *
 *  VÌ SAO CÓ ĐÚNG BỐN CẤP. Bốn cấp không phải để cho đẹp sơ đồ, mà vì MỨC TỰ
 *  CHỦ khác nhau:
 *
 *      cấp 1 · điều hành      nhìn toàn cảnh, hầu hết CHỈ ĐỌC — người nhìn
 *                             rộng nhất lại là người được phép động ít nhất,
 *                             vì một lệnh sai ở đây lan ra toàn hệ.
 *      cấp 2 · trưởng ban     soạn thảo, đề xuất, chưa tự ghi.
 *      cấp 3 · chuyên viên    làm việc chuyên sâu, một số được ghi sau duyệt.
 *      cấp 4 · vi chuyên viên việc hẹp và lặp lại, nên được tự chủ cao nhất
 *                             ở đúng cái việc hẹp ấy.
 *
 *  KPI KHÔNG PHẢI TRANG TRÍ. Mỗi trợ lý mang một bộ chỉ số, và mỗi chỉ số phải
 *  khai NGUỒN ĐO. Chỉ số nào hệ thống chưa đo được thì ghi thẳng doDuoc: false
 *  chứ không bịa một con số cho đủ bảng — đúng cách sổ cái dòng tiền đã làm.
 *  src/crm/kpi.js chấm điểm CHỈ trên những chỉ số đo được, và nói rõ còn bao
 *  nhiêu chỉ số chưa nối nguồn.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/**
 * BỐN MỨC ĐỘNG CHẠM. Thang này đo MỘT thứ: việc làm xong rồi thì lùi lại được
 * tới đâu. Không đo độ khó, không đo cấp bậc người làm.
 *
 *     1 · chỉ đọc          không đổi gì, lùi lại là không cần lùi
 *     2 · soạn nháp        có sản phẩm, nhưng chưa rời khỏi hệ thống
 *     3 · ghi vào sổ nhà   đổi dữ liệu của chính mình — sửa lại được, và
 *                          mỗi lần ghi đều để lại vết trong nhật ký
 *     4 · chạm ra ngoài    tới một con người thật: thư đã gửi, tin đã nhắn.
 *                          KHÔNG LÙI LẠI ĐƯỢC.
 *
 * MỨC 4 KHÔNG CẤP CHO AI. Đây là luật cứng nhất của cả ban: không một trợ lý
 * nào, dù cấp nào, được tự mình chạm tới một gia đình. Mọi việc mức 4 đều
 * dừng ở hàng chờ duyệt cho tới khi một người thật gật đầu. Vì vậy bảng dưới
 * đây không có trần nào bằng 4, và hàm soiSo() chặn luôn ở tầng dữ liệu.
 *
 * TRẦN ĐI NGƯỢC VỚI CẤP, và đó là chủ ý. Cấp càng cao thì nhìn càng rộng, nên
 * một lệnh sai ở đó lan càng xa — vì vậy người ngồi cao nhất lại bị buộc chặt
 * nhất. Cấp 3 và cấp 4 làm việc hẹp, hỏng thì hỏng một chỗ và lùi lại được.
 *
 * Bản đầu của tệp này xếp thang ngược: ghi nhật ký tương tác bị đặt mức cao
 * hơn gửi thư cho phụ huynh, vì tôi xếp theo "quyền" chứ không theo "lùi lại
 * được tới đâu". Xếp theo quyền thì việc vô hại lại cần giấy phép to hơn việc
 * không thu về được. Đã xếp lại theo đúng thứ hỏng thì mất gì.
 */
const MUC_DONG_CHAM = {
  1: { ten: 'Chỉ đọc', luiLaiDuoc: true },
  2: { ten: 'Soạn nháp', luiLaiDuoc: true },
  3: { ten: 'Ghi vào sổ nhà', luiLaiDuoc: true },
  4: { ten: 'Chạm ra ngoài', luiLaiDuoc: false },
};

/** Mức không bao giờ cấp thẳng cho trợ lý — phải qua người thật. */
const MUC_PHAI_CO_NGUOI = 4;

/** Bốn cấp, kèm mức tự chủ TRẦN của cấp ấy. */
const CAP = {
  1: { ten: 'Điều hành', tranTuChu: 2, moTa: 'Nhìn toàn cảnh, quyết định hướng đi' },
  2: { ten: 'Trưởng ban', tranTuChu: 3, moTa: 'Điều phối một mảng, soạn thảo và đề xuất' },
  3: { ten: 'Chuyên viên', tranTuChu: 3, moTa: 'Làm việc chuyên sâu trong một mảng hẹp' },
  4: { ten: 'Vi chuyên viên', tranTuChu: 3, moTa: 'Một việc hẹp, lặp lại, đo được' },
};

/** Miền nghiệp vụ. Dùng để gom nhóm và để chọn người khi định tuyến. */
const MIEN = {
  'dieu-hanh': 'Điều hành chung',
  'tuyen-sinh': 'Tuyển sinh và ghi danh',
  'cham-soc': 'Chăm sóc gia đình đang học',
  'hoc-phi': 'Học phí và công nợ',
  'du-lieu': 'Dữ liệu và vận hành',
  'rui-ro': 'Rủi ro và tuân thủ',
};

/**
 * Một chỉ số KPI.
 * @typedef {object} ChiSo
 * @property {string} ma       mã ngắn, duy nhất trong phạm vi trợ lý
 * @property {string} ten      tên đọc được
 * @property {string} donVi    đơn vị đo
 * @property {number} nguong   ngưỡng đạt
 * @property {'cao-tot'|'thap-tot'} chieu  cao hơn là tốt, hay thấp hơn là tốt
 * @property {string|null} nguon  lấy số ở đâu; null nghĩa là CHƯA NỐI NGUỒN
 * @property {boolean} doDuoc  hệ thống đo được chỉ số này hay chưa
 */

const cs = (ma, ten, donVi, nguong, chieu, nguon) => ({
  ma, ten, donVi, nguong, chieu, nguon, doDuoc: nguon !== null,
});

const DS = [
  // ════════════════ CẤP 1 — ĐIỀU HÀNH (5) ════════════════
  {
    ma: 'dieu-hanh-tong',
    ten: 'Trợ lý điều hành tổng',
    cap: 1, mien: 'dieu-hanh',
    moTa: 'Ghép các mảng rời thành một bức tranh, chỉ ra ba việc đáng làm nhất tuần này.',
    nangLuc: ['tong-hop-toan-canh', 'xep-uu-tien', 'canh-bao-som'],
    congCu: ['doc_toan_canh', 'doc_gia_dinh', 'doc_hoc_phi', 'doc_the_diem'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Thẻ điểm cân bằng bốn viễn cảnh', 'Nhịp rà soát quý của hệ thống'],
    kpi: [
      cs('DUNG_HEN', 'Bản tin điều hành ra đúng nhịp', '% số nhịp', 95, 'cao-tot', 'lich-viec.js đếm số lần chạy đúng giờ'),
      cs('CO_CAN_CU', 'Kết luận nào cũng dẫn được về số gốc', '% kết luận', 100, 'cao-tot', 'đếm lượt gọi công cụ trên mỗi phiên'),
      cs('SOM_HON', 'Cảnh báo phát trước khi việc hỏng', 'ngày', 7, 'cao-tot', null),
    ],
  },
  {
    ma: 'dieu-hanh-tuyen-sinh',
    ten: 'Trợ lý điều hành tuyển sinh',
    cap: 1, mien: 'tuyen-sinh',
    moTa: 'Trông coi cả đường đi từ lúc một gia đình biết tới hệ thống cho tới buổi học đầu tiên.',
    nangLuc: ['nhin-toan-duong-ghi-danh', 'can-doi-nguon-luc-tu-van'],
    congCu: ['doc_gia_dinh', 'doc_toan_canh', 'doc_chien_dich'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Phễu ghi danh năm chặng', 'Bản đồ chiến lược mục tiêu tăng trưởng'],
    kpi: [
      cs('CHUYEN_CHANG', 'Tỷ lệ đi hết chặng từ quan tâm tới học thật', '%', 25, 'cao-tot', null),
      cs('TON_CHANG', 'Số gia đình đứng yên quá 14 ngày ở một chặng', 'gia đình', 10, 'thap-tot', null),
    ],
  },
  {
    ma: 'dieu-hanh-tai-chinh',
    ten: 'Trợ lý điều hành tài chính',
    cap: 1, mien: 'hoc-phi',
    moTa: 'Giữ cho dòng tiền học phí đủ trước khi nghĩ tới việc mở rộng.',
    nangLuc: ['giu-thanh-khoan', 'soi-ngan-sach'],
    congCu: ['doc_hoc_phi', 'doc_so_cai', 'doc_an_toan_tai_chinh'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Cửa an toàn tài chính của hệ thống', 'Sổ cái dòng tiền có khai độ tin cậy'],
    kpi: [
      cs('CHI_TRONG_NGAN', 'Chi phí vận hành nằm trong ngân sách', '% số ngày', 100, 'cao-tot', 'so-cai.js so chi tiêu với ngân sách ngày và tháng'),
      cs('KHOAN_NOI_NGUON', 'Khoản chi đã nối được nguồn đo', '% số khoản', 100, 'cao-tot', 'so-cai.js đếm khoản có nguồn khác null'),
      cs('DEM_TIEN_MAT', 'Số tháng sống được bằng tiền đang có', 'tháng', 6, 'cao-tot', null),
    ],
  },
  {
    ma: 'dieu-hanh-van-hanh',
    ten: 'Trợ lý điều hành vận hành',
    cap: 1, mien: 'du-lieu',
    moTa: 'Soi chỗ tắc trong quy trình phục vụ, từ lúc nhận yêu cầu tới lúc gia đình hài lòng.',
    nangLuc: ['soi-quy-trinh', 'do-thoi-gian-cho'],
    congCu: ['doc_toan_canh', 'doc_yeu_cau', 'doc_diem_cham'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Mười bước phục hồi khi phục vụ hỏng', 'Lưới điểm chạm mười nghìn ô'],
    kpi: [
      cs('CHO_LAU_NHAT', 'Chặng khiến gia đình chờ lâu nhất', 'giờ', 24, 'thap-tot', null),
      cs('PHUC_HOI_DU_BUOC', 'Việc hỏng được chạy đủ mười bước phục hồi', '%', 100, 'cao-tot', 'kho yêu cầu đếm số bước đã ghi trên mỗi việc'),
    ],
  },
  {
    ma: 'dieu-hanh-rui-ro',
    ten: 'Trợ lý điều hành rủi ro',
    cap: 1, mien: 'rui-ro',
    moTa: 'Đứng về phía cái có thể hỏng: dữ liệu trẻ em, cam kết đã hứa, nghĩa vụ pháp lý.',
    nangLuc: ['soi-rui-ro', 'soi-tuan-thu', 'chan-viec-vuot-rao'],
    congCu: ['doc_rui_ro', 'doc_an_toan_phap_ly', 'doc_gia_dinh'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Sổ rủi ro mười hai mục có cách chặn', 'Luật riêng tư dữ liệu trẻ em của hệ thống'],
    kpi: [
      cs('RUI_RO_CO_CACH_CHAN', 'Rủi ro đã có cách chặn viết rõ', '% số mục', 100, 'cao-tot', 'rui-ro.js đếm mục có trường cachChan'),
      cs('KHONG_RO_RI', 'Số lần dữ liệu nội bộ lọt ra mặt công khai', 'lần', 0, 'thap-tot', 'buc-tuong.js soi toàn bộ trang công khai mỗi lượt thanh tra'),
    ],
  },

  // ════════════════ CẤP 2 — TRƯỞNG BAN (8) ════════════════
  {
    ma: 'ban-tuyen-sinh',
    ten: 'Trưởng ban tuyển sinh',
    cap: 2, mien: 'tuyen-sinh',
    moTa: 'Chia việc cho đội tư vấn, không để gia đình nào rơi qua kẽ tay.',
    nangLuc: ['chia-viec-tu-van', 'theo-dau-gia-dinh-moi'],
    congCu: ['doc_gia_dinh', 'soan_thu', 'cap_nhat_diem'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Phễu ghi danh năm chặng'],
    kpi: [
      cs('KHONG_BO_SOT', 'Gia đình mới được chạm trong 24 giờ', '%', 95, 'cao-tot', null),
      cs('THU_SOAN_DUOC_DUNG', 'Thư đã soạn được người thật gửi đi', '%', 70, 'cao-tot', null),
    ],
  },
  {
    ma: 'ban-tu-van',
    ten: 'Trưởng ban tư vấn lộ trình',
    cap: 2, mien: 'tuyen-sinh',
    moTa: 'Bảo đảm lộ trình đề xuất cho mỗi em dựa trên kết quả khảo sát thật, không dựa vào cảm tính người bán.',
    nangLuc: ['doi-chieu-khao-sat', 'de-xuat-lo-trinh'],
    congCu: ['doc_gia_dinh', 'doc_khao_sat', 'doc_lo_trinh'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Luật đo của bộ khảo sát', 'Năm tầng giá trị mười cấp'],
    kpi: [
      cs('DUA_TREN_KHAO_SAT', 'Đề xuất có kèm kết quả khảo sát', '%', 100, 'cao-tot', 'kho khảo sát trả về bản ghi của chính học viên ấy'),
      cs('KHONG_HUA_QUA', 'Đề xuất không hứa mốc thời gian chưa đo được', 'lần vi phạm', 0, 'thap-tot', 'bộ soát ngôn ngữ chặn câu hứa không căn cứ'),
    ],
  },
  {
    ma: 'ban-cham-soc',
    ten: 'Trưởng ban chăm sóc gia đình',
    cap: 2, mien: 'cham-soc',
    moTa: 'Trông coi lưới điểm chạm: đúng người, đúng lúc, đúng việc đang xảy ra với em nhỏ.',
    nangLuc: ['dieu-phoi-diem-cham', 'xep-uu-tien-cham-soc'],
    congCu: ['doc_gia_dinh', 'doc_diem_cham', 'ghi_tuong_tac'],
    tuChuToiDa: 3,
    khungNghiepVu: ['Lưới điểm chạm mười nghìn ô', 'Bốn mươi tình huống có kịch bản'],
    kpi: [
      cs('CHAM_DUNG_LUC', 'Điểm chạm phát đúng thời điểm đã định', '%', 90, 'cao-tot', null),
      cs('KHONG_CHAM_TRUNG', 'Một gia đình không nhận hai điểm chạm trùng nội dung trong 7 ngày', 'lần trùng', 0, 'thap-tot', null),
    ],
  },
  {
    ma: 'ban-ho-tro',
    ten: 'Trưởng ban hỗ trợ và khiếu nại',
    cap: 2, mien: 'cham-soc',
    moTa: 'Nhận việc hỏng, chạy đủ bốn bước phục hồi, và không để việc nào chìm.',
    nangLuc: ['phan-viec-ho-tro', 'theo-dau-phuc-hoi'],
    congCu: ['doc_yeu_cau', 'doc_tinh_huong', 'soan_thu'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Mười bước phục hồi khi phục vụ hỏng', 'Mười quyền trao cho người trực tiếp phục vụ'],
    kpi: [
      cs('DU_MUOI_BUOC', 'Việc hỏng chạy đủ mười bước phục hồi', '%', 100, 'cao-tot', 'kho yêu cầu đếm số bước đã ghi trên mỗi việc'),
      cs('TRA_LOI_DAU', 'Thời gian tới lần trả lời đầu tiên', 'giờ', 4, 'thap-tot', null),
    ],
  },
  {
    ma: 'ban-hoc-phi',
    ten: 'Trưởng ban học phí và công nợ',
    cap: 2, mien: 'hoc-phi',
    moTa: 'Nhắc học phí theo cách giữ được quan hệ, và dừng lại đúng lúc khi gia đình đang khó.',
    nangLuc: ['xep-lich-nhac', 'nhan-dien-gia-dinh-dang-kho'],
    congCu: ['doc_hoc_phi', 'doc_gia_dinh', 'soan_thu', 'gui_thu'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Sổ cái dòng tiền có khai độ tin cậy'],
    kpi: [
      cs('NHAC_DUNG_NGUOI', 'Thư nhắc gửi đúng gia đình còn nợ', '%', 100, 'cao-tot', null),
      cs('KHONG_NHAC_QUA', 'Không nhắc quá 2 lần một kỳ với cùng một gia đình', 'lần vi phạm', 0, 'thap-tot', null),
    ],
  },
  {
    ma: 'ban-ke-hoach-tai-chinh',
    ten: 'Trưởng ban kế hoạch tài chính',
    cap: 2, mien: 'hoc-phi',
    moTa: 'Dựng kịch bản thu chi và nói rõ kịch bản nào dựa trên số đo được, kịch bản nào chỉ là giả định.',
    nangLuc: ['dung-kich-ban', 'soi-chenh-ngan-sach'],
    congCu: ['doc_so_cai', 'doc_hoc_phi', 'doc_an_toan_tai_chinh'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Thẻ điểm cân bằng bốn viễn cảnh', 'Cửa an toàn tài chính của hệ thống'],
    kpi: [
      cs('KHAI_GIA_DINH', 'Mỗi kịch bản khai rõ giả định đã dùng', '%', 100, 'cao-tot', 'bộ soi kịch bản đòi trường giaDinh không rỗng'),
      cs('SAI_SO_DU_BAO', 'Sai số dự báo chi phí tháng', '%', 15, 'thap-tot', null),
    ],
  },
  {
    ma: 'ban-truyen-thong',
    ten: 'Trưởng ban truyền thông tuyển sinh',
    cap: 2, mien: 'tuyen-sinh',
    moTa: 'Giữ cho mọi lời hệ thống nói ra ngoài đúng với việc hệ thống làm được bên trong.',
    nangLuc: ['dieu-phoi-chien-dich', 'giu-loi-noi-dung-su-that'],
    congCu: ['doc_chien_dich', 'soan_noi_dung', 'doc_toan_canh'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Bức tường ngăn phân loại nội bộ lọt ra ngoài'],
    kpi: [
      cs('QUA_BUC_TUONG', 'Nội dung phát ra đều qua được bức tường', '%', 100, 'cao-tot', 'buc-tuong.js soi từng chuỗi trước khi cho đăng'),
      cs('DUNG_TIENG_VIET', 'Nội dung đạt chuẩn tiếng Việt bốn cấp của hệ thống', '%', 100, 'cao-tot', 'bộ soát ngôn ngữ chấm từng đoạn'),
    ],
  },
  {
    ma: 'ban-du-lieu',
    ten: 'Trưởng ban quản trị dữ liệu',
    cap: 2, mien: 'du-lieu',
    moTa: 'Giữ hồ sơ gia đình sạch, không trùng, không rỗng chỗ cần thiết.',
    nangLuc: ['soi-chat-luong-du-lieu', 'gop-ho-so-trung'],
    congCu: ['doc_gia_dinh', 'ghi_ho_so'],
    tuChuToiDa: 3,
    khungNghiepVu: ['Luật riêng tư dữ liệu trẻ em của hệ thống'],
    kpi: [
      cs('HO_SO_DU_TRUONG', 'Hồ sơ gia đình đủ trường bắt buộc', '%', 98, 'cao-tot', 'đếm trực tiếp trên kho người dùng và kho học viên'),
      cs('KHONG_TRUNG', 'Số cặp hồ sơ trùng chưa gộp', 'cặp', 0, 'thap-tot', 'đối chiếu tên và số liên lạc đã chuẩn hoá'),
    ],
  },

  // ════════════════ CẤP 3 — CHUYÊN VIÊN (12) ════════════════
  {
    ma: 'cham-diem-quan-tam',
    ten: 'Chuyên viên chấm điểm mức quan tâm',
    cap: 3, mien: 'tuyen-sinh',
    moTa: 'Chấm xem gia đình nào đang thật sự cần, để đội tư vấn gọi đúng người trước.',
    nangLuc: ['cham-diem', 'doc-dau-hieu-quan-tam'],
    congCu: ['doc_gia_dinh', 'cap_nhat_diem'],
    tuChuToiDa: 3,
    khungNghiepVu: ['Thang điểm dựa trên hành vi quan sát được, không dựa trên phỏng đoán'],
    kpi: [
      cs('CHAM_CO_CAN_CU', 'Điểm nào cũng chỉ ra được hành vi gốc', '%', 100, 'cao-tot', 'mỗi lần chấm ghi kèm danh sách dấu hiệu đã dùng'),
      cs('DO_PHU', 'Gia đình mới được chấm trong 1 giờ', '%', 95, 'cao-tot', null),
    ],
  },
  {
    ma: 'tu-van-lo-trinh',
    ten: 'Chuyên viên tư vấn lộ trình học',
    cap: 3, mien: 'tuyen-sinh',
    moTa: 'Dựng lộ trình cho một em cụ thể, dựa trên bài khảo sát và mức hiện tại của em.',
    nangLuc: ['dung-lo-trinh', 'giai-thich-cho-phu-huynh'],
    congCu: ['doc_khao_sat', 'doc_lo_trinh', 'doc_gia_dinh'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Năm tầng giá trị mười cấp', 'Chu kỳ chín mươi ngày'],
    kpi: [
      cs('KHOP_MUC_HIEN_TAI', 'Lộ trình bắt đầu đúng mức em đang có', '%', 100, 'cao-tot', 'đối chiếu với trường mức hiện tại trong hồ sơ học viên'),
      cs('PHU_HUYNH_HIEU', 'Phụ huynh đọc xong nói lại đúng ba việc kế tiếp', '%', 80, 'cao-tot', null),
    ],
  },
  {
    ma: 'dinh-gia-goi-hoc',
    ten: 'Chuyên viên định giá gói học',
    cap: 3, mien: 'hoc-phi',
    moTa: 'Đề xuất mức học phí nằm giữa hai ranh: gia đình trả được, và hệ thống không lỗ.',
    nangLuc: ['tinh-gia-san', 'de-xuat-muc-hoc-phi'],
    congCu: ['doc_so_cai', 'doc_gia_dinh'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Giá sàn tính từ chi phí đo được, không tính từ cảm giác'],
    kpi: [
      cs('TREN_GIA_SAN', 'Mức đề xuất không thấp hơn giá sàn đã tính', '%', 100, 'cao-tot', 'so với chi phí trên mỗi học viên lấy từ sổ cái'),
      cs('KHAI_KHOAN_CHUA_DO', 'Khai rõ khoản chi phí nào chưa nối nguồn', '%', 100, 'cao-tot', 'so-cai.js trả về danh sách khoản chưa có nguồn'),
    ],
  },
  {
    ma: 'soan-noi-dung',
    ten: 'Chuyên viên soạn nội dung chăm sóc',
    cap: 3, mien: 'cham-soc',
    moTa: 'Viết thư và tin nhắn gửi gia đình — viết được, nhưng không tự gửi.',
    nangLuc: ['soan-thu', 'viet-theo-tinh-huong'],
    congCu: ['soan_thu', 'soan_noi_dung', 'doc_tinh_huong'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Bốn mươi tình huống có kịch bản', 'Chuẩn tiếng Việt bốn cấp của hệ thống'],
    kpi: [
      cs('DAT_TIENG_VIET', 'Bản thảo đạt chuẩn tiếng Việt bốn cấp', '%', 100, 'cao-tot', 'bộ soát ngôn ngữ chấm từng bản thảo'),
      cs('KHONG_LO_NOI_BO', 'Bản thảo không chứa phân loại nội bộ', 'lần vi phạm', 0, 'thap-tot', 'buc-tuong.js soi từng bản thảo trước khi trả về'),
    ],
  },
  {
    ma: 'phan-tich-chien-dich',
    ten: 'Chuyên viên phân tích chiến dịch',
    cap: 3, mien: 'tuyen-sinh',
    moTa: 'Nói thẳng chiến dịch nào có hiệu quả đo được và chiến dịch nào chỉ có cảm giác hiệu quả.',
    nangLuc: ['do-hieu-qua', 'tach-nguyen-nhan'],
    congCu: ['doc_chien_dich', 'doc_toan_canh'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Nguyên tắc: chưa đo được thì ghi là chưa đo được'],
    kpi: [
      cs('KET_LUAN_CO_SO', 'Kết luận nào cũng kèm số gốc', '%', 100, 'cao-tot', 'mỗi kết luận ghi kèm nguồn dữ liệu đã đọc'),
      cs('DAY_DU_KENH', 'Tỷ lệ kênh tuyển sinh đã nối được nguồn đo', '%', 100, 'cao-tot', null),
    ],
  },
  {
    ma: 'ho-so-360',
    ten: 'Chuyên viên hồ sơ gia đình toàn cảnh',
    cap: 3, mien: 'cham-soc',
    moTa: 'Ghép mọi mảnh về một gia đình thành một trang, và chỉ ra việc nên làm kế tiếp.',
    nangLuc: ['ghep-ho-so', 'de-xuat-viec-ke-tiep'],
    congCu: ['doc_gia_dinh', 'doc_khao_sat', 'doc_hoc_phi', 'ghi_tuong_tac'],
    tuChuToiDa: 3,
    khungNghiepVu: ['Luật riêng tư dữ liệu trẻ em của hệ thống'],
    kpi: [
      cs('KHONG_LO_TAM_LY', 'Không đưa câu trả lời tâm lý thô vào hồ sơ', 'lần vi phạm', 0, 'thap-tot', 'kho khảo sát chặn đọc câu thô ở tầng dữ liệu'),
      cs('DU_BA_MANH', 'Hồ sơ ghép đủ học tập, chăm sóc và học phí', '%', 95, 'cao-tot', 'đếm số mảnh dữ liệu ghép được trên mỗi hồ sơ'),
    ],
  },
  {
    ma: 'phan-loai-yeu-cau',
    ten: 'Chuyên viên phân loại yêu cầu hỗ trợ',
    cap: 3, mien: 'cham-soc',
    moTa: 'Đọc yêu cầu của gia đình, xếp đúng nhóm, chuyển đúng người.',
    nangLuc: ['phan-loai', 'chuyen-viec'],
    congCu: ['doc_yeu_cau', 'doc_tinh_huong', 'ghi_ho_so'],
    tuChuToiDa: 3,
    khungNghiepVu: ['Bốn mươi tình huống có kịch bản'],
    kpi: [
      cs('XEP_DUNG_NHOM', 'Yêu cầu xếp đúng nhóm ngay lần đầu', '%', 90, 'cao-tot', null),
      cs('KHONG_XEP_NHAM_KHAN', 'Việc khẩn không bị xếp xuống nhóm thường', 'lần', 0, 'thap-tot', null),
    ],
  },
  {
    ma: 'du-bao-thoi-hoc',
    ten: 'Chuyên viên dự báo nguy cơ dừng học',
    cap: 3, mien: 'cham-soc',
    moTa: 'Chỉ ra em nào đang trượt dần khỏi lộ trình, trước khi gia đình nói lời chia tay.',
    nangLuc: ['doc-dau-hieu-truot', 'de-xuat-can-thiep'],
    congCu: ['doc_gia_dinh', 'doc_lo_trinh', 'doc_khao_sat'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Dấu hiệu quan sát được: vắng buổi, tụt mức, im lặng kéo dài'],
    kpi: [
      cs('BAO_TRUOC', 'Cảnh báo phát trước khi gia đình dừng', 'ngày', 21, 'cao-tot', null),
      cs('KHONG_BAO_OAN', 'Tỷ lệ cảnh báo sai làm phiền gia đình đang học tốt', '%', 20, 'thap-tot', null),
    ],
  },
  {
    ma: 'du-bao-dong-tien',
    ten: 'Chuyên viên dự báo dòng tiền học phí',
    cap: 3, mien: 'hoc-phi',
    moTa: 'Dự báo tiền vào ra 30, 60, 90 ngày, và nói rõ phần nào là số thật, phần nào là giả định.',
    nangLuc: ['du-bao-ba-moc', 'tach-that-va-gia-dinh'],
    congCu: ['doc_so_cai', 'doc_hoc_phi', 'doc_an_toan_tai_chinh'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Sổ cái dòng tiền có khai độ tin cậy'],
    kpi: [
      cs('TACH_RO', 'Dự báo tách rõ số đo được và số giả định', '%', 100, 'cao-tot', 'so-cai.js phân loại từng khoản theo bốn mức tin cậy'),
      cs('KHONG_DUNG_SO_BIA', 'Không dùng khoản chưa nối nguồn như số thật', 'lần vi phạm', 0, 'thap-tot', 'so-cai.js từ chối ghi khoản chưa nối nguồn'),
    ],
  },
  {
    ma: 'quan-ly-cong-no',
    ten: 'Chuyên viên quản lý công nợ học phí',
    cap: 3, mien: 'hoc-phi',
    moTa: 'Theo từng khoản còn thiếu, soạn lời nhắc, và biết khi nào nên ngừng nhắc mà gọi điện.',
    nangLuc: ['theo-cong-no', 'soan-loi-nhac'],
    congCu: ['doc_hoc_phi', 'soan_thu', 'gui_thu'],
    tuChuToiDa: 2,
    khungNghiepVu: ['Nhắc nợ là việc giữ quan hệ, không phải việc đòi tiền'],
    kpi: [
      cs('DUNG_SO_TIEN', 'Số tiền trong thư nhắc khớp sổ', '%', 100, 'cao-tot', 'đối chiếu trực tiếp với kho học phí trước khi soạn'),
      cs('KY_HAN_TRUNG_BINH', 'Số ngày trung bình từ hạn tới lúc thu được', 'ngày', 15, 'thap-tot', null),
    ],
  },
  {
    ma: 'tham-dinh-kha-nang',
    ten: 'Chuyên viên thẩm định khả năng chi trả',
    cap: 3, mien: 'hoc-phi',
    moTa: 'Xem gia đình có kham được gói học không, để đề xuất gói vừa sức thay vì gói đắt rồi bỏ dở.',
    nangLuc: ['tham-dinh', 'de-xuat-goi-vua-suc'],
    congCu: ['doc_hoc_phi', 'doc_gia_dinh'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Lịch sử thanh toán quan sát được, không suy đoán thu nhập'],
    kpi: [
      cs('KHONG_SUY_DOAN', 'Không suy đoán thu nhập gia đình', 'lần vi phạm', 0, 'thap-tot', 'công cụ chỉ trả về lịch sử thanh toán, không có trường thu nhập'),
      cs('GOI_GIU_DUOC', 'Gói đã đề xuất còn được giữ sau 3 tháng', '%', 85, 'cao-tot', null),
    ],
  },
  {
    ma: 'lam-sach-du-lieu',
    ten: 'Chuyên viên làm sạch dữ liệu',
    cap: 3, mien: 'du-lieu',
    moTa: 'Dọn hồ sơ trùng, hồ sơ thiếu, hồ sơ sai định dạng — dọn sau khi được duyệt.',
    nangLuc: ['tim-trung', 'chuan-hoa-truong'],
    congCu: ['doc_gia_dinh', 'ghi_ho_so'],
    tuChuToiDa: 3,
    khungNghiepVu: ['Sửa dữ liệu là việc có thể làm hỏng, nên phải qua duyệt'],
    kpi: [
      cs('SUA_CO_VET', 'Mỗi lần sửa đều để lại vết trong nhật ký kiểm toán', '%', 100, 'cao-tot', 'nhật ký kiểm toán móc xích băm ghi từng lần ghi'),
      cs('KHONG_XOA_NHAM', 'Số bản ghi bị xoá nhầm', 'bản ghi', 0, 'thap-tot', 'công cụ ghi hồ sơ không có nhánh xoá'),
    ],
  },

  // ════════════════ CẤP 4 — VI CHUYÊN VIÊN (5) ════════════════
  {
    ma: 'doc-y-dinh',
    ten: 'Trợ lý đọc ý định tin nhắn',
    cap: 4, mien: 'du-lieu',
    moTa: 'Một việc duy nhất: tin nhắn này của gia đình đang muốn gì.',
    nangLuc: ['doc-y-dinh'],
    congCu: ['doc_tinh_huong'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Bốn mươi tình huống có kịch bản'],
    kpi: [
      cs('DOC_DUNG', 'Đọc đúng ý định ngay lần đầu', '%', 85, 'cao-tot', null),
      cs('NHAN_KHONG_RO', 'Nói thẳng khi không đọc được ý định', '%', 100, 'cao-tot', 'trả về nhãn không-rõ thay vì đoán bừa'),
    ],
  },
  {
    ma: 'tom-tat-buoi-lam-viec',
    ten: 'Trợ lý tóm tắt buổi làm việc',
    cap: 4, mien: 'du-lieu',
    moTa: 'Biến một buổi trao đổi thành mấy dòng và một danh sách việc phải làm.',
    nangLuc: ['tom-tat', 'rut-viec-phai-lam'],
    congCu: ['ghi_tuong_tac'],
    tuChuToiDa: 3,
    khungNghiepVu: ['Tóm tắt phải giữ nguyên con số và tên người'],
    kpi: [
      cs('GIU_SO', 'Con số trong bản tóm tắt khớp bản gốc', '%', 100, 'cao-tot', 'đối chiếu chuỗi số giữa bản gốc và bản tóm tắt'),
      cs('CO_VIEC_PHAI_LAM', 'Bản tóm tắt nào cũng có danh sách việc', '%', 100, 'cao-tot', 'đòi trường việc phải làm không rỗng'),
    ],
  },
  {
    ma: 'doc-cam-xuc',
    ten: 'Trợ lý đọc cảm xúc gia đình',
    cap: 4, mien: 'cham-soc',
    moTa: 'Đọc giọng của gia đình trong tin nhắn, để người trực tiếp phục vụ biết mình đang bước vào đâu.',
    nangLuc: ['doc-giong'],
    congCu: ['doc_tinh_huong'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Đọc giọng là để chuẩn bị, không phải để xếp loại con người'],
    kpi: [
      cs('KHONG_XEP_LOAI_NGUOI', 'Không gắn nhãn cố định cho một người', 'lần vi phạm', 0, 'thap-tot', 'kết quả chỉ gắn vào một tin nhắn, không ghi vào hồ sơ'),
      cs('BAT_DUOC_GIAN', 'Bắt được tin nhắn có giọng bức xúc', '%', 90, 'cao-tot', null),
    ],
  },
  {
    ma: 'phat-hien-bat-thuong',
    ten: 'Trợ lý phát hiện bất thường',
    cap: 4, mien: 'rui-ro',
    moTa: 'Soi các con số lệch khỏi thói quen của chính hệ thống và báo lên.',
    nangLuc: ['soi-lech'],
    congCu: ['doc_so_cai', 'doc_toan_canh'],
    tuChuToiDa: 1,
    khungNghiepVu: ['So với chính mình trong quá khứ, không so với số ngành'],
    kpi: [
      cs('BAO_CO_SO_SANH', 'Mỗi báo động kèm mốc so sánh', '%', 100, 'cao-tot', 'mỗi báo động ghi kèm giá trị nền đã dùng'),
      cs('IT_BAO_OAN', 'Số báo động sai trong một tuần', 'lần', 3, 'thap-tot', null),
    ],
  },
  {
    ma: 'tinh-hieu-qua',
    ten: 'Trợ lý tính hiệu quả hoạt động',
    cap: 4, mien: 'dieu-hanh',
    moTa: 'Tính xem một hoạt động đáng giá bao nhiêu, và từ chối tính khi chưa đủ số.',
    nangLuc: ['tinh-hieu-qua'],
    congCu: ['doc_so_cai', 'doc_toan_canh'],
    tuChuToiDa: 1,
    khungNghiepVu: ['Thiếu một vế thì không có tỷ số — nói thiếu, không ước lượng'],
    kpi: [
      cs('TU_CHOI_KHI_THIEU', 'Từ chối tính khi thiếu vế', '%', 100, 'cao-tot', 'trả về lý do thiếu thay vì một con số'),
      cs('CONG_KHAI_CONG_THUC', 'Mỗi kết quả kèm công thức đã dùng', '%', 100, 'cao-tot', 'kết quả mang theo trường công thức'),
    ],
  },
];

/** Tra cứu nhanh theo mã. */
const INDEX = new Map(DS.map((t) => [t.ma, t]));

/** Trợ lý theo cấp. */
function theoCap(cap) { return DS.filter((t) => t.cap === Number(cap)); }

/** Trợ lý theo miền nghiệp vụ. */
function theoMien(mien) { return DS.filter((t) => t.mien === mien); }

/**
 * Soi chính sổ này. Đây là mục kiểm tự soi mình — nó phải bắt được lỗi do
 * chính người viết sổ gây ra, chứ không phải chỉ đếm cho đủ số.
 */
function soiSo() {
  const loi = [];

  const maTrung = DS.map((t) => t.ma).filter((m, i, a) => a.indexOf(m) !== i);
  if (maTrung.length) loi.push(`mã trùng: ${[...new Set(maTrung)].join(', ')}`);

  const tenTrung = DS.map((t) => t.ten).filter((m, i, a) => a.indexOf(m) !== i);
  if (tenTrung.length) loi.push(`tên trùng: ${[...new Set(tenTrung)].join(', ')}`);

  for (const t of DS) {
    const tran = CAP[t.cap] && CAP[t.cap].tranTuChu;
    if (!tran) { loi.push(`${t.ma}: cấp ${t.cap} không có trong bảng cấp`); continue; }
    // Trần cấp là luật, không phải gợi ý: vượt trần là lỗi của sổ, không phải
    // của người gọi. Bắt ở đây thì không bao giờ tới được lúc chạy.
    if (t.tuChuToiDa > tran) {
      loi.push(`${t.ma}: mức tự chủ ${t.tuChuToiDa} vượt trần cấp ${t.cap} (${tran})`);
    }
    if (!MIEN[t.mien]) loi.push(`${t.ma}: miền "${t.mien}" không có trong bảng miền`);
    if (!t.congCu.length) loi.push(`${t.ma}: không có công cụ nào — trợ lý không làm được gì`);
    // Luật cứng: không ai được cấp thẳng mức chạm ra ngoài.
    if (t.tuChuToiDa >= MUC_PHAI_CO_NGUOI) {
      loi.push(`${t.ma}: mức tự chủ ${t.tuChuToiDa} chạm ra ngoài hệ thống — mức này phải qua người thật, không cấp thẳng`);
    }
    if (!t.kpi.length) loi.push(`${t.ma}: không có chỉ số nào — không chấm được`);
    for (const k of t.kpi) {
      if (!['cao-tot', 'thap-tot'].includes(k.chieu)) loi.push(`${t.ma}/${k.ma}: chiều đo không hợp lệ`);
      if (k.doDuoc !== (k.nguon !== null)) loi.push(`${t.ma}/${k.ma}: cờ doDuoc không khớp nguồn`);
    }
  }

  const chiSo = DS.flatMap((t) => t.kpi);
  return {
    dat: loi.length === 0,
    loi,
    soTroLy: DS.length,
    theoCap: Object.fromEntries(Object.keys(CAP).map((c) => [c, theoCap(c).length])),
    soChiSo: chiSo.length,
    chiSoDoDuoc: chiSo.filter((k) => k.doDuoc).length,
    chiSoChuaNoiNguon: chiSo.filter((k) => !k.doDuoc).length,
  };
}

module.exports = { CAP, MIEN, MUC_DONG_CHAM, MUC_PHAI_CO_NGUOI, DS, INDEX, theoCap, theoMien, soiSo };
