'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MÀN HÌNH QUẢN TRỊ CRM — dựng sẵn ở máy chủ, chỉ vai quản trị xem được
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  BỐN QUY TẮC, giống hệt khu riêng của các gia đình, vì lý do giống hệt:
 *
 *      · Không một dòng JavaScript nào. Trang này hiển thị dữ liệu gia đình
 *        và học phí; càng ít thứ chạy trên máy người xem thì càng ít chỗ cho
 *        một đoạn mã lạ chen vào.
 *      · Không thuộc tính style viết thẳng trong thẻ. Kiểu dáng nằm trong một
 *        khối có nonce, đúng chính sách bảo mật nội dung của hệ.
 *      · Không lưu đệm, không cho công cụ tìm kiếm ghi nhận.
 *      · Mọi chuỗi đi ra đều qua hàm thoát ký tự. Tên một gia đình có dấu
 *        ngoặc nhọn là chuyện hiếm nhưng không phải không bao giờ.
 *
 *  VÌ SAO TRANG NÀY KHÔNG NẰM TRONG BỘ TRANG CÔNG KHAI. Bộ ấy có 177 trang,
 *  đều đi qua bộ soát SEO và bộ soát tiếng Việt, và đều là trang ai cũng xem
 *  được. Trang này thì ngược lại hoàn toàn: nó chứa đúng những cách phân loại
 *  mà bức tường sinh ra để giữ lại. Trộn nó vào bộ ấy là mở một cửa sau.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const thoat = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

const soVN = (n) => (Number.isFinite(Number(n)) ? Number(n).toLocaleString('vi-VN') : '—');

const gioPhut = (t) => (t ? new Date(t).toLocaleString('vi-VN', { hour12: false }) : '—');

const KIEU = `
  :root { color-scheme: light dark; }
  * { box-sizing: border-box; }
  body { margin: 0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
         line-height: 1.55; background: #f6f7f9; color: #17202a; }
  @media (prefers-color-scheme: dark) { body { background: #12151a; color: #e6e9ee; } }
  header { padding: 20px 16px; background: #1d3557; color: #fff; }
  header h1 { margin: 0 0 4px; font-size: 20px; font-weight: 650; }
  header p { margin: 0; opacity: .85; font-size: 13px; }
  main { max-width: 980px; margin: 0 auto; padding: 16px; }
  section { background: #fff; border: 1px solid #dfe3e8; border-radius: 10px;
            padding: 14px 16px; margin: 0 0 14px; }
  @media (prefers-color-scheme: dark) { section { background: #1b1f27; border-color: #2c323d; } }
  section h2 { margin: 0 0 10px; font-size: 15px; font-weight: 650; letter-spacing: .01em; }
  .o { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; }
  .the { border: 1px solid #e6e9ee; border-radius: 8px; padding: 10px 12px; }
  @media (prefers-color-scheme: dark) { .the { border-color: #2c323d; } }
  .the b { display: block; font-size: 22px; font-weight: 650; }
  .the span { font-size: 12px; opacity: .75; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th, td { text-align: left; padding: 7px 8px; border-bottom: 1px solid #edf0f3; vertical-align: top; }
  @media (prefers-color-scheme: dark) { th, td { border-color: #2c323d; } }
  th { font-weight: 600; opacity: .75; font-size: 12px; }
  .cao { color: #b00020; font-weight: 600; }
  .vua { color: #9a6700; }
  .thap { opacity: .7; }
  .khoa { color: #b00020; font-weight: 600; }
  ul { margin: 6px 0 0; padding-left: 18px; }
  li { margin: 3px 0; font-size: 13px; }
  .ghi { font-size: 12px; opacity: .7; margin-top: 8px; }
  .trong { padding: 10px 0; opacity: .7; font-size: 13px; }
  nav { margin-bottom: 12px; font-size: 13px; }
  nav a { color: #1d3557; margin-right: 12px; }
  @media (prefers-color-scheme: dark) { nav a { color: #8ab4f8; } }
`;

function khung({ tieuDe, than, nonce }) {
  return `<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<title>${thoat(tieuDe)} · Quản trị GITAmath</title>
<style nonce="${thoat(nonce)}">${KIEU}</style>
</head>
<body>
<header>
  <h1>${thoat(tieuDe)}</h1>
  <p>Khu điều hành nội bộ — nội dung ở đây không dành cho gia đình học viên.</p>
</header>
<main>
<nav><a href="/quan-tri/crm">Bàn điều khiển</a><a href="/quan-tri/crm/tro-ly">Ba mươi trợ lý</a><a href="/quan-tri/crm/duyet">Hàng chờ duyệt</a><a href="/quan-tri/crm/kpi">Bảng điểm</a></nav>
${than}
</main>
</body>
</html>`;
}

/** Bàn điều khiển — một màn hình đủ để biết ban này đang ở đâu. */
function trangBanDieuKhien(crm, lichCrm, nonce) {
  const bd = crm.quanTri.banDieuKhien();
  const tq = bd.kho || {};
  const hp = tq.hocPhi || {};

  const viec = bd.viecCanLamNgay.map((v) =>
    `<li class="${thoat(v.muc)}">${thoat(v.viec)}</li>`).join('');

  const the = [
    ['Gia đình đang học', soVN((tq.theoChang && tq.theoChang['dang-hoc']) || 0), 'đếm trên kho CRM'],
    ['Học phí còn thiếu', soVN(hp.tienChuaThu || 0), 'đồng · kho học phí'],
    ['Quá hạn', soVN(hp.tienQuaHan || 0), 'đồng · đã quá ngày hẹn'],
    ['Yêu cầu đang mở', soVN((tq.yeuCau && tq.yeuCau.dangMo) || 0), 'chưa xong, chưa đóng'],
    ['Việc chờ duyệt', soVN((bd.hangCho && bd.hangCho.theoTrangThai && bd.hangCho.theoTrangThai.cho) || 0), 'đang chờ người thật'],
    ['Trợ lý bị khoá', soVN(bd.quyen.dangKhoa), `trên ${bd.quyen.tong}`],
  ].map(([t, b, g]) => `<div class="the"><b>${thoat(b)}</b><span>${thoat(t)} — ${thoat(g)}</span></div>`).join('');

  const lich = lichCrm
    ? lichCrm.status().viec.map((v) => `<tr>
        <td>${thoat(v.ten)}</td>
        <td>${v.soLan} lần</td>
        <td>${v.soLoi ? `<span class="cao">${v.soLoi} lỗi</span>` : '—'}</td>
        <td>${thoat(gioPhut(v.lanCuoi))}</td></tr>`).join('')
    : '';

  const trangThai = bd.trangThai.chay
    ? '<p>Ban đang hoạt động bình thường.</p>'
    : `<p class="cao">CẢ BAN ĐANG DỪNG từ ${thoat(gioPhut(bd.trangThai.tuLuc))} — ${thoat(bd.trangThai.lyDo)} (lệnh của ${thoat(bd.trangThai.dungBoi)}).</p>`;

  const than = `
<section>
  <h2>Trạng thái</h2>
  ${trangThai}
  <ul>${viec}</ul>
</section>

<section>
  <h2>Sáu con số của hôm nay</h2>
  <div class="o">${the}</div>
  <p class="ghi">Mọi con số đếm trực tiếp trên kho lúc mở trang. Không có con số nào chép lại từ lần xem trước.</p>
</section>

<section>
  <h2>Ngưỡng đang áp dụng</h2>
  <table>
    <tr><th>Ngưỡng cần người duyệt</th><td>${thoat(bd.nguong ? bd.nguong.nguongCanNguoi : '—')}</td></tr>
    <tr><th>Ngưỡng chặn hẳn</th><td>${thoat(bd.nguong ? bd.nguong.nguongChan : '—')}</td></tr>
  </table>
  <p class="ghi">${bd.nguong ? bd.nguong.luatCung.map((l) => thoat(l)).join(' · ') : ''}</p>
</section>

<section>
  <h2>Việc chạy nền</h2>
  ${lich ? `<table><tr><th>Việc</th><th>Đã chạy</th><th>Lỗi</th><th>Lần gần nhất</th></tr>${lich}</table>`
    : '<p class="trong">Lịch việc chưa bật.</p>'}
</section>

<section>
  <h2>Mười lệnh quản trị gần nhất</h2>
  ${bd.lenhGanDay.length
    ? `<table><tr><th>Lệnh</th><th>Người ra lệnh</th><th>Lúc</th></tr>${
      bd.lenhGanDay.map((l) => `<tr><td>${thoat(l.lenh)}</td><td>${thoat(l.boi)}</td><td>${thoat(gioPhut(l.luc))}</td></tr>`).join('')}</table>`
    : '<p class="trong">Chưa có lệnh quản trị nào được ghi.</p>'}
</section>`;

  return khung({ tieuDe: 'Bàn điều khiển quan hệ gia đình', than, nonce });
}

/** Bảng quyền ba mươi trợ lý. */
function trangTroLy(crm, nonce) {
  const q = crm.quanTri.bangQuyen();
  const hang = q.hang.map((h) => `<tr>
    <td>${thoat(h.ten)}<br><span class="ghi">${thoat(h.ma)}</span></td>
    <td>${h.cap}</td>
    <td>${thoat(h.mien)}</td>
    <td>${h.tranTheoSo}</td>
    <td class="${h.khoa ? 'khoa' : ''}">${h.mucThat}${h.khoa ? ' (khoá)' : ''}</td>
    <td class="ghi">${thoat(h.vi)}</td>
    <td>${h.soCongCu}</td></tr>`).join('');

  const than = `
<section>
  <h2>Ba mươi trợ lý AI chuyên môn</h2>
  <table>
    <tr><th>Trợ lý</th><th>Cấp</th><th>Miền</th><th>Trần theo sổ</th><th>Mức thật</th><th>Vì sao</th><th>Công cụ</th></tr>
    ${hang}
  </table>
  <p class="ghi">Trần theo sổ chỉ HẠ được, không nâng được từ màn hình này. Mức ${thoat(q.tomTat.tranTuyetDoi + 1)} — chạm ra ngoài hệ thống — không cấp cho ai, mọi việc mức ấy đều dừng ở hàng chờ duyệt.</p>
</section>`;

  return khung({ tieuDe: 'Quyền của ba mươi trợ lý', than, nonce });
}

/** Hàng chờ duyệt. */
function trangDuyet(crm, nonce) {
  const bd = crm.choDuyet.bangDo();
  const ds = crm.choDuyet.dangCho({ gioiHan: 50 });
  const hang = ds.map((v) => `<tr>
    <td>${thoat(v.viec)}<br><span class="ghi">${thoat(v.troLyTen || v.troLyMa)} · ${thoat(v.id)}</span></td>
    <td>${thoat(v.diemRuiRo)}</td>
    <td>${v.deXuat.map((d) => thoat(d.congCu || d.vi || '')).join('<br>')}</td>
    <td>${thoat(gioPhut(v.hetHanLuc))}</td></tr>`).join('');

  const than = `
<section>
  <h2>Đang chờ người thật quyết</h2>
  ${ds.length
    ? `<table><tr><th>Việc</th><th>Rủi ro</th><th>Sẽ chạy gì nếu đồng ý</th><th>Hết hạn</th></tr>${hang}</table>`
    : '<p class="trong">Không có việc nào đang chờ.</p>'}
  <p class="ghi">Quyết bằng cổng <code>POST /crm/duyet/&lt;mã&gt;/quyet</code>. Việc quá hạn mà không ai quyết thì đóng lại ở trạng thái hết hạn — im lặng không bao giờ được tính là đồng ý.</p>
</section>

<section>
  <h2>Bảng đo của chính hàng chờ</h2>
  <table>
    <tr><th>Tổng số việc đã qua</th><td>${soVN(bd.tong)}</td></tr>
    <tr><th>Đang chờ</th><td>${soVN(bd.theoTrangThai.cho)}</td></tr>
    <tr><th>Đã đồng ý</th><td>${soVN(bd.theoTrangThai['dong-y'])}</td></tr>
    <tr><th>Đã từ chối</th><td>${soVN(bd.theoTrangThai['tu-choi'])}</td></tr>
    <tr><th>Hết hạn mà không ai quyết</th><td class="${bd.theoTrangThai['het-han'] ? 'cao' : ''}">${soVN(bd.theoTrangThai['het-han'])}</td></tr>
    <tr><th>Chờ trung bình</th><td>${bd.thoiGianChoTrungBinhPhut == null ? '—' : `${soVN(bd.thoiGianChoTrungBinhPhut)} phút`}</td></tr>
  </table>
  ${bd.canhBao ? `<p class="cao">${thoat(bd.canhBao)}</p>` : ''}
</section>`;

  return khung({ tieuDe: 'Hàng chờ duyệt', than, nonce });
}

/** Bảng điểm KPI. */
function trangKpi(crm, nonce) {
  const b = crm.kpi.bangDiem();
  const ds = require('./so-tro-ly').DS.map((t) => crm.kpi.cham(t.ma));
  const hang = ds.map((r) => `<tr>
    <td>${thoat(r.troLyTen)}<br><span class="ghi">${thoat(r.troLyMa)}</span></td>
    <td>${r.chamDuoc ? thoat(r.diem) : '—'}</td>
    <td>${r.chamDuoc ? thoat(r.xep) : `<span class="ghi">${thoat(r.lyDo || 'chưa đủ dữ liệu')}</span>`}</td>
    <td>${r.thongKe.chiSoChamDuoc}/${r.thongKe.tongChiSo}</td>
    <td class="ghi">${thoat(r.luuY || '')}</td></tr>`).join('');

  const than = `
<section>
  <h2>Độ phủ của chính bảng điểm</h2>
  <div class="o">
    <div class="the"><b>${soVN(b.doPhuChiSo.tong)}</b><span>chỉ số đã khai</span></div>
    <div class="the"><b>${soVN(b.doPhuChiSo.coNguonDo)}</b><span>chỉ số đã nối nguồn đo</span></div>
    <div class="the"><b>${soVN(b.doPhuChiSo.chuaNoiNguon)}</b><span>chỉ số CHƯA nối nguồn</span></div>
    <div class="the"><b>${thoat(b.doPhuChiSo.tyLeCoNguon)}%</b><span>độ phủ</span></div>
  </div>
  <p class="ghi">Điểm chỉ tính trên chỉ số có nguồn. Chỉ số chưa nối nguồn được đếm riêng chứ không chấm bừa cho bảng đỡ trống.</p>
</section>

<section>
  <h2>Bảng điểm ba mươi trợ lý</h2>
  <table>
    <tr><th>Trợ lý</th><th>Điểm</th><th>Xếp</th><th>Chấm được</th><th>Lưu ý</th></tr>
    ${hang}
  </table>
  ${b.loiNhan ? `<p class="ghi">${thoat(b.loiNhan)}</p>` : ''}
</section>`;

  return khung({ tieuDe: 'Bảng điểm ba mươi trợ lý', than, nonce });
}

/**
 * Định tuyến trang quản trị.
 * @returns {{html:string}|null} null nghĩa là đường dẫn này không phải của CRM
 */
function xemTrang(crm, lichCrm, duongDan, nonce) {
  const d = String(duongDan || '').replace(/\/+$/, '') || '/quan-tri/crm';
  if (d === '/quan-tri/crm') return { html: trangBanDieuKhien(crm, lichCrm, nonce) };
  if (d === '/quan-tri/crm/tro-ly') return { html: trangTroLy(crm, nonce) };
  if (d === '/quan-tri/crm/duyet') return { html: trangDuyet(crm, nonce) };
  if (d === '/quan-tri/crm/kpi') return { html: trangKpi(crm, nonce) };
  return null;
}

module.exports = { xemTrang, moiDuongDan: () => ['/quan-tri/crm', '/quan-tri/crm/tro-ly', '/quan-tri/crm/duyet', '/quan-tri/crm/kpi'] };
