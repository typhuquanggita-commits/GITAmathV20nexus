'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐIỀU PHỐI CRM — một lượt đi qua chín cửa, và không cửa nào bỏ được
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *      1. Ghi câu hỏi vào sổ            — để sau này đọc lại được
 *      2. Hỏi bàn điều khiển            — ban có đang dừng không, ai bị khoá
 *      3. Định tuyến                    — giao cho ai, đọc không ra thì hỏi lại
 *      4. Cân mức tự chủ                — lượt này được làm tới đâu
 *      5. Chạy tổ                       — người phụ trước, người chính sau
 *      6. Dựng hàng chờ duyệt nếu cần   — việc chạm ra ngoài dừng ở đây
 *      7. Soi lời trả lời               — qua bức tường trước khi trả ra
 *      8. Ghi tín hiệu                  — để lần sau biết lần này thế nào
 *      9. Ghi nhật ký kiểm toán         — móc xích băm, sửa một bản là vỡ cả
 *
 *  CỬA 7 LÀ CỬA DỄ QUÊN NHẤT VÀ QUAN TRỌNG NHẤT. Trợ lý đọc dữ liệu nội bộ để
 *  suy nghĩ là đúng việc của họ. Nhưng lời họ nói ra có thể mang theo tên một
 *  cách phân loại mà khách hàng không được biết. Vì vậy mọi câu trả lời đều đi
 *  qua bức tường trước khi rời khỏi tệp này — kể cả khi người hỏi là quản trị,
 *  vì màn hình quản trị cũng có lúc bị chụp lại và gửi đi.
 *
 *  ĐỌC KHÔNG RA THÌ HỎI LẠI, KHÔNG ĐOÁN. Cửa 3 trả về "không rõ" thì lượt dừng
 *  ngay tại đó với một câu hỏi lại. Đưa cho một trợ lý không đúng việc là tạo
 *  ra một câu trả lời trôi chảy và sai — thứ tệ hơn im lặng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { id: newId } = require('../utils');
const tuong = require('../cay-tien/buc-tuong');

const KhoCRM = require('./kho');
const KhoCongCu = require('./kho-cong-cu');
const MucTuChu = require('./muc-tu-chu');
const DinhTuyen = require('./dinh-tuyen');
const ToTruong = require('./to-truong');
const ChoDuyet = require('./cho-duyet');
const TinHieu = require('./tin-hieu');
const HopTac = require('./hop-tac');
const KpiCRM = require('./kpi');
const QuanTriCRM = require('./quan-tri');

class DieuPhoiCRM {
  /**
   * @param {object} o
   * @param {object} o.N       Nexus
   * @param {string} o.loiDinhTuyen  'ghep' | 'tu-khoa' | 'mo-hinh'
   */
  constructor({ N, loiDinhTuyen = null } = {}) {
    if (!N || !N.db) throw new Error('DieuPhoiCRM cần Nexus có cơ sở dữ liệu');
    this.N = N;

    this.kho = new KhoCRM({ db: N.db, nhatKy: N.audit });
    this.congCu = new KhoCongCu({ N, kho: this.kho });
    this.mucTuChu = new MucTuChu();
    this.dinhTuyen = new DinhTuyen({
      llm: N.llm || null,
      loi: loiDinhTuyen || process.env.CRM_LOI_DINH_TUYEN || 'ghep',
      boDem: N.cache || null,
    });
    this.hopTac = new HopTac({ N });
    this.toTruong = new ToTruong({ llm: N.llm || null, congCu: this.congCu, hopTac: this.hopTac });
    this.choDuyet = new ChoDuyet({ repo: this.kho.duyet, nhatKy: N.audit });
    this.tinHieu = new TinHieu({ repo: this.kho.tinHieu });
    this.kpi = new KpiCRM({ tinHieu: this.tinHieu, choDuyet: this.choDuyet, kho: this.kho });
    this.quanTri = new QuanTriCRM({
      nhatKy: N.audit, mucTuChu: this.mucTuChu, choDuyet: this.choDuyet,
      kpi: this.kpi, kho: this.kho,
    });

    this.dem = { luot: 0, khongDocRa: 0, canNguoi: 0, bichan: 0, tuongChan: 0 };
  }

  /**
   * Chạy một lượt.
   *
   * @param {object} o
   * @param {string} o.cauHoi
   * @param {string} o.phienId   nối nhiều lượt vào một phiên
   * @param {string} o.boi       ai hỏi — bắt buộc, vì mọi lượt đều ghi sổ
   * @param {object} o.boiCanh   {giaDinhId, hocVienId, soTien, tuKhoa}
   */
  async chay({ cauHoi, phienId = null, boi = null, boiCanh = {} } = {}) {
    const t0 = Date.now();
    const phien = phienId || newId('PHIEN');
    this.dem.luot++;

    if (!cauHoi || String(cauHoi).trim().length < 3) {
      return this._tra(phien, { ok: false, loi: 'CAU_HOI_QUA_NGAN' }, t0);
    }
    if (!boi) {
      return this._tra(phien, {
        ok: false, loi: 'THIEU_NGUOI_HOI',
        lyDo: 'Mọi lượt CRM đều vào nhật ký kiểm toán, nên phải biết ai hỏi.',
      }, t0);
    }

    // ── Cửa 1 · ghi câu hỏi ──
    this._nhatKy('crm.luot.bat-dau', phien, boi, { soChu: String(cauHoi).length });

    // ── Cửa 2 · bàn điều khiển ──
    if (this.quanTri.toanBanDung) {
      return this._tra(phien, {
        ok: false, loi: 'TOAN_BAN_DANG_DUNG',
        lyDo: `Super Admin đã dừng cả ban: ${this.quanTri.toanBanDung.lyDo}`,
      }, t0);
    }

    // ── Cửa 3 · định tuyến ──
    const tuyen = await this.dinhTuyen.doc(cauHoi);
    if (!tuyen.doc) {
      this.dem.khongDocRa++;
      this._nhatKy('crm.luot.khong-doc-ra', phien, boi, { deNghi: tuyen.deNghi });
      return this._tra(phien, {
        ok: false, loi: 'KHONG_DOC_RA_Y_DINH',
        lyDo: tuyen.lyDo, hoiLai: tuyen.lamGiTiepTheo, deNghi: tuyen.deNghi,
      }, t0);
    }

    const troLy = tuyen.troLyChinh;
    const mucBanDieuKhien = this.quanTri.mucThatCua(troLy.ma);
    if (!mucBanDieuKhien || mucBanDieuKhien.muc === 0) {
      return this._tra(phien, {
        ok: false, loi: 'TRO_LY_DANG_KHOA',
        lyDo: `Trợ lý "${troLy.ten}" hiện không hoạt động: ${mucBanDieuKhien ? mucBanDieuKhien.vi : 'không rõ'}.`,
      }, t0);
    }

    // ── Cửa 4 · cân mức tự chủ ──
    const mucCongCu = troLy.congCu.map((c) => this.congCu.mucCua(c));
    const can = this.mucTuChu.can({
      troLy,
      yDinh: tuyen.nhanYDinh,
      soTien: Number(boiCanh.soTien) || 0,
      chamHocVien: tuyen.chamHocVien || !!boiCanh.hocVienId,
      mucCongCu,
    });

    if (!can.choLam) {
      this.dem.bichan++;
      this._nhatKy('crm.luot.bi-chan', phien, boi, { diem: can.diem, lyDo: can.lyDo });
      return this._tra(phien, { ok: false, loi: 'BI_CHAN', lyDo: can.lyDo, diemRuiRo: can.diem, phanRuiRo: can.phan }, t0);
    }

    const mucThat = Math.min(can.mucThat, mucBanDieuKhien.muc);

    // ── Cửa 5 · chạy tổ ──
    const to = await this.toTruong.chayTo({
      troLyChinh: troLy,
      troLyPhu: tuyen.troLyPhu,
      cauHoi,
      boiCanh: { ...boiCanh, phienId: phien, troLyMa: troLy.ma },
      mucThat,
    });

    // ── Cửa 6 · hàng chờ duyệt ──
    let viecCho = null;
    if (can.canNguoi) {
      this.dem.canNguoi++;
      const r = this.choDuyet.xin({
        phienId: phien,
        troLyMa: troLy.ma, troLyTen: troLy.ten,
        giaDinhId: boiCanh.giaDinhId || null,
        viec: `${troLy.ten} xin làm: ${String(cauHoi).slice(0, 300)}`,
        deXuat: this._deXuatTuLuot(to, troLy, mucThat),
        diemRuiRo: can.diem,
        lyDo: can.lyDo,
      });
      if (r.ok) viecCho = r.viecCho;
    }

    // ── Cửa 7 · soi lời trả lời ──
    let traLoi = to.traLoiCuoi;
    // soiRoRi trả về {sach, roRi:[…]} — cờ là "sach", còn "roRi" là DANH SÁCH.
    // Bản đầu viết `if (roRi && roRi.roRi)`, và một mảng rỗng trong JavaScript
    // vẫn là giá trị đúng, nên bức tường chặn mọi câu trả lời kể cả câu sạch.
    // Bắt được lúc chạy thử: một câu không có chữ nào cấm vẫn bị giữ lại.
    const soi = tuong.soiRoRi(String(traLoi || ''));
    if (!soi.sach) {
      this.dem.tuongChan++;
      this._nhatKy('crm.luot.tuong-chan', phien, boi, { cum: soi.roRi.map((r) => r.cum).slice(0, 3) });
      traLoi = 'Câu trả lời đã dựng xong nhưng bị bức tường giữ lại vì có chứa cách phân loại nội bộ. '
        + 'Đây là bức tường làm đúng việc của nó, không phải lỗi. Hãy hỏi lại theo hướng khác, '
        + 'hoặc đọc số liệu gốc ở mục quản trị.';
    }

    // ── Cửa 8 · tín hiệu ──
    const tinHieuId = this.tinHieu.ghi({
      phienId: phien,
      yDinh: tuyen.yDinh,
      nguonDinhTuyen: tuyen.nguon,
      doTin: tuyen.doTin,
      chuoiTroLy: to.chuoiTroLy,
      kieuGhep: to.kieuGhep,
      congCuGoi: to.congCuGoi,
      soChuGoc: String(cauHoi).length,
      msTong: Date.now() - t0,
      diemRuiRo: can.diem,
      canNguoi: can.canNguoi,
      moHinh: to.moHinh,
    });

    // ── Cửa 9 · nhật ký ──
    this._nhatKy('crm.luot.xong', phien, boi, {
      yDinh: tuyen.yDinh, troLy: troLy.ma, kieuGhep: to.kieuGhep,
      mucThat, canNguoi: can.canNguoi, viecChoId: viecCho ? viecCho.id : null,
    });

    return this._tra(phien, {
      ok: true,
      traLoi,
      yDinh: tuyen.yDinh,
      doTinDinhTuyen: tuyen.doTin,
      nguonDinhTuyen: tuyen.nguon,
      troLyChinh: { ma: troLy.ma, ten: troLy.ten, cap: troLy.cap, mien: troLy.mien },
      troLyPhu: tuyen.troLyPhu.map((p) => ({ ma: p.ma, ten: p.ten })),
      kieuGhep: to.kieuGhep,
      mucTuChuThat: mucThat,
      diemRuiRo: can.diem,
      phanRuiRo: can.phan,
      canNguoiDuyet: can.canNguoi,
      viecCho: viecCho ? { id: viecCho.id, hetHanLuc: viecCho.hetHanLuc, soDeXuat: viecCho.deXuat.length } : null,
      congCuDaGoi: to.congCuGoi,
      moHinh: to.moHinh,
      tinHieuId,
    }, t0);
  }

  /**
   * Việc cụ thể sẽ chạy nếu người duyệt đồng ý.
   *
   * Không bao giờ để danh sách này rỗng: hàng chờ từ chối nhận việc rỗng, và
   * đó là đúng — gật đầu với một khoảng trống thì không phải là duyệt.
   */
  _deXuatTuLuot(to, troLy, mucThat) {
    // Gộp theo tên công cụ: người chính và người phụ cùng cầm gui_thu thì
    // người duyệt chỉ cần thấy MỘT dòng, không phải hai dòng giống hệt nhau.
    const chuaChay = new Map();
    for (const l of to.cacLuot) {
      for (const c of l.congCuDaGoi) {
        if (!c.chay && c.lyDo && !chuaChay.has(c.ten)) chuaChay.set(c.ten, { congCu: c.ten, vi: c.lyDo });
      }
    }
    if (chuaChay.size) return [...chuaChay.values()].slice(0, 20);
    return [{
      congCu: null,
      vi: `Đồng ý cho "${troLy.ten}" hành động theo đề xuất trong câu trả lời, ở mức ${mucThat}.`,
    }];
  }

  /**
   * Người duyệt quyết. Quyết xong thì tín hiệu học được cập nhật ngược —
   * đây chính là chỗ vòng học khép lại.
   */
  quyetViecCho(id, { trangThai, nguoiQuyet, ghiChu = null } = {}) {
    const r = this.choDuyet.quyet(id, { trangThai, nguoiQuyet, ghiChu });
    if (r.ok && r.viecCho && r.viecCho.phienId) {
      this.tinHieu.ghiPhanHoi(r.viecCho.phienId, trangThai, { viecChayThat: trangThai === 'dong-y' });
    }
    return r;
  }

  _nhatKy(hanhDong, phien, boi, chiTiet) {
    if (!this.N.audit) return;
    Promise.resolve(this.N.audit.record({
      actor: boi || 'crm', action: hanhDong, target: phien,
      verdict: 'ALLOW', detail: chiTiet,
    })).catch(() => {});
  }

  _tra(phienId, than, t0) {
    return { phienId, ...than, ms: Date.now() - t0 };
  }

  status() {
    return {
      troLy: require('./so-tro-ly').soiSo(),
      congCu: this.congCu.status(),
      dinhTuyen: this.dinhTuyen.status(),
      mucTuChu: this.mucTuChu.status(),
      hangCho: this.choDuyet.status(),
      tinHieu: this.tinHieu.status(),
      hopTac: this.hopTac.status(),
      kpi: this.kpi.status(),
      quanTri: this.quanTri.status(),
      kho: this.kho.status(),
      dem: { ...this.dem },
    };
  }
}

module.exports = DieuPhoiCRM;
