'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HỢP TÁC — cây cầu từ 30 trợ lý CRM sang 500 trợ lý và các nhà khoa học
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Đây là chỗ câu "hợp tác với lực lượng 500" thôi làm một dòng mô tả và trở
 *  thành một lệnh gọi có thật.
 *
 *  BA CỬA, và mỗi cửa mở cho một loại việc khác hẳn:
 *
 *      giaoMotViec   một việc, một trợ lý trong 500 làm. Dùng khi việc rõ
 *                    ràng và không cần bàn.
 *      giaoToViec    Người chia việc → nhiều Người làm chạy song song →
 *                    Người phản biện chấm → gộp lại. Dùng khi việc lớn, chia
 *                    được, và chia ra thì nhanh hơn.
 *      hoiNhaKhoaHoc hỏi nhà khoa học toán hoặc nhà khoa học ngôn ngữ. Dùng
 *                    khi câu hỏi đụng chuyên môn mà trợ lý CRM không có.
 *
 *  VÌ SAO KHÔNG ĐỂ TRỢ LÝ CRM TỰ LÀM HẾT. Ba mươi trợ lý ở đây biết việc quan
 *  hệ gia đình. Họ KHÔNG biết thẩm định một lời giải toán, không biết soi
 *  chính tả bốn cấp, không biết dựng một bộ đề. Bắt họ làm là bắt họ đoán, mà
 *  đoán trong việc chuyên môn thì tạo ra thứ trông như đúng.
 *
 *  MỖI LẦN GỌI ĐỀU CÓ TRẦN. Giao việc xuống lực lượng là tốn token thật, nên
 *  mỗi lệnh gọi mang theo hạn thời gian và hạn số người; hết hạn thì trả về
 *  "không kịp" chứ không treo lượt của người đang hỏi.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { withTimeout } = require('../utils');

/** Loại việc của lực lượng 500 mà CRM được phép giao. */
const VIEC_CHO_PHEP = {
  business_analysis: 'Phân tích nghiệp vụ — việc mặc định của CRM',
  vietnamese: 'Viết và biên tập tiếng Việt',
  content_editing: 'Biên tập nội dung đã có',
  long_context: 'Đọc tài liệu dài rồi rút gọn',
  complex_reasoning: 'Suy luận nhiều bước',
};

const HAN_MOT_VIEC_MS = 20_000;
const HAN_TO_VIEC_MS = 60_000;
const SO_NGUOI_TOI_DA = 5;

class HopTac {
  /**
   * @param {object} N Nexus — cần scheduler, scientist, linguist, agents
   */
  constructor({ N } = {}) {
    this.N = N || null;
    this.dem = { motViec: 0, toViec: 0, nhaKhoaHoc: 0, khongKip: 0, tuChoi: 0 };
  }

  /** Lực lượng có sẵn tới đâu — để tầng trên biết cầu này có đi được không. */
  sanSang() {
    const N = this.N;
    return {
      lucLuong: !!(N && N.scheduler),
      soTroLy: N && N.agents ? N.agents.length : 0,
      nhaKhoaHocToan: !!(N && N.scientist),
      nhaKhoaHocNgonNgu: !!(N && N.linguist),
      loaiViecChoPhep: Object.keys(VIEC_CHO_PHEP),
    };
  }

  _chan(loaiViec) {
    if (!this.N || !this.N.scheduler) {
      return { ok: false, loi: 'CHUA_CO_LUC_LUONG', lyDo: 'Hệ thống chưa dựng đội điều phối trợ lý.' };
    }
    if (!VIEC_CHO_PHEP[loaiViec]) {
      this.dem.tuChoi++;
      return {
        ok: false, loi: 'LOAI_VIEC_KHONG_CHO_PHEP',
        lyDo: `CRM chỉ được giao xuống lực lượng ${Object.keys(VIEC_CHO_PHEP).length} loại việc: ${Object.keys(VIEC_CHO_PHEP).join(', ')}.`,
      };
    }
    return null;
  }

  /**
   * Giao một việc cho một trợ lý trong lực lượng 500.
   * @param {object} o
   * @param {string} o.loaiViec
   * @param {string} o.noiDung
   * @param {string} o.xinBoi  mã trợ lý CRM đứng tên xin
   */
  async giaoMotViec({ loaiViec = 'business_analysis', noiDung, xinBoi = null, hanMs = HAN_MOT_VIEC_MS } = {}) {
    const chan = this._chan(loaiViec);
    if (chan) return chan;
    if (!noiDung || String(noiDung).trim().length < 10) {
      return { ok: false, loi: 'NOI_DUNG_QUA_NGAN' };
    }
    this.dem.motViec++;
    const t0 = Date.now();
    try {
      const r = await withTimeout(
        this.N.scheduler.dispatch({
          type: loaiViec,
          input: String(noiDung),
          requester: `crm:${xinBoi || 'khong-ro'}`,
          dedupeKey: null,
        }),
        hanMs, 'HET_HAN_CHO',
      );
      return {
        ok: !!r.ok,
        ketQua: r.ok ? r.output : null,
        loi: r.ok ? null : (r.error || 'LUC_LUONG_KHONG_TRA_LOI'),
        troLyDaLam: r.agentId || null,
        ms: Date.now() - t0,
        nguon: 'Lực lượng trợ lý AI của hệ thống',
      };
    } catch (e) {
      this.dem.khongKip++;
      return { ok: false, loi: 'HET_HAN_CHO', lyDo: `Lực lượng không trả lời trong ${Math.round(hanMs / 1000)} giây.`, ms: Date.now() - t0 };
    }
  }

  /**
   * Giao một tổ: chia việc, làm song song, phản biện, gộp.
   * Dùng khi việc chia ra được. Việc không chia được mà vẫn giao tổ thì chỉ
   * tốn thêm người chứ không nhanh hơn.
   */
  async giaoToViec({ loaiViec = 'business_analysis', noiDung, soNguoi = 3, xinBoi = null, hanMs = HAN_TO_VIEC_MS } = {}) {
    const chan = this._chan(loaiViec);
    if (chan) return chan;
    if (!noiDung || String(noiDung).trim().length < 20) {
      return { ok: false, loi: 'NOI_DUNG_QUA_NGAN', lyDo: 'Việc quá ngắn thì không chia tổ được — giao một người là đủ.' };
    }
    const n = Math.max(2, Math.min(Number(soNguoi) || 3, SO_NGUOI_TOI_DA));
    this.dem.toViec++;
    const t0 = Date.now();
    try {
      const r = await withTimeout(
        this.N.scheduler.team({ type: loaiViec, input: String(noiDung), workers: n }),
        hanMs, 'HET_HAN_CHO',
      );
      return {
        ok: !!r.ok,
        ketQua: r.ok ? (r.output || r.merged || null) : null,
        soNguoiDaLam: n,
        duongDi: r.trail || null,
        loi: r.ok ? null : (r.error || 'TO_KHONG_TRA_LOI'),
        ms: Date.now() - t0,
        nguon: 'Tổ trợ lý AI: chia việc, làm song song, phản biện, gộp',
      };
    } catch (e) {
      this.dem.khongKip++;
      return { ok: false, loi: 'HET_HAN_CHO', lyDo: `Tổ không xong trong ${Math.round(hanMs / 1000)} giây.`, ms: Date.now() - t0 };
    }
  }

  /**
   * Hỏi một nhà khoa học của hệ thống.
   *
   * Hai nhà khoa học này KHÔNG phải mô hình ngôn ngữ khoác tên khác: họ có
   * phương pháp riêng viết bằng mã, và kết quả của họ kiểm chứng được. Vì vậy
   * cửa này trả về nguyên kết quả có cấu trúc, không diễn giải lại thành văn.
   *
   * @param {'toan'|'ngon-ngu'} nganh
   * @param {string} viec    tên việc của nhà khoa học ấy
   */
  async hoiNhaKhoaHoc({ nganh, viec, thamSo = {} } = {}) {
    this.dem.nhaKhoaHoc++;
    const N = this.N;

    if (nganh === 'toan') {
      if (!N || !N.scientist) return { ok: false, loi: 'CHUA_CO_NHA_KHOA_HOC_TOAN' };
      const CHO_PHEP = { 'doc-vi': 'docVi', 'phap-do': 'phapDo', 'giai-da-cach': 'giaiDaCach', 'ghep-phuong-phap': 'ghepPhuongPhap' };
      const ham = CHO_PHEP[viec];
      if (!ham) {
        return { ok: false, loi: 'VIEC_KHONG_CHO_PHEP', lyDo: `Nhà khoa học toán mở cho CRM các việc: ${Object.keys(CHO_PHEP).join(', ')}.` };
      }
      try {
        const kq = await N.scientist[ham](thamSo.deBai || thamSo.vanDe || thamSo.docVi, thamSo.tuyChon || {});
        return { ok: true, nganh: 'toan', viec, ketQua: kq, nguon: 'src/math/scientist.js' };
      } catch (e) { return { ok: false, loi: 'NHA_KHOA_HOC_HONG', lyDo: e.message }; }
    }

    if (nganh === 'ngon-ngu') {
      if (!N || !N.linguist) return { ok: false, loi: 'CHUA_CO_NHA_KHOA_HOC_NGON_NGU' };
      const CHO_PHEP = { soat: 'soat', 'chuan-hoa': 'chuanHoa', 'phan-tich-cau': 'phanTichCau' };
      const ham = CHO_PHEP[viec];
      if (!ham) {
        return { ok: false, loi: 'VIEC_KHONG_CHO_PHEP', lyDo: `Nhà khoa học ngôn ngữ mở cho CRM các việc: ${Object.keys(CHO_PHEP).join(', ')}.` };
      }
      try {
        const kq = N.linguist[ham](thamSo.chu || '', thamSo.tuyChon || {});
        return { ok: true, nganh: 'ngon-ngu', viec, ketQua: kq, nguon: 'src/lang/scientist.js' };
      } catch (e) { return { ok: false, loi: 'NHA_KHOA_HOC_HONG', lyDo: e.message }; }
    }

    return { ok: false, loi: 'NGANH_LA', lyDo: 'Chỉ có hai ngành: toan và ngon-ngu.' };
  }

  status() {
    return { ...this.sanSang(), daGoi: { ...this.dem } };
  }
}

module.exports = HopTac;
module.exports.VIEC_CHO_PHEP = VIEC_CHO_PHEP;
