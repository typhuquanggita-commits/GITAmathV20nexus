'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐỊNH TUYẾN — câu hỏi này giao cho ai
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  BA LỐI, và lối mặc định là lối ghép:
 *
 *      tu-khoa   so từ khoá. Nhanh, tất định, không tốn một đồng nào. Đọc
 *                đúng khoảng bảy phần mười câu hỏi thường gặp.
 *      mo-hinh   hỏi mô hình ngôn ngữ. Đọc được câu lạ, nhưng chậm, tốn, và
 *                KHÔNG TẤT ĐỊNH — cùng một câu có thể ra hai kết quả.
 *      ghep      so từ khoá trước; chỉ khi từ khoá không chắc mới hỏi mô hình.
 *
 *  TẤT ĐỊNH LÀ LUẬT CỦA HỆ NÀY, nên lối ghép được viết sao cho phần tất định
 *  luôn chạy trước và luôn thắng khi nó chắc. Mục kiểm chạy ở lối tu-khoa để
 *  kết quả lặp lại được; lối ghép dành cho lúc chạy thật.
 *
 *  ĐỌC KHÔNG RA THÌ NÓI LÀ KHÔNG RA. Bản thiết kế gốc, khi không phân loại
 *  được, ném câu hỏi cho trợ lý điều hành tổng với độ tin 0,3. Làm vậy thì
 *  người dùng nhận một câu trả lời trông như thật từ một trợ lý không được
 *  giao việc ấy. Ở đây, không đọc ra thì trả về nhãn "khong-ro" kèm danh sách
 *  đề nghị, và tầng điều phối hỏi lại người dùng.
 *
 *  BỘ ĐỆM CHỈ ĐẶT Ở ĐÂY, KHÔNG ĐẶT Ở CHỖ TRẢ LỜI. Bản thiết kế gốc đệm MỌI
 *  lượt gọi mô hình. Đặt ở chỗ trả lời thì nguy: lời nhắc gửi cho mô hình có
 *  kèm SỐ LIỆU ĐỌC LÚC ẤY — công nợ, số gia đình, kỳ tới hạn — nên một câu trả
 *  lời đệm lại là một bức ảnh chụp số liệu cũ, và lần sau nó được đưa ra như
 *  số hôm nay. Sai kiểu ấy không ai nhìn ra, vì câu trả lời vẫn trôi chảy.
 *
 *  Còn ở đây thì an toàn: phân loại ý định chỉ nhìn vào CHÍNH CÂU HỎI, không
 *  nhìn vào dữ liệu. "Kiểm tra công nợ" hôm nay hay tháng sau vẫn là ý định
 *  công nợ. Đệm đúng chỗ này cắt được phần lớn lượt gọi mô hình tốn kém mà
 *  không tạo ra một con số cũ nào.
 *
 *  MỖI Ý ĐỊNH CÓ NGƯỜI CHÍNH VÀ NGƯỜI PHỤ. Người phụ không phải để cho đông:
 *  họ chạy trước, bỏ ngữ cảnh lên bảng chung, rồi người chính mới trả lời. Ai
 *  đứng phụ cho ai là chuyện đã cân nhắc từng dòng, không phải ghép máy móc.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { viKey } = require('../utils');
const { INDEX: TRO_LY } = require('./so-tro-ly');

/**
 * Bảng ý định. Mỗi dòng: ý định → người chính, người phụ, nhãn ý định để cân
 * rủi ro, và việc này có chạm dữ liệu học viên hay không.
 */
const BANG_Y_DINH = {
  'toan-canh': { chinh: 'dieu-hanh-tong', phu: ['dieu-hanh-tai-chinh'], nhan: 'phan_tich', chamHocVien: false },
  'tuyen-sinh-toan-canh': { chinh: 'dieu-hanh-tuyen-sinh', phu: ['ban-tuyen-sinh'], nhan: 'phan_tich', chamHocVien: false },
  'cham-diem-gia-dinh': { chinh: 'cham-diem-quan-tam', phu: [], nhan: 'cham_diem', chamHocVien: false },
  'tu-van-lo-trinh': { chinh: 'tu-van-lo-trinh', phu: ['ban-tu-van'], nhan: 'phan_tich', chamHocVien: true },
  'dinh-gia': { chinh: 'dinh-gia-goi-hoc', phu: ['ban-ke-hoach-tai-chinh'], nhan: 'doi_hoc_phi', chamHocVien: false },
  'chien-dich': { chinh: 'phan-tich-chien-dich', phu: ['ban-truyen-thong'], nhan: 'phan_tich', chamHocVien: false },
  'soan-noi-dung': { chinh: 'soan-noi-dung', phu: ['ban-truyen-thong'], nhan: 'soan_thao', chamHocVien: false },
  'ho-so-gia-dinh': { chinh: 'ho-so-360', phu: ['ban-cham-soc'], nhan: 'tra_cuu', chamHocVien: true },
  'yeu-cau-ho-tro': { chinh: 'phan-loai-yeu-cau', phu: ['ban-ho-tro'], nhan: 'sua_ho_so', chamHocVien: false },
  'nguy-co-dung-hoc': { chinh: 'du-bao-thoi-hoc', phu: ['ban-cham-soc'], nhan: 'du_bao', chamHocVien: true },
  'dong-tien': { chinh: 'du-bao-dong-tien', phu: ['dieu-hanh-tai-chinh'], nhan: 'du_bao', chamHocVien: false },
  'cong-no': { chinh: 'quan-ly-cong-no', phu: ['ban-hoc-phi'], nhan: 'nhac_hoc_phi', chamHocVien: false },
  'kha-nang-chi-tra': { chinh: 'tham-dinh-kha-nang', phu: ['ban-hoc-phi'], nhan: 'phan_tich', chamHocVien: false },
  'ke-hoach-tai-chinh': { chinh: 'ban-ke-hoach-tai-chinh', phu: ['dieu-hanh-tai-chinh'], nhan: 'du_bao', chamHocVien: false },
  'chat-luong-du-lieu': { chinh: 'lam-sach-du-lieu', phu: ['ban-du-lieu'], nhan: 'sua_ho_so', chamHocVien: false },
  'rui-ro-tuan-thu': { chinh: 'dieu-hanh-rui-ro', phu: [], nhan: 'phan_tich', chamHocVien: false },
  'van-hanh': { chinh: 'dieu-hanh-van-hanh', phu: ['ban-ho-tro'], nhan: 'phan_tich', chamHocVien: false },
  'diem-cham': { chinh: 'ban-cham-soc', phu: [], nhan: 'tra_cuu', chamHocVien: false },
  'y-dinh-tin-nhan': { chinh: 'doc-y-dinh', phu: [], nhan: 'tra_cuu', chamHocVien: false },
  'cam-xuc': { chinh: 'doc-cam-xuc', phu: [], nhan: 'tra_cuu', chamHocVien: false },
  'tom-tat': { chinh: 'tom-tat-buoi-lam-viec', phu: [], nhan: 'ghi_nhat_ky', chamHocVien: false },
  'bat-thuong': { chinh: 'phat-hien-bat-thuong', phu: ['dieu-hanh-rui-ro'], nhan: 'phan_tich', chamHocVien: false },
  'hieu-qua': { chinh: 'tinh-hieu-qua', phu: [], nhan: 'phan_tich', chamHocVien: false },
  'the-diem': { chinh: 'dieu-hanh-tong', phu: ['dieu-hanh-rui-ro'], nhan: 'phan_tich', chamHocVien: false },
  'gui-thu': { chinh: 'soan-noi-dung', phu: ['ban-cham-soc'], nhan: 'gui_ra_ngoai', chamHocVien: false },
};

/**
 * Từ khoá → ý định. Viết không dấu vì phép so bỏ dấu trước khi khớp; phụ
 * huynh và nhân viên gõ không dấu là chuyện thường ngày.
 *
 * Thứ tự CÓ NGHĨA: dòng trên khớp trước. Cụm hẹp đặt trên cụm rộng, nếu không
 * thì "cong no hoc phi" bị "hoc phi" ở dưới nuốt mất.
 */
const TU_KHOA = [
  [['cong no', 'no hoc phi', 'nhac no', 'chua dong tien', 'phai thu'], 'cong-no'],
  [['dong tien', 'thanh khoan', 'tien vao ra', 'du bao thu'], 'dong-tien'],
  [['kha nang chi tra', 'kham noi', 'goi vua suc'], 'kha-nang-chi-tra'],
  [['ke hoach tai chinh', 'ngan sach', 'kich ban tai chinh'], 'ke-hoach-tai-chinh'],
  [['dinh gia', 'gia goi hoc', 'muc hoc phi', 'bang gia'], 'dinh-gia'],
  [['nguy co dung', 'bo hoc', 'thoi hoc', 'nghi hoc', 'muon nghi'], 'nguy-co-dung-hoc'],
  [['lo trinh hoc', 'tu van lo trinh', 'nen hoc gi', 'hoc tu dau'], 'tu-van-lo-trinh'],
  [['cham diem', 'muc quan tam', 'gia dinh nao goi truoc'], 'cham-diem-gia-dinh'],
  [['ho so gia dinh', 'ho so 360', 'toan canh mot gia dinh', 'gia dinh nay'], 'ho-so-gia-dinh'],
  [['yeu cau ho tro', 'khieu nai', 'phan anh', 'phu huynh bao'], 'yeu-cau-ho-tro'],
  [['diem cham', 'luoi cham', 'cham soc luc nao'], 'diem-cham'],
  [['chien dich', 'tuyen sinh kenh', 'quang ba'], 'chien-dich'],
  [['soan noi dung', 'viet bai', 'viet noi dung'], 'soan-noi-dung'],
  [['gui thu', 'gui mail', 'nhan tin cho phu huynh'], 'gui-thu'],
  [['chat luong du lieu', 'ho so trung', 'trung lap', 'lam sach'], 'chat-luong-du-lieu'],
  [['rui ro', 'tuan thu', 'phap ly'], 'rui-ro-tuan-thu'],
  [['bat thuong', 'lech bat thuong', 'gian lan'], 'bat-thuong'],
  [['the diem', 'bon vien canh', 'ban do chien luoc'], 'the-diem'],
  [['hieu qua', 'dang gia bao nhieu', 'bo ra duoc gi'], 'hieu-qua'],
  [['tom tat', 'bien ban', 'buoi lam viec'], 'tom-tat'],
  [['y dinh', 'tin nhan nay muon gi'], 'y-dinh-tin-nhan'],
  [['cam xuc', 'giong cua phu huynh', 'buc xuc'], 'cam-xuc'],
  [['van hanh', 'quy trinh', 'tac o dau', 'cho lau'], 'van-hanh'],
  [['tuyen sinh'], 'tuyen-sinh-toan-canh'],
  [['toan canh', 'tong quan', 'tinh hinh chung'], 'toan-canh'],
];

const DO_TIN_TU_KHOA = 0.75;
const DO_TIN_TOI_THIEU = 0.55;

class DinhTuyen {
  /**
   * @param {object} o
   * @param {object} o.llm   LLMRouter của hệ; null thì chỉ chạy lối từ khoá
   * @param {string} o.loi   'ghep' | 'tu-khoa' | 'mo-hinh'
   */
  constructor({ llm = null, loi = 'ghep', boDem = null } = {}) {
    this.llm = llm;
    this.loi = ['ghep', 'tu-khoa', 'mo-hinh'].includes(loi) ? loi : 'ghep';
    // Bộ đệm sẵn có của hệ thống, không dựng bộ đệm thứ hai: hai bộ đệm cho
    // cùng một việc thì có hai chỗ hết hạn lệch nhau.
    this.boDem = boDem;
    this.dem = { hoiMoHinh: 0, tuBoDem: 0 };
  }

  _khoaDem(chu) { return `crm-y-dinh:${String(chu).trim().slice(0, 400)}`; }

  _soTuKhoa(chu) {
    const k = viKey(String(chu || ''));
    for (const [cum, yDinh] of TU_KHOA) {
      for (const c of cum) {
        if (k.includes(c)) return { yDinh, doTin: DO_TIN_TU_KHOA, khop: c };
      }
    }
    return null;
  }

  async _hoiMoHinh(chu) {
    if (!this.llm) return null;

    if (this.boDem) {
      try {
        const co = await this.boDem.get(this._khoaDem(chu), 'chat');
        if (co && co.value && BANG_Y_DINH[co.value.yDinh]) {
          this.dem.tuBoDem++;
          return { ...co.value, tuBoDem: true };
        }
      } catch { /* bộ đệm hỏng thì hỏi mô hình như thường, không được chặn việc */ }
    }

    this.dem.hoiMoHinh++;
    const dsY = Object.keys(BANG_Y_DINH);
    const r = await this.llm.call({
      task: 'business_analysis',
      system: 'Bạn phân loại câu hỏi nghiệp vụ. Chỉ trả về JSON, không giải thích thêm.',
      prompt: `Xếp câu hỏi sau vào ĐÚNG MỘT ý định trong danh sách.\n`
        + `Danh sách: ${dsY.join(', ')}\n`
        + `Nếu không có ý định nào hợp, trả về "khong-ro".\n\n`
        + `Câu hỏi: "${String(chu).slice(0, 500)}"\n\n`
        + `Trả về đúng dạng: {"yDinh":"<mã>","doTin":<0.0-1.0>,"viSao":"<một câu ngắn>"}`,
      temperature: 0,
      maxTokens: 200,
    });
    if (!r.ok || !r.text) return null;
    const m = String(r.text).match(/\{[\s\S]*?\}/);
    if (!m) return null;
    try {
      const j = JSON.parse(m[0]);
      if (!BANG_Y_DINH[j.yDinh]) return null;
      const doTin = Number(j.doTin);
      const kq = {
        yDinh: j.yDinh,
        doTin: Number.isFinite(doTin) ? Math.max(0, Math.min(1, doTin)) : 0.6,
        viSao: String(j.viSao || '').slice(0, 200),
        moHinh: r.provider,
      };
      // Chỉ đệm cái NHÃN, không đệm câu trả lời. Xem đầu tệp.
      if (this.boDem) {
        try { await this.boDem.set(this._khoaDem(chu), kq, 'chat'); } catch { /* bỏ qua */ }
      }
      return kq;
    } catch { return null; }
  }

  _dung(nguon, ketQua) {
    const spec = BANG_Y_DINH[ketQua.yDinh];
    const chinh = TRO_LY.get(spec.chinh);
    const phu = spec.phu.map((m) => TRO_LY.get(m)).filter(Boolean);
    return {
      doc: true,
      yDinh: ketQua.yDinh,
      nhanYDinh: spec.nhan,
      chamHocVien: spec.chamHocVien,
      troLyChinh: chinh,
      troLyPhu: phu,
      doTin: ketQua.doTin,
      nguon,
      viSao: ketQua.viSao || (ketQua.khop ? `Khớp cụm từ khoá "${ketQua.khop}".` : null),
      moHinh: ketQua.moHinh || null,
    };
  }

  _khongDoc(chu) {
    // Gợi ý ba ý định gần nhất theo số từ chung — giúp người hỏi hỏi lại được,
    // thay vì nhận một câu trả lời sai từ một trợ lý không đúng việc.
    const k = viKey(String(chu || ''));
    const tu = new Set(k.split(/\s+/).filter((t) => t.length > 2));
    const cham = TU_KHOA.map(([cum, y]) => {
      const diem = cum.reduce((t, c) => t + c.split(' ').filter((w) => tu.has(w)).length, 0);
      return { yDinh: y, diem };
    }).filter((x) => x.diem > 0).sort((a, b) => b.diem - a.diem).slice(0, 3);
    return {
      doc: false,
      yDinh: 'khong-ro',
      lyDo: 'Không xếp được câu hỏi này vào ý định nào đã khai.',
      lamGiTiepTheo: cham.length
        ? `Có phải ý là một trong: ${cham.map((c) => c.yDinh).join(', ')}?`
        : `Nêu rõ hơn việc cần làm. Hệ thống hiện đọc được ${Object.keys(BANG_Y_DINH).length} loại việc.`,
      deNghi: cham.map((c) => c.yDinh),
    };
  }

  /** Định tuyến một câu hỏi. */
  async doc(chu) {
    if (!chu || !String(chu).trim()) return this._khongDoc('');

    if (this.loi === 'tu-khoa') {
      const tk = this._soTuKhoa(chu);
      return tk ? this._dung('tu-khoa', tk) : this._khongDoc(chu);
    }

    if (this.loi === 'mo-hinh') {
      const mh = await this._hoiMoHinh(chu);
      return mh && mh.doTin >= DO_TIN_TOI_THIEU ? this._dung('mo-hinh', mh) : this._khongDoc(chu);
    }

    // Lối ghép: tất định trước.
    const tk = this._soTuKhoa(chu);
    if (tk && tk.doTin >= DO_TIN_TU_KHOA) return this._dung('tu-khoa', tk);

    const mh = await this._hoiMoHinh(chu);
    if (mh && mh.doTin >= DO_TIN_TOI_THIEU) return this._dung('mo-hinh', mh);
    if (tk) return this._dung('tu-khoa-du-phong', tk);
    return this._khongDoc(chu);
  }

  /**
   * Soi chính bảng định tuyến. Bắt được ba loại lỗi mà mắt người hay bỏ qua:
   * trỏ vào trợ lý không tồn tại, trợ lý phụ trùng trợ lý chính, và ý định
   * không có một từ khoá nào dẫn tới.
   */
  static soiBang() {
    const loi = [];
    for (const [y, spec] of Object.entries(BANG_Y_DINH)) {
      if (!TRO_LY.has(spec.chinh)) loi.push(`${y}: trợ lý chính "${spec.chinh}" không có trong sổ`);
      for (const p of spec.phu) {
        if (!TRO_LY.has(p)) loi.push(`${y}: trợ lý phụ "${p}" không có trong sổ`);
        if (p === spec.chinh) loi.push(`${y}: trợ lý phụ trùng trợ lý chính`);
      }
      if (spec.phu.length > 2) loi.push(`${y}: ${spec.phu.length} trợ lý phụ — tổ quá ba người thì tốn hơn lợi`);
    }
    const coTuKhoa = new Set(TU_KHOA.map(([, y]) => y));
    for (const y of Object.keys(BANG_Y_DINH)) {
      if (!coTuKhoa.has(y)) loi.push(`${y}: không có từ khoá nào dẫn tới — lối tất định không bao giờ chọn được`);
    }
    for (const [, y] of TU_KHOA) {
      if (!BANG_Y_DINH[y]) loi.push(`từ khoá trỏ tới ý định "${y}" không có trong bảng`);
    }
    return {
      dat: loi.length === 0, loi,
      soYDinh: Object.keys(BANG_Y_DINH).length,
      soCumTuKhoa: TU_KHOA.reduce((t, [c]) => t + c.length, 0),
      soYDinhCoNguoiPhu: Object.values(BANG_Y_DINH).filter((s) => s.phu.length).length,
    };
  }

  status() {
    const tong = this.dem.hoiMoHinh + this.dem.tuBoDem;
    return {
      loi: this.loi,
      coBoDem: !!this.boDem,
      boDem: {
        ...this.dem,
        tyLeTrungBoDem: tong ? Math.round((this.dem.tuBoDem / tong) * 100) : null,
        ghiChu: 'Chỉ đệm NHÃN Ý ĐỊNH. Câu trả lời không bao giờ được đệm, vì nó '
          + 'mang theo số liệu đọc lúc ấy.',
      },
      ...DinhTuyen.soiBang(),
    };
  }
}

module.exports = DinhTuyen;
module.exports.BANG_Y_DINH = BANG_Y_DINH;
module.exports.TU_KHOA = TU_KHOA;
