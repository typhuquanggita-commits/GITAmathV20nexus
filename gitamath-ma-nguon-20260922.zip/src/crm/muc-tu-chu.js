'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MỨC TỰ CHỦ — quyết định trợ lý được làm tới đâu trong MỘT lượt cụ thể
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Mức tự chủ ghi trong sổ trợ lý là TRẦN. Tệp này quyết định mức THẬT cho
 *  từng lượt, và mức thật không bao giờ vượt trần.
 *
 *  BỐN CẤU PHẦN CỦA ĐIỂM RỦI RO, và mỗi cấu phần trả lời một câu khác nhau:
 *
 *      tiền     · 0,35   việc này động tới bao nhiêu tiền của gia đình
 *      động chạm· 0,20   LƯỢT NÀY chạm tới đâu — không phải trợ lý này vốn
 *                        được phép tới đâu
 *      trẻ em   · 0,25   việc này có chạm dữ liệu của một đứa trẻ không
 *      ý định   · 0,20   bản thân việc muốn làm nặng tới mức nào
 *
 *  CẤU PHẦN THỨ HAI TỪNG ĐO NHẦM THỨ. Bản đầu lấy TRẦN của trợ lý: ai được
 *  phép ghi thì mọi lượt của họ đều bị cộng thêm rủi ro, kể cả lượt chỉ đọc.
 *  Hậu quả bắt được lúc kiểm: trợ lý hồ sơ toàn cảnh chỉ ĐỌC hồ sơ một gia
 *  đình cũng ra 0,403 và phải xin duyệt — mà đọc hồ sơ là việc thường ngày
 *  nhất của cả ban. Rủi ro đến từ việc lượt này LÀM GÌ, không từ việc trợ lý
 *  ấy có thể làm gì ở một lượt khác. Nay lấy mức động chạm cao nhất thật sự
 *  có trong lượt.
 *
 *  VÌ SAO TRẺ EM NẶNG HƠN TRẦN. Bản thiết kế gốc dùng trọng số 0,20 cho dữ
 *  liệu cá nhân và 0,25 cho trần tự chủ. Hệ này phục vụ trẻ em đang đi học,
 *  và dữ liệu sàng lọc tâm lý của một em nhỏ nặng hơn việc một trợ lý được
 *  phép làm gì. Nên hai con số ấy đổi chỗ cho nhau, có chủ ý.
 *
 *  HAI NGƯỠNG:
 *      ≥ 0,35  phải có người duyệt
 *      ≥ 0,90  chặn hẳn, không đưa ra hàng chờ nữa
 *
 *  HAI LUẬT ĐỨNG NGOÀI MỌI CON SỐ. Cả hai đều bỏ qua điểm rủi ro:
 *
 *    1. Việc mức 4 — chạm ra ngoài hệ thống — LUÔN phải có người duyệt.
 *    2. Việc vừa CHẠM DỮ LIỆU MỘT EM NHỎ vừa GHI hoặc GỬI — luôn phải có
 *       người duyệt. Đọc kết luận khảo sát để tư vấn thì không, vì đó là việc
 *       thường ngày và kho khảo sát đã tự chặn câu trả lời thô ở tầng dữ liệu.
 *
 *  VÌ SAO PHẢI VIẾT LUẬT 2 RA. Lúc thử, một lượt "đọc dữ liệu khảo sát của
 *  một em nhỏ" ra điểm 0,347 — tự chạy, vì ngưỡng là 0,35. Nó lọt không phải
 *  vì hệ thống đã cân nhắc và thấy nên cho qua, mà vì phép cộng tình cờ ra
 *  con số ấy. Cấu phần trẻ em có nặng tối đa cũng chỉ đóng góp 0,25, nên tự
 *  nó không bao giờ với tới ngưỡng. Nâng trọng số lên cho "đủ" thì méo mọi
 *  lượt khác. Đúng việc phải làm là nói thẳng ra luật, để lần sau ai đọc cũng
 *  thấy, thay vì để nó phụ thuộc vào một phép cộng may rủi.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round, clamp } = require('../utils');
const { MUC_PHAI_CO_NGUOI } = require('./so-tro-ly');

const TRONG_SO = { tien: 0.35, dongCham: 0.20, treEm: 0.25, yDinh: 0.20 };

const NGUONG_CAN_NGUOI = 0.35;
const NGUONG_CHAN = 0.90;

/** Ngưỡng tiền, tính bằng đồng. */
const TIEN_CAN_NGUOI = 2_000_000;      // một kỳ học phí thông thường
const TIEN_CHAN = 50_000_000;          // quá mức một giao dịch đơn lẻ của hệ này

/**
 * Bảng ý định. Con số là mức nặng của chính việc ấy, không phụ thuộc ai làm.
 * Ý định không có trong bảng thì lấy 0,30 — không phải 0, vì việc lạ thì đáng
 * ngờ hơn việc quen, chứ không phải ít đáng ngờ hơn.
 */
const Y_DINH = {
  xoa: 1.00,
  doi_hoc_phi: 0.80,
  gui_ra_ngoai: 0.70,
  chot_ghi_danh: 0.70,
  sua_ho_so: 0.50,
  nhac_hoc_phi: 0.45,
  soan_thao: 0.30,
  cham_diem: 0.25,
  du_bao: 0.15,
  phan_tich: 0.15,
  tra_cuu: 0.10,
  ghi_nhat_ky: 0.05,
};
const Y_DINH_MAC_DINH = 0.30;

/** Năng lực chạm tới dữ liệu trẻ em. */
const CHAM_TRE_EM = new Set([
  'doi-chieu-khao-sat', 'dung-lo-trinh', 'ghep-ho-so', 'doc-dau-hieu-truot',
  'de-xuat-lo-trinh', 'giai-thich-cho-phu-huynh', 'de-xuat-can-thiep',
]);

class MucTuChu {
  constructor({ nguongCanNguoi = NGUONG_CAN_NGUOI, nguongChan = NGUONG_CHAN } = {}) {
    this.nguongCanNguoi = nguongCanNguoi;
    this.nguongChan = nguongChan;
  }

  _rrTien(soTien) {
    const t = Number(soTien) || 0;
    if (t <= 0) return 0;
    if (t >= TIEN_CHAN) return 1;
    if (t >= TIEN_CAN_NGUOI) return 0.5 + ((t - TIEN_CAN_NGUOI) / (TIEN_CHAN - TIEN_CAN_NGUOI)) * 0.5;
    return (t / TIEN_CAN_NGUOI) * 0.5;
  }

  /**
   * Mức động chạm của LƯỢT NÀY: lấy mức cao nhất trong các công cụ có mặt.
   * Không có công cụ nào thì lùi về trần của trợ lý, vì lúc ấy không còn gì
   * khác để căn cứ.
   */
  _rrDongCham(mucCongCu, tranTuChu) {
    const ds = (mucCongCu || []).map(Number).filter(Number.isFinite);
    const cao = ds.length ? Math.max(...ds) : Number(tranTuChu);
    return clamp((cao - 1) / 3, 0, 1);
  }

  _rrTreEm(nangLuc, chamHocVien) {
    if (chamHocVien === true) return 1;
    if (!Array.isArray(nangLuc) || !nangLuc.length) return 0.3;
    const trung = nangLuc.filter((n) => CHAM_TRE_EM.has(n)).length;
    return trung ? clamp(0.5 + trung * 0.25, 0, 1) : 0.1;
  }

  _rrYDinh(yDinh) {
    if (!yDinh) return Y_DINH_MAC_DINH;
    return Y_DINH[yDinh] != null ? Y_DINH[yDinh] : Y_DINH_MAC_DINH;
  }

  /**
   * Cân một lượt.
   * @param {object} o
   * @param {object} o.troLy       bản ghi trợ lý trong sổ
   * @param {string} o.yDinh       nhãn ý định
   * @param {number} o.soTien      số tiền việc này động tới, 0 nếu không
   * @param {boolean} o.chamHocVien  việc này có đọc dữ liệu học viên không
   * @param {number[]} o.mucCongCu   mức động chạm của các công cụ sẽ dùng
   */
  can({ troLy, yDinh = null, soTien = 0, chamHocVien = false, mucCongCu = [] } = {}) {
    if (!troLy) throw new Error('MucTuChu.can cần một trợ lý');

    const phan = {
      tien: this._rrTien(soTien),
      dongCham: this._rrDongCham(mucCongCu, troLy.tuChuToiDa),
      treEm: this._rrTreEm(troLy.nangLuc, chamHocVien),
      yDinh: this._rrYDinh(yDinh),
    };
    const diem = clamp(
      TRONG_SO.tien * phan.tien
      + TRONG_SO.dongCham * phan.dongCham
      + TRONG_SO.treEm * phan.treEm
      + TRONG_SO.yDinh * phan.yDinh,
      0, 1,
    );

    // Hai luật đứng ngoài mọi con số.
    const coViecRaNgoai = (mucCongCu || []).some((m) => Number(m) >= MUC_PHAI_CO_NGUOI);
    const coViecGhi = (mucCongCu || []).some((m) => Number(m) >= 3);
    const chamTreEmVaGhi = chamHocVien === true && (coViecGhi || coViecRaNgoai);

    if (diem >= this.nguongChan) {
      return {
        choLam: false, mucThat: 1, canNguoi: true,
        diem: round(diem, 3), phan: this._lamTron(phan),
        lyDo: `Điểm rủi ro ${round(diem, 2)} vượt ngưỡng chặn ${this.nguongChan}.`,
        nhan: 'chan',
      };
    }

    const canNguoi = coViecRaNgoai || chamTreEmVaGhi || diem >= this.nguongCanNguoi;
    // Cần người thì mức thật tụt xuống 3: trợ lý vẫn làm được mọi việc trong
    // nhà, chỉ dừng đúng ở bậc thềm.
    const mucThat = canNguoi ? Math.min(troLy.tuChuToiDa, 3) : troLy.tuChuToiDa;

    return {
      choLam: true, mucThat, canNguoi,
      diem: round(diem, 3), phan: this._lamTron(phan),
      lyDo: coViecRaNgoai
        ? 'Lượt này có việc chạm ra ngoài hệ thống — luôn phải có người duyệt.'
        : chamTreEmVaGhi
          ? 'Lượt này vừa chạm dữ liệu một em nhỏ vừa ghi — luôn phải có người duyệt.'
          : canNguoi
            ? `Điểm rủi ro ${round(diem, 2)} vượt ngưỡng cần người ${this.nguongCanNguoi}.`
            : `Điểm rủi ro ${round(diem, 2)} dưới ngưỡng cần người.`,
      nhan: canNguoi ? 'can-nguoi' : 'tu-lam',
    };
  }

  _lamTron(p) {
    return Object.fromEntries(Object.entries(p).map(([k, v]) => [k, round(v, 3)]));
  }

  status() {
    return {
      trongSo: TRONG_SO,
      nguongCanNguoi: this.nguongCanNguoi,
      nguongChan: this.nguongChan,
      nguongTienCanNguoi: TIEN_CAN_NGUOI,
      nguongTienChan: TIEN_CHAN,
      soYDinhDaKhai: Object.keys(Y_DINH).length,
      luatCung: [
        'Việc mức 4 (chạm ra ngoài hệ thống) luôn phải có người duyệt.',
        'Việc vừa chạm dữ liệu một em nhỏ vừa ghi hoặc gửi luôn phải có người duyệt.',
      ],
    };
  }
}

module.exports = MucTuChu;
module.exports.TRONG_SO = TRONG_SO;
module.exports.Y_DINH = Y_DINH;
module.exports.CHAM_TRE_EM = CHAM_TRE_EM;
module.exports.NGUONG_CAN_NGUOI = NGUONG_CAN_NGUOI;
module.exports.NGUONG_CHAN = NGUONG_CHAN;
