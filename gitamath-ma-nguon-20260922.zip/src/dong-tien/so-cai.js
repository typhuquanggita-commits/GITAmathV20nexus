'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SỔ CÁI DÒNG TIỀN — ghi, chặn, và nói thật về chỗ chưa biết
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  NÓI TRƯỚC CHỖ HỆ THỐNG KHÔNG BIẾT, vì một sổ cái giấu chỗ trống thì nguy
 *  hiểm hơn không có sổ cái:
 *
 *    · DOANH THU — hệ thống CHƯA nối dữ liệu thanh toán nào. Không biết gia
 *      đình nào đã đóng bao nhiêu, gói nào, kỳ hạn nào. Mọi con số doanh thu
 *      xuất hiện ở đây sẽ là bịa, nên không có con số nào.
 *    · CHI PHÍ NGƯỜI — lương, thuê ngoài, hạ tầng: chưa nối.
 *    · CHI PHÍ MÔ HÌNH — có đo được, nhưng đang là ƯỚC LƯỢNG chứ không phải
 *      hoá đơn. Bảng giá dưới đây phải được cập nhật tay theo bảng giá thật
 *      của nhà cung cấp, và sổ cái ghi rõ ngày cập nhật gần nhất.
 *
 *  BỐN MỨC TIN CẬY, ghi kèm MỌI khoản:
 *      hoa-don    có hoá đơn hoặc sao kê đối chiếu được
 *      do-duoc    hệ thống tự đếm được (số token, số lần gọi)
 *      uoc-luong  suy từ số đo qua một bảng giá có thể lỗi thời
 *      chua-co    chưa nối nguồn — KHÔNG có số, chỉ có tên khoản
 *
 *  CÁI LÀM SỔ NÀY CÓ RĂNG: ngân sách CỨNG. Vượt trần là CHẶN, không phải cảnh
 *  báo rồi vẫn tiêu. Một hệ thống 500 trợ lý AI gọi mô hình trong vòng lặp có
 *  thể đốt sạch ngân sách tháng trong một đêm, và cảnh báo gửi lúc 3 giờ sáng
 *  thì không ai đọc.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');

const TIN_CAY = ['hoa-don', 'do-duoc', 'uoc-luong', 'chua-co'];

/**
 * Bảng giá mô hình, USD cho một triệu token.
 *
 * ĐÂY LÀ BẢNG PHẢI CẬP NHẬT TAY. Nhà cung cấp đổi giá thì con số ở đây sai, và
 * sai theo hướng nguy hiểm: ngân sách tưởng còn mà thật ra đã hết. Trường
 * `capNhat` được in kèm mọi báo cáo để không ai quên.
 */
const BANG_GIA = {
  capNhat: '2026-09-19',
  nguon: 'Nhập tay từ bảng giá công bố của nhà cung cấp. Đối chiếu lại mỗi quý.',
  moi: {
    // vao = token đầu vào, ra = token đầu ra
    'fast': { vao: 0.80, ra: 4.00 },
    'balanced': { vao: 3.00, ra: 15.00 },
    'strong': { vao: 15.00, ra: 75.00 },
    'mock': { vao: 0, ra: 0 },
  },
};

/** Các khoản mục của dòng tiền, kèm mức tin cậy hiện tại. */
const KHOAN = [
  {
    ma: 'MO_HINH', ten: 'Chi phí gọi mô hình ngôn ngữ', chieu: 'chi',
    tinCay: 'uoc-luong',
    nguon: 'Đếm token thật × bảng giá nhập tay',
    thieu: 'Chưa đối chiếu với hoá đơn nhà cung cấp. Lệch giá là lệch toàn bộ con số.',
  },
  {
    ma: 'GIONG_NOI', ten: 'Chi phí tổng hợp giọng nói', chieu: 'chi',
    tinCay: 'do-duoc',
    nguon: 'Đếm số giây âm thanh đã dựng',
    thieu: 'Giọng dựng bằng mã nội bộ nên chi phí bằng 0; dùng nhà cung cấp ngoài thì phải nối giá vào đây.',
  },
  {
    ma: 'DOANH_THU', ten: 'Doanh thu từ gia đình', chieu: 'thu',
    tinCay: 'chua-co',
    nguon: null,
    thieu: 'CHƯA nối dữ liệu thanh toán. Không biết gia đình nào đóng bao nhiêu, gói gì, kỳ hạn nào. '
      + 'Mọi báo cáo lợi nhuận đều KHÔNG dựng được cho tới khi nối xong.',
  },
  {
    ma: 'NHAN_SU', ten: 'Chi phí con người', chieu: 'chi',
    tinCay: 'chua-co',
    nguon: null,
    thieu: 'CHƯA nối bảng lương và hợp đồng thuê ngoài.',
  },
  {
    ma: 'HA_TANG', ten: 'Chi phí hạ tầng', chieu: 'chi',
    tinCay: 'chua-co',
    nguon: null,
    thieu: 'CHƯA nối hoá đơn máy chủ, lưu trữ, băng thông.',
  },
];

const KHOAN_INDEX = new Map(KHOAN.map((k) => [k.ma, k]));

/** Ngân sách mặc định, USD. Đặt qua biến môi trường khi vận hành thật. */
const NGAN_SACH_MAC_DINH = {
  ngay: Number(process.env.NGAN_SACH_NGAY_USD || 5),
  thang: Number(process.env.NGAN_SACH_THANG_USD || 100),
  // Chạm ngưỡng này thì cảnh báo, chưa chặn.
  nguongCanhBao: 0.8,
};

const NGAY = 86400000;
const ngayCua = (t) => new Date(t).toISOString().slice(0, 10);
const thangCua = (t) => new Date(t).toISOString().slice(0, 7);

class SoCai {
  /** @param {object} o {repo, nganSach, bayGio} */
  constructor({ repo = null, nganSach = null, bayGio = () => Date.now() } = {}) {
    if (repo) {
      const can = ['put', 'filter', 'delete', 'count'];
      const thieu = can.filter((m) => typeof repo[m] !== 'function');
      if (thieu.length) throw new Error(`SoCai: kho bền vững thiếu ${thieu.join(', ')}`);
    }
    this.repo = repo;
    this.trongBoNho = [];
    this.nganSach = { ...NGAN_SACH_MAC_DINH, ...(nganSach || {}) };
    this.bayGio = bayGio;
    this.stats = { ghi: 0, chan: 0, canhBao: 0 };
  }

  _tatCa() { return this.repo ? this.repo.filter(() => true) : this.trongBoNho; }

  /** Quy token ra USD theo bảng giá. Trả kèm mức tin cậy, không trả số trần trụi. */
  quyRaTien({ bac = 'balanced', tokenVao = 0, tokenRa = 0 } = {}) {
    const g = BANG_GIA.moi[bac] || BANG_GIA.moi.balanced;
    const usd = round((tokenVao / 1e6) * g.vao + (tokenRa / 1e6) * g.ra, 6);
    return {
      usd, bac, tokenVao, tokenRa,
      tinCay: 'uoc-luong',
      bangGiaCapNhat: BANG_GIA.capNhat,
      ghiChu: `Ước lượng theo bảng giá cập nhật ${BANG_GIA.capNhat}. Không phải hoá đơn.`,
    };
  }

  /**
   * Ghi một khoản. Khoản nào thuộc nhóm 'chua-co' thì TỪ CHỐI ghi số — vì ghi
   * một con số vào chỗ chưa có nguồn là bịa sổ.
   */
  ghi({ khoan, usd = 0, chiTiet = null, boi = 'he-thong', luc = null } = {}) {
    const k = KHOAN_INDEX.get(khoan);
    if (!k) return { ok: false, error: 'KHÔNG_CÓ_KHOẢN_NÀY', khoan };
    if (k.tinCay === 'chua-co') {
      return {
        ok: false, error: 'KHOẢN_CHƯA_CÓ_NGUỒN',
        reason: `${k.ten}: ${k.thieu} Ghi một con số vào đây là bịa sổ.`,
      };
    }
    const so = Number(usd);
    if (!Number.isFinite(so) || so < 0) return { ok: false, error: 'SỐ_TIỀN_KHÔNG_HỢP_LỆ', usd };

    const t = luc || this.bayGio();
    const ban = {
      id: `SC-${khoan}-${t}-${Math.abs(this._bam(JSON.stringify(chiTiet || {}) + t)).toString(36)}`,
      khoan, chieu: k.chieu, usd: round(so, 6),
      tinCay: k.tinCay, luc: t, ngay: ngayCua(t), thang: thangCua(t),
      boi, chiTiet,
    };
    if (this.repo) this.repo.put(ban); else this.trongBoNho.push(ban);
    this.stats.ghi++;
    return { ok: true, id: ban.id, usd: ban.usd, tinCay: ban.tinCay };
  }

  _bam(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) { h = ((h << 5) - h + s.charCodeAt(i)) | 0; }
    return h;
  }

  /** Tổng chi trong một ngày và một tháng. */
  tong({ luc = null } = {}) {
    const t = luc || this.bayGio();
    const ng = ngayCua(t);
    const th = thangCua(t);
    let ngay = 0;
    let thang = 0;
    for (const b of this._tatCa()) {
      if (b.chieu !== 'chi') continue;
      if (b.thang === th) thang += b.usd;
      if (b.ngay === ng) ngay += b.usd;
    }
    return { ngay: round(ngay, 6), thang: round(thang, 6), moc: { ngay: ng, thang: th } };
  }

  /**
   * CỬA NGÂN SÁCH — hỏi TRƯỚC khi tiêu, không báo sau khi đã tiêu.
   *
   * Trả về {ok:false} thì bên gọi PHẢI dừng. Đây là chỗ biến sổ cái từ một
   * bảng số thành một cái phanh.
   */
  xinTieu({ usd = 0, khoan = 'MO_HINH', luc = null } = {}) {
    const so = Number(usd) || 0;
    const t = luc || this.bayGio();
    const tg = this.tong({ luc: t });
    const sauNgay = tg.ngay + so;
    const sauThang = tg.thang + so;

    if (sauNgay > this.nganSach.ngay) {
      this.stats.chan++;
      return {
        ok: false, error: 'VƯỢT_NGÂN_SÁCH_NGÀY',
        reason: `Chi hôm nay ${round(tg.ngay, 4)} USD, khoản này thêm ${round(so, 4)} USD `
          + `sẽ vượt trần ngày ${this.nganSach.ngay} USD.`,
        daTieu: tg, tran: this.nganSach,
      };
    }
    if (sauThang > this.nganSach.thang) {
      this.stats.chan++;
      return {
        ok: false, error: 'VƯỢT_NGÂN_SÁCH_THÁNG',
        reason: `Chi tháng này ${round(tg.thang, 4)} USD, khoản này thêm ${round(so, 4)} USD `
          + `sẽ vượt trần tháng ${this.nganSach.thang} USD.`,
        daTieu: tg, tran: this.nganSach,
      };
    }
    const canhBao = [];
    if (sauNgay > this.nganSach.ngay * this.nganSach.nguongCanhBao) canhBao.push('ngày');
    if (sauThang > this.nganSach.thang * this.nganSach.nguongCanhBao) canhBao.push('tháng');
    if (canhBao.length) this.stats.canhBao++;
    return { ok: true, conLai: { ngay: round(this.nganSach.ngay - sauNgay, 6), thang: round(this.nganSach.thang - sauThang, 6) }, canhBao, khoan };
  }

  /**
   * Biên bản dòng tiền. Phần QUAN TRỌNG NHẤT là danh sách khoản CHƯA CÓ NGUỒN
   * — nó nằm ngay đầu, không nằm ở chú thích cuối trang.
   */
  bienBan({ luc = null } = {}) {
    const t = luc || this.bayGio();
    const tg = this.tong({ luc: t });
    const theoKhoan = {};
    for (const b of this._tatCa()) {
      if (b.thang !== tg.moc.thang) continue;
      theoKhoan[b.khoan] = round((theoKhoan[b.khoan] || 0) + b.usd, 6);
    }
    const chuaCo = KHOAN.filter((k) => k.tinCay === 'chua-co');
    const doDuoc = KHOAN.filter((k) => k.tinCay !== 'chua-co');
    return {
      luc: t,
      bangGia: { capNhat: BANG_GIA.capNhat, nguon: BANG_GIA.nguon },
      // Nói chỗ mù TRƯỚC, rồi mới tới con số.
      chuaCoNguon: chuaCo.map((k) => ({ ma: k.ma, ten: k.ten, chieu: k.chieu, thieu: k.thieu })),
      doDuoc: doDuoc.map((k) => ({
        ma: k.ma, ten: k.ten, chieu: k.chieu, tinCay: k.tinCay,
        thangNay: theoKhoan[k.ma] || 0, thieu: k.thieu,
      })),
      tong: tg,
      nganSach: this.nganSach,
      conLai: { ngay: round(this.nganSach.ngay - tg.ngay, 6), thang: round(this.nganSach.thang - tg.thang, 6) },
      ketLuan: chuaCo.length
        ? `KHÔNG dựng được báo cáo lợi nhuận: ${chuaCo.length}/${KHOAN.length} khoản chưa nối nguồn `
          + `(${chuaCo.map((k) => k.ten).join(', ')}). Sổ này hiện chỉ theo dõi được CHI PHÍ VẬN HÀNH.`
        : 'Mọi khoản đều có nguồn.',
      canhBao: tg.thang > this.nganSach.thang * this.nganSach.nguongCanhBao
        ? `Đã dùng ${Math.round(tg.thang / this.nganSach.thang * 100)}% ngân sách tháng.` : null,
    };
  }

  status() {
    return {
      banGhi: this._tatCa().length, ...this.stats,
      benVung: !!this.repo,
      banGhiTrenDia: this.repo ? this.repo.count() : 0,
      nganSach: this.nganSach,
    };
  }
}

module.exports = SoCai;
module.exports.KHOAN = KHOAN;
module.exports.BANG_GIA = BANG_GIA;
module.exports.TIN_CAY = TIN_CAY;
module.exports.NGAN_SACH_MAC_DINH = NGAN_SACH_MAC_DINH;
