'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  NĂM HỆ CHUẨN — SỐ LIỆU LẤY TỪ TÀI LIỆU GỐC, KHÔNG ƯỚC LƯỢNG
 * ═══════════════════════════════════════════════════════════════════════════
 *  Cấu trúc từng kỳ thi dưới đây chép đúng từ bộ tài liệu đặc tả của hệ thống
 *  (HSA 1300, TSA 100, SAT 1600, IELTS 9.0 và phần SPT nằm trong tài liệu
 *  TSA). Số câu, số phút và trọng số là dữ kiện, không phải ước lượng — nên
 *  chúng nằm ở một chỗ duy nhất và có kiểm thử giữ.
 *
 *  PHÁT HIỆN QUAN TRỌNG KHI ĐỌC CẢ NĂM TÀI LIỆU:
 *  Cả năm hệ chuẩn đều chia trình độ thành ĐÚNG MƯỜI NẤC, và mười nấc ấy
 *  mang cùng một tên gọi theo cùng một thứ tự: Foundation, Emerging,
 *  Developing, Intermediate, Proficient, Advanced, Highly Proficient, Elite,
 *  nấc thứ chín tuỳ hệ, rồi Perfect.
 *
 *  Mười tầng năng lực mà hệ thống đang dùng (Khởi động → Đỉnh cao) cũng đúng
 *  mười nấc. Nghĩa là KHÔNG CẦN dựng thang thứ hai: tầng của hệ thống chính
 *  là xương sống, và mỗi hệ chuẩn chỉ là một cách quy đổi tầng ấy ra đồng
 *  tiền riêng của nó. Đây là điều làm ma trận đa tầng đứng được — nếu mỗi hệ
 *  một thang riêng thì không có phép so nào giữa chúng có nghĩa.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/** Tên chung của mười nấc, dùng cho mọi hệ chuẩn. */
const TEN_NAC = [
  'Foundation', 'Emerging', 'Developing', 'Intermediate', 'Proficient',
  'Advanced', 'Highly Proficient', 'Elite', 'Top-National', 'Perfect',
];

/**
 * Năm hệ chuẩn.
 *   thang   : [thấp nhất, cao nhất] của điểm hệ đó
 *   nac     : mười mốc điểm, nấc thứ i ứng với tầng i của hệ thống
 *   phan    : các phần thi, kèm số câu, số phút và trọng số nếu hệ có khai
 *   monChinh: hệ này đo môn nào — quyết định dạng bài nào được tính vào
 */
const CHUAN = [
  {
    id: 'hsa',
    ten: 'HSA — Đánh giá năng lực Đại học Quốc gia Hà Nội',
    ngan: 'HSA 1300',
    thang: [150, 1300],
    monChinh: ['toan', 'ngu-van', 'khoa-hoc', 'tieng-anh'],
    // Tài liệu gốc ghi TỔNG là một KHOẢNG (150–200 câu, 195–255 phút) vì phần
    // tự chọn thay đổi theo lựa chọn của thí sinh. Ghi đúng khoảng thay vì
    // chọn một đầu — chọn một đầu là làm mất thông tin có thật trong nguồn.
    tongCau: [150, 200],
    tongPhut: [195, 255],
    nac: [
      [150, 350], [350, 500], [500, 650], [650, 800], [800, 900],
      [900, 1000], [1000, 1100], [1100, 1200], [1200, 1280], [1280, 1300],
    ],
    phan: [
      { id: 'p1-toan', ten: 'Toán học và xử lý số liệu', cau: 50, phut: 75, mon: 'toan' },
      { id: 'p2-ngu-van', ten: 'Ngôn ngữ và văn học', cau: 50, phut: 60, mon: 'ngu-van' },
      { id: 'p3-khoa-hoc', ten: 'Khoa học tự nhiên', cau: 50, phut: 60, mon: 'khoa-hoc' },
      { id: 'p4-tu-chon', ten: 'Tự chọn: tiếng Anh hoặc Sử và Địa', cau: 50, phut: 60, mon: 'tieng-anh' },
    ],
  },
  {
    id: 'tsa',
    ten: 'TSA — Đánh giá tư duy Đại học Bách khoa Hà Nội',
    ngan: 'TSA 100',
    thang: [0, 100],
    monChinh: ['toan', 'doc-hieu', 'khoa-hoc', 'tieng-anh'],
    tongCau: 80,
    tongPhut: 130,
    nac: [
      [0, 20], [20, 30], [30, 40], [40, 50], [50, 60],
      [60, 70], [70, 80], [80, 90], [90, 98], [98, 100],
    ],
    phan: [
      { id: 'p1-toan-logic', ten: 'Toán học và tư duy logic', cau: 20, phut: 40, mon: 'toan' },
      { id: 'p2-doc-hieu', ten: 'Đọc hiểu', cau: 20, phut: 30, mon: 'doc-hieu' },
      { id: 'p3-khoa-hoc', ten: 'Khoa học tự nhiên', cau: 20, phut: 30, mon: 'khoa-hoc' },
      { id: 'p4-tieng-anh', ten: 'Tiếng Anh', cau: 20, phut: 30, mon: 'tieng-anh' },
    ],
  },
  {
    id: 'spt',
    ten: 'SPT — Đánh giá năng lực chuyên biệt Đại học Quốc gia Thành phố Hồ Chí Minh',
    ngan: 'SPT 1200',
    thang: [0, 1200],
    monChinh: ['toan', 'tieng-anh', 'khoa-hoc', 'xa-hoi'],
    tongCau: 160,
    tongPhut: 250,
    nac: [
      [0, 200], [200, 400], [400, 550], [550, 700], [700, 800],
      [800, 900], [900, 960], [960, 1000], [1000, 1120], [1120, 1200],
    ],
    phan: [
      { id: 'math_logic', ten: 'Toán và tư duy logic', cau: 30, phut: 75, trongSo: 0.30, mon: 'toan' },
      { id: 'english', ten: 'Tiếng Anh', cau: 40, phut: 60, trongSo: 0.25, mon: 'tieng-anh' },
      { id: 'science', ten: 'Khoa học tự nhiên', cau: 50, phut: 65, trongSo: 0.25, mon: 'khoa-hoc' },
      { id: 'social', ten: 'Khoa học xã hội', cau: 40, phut: 50, trongSo: 0.20, mon: 'xa-hoi' },
    ],
  },
  {
    id: 'sat',
    ten: 'SAT — Digital SAT theo chuẩn College Board',
    ngan: 'SAT 1600',
    thang: [400, 1600],
    monChinh: ['toan', 'tieng-anh'],
    tongCau: 98,
    tongPhut: 134,
    nac: [
      [400, 600], [600, 750], [750, 900], [900, 1050], [1050, 1200],
      [1200, 1300], [1300, 1400], [1400, 1480], [1480, 1560], [1560, 1600],
    ],
    phan: [
      { id: 'rw', ten: 'Reading and Writing', cau: 54, phut: 64, mon: 'tieng-anh' },
      { id: 'math', ten: 'Math', cau: 44, phut: 70, mon: 'toan' },
    ],
    // Digital SAT chấm thích ứng: làm tốt mô-đun một thì mô-đun hai khó hơn
    // và trần điểm cao hơn. Ghi lại vì nó đổi cách dựng đề thử, không chỉ đổi
    // cách chấm.
    thichUng: true,
  },
  {
    id: 'ielts',
    ten: 'IELTS — chuẩn Academic bốn kỹ năng',
    ngan: 'IELTS 9.0',
    thang: [0, 9],
    monChinh: ['tieng-anh'],
    // Writing và Speaking tính theo BÀI chứ không theo câu, nên tổng câu của
    // IELTS không cùng đơn vị với bốn hệ kia. Vẫn ghi ra để phép tự kiểm cộng
    // lại được, kèm chú thích để không ai đem so thẳng với HSA hay SAT.
    tongCau: 85,
    tongPhut: 165,
    donViCau: 'Listening và Reading tính theo câu; Writing và Speaking tính theo bài',
    nac: [
      [0, 3.5], [3.5, 4.5], [4.5, 5], [5, 5.5], [5.5, 6],
      [6, 6.5], [6.5, 7], [7, 7.5], [7.5, 8.5], [8.5, 9],
    ],
    phan: [
      { id: 'listening', ten: 'Listening — bốn phần', cau: 40, phut: 30, mon: 'tieng-anh', kyNang: 'nghe' },
      { id: 'reading', ten: 'Reading — ba bài đọc', cau: 40, phut: 60, mon: 'tieng-anh', kyNang: 'doc' },
      { id: 'writing', ten: 'Writing — Task 1 và Task 2', cau: 2, phut: 60, mon: 'tieng-anh', kyNang: 'viet' },
      { id: 'speaking', ten: 'Speaking — ba phần', cau: 3, phut: 15, mon: 'tieng-anh', kyNang: 'noi' },
    ],
    // Bốn tiêu chí chấm chính thức của Writing và Speaking. Ghi ra để bộ chấm
    // bám đúng tiêu chí chứ không tự nghĩ ra thang riêng.
    tieuChiCham: {
      viet: ['Task Achievement', 'Coherence and Cohesion', 'Lexical Resource', 'Grammatical Range and Accuracy'],
      noi: ['Fluency and Coherence', 'Lexical Resource', 'Grammatical Range and Accuracy', 'Pronunciation'],
    },
  },
];

const CHUAN_INDEX = new Map(CHUAN.map((c) => [c.id, c]));

/**
 * Sáu bậc CEFR cho tiếng Anh nền, lớp 1 đến lớp 12.
 * CEFR không phải kỳ thi mà là thang mô tả năng lực, nên để riêng: nó gắn vào
 * LỚP HỌC chứ không gắn vào một bài thi nào.
 */
const CEFR = [
  { id: 'a1', ten: 'A1 · Beginner', gio: 100, tuVung: 500, lop: [1, 3] },
  { id: 'a2', ten: 'A2 · Elementary', gio: 150, tuVung: 1000, lop: [3, 5] },
  { id: 'b1', ten: 'B1 · Intermediate', gio: 200, tuVung: 2000, lop: [6, 8] },
  { id: 'b2', ten: 'B2 · Upper-Intermediate', gio: 250, tuVung: 3500, lop: [9, 10] },
  { id: 'c1', ten: 'C1 · Advanced', gio: 300, tuVung: 5000, lop: [11, 12] },
  { id: 'c2', ten: 'C2 · Mastery', gio: 300, tuVung: 8000, lop: [12, 12] },
];

const CEFR_INDEX = new Map(CEFR.map((c) => [c.id, c]));

/** Bậc CEFR ứng với một lớp phổ thông. */
function cefrCuaLop(lop) {
  const n = Number(lop);
  return CEFR.find((c) => n >= c.lop[0] && n <= c.lop[1]) || null;
}

/**
 * Quy đổi tầng năng lực (0–9) ra khoảng điểm của một hệ chuẩn.
 * Trả về khoảng chứ không trả một con số: hệ thống biết học viên ở tầng nào,
 * không biết chính xác học viên sẽ được bao nhiêu điểm. Nói một con số đơn lẻ
 * là hứa thứ mình không đo được.
 */
function diemTheoTang(chuanId, tang) {
  const c = CHUAN_INDEX.get(chuanId);
  const t = Number(tang);
  if (!c || !Number.isInteger(t) || t < 0 || t > 9) return null;
  const [tu, den] = c.nac[t];
  return { chuanId, tang, tu, den, tenNac: TEN_NAC[t], thang: c.thang };
}

/**
 * Chiều ngược lại: có điểm thật của một kỳ thi thì suy ra tầng.
 * Dùng khi học viên mang điểm thi thật tới — lúc đó điểm thật thắng mọi ước
 * lượng của hệ thống.
 */
function tangTheoDiem(chuanId, diem) {
  const c = CHUAN_INDEX.get(chuanId);
  const d = Number(diem);
  if (!c || !Number.isFinite(d)) return null;
  for (let i = c.nac.length - 1; i >= 0; i--) {
    if (d >= c.nac[i][0]) return { chuanId, tang: i, tenNac: TEN_NAC[i], diem: d };
  }
  return { chuanId, tang: 0, tenNac: TEN_NAC[0], diem: d };
}

/**
 * Tổng số câu và số phút của một hệ, TÍNH LẠI từ các phần.
 *
 * Có hàm này để bắt lệch giữa con số tổng đã khai và tổng thật của các phần.
 * Lệch như vậy là loại lỗi âm thầm nhất trong dữ liệu đặc tả: không ai để ý,
 * nhưng mọi phép quy đổi dựa lên nó đều sai theo.
 */
function tongCua(chuanId) {
  const c = CHUAN_INDEX.get(chuanId);
  if (!c) return null;
  const cau = c.phan.reduce((s, p) => s + (p.cau || 0), 0);
  const phut = c.phan.reduce((s, p) => s + (p.phut || 0), 0);
  const trong = (khai, that) => (Array.isArray(khai)
    ? that >= khai[0] && that <= khai[1]
    : khai === that);
  return {
    cau,
    phut,
    khopCau: trong(c.tongCau, cau),
    khopPhut: trong(c.tongPhut, phut),
  };
}

module.exports = {
  CHUAN, CHUAN_INDEX, TEN_NAC, CEFR, CEFR_INDEX,
  cefrCuaLop, diemTheoTang, tangTheoDiem, tongCua,
};
