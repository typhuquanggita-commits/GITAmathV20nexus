'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  THẨM ĐỊNH TOÁN HỌC — không tin lời mô hình, chỉ tin phép tính
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mô hình sinh ra đề và đáp án. Trước khi bất kỳ bài nào được đưa cho học
 *  viên, bộ này TỰ GIẢI hoặc TỰ ĐỐI CHIẾU bằng số học, rồi mới kết luận.
 *
 *  · Hai biểu thức có bằng nhau không: thử ở nhiều điểm lấy mẫu TẤT ĐỊNH
 *    (mulberry32 có seed), cả số nguyên lẫn số lẻ, cả âm lẫn dương.
 *  · Phương trình bậc nhất / bậc hai: giải chính xác, đối chiếu tập nghiệm.
 *  · Nghiệm do mô hình đưa ra: thay ngược vào phương trình gốc.
 *  · Đáp án dạng tập, khoảng, bất phương trình: so bằng cách lấy mẫu miền.
 *
 *  Mọi kết luận đều kèm BẰNG CHỨNG (điểm thử, sai số) để người thật soát lại.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { parse, evaluate, variables, stringify, latexToPlain } = require('./expression');
const { seededRandom, round } = require('../utils');

const EPS = 1e-7;
const SAMPLES = 24;

/** Điểm lấy mẫu tất định: có số nguyên nhỏ, số lẻ, âm, dương, gần 0 và xa 0. */
function samplePoints(n = SAMPLES, seed = 'gita-verifier') {
  const rnd = seededRandom(seed);
  const fixed = [1, 2, 3, -1, -2, 0.5, -0.5, 1.5, 4, -3, 7, 10];
  const out = fixed.slice(0, Math.min(n, fixed.length));
  while (out.length < n) {
    const v = round((rnd() * 20 - 10), 4);
    if (Math.abs(v) > 1e-3) out.push(v);
  }
  return out;
}

function near(a, b, tol = EPS) {
  if (Number.isNaN(a) || Number.isNaN(b)) return false;
  if (!Number.isFinite(a) || !Number.isFinite(b)) return a === b;
  return Math.abs(a - b) <= tol * Math.max(1, Math.abs(a), Math.abs(b));
}

class MathVerifier {
  constructor({ seed = 'gita-verifier' } = {}) {
    this.seed = seed;
    this.stats = { checks: 0, passed: 0, failed: 0, unparsable: 0, equations: 0, substitutions: 0 };
  }

  // ── 1. So hai biểu thức ──────────────────────────────────────────────────

  /**
   * Hai biểu thức có đồng nhất bằng nhau không.
   * @returns {{ok, equal, reason, tested, mismatch?, evidence}}
   */
  equivalent(exprA, exprB, { vars = null, points = SAMPLES, domain = null } = {}) {
    this.stats.checks++;
    let A, B;
    try { A = parse(exprA); } catch (e) { this.stats.unparsable++; return { ok: false, error: 'PARSE_ERROR', side: 'A', message: e.message, input: String(exprA) }; }
    try { B = parse(exprB); } catch (e) { this.stats.unparsable++; return { ok: false, error: 'PARSE_ERROR', side: 'B', message: e.message, input: String(exprB) }; }

    const varsA = [...variables(A)];
    const varsB = [...variables(B)];
    const all = vars || [...new Set([...varsA, ...varsB])].sort();

    if (!all.length) {
      const a = evaluate(A, {});
      const b = evaluate(B, {});
      const equal = near(a, b);
      this[equal ? '_pass' : '_fail']();
      return {
        ok: true, equal, tested: 1,
        reason: equal ? 'Hai vế cho cùng một giá trị' : `Khác nhau: ${a} ≠ ${b}`,
        evidence: [{ vars: {}, a, b }],
      };
    }

    // Điều kiện xác định do người soạn nêu (ví dụ "x != 1"): điểm nào không
    // thoả thì không xét — đúng như cách một bài rút gọn phải được phát biểu.
    let domainNode = null;
    if (domain) {
      try { domainNode = parse(domain); } catch (e) {
        return { ok: false, error: 'PARSE_ERROR', side: 'domain', message: e.message, input: String(domain) };
      }
      if (domainNode.k !== 'rel') return { ok: false, error: 'DOMAIN_NOT_A_CONDITION', hint: 'Điều kiện phải có dấu so sánh, ví dụ "x != 1"' };
    }

    const pts = samplePoints(points, this.seed);
    const evidence = [];
    let tested = 0;
    let domainSkips = 0;
    let outOfDomain = 0;

    for (let i = 0; i < pts.length; i++) {
      const env = {};
      all.forEach((v, k) => { env[v] = pts[(i + k * 5) % pts.length]; });
      if (domainNode) {
        let inside = true;
        try { inside = !!evaluate(domainNode, env); } catch { inside = false; }
        if (!inside) { outOfDomain++; continue; }
      }
      let a, b;
      try { a = evaluate(A, env); } catch { continue; }
      try { b = evaluate(B, env); } catch { continue; }
      const aBad = Number.isNaN(a) || !Number.isFinite(a);
      const bBad = Number.isNaN(b) || !Number.isFinite(b);
      if (aBad && bBad) { domainSkips++; continue; }     // cùng ngoài miền xác định: không kết luận
      if (aBad !== bBad) {
        this._fail();
        return {
          ok: true, equal: false, tested, domainIssue: true,
          reason: `Tại ${all.map((v) => `${v}=${env[v]}`).join(', ')} một vế xác định, vế kia không `
            + `(${aBad ? 'không xác định' : round(a, 6)} vs ${bBad ? 'không xác định' : round(b, 6)}) — `
            + `hai vế khác miền xác định. Bài rút gọn phải nêu điều kiện, ví dụ "${all[0]} != ${env[all[0]]}".`,
          mismatch: { vars: env, a, b },
          evidence,
        };
      }
      tested++;
      if (!near(a, b)) {
        this._fail();
        return {
          ok: true, equal: false, tested,
          reason: `Khác nhau tại ${all.map((v) => `${v}=${env[v]}`).join(', ')}: ${round(a, 6)} ≠ ${round(b, 6)}`,
          mismatch: { vars: env, a: round(a, 8), b: round(b, 8) },
          evidence,
        };
      }
      if (evidence.length < 3) evidence.push({ vars: env, a: round(a, 6), b: round(b, 6) });
    }

    if (tested < 3) {
      return {
        ok: true, equal: null, tested, domainSkips, outOfDomain,
        reason: `Chỉ thử được ${tested} điểm trong miền xác định — không đủ căn cứ kết luận`,
        evidence,
      };
    }
    this._pass();
    return {
      ok: true, equal: true, tested, domainSkips, outOfDomain,
      reason: `Trùng khớp tại ${tested} điểm thử` + (domain ? ` trong điều kiện ${domain}` : ''),
      evidence,
    };
  }

  _pass() { this.stats.passed++; }
  _fail() { this.stats.failed++; }

  // ── 2. Giải phương trình ─────────────────────────────────────────────────

  /**
   * Trích hệ số của đa thức bậc ≤ 2 theo biến x, bằng cách lấy mẫu.
   * Trả null nếu không phải đa thức bậc ≤ 2.
   */
  _quadCoeffs(node, v = 'x') {
    const f = (t) => evaluate(node, { [v]: t });
    let y0, y1, ym1, y2;
    try { y0 = f(0); y1 = f(1); ym1 = f(-1); y2 = f(2); } catch { return null; }
    if ([y0, y1, ym1, y2].some((y) => !Number.isFinite(y))) return null;
    const a = (y1 + ym1 - 2 * y0) / 2;
    const b = (y1 - ym1) / 2;
    const c = y0;
    // Kiểm tra lại ở một điểm khác: nếu không khớp thì không phải bậc ≤ 2.
    const pred = a * 4 + b * 2 + c;
    if (!near(pred, y2, 1e-6)) return null;
    for (const t of [3, -2.5, 5.5]) {
      let y; try { y = f(t); } catch { return null; }
      if (!Number.isFinite(y) || !near(a * t * t + b * t + c, y, 1e-6)) return null;
    }
    return { a: round(a, 10), b: round(b, 10), c: round(c, 10) };
  }

  /**
   * Dò nghiệm bằng số cho phương trình một ẩn không phải đa thức bậc ≤ 2.
   * Quét đổi dấu trên một lưới mịn rồi chia đôi để tinh chỉnh.
   * Điểm cực (mẫu bằng 0) cũng làm đổi dấu nên phải loại bằng cách kiểm |f| nhỏ.
   */
  _solveNumeric(diff, v, equation, { from = -60, to = 60, steps = 24000 } = {}) {
    const f = (x) => {
      try {
        const y = evaluate(diff, { [v]: x });
        return Number.isFinite(y) ? y : null;
      } catch { return null; }
    };

    const roots = [];
    const poles = [];
    let prevX = null;
    let prevY = null;

    for (let i = 0; i <= steps; i++) {
      const x = from + ((to - from) * i) / steps;
      const y = f(x);
      if (y === null) { prevX = null; prevY = null; continue; }
      if (Math.abs(y) < 1e-12) {
        if (!roots.some((r) => near(r, x, 1e-6))) roots.push(round(x, 9));
        prevX = x; prevY = y;
        continue;
      }
      if (prevY !== null && Math.sign(prevY) !== Math.sign(y)) {
        // Chia đôi trong khoảng đổi dấu.
        let lo = prevX, hi = x, ylo = prevY;
        for (let k = 0; k < 80; k++) {
          const mid = (lo + hi) / 2;
          const ym = f(mid);
          if (ym === null) break;
          if (Math.sign(ym) === Math.sign(ylo)) { lo = mid; ylo = ym; } else hi = mid;
        }
        const r = (lo + hi) / 2;
        const yr = f(r);
        // Nghiệm thật thì f(r) ≈ 0; cực thì f nhảy từ −∞ sang +∞, |f(r)| vẫn rất lớn.
        if (yr !== null && Math.abs(yr) < 1e-6 * Math.max(1, Math.abs(r))) {
          if (!roots.some((x2) => near(x2, r, 1e-6))) roots.push(round(r, 9));
        } else {
          poles.push(round(r, 6));
        }
      }
      prevX = x; prevY = y;
    }

    // Làm tròn về số nguyên / số đẹp khi rất gần, để đối chiếu đáp án viết tay.
    const cleaned = roots.map((r) => (Math.abs(r - Math.round(r)) < 1e-7 ? Math.round(r) : round(r, 8)))
      .filter((r, i, arr) => arr.findIndex((x) => near(x, r, 1e-6)) === i)
      .sort((a, b) => a - b);

    return {
      ok: true,
      kind: 'NUMERIC',
      method: 'NUMERIC',
      roots: cleaned,
      poles: [...new Set(poles)],
      scanned: { from, to, steps },
      note: cleaned.length
        ? `Dò bằng số trên đoạn [${from}; ${to}]: tìm được ${cleaned.length} nghiệm${poles.length ? `, bỏ qua ${poles.length} điểm cực` : ''}`
        : `Dò bằng số trên đoạn [${from}; ${to}]: không tìm thấy nghiệm nào`,
      caveat: 'Kết quả dò bằng số chỉ chắc chắn trong đoạn đã quét; nghiệm nằm ngoài đoạn này sẽ không được phát hiện.',
    };
  }

  /**
   * Giải phương trình một ẩn bậc ≤ 2 một cách chính xác.
   * @returns {{ok, kind, roots, coeffs, note}}
   */
  solve(equation, v = 'x') {
    this.stats.equations++;
    let node;
    try { node = parse(equation); } catch (e) { return { ok: false, error: 'PARSE_ERROR', message: e.message }; }
    if (node.k !== 'rel' || node.op !== '=') return { ok: false, error: 'NOT_AN_EQUATION', hint: 'Cần dạng "vế trái = vế phải"' };

    const diff = { k: 'bin', op: '-', a: node.a, b: node.b };
    const vars = [...variables(diff)];
    if (vars.length === 0) {
      const val = evaluate(diff, {});
      return { ok: true, kind: near(val, 0) ? 'IDENTITY' : 'CONTRADICTION', roots: [], note: near(val, 0) ? 'Đẳng thức luôn đúng' : 'Đẳng thức luôn sai' };
    }
    if (vars.length > 1 || !vars.includes(v)) {
      return { ok: false, error: 'MULTIVARIATE', variables: vars, hint: `Chỉ giải được phương trình một ẩn; tìm thấy: ${vars.join(', ')}` };
    }

    const co = this._quadCoeffs(diff, v);
    if (!co) {
      // Không phải đa thức bậc ≤ 2 (phương trình chứa ẩn ở mẫu, chứa căn, …):
      // chuyển sang dò nghiệm bằng số, và NÓI RÕ là đã dùng cách đó.
      return this._solveNumeric(diff, v, equation);
    }

    const { a, b, c } = co;
    if (near(a, 0, 1e-9)) {
      if (near(b, 0, 1e-9)) {
        return near(c, 0, 1e-9)
          ? { ok: true, kind: 'IDENTITY', roots: [], coeffs: co, note: 'Nghiệm đúng với mọi x' }
          : { ok: true, kind: 'NO_SOLUTION', roots: [], coeffs: co, note: 'Vô nghiệm' };
      }
      const x = -c / b;
      return { ok: true, kind: 'LINEAR', roots: [round(x, 10)], coeffs: co, note: `Phương trình bậc nhất: x = ${round(x, 6)}` };
    }

    const delta = b * b - 4 * a * c;
    if (delta < -1e-9) {
      return { ok: true, kind: 'QUADRATIC', roots: [], delta: round(delta, 10), coeffs: co, note: `Δ = ${round(delta, 6)} < 0 nên vô nghiệm thực` };
    }
    if (near(delta, 0, 1e-9)) {
      const x = -b / (2 * a);
      return { ok: true, kind: 'QUADRATIC', roots: [round(x, 10)], delta: 0, coeffs: co, note: `Δ = 0, nghiệm kép x = ${round(x, 6)}` };
    }
    const s = Math.sqrt(delta);
    const r1 = (-b - s) / (2 * a);
    const r2 = (-b + s) / (2 * a);
    return {
      ok: true, kind: 'QUADRATIC',
      roots: [round(Math.min(r1, r2), 10), round(Math.max(r1, r2), 10)],
      delta: round(delta, 10), coeffs: co,
      note: `Δ = ${round(delta, 6)} > 0, hai nghiệm phân biệt`,
    };
  }

  // ── 3. Thay nghiệm ngược vào phương trình ────────────────────────────────

  /** Nghiệm mô hình đưa ra có thật sự thoả phương trình không. */
  substitute(equation, value, v = 'x') {
    this.stats.substitutions++;
    let node;
    try { node = parse(equation); } catch (e) { return { ok: false, error: 'PARSE_ERROR', message: e.message }; }
    if (node.k !== 'rel') return { ok: false, error: 'NOT_A_RELATION' };
    let lhs, rhs;
    try {
      lhs = evaluate(node.a, { [v]: value });
      rhs = evaluate(node.b, { [v]: value });
    } catch (e) { return { ok: false, error: 'EVAL_ERROR', message: e.message }; }
    if (Number.isNaN(lhs) || Number.isNaN(rhs)) {
      return { ok: true, satisfied: false, reason: `x = ${value} nằm ngoài miền xác định`, lhs, rhs };
    }
    const diff = Math.abs(lhs - rhs);
    const satisfied = diff <= 1e-6 * Math.max(1, Math.abs(lhs), Math.abs(rhs));
    return {
      ok: true, satisfied,
      lhs: round(lhs, 8), rhs: round(rhs, 8), diff: round(diff, 10),
      reason: satisfied ? `Thay x = ${value} cho hai vế bằng nhau` : `Thay x = ${value}: ${round(lhs, 6)} ≠ ${round(rhs, 6)}`,
    };
  }

  // ── 4. Đối chiếu tập nghiệm ──────────────────────────────────────────────

  /** Bóc tập nghiệm từ chuỗi kiểu "x = 2 hoặc x = 3", "{2; 3}", "S = {2,3}", "x=2; x=3". */
  parseRootSet(text) {
    const s = latexToPlain(String(text ?? ''))
      .replace(/^\s*S\s*=\s*/i, '')
      .replace(/\b(hoac|hoặc|or|và|va)\b/gi, ';')
      .replace(/[{}[\]]/g, ' ')
      .replace(/\bx\s*=\s*/gi, ' ');
    const parts = s.split(/[;,]/).map((p) => p.trim()).filter(Boolean);
    const roots = [];
    const bad = [];
    for (const p of parts) {
      try {
        const val = evaluate(parse(p), {});
        if (Number.isFinite(val)) roots.push(round(val, 10)); else bad.push(p);
      } catch { bad.push(p); }
    }
    return { roots: [...new Set(roots)].sort((a, b) => a - b), unparsed: bad };
  }

  /** Tập nghiệm mô hình đưa ra có đúng bằng tập nghiệm thật không. */
  checkRoots(equation, claimed, v = 'x') {
    const truth = this.solve(equation, v);
    if (!truth.ok) return { ok: false, ...truth };
    const got = Array.isArray(claimed) ? { roots: [...new Set(claimed.map((x) => round(Number(x), 10)))].sort((a, b) => a - b), unparsed: [] } : this.parseRootSet(claimed);

    const want = truth.roots;
    const missing = want.filter((w) => !got.roots.some((g) => near(g, w, 1e-6)));
    const extra = got.roots.filter((g) => !want.some((w) => near(g, w, 1e-6)));
    const correct = missing.length === 0 && extra.length === 0 && got.unparsed.length === 0;

    // Nghiệm thừa do mô hình bịa: chỉ rõ nó sai ở đâu khi thay vào.
    const extraProof = extra.map((x) => ({ root: x, ...this.substitute(equation, x, v) }));

    this[correct ? '_pass' : '_fail']();
    return {
      ok: true, correct,
      kind: truth.kind,
      trueRoots: want,
      claimedRoots: got.roots,
      missing, extra,
      unparsed: got.unparsed,
      delta: truth.delta,
      reason: correct ? 'Tập nghiệm khớp hoàn toàn'
        : [
          missing.length ? `thiếu nghiệm ${missing.join(', ')}` : '',
          extra.length ? `thừa nghiệm ${extra.join(', ')}` : '',
          got.unparsed.length ? `không đọc được "${got.unparsed.join('", "')}"` : '',
        ].filter(Boolean).join('; '),
      extraProof,
    };
  }

  // ── 5. Bất phương trình / miền nghiệm ────────────────────────────────────

  /**
   * Hai điều kiện có cùng tập nghiệm không — lấy mẫu trên trục số.
   * Dùng cho đáp án kiểu "x ≥ 3", "x > 2 và x < 5".
   */
  sameSolutionSet(condA, condB, { v = 'x', from = -50, to = 50, steps = 400 } = {}) {
    let A, B;
    try { A = parse(condA); } catch (e) { return { ok: false, error: 'PARSE_ERROR', side: 'A', message: e.message }; }
    try { B = parse(condB); } catch (e) { return { ok: false, error: 'PARSE_ERROR', side: 'B', message: e.message }; }
    if (A.k !== 'rel' || B.k !== 'rel') return { ok: false, error: 'NOT_A_RELATION', hint: 'Cần điều kiện dạng so sánh, ví dụ x >= 3' };

    const diffs = [];
    let checked = 0;
    for (let i = 0; i <= steps; i++) {
      const x = from + ((to - from) * i) / steps;
      let a, b;
      try { a = evaluate(A, { [v]: x }); } catch { continue; }
      try { b = evaluate(B, { [v]: x }); } catch { continue; }
      checked++;
      if (a !== b && diffs.length < 5) diffs.push({ [v]: round(x, 4), a, b });
    }
    const same = diffs.length === 0 && checked > 10;
    this[same ? '_pass' : '_fail']();
    return {
      ok: true, same, checked,
      reason: same ? `Cùng tập nghiệm trên ${checked} điểm thử`
        : `Khác nhau tại ${diffs.map((d) => `${v}=${d[v]}`).join(', ')}`,
      counterExamples: diffs,
    };
  }

  // ── 6. Thẩm định trọn một bài ────────────────────────────────────────────

  /**
   * Soát một bài trước khi đưa vào kho.
   * @param {object} item {stem, answer, solutionSteps, check:{equation, expect, kind}}
   */
  verifyItem(item = {}) {
    const checks = [];
    const add = (name, passed, detail) => checks.push({ name, passed, detail });

    const ck = item.check || {};
    // Bài tiếng Anh không có số để thay, nên chốt bằng bộ giải lại ngữ pháp:
    // đọc lại câu nguồn rồi tự biến đổi, so với đáp án bộ sinh khai báo.
    // Nạp muộn để module toán không phụ thuộc cứng vào module ngôn ngữ.
    if (ck.english) {
      const { kiemTiengAnh } = require('../lang/en-verifier');
      const r = kiemTiengAnh(ck.english, item.answer);
      add(r.ten, r.dat, r.chiTiet);
      return {
        ok: true,
        verified: r.dat,
        verdict: r.dat ? 'ĐẠT' : 'SAI',
        checks,
        failedCount: r.dat ? 0 : 1,
        reason: r.dat ? `Bộ giải lại ngữ pháp cho cùng kết quả: ${r.chiTiet}` : `Không đạt: ${r.chiTiet}`,
      };
    }
    if (ck.equation && (ck.roots || item.answer)) {
      const r = this.checkRoots(ck.equation, ck.roots || item.answer, ck.variable || 'x');
      add('tập nghiệm', r.ok && r.correct, r.reason || r.error);
      if (r.ok && r.correct) {
        for (const root of r.trueRoots) {
          const sub = this.substitute(ck.equation, root, ck.variable || 'x');
          add(`thay x = ${root}`, sub.ok && sub.satisfied, sub.reason || sub.error);
        }
      }
    } else if (ck.expression && ck.equals) {
      const r = this.equivalent(ck.expression, ck.equals, { domain: ck.domain || null });
      add(r.domainIssue ? 'điều kiện xác định' : 'biểu thức tương đương', r.ok && r.equal === true, r.reason || r.error);
    } else if (ck.condition && item.answer) {
      const r = this.sameSolutionSet(ck.condition, item.answer, { v: ck.variable || 'x' });
      add('miền nghiệm', r.ok && r.same, r.reason || r.error);
    } else {
      return {
        ok: true, verified: false, verdict: 'KHÔNG_KIỂM_ĐƯỢC',
        reason: 'Bài chưa khai báo phần kiểm tra máy (check.equation / check.expression / check.condition)',
        checks: [],
      };
    }

    const failed = checks.filter((c) => !c.passed);
    return {
      ok: true,
      verified: failed.length === 0,
      verdict: failed.length === 0 ? 'ĐẠT' : 'SAI',
      checks,
      failedCount: failed.length,
      reason: failed.length === 0
        ? `Máy tự kiểm ${checks.length} điểm, khớp hết`
        : `Không đạt ${failed.length}/${checks.length} điểm: ${failed.map((f) => `${f.name} (${f.detail})`).join('; ')}`,
    };
  }

  status() {
    return {
      ...this.stats,
      passRate: this.stats.checks ? round(this.stats.passed / this.stats.checks, 3) : 0,
      samples: SAMPLES,
      seed: this.seed,
    };
  }
}

module.exports = MathVerifier;
module.exports.samplePoints = samplePoints;
module.exports.near = near;
