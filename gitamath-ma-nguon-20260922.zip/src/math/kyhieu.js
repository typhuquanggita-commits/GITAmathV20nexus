'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MÁY KÝ HIỆU TOÁN — chuẩn quốc tế, dạng Unicode phẳng
 * ═══════════════════════════════════════════════════════════════════════════
 *  Hệ thống này có HAI dạng viết toán, và cả hai đều chuẩn:
 *
 *   · LaTeX  (\dfrac{a}{b}, x^{2}, \sqrt{x}) — dạng LƯU TRỮ. Điều A02 Hiến
 *     pháp bắt buộc học liệu phải lưu ở dạng này; src/content/notation.js
 *     cưỡng chế. Giao diện web dựng lại bằng ui/tex.js.
 *   · Unicode phẳng (a⁄b, x², √x) — dạng TRÌNH BÀY cho nơi KHÔNG dựng được
 *     LaTeX: khung hình video, dòng lệnh, tệp văn bản, tin nhắn.
 *
 *  Tệp này lo dạng thứ hai. Nó nhận vào cả LaTeX lẫn lối viết thô của máy
 *  (x^2, x_1, sqrt(x), Delta) và trả ra đúng ký hiệu toán học quốc tế.
 *
 *  BA CHỖ DỄ LÀM HỎNG, và cách đã xử lý:
 *
 *   1. Dấu "/" trong tiếng Việt PHẦN LỚN không phải phân số: "20/11",
 *      "km/h", "và/hoặc", "http://". Đổi bừa là hỏng văn bản. Ở đây "/" chỉ
 *      đổi thành "⁄" khi quanh nó có dấu hiệu toán thật (=, +, ², √…) và
 *      không rơi vào ngày tháng, đơn vị đo hay địa chỉ mạng.
 *   2. Dấu "-" cũng vậy: "đen-ta", "cô-sin", "Bài 3-4" đều KHÔNG phải phép
 *      trừ. Chỉ đổi thành "−" (U+2212) khi hai bên là toán hạng thật và
 *      quanh đó có dấu hiệu toán.
 *   3. Không phải ký tự nào cũng có bản mũ/chỉ số trong Unicode: "q" không
 *      có dạng mũ, "b" không có dạng chỉ số dưới. Gặp trường hợp đó thì GIỮ
 *      NGUYÊN lối viết cũ và để bộ soát báo, chứ không nuốt mất ký tự — nuốt
 *      mất là đổi nghĩa công thức, tội nặng hơn nhiều so với viết chưa đẹp.
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── Bảng ký tự mũ và chỉ số dưới mà Unicode thật sự có ─────────────────────
const SIEU = {
  0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹',
  '+': '⁺', '-': '⁻', '−': '⁻', '=': '⁼', '(': '⁽', ')': '⁾',
  a: 'ᵃ', b: 'ᵇ', c: 'ᶜ', d: 'ᵈ', e: 'ᵉ', f: 'ᶠ', g: 'ᵍ', h: 'ʰ', i: 'ⁱ', j: 'ʲ',
  k: 'ᵏ', l: 'ˡ', m: 'ᵐ', n: 'ⁿ', o: 'ᵒ', p: 'ᵖ', r: 'ʳ', s: 'ˢ', t: 'ᵗ', u: 'ᵘ',
  v: 'ᵛ', w: 'ʷ', x: 'ˣ', y: 'ʸ', z: 'ᶻ',
};
const DUOI = {
  0: '₀', 1: '₁', 2: '₂', 3: '₃', 4: '₄', 5: '₅', 6: '₆', 7: '₇', 8: '₈', 9: '₉',
  '+': '₊', '-': '₋', '−': '₋', '=': '₌', '(': '₍', ')': '₎',
  a: 'ₐ', e: 'ₑ', h: 'ₕ', i: 'ᵢ', j: 'ⱼ', k: 'ₖ', l: 'ₗ', m: 'ₘ', n: 'ₙ',
  o: 'ₒ', p: 'ₚ', r: 'ᵣ', s: 'ₛ', t: 'ₜ', u: 'ᵤ', v: 'ᵥ', x: 'ₓ',
};

/** Bảng ngược — dùng cho bộ đọc thành lời và cho việc soát lại. */
const SIEU_NGUOC = Object.fromEntries(Object.entries(SIEU).map(([k, v]) => [v, k]));
const DUOI_NGUOC = Object.fromEntries(Object.entries(DUOI).map(([k, v]) => [v, k]));

/** Phân số có sẵn một ký tự trong Unicode. */
const PHAN_SO_DEP = {
  '1/2': '½', '1/3': '⅓', '2/3': '⅔', '1/4': '¼', '3/4': '¾',
  '1/5': '⅕', '2/5': '⅖', '3/5': '⅗', '4/5': '⅘',
  '1/6': '⅙', '5/6': '⅚', '1/8': '⅛', '3/8': '⅜', '5/8': '⅝', '7/8': '⅞',
};
const PHAN_SO_NGUOC = Object.fromEntries(Object.entries(PHAN_SO_DEP).map(([k, v]) => [v, k]));

/** Ký hiệu rời: lối viết thô hoặc LaTeX → ký tự chuẩn. */
const KY_HIEU = [
  // Tập hợp số — chỉ đổi từ LaTeX \mathbb, KHÔNG đoán từ chữ R, N, Z đứng lẻ:
  // "N" trong "N người" là danh từ, đổi thành ℕ là sai nghĩa.
  [/\\mathbb\s*\{\s*R\s*\}|\\R\b/g, 'ℝ'], [/\\mathbb\s*\{\s*N\s*\}|\\N\b/g, 'ℕ'],
  [/\\mathbb\s*\{\s*Z\s*\}/g, 'ℤ'], [/\\mathbb\s*\{\s*Q\s*\}/g, 'ℚ'],
  [/\\mathbb\s*\{\s*C\s*\}/g, 'ℂ'], [/\\mathbb\s*\{\s*P\s*\}/g, 'ℙ'],
  // Biệt thức: ∆ (U+2206 INCREMENT) là ký tự toán; Δ (U+0394) là chữ cái Hy Lạp.
  [/\\Delta\b|Δ/g, '∆'], [/\\delta\b/g, 'δ'],
  [/\\alpha\b/g, 'α'], [/\\beta\b/g, 'β'], [/\\gamma\b/g, 'γ'], [/\\theta\b/g, 'θ'],
  [/\\lambda\b/g, 'λ'], [/\\mu\b/g, 'μ'], [/\\pi\b/g, 'π'], [/\\omega\b/g, 'ω'],
  [/\\varphi\b|\\phi\b/g, 'φ'], [/\\sigma\b/g, 'σ'], [/\\tau\b/g, 'τ'],
  [/\\infty\b/g, '∞'], [/\\emptyset\b|\\varnothing\b/g, '∅'],
  [/\\leq\b|\\le\b|<=/g, '≤'], [/\\geq\b|\\ge\b|>=/g, '≥'],
  [/\\neq\b|\\ne\b|!=/g, '≠'], [/\\approx\b|~=/g, '≈'], [/\\equiv\b/g, '≡'],
  [/\\pm\b|\+\/-/g, '±'], [/\\mp\b/g, '∓'],
  [/\\cdot\b/g, '·'], [/\\times\b/g, '×'], [/\\div\b/g, '÷'],
  [/\\notin\b/g, '∉'], [/\\in\b/g, '∈'], [/\\ni\b/g, '∋'],
  [/\\subseteq\b/g, '⊆'], [/\\subset\b/g, '⊂'], [/\\supset\b/g, '⊃'],
  [/\\cup\b/g, '∪'], [/\\cap\b/g, '∩'], [/\\setminus\b/g, '∖'],
  [/\\forall\b/g, '∀'], [/\\exists\b/g, '∃'], [/\\neg\b/g, '¬'],
  [/\\Leftrightarrow\b|\\iff\b/g, '⇔'], [/\\Rightarrow\b|\\implies\b/g, '⇒'],
  [/\\rightarrow\b|\\to\b|->/g, '→'], [/\\leftarrow\b/g, '←'],
  [/\\sum\b/g, '∑'], [/\\prod\b/g, '∏'], [/\\int\b/g, '∫'],
  [/\\angle\b/g, '∠'], [/\\perp\b/g, '⊥'], [/\\parallel\b/g, '∥'],
  [/\\degree\b|\\circ\b/g, '°'], [/\\prime\b/g, '′'],
  [/\\ldots\b|\\dots\b|\.\.\./g, '…'],
  [/\\%/g, '%'], [/\\\$/g, '$'],
];

/** Lệnh LaTeX chỉ để trình bày — bỏ đi, không mang nghĩa toán. */
const BO_LENH = /\\(?:left|right|displaystyle|textstyle|quad|qquad|,|;|!|:)\s?/g;

// ── Chuyển chuỗi sang dạng mũ / chỉ số dưới ────────────────────────────────

/**
 * Đưa chuỗi lên dạng mũ. Trả về null nếu có ký tự Unicode không có bản mũ —
 * người gọi phải giữ nguyên lối viết cũ chứ không được nuốt ký tự.
 */
function lenSieu(s) {
  let ra = '';
  for (const c of String(s)) {
    const t = SIEU[c] ?? SIEU[c.toLowerCase()];
    if (!t) return null;
    ra += t;
  }
  return ra || null;
}

/** Đưa chuỗi xuống dạng chỉ số dưới. Trả về null nếu không đủ ký tự. */
function xuongDuoi(s) {
  let ra = '';
  for (const c of String(s)) {
    const t = DUOI[c] ?? DUOI[c.toLowerCase()];
    if (!t) return null;
    ra += t;
  }
  return ra || null;
}

// ── Che những chỗ KHÔNG được đụng vào ──────────────────────────────────────

/**
 * Địa chỉ mạng, ngày tháng, giờ, đơn vị đo, đường dẫn tệp: đây là những chỗ
 * dấu "/" và "-" mang nghĩa khác hẳn. Che lại trước khi đổi ký hiệu.
 */
const CHE = [
  /https?:\/\/\S+/g,                                   // http://…
  /\b\d{1,2}\/\d{1,2}\/\d{2,4}\b/g,                       // 20/11/2025
  // Dạng hai phần "20/11" chỉ là ngày khi có chữ chỉ ngày đứng trước; nếu
  // không thì rất có thể là phân số — "1/2" mà che đi là hỏng cả bài toán.
  /(?:\b(?:ng[àa]y|h[ôo]m|v[àa]o|t[ừu]|đ[êe]́?n)\s+)\d{1,2}\/\d{1,2}\b/gi,
  /\b\d{1,2}:\d{2}(?::\d{2})?\b/g,                     // 08:30
  /\b\d+(?:[.,]\d+)?\s?(?:km|m|cm|mm|kg|g|mg|l|ml|s|h|ph)\/(?:h|s|ph|kg|l|m[²³]?)\b/gi,  // 60 km/h
  /\b(?:km|m|cm|dm|mm|kg|g|l|ml|đ|VND|USD)\/(?:h|s|ph|kg|l|m[²³]?|người|năm|tháng)\b/gi, // km/h, đ/kg
  /\bv[àa]\/ho[ặa]c\b/gi,                              // và/hoặc
  /\b[\w.-]+\.(?:js|json|md|txt|html|css|png|jpg|avi|wav)\b/g, // tên tệp
];

function che(s) {
  const kho = [];
  let ra = s;
  for (const re of CHE) {
    ra = ra.replace(re, (m) => { kho.push(m); return `\u0001${kho.length - 1}\u0001`; });
  }
  return { ra, kho };
}
const boChe = (s, kho) => s.replace(/\u0001(\d+)\u0001/g, (_, i) => kho[Number(i)]);

/** Quanh vị trí này có dấu hiệu đang viết toán không? */
const DAU_HIEU_TOAN = /[=+·×÷√∛∆∑∫≤≥≠≈±⁄¹²³⁰⁴⁵⁶⁷⁸⁹ⁿ₀₁₂₃₄₅₆₇₈₉ℝℕℤℚℂ∈∉⊂⊆∪∩∀∃⇒⇔∅<>]|\^|\bsqrt\b/;
function quanhCoToan(s, i, ban = 24) {
  return DAU_HIEU_TOAN.test(s.slice(Math.max(0, i - ban), i + ban));
}

/**
 * Bọc ngoặc cho tử/mẫu khi cần — (a + b)⁄(c + d).
 * Mẫu khắt khe hơn tử: "a⁄2b" đọc được hai nghĩa (a⁄(2b) hay (a⁄2)·b), nên
 * mẫu chỉ được để trần khi là MỘT hạng tử duy nhất; tử thì chỉ cần bọc khi
 * có phép cộng trừ ở tầng ngoài cùng.
 */
function bocNeuCan(s, { mau = false } = {}) {
  const t = String(s).trim();
  if (!t) return t;
  if (/^\(.*\)$/.test(t) && canBang(t.slice(1, -1))) return t;
  const motHangTu = /^[−-]?(?:\d+(?:[.,]\d+)?|[A-Za-zΑ-Ωα-ω∆][⁰-⁹¹²³ⁿ₀-₉′]*)$/.test(t)
    || /^[−-]?[√∛∜]?\([^()]*\)$/.test(t)
    || /^[−-]?[√∛∜][A-Za-zΑ-Ωα-ω0-9∆][⁰-⁹¹²³ⁿ₀-₉]*$/.test(t);
  if (motHangTu) return t;
  if (!mau && !/[+−±]/.test(boNgoacTrong(t))) return t;   // tử: tích thì để trần
  return `(${t})`;
}

/** Bỏ phần nằm trong ngoặc để xét phép toán ở tầng ngoài cùng. */
function boNgoacTrong(s) {
  let ra = ''; let d = 0;
  for (const c of s) {
    if (c === '(') d++;
    else if (c === ')') d--;
    else if (d === 0) ra += c;
  }
  return ra;
}
function canBang(s) {
  let d = 0;
  for (const c of s) { if (c === '(') d++; else if (c === ')') { d--; if (d < 0) return false; } }
  return d === 0;
}

/** Đọc một cặp {} cân bằng bắt đầu tại i. */
function docNgoac(s, i) {
  if (s[i] !== '{') return null;
  let d = 0;
  for (let j = i; j < s.length; j++) {
    if (s[j] === '{') d++;
    else if (s[j] === '}') { d--; if (d === 0) return { than: s.slice(i + 1, j), sau: j + 1 }; }
  }
  return null;
}

/** Bóc \frac{…}{…}, \sqrt[…]{…}, \vec{…}, \overline{…} từ trong ra ngoài. */
function bocLatex(s) {
  let ra = s;
  for (let vong = 0; vong < 60; vong++) {
    const mFrac = ra.match(/\\(?:dfrac|tfrac|frac|cfrac)\s*(?=\{)/);
    const mSqrt = ra.match(/\\sqrt\s*(?:\[([^\]]*)\])?\s*(?=\{)/);
    const mVec = ra.match(/\\(?:vec|overrightarrow)\s*(?=\{)/);
    const mLine = ra.match(/\\(?:overline|bar)\s*(?=\{)/);
    const ung = [[mFrac, 'frac'], [mSqrt, 'sqrt'], [mVec, 'vec'], [mLine, 'line']]
      .filter(([m]) => m)
      .sort((a, b) => b[0].index - a[0].index);   // cái trong cùng nằm sau cùng
    if (!ung.length) break;
    const [m, loai] = ung[0];
    const dau = m.index;
    const batDau = dau + m[0].length;

    if (loai === 'frac') {
      const tu = docNgoac(ra, batDau);
      if (!tu) break;
      let k = tu.sau; while (ra[k] === ' ') k++;
      const mau = docNgoac(ra, k);
      if (!mau) break;
      ra = ra.slice(0, dau) + phanSo(tu.than, mau.than) + ra.slice(mau.sau);
    } else if (loai === 'sqrt') {
      const than = docNgoac(ra, batDau);
      if (!than) break;
      ra = ra.slice(0, dau) + can(than.than, m[1]) + ra.slice(than.sau);
    } else if (loai === 'vec') {
      const than = docNgoac(ra, batDau);
      if (!than) break;
      ra = ra.slice(0, dau) + `${than.than}⃗` + ra.slice(than.sau);
    } else {
      const than = docNgoac(ra, batDau);
      if (!than) break;
      ra = ra.slice(0, dau) + `${than.than}̅` + ra.slice(than.sau);
    }
  }
  return ra;
}

/** Dựng phân số: ½ nếu có sẵn ký tự, không thì a⁄b có bọc ngoặc khi cần. */
function phanSo(tu, mau, { dep = true } = {}) {
  const a = String(tu).trim();
  const b = String(mau).trim();
  if (dep && PHAN_SO_DEP[`${a}/${b}`]) return PHAN_SO_DEP[`${a}/${b}`];
  return `${bocNeuCan(a)}⁄${bocNeuCan(b, { mau: true })}`;
}

/** Dựng căn: √x, √(x + 1), ∛x, ⁴√x. */
function can(than, bac) {
  const t = String(than).trim();
  const than2 = /^[0-9A-Za-zΑ-Ωα-ω][0-9A-Za-zΑ-Ωα-ω⁰-⁹¹²³ⁿ₀-₉]*$|^∆$|^\(.*\)$/.test(t) ? t : `(${t})`;
  const b = bac ? String(bac).trim() : '';
  if (!b || b === '2') return `√${than2}`;
  if (b === '3') return `∛${than2}`;
  if (b === '4') return `∜${than2}`;
  const s = lenSieu(b);
  return s ? `${s}√${than2}` : `√[${b}]${than2}`;
}

// ── Cửa chính ──────────────────────────────────────────────────────────────

/**
 * Đưa một đoạn văn bản về ký hiệu toán chuẩn dạng Unicode phẳng.
 * Nhận cả LaTeX lẫn lối viết thô của máy.
 */
function chuanHoa(text, { phanSoDep = true, doiTru = true, doiChia = true, doiNhan = true } = {}) {
  if (typeof text !== 'string' || !text) return text;
  const { ra: dauVao, kho } = che(text);
  let s = dauVao;

  // 1. Bóc vỏ LaTeX hiển thị: $…$, \(…\), \[…\]
  s = s.replace(/\$\$?([^$]*)\$\$?/g, ' $1 ').replace(/\\[()[\]]/g, ' ');
  s = s.replace(BO_LENH, ' ');

  // 2. Ký hiệu rời — làm TRƯỚC khi bóc phân số và căn, để \sqrt{\Delta}
  //    thành √∆ chứ không thành √(∆) thừa một cặp ngoặc.
  for (const [re, ch] of KY_HIEU) s = s.replace(re, ch);

  // 3. Cấu trúc lồng nhau (phân số, căn, vector) — phải làm trước mũ/chỉ số,
  //    vì tử và mẫu bên trong thường có sẵn mũ.
  s = bocLatex(s);

  // 4. Mũ: x^{n+1} → x⁽ⁿ⁺¹⁾, x^(n+1), x^2
  const mu = (toanBo, goc, so) => {
    const t = lenSieu(so);
    return t === null ? toanBo : goc + t;
  };
  s = s.replace(/([0-9A-Za-zΑ-Ωα-ω)\]}⁾])\s*\^\s*\{([^{}]+)\}/g, (m, g, e) => mu(m, g, e.trim()));
  s = s.replace(/([0-9A-Za-zΑ-Ωα-ω)\]}⁾])\s*\^\s*\(([^()]+)\)/g, (m, g, e) => mu(m, g, `(${e.trim()})`));
  s = s.replace(/([0-9A-Za-zΑ-Ωα-ω)\]}⁾])\s*\^\s*(-?\d+|[A-Za-z])/g, (m, g, e) => mu(m, g, e));

  // 5. Chỉ số dưới: x_{n+1} → x₍ₙ₊₁₎, x_1 → x₁
  const chiSo = (toanBo, goc, so) => {
    const t = xuongDuoi(so);
    return t === null ? toanBo : goc + t;
  };
  s = s.replace(/([0-9A-Za-zΑ-Ωα-ω)\]}])\s*_\s*\{([^{}]+)\}/g, (m, g, e) => chiSo(m, g, e.trim()));
  s = s.replace(/([0-9A-Za-zΑ-Ωα-ω)\]}])\s*_\s*\(([^()]+)\)/g, (m, g, e) => chiSo(m, g, `(${e.trim()})`));
  s = s.replace(/([0-9A-Za-zΑ-Ωα-ω)\]}])\s*_\s*([0-9A-Za-z])/g, (m, g, e) => chiSo(m, g, e));

  // 6. Hàm viết thô
  s = s.replace(/\bsqrt\s*\[\s*(\d+)\s*\]\s*\(([^()]*)\)/gi, (_, b, t) => can(t, b));
  for (let i = 0; i < 6; i++) {
    const truoc = s;
    s = s.replace(/\bsqrt\s*\(([^()]*)\)/gi, (_, t) => can(t));
    s = s.replace(/\bcbrt\s*\(([^()]*)\)/gi, (_, t) => can(t, 3));
    if (s === truoc) break;
  }
  s = s.replace(/\bsqrt\s+([0-9A-Za-z]+)/gi, (_, t) => `√${t}`);
  s = s.replace(/\b(?:vec|vector)\s*\(([^()]*)\)/gi, (_, v) => `${v.trim()}⃗`);
  s = s.replace(/\babs\s*\(([^()]*)\)/gi, (_, v) => `|${v.trim()}|`);
  s = s.replace(/\bDelta\b/g, '∆');
  // "in", "not in", "union"… là lối viết thô của máy. Chỉ đổi khi quanh đó
  // đúng là đang viết toán: "in" còn là một từ tiếng Anh và tiếng Việt.
  const TU_TOAN = [[/\bnot\s+in\b/gi, '∉'], [/\bin\b/g, '∈'], [/\bunion\b/gi, '∪'],
    [/\bintersect\b/gi, '∩'], [/\bsubset\b/gi, '⊂'], [/\bforall\b/gi, '∀'],
    [/\bexists\b/gi, '∃'], [/\bempty\b/gi, '∅'], [/\bimplies\b/gi, '⇒'], [/\biff\b/gi, '⇔']];
  for (const [re, ch] of TU_TOAN) s = s.replace(re, (m, i, str) => (quanhCoToan(str, i) ? ch : m));
  s = s.replace(/\blog_?\s*\{?([0-9a-z]+)\}?\s*(?=[(\s])/gi, (m, b) => {
    const d = xuongDuoi(b);
    return d ? `log${d} ` : m;
  });

  // 7. Phân số viết bằng dấu "/" — chỉ trong ngữ cảnh toán rõ ràng.
  if (doiChia) {
    s = s.replace(/\(([^()]+)\)\s*\/\s*\(([^()]+)\)/g, (_, a, b) => phanSo(a, b, { dep: phanSoDep }));
    s = s.replace(/\(([^()]+)\)\s*\/\s*([0-9A-Za-z][0-9A-Za-z⁰-⁹¹²³₀-₉]*)/g, (_, a, b) => phanSo(a, b, { dep: phanSoDep }));
    s = s.replace(/([0-9A-Za-z][0-9A-Za-z⁰-⁹¹²³₀-₉]*)\s*\/\s*\(([^()]+)\)/g, (_, a, b) => phanSo(a, b, { dep: phanSoDep }));
    s = s.replace(/(\d+)\s*\/\s*(\d+)/g, (m, a, b, i, str) => (quanhCoToan(str, i) ? phanSo(a, b, { dep: phanSoDep }) : m));
    s = s.replace(/\b([a-z])\s*\/\s*([a-z])\b/g, (m, a, b, i, str) => (quanhCoToan(str, i) ? phanSo(a, b, { dep: false }) : m));
  }

  // 8. Dấu nhân: chỉ khi hai bên là toán hạng thật (không đụng **in đậm**).
  if (doiNhan) {
    // Chạy hai lượt: 4*1*6 có hai dấu nhân chung một ký tự nên một lượt chỉ
    // bắt được dấu thứ nhất.
    // Chỉ chấp nhận tối đa MỘT dấu cách và không vắt qua dòng: "= 1\n\n*Vì…"
    // là chữ in nghiêng của Markdown, không phải phép nhân.
    for (let i = 0; i < 2; i++) s = s.replace(/([0-9A-Za-z)\]⁰-⁹¹²³₀-₉]) ?\* ?([0-9A-Za-z(√])/g, '$1 · $2');
    s = s.replace(/(\d)\s*×\s*(\d)/g, '$1 · $2');
  }

  // 9. Dấu trừ thật (U+2212) — xem ghi chú đầu tệp về "đen-ta", "Bài 3-4".
  if (doiTru) {
    // Trừ hai ngôi có dấu cách hai bên: giữ nguyên khoảng cách.
    s = s.replace(/([0-9A-Za-z)\]⁰-⁹¹²³₀-₉∆|])( +)-( +)(?=[0-9A-Za-z(√∆|])/g,
      (m, tr, k1, k2, i, str) => (quanhCoToan(str, i) ? `${tr}${k1}−${k2}` : m));
    // Trừ hai ngôi viết dính: x-1 → x − 1
    s = s.replace(/([0-9A-Za-z)\]⁰-⁹¹²³₀-₉∆])-(?=[0-9A-Za-z(√∆])/g,
      (m, tr, i, str) => (quanhCoToan(str, i) ? `${tr} − ` : m));
    // Dấu âm một ngôi: đứng đầu, sau ngoặc mở hoặc sau một phép toán.
    s = s.replace(/(^|[(=+·×÷<>≤≥≠⁄]\s*)-(?=[0-9A-Za-z(√∆])/g,
      (m, tr, i, str) => (quanhCoToan(str, i) ? `${tr}−` : m));
  }

  // 9b. Giãn dấu cộng và dấu trừ hai ngôi cho dễ đọc: −b+√∆ → −b + √∆
  s = s.replace(/([0-9A-Za-z)\]⁰-⁹¹²³₀-₉∆|])([+−])(?=[0-9A-Za-z(√∆|])/g,
    (m, tr, dau, i, str) => (quanhCoToan(str, i) ? `${tr} ${dau} ` : m));

  // 10. Dọn khoảng trắng do bóc lệnh LaTeX để lại, giữ nguyên xuống dòng.
  s = s.replace(/[ \t]{2,}/g, ' ').replace(/ ([,;.:)])/g, '$1').replace(/\( /g, '(');

  return boChe(s, kho);
}

/** Chuẩn hoá đệ quy mọi chuỗi trong một cấu trúc dữ liệu. */
function chuanHoaSau(x, o) {
  if (x === null || x === undefined) return x;
  if (typeof x === 'string') return chuanHoa(x, o);
  if (Array.isArray(x)) return x.map((y) => chuanHoaSau(y, o));
  if (typeof x === 'object') {
    const ra = {};
    for (const [k, v] of Object.entries(x)) ra[k] = chuanHoaSau(v, o);
    return ra;
  }
  return x;
}

// ── Soát tầng 1: ký hiệu ───────────────────────────────────────────────────

/**
 * Tìm những chỗ còn viết toán theo lối máy. Trả về danh sách lỗi có trích
 * dẫn đúng chỗ sai, để người sửa không phải đi dò.
 */
function kiemKyHieu(text) {
  const s = String(text || '');
  const { ra: sach } = che(s);
  const loi = [];
  const bat = (re, ma, moTa, cach) => {
    const co = sach.match(re);
    if (co) loi.push({ ma, moTa: `${moTa} (${co.length} chỗ: ${[...new Set(co)].slice(0, 3).join(', ')})`, cach });
  };

  bat(/[0-9A-Za-z)\]]\^[0-9A-Za-z({-]/g, 'MU_THO', 'Còn dùng dấu ^ cho luỹ thừa', 'Viết x² thay cho x^2');
  bat(/[A-Za-z]_[0-9A-Za-z({]/g, 'CHI_SO_THO', 'Còn dùng dấu _ cho chỉ số dưới', 'Viết x₁ thay cho x_1');
  bat(/\bsqrt\s*[([]/gi, 'CAN_THO', 'Còn dùng sqrt()', 'Viết √x hoặc √(x + 1)');
  bat(/\b(?:vec|vector)\s*\(/gi, 'VECTO_THO', 'Còn dùng vec()', 'Viết a⃗');
  bat(/\babs\s*\(/gi, 'TRI_TUYET_DOI_THO', 'Còn dùng abs()', 'Viết |x|');
  bat(/Δ/g, 'DELTA_SAI', 'Dùng Δ (chữ cái Hy Lạp U+0394) làm biệt thức', 'Dùng ∆ (U+2206)');
  bat(/\\(?:dfrac|frac|sqrt|mathbb|Delta|cdot|le|ge|ne)\b/g, 'CON_LATEX', 'Còn lệnh LaTeX chưa dựng', 'Chuyển sang ký hiệu Unicode khi in ra văn bản thuần');
  bat(/<=|>=|!=/g, 'SO_SANH_THO', 'Còn viết <=, >=, !=', 'Dùng ≤, ≥, ≠');

  // "/" và "*" chỉ tính là lỗi khi quanh đó đúng là đang viết toán.
  for (const m of sach.matchAll(/\//g)) {
    if (quanhCoToan(sach, m.index)) {
      loi.push({ ma: 'CHIA_THO', moTa: `Dùng "/" trong biểu thức toán: "${sach.slice(Math.max(0, m.index - 12), m.index + 12).trim()}"`, cach: 'Dùng ⁄ (U+2044) hoặc \\dfrac{}{} ' });
      break;
    }
  }
  // Cùng luật với lúc chuẩn hoá: "*chữ in nghiêng*" của Markdown không phải
  // dấu nhân, nên không được tính là lỗi.
  for (const m of sach.matchAll(/[0-9A-Za-z)] ?\* ?[0-9A-Za-z(]/g)) {
    loi.push({ ma: 'NHAN_THO', moTa: `Dùng "*" làm dấu nhân: "${m[0]}"`, cach: 'Dùng dấu · ' });
    break;
  }

  return { ok: loi.length === 0, soLoi: loi.length, loi };
}

/**
 * Đường về: Unicode phẳng → lối viết máy đọc được (^, /, sqrt, *).
 * Dùng để đưa công thức trên khung hình vào bộ xác minh toán học — phải kiểm
 * được đáp số thì mới dám nói bài giảng là đúng.
 */
function veAscii(text) {
  let s = String(text || '');
  // Mũ và chỉ số: gom từng cụm liền nhau thành ^( ) và _( ).
  s = s.replace(/[⁰-⁹¹²³ⁿ⁺⁻⁽⁾ᵃ-ᶻᵏ-ᵗ]+/gu, (m) => {
    const t = [...m].map((c) => SIEU_NGUOC[c] ?? '').join('');
    return t ? `^(${t})` : m;
  });
  s = s.replace(/[₀-₉₊₋₍₎ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓ]+/gu, (m) => {
    const t = [...m].map((c) => DUOI_NGUOC[c] ?? '').join('');
    return t ? `_${t}` : m;
  });
  for (const [dep, tho] of Object.entries(PHAN_SO_NGUOC)) s = s.split(dep).join(`(${tho})`);
  s = s.replace(/√\(([^()]*)\)/g, 'sqrt($1)').replace(/√([A-Za-z0-9∆]+)/g, 'sqrt($1)');
  s = s.replace(/∛\(([^()]*)\)/g, '($1)^(1/3)').replace(/∛([A-Za-z0-9]+)/g, '($1)^(1/3)');
  s = s.replace(/⁄/g, '/').replace(/−/g, '-').replace(/·/g, '*').replace(/×/g, '*').replace(/÷/g, '/');
  s = s.replace(/≤/g, '<=').replace(/≥/g, '>=').replace(/≠/g, '!=');
  s = s.replace(/∆/g, 'Delta').replace(/π/g, 'pi');
  return s;
}


// ── Đường thứ hai: Unicode phẳng → LaTeX, để bộ đọc giọng nói dùng ─────────

/** Ký tự chỉ có trong toán — thấy nó là biết đoạn này đang viết công thức. */
const CHU_TOAN = /[⁰-⁹¹²³ⁿ⁺⁻⁽⁾ˣᵐᵏ₀-₉ₙₓₘₖ₊₋₍₎√∛∜∆∇∑∏∫∞°∠⊥∥≤≥≠≈≡±∓·×÷⁄∈∉∋⊂⊆⊃∪∩∅∀∃¬⇒⇔→←↔ℝℕℤℚℂℙ½⅓⅔¼¾⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞−′]/u;
/** Mảnh biểu thức bình thường: số, biến, ngoặc, dấu cộng… */
const MANH_TOAN = /^[0-9A-Za-z()+.,;:=<>{}|[\]'-]+$/;
/** Tên hàm được phép đứng trong công thức dưới dạng chữ. */
const TEN_HAM = new Set(['sqrt', 'sin', 'cos', 'tan', 'cot', 'log', 'ln', 'exp', 'lim', 'max', 'min', 'arcsin', 'arccos', 'arctan']);
/** Một cụm chữ cái thuần từ hai ký tự trở lên là LỜI VĂN ("ta", "cho"), không phải toán. */
const laManhToan = (t) => MANH_TOAN.test(t) && !(/^[A-Za-z]{2,}$/.test(t) && !TEN_HAM.has(t.toLowerCase()));

/** Gom một cụm ký tự mũ (hoặc chỉ số) liền nhau thành chuỗi gốc. */
function _gom(m, bang) { return [...m].map((c) => bang[c] ?? '').join(''); }

/** Đổi MỘT biểu thức Unicode phẳng sang LaTeX. */
function motCongThucVeLatex(bt) {
  let s = String(bt);
  for (const [dep, tho] of Object.entries(PHAN_SO_NGUOC)) {
    const [a, b] = tho.split('/');
    s = s.split(dep).join(`\\dfrac{${a}}{${b}}`);
  }
  s = s.replace(/[⁰-⁹¹²³ⁿ⁺⁻⁽⁾ˣᵐᵏ]+/gu, (m) => `^{${_gom(m, SIEU_NGUOC)}}`);
  s = s.replace(/[₀-₉ₙₓₘₖ₊₋₍₎ₐₑₕᵢⱼₗₒₚᵣₛₜᵤᵥ]+/gu, (m) => `_{${_gom(m, DUOI_NGUOC)}}`);
  // Phân số: lấy trọn toán hạng hai bên dấu ⁄, kể cả khi có ngoặc.
  for (let i = 0; i < 12 && s.includes('⁄'); i++) {
    const k = s.indexOf('⁄');
    const tu = _toanHangTrai(s, k);
    const mau = _toanHangPhai(s, k + 1);
    if (!tu || !mau) { s = s.replace('⁄', '/'); break; }
    s = s.slice(0, tu.dau) + `\\dfrac{${_boNgoacNgoai(tu.chu)}}{${_boNgoacNgoai(mau.chu)}}` + s.slice(mau.het);
  }
  // Không cho ngoặc nhọn vào lớp ký tự này: "\\dfrac{… √∆}{2a}" sẽ bị ngoạm
  // luôn cả "}{2a}" và làm lệch cặp ngoặc của phân số.
  s = s.replace(/√\(([^()]*)\)/g, '\\sqrt{$1}')
    .replace(/√([A-Za-z0-9∆Α-Ωα-ω]+(?:\^\{[^{}]*\})?)/gu, '\\sqrt{$1}');
  s = s.replace(/∛\(([^()]*)\)/g, '\\sqrt[3]{$1}').replace(/∛([A-Za-z0-9∆]+)/g, '\\sqrt[3]{$1}');
  const BANG = [['∆', '\\Delta'], ['−', '-'], ['·', '\\cdot'], ['×', '\\times'], ['÷', '\\div'],
    ['≤', '\\le'], ['≥', '\\ge'], ['≠', '\\ne'], ['≈', '\\approx'], ['±', '\\pm'],
    ['∈', '\\in'], ['∉', '\\notin'], ['⊂', '\\subset'], ['⊆', '\\subseteq'],
    ['∪', '\\cup'], ['∩', '\\cap'], ['∅', '\\emptyset'], ['∀', '\\forall'], ['∃', '\\exists'],
    ['⇒', '\\Rightarrow'], ['⇔', '\\Leftrightarrow'], ['→', '\\to'],
    ['ℝ', '\\mathbb{R}'], ['ℕ', '\\mathbb{N}'], ['ℤ', '\\mathbb{Z}'], ['ℚ', '\\mathbb{Q}'], ['ℂ', '\\mathbb{C}'],
    ['∑', '\\sum'], ['∏', '\\prod'], ['∫', '\\int'], ['∞', '\\infty'], ['π', '\\pi'], ['°', '^{\\circ}']];
  for (const [a, b] of BANG) s = s.split(a).join(b);
  // Lệnh LaTeX phải có ranh giới: "\\pir^{2}" là lệnh không tồn tại, còn
  // "\\pi r^{2}" mới đọc ra "pi nhân r bình phương". Phải liệt kê tường minh
  // từng lệnh, dài trước ngắn sau: dùng /\\[a-zA-Z]+/ thì bộ máy sẽ lùi bước
  // và xẻ đôi luôn "\\dfrac" thành "\\dfra c".
  s = s.replace(/\\(infty|Delta|delta|alpha|beta|gamma|theta|lambda|sigma|omega|varphi|phi|tau|mu|pi|notin|emptyset|subseteq|subset|forall|exists|cdot|times|div|cup|cap|le|ge|ne|pm|to|in)(?=[A-Za-z])/g, '\\$1 ');
  return s;
}

function _boNgoacNgoai(s) {
  const t = s.trim();
  return /^\(.*\)$/.test(t) && canBang(t.slice(1, -1)) ? t.slice(1, -1) : t;
}
/** Toán hạng ngay bên trái vị trí i (có thể là một cụm trong ngoặc). */
function _toanHangTrai(s, i) {
  let j = i - 1;
  while (j >= 0 && s[j] === ' ') j--;
  if (s[j] === ')') {
    let d = 0;
    for (; j >= 0; j--) {
      if (s[j] === ')') d++;
      else if (s[j] === '(') { d--; if (d === 0) break; }
    }
    if (j < 0) return null;
    return { dau: j, chu: s.slice(j, i) };
  }
  const het = j + 1;
  while (j >= 0 && /[0-9A-Za-z^{}_\\]/.test(s[j])) j--;
  return het > j + 1 ? { dau: j + 1, chu: s.slice(j + 1, het) } : null;
}
/** Toán hạng ngay bên phải vị trí i. */
function _toanHangPhai(s, i) {
  let j = i;
  while (j < s.length && s[j] === ' ') j++;
  if (s[j] === '(') {
    let d = 0;
    for (; j < s.length; j++) {
      if (s[j] === '(') d++;
      else if (s[j] === ')') { d--; if (d === 0) { j++; break; } }
    }
    return { het: j, chu: s.slice(i, j) };
  }
  const dau = j;
  while (j < s.length && /[0-9A-Za-z^{}_\\]/.test(s[j])) j++;
  return j > dau ? { het: j, chu: s.slice(dau, j) } : null;
}

/**
 * Tìm các công thức lẫn trong lời văn, đổi sang LaTeX và bọc $…$.
 * Bộ đọc giọng nói (src/voice/speech-text.js) đọc rất chuẩn phần nằm trong
 * $…$ — "x^{2}" thành "ích bình phương". Nhưng nó KHÔNG biết dạng Unicode
 * phẳng: "x²" sẽ bị đọc thành "ích" rồi bỏ rơi dấu mũ. Hàm này là cây cầu
 * giữa dạng ĐẸP TRÊN MÀN HÌNH và dạng ĐỌC ĐƯỢC THÀNH LỜI.
 */
function bocCongThuc(text) {
  const s = String(text || '');
  if (!CHU_TOAN.test(s)) return s;
  const tu = s.split(/(\s+)/);          // giữ nguyên khoảng trắng
  const manh = tu.map((t) => (/^\s+$/.test(t) ? 'trang' : CHU_TOAN.test(t) ? 'manh' : laManhToan(t) ? 'yeu' : 'chu'));

  const ra = [];
  let i = 0;
  while (i < tu.length) {
    if (manh[i] !== 'manh' && manh[i] !== 'yeu') { ra.push(tu[i]); i++; continue; }
    let j = i;
    let coManh = false;
    while (j < tu.length && (manh[j] === 'manh' || manh[j] === 'yeu' || (manh[j] === 'trang' && j + 1 < tu.length && (manh[j + 1] === 'manh' || manh[j + 1] === 'yeu')))) {
      if (manh[j] === 'manh') coManh = true;
      j++;
    }
    let cum = tu.slice(i, j).join('');
    if (!coManh) { ra.push(cum); i = j; continue; }
    // Dấu câu cuối câu không thuộc công thức.
    const duoi = cum.match(/[.,;:!?]+$/);
    if (duoi) cum = cum.slice(0, -duoi[0].length);
    ra.push(`$${motCongThucVeLatex(cum)}$${duoi ? duoi[0] : ''}`);
    i = j;
  }
  return ra.join('');
}

module.exports = {
  chuanHoa, chuanHoaSau, kiemKyHieu, veAscii, bocCongThuc, motCongThucVeLatex,
  lenSieu, xuongDuoi, phanSo, can,
  SIEU, DUOI, SIEU_NGUOC, DUOI_NGUOC, PHAN_SO_DEP, PHAN_SO_NGUOC,
};
