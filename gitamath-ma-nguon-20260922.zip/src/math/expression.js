'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỘ ĐỌC VÀ TÍNH BIỂU THỨC TOÁN
 * ═══════════════════════════════════════════════════════════════════════════
 *  Không dùng eval(). Chuỗi đi vào được phân tích thành cây cú pháp rồi mới
 *  tính — nội dung do mô hình sinh ra là DỮ LIỆU, không bao giờ là mã chạy.
 *
 *  Hỗ trợ: + − × ÷ ^, dấu ngoặc, hàm (sqrt, abs, sin, cos, tan, ln, log,
 *  exp, min, max), hằng (pi, e), biến, nhân ngầm (2x, 3(x+1), x(x+1)),
 *  giai thừa n!, và LaTeX thường gặp (\dfrac, \sqrt, \cdot, ^{}, _{}).
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── LaTeX → biểu thức phẳng ────────────────────────────────────────────────

/** Bóc nội dung cặp ngoặc nhọn bắt đầu tại vị trí i (s[i] === '{'). */
function readBrace(s, i) {
  if (s[i] !== '{') {
    // \sqrt2 hay ^2 — một ký tự là đủ.
    return { body: s[i] ?? '', next: i + 1 };
  }
  let depth = 0;
  for (let j = i; j < s.length; j++) {
    if (s[j] === '{') depth++;
    else if (s[j] === '}') { depth--; if (depth === 0) return { body: s.slice(i + 1, j), next: j + 1 }; }
  }
  return { body: s.slice(i + 1), next: s.length };
}

function latexToPlain(input) {
  let s = String(input ?? '').trim();
  if (!s) return '';

  // Bỏ ký hiệu trình bày không mang nghĩa tính toán.
  s = s.replace(/\$\$?/g, '')
    .replace(/\\(left|right|displaystyle|,|;|!|quad|qquad)\b/g, ' ')
    .replace(/\\(left|right)([([{|.])/g, '$2')
    .replace(/\\text\s*\{([^}]*)\}/g, '$1')
    .replace(/\\mathrm\s*\{([^}]*)\}/g, '$1');

  let out = '';
  for (let i = 0; i < s.length;) {
    if (s[i] !== '\\') { out += s[i++]; continue; }
    const m = s.slice(i).match(/^\\([a-zA-Z]+)/);
    if (!m) { i++; continue; }
    const cmd = m[1];
    let j = i + m[0].length;
    while (s[j] === ' ') j++;

    if (cmd === 'dfrac' || cmd === 'frac' || cmd === 'tfrac') {
      const a = readBrace(s, j);
      let k = a.next; while (s[k] === ' ') k++;
      const b = readBrace(s, k);
      out += `((${latexToPlain(a.body)})/(${latexToPlain(b.body)}))`;
      i = b.next;
      continue;
    }
    if (cmd === 'sqrt') {
      // \sqrt[n]{x} → x^(1/n)
      if (s[j] === '[') {
        const close = s.indexOf(']', j);
        const n = s.slice(j + 1, close);
        const a = readBrace(s, close + 1);
        out += `((${latexToPlain(a.body)})^(1/(${latexToPlain(n)})))`;
        i = a.next;
      } else {
        const a = readBrace(s, j);
        out += `sqrt(${latexToPlain(a.body)})`;
        i = a.next;
      }
      continue;
    }
    if (cmd === 'cdot' || cmd === 'times') { out += '*'; i = j; continue; }
    if (cmd === 'div') { out += '/'; i = j; continue; }
    if (cmd === 'pi') { out += 'pi'; i = j; continue; }
    if (cmd === 'infty') { out += 'Infinity'; i = j; continue; }
    if (cmd === 'le' || cmd === 'leq') { out += '<='; i = j; continue; }
    if (cmd === 'ge' || cmd === 'geq') { out += '>='; i = j; continue; }
    if (cmd === 'ne' || cmd === 'neq') { out += '!='; i = j; continue; }
    if (cmd === 'pm') { out += '±'; i = j; continue; }
    if (['log', 'ln', 'sin', 'cos', 'tan', 'cot', 'exp', 'min', 'max', 'abs'].includes(cmd)) {
      out += cmd; i = j; continue;
    }
    if (cmd === 'lvert' || cmd === 'rvert') { out += '|'; i = j; continue; }
    // Lệnh lạ: bỏ tên lệnh, giữ nội dung.
    i = j;
  }

  // ^{...} và _{...}
  out = out.replace(/\^\s*\{([^{}]*)\}/g, '^($1)').replace(/_\s*\{([^{}]*)\}/g, '_$1');
  return out.replace(/\s+/g, ' ').trim();
}

// ── Tách từ tố ──────────────────────────────────────────────────────────────

const FUNCS = new Set(['sqrt', 'cbrt', 'abs', 'sin', 'cos', 'tan', 'cot', 'asin', 'acos', 'atan',
  'ln', 'log', 'log2', 'log10', 'exp', 'min', 'max', 'floor', 'ceil', 'round', 'sign']);
const CONSTS = { pi: Math.PI, e: Math.E, Infinity: Infinity };

function tokenize(src) {
  const s = String(src);
  const out = [];
  let i = 0;
  const last = () => out[out.length - 1];
  const needsImplicitMul = () => {
    const t = last();
    return t && (t.type === 'num' || t.type === 'var' || t.type === 'const' || (t.type === 'op' && t.v === ')') || (t.type === 'op' && t.v === '!'));
  };

  while (i < s.length) {
    const c = s[i];
    if (c === ' ' || c === '\t' || c === '\n') { i++; continue; }

    if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(s[i + 1] || ''))) {
      let j = i;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      const numText = s.slice(i, j);
      if ((numText.match(/\./g) || []).length > 1) throw new Error(`Số không hợp lệ: ${numText}`);
      if (needsImplicitMul()) out.push({ type: 'op', v: '*', implicit: true });
      out.push({ type: 'num', v: Number(numText) });
      i = j;
      continue;
    }

    if (/[A-Za-z]/.test(c)) {
      let j = i;
      while (j < s.length && /[A-Za-z0-9_]/.test(s[j])) j++;
      let name = s.slice(i, j);
      // Tên hàm phải đứng ngay trước dấu mở ngoặc, nếu không thì là biến.
      let k = j; while (s[k] === ' ') k++;
      if (FUNCS.has(name) && s[k] === '(') {
        if (needsImplicitMul()) out.push({ type: 'op', v: '*', implicit: true });
        out.push({ type: 'func', v: name });
        i = j;
        continue;
      }
      if (name in CONSTS) {
        if (needsImplicitMul()) out.push({ type: 'op', v: '*', implicit: true });
        out.push({ type: 'const', v: name });
        i = j;
        continue;
      }
      // Chuỗi chữ cái liền nhau = tích các biến một chữ (xy = x*y), trừ khi có chỉ số (x_1, a2).
      if (/^[A-Za-z]+$/.test(name) && name.length > 1) {
        for (const ch of name) {
          if (needsImplicitMul()) out.push({ type: 'op', v: '*', implicit: true });
          out.push({ type: 'var', v: ch });
        }
        i = j;
        continue;
      }
      if (needsImplicitMul()) out.push({ type: 'op', v: '*', implicit: true });
      out.push({ type: 'var', v: name });
      i = j;
      continue;
    }

    if (c === '(') {
      if (needsImplicitMul()) out.push({ type: 'op', v: '*', implicit: true });
      out.push({ type: 'op', v: '(' }); i++; continue;
    }
    if (c === ')') { out.push({ type: 'op', v: ')' }); i++; continue; }
    if (c === '|') { out.push({ type: 'op', v: '|' }); i++; continue; }
    if (c === ',') { out.push({ type: 'op', v: ',' }); i++; continue; }
    // Toán tử hai ký tự phải xét TRƯỚC, nếu không "!=" bị đọc thành giai thừa rồi dấu bằng.
    const two = s.slice(i, i + 2);
    if (['<=', '>=', '!=', '=='].includes(two)) { out.push({ type: 'cmp', v: two === '==' ? '=' : two }); i += 2; continue; }
    if (c === '!') { out.push({ type: 'op', v: '!' }); i++; continue; }
    if ('+-*/^'.includes(c)) { out.push({ type: 'op', v: c }); i++; continue; }
    if (c === '×') { out.push({ type: 'op', v: '*' }); i++; continue; }
    if (c === '÷' || c === ':') { out.push({ type: 'op', v: '/' }); i++; continue; }
    if (c === '−' || c === '–') { out.push({ type: 'op', v: '-' }); i++; continue; }
    if (c === '=' || c === '<' || c === '>' || c === '≤' || c === '≥' || c === '≠') {
      out.push({ type: 'cmp', v: c === '≤' ? '<=' : c === '≥' ? '>=' : c === '≠' ? '!=' : c });
      i++; continue;
    }
    throw new Error(`Ký tự không hiểu: "${c}" tại vị trí ${i}`);
  }
  return out;
}

// ── Phân tích cú pháp (leo độ ưu tiên) ──────────────────────────────────────

const PREC = { '+': 1, '-': 1, '*': 2, '/': 2, '^': 4 };
const RIGHT = new Set(['^']);

function parse(src) {
  const toks = tokenize(latexToPlain(src));
  let pos = 0;
  const peek = () => toks[pos];
  const eat = (v) => {
    const t = toks[pos];
    if (!t || (t.v !== v)) throw new Error(`Thiếu "${v}"`);
    pos++;
    return t;
  };

  function parseAtom() {
    const t = peek();
    if (!t) throw new Error('Biểu thức kết thúc đột ngột');
    if (t.type === 'num') { pos++; return { k: 'num', v: t.v }; }
    if (t.type === 'const') { pos++; return { k: 'const', v: t.v }; }
    if (t.type === 'var') { pos++; return { k: 'var', v: t.v }; }
    if (t.type === 'func') {
      pos++;
      eat('(');
      const args = [parseExpr(0)];
      while (peek() && peek().v === ',') { pos++; args.push(parseExpr(0)); }
      eat(')');
      return { k: 'call', f: t.v, args };
    }
    if (t.v === '(') { pos++; const e = parseExpr(0); eat(')'); return e; }
    if (t.v === '|') { pos++; const e = parseExpr(0); eat('|'); return { k: 'call', f: 'abs', args: [e] }; }
    // Dấu trừ đứng trước bám LỎNG hơn luỹ thừa: −2² = −(2²) = −4, không phải (−2)² = 4.
    if (t.v === '-') { pos++; return { k: 'neg', a: parseExpr(PREC['^']) }; }
    if (t.v === '+') { pos++; return parseExpr(PREC['^']); }
    throw new Error(`Không hiểu "${t.v}"`);
  }

  function parseUnary() {
    let node = parseAtom();
    // Hậu tố: giai thừa
    while (peek() && peek().v === '!') { pos++; node = { k: 'call', f: 'fact', args: [node] }; }
    return node;
  }

  function parseExpr(minPrec) {
    let left = parseUnary();
    for (;;) {
      const t = peek();
      if (!t || t.type !== 'op' || !(t.v in PREC)) break;
      const prec = PREC[t.v];
      if (prec < minPrec) break;
      pos++;
      const right = parseExpr(RIGHT.has(t.v) ? prec : prec + 1);
      left = { k: 'bin', op: t.v, a: left, b: right };
    }
    return left;
  }

  // Có toán tử so sánh → quan hệ, không phải biểu thức đơn.
  const leftSide = parseExpr(0);
  const t = peek();
  if (t && t.type === 'cmp') {
    pos++;
    const rightSide = parseExpr(0);
    if (pos !== toks.length) throw new Error(`Thừa ký tự từ vị trí ${pos}`);
    return { k: 'rel', op: t.v, a: leftSide, b: rightSide };
  }
  if (pos !== toks.length) throw new Error(`Thừa ký tự: "${toks[pos].v}"`);
  return leftSide;
}

// ── Tính giá trị ────────────────────────────────────────────────────────────

const FN = {
  sqrt: (x) => (x < 0 ? NaN : Math.sqrt(x)),
  cbrt: Math.cbrt,
  abs: Math.abs,
  sin: Math.sin, cos: Math.cos, tan: Math.tan,
  cot: (x) => 1 / Math.tan(x),
  asin: Math.asin, acos: Math.acos, atan: Math.atan,
  ln: (x) => (x <= 0 ? NaN : Math.log(x)),
  log: (x, b) => (b === undefined ? (x <= 0 ? NaN : Math.log10(x)) : (x <= 0 || b <= 0 || b === 1 ? NaN : Math.log(x) / Math.log(b))),
  log2: (x) => (x <= 0 ? NaN : Math.log2(x)),
  log10: (x) => (x <= 0 ? NaN : Math.log10(x)),
  exp: Math.exp,
  min: Math.min, max: Math.max,
  floor: Math.floor, ceil: Math.ceil, round: Math.round, sign: Math.sign,
  fact: (n) => {
    if (!Number.isInteger(n) || n < 0 || n > 170) return NaN;
    let r = 1; for (let i = 2; i <= n; i++) r *= i;
    return r;
  },
};

function evaluate(node, vars = {}) {
  switch (node.k) {
    case 'num': return node.v;
    case 'const': return CONSTS[node.v];
    case 'var': {
      if (!(node.v in vars)) throw new Error(`Chưa gán giá trị cho biến "${node.v}"`);
      return vars[node.v];
    }
    case 'neg': return -evaluate(node.a, vars);
    case 'call': {
      const f = FN[node.f];
      if (!f) throw new Error(`Không có hàm "${node.f}"`);
      return f(...node.args.map((a) => evaluate(a, vars)));
    }
    case 'bin': {
      const a = evaluate(node.a, vars);
      const b = evaluate(node.b, vars);
      switch (node.op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return b === 0 ? NaN : a / b;
        case '^': {
          // (số âm)^(số thập phân) không có nghĩa trên tập thực.
          if (a < 0 && !Number.isInteger(b)) return NaN;
          return Math.pow(a, b);
        }
        default: throw new Error(`Toán tử lạ ${node.op}`);
      }
    }
    case 'rel': {
      const a = evaluate(node.a, vars);
      const b = evaluate(node.b, vars);
      switch (node.op) {
        case '=': return Math.abs(a - b) < 1e-9;
        case '<': return a < b;
        case '>': return a > b;
        case '<=': return a <= b + 1e-12;
        case '>=': return a >= b - 1e-12;
        case '!=': return Math.abs(a - b) >= 1e-9;
        default: throw new Error(`Quan hệ lạ ${node.op}`);
      }
    }
    default: throw new Error(`Nút lạ ${node.k}`);
  }
}

/** Danh sách biến xuất hiện trong cây, đã sắp thứ tự. */
function variables(node, out = new Set()) {
  if (!node || typeof node !== 'object') return out;
  if (node.k === 'var') out.add(node.v);
  for (const key of ['a', 'b']) if (node[key]) variables(node[key], out);
  if (node.args) for (const a of node.args) variables(a, out);
  return out;
}

/** In lại cây thành chuỗi chuẩn hoá — dùng để so sánh và hiển thị. */
function stringify(node) {
  switch (node.k) {
    case 'num': return String(node.v);
    case 'const': return node.v;
    case 'var': return node.v;
    case 'neg': return `-${stringify(node.a)}`;
    case 'call': return `${node.f}(${node.args.map(stringify).join(', ')})`;
    case 'bin': return `(${stringify(node.a)} ${node.op} ${stringify(node.b)})`;
    case 'rel': return `${stringify(node.a)} ${node.op} ${stringify(node.b)}`;
    default: return '?';
  }
}

module.exports = { parse, evaluate, variables, stringify, latexToPlain, tokenize, FUNCS, CONSTS };
