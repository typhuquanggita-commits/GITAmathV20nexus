'use strict';
/**
 * GITAmath Nexus V20 — Configuration
 * Mọi giá trị đều có mặc định chạy được. Không có biến môi trường nào là bắt buộc.
 */

const fs = require('node:fs');
const path = require('node:path');

// Nạp .env nếu có, không ghi đè biến môi trường đã tồn tại.
(function loadDotEnv() {
  const file = path.join(__dirname, '..', '.env');
  if (!fs.existsSync(file)) return;
  for (const raw of fs.readFileSync(file, 'utf8').split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  }
})();

const num = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));
const bool = (v, d) => (v === undefined || v === '' ? d : /^(1|true|yes|on)$/i.test(String(v)));

const cfg = {
  VERSION: '20.0.0',
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: num(process.env.PORT, 9999),
  HOST: process.env.HOST || '0.0.0.0',

  // ── Hạ tầng: để trống thì dùng adapter in-memory, hệ thống vẫn chạy đầy đủ ──
  REDIS_URL: process.env.REDIS_URL || '',

  // ── Lực lượng agent ──
  AGENT_TOTAL: num(process.env.AGENT_TOTAL, 500),
  AGENT_GLOBAL_CONCURRENCY: num(process.env.AGENT_GLOBAL_CONCURRENCY, 64),
  AGENT_TOKENS_PER_MIN: num(process.env.AGENT_TOKENS_PER_MIN, 600000),

  // ── Ngưỡng KPI (điều A16 hiến pháp: ≥ 98% pass rate tại inspectors) ──
  KPI: {
    successRate: num(process.env.KPI_SUCCESS_RATE, 0.9),
    qualityScore: num(process.env.KPI_QUALITY_SCORE, 0.85),
    p95LatencyMs: num(process.env.KPI_P95_LATENCY_MS, 5000),
    costPerTaskUsd: num(process.env.KPI_COST_PER_TASK_USD, 0.001),
    utilization: num(process.env.KPI_UTILIZATION, 0.6),
    coachThreshold: num(process.env.KPI_COACH_THRESHOLD, 0.9),
  },

  // ── LLM ──
  LLM: {
    timeoutMs: num(process.env.LLM_TIMEOUT_MS, 30000),
    maxRetries: num(process.env.LLM_MAX_RETRIES, 2),
    breakerThreshold: num(process.env.LLM_BREAKER_THRESHOLD, 5),
    breakerCooldownMs: num(process.env.LLM_BREAKER_COOLDOWN_MS, 60000),
    allowMock: bool(process.env.LLM_ALLOW_MOCK, true),
    keys: {
      groq: process.env.GROQ_API_KEY || '',
      cerebras: process.env.CEREBRAS_API_KEY || '',
      google: process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || '',
      openai: process.env.OPENAI_API_KEY || '',
      anthropic: process.env.ANTHROPIC_API_KEY || '',
      nvidia: process.env.NVIDIA_API_KEY || '',
    },
  },

  // ── Định tuyến thích ứng (Thompson Sampling) ──
  ROUTER: {
    epsilon: num(process.env.ROUTER_EPSILON, 0.15),
    decayAt: num(process.env.ROUTER_DECAY_AT, 1000),
    weights: {
      quality: num(process.env.ROUTER_W_QUALITY, 0.6),
      cost: num(process.env.ROUTER_W_COST, 0.3),
      latency: num(process.env.ROUTER_W_LATENCY, 0.1),
    },
  },

  // ── Hàng đợi ──
  QUEUE: {
    concurrency: num(process.env.QUEUE_CONCURRENCY, 16),
    maxAttempts: num(process.env.QUEUE_MAX_ATTEMPTS, 3),
    backlogAlert: num(process.env.QUEUE_BACKLOG_ALERT, 500),
  },

  // ── Orchestrator ──
  RUN_TTL_SEC: num(process.env.RUN_TTL_SEC, 86400),

  // ── Giọng nói giảng viên ──
  VOICE: {
    // Bộ tổng hợp mặc định chạy ngay trong tiến trình, không cần mạng, không cần khoá.
    provider: process.env.VOICE_PROVIDER || 'offline',
    sampleRate: num(process.env.VOICE_SAMPLE_RATE, 22050),
    cacheMax: num(process.env.VOICE_CACHE_MAX, 256),
    maxChars: num(process.env.VOICE_MAX_CHARS, 4000),
    // Đường dẫn tới piper (bộ tổng hợp nơ-ron chạy cục bộ) nếu máy có cài.
    piperBin: process.env.PIPER_BIN || '',
    piperModel: process.env.PIPER_MODEL || '',
    // Bộ tổng hợp nơ-ron tiếng Việt. Mỗi bộ nhận một trong hai cách gọi:
    // máy chủ HTTP cục bộ (…_URL) hoặc chạy trực tiếp bằng Python (…_DIR).
    zeroTtsUrl: process.env.ZEROTTS_URL || '',
    zeroTtsDir: process.env.ZEROTTS_DIR || '',
    vieNeuUrl: process.env.VIENEU_URL || '',
    vieNeuDir: process.env.VIENEU_DIR || '',
    gOmniUrl: process.env.GOMNIVOICE_URL || '',
    gOmniDir: process.env.GOMNIVOICE_DIR || '',
    pythonBin: process.env.PYTHON_BIN || 'python3',
    // edge-tts: giọng nơ-ron của Microsoft, miễn phí, không cần khoá.
    // Cài bằng: pip3 install edge-tts
    edgeBin: process.env.EDGE_TTS_BIN || 'edge-tts',
    edgeVoiceNu: process.env.EDGE_VOICE_FEMALE || 'vi-VN-HoaiMyNeural',
    edgeVoiceNam: process.env.EDGE_VOICE_MALE || 'vi-VN-NamMinhNeural',
    // Hát: tổng hợp giọng hát (SVS) và chuyển đổi giọng hát (SVC).
    soulxDir: process.env.SOULX_SINGER_DIR || '',
    openUtauBin: process.env.OPENUTAU_BIN || '',
    openUtauVoicebank: process.env.OPENUTAU_VOICEBANK || '',
    soVitsDir: process.env.SOVITS_SVC_DIR || '',
    soVitsModel: process.env.SOVITS_SVC_MODEL || '',
    ffmpegBin: process.env.FFMPEG_BIN || '',
    // Hậu kỳ mặc định cho lời giảng.
    studioPreset: process.env.VOICE_STUDIO_PRESET || 'giang-bai',
    studioEnabled: bool(process.env.VOICE_STUDIO, true),
    // Trần thời lượng một bài hát (giây) — chặn yêu cầu dựng cả album.
    maxSongSeconds: num(process.env.VOICE_MAX_SONG_SECONDS, 300),
    // Khoá dịch vụ đám mây — để trống thì nhà cung cấp đó báo "chưa sẵn sàng".
    elevenLabsKey: process.env.ELEVENLABS_API_KEY || '',
    azureKey: process.env.AZURE_SPEECH_KEY || '',
    azureRegion: process.env.AZURE_SPEECH_REGION || 'southeastasia',
    googleKey: process.env.GOOGLE_TTS_API_KEY || process.env.GOOGLE_API_KEY || '',
    // Cổng dịch không chính thức: TẮT mặc định, chỉ bật khi người vận hành
    // tự chịu trách nhiệm (xem src/voice/providers.js).
    allowUnofficial: bool(process.env.VOICE_ALLOW_UNOFFICIAL, false),
    // Pháp lý (Luật An ninh mạng 116/2025/QH15)
    watermark: bool(process.env.VOICE_WATERMARK, true),
    retentionDays: num(process.env.VOICE_RETENTION_DAYS, 180),
    minorAge: num(process.env.VOICE_MINOR_AGE, 18),
  },

  // ── Sản xuất phim ──
  FILM: {
    // Cổng dựng video. Để trống thì hệ thống chỉ dựng được bản nháp
    // (bảng phân cảnh + đường tiếng + phim nháp) — vẫn đủ để duyệt nhịp phim.
    falKey: process.env.FAL_KEY || process.env.KHOA_FAL || '',
    // Trần chi tiêu cho MỘT phim. Vượt là chặn, không hỏi lại.
    tranChiTieuUsd: num(process.env.FILM_MAX_USD, 25),
    // Bắt buộc xác nhận trước khi gọi API tính tiền.
    batBuocXacNhan: bool(process.env.FILM_REQUIRE_CONFIRM, true),
    uuTien: process.env.FILM_PRIORITY || 'can-bang',
    chatLuong: process.env.FILM_QUALITY || 'hd',
    thuMuc: process.env.FILM_DIR || '',
    // Trần thời lượng một phim (giây) — chặn yêu cầu dựng cả tập phim.
    tranGiay: num(process.env.FILM_MAX_SECONDS, 600),
  },

  // ── Xưởng ảnh ──
  PHOTO: {
    // mien-phi | tai-may | hon-hop | co-khoa
    cheDo: process.env.PHOTO_MODE || 'mien-phi',
    // Cổng miễn phí không cần khoá. Đổi được để trỏ về máy chủ nội bộ.
    pollinationsUrl: process.env.POLLINATIONS_URL || 'https://image.pollinations.ai',
    comfyUrl: process.env.COMFYUI_URL || 'http://127.0.0.1:8188',
    comfyModel: process.env.COMFYUI_MODEL || 'flux1-schnell.safetensors',
    hfKey: process.env.HF_TOKEN || '',
    hfModel: process.env.HF_MODEL || 'black-forest-labs/FLUX.1-schnell',
    // hd | 2k | 4k | 8k
    chatLuong: process.env.PHOTO_QUALITY || '4k',
    mayAnh: process.env.PHOTO_CAMERA || 'Fujifilm',
    phim: process.env.PHOTO_FILM || 'Khong',
    // Trần số điểm ảnh cho một lần xử lý — chặn yêu cầu làm nổ bộ nhớ.
    tranMegapixel: num(process.env.PHOTO_MAX_MP, 36),
    tranByteVao: num(process.env.PHOTO_MAX_INPUT_BYTES, 25 * 1024 * 1024),
    chatLuongJpeg: num(process.env.PHOTO_JPEG_QUALITY, 94),
  },

  // ── Bài giảng: một lệnh ra một tệp video có tiếng ──
  // Mặc định để 'hd' vì đây là độ phân giải xem được trên máy chiếu lớp học
  // mà vẫn dựng xong trong vài giây; 'full-hd' nặng gấp hơn hai lần.
  BAIGIANG: {
    kho: process.env.LESSON_QUALITY || 'hd',
    chatLuongJpeg: num(process.env.LESSON_JPEG_QUALITY, 86),
    thuMuc: process.env.LESSON_OUT_DIR || path.join(process.cwd(), 'data', 'bai-giang'),
    tranPhut: num(process.env.LESSON_MAX_MINUTES, 30),
  },

  // ── Trang công khai (SEO) ──
  // Địa chỉ gốc phải là địa chỉ THẬT khi phát hành: thẻ canonical và sitemap
  // trỏ sai tên miền thì công cụ tìm kiếm bỏ qua cả trang.
  WEB: {
    diaChiGoc: process.env.WEB_BASE_URL || 'https://gitamath.vn',
    tenToChuc: process.env.WEB_ORG_NAME || 'GITAmath',
    moTaToChuc: process.env.WEB_ORG_DESC
      || 'Hệ thống dạy và học Toán theo chương trình phân tầng, đo được tiến bộ của từng học viên.',
    lienHe: process.env.WEB_CONTACT || '',
    bat: process.env.WEB_PUBLIC !== '0',
  },

  // ── Quản trị ──
  RATE_LIMIT_PER_MIN: num(process.env.RATE_LIMIT_PER_MIN, 200),
  AUDIT_RETENTION_DAYS: num(process.env.AUDIT_RETENTION_DAYS, 365),
  LOG_LEVEL: process.env.LOG_LEVEL || 'info',
};

cfg.hasAnyLLMKey = Object.values(cfg.LLM.keys).some(Boolean);

module.exports = cfg;
