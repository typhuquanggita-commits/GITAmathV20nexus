'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  GIAO VIỆC CÓ HỢP ĐỒNG — "bắt buộc phải hiểu nhau"
 * ═══════════════════════════════════════════════════════════════════════════
 *  Agent không được đoán ý nhau. Mỗi lần giao việc là một HỢP ĐỒNG:
 *
 *    1. OFFER    bên giao nêu rõ: mục tiêu · đầu vào · định dạng đầu ra ·
 *                tiêu chí nghiệm thu · thời hạn
 *    2. ACK      bên nhận phải xác nhận hiểu, tóm tắt lại yêu cầu bằng lời mình
 *    3. CLARIFY  không hiểu thì HỎI LẠI, tuyệt đối không được đoán rồi làm
 *    4. DELIVER  nộp kết quả đúng định dạng đã cam kết
 *    5. ACCEPT   bên giao nghiệm thu theo đúng tiêu chí đã nêu
 *
 *  Hợp đồng không được ACK thì không có việc nào được chạy.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { id: newId, round, viKey } = require('../utils');
const { taskTypeForDivision } = require('../agents/taxonomy');

const STATE = {
  OFFERED: 'OFFERED',
  ACKED: 'ACKED',
  CLARIFYING: 'CLARIFYING',
  DELIVERED: 'DELIVERED',
  ACCEPTED: 'ACCEPTED',
  REJECTED: 'REJECTED',
  EXPIRED: 'EXPIRED',
};

/** Ngưỡng hiểu: bản tóm tắt của bên nhận phải phủ được các từ khoá của yêu cầu. */
const UNDERSTANDING_THRESHOLD = 0.5;

class HandoffRegistry {
  constructor({ runtime, scheduler, audit }) {
    this.runtime = runtime;
    this.scheduler = scheduler;
    this.audit = audit;
    this.contracts = new Map();
    this.stats = { offered: 0, acked: 0, clarified: 0, delivered: 0, accepted: 0, rejected: 0, misunderstood: 0 };
  }

  /** 1. OFFER — bên giao mô tả việc theo khuôn bắt buộc. */
  offer({ fromAgentId, toAgentId, goal, inputs = {}, outputFormat, acceptance = [], deadlineMs = 120000, missionId = null }) {
    if (!goal || !outputFormat || !acceptance.length) {
      return { ok: false, error: 'INCOMPLETE_CONTRACT', need: ['goal', 'outputFormat', 'acceptance[]'] };
    }
    const c = {
      id: newId('HO'),
      missionId,
      fromAgentId,
      toAgentId,
      goal,
      inputs,
      outputFormat,
      acceptance,
      state: STATE.OFFERED,
      offeredAt: Date.now(),
      deadlineAt: Date.now() + deadlineMs,
      ack: null,
      clarifications: [],
      delivery: null,
      review: null,
      understanding: null,
    };
    this.contracts.set(c.id, c);
    this.stats.offered++;
    bus.safeEmit('handoff:offered', { contractId: c.id, fromAgentId, toAgentId });
    return { ok: true, contract: this._view(c) };
  }

  /** Bản tóm tắt yêu cầu mà bên giao mong bên nhận hiểu được. */
  _briefText(c) {
    return [
      `MỤC TIÊU: ${c.goal}`,
      `ĐẦU VÀO: ${JSON.stringify(c.inputs)}`,
      `ĐỊNH DẠNG ĐẦU RA: ${c.outputFormat}`,
      `TIÊU CHÍ NGHIỆM THU:\n${c.acceptance.map((a, i) => `  ${i + 1}. ${a}`).join('\n')}`,
      `HẠN: ${new Date(c.deadlineAt).toISOString()}`,
    ].join('\n');
  }

  /** Đo mức hiểu: tóm tắt của bên nhận phủ bao nhiêu phần từ khoá của yêu cầu. */
  _understanding(c, restatement) {
    const want = new Set(
      viKey(`${c.goal} ${c.outputFormat} ${c.acceptance.join(' ')}`)
        .split(/\s+/).filter((w) => w.length > 3)
    );
    if (!want.size) return 1;
    const got = new Set(viKey(String(restatement)).split(/\s+/));
    let hit = 0;
    for (const w of want) if (got.has(w)) hit++;
    return round(hit / want.size, 3);
  }

  /**
   * 2/3. Bên nhận đọc hợp đồng rồi ACK hoặc CLARIFY.
   * Bên nhận PHẢI tóm tắt lại bằng lời mình — đó là bằng chứng đã hiểu.
   */
  async acknowledge(contractId) {
    const c = this.contracts.get(contractId);
    if (!c) return { ok: false, error: 'CONTRACT_NOT_FOUND' };
    if (c.state !== STATE.OFFERED && c.state !== STATE.CLARIFYING) {
      return { ok: false, error: 'WRONG_STATE', state: c.state };
    }
    if (Date.now() > c.deadlineAt) { c.state = STATE.EXPIRED; return { ok: false, error: 'EXPIRED' }; }

    const agent = this.runtime.get(c.toAgentId);
    if (!agent) return { ok: false, error: 'AGENT_NOT_FOUND' };

    const r = await this.runtime.run(c.toAgentId, {
      type: taskTypeForDivision(agent.division),
      allowCache: false, maxTokens: 500, temperature: 0.2,
      input:
        `Bạn được giao một việc. ĐỪNG LÀM VIỆC ĐÓ NGAY.\n` +
        `Trước hết hãy chứng minh bạn đã hiểu, theo đúng định dạng:\n` +
        `TÓM TẮT: <diễn đạt lại yêu cầu bằng lời của bạn>\n` +
        `SẴN SÀNG: CÓ hoặc KHÔNG\n` +
        `HỎI LẠI: <câu hỏi nếu có điểm chưa rõ, để trống nếu đã rõ>\n\n` +
        `HỢP ĐỒNG:\n${this._briefText(c)}`,
    });
    if (!r.ok) return { ok: false, error: 'ACK_FAILED', detail: r.error };

    const out = String(r.output);
    const restatement = (out.match(/TÓM TẮT\s*:\s*([\s\S]*?)(?=\n\s*(?:SẴN SÀNG|HỎI LẠI)\s*:|$)/i) || [])[1]?.trim() || '';
    const ready = /SẴN SÀNG\s*:\s*CÓ/i.test(out);
    const question = (out.match(/HỎI LẠI\s*:\s*(.+)/i) || [])[1]?.trim() || '';

    const score = this._understanding(c, restatement);
    c.understanding = { score, restatement, at: Date.now() };

    // Không đủ hiểu, hoặc tự nhận chưa sẵn sàng, hoặc có câu hỏi → chuyển sang hỏi lại
    if (!ready || score < UNDERSTANDING_THRESHOLD || question) {
      c.state = STATE.CLARIFYING;
      c.clarifications.push({ at: Date.now(), from: c.toAgentId, question: question || 'Chưa nắm rõ yêu cầu', score });
      this.stats.clarified++;
      if (score < UNDERSTANDING_THRESHOLD) this.stats.misunderstood++;
      bus.safeEmit('handoff:clarify', { contractId: c.id, score });
      return { ok: false, error: 'NEEDS_CLARIFICATION', understanding: score, question: question || null, restatement };
    }

    c.state = STATE.ACKED;
    c.ack = { at: Date.now(), agentId: c.toAgentId, score };
    this.stats.acked++;
    bus.safeEmit('handoff:acked', { contractId: c.id, score });
    return { ok: true, understanding: score, restatement, state: c.state };
  }

  /** 3. Bên giao trả lời câu hỏi, bổ sung vào hợp đồng rồi mời ACK lại. */
  clarify(contractId, answer, extraAcceptance = []) {
    const c = this.contracts.get(contractId);
    if (!c) return { ok: false, error: 'CONTRACT_NOT_FOUND' };
    c.clarifications.push({ at: Date.now(), from: c.fromAgentId, answer });
    if (extraAcceptance.length) c.acceptance.push(...extraAcceptance);
    c.goal = `${c.goal}\n[Làm rõ] ${answer}`;
    c.state = STATE.OFFERED;
    return { ok: true, state: c.state, clarifications: c.clarifications.length };
  }

  /** 4. DELIVER — chỉ chạy được sau khi đã ACK. */
  async deliver(contractId) {
    const c = this.contracts.get(contractId);
    if (!c) return { ok: false, error: 'CONTRACT_NOT_FOUND' };
    if (c.state !== STATE.ACKED) return { ok: false, error: 'NOT_ACKED', state: c.state, hint: 'Phải acknowledge() trước' };
    if (Date.now() > c.deadlineAt) { c.state = STATE.EXPIRED; return { ok: false, error: 'EXPIRED' }; }

    const agent = this.runtime.get(c.toAgentId);
    const r = await this.runtime.run(c.toAgentId, {
      type: taskTypeForDivision(agent?.division),
      allowCache: false, maxTokens: 1200,
      input: `Thực hiện việc đã nhận. Trả về ĐÚNG định dạng đã cam kết.\n\n${this._briefText(c)}`,
    });
    if (!r.ok) { c.state = STATE.REJECTED; this.stats.rejected++; return { ok: false, error: 'DELIVERY_FAILED', detail: r.error }; }

    c.delivery = { at: Date.now(), output: r.output, ms: r.ms, provider: r.provider };
    c.state = STATE.DELIVERED;
    this.stats.delivered++;
    return { ok: true, state: c.state, output: r.output, ms: r.ms };
  }

  /** 5. ACCEPT — nghiệm thu theo đúng tiêu chí đã nêu, do một Critic độc lập chấm. */
  async accept(contractId) {
    const c = this.contracts.get(contractId);
    if (!c) return { ok: false, error: 'CONTRACT_NOT_FOUND' };
    if (c.state !== STATE.DELIVERED) return { ok: false, error: 'NOT_DELIVERED', state: c.state };

    // Thanh tra phải cùng khối với người làm, nếu không sẽ vi phạm điều A13.
    const receiver = this.runtime.get(c.toAgentId);
    const reviewType = taskTypeForDivision(receiver?.division);
    const critic = this.scheduler.select(reviewType, { rank: 'CRITIC', exclude: [c.fromAgentId, c.toAgentId] });
    let passed = [], failed = [];
    if (critic) {
      const r = await this.runtime.run(critic.id, {
        type: taskTypeForDivision(critic.division), allowCache: false, maxTokens: 500, temperature: 0.1,
        input:
          `Nghiệm thu kết quả theo từng tiêu chí. Mỗi dòng một tiêu chí, định dạng "n: ĐẠT" hoặc "n: KHÔNG ĐẠT — lý do".\n\n` +
          `TIÊU CHÍ:\n${c.acceptance.map((a, i) => `${i + 1}. ${a}`).join('\n')}\n\n` +
          `KẾT QUẢ NỘP:\n${String(c.delivery.output).slice(0, 3000)}`,
      });
      if (r.ok) {
        c.acceptance.forEach((a, i) => {
          const m = String(r.output).match(new RegExp(`^\\s*${i + 1}\\s*:\\s*(ĐẠT|KHÔNG ĐẠT)(.*)$`, 'im'));
          if (m && /^ĐẠT/i.test(m[1])) passed.push(a); else failed.push({ criterion: a, note: m?.[2]?.trim() || 'không rõ' });
        });
        c.review = { criticId: critic.id, raw: r.output };
      }
    }
    // Không có Critic thì coi như chưa nghiệm thu được, KHÔNG mặc định là đạt.
    if (!critic || (!passed.length && !failed.length)) {
      failed = c.acceptance.map((a) => ({ criterion: a, note: 'chưa có thanh tra nghiệm thu' }));
    }

    const ok = failed.length === 0;
    c.state = ok ? STATE.ACCEPTED : STATE.REJECTED;
    if (ok) this.stats.accepted++; else this.stats.rejected++;

    this.audit?.record({
      actor: c.toAgentId, action: 'handoff.accept', verdict: ok ? 'ALLOW' : 'DENY', severity: ok ? 0 : 1,
      detail: { contractId: c.id, passed: passed.length, failed: failed.length },
    });

    return { ok, state: c.state, passed, failed, criticId: critic?.id, output: ok ? c.delivery.output : null };
  }

  /** Chạy trọn vòng đời một hợp đồng. Dùng trong tổng động viên. */
  async run(spec) {
    const o = this.offer(spec);
    if (!o.ok) return o;
    const id = o.contract.id;

    let ack = await this.acknowledge(id);
    if (!ack.ok && ack.error === 'NEEDS_CLARIFICATION') {
      // Bên giao trả lời một lần rồi mời hiểu lại.
      this.clarify(id, `Làm đúng định dạng đã nêu; nếu thiếu dữ liệu thì ghi rõ "THIẾU: <mục>".`);
      ack = await this.acknowledge(id);
    }
    if (!ack.ok) return { ok: false, contractId: id, stage: 'ack', ...ack };

    const del = await this.deliver(id);
    if (!del.ok) return { ok: false, contractId: id, stage: 'deliver', ...del };

    const acc = await this.accept(id);
    return { ok: acc.ok, contractId: id, stage: 'accept', understanding: ack.understanding, ...acc };
  }

  _view(c) {
    return {
      id: c.id, missionId: c.missionId, from: c.fromAgentId, to: c.toAgentId,
      goal: c.goal, outputFormat: c.outputFormat, acceptance: c.acceptance,
      state: c.state, understanding: c.understanding?.score ?? null,
      clarifications: c.clarifications.length,
      deadlineAt: new Date(c.deadlineAt).toISOString(),
    };
  }

  get(contractId) { const c = this.contracts.get(contractId); return c ? this._view(c) : null; }

  list({ missionId = null, state = null, limit = 50 } = {}) {
    let arr = [...this.contracts.values()];
    if (missionId) arr = arr.filter((c) => c.missionId === missionId);
    if (state) arr = arr.filter((c) => c.state === state);
    return arr.slice(-limit).map((c) => this._view(c));
  }

  status() {
    const byState = Object.create(null);
    for (const c of this.contracts.values()) byState[c.state] = (byState[c.state] || 0) + 1;
    const scores = [...this.contracts.values()].map((c) => c.understanding?.score).filter((x) => x != null);
    return {
      contracts: this.contracts.size,
      byState,
      ...this.stats,
      avgUnderstanding: scores.length ? round(scores.reduce((a, b) => a + b, 0) / scores.length, 3) : 0,
      understandingThreshold: UNDERSTANDING_THRESHOLD,
    };
  }
}

module.exports = HandoffRegistry;
module.exports.STATE = STATE;
module.exports.UNDERSTANDING_THRESHOLD = UNDERSTANDING_THRESHOLD;
