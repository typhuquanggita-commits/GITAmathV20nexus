'use strict';
/**
 * Guardrails — kiểm tra đầu vào rẻ tiền, chạy trước mọi thứ khác.
 * Rate limit dùng SLIDING WINDOW (bản cũ dùng fixed window nên bị bypass ở ranh giới cửa sổ).
 */

const cfg = require('../config');

/** Luhn — chỉ coi là số thẻ khi thực sự hợp lệ, tránh báo nhầm mọi dãy 13–19 chữ số. */
function isLuhn(digits) {
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = digits.charCodeAt(i) - 48;
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d; alt = !alt;
  }
  return sum % 10 === 0;
}

const RE_PII = [
  { name: 'cccd_cmnd', re: /\b\d{9,12}\b/ },
  {
    name: 'credit_card',
    test: (s) => {
      for (const m of s.matchAll(/\b(?:\d[ -]?){12,18}\d\b/g)) {
        const d = m[0].replace(/[^\d]/g, '');
        if (d.length >= 13 && d.length <= 19 && isLuhn(d)) return true;
      }
      return false;
    },
  },
  { name: 'email', re: /[\w.+-]+@[\w-]+\.[\w.]{2,}/ },
  { name: 'phone_vn', re: /\b(?:0|\+84)(?:3|5|7|8|9)\d{8}\b/ },
];

const RE_UNSAFE = [
  { name: 'exploit', re: /\b(eval\s*\(|exec\s*\(|rm\s+-rf|drop\s+table|;\s*--)/i },
  { name: 'path_traversal', re: /\.\.\//},
  { name: 'ransom', re: /(encrypt\s+all\s+files|delete\s+all\s+data|format\s+c:)/i },
];

const MAX_INPUT = 32000;

class Guardrails {
  constructor() {
    this.buckets = new Map(); // key -> number[] timestamps
    this.stats = { checks: 0, blocked: 0, rateLimited: 0, piiFlags: 0, byReason: Object.create(null) };
    this._gc = setInterval(() => this._sweep(), 60_000);
    if (this._gc.unref) this._gc.unref();
  }

  _sweep() {
    const cutoff = Date.now() - 60_000;
    for (const [k, arr] of this.buckets) {
      const kept = arr.filter((t) => t > cutoff);
      if (kept.length) this.buckets.set(k, kept);
      else this.buckets.delete(k); // dọn bucket rỗng — sửa rò rỉ bộ nhớ #11 báo cáo IRON
    }
  }

  /** Sliding window 60s. */
  rateLimit(key, max = cfg.RATE_LIMIT_PER_MIN) {
    const now = Date.now();
    const cutoff = now - 60_000;
    const arr = (this.buckets.get(key) || []).filter((t) => t > cutoff);
    if (arr.length >= max) {
      this.stats.rateLimited++;
      return { ok: false, reason: 'RATE_LIMIT', retryAfterMs: Math.max(0, arr[0] + 60_000 - now) };
    }
    arr.push(now);
    this.buckets.set(key, arr);
    return { ok: true, remaining: max - arr.length };
  }

  _fail(reason, detail) {
    this.stats.blocked++;
    this.stats.byReason[reason] = (this.stats.byReason[reason] || 0) + 1;
    return { ok: false, reason, detail };
  }

  checkInput(input, { allowPII = false } = {}) {
    this.stats.checks++;
    if (typeof input !== 'string' || !input.trim()) return this._fail('EMPTY_INPUT');
    if (input.length > MAX_INPUT) return this._fail('INPUT_TOO_LARGE', `${input.length} > ${MAX_INPUT}`);

    for (const { name, re } of RE_UNSAFE) {
      if (re.test(input)) return this._fail('UNSAFE_PATTERN', name);
    }

    const pii = [];
    for (const p of RE_PII) {
      const hit = p.test ? p.test(input) : p.re.test(input);
      if (hit) pii.push(p.name);
    }
    if (pii.length) {
      this.stats.piiFlags++;
      if (!allowPII) return this._fail('PII_DETECTED', pii.join(','));
    }

    return { ok: true, pii };
  }

  /** Che thông tin cá nhân trước khi ghi log (điều A04). */
  redact(text) {
    let out = String(text);
    out = out.replace(/[\w.+-]+@[\w-]+\.[\w.]{2,}/g, '[email]');
    out = out.replace(/\b(?:0|\+84)(?:3|5|7|8|9)\d{8}\b/g, '[phone]');
    out = out.replace(/\b\d{9,12}\b/g, '[id]');
    return out;
  }

  stop() { clearInterval(this._gc); }

  status() {
    return {
      ...this.stats,
      activeBuckets: this.buckets.size,
      limitPerMin: cfg.RATE_LIMIT_PER_MIN,
      byReason: Object.entries(this.stats.byReason).sort((a, b) => b[1] - a[1]).slice(0, 8),
    };
  }
}

module.exports = Guardrails;
