'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỨC TƯỜNG — NGĂN CÂY TIỀN LỌT RA MẶT KHÁCH HÀNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Luật một câu: MỌI THỨ TRONG src/cay-tien/ CHỈ DÀNH CHO VAI QUẢN TRỊ.
 *
 *  Vì sao phải có một tệp riêng chỉ để canh một luật? Vì luật này thuộc loại
 *  luật KHÔNG ĐƯỢC PHÉP hỏng một lần. Một lần rò rỉ là một gia đình đọc thấy
 *  mình bị hệ thống xếp vào "Cây chớm héo", và chuyện đó không sửa lại được
 *  bằng một bản vá. Luật nào chỉ tồn tại trong trí nhớ người viết mã thì sớm
 *  muộn cũng hỏng, nên luật này được viết thành PHÉP ĐO chạy trong bộ kiểm:
 *  quét toàn bộ trang công khai và cả bốn vai trong khu riêng, thấy một chữ
 *  của bảng dưới đây là trượt.
 *
 *  Bảng từ cấm là DANH SÁCH ĐÓNG và phải khớp với phan-loai.js — thêm một
 *  nhóm mới ở đó mà quên thêm tên nhóm vào đây thì có một mục kiểm bắt được,
 *  chứ không im lặng cho qua.
 *
 *  PHÉP SOI CHỮ KHÔNG BẮT ĐƯỢC MỌI THỨ — nói thẳng để không ai tin nhầm vào
 *  nó. Một gói JSON `{giaTri:{diem:0.7}}` lọt ra ngoài thì phép soi này im
 *  lặng, vì "giaTri" và "diem" là chữ dùng chung khắp hệ thống và cấm chúng
 *  sẽ bắt oan cả "Cây giá trị" của khách. Nên bức tường có HAI lớp, và lớp
 *  thứ hai mới là lớp chặn hình dạng dữ liệu:
 *    · lớp chữ    — soiRoRi(), quét mọi mặt khách hàng nhìn thấy;
 *    · lớp cổng   — choVao()/choVaoTheoTaiKhoan(), chặn ngay tại cửa API, và
 *                   có mục kiểm gõ cửa bằng đủ bốn vai để chứng minh nó chặn.
 *  Bỏ một trong hai lớp là bức tường thủng, dù lớp còn lại vẫn xanh.
 *
 *  MỘT CHỮ ĐƯỢC PHÉP: "Cây giá trị". Đó là cây của khách hàng
 *  (src/nha/cay-gia-tri.js), năm tầng và thứ gia đình nhận được khi đi hết.
 *  Hai cây trùng một chữ "cây" nên phép soi phải phân biệt được chúng; đó là
 *  lý do bảng dưới đây liệt kê CỤM TỪ, không liệt kê từ đơn.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { viKey } = require('../utils');
const { NHOM } = require('./phan-loai');

/** Vai duy nhất được xem Cây Tiền. Giáo viên cũng không, vì đây là việc điều hành. */
const VAI_DUOC_XEM = ['co-van'];
/** Vai tài khoản tương ứng. */
const TAI_KHOAN_DUOC_XEM = ['ADMIN'];

/**
 * Cụm từ cấm xuất hiện ở bất kỳ mặt nào khách hàng nhìn thấy.
 * Viết thường, không dấu câu — phép soi tự bỏ dấu câu trước khi so.
 */
const CUM_CAM = [
  'cây tiền', 'cay tien',
  'cây cần cứu', 'cây đang lớn', 'cây chớm héo', 'hạt mới',
  'giá trị đồng hành', 'nguy cơ rời bỏ', 'điểm giá trị',
  'xếp nhóm', 'phân loại khách hàng', 'khách hàng lớn',
  'cost-to-serve', 'customer lifetime value', 'clv',
  'giờ chăm sóc', 'nguồn lực chăm sóc',
  // Mã nhóm cũng cấm: một bản JSON lọt ra thì mã lộ trước cả tên.
  ...Object.keys(NHOM).map((k) => k.toLowerCase()),
];

/** Cụm ĐƯỢC PHÉP dù chứa chữ nhạy cảm — kiểm trước, để khỏi báo oan. */
const CUM_MIEN = ['cây giá trị', 'cay gia tri'];

/** Bảng cấm và bảng miễn, đã chuẩn hoá sẵn một lần khi nạp mô-đun. */
let CAM_CHUAN = null;
let MIEN_CHUAN = null;

const NAM_DAU_THOAT = [
  [/&amp;/g, '&'], [/&lt;/g, '<'], [/&gt;/g, '>'], [/&quot;/g, '"'], [/&#39;/g, "'"],
];

/** Gỡ dấu thoát HTML — chữ bị đổi thành &quot; vẫn là chữ ấy khi hiện lên màn hình. */
function goDauThoat(s) {
  let ra = String(s == null ? '' : s);
  for (const [re, ch] of NAM_DAU_THOAT) ra = ra.replace(re, ch);
  return ra;
}

/** Gom mọi chuỗi trong một giá trị lồng nhau thành một mảng phẳng. */
function gomChuoi(x, ra = [], sau = 0) {
  if (sau > 12 || x == null) return ra;
  if (typeof x === 'string') { ra.push(x); return ra; }
  if (Array.isArray(x)) { for (const y of x) gomChuoi(y, ra, sau + 1); return ra; }
  if (x instanceof Map) { for (const [k, v] of x) { gomChuoi(k, ra, sau + 1); gomChuoi(v, ra, sau + 1); } return ra; }
  if (typeof x === 'object') {
    for (const k of Object.keys(x)) { ra.push(k); gomChuoi(x[k], ra, sau + 1); }
  }
  return ra;
}

/**
 * Đưa một chuỗi về dạng so sánh được: gỡ dấu thoát HTML, BỎ DẤU TIẾNG VIỆT,
 * và coi gạch dưới / gạch nối / dấu chấm như khoảng trắng.
 *
 * Bỏ dấu là chỗ quan trọng nhất. "Cây chớm héo" gõ không dấu thành "cay chom
 * heo" vẫn là đúng chữ ấy khi hiện lên màn hình, và mã nhóm CAY_CHOM_HEO cũng
 * quy về đúng chuỗi đó. Một phép soi chỉ so chuỗi có dấu sẽ bỏ lọt cả hai.
 */
const chuanHoa = (s) => viKey(goDauThoat(s).replace(/[_\-.]+/g, ' '));

/**
 * Tìm một cụm cấm, nhưng KHÔNG chấp nhận chỗ khớp bắt đầu hoặc kết thúc ở
 * GIỮA một từ.
 *
 * Vì sao phải có hàm này. Phép soi cũ dùng indexOf thẳng, và một mô-đun mới
 * khi chạy qua tường đã làm nó báo động nhầm: câu "Nhóm được bảo vệ chặt
 * nhất. Mọi tiếp xúc…" sau khi bỏ dấu và bỏ dấu câu thành "…chat nhat moi
 * tiep xuc…", trong đó có chuỗi con "hat moi" — đúng bằng tên một nhóm.
 *
 * Một bộ soi an ninh báo động nhầm không phải chuyện nhỏ. Người trực gặp vài
 * lần là thôi đọc, và lần thứ tư nó báo đúng thì cũng không ai nhìn. Nên
 * chỗ khớp phải nằm trọn trong ranh giới từ.
 *
 * Luật này KHÔNG nới lỏng phép soi: một cụm cấm có thật bao giờ cũng bắt đầu
 * ở đầu một từ. Nó chỉ bỏ đi đúng những chỗ khớp cắt ngang thân từ.
 */
function viTriCum(s, cum) {
  const laChu = (c) => !!c && /[a-z0-9]/.test(c);
  let tu = 0;
  for (;;) {
    const i = s.indexOf(cum, tu);
    if (i < 0) return -1;
    const truoc = i > 0 ? s[i - 1] : '';
    const sau = i + cum.length < s.length ? s[i + cum.length] : '';
    if (!laChu(truoc) && !laChu(sau)) return i;
    tu = i + 1;
  }
}

/**
 * Soi một thứ bất kỳ — chuỗi, đối tượng, cả một trang HTML — xem có chữ nào
 * của Cây Tiền lọt vào không.
 *
 * @returns {{sach:boolean, roRi:Array<{cum:string, trich:string}>}}
 */
function soiRoRi(thu) {
  if (!CAM_CHUAN) {
    CAM_CHUAN = [...new Set(CUM_CAM.map(chuanHoa).filter(Boolean))];
    MIEN_CHUAN = [...new Set(CUM_MIEN.map(chuanHoa).filter(Boolean))];
  }
  const roRi = [];
  for (const chuoi of gomChuoi(thu)) {
    const s = chuanHoa(chuoi);
    if (!s) continue;
    // Che các cụm được miễn TRƯỚC khi dò cụm cấm, nếu không "cây giá trị" sẽ
    // bị chính phép soi này bắt oan mỗi lần mặt khách hàng nhắc tới nó.
    let sach = s;
    for (const mien of MIEN_CHUAN) sach = sach.split(mien).join(' ');
    for (const cum of CAM_CHUAN) {
      const i = viTriCum(sach, cum);
      if (i < 0) continue;
      roRi.push({ cum, trich: chuoi.slice(Math.max(0, i - 40), i + cum.length + 40).trim() });
      if (roRi.length >= 20) return { sach: false, roRi };
    }
  }
  return { sach: roRi.length === 0, roRi };
}

/**
 * Cổng vào. Trả về lý do từ chối bằng chữ, để chỗ gọi khỏi tự chế thông báo.
 * @param {string} vaiId vai trong nhà ('co-van', 'phu-huynh'…)
 */
function choVao(vaiId) {
  if (VAI_DUOC_XEM.includes(vaiId)) return { ok: true };
  return {
    ok: false,
    error: 'KHÔNG_ĐỦ_QUYỀN',
    // Thông báo KHÔNG nhắc tới Cây Tiền. Nói "bạn không được xem bảng phân
    // loại giá trị khách hàng" là đã để lộ rằng bảng ấy tồn tại.
    reason: 'Mục này thuộc khu điều hành hệ thống.',
  };
}

/** Cổng vào theo vai TÀI KHOẢN (ADMIN/TEACHER/PARENT/LEARNER). */
function choVaoTheoTaiKhoan(role) {
  if (TAI_KHOAN_DUOC_XEM.includes(String(role || '').toUpperCase())) return { ok: true };
  return { ok: false, error: 'KHÔNG_ĐỦ_QUYỀN', reason: 'Mục này thuộc khu điều hành hệ thống.' };
}

/** Đọc một cookie theo tên. Không kéo thêm thư viện nào cho một việc bốn dòng. */
function docCookie(header, ten) {
  if (!header) return null;
  for (const phan of String(header).split(';')) {
    const i = phan.indexOf('=');
    if (i < 0) continue;
    if (phan.slice(0, i).trim() === ten) return decodeURIComponent(phan.slice(i + 1).trim());
  }
  return null;
}

/**
 * Cổng vào cho một yêu cầu HTTP.
 *
 * Bộ định tuyến API của hệ thống KHÔNG có lớp xác thực chung — mọi cổng đều mở
 * cho ai gọi được tới máy chủ. Với phần lớn nhóm cổng thì đó là lựa chọn đã
 * cân nhắc, nhưng với Cây Tiền thì không: một cổng mở ở đây là bảng phân loại
 * gia đình nằm sau một dòng curl. Nên mọi cổng /cay-tien/* tự kiểm quyền ngay
 * trong tay xử lý, bằng hàm này, và KHÔNG cổng nào được bỏ qua bước ấy — có
 * một mục kiểm gõ cửa bằng đủ bốn vai để chứng minh.
 */
function choVaoYeuCau(N, req) {
  const cookie = docCookie(req && req.headers && req.headers.cookie, 'gita_token');
  const bearer = String((req && req.headers && req.headers.authorization) || '').replace(/^Bearer\s+/i, '');
  const token = cookie || bearer || null;
  if (!token || !N || !N.accounts || typeof N.accounts.session !== 'function') {
    return { ok: false, error: 'KHÔNG_ĐỦ_QUYỀN', reason: 'Mục này thuộc khu điều hành hệ thống.' };
  }
  const phien = N.accounts.session(token);
  if (!phien) return { ok: false, error: 'KHÔNG_ĐỦ_QUYỀN', reason: 'Mục này thuộc khu điều hành hệ thống.' };
  return choVaoTheoTaiKhoan(phien.role);
}

module.exports = {
  viTriCum,
  VAI_DUOC_XEM, TAI_KHOAN_DUOC_XEM, CUM_CAM, CUM_MIEN,
  soiRoRi, choVao, choVaoTheoTaiKhoan, choVaoYeuCau, gomChuoi, goDauThoat,
};
