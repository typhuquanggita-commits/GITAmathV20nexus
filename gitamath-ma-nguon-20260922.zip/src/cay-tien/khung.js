'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CÂY TIỀN — KHUNG TÁM NĂNG LỰC  ·  NỘI BỘ QUẢN TRỊ, KHÁCH KHÔNG ĐƯỢC XEM
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ⚠ ĐỌC KỸ TRƯỚC KHI SỬA TỆP NÀY
 *
 *  Toàn bộ thư mục src/cay-tien/ là công cụ ĐIỀU HÀNH. Nó xếp hạng gia đình
 *  theo giá trị đồng hành để phân bổ nguồn lực chăm sóc. Đó là việc chính
 *  đáng của người quản trị, NHƯNG nó tuyệt đối không được lọt ra mặt khách
 *  hàng: không gia đình nào được đọc thấy mình bị xếp vào nhóm nào, và không
 *  học viên nào được biết bạn mình thuộc nhóm "đáng đầu tư hơn".
 *
 *  Lý do không phải là giữ bí mật kinh doanh. Lý do là: một đứa trẻ biết hệ
 *  thống đang xếp hạng gia đình mình theo giá trị sẽ học với một tâm thế
 *  khác, và cái khác ấy phá đúng thứ hệ thống này tồn tại để tạo ra.
 *
 *  Bức tường ngăn nằm ở src/cay-tien/buc-tuong.js và ĐƯỢC MÁY CƯỠNG CHẾ:
 *  có mục kiểm quét toàn bộ trang công khai và cả bốn vai trong khu riêng,
 *  bắt được một chữ của bảng từ cấm là trượt. Đừng nới bức tường ấy.
 *
 *  Mặt khách hàng nhìn thấy là CÂY GIÁ TRỊ (src/nha/cay-gia-tri.js): năm tầng
 *  và thứ gia đình nhận được khi đi hết. Hai cây, hai phía, không gặp nhau.
 *
 * ───────────────────────────────────────────────────────────────────────────
 *  NGUỒN KHUNG
 *
 *  Tám năng lực dưới đây hệ thống hoá từ tám chương của "Cây Tiền" (Lý Tiễn):
 *  chọn khách hàng → hiểu khách hàng → hiểu đối thủ → đo khả năng sinh lợi →
 *  kế hoạch phục vụ → quản lý giá trị → đối tác chiến lược → nhân bản.
 *
 *  Đây là DIỄN GIẢI ỨNG DỤNG, không phải nguyên văn sách. Mỗi năng lực ở đây
 *  đều phải trả lời thêm một câu mà sách không cần trả lời: "dữ liệu nào
 *  trong hệ thống này đáp được câu hỏi đó?" — và khi chưa có dữ liệu thì ghi
 *  thẳng là CHƯA CÓ, kèm thứ cần nối vào. Một khung quản trị mà mọi ô đều
 *  xanh là một khung chưa ai dùng thật.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/**
 * Tám năng lực.
 *   ma        mã bất biến
 *   chuong    chương tương ứng trong sách
 *   ten       tên năng lực trong hệ GITAmathV20nexus
 *   hoi       câu hỏi chiến lược của chương
 *   hoiGita   câu hỏi ấy hỏi lại bằng ngôn ngữ của hệ thống này
 *   nguon     nguồn dữ liệu trong hệ thống trả lời được câu hỏi
 *   coDuLieu  true nếu hệ thống ĐANG có dữ liệu ấy; false thì `thieu` nói rõ
 *   thieu     thứ còn phải nối vào mới trả lời được
 *   to        tổ trong 500 trợ lý AI chịu trách nhiệm năng lực này
 */
const NANG_LUC = [
  {
    ma: 'CHON',
    chuong: 1,
    ten: 'Chọn đúng gia đình để dồn sức',
    hoi: 'Ai là Cây Tiền của doanh nghiệp?',
    hoiGita: 'Gia đình nào đang đi thật, đi đều, và tiến thật — để dồn cố vấn vào đó?',
    nguon: ['telemetry.attempts', 'telemetry.sessions', 'nha-truc'],
    coDuLieu: true,
    thieu: null,
    khoi: 'BUSINESS', to: 'bi',
  },
  {
    ma: 'HIEU',
    chuong: 2,
    ten: 'Hiểu gia đình sâu hơn một bảng điểm',
    hoi: 'Tôi hiểu họ sâu đến mức nào?',
    hoiGita: 'Ngoài điểm số, ta biết gì về nhịp học, thói quen và chỗ vướng của học viên này?',
    nguon: ['telemetry.behaviors', 'telemetry.topMisconceptions', 'mastery'],
    coDuLieu: true,
    thieu: null,
    khoi: 'RESEARCH', to: 'curriculum',
  },
  {
    ma: 'DOI_THU',
    chuong: 3,
    ten: 'Biết vì sao gia đình chọn mình',
    hoi: 'Tại sao họ phải chọn tôi thay vì đối thủ?',
    hoiGita: 'Gia đình rời đi thì rời sang đâu, và vì thiếu thứ gì ở đây?',
    nguon: [],
    coDuLieu: false,
    thieu: 'Phỏng vấn lý do rời bỏ (exit interview) và khảo sát nơi chuyển đến. '
      + 'Hệ thống hiện đo được VIỆC rời đi, chưa đo được LÝ DO rời đi.',
    khoi: 'RESEARCH', to: 'exam-intel',
  },
  {
    ma: 'SINH_LOI',
    chuong: 4,
    ten: 'Đo giá trị một gia đình tạo ra',
    hoi: 'Khách hàng này thực sự có giá trị bao nhiêu?',
    hoiGita: 'Gia đình này đóng góp bao nhiêu vào thứ hệ thống tồn tại để tạo ra?',
    nguon: ['telemetry', 'mastery', 'nha-truc'],
    coDuLieu: true,
    // Nói thẳng chỗ khung này KHÁC sách: sách đo bằng tiền, hệ thống này chưa
    // có một đồng dữ liệu thanh toán nào. Nên trục "sinh lợi" ở đây đo GIÁ TRỊ
    // ĐỒNG HÀNH — nhịp đi và mức tiến — chứ không đo doanh thu. Ghép đại doanh
    // thu vào đây bằng cách ước lượng là bịa số, và một con số bịa ở trục này
    // sẽ dẫn sai mọi quyết định phân bổ nguồn lực phía sau.
    thieu: 'Dữ liệu thanh toán (gói đã mua, kỳ hạn, giá trị hợp đồng). Chưa nối thì '
      + 'trục sinh lợi đo GIÁ TRỊ ĐỒNG HÀNH, không đo tiền — và báo cáo phải nói đúng như vậy.',
    khoi: 'BUSINESS', to: 'finance',
  },
  {
    ma: 'PHUC_VU',
    chuong: 5,
    ten: 'Phục vụ theo mức, không phục vụ tùy hứng',
    hoi: 'Tôi có hệ thống nào để phục vụ họ vượt trội?',
    hoiGita: 'Mỗi nhóm gia đình được chạm bao lâu một lần, bởi ai, và làm gì ở lần chạm đó?',
    nguon: ['nexus/diem-cham', 'nha-truc'],
    coDuLieu: true,
    thieu: null,
    khoi: 'TUTOR', to: 'coach-1v1',
  },
  {
    ma: 'GIA_TRI',
    chuong: 6,
    ten: 'Tăng giá trị thay vì tăng giao dịch',
    hoi: 'Tôi còn có thể tạo thêm bao nhiêu giá trị cho họ?',
    hoiGita: 'Gia đình này còn phần nào của hệ thống chưa dùng tới mà đáng dùng?',
    nguon: ['nha/ban-do', 'mastery', 'matran/ma-tran'],
    coDuLieu: true,
    thieu: null,
    khoi: 'TUTOR', to: 'coach-1v1',
  },
  {
    ma: 'DOI_TAC',
    chuong: 7,
    ten: 'Biến gia đình thành người đồng hành',
    hoi: 'Làm sao biến giao dịch thành quan hệ chiến lược?',
    hoiGita: 'Gia đình nào đủ tin để cùng thử chương trình mới và giới thiệu gia đình khác?',
    nguon: [],
    coDuLieu: false,
    thieu: 'Sổ giới thiệu (gia đình nào đến từ gia đình nào). Chưa có thì trục lan toả '
      + 'KHÔNG được chấm, và nhóm phân loại phải nói rõ là chấm thiếu một trục.',
    khoi: 'BUSINESS', to: 'growth',
  },
  {
    ma: 'NHAN_BAN',
    chuong: 8,
    ten: 'Nhân bản cách làm, không nhân bản con người',
    hoi: 'Làm sao biến một Cây Tiền thành cả hệ thống Cây Tiền?',
    hoiGita: 'Cách chăm một gia đình thành công đã thành quy trình chạy được chưa?',
    nguon: ['nha/nhiem-vu', 'agents/roster'],
    coDuLieu: true,
    thieu: null,
    khoi: 'CODE', to: 'devops',
  },
];

const NANG_LUC_INDEX = new Map(NANG_LUC.map((x) => [x.ma, x]));

/** Bảng tám năng lực, kèm đúng hai con số: mấy năng lực đủ dữ liệu, mấy chưa. */
function khung() {
  const du = NANG_LUC.filter((x) => x.coDuLieu);
  return {
    soNangLuc: NANG_LUC.length,
    soCoDuLieu: du.length,
    soThieuDuLieu: NANG_LUC.length - du.length,
    nangLuc: NANG_LUC.map((x) => ({ ...x, nguon: x.nguon.slice() })),
    // Không làm tròn thành "8/8 sẵn sàng". Ba năng lực còn thiếu dữ liệu là ba
    // chỗ quyết định sẽ mò, và người điều hành phải nhìn thấy điều đó mỗi lần
    // mở báo cáo.
    ketLuan: du.length === NANG_LUC.length
      ? 'Cả tám năng lực đều có dữ liệu trả lời.'
      : `${NANG_LUC.length - du.length}/${NANG_LUC.length} năng lực chưa có dữ liệu: `
        + NANG_LUC.filter((x) => !x.coDuLieu).map((x) => x.ten).join(' · '),
  };
}

module.exports = { NANG_LUC, NANG_LUC_INDEX, khung };
