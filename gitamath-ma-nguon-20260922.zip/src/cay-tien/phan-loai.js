'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CÂY TIỀN — SÀNG LỌC · PHÂN LOẠI · CHĂM SÓC · TỐI ƯU DỊCH VỤ
 *  NỘI BỘ QUẢN TRỊ. KHÁCH HÀNG KHÔNG ĐƯỢC XEM. Xem src/cay-tien/khung.js.
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  BỐN VIỆC, THEO ĐÚNG THỨ TỰ
 *    1. SÀNG LỌC  — loại ra những gia đình CHƯA ĐỦ DẤU VẾT để chấm. Đây là
 *       bước đầu tiên chứ không phải bước phụ: chấm một gia đình mới vào học
 *       ba hôm rồi xếp họ vào nhóm "giá trị thấp" là một quyết định sai được
 *       ra bằng dữ liệu không đủ, và nó tự ứng nghiệm — ít chăm sóc thì họ đi
 *       thật.
 *    2. PHÂN LOẠI — hai trục, bốn nhóm, cộng một nhóm "chưa chấm".
 *    3. CHĂM SÓC  — mỗi nhóm một nhịp chạm và một tổ phụ trách.
 *    4. TỐI ƯU    — so nguồn lực đang đổ vào với giá trị từng nhóm tạo ra.
 *
 *  HAI TRỤC, VÀ LÝ DO CHỌN ĐÚNG HAI TRỤC NÀY
 *
 *    Trục ĐỨNG — GIÁ TRỊ ĐỒNG HÀNH. Không phải doanh thu. Hệ thống này chưa
 *    có một đồng dữ liệu thanh toán nào, nên bất kỳ con số tiền nào xuất hiện
 *    ở đây cũng là bịa. Giá trị đồng hành gộp hai thứ đo được: gia đình đi
 *    ĐỀU tới đâu, và học viên TIẾN tới đâu.
 *
 *    Trục NGANG — NGUY CƠ RỜI BỎ. Một gia đình giá trị cao đang sắp rời đi và
 *    một gia đình giá trị cao đang đi đều cần hai cách đối xử khác hẳn nhau.
 *    Bảng một trục không nói được điều đó, nên hoá ra vô dụng đúng lúc cần
 *    nhất.
 *
 *  ĐIỀU TỆP NÀY KHÔNG LÀM
 *    · Không xếp hạng học viên theo năng lực. Nhóm ở đây nói về QUAN HỆ giữa
 *      hệ thống và gia đình, không nói học viên giỏi hay kém. Một học viên
 *      yếu đi đều đặn nằm ở nhóm cao hơn một học viên giỏi đã bỏ ba tuần.
 *    · Không kết luận nhân quả. Nhóm là một QUAN SÁT, không phải một lời
 *      tiên đoán, và càng không phải một bản án.
 *    · Không đẩy ra ngoài. Mọi lối ra của tệp này đi qua bức tường ở
 *      buc-tuong.js.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');

/** Dưới các ngưỡng này thì KHÔNG chấm — trả về nhóm "hạt mới". */
const SANG_LOC = {
  baiToiThieu: 20,      // đủ bài để nói được về độ chính xác
  buoiToiThieu: 5,      // đủ buổi để nói được về nhịp
  ngayToiThieu: 14,     // đủ thời gian để nhịp có nghĩa
};

const NGAY = 86400000;

/**
 * Bốn nhóm, cộng nhóm chưa chấm.
 *
 *  Tên nhóm cố tình KHÔNG dùng chữ "hạng A/B/C". Một nhãn thứ bậc trần trụi
 *  làm người chăm sóc đọc nó như một phán quyết về gia đình; tên có hình ảnh
 *  nhắc rằng cây thì nuôi được, và cây đang héo thì cứu được.
 */
const NHOM = {
  CAY_TIEN: {
    ma: 'CAY_TIEN', ten: 'Cây tiền',
    moTa: 'Đi đều và tiến thật. Đây là nhóm chứng minh hệ thống chạy được.',
    viec: 'Giữ nguyên nhịp, mời thử chương trình mới trước, xin nhận xét thật.',
    nhipCham: 'mỗi tuần một lần',
    khoi: 'TUTOR', to: 'coach-1v1',
    uuTien: 2,
  },
  CAY_CAN_CUU: {
    ma: 'CAY_CAN_CUU', ten: 'Cây cần cứu',
    moTa: 'Giá trị cao nhưng đang có dấu hiệu rời đi. Mất nhóm này là mất nhiều nhất.',
    viec: 'Cố vấn gọi trong 48 giờ, tìm đúng chỗ vướng, sửa lộ trình ngay trong tuần.',
    nhipCham: 'trong 48 giờ, rồi hai lần mỗi tuần cho tới khi nhịp trở lại',
    khoi: 'TUTOR', to: 'coach-1v1',
    // Ưu tiên 1 — cao hơn cả nhóm Cây tiền. Nguồn lực chăm sóc là hữu hạn, và
    // một giờ dành cho gia đình sắp rời đi giữ được nhiều hơn một giờ dành cho
    // gia đình vốn đã đi đều.
    uuTien: 1,
  },
  CAY_DANG_LON: {
    ma: 'CAY_DANG_LON', ten: 'Cây đang lớn',
    moTa: 'Đi đều nhưng chưa tiến nhanh, hoặc tiến nhanh nhưng chưa đều.',
    viec: 'Tìm đúng một chỗ nghẽn và gỡ, thay vì thêm bài.',
    nhipCham: 'hai tuần một lần',
    khoi: 'RESEARCH', to: 'curriculum',
    uuTien: 3,
  },
  CAY_CHOM_HEO: {
    ma: 'CAY_CHOM_HEO', ten: 'Cây chớm héo',
    moTa: 'Nhịp đang thưa dần và mức tiến đang chững.',
    viec: 'Hạ tải một bậc, đặt lại mục tiêu tuần cho vừa sức, hỏi phụ huynh về hoàn cảnh.',
    nhipCham: 'mỗi tuần một lần',
    khoi: 'TUTOR', to: 'friendly',
    uuTien: 2,
  },
  HAT_MOI: {
    ma: 'HAT_MOI', ten: 'Hạt mới',
    moTa: 'Chưa đủ dấu vết để chấm. Đây KHÔNG phải nhóm giá trị thấp.',
    viec: 'Chăm theo chuẩn chung, không cắt bớt gì, cho tới khi đủ dữ liệu để chấm.',
    nhipCham: 'mỗi tuần một lần trong sáu tuần đầu',
    khoi: 'TUTOR', to: 'friendly',
    uuTien: 2,
  },
};

/** Ngưỡng chia trục. Đặt thành hằng số có tên để không ai rải số vào mã. */
const NGUONG = {
  giaTriCao: 0.60,     // điểm giá trị đồng hành từ đây trở lên là "cao"
  ruiRoCao: 0.50,      // điểm nguy cơ rời bỏ từ đây trở lên là "đang rời"
  nguoiIm: 10,         // số ngày không có hoạt động thì coi là đang im
  nguoiBo: 21,         // số ngày không có hoạt động thì coi là gần như đã rời
};

// ── 1. SÀNG LỌC ─────────────────────────────────────────────────────────────

/** Dấu vết thô của một học viên, rút thẳng từ bộ quan sát. */
function dauVet(telemetry, userId, { bayGio = Date.now() } = {}) {
  const at = (telemetry.attempts && telemetry.attempts.get(userId)) || [];
  const buoi = ((telemetry.sessions && telemetry.sessions.get(userId)) || []).filter((s) => s.end);
  const lam = at.filter((x) => !x.skipped);
  const moc = [...at.map((x) => x.at), ...buoi.map((s) => s.end)].filter(Boolean);
  const dau = moc.length ? Math.min(...moc) : null;
  const cuoi = moc.length ? Math.max(...moc) : null;
  return {
    soBai: at.length,
    soBaiLam: lam.length,
    soBuoi: buoi.length,
    soNgayTheoHoc: dau ? round((bayGio - dau) / NGAY, 1) : 0,
    soNgayImLang: cuoi ? round((bayGio - cuoi) / NGAY, 1) : null,
    doChinhXac: lam.length ? round(lam.filter((x) => x.correct).length / lam.length, 3) : null,
    tiLeBoBai: at.length ? round(at.filter((x) => x.skipped).length / at.length, 3) : 0,
    phutMoiBuoi: buoi.length ? round(buoi.reduce((s, x) => s + (x.minutes || 0), 0) / buoi.length, 1) : 0,
  };
}

/** Gia đình này đã đủ dấu vết để chấm chưa? Thiếu gì thì nói rõ thiếu gì. */
function duDeCham(d) {
  const thieu = [];
  if (d.soBai < SANG_LOC.baiToiThieu) thieu.push(`mới ${d.soBai}/${SANG_LOC.baiToiThieu} bài`);
  if (d.soBuoi < SANG_LOC.buoiToiThieu) thieu.push(`mới ${d.soBuoi}/${SANG_LOC.buoiToiThieu} buổi`);
  if (d.soNgayTheoHoc < SANG_LOC.ngayToiThieu) thieu.push(`mới theo học ${d.soNgayTheoHoc}/${SANG_LOC.ngayToiThieu} ngày`);
  return { du: thieu.length === 0, thieu };
}

// ── 2. HAI TRỤC ─────────────────────────────────────────────────────────────

/**
 * Trục đứng — GIÁ TRỊ ĐỒNG HÀNH, thang 0..1, gộp hai nửa bằng nhau:
 *   · ĐỀU  — số buổi trên mỗi tuần theo học, chuẩn hoá theo nhịp mong muốn 3 buổi/tuần
 *   · TIẾN — độ chính xác và số dạng đã thạo
 * Cộng hai nửa bằng nhau có chủ ý: một gia đình đi đều mà tiến chậm vẫn đang
 * tạo ra thứ hệ thống cần, và một gia đình tiến nhanh rồi biến mất thì không.
 */
function diemGiaTri(d, mas) {
  const tuan = Math.max(d.soNgayTheoHoc / 7, 1);
  const deu = Math.min(d.soBuoi / tuan / 3, 1);
  const chinhXac = d.doChinhXac == null ? 0 : d.doChinhXac;
  const thao = mas && mas.formsTouched ? Math.min(mas.formsMastered / Math.max(mas.formsTouched, 1), 1) : 0;
  const tien = (chinhXac + thao) / 2;
  return { diem: round((deu + tien) / 2, 3), deu: round(deu, 3), tien: round(tien, 3) };
}

/**
 * Trục ngang — NGUY CƠ RỜI BỎ, thang 0..1. Ba dấu hiệu, đều đọc từ dấu vết:
 *   · IM LẶNG  — bao lâu rồi không thấy hoạt động
 *   · BỎ BÀI   — tỉ lệ bấm bỏ giữa chừng
 *   · BUỔI NGẮN— buổi học ngắn dần, dấu hiệu sớm hơn cả việc nghỉ hẳn
 *
 * KHÔNG lấy trung bình ba dấu hiệu. Lấy trung bình là sai, và sai theo hướng
 * nguy hiểm nhất: một gia đình im lặng hai mươi ngày mà trước đó làm bài rất
 * chăm sẽ ra điểm rủi ro 30/100, tức là được xếp vào nhóm "đang đi tốt" đúng
 * lúc họ đã bỏ đi. Ba dấu hiệu này không bù trừ cho nhau — chăm chỉ tháng
 * trước không làm cho việc biến mất tuần này bớt đáng lo.
 *
 * Nên: IM LẶNG tự nó đủ để kéo điểm rủi ro lên, còn hai dấu hiệu "đang học mà
 * học hỏng" thì gộp với nhau. Điểm cuối là cái nào CAO HƠN. Nói cách khác,
 * một dấu hiệu nặng là đủ để phải lo, không cần cả ba cùng nặng.
 */
function diemRuiRo(d) {
  const im = d.soNgayImLang == null ? 1
    : Math.min(Math.max(d.soNgayImLang - NGUONG.nguoiIm, 0) / (NGUONG.nguoiBo - NGUONG.nguoiIm), 1);
  const bo = Math.min(d.tiLeBoBai / 0.3, 1);
  const ngan = d.phutMoiBuoi > 0 ? Math.min(Math.max(15 - d.phutMoiBuoi, 0) / 15, 1) : 0;
  const dangHocHong = (bo + ngan) / 2;
  return {
    diem: round(Math.max(im, dangHocHong), 3),
    imLang: round(im, 3), boBai: round(bo, 3), buoiNgan: round(ngan, 3),
    // Ghi lại dấu hiệu nào đang quyết định điểm, để người chăm sóc biết gọi
    // điện hỏi chuyện gì thay vì hỏi chung chung.
    dauHieuNang: im >= dangHocHong ? 'im-lang' : 'dang-hoc-hong',
  };
}

// ── 3. PHÂN LOẠI MỘT GIA ĐÌNH ───────────────────────────────────────────────

/**
 * Xếp nhóm cho một học viên.
 * @returns {object} luôn có `nhom`, `duCanCu`, và `viLy` — lý do bằng chữ,
 *          để người chăm sóc đọc được mà không cần tra công thức.
 */
function xepNhom(telemetry, userId, { mastery = null, bayGio = Date.now() } = {}) {
  const d = dauVet(telemetry, userId, { bayGio });
  const sang = duDeCham(d);
  const mas = mastery && typeof mastery.summary === 'function' ? mastery.summary(userId) : null;

  if (!sang.du) {
    return {
      userId, duCanCu: false, nhom: NHOM.HAT_MOI.ma, tenNhom: NHOM.HAT_MOI.ten,
      dauVet: d, giaTri: null, ruiRo: null,
      viLy: `Chưa đủ dấu vết để chấm: ${sang.thieu.join(', ')}. `
        + 'Nhóm "Hạt mới" KHÔNG phải nhóm giá trị thấp — chăm theo chuẩn chung, không cắt bớt gì.',
    };
  }

  const gt = diemGiaTri(d, mas);
  const rr = diemRuiRo(d);
  const cao = gt.diem >= NGUONG.giaTriCao;
  const roi = rr.diem >= NGUONG.ruiRoCao;
  const ma = cao ? (roi ? 'CAY_CAN_CUU' : 'CAY_TIEN') : (roi ? 'CAY_CHOM_HEO' : 'CAY_DANG_LON');

  const viLyRuiRo = [];
  if (rr.imLang > 0) viLyRuiRo.push(`im lặng ${d.soNgayImLang} ngày`);
  if (rr.boBai > 0) viLyRuiRo.push(`bỏ ${Math.round(d.tiLeBoBai * 100)}% số bài`);
  if (rr.buoiNgan > 0) viLyRuiRo.push(`buổi học trung bình ${d.phutMoiBuoi} phút`);

  return {
    userId, duCanCu: true, nhom: ma, tenNhom: NHOM[ma].ten,
    dauVet: d, giaTri: gt, ruiRo: rr,
    viLy: `Giá trị đồng hành ${Math.round(gt.diem * 100)}/100 `
      + `(đi đều ${Math.round(gt.deu * 100)}, tiến ${Math.round(gt.tien * 100)}); `
      + `nguy cơ rời bỏ ${Math.round(rr.diem * 100)}/100`
      + (viLyRuiRo.length ? ` — ${viLyRuiRo.join(', ')}` : '')
      + '. Đây là quan sát trên dấu vết, không phải dự đoán chắc chắn.',
  };
}

// ── 4. CẢ VƯỜN ──────────────────────────────────────────────────────────────

/**
 * Xếp nhóm toàn bộ học viên có dấu vết, rồi gom thành biên bản điều hành.
 * @param {object} o {telemetry, mastery, bayGio}
 */
function soiVuon({ telemetry, mastery = null, bayGio = Date.now() } = {}) {
  const ids = telemetry && telemetry.attempts ? [...telemetry.attempts.keys()] : [];
  const xep = ids.map((id) => xepNhom(telemetry, id, { mastery, bayGio }))
    .sort((a, b) => (NHOM[a.nhom].uuTien - NHOM[b.nhom].uuTien)
      || ((b.giaTri ? b.giaTri.diem : 0) - (a.giaTri ? a.giaTri.diem : 0))
      || String(a.userId).localeCompare(String(b.userId)));

  const theoNhom = Object.values(NHOM).map((n) => {
    const trong = xep.filter((x) => x.nhom === n.ma);
    return {
      ma: n.ma, ten: n.ten, moTa: n.moTa, viec: n.viec, nhipCham: n.nhipCham,
      khoi: n.khoi, to: n.to, uuTien: n.uuTien,
      soGiaDinh: trong.length,
      tiLe: ids.length ? round(trong.length / ids.length, 3) : 0,
      giaDinh: trong.map((x) => x.userId),
    };
  }).sort((a, b) => a.uuTien - b.uuTien || b.soGiaDinh - a.soGiaDinh);

  const canCuu = theoNhom.find((n) => n.ma === 'CAY_CAN_CUU');
  const hatMoi = theoNhom.find((n) => n.ma === 'HAT_MOI');
  const daCham = xep.filter((x) => x.duCanCu).length;

  return {
    luc: bayGio,
    soGiaDinh: ids.length,
    soDaCham: daCham,
    soChuaDuCanCu: ids.length - daCham,
    nguongSangLoc: { ...SANG_LOC },
    theoNhom,
    xep,
    // Việc gấp nhất luôn được nêu trước, và nêu bằng số chứ không bằng tính từ.
    viecGapNhat: canCuu && canCuu.soGiaDinh
      ? `${canCuu.soGiaDinh} gia đình thuộc nhóm "Cây cần cứu" — cố vấn phải gọi trong 48 giờ.`
      : (ids.length === 0
        ? 'Chưa có gia đình nào có dấu vết. Chưa xếp nhóm được, và cũng chưa cần.'
        : 'Không có gia đình nào ở nhóm cần cứu.'),
    ghiChu: `${ids.length - daCham}/${ids.length} gia đình chưa đủ dấu vết nên chưa chấm. `
      + 'Trục giá trị ở đây là GIÁ TRỊ ĐỒNG HÀNH, không phải doanh thu — hệ thống chưa nối dữ liệu thanh toán.',
  };
}

// ── 5. TỐI ƯU DỊCH VỤ ───────────────────────────────────────────────────────

/**
 * So NGUỒN LỰC đang đổ vào từng nhóm với GIÁ TRỊ nhóm ấy tạo ra.
 *
 * Đây là câu hỏi của chương 5 và chương 9 gộp lại: phân bổ nguồn lực có đi
 * theo giá trị không? Phép so chỉ có nghĩa khi CẢ HAI vế cùng có số thật, nên
 * hàm này đòi người gọi đưa vào số giờ chăm sóc đã dùng cho từng nhóm. Không
 * đưa thì trả về đúng chữ "chưa đo được" — không ước lượng hộ.
 *
 * @param {object} vuon  kết quả soiVuon()
 * @param {object} gioCham  {MA_NHOM: số giờ đã dùng}
 */
function toiUuDichVu(vuon, gioCham = null) {
  if (!gioCham || !Object.keys(gioCham).length) {
    return {
      ok: true, duCanCu: false, hang: [],
      ghiChu: 'Chưa đo được: hệ thống chưa ghi số giờ chăm sóc theo nhóm. '
        + 'Nối sổ giờ cố vấn vào rồi gọi lại hàm này; ước lượng hộ ở đây là bịa số.',
    };
  }
  const tongGio = Object.values(gioCham).reduce((s, x) => s + (Number(x) || 0), 0);
  const hang = vuon.theoNhom.map((n) => {
    const gio = Number(gioCham[n.ma] || 0);
    const phanGio = tongGio ? gio / tongGio : 0;
    const phanNha = n.tiLe;
    return {
      ma: n.ma, ten: n.ten, uuTien: n.uuTien,
      soGiaDinh: n.soGiaDinh, gio: round(gio, 1),
      phanTramGio: round(phanGio, 3), phanTramGiaDinh: round(phanNha, 3),
      lech: round(phanGio - phanNha, 3),
    };
  });
  const dồn = hang.filter((h) => h.lech > 0.15).sort((a, b) => b.lech - a.lech);
  const boi = hang.filter((h) => h.lech < -0.15 && h.uuTien <= 2).sort((a, b) => a.lech - b.lech);
  return {
    ok: true, duCanCu: true, tongGio: round(tongGio, 1), hang,
    ketLuan: [
      dồn.length ? `Đang dồn giờ quá mức vào: ${dồn.map((h) => h.ten).join(', ')}.` : null,
      boi.length ? `Nhóm ưu tiên cao đang thiếu giờ: ${boi.map((h) => h.ten).join(', ')}.` : null,
    ].filter(Boolean).join(' ') || 'Giờ chăm sóc đang đi sát tỉ trọng từng nhóm.',
  };
}

module.exports = {
  NHOM, NGUONG, SANG_LOC,
  dauVet, duDeCham, diemGiaTri, diemRuiRo, xepNhom, soiVuon, toiUuDichVu,
};
