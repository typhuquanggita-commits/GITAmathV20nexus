'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TỪ VỰNG THEO LỚP — dựng từ chính chương trình, không lấy từ trên trời
 * ═══════════════════════════════════════════════════════════════════════════
 *  Câu hỏi cần trả lời: "đề bài lớp 3 này có dùng từ nào mà mãi lớp 9 mới
 *  dạy không?". Muốn trả lời được thì phải biết mỗi thuật ngữ xuất hiện lần
 *  đầu ở lớp nào.
 *
 *  Nguồn duy nhất: danh mục dạng bài của chương trình (mã dạng có sẵn số lớp:
 *  M3.… là lớp 3) và kho học liệu đã thẩm định. Không có danh sách từ nào
 *  được chép từ bên ngoài vào, nên mỗi từ ở đây đều truy ngược được về một
 *  dạng bài có thật.
 *
 *  Giới hạn phải nói rõ: đây là từ vựng TOÁN của chương trình này, không phải
 *  từ điển tiếng Việt phổ thông. Từ đời thường ("quả cam", "cái bàn") không
 *  có trong đó, nên chúng được xếp vào nhóm "không xác định" chứ không bị coi
 *  là từ khó.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { FORM_INDEX } = require('../curriculum/hierarchy');
const { cacTieng } = require('./chinhta');

/** Từ công cụ — không mang nghĩa chuyên môn, không xét cấp độ. */
const TU_CONG_CU = new Set(`
và là của có cho với trong ngoài trên dưới các những cái con
này kia đó ấy thì mà nếu nên vì do bởi khi lúc đã đang sẽ được bị rất
hơn nhất cũng chỉ còn nữa lại đi về ra vào lên xuống ta em anh chị bạn
tôi mình chúng họ ai gì nào đâu sao bao nhiêu mấy hãy đừng chớ không
chưa phải nhưng hoặc hay tuy dù song bằng như để từ đến tại theo trước
sau giữa cùng mỗi mọi tất cả toàn nhiều ít thêm bớt rồi xong vẫn đều
biết làm thấy nói hỏi trả lời viết đọc học xem tìm cần phải nên thử
`.trim().split(/\s+/));

/**
 * Tách cụm thuật ngữ (một đến bốn tiếng) ra khỏi một tên dạng bài.
 * Chỉ nhận tiếng thuần chữ cái: "ax²", "a 0", "2x" là ký hiệu toán chứ không
 * phải thuật ngữ, đưa vào bảng từ vựng là làm bẩn bảng.
 */
function cumTu(chuoi) {
  const tieng = String(chuoi || '').toLowerCase()
    .split(/[^\p{L}]+/u)
    .filter((t) => t && /^[\p{L}]+$/u.test(t));
  const ra = new Set();
  for (let n = 1; n <= 4; n++) {
    for (let i = 0; i + n <= tieng.length; i++) {
      const cum = tieng.slice(i, i + n);
      // Cụm không được mở đầu hay kết thúc bằng từ công cụ: "và tương",
      // "của phương" không phải thuật ngữ.
      if (TU_CONG_CU.has(cum[0]) || TU_CONG_CU.has(cum[n - 1])) continue;
      if (n === 1 && cum[0].length < 2) continue;
      ra.add(cum.join(' '));
    }
  }
  return [...ra];
}

/**
 * Dựng bảng: thuật ngữ → lớp xuất hiện sớm nhất, kèm dạng bài nguồn.
 * Tất định: cùng một chương trình luôn cho cùng một bảng.
 */
function dungBang({ bank = null } = {}) {
  const bang = new Map();
  const ghi = (tu, lop, nguon) => {
    const cu = bang.get(tu);
    if (!cu || lop < cu.lop) bang.set(tu, { lop, nguon });
  };

  const dang = [...FORM_INDEX.values()].sort((a, b) => a.code.localeCompare(b.code));
  for (const f of dang) {
    const lop = Number((f.code.match(/^M(\d+)/) || [])[1]);
    if (!lop) continue;
    for (const t of cumTu(f.name)) ghi(t, lop, f.code);
    for (const bay of f.traps || []) for (const t of cumTu(bay)) ghi(t, lop, f.code);
  }

  if (bank) {
    for (const f of dang) {
      const lop = Number((f.code.match(/^M(\d+)/) || [])[1]);
      if (!lop) continue;
      for (const b of bank.query({ formCode: f.code, limit: 100 })) {
        const van = String(b.stem || '').replace(/\$[^$]*\$/g, ' ');
        for (const t of cumTu(van)) if (t.split(' ').length >= 2) ghi(t, lop, f.code);
      }
    }
  }
  return bang;
}

class TuVung {
  constructor({ bank = null } = {}) {
    this.bank = bank;
    this.bang = dungBang({ bank });
  }

  /** Lớp sớm nhất mà thuật ngữ này xuất hiện trong chương trình. */
  capDo(tu) {
    const t = String(tu || '').toLowerCase().trim();
    return this.bang.get(t) || null;
  }

  /** Mọi thuật ngữ của một lớp, kèm dạng bài nguồn. */
  theoLop(lop, { dauDu = true } = {}) {
    const l = Number(lop);
    let ra = [...this.bang.entries()].filter(([, v]) => v.lop === l).map(([tu, v]) => ({ tu, ...v }));
    if (dauDu) {
      // Chỉ giữ cụm ĐẦY ĐỦ: "bậc hai" nằm gọn trong "phương trình bậc hai"
      // thì liệt kê cả hai là liệt kê một thứ hai lần.
      const tatCa = ra.map((x) => x.tu);
      ra = ra.filter((x) => !tatCa.some((y) => y !== x.tu && y.includes(x.tu)));
    }
    ra.sort((a, b) => a.tu.localeCompare(b.tu, 'vi'));
    return { ok: true, lop: l, tong: ra.length, items: ra };
  }

  /**
   * Thuật ngữ trong văn bản mà chương trình chỉ dạy Ở LỚP CAO HƠN.
   * Đây là phép đo nói lên nhiều nhất: dùng từ chưa được học là bắt học sinh
   * đoán nghĩa giữa lúc đang phải nghĩ toán.
   */
  tuVuotLop(text, lop) {
    const l = Number(lop);
    // Khớp theo TIẾNG chứ không theo chuỗi con: "giá" nằm trong "giác", khớp
    // kiểu chuỗi con thì "tam giác" bị báo là dùng từ "giá" của lớp 12.
    const tieng = String(text || '').toLowerCase()
      .replace(/\$[^$]*\$/g, ' ')
      .split(/[^\p{L}]+/u).filter(Boolean);
    const coCum = new Set();
    for (let n = 1; n <= 4; n++) {
      for (let i = 0; i + n <= tieng.length; i++) coCum.add(tieng.slice(i, i + n).join(' '));
    }
    const vuot = new Map();
    for (const [tu, v] of this.bang) {
      if (v.lop <= l) continue;
      // Chỉ tính CỤM từ hai tiếng trở lên là thuật ngữ. Động từ một tiếng
      // ("tính", "tìm", "cho") dùng ở mọi lớp, báo nó vượt lớp là báo sai.
      if (!tu.includes(' ')) continue;
      if (!coCum.has(tu)) continue;
      vuot.set(tu, v);
    }
    const ds = [...vuot.entries()]
      .filter(([tu]) => ![...vuot.keys()].some((k) => k !== tu && k.includes(tu)))
      .map(([tu, v]) => ({ tu, lopDay: v.lop, nguon: v.nguon }))
      .sort((a, b) => b.lopDay - a.lopDay);
    return { ok: true, lop: l, tong: ds.length, items: ds };
  }

  /** Thuật ngữ của một dạng bài, dùng làm bảng từ vựng cho bài giảng. */
  choDang(maDang) {
    const f = FORM_INDEX.get(maDang);
    if (!f) return { ok: false, error: 'KHÔNG_CÓ_DẠNG_BÀI', maDang };
    const lop = Number((f.code.match(/^M(\d+)/) || [])[1]) || null;
    const tu = cumTu(f.name)
      .concat((f.traps || []).flatMap((t) => cumTu(t)))
      .filter((t, i, a) => a.indexOf(t) === i && t.split(' ').length >= 2);
    return {
      ok: true, maDang, lop, tenDang: f.name,
      tong: tu.length,
      items: tu.map((t) => {
        const v = this.bang.get(t);
        return { tu: t, lopDay: v ? v.lop : lop, moi: !v || v.lop === lop };
      }),
      canBietTruoc: (f.prereq || []).map((c) => ({ ma: c, ten: FORM_INDEX.get(c)?.name || c })),
    };
  }

  status() {
    const theoLop = {};
    for (const v of this.bang.values()) theoLop[v.lop] = (theoLop[v.lop] || 0) + 1;
    return {
      tongThuatNgu: this.bang.size,
      theoLop,
      nguon: this.bank ? 'danh mục dạng bài + kho học liệu đã thẩm định' : 'danh mục dạng bài',
      luuY: 'Đây là từ vựng toán của chương trình, không phải từ điển tiếng Việt phổ thông.',
    };
  }
}

module.exports = { TuVung, cumTu, dungBang, TU_CONG_CU };
