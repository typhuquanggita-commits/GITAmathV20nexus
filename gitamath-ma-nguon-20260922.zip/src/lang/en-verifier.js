'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  GIẢI LẠI BÀI TIẾNG ANH — chốt kiểm độc lập cho học liệu môn tiếng Anh
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bài toán được chốt bằng cách THAY SỐ vào biểu thức. Bài ngữ pháp không có
 *  số để thay, nên chốt bằng cách khác: ĐỌC LẠI CÂU NGUỒN rồi tự biến đổi.
 *
 *  Mức độ độc lập — nói thẳng để không ai hiểu nhầm về sức mạnh của phép kiểm:
 *
 *    · bị động, thì, tường thuật, điều kiện — ĐỘC LẬP THẬT. Bộ kiểm chỉ nhận
 *      chuỗi câu nguồn, tự tách chủ ngữ / động từ / tân ngữ, tự dò ngược động
 *      từ về dạng gốc rồi tự chia lại. Bộ sinh ghép câu, bộ kiểm đọc câu —
 *      hai đường khác nhau, sai một bên là lệch ngay.
 *    · mệnh đề quan hệ — ĐỘC LẬP MỘT PHẦN. Bộ kiểm nhận hai câu nguồn và tự
 *      nối, nhưng phải dùng chung danh sách cụm danh từ với bộ sinh.
 *    · kết hợp từ — KHÔNG phải kiểm lời giải mà là kiểm CHẤT LƯỢNG ĐỀ: bảo
 *      đảm đáp án đúng có trong bảng và MỌI phương án nhiễu đều KHÔNG đi được
 *      với cụm đó. Đây chính là chỗ đề trắc nghiệm hay hỏng: có hai đáp án
 *      cùng đúng.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const G = require('./en-grammar');
const { dongTuCho } = require('./en-collocation');


// ═══════════════════════════════════════════════════════════════════════════
//  ĐỌC HIỂU, VIẾT LUẬN, NÓI THEO CHỦ ĐỀ — kiểm CHẤT LƯỢNG ĐỀ bằng cách ĐỌC
//  LẠI CHÍNH ĐOẠN VĂN, không tin vào lời khai của bộ sinh.
// ═══════════════════════════════════════════════════════════════════════════
//  Bốn dạng này không có phép biến đổi ngữ pháp để giải lại. Cái kiểm được —
//  và cũng là cái quyết định đề hay hay đề hỏng — là QUAN HỆ GIỮA PHƯƠNG ÁN
//  VÀ VĂN BẢN:
//    · ý chính phải TRẢI trên nhiều câu; nếu nó nằm gọn trong một câu thì đó
//      là chi tiết, không phải ý chính;
//    · câu suy luận phải BÁM VÀO BÀI mà KHÔNG được có sẵn trong bài; nếu một
//      câu của bài đã chứa đủ nó thì đề đang hỏi lại điều đã nêu;
//    · dàn ý phải phục vụ ĐÚNG DẠNG CÂU HỎI, mà dạng câu hỏi đọc ra được từ
//      chính chữ của đề ("to what extent do you agree" ≠ "discuss both views");
//    · bài nói phải chạm ĐỦ BỐN GẠCH ĐẦU DÒNG của thẻ đề.
//  Bộ kiểm tự tách câu, tự lấy từ nội dung, tự đếm — bộ sinh khai gì cũng
//  phải chịu kết quả đọc lại này.

const TU_CHUC_NANG = new Set(('a an the of in on at to and or but is are was were be been being that this these those it its '
  + 'for with as by from they their them he she his her we our us you your i my me there here when where which who whom whose '
  + 'what how why if while also such very into about after before between during over under up down than then so because since '
  + 'more most less least some many much few can could will would shall should may might must do does did have has had both '
  + 'each any one two three own other others however therefore thus still yet even again just now make makes made get gets got '
  + 'go goes went say says said see sees saw take takes took come comes came use uses used put puts let lets am out').split(' '));

const TU_PHAM_VI = ['all', 'every', 'always', 'never', 'none', 'entirely', 'completely', 'only', 'nobody', 'everyone'];
// Ngưỡng bám bài. Phương án đúng phải nói về chính đoạn này (bắt được ít nhất
// bảy phần mười số từ nội dung vào bài); phương án "ngoài bài" phải lạc hẳn
// (bắt được nhiều nhất một nửa). Khoảng trống giữa hai ngưỡng là chỗ đề không
// được rơi vào — rơi vào đó nghĩa là nhiễu và đáp án gần nhau quá.
const BAM_TOI_THIEU = 0.7;
const BAM_LAC = 0.5;

const TU_PHU_DINH = ['not', 'never', 'no', 'cannot', 'fewer', 'less', 'rarely', 'without', 'nothing', 'none', 'nobody'];

/** Rút gọn một từ về dạng gốc thô, đủ để "students" gặp được "student". */
function goc(tu) {
  const t = String(tu).toLowerCase().replace(/[^a-z]/g, '');
  if (t.length > 4 && t.endsWith('ies')) return `${t.slice(0, -3)}y`;
  if (t.length > 5 && t.endsWith('ing')) return t.slice(0, -3);
  if (t.length > 4 && t.endsWith('ed')) return t.slice(0, -2);
  if (t.length > 4 && t.endsWith('es')) return t.slice(0, -2);
  if (t.length > 3 && t.endsWith('s')) return t.slice(0, -1);
  return t;
}

/** Các từ MANG NGHĨA của một chuỗi: bỏ từ chức năng, bỏ từ quá ngắn. */
function tuNoiDung(vanBan) {
  const ra = [];
  for (const w of String(vanBan || '').toLowerCase().split(/[^a-z']+/)) {
    if (!w || TU_CHUC_NANG.has(w)) continue;
    const g = goc(w);
    if (g.length >= 3 && !TU_CHUC_NANG.has(g)) ra.push(g);
  }
  return ra;
}

/** Tách đoạn thành câu. Dấu chấm, chấm hỏi, chấm than mới kết thúc câu. */
function cauCua(vanBan) {
  return String(vanBan || '').split(/(?<=[.!?])\s+/).map((c) => c.trim()).filter((c) => c.length > 1);
}

const boTu = (s) => new Set(tuNoiDung(s));
/** Số câu có ÍT NHẤT một từ nội dung của phương án — độ TRẢI của phương án. */
const trai = (cacCau, tu) => cacCau.filter((c) => { const s = boTu(c); return tu.some((t) => s.has(t)); }).length;
/** Số câu chứa ĐỦ mọi từ nội dung của phương án — phương án đã được nêu thẳng. */
const cauChuaDu = (cacCau, tu) => cacCau.filter((c) => { const s = boTu(c); return tu.every((t) => s.has(t)); }).length;
/** Tỉ lệ từ của phương án bắt được vào bài — độ BÁM BÀI. */
const bamBai = (bai, tu) => { if (!tu.length) return 0; const s = boTu(bai); return tu.filter((t) => s.has(t)).length / tu.length; };
/** Những từ của phương án KHÔNG có trong bài. */
const tuLa = (bai, tu) => { const s = boTu(bai); return [...new Set(tu.filter((t) => !s.has(t)))]; };
/** Mọi từ của một chuỗi, chưa bỏ từ chức năng — "no", "not" chỉ có hai, ba
 *  chữ cái nên không lọt vào danh sách từ nội dung, mà chúng lại là thứ quyết
 *  định một phương án có trái bài hay không. */
const tuTho = (vanBan) => new Set(String(vanBan || '').toLowerCase().split(/[^a-z']+/).filter(Boolean));
/** Từ phạm vi (hoặc phủ định) có trong phương án mà bài không hề nói. */
const tuThem = (bang, bai, y) => {
  const cb = tuTho(bai); const cy = tuTho(y);
  return bang.filter((w) => cy.has(w) && !cb.has(w));
};

function kiemYChinh(ck, dapAn) {
  const ten = 'đọc hiểu ý chính';
  const cacCau = cauCua(ck.doan);
  if (cacCau.length < 4) return { dat: false, ten, chiTiet: `đoạn chỉ có ${cacCau.length} câu, không đủ để hỏi ý chính` };
  const tuDung = tuNoiDung(ck.dapAnDung);
  if (!tuDung.length) return { dat: false, ten, chiTiet: 'phương án đúng không có từ nội dung nào' };

  const bam = bamBai(ck.doan, tuDung);
  if (bam < BAM_TOI_THIEU) {
    return { dat: false, ten, chiTiet: `phương án đúng chỉ bám bài ${Math.round(bam * 100)}% số từ nội dung — ý chính phải nói về chính đoạn này` };
  }
  const rong = tuThem(TU_PHAM_VI, ck.doan, ck.dapAnDung);
  if (rong.length) return { dat: false, ten, chiTiet: `phương án đúng nói quá phạm vi bài: "${rong.join(', ')}" không có trong bài` };
  const raiDung = trai(cacCau, tuDung);
  if (raiDung < 3) return { dat: false, ten, chiTiet: `phương án đúng chỉ chạm ${raiDung} câu — ý chính phải trải trên ít nhất 3 câu` };
  if (cauChuaDu(cacCau, tuDung) > 0) {
    return { dat: false, ten, chiTiet: 'một câu của bài đã chứa đủ phương án đúng — đó là chi tiết của câu đó, không phải ý chính của cả đoạn' };
  }

  // Phương án nào cũng phải HỎNG theo đúng kiểu đã khai, và không phương án
  // nhiễu nào được đạt cả ba điều kiện của ý chính — có thế đề mới một đáp án.
  const laYChinh = (y) => {
    const t = tuNoiDung(y);
    return t.length > 0 && bamBai(ck.doan, t) >= BAM_TOI_THIEU && !tuThem(TU_PHAM_VI, ck.doan, y).length
      && cauChuaDu(cacCau, t) === 0 && trai(cacCau, t) >= 3;
  };
  for (const n of ck.nhieu || []) {
    const tuN = tuNoiDung(n.y);
    const laN = tuLa(ck.doan, tuN);
    const rongN = tuThem(TU_PHAM_VI, ck.doan, n.y);
    if (n.loai === 'chi-tiet') {
      if (cauChuaDu(cacCau, tuN) === 0) return { dat: false, ten, chiTiet: `nhiễu chi tiết "${n.y}" không nằm gọn trong câu nào của bài` };
    } else if (n.loai === 'ngoai-bai') {
      const bamN = bamBai(ck.doan, tuN);
      if (bamN > BAM_LAC) return { dat: false, ten, chiTiet: `nhiễu ngoài bài "${n.y}" vẫn bám bài ${Math.round(bamN * 100)}% — chưa đủ lạc để loại` };
    } else if (n.loai === 'qua-rong') {
      if (!rongN.length) return { dat: false, ten, chiTiet: `nhiễu quá rộng "${n.y}" không có từ phạm vi nào vượt bài` };
    } else {
      return { dat: false, ten, chiTiet: `loại nhiễu "${n.loai}" chưa khai báo được` };
    }
    if (laYChinh(n.y)) return { dat: false, ten, chiTiet: `đề mập mờ: nhiễu "${n.y}" cũng đạt đủ điều kiện của một ý chính` };
  }
  const khop = chuan(ck.dapAnDung) === chuan(dapAn);
  return {
    dat: khop, ten, suyRa: ck.dapAnDung,
    chiTiet: khop
      ? `đọc lại ${cacCau.length} câu: chỉ phương án đúng trải trên ${raiDung} câu, ${(ck.nhieu || []).length} nhiễu đều hỏng theo đúng kiểu đã khai`
      : `bộ kiểm chọn "${ck.dapAnDung}", đáp án khai "${dapAn}"`,
  };
}

function kiemSuyLuan(ck, dapAn) {
  const ten = 'đọc hiểu suy luận';
  const cacCau = cauCua(ck.doan);
  if (cacCau.length < 3) return { dat: false, ten, chiTiet: `đoạn chỉ có ${cacCau.length} câu, không đủ dữ kiện để suy` };
  const tuDung = tuNoiDung(ck.dapAnDung);
  const bam = bamBai(ck.doan, tuDung);
  if (bam < BAM_TOI_THIEU) {
    return { dat: false, ten, chiTiet: `câu suy luận đúng chỉ bám bài ${Math.round(bam * 100)}% số từ nội dung — suy luận phải bám vào dữ kiện của bài` };
  }
  const phuDinh = tuThem(TU_PHU_DINH, ck.doan, ck.dapAnDung);
  if (phuDinh.length) return { dat: false, ten, chiTiet: `câu suy luận đúng phủ định điều bài không hề phủ định: "${phuDinh.join(', ')}"` };
  if (cauChuaDu(cacCau, tuDung) > 0) return { dat: false, ten, chiTiet: 'câu suy luận đúng đã được nêu thẳng trong một câu của bài — đó là câu hỏi chi tiết, không phải suy luận' };
  const raiDung = trai(cacCau, tuDung);
  if (raiDung < 2) return { dat: false, ten, chiTiet: `câu suy luận đúng chỉ dựa vào ${raiDung} câu — suy luận cần nối ít nhất hai dữ kiện` };

  for (const n of ck.nhieu || []) {
    const tuN = tuNoiDung(n.y);
    const laN = tuLa(ck.doan, tuN);
    const duN = cauChuaDu(cacCau, tuN);
    const phuDinhN = tuThem(TU_PHU_DINH, ck.doan, n.y);
    if (n.loai === 'da-neu') {
      if (duN === 0) return { dat: false, ten, chiTiet: `nhiễu "đã nêu" — "${n.y}" — không có câu nào của bài chứa đủ nó` };
    } else if (n.loai === 'ngoai-bai') {
      const bamN = bamBai(ck.doan, tuN);
      if (bamN > BAM_LAC) return { dat: false, ten, chiTiet: `nhiễu ngoài bài "${n.y}" vẫn bám bài ${Math.round(bamN * 100)}% — chưa đủ lạc để loại` };
    } else if (n.loai === 'trai-bai') {
      if (!phuDinhN.length) return { dat: false, ten, chiTiet: `nhiễu trái bài "${n.y}" không chứa từ phủ định nào vượt bài` };
    } else {
      return { dat: false, ten, chiTiet: `loại nhiễu "${n.loai}" chưa khai báo được` };
    }
    const nhuDapAn = bamBai(ck.doan, tuN) >= BAM_TOI_THIEU && duN === 0 && !phuDinhN.length && trai(cacCau, tuN) >= 2;
    if (nhuDapAn) return { dat: false, ten, chiTiet: `đề mập mờ: nhiễu "${n.y}" cũng là một suy luận hợp lệ của bài` };
  }
  const khop = chuan(ck.dapAnDung) === chuan(dapAn);
  return {
    dat: khop, ten, suyRa: ck.dapAnDung,
    chiTiet: khop
      ? `đọc lại ${cacCau.length} câu: phương án đúng bám bài mà không câu nào nêu thẳng, ${(ck.nhieu || []).length} nhiễu đều hỏng theo đúng kiểu đã khai`
      : `bộ kiểm chọn "${ck.dapAnDung}", đáp án khai "${dapAn}"`,
  };
}

// Dạng đề IELTS Task 2 đọc ra được từ CHÍNH CHỮ CỦA ĐỀ, không cần ai khai.
const DAU_HIEU_DE = [
  { dang: 'dong-y', re: /to what extent do you agree|do you agree or disagree/i },
  { dang: 'hai-quan-diem', re: /discuss both (?:these )?(?:views|sides)/i },
  { dang: 'van-de-giai-phap', re: /what (?:are the )?problems.*what (?:are the )?solutions|problems.*what can be done/i },
  { dang: 'nguyen-nhan-giai-phap', re: /what (?:are the )?causes.*(?:solutions|measures|what can be done)/i },
  { dang: 'hai-mat', re: /advantages and disadvantages|advantages outweigh/i },
];

// Mỗi dạng đòi một bộ dấu hiệu trong câu chủ đề. Thiếu dấu hiệu là dàn ý lạc.
const DAU_HIEU_LUAN = {
  'dong-y': [/\b(agree|disagree)\b/i, /\b(because|since)\b/i],
  'hai-quan-diem': [/\b(while|although)\b/i, /\bI\s+(believe|think|argue|would)\b/i],
  'van-de-giai-phap': [/\bproblem/i, /\b(solution|measure)/i],
  'nguyen-nhan-giai-phap': [/\bcause/i, /\b(solution|measure)/i],
  'hai-mat': [/\badvantage/i, /\b(disadvantage|drawback)/i],
};

function kiemDeLuan(ck, dapAn) {
  const ten = 'viết luận học thuật';
  const doc = DAU_HIEU_DE.filter((d) => d.re.test(ck.de));
  if (doc.length !== 1) {
    return { dat: false, ten, chiTiet: doc.length ? `đề khớp ${doc.length} dạng câu hỏi cùng lúc: ${doc.map((d) => d.dang).join(', ')}` : 'không đọc ra dạng câu hỏi từ chữ của đề' };
  }
  const dang = doc[0].dang;
  const dauHieu = DAU_HIEU_LUAN[dang];
  const thieu = dauHieu.filter((re) => !re.test(ck.dapAnDung));
  if (thieu.length) return { dat: false, ten, chiTiet: `đề thuộc dạng "${dang}" nhưng câu chủ đề đúng thiếu dấu hiệu bắt buộc của dạng đó` };

  for (const n of ck.nhieu || []) {
    const du = dauHieu.filter((re) => re.test(n.y));
    if (du.length === dauHieu.length) {
      return { dat: false, ten, chiTiet: `đề mập mờ: câu chủ đề nhiễu "${n.y}" cũng đủ dấu hiệu của dạng "${dang}"` };
    }
  }
  const khop = chuan(ck.dapAnDung) === chuan(dapAn);
  return {
    dat: khop, ten, suyRa: ck.dapAnDung,
    chiTiet: khop
      ? `đọc chữ của đề ra dạng "${dang}"; chỉ một câu chủ đề đủ dấu hiệu của dạng đó`
      : `bộ kiểm chọn "${ck.dapAnDung}", đáp án khai "${dapAn}"`,
  };
}

function kiemTheNoi(ck, dapAn) {
  const ten = 'nói theo chủ đề';
  const dong = String(ck.the || '').split('\n').map((d) => d.trim()).filter(Boolean);
  const gach = dong.filter((d) => d.startsWith('·')).map((d) => d.replace(/^·\s*/, ''));
  if (gach.length !== 4) return { dat: false, ten, chiTiet: `thẻ đề có ${gach.length} gạch đầu dòng, thẻ IELTS Part 2 phải có đúng 4` };
  const gachRong = gach.filter((g) => tuNoiDung(g).length === 0);
  if (gachRong.length) return { dat: false, ten, chiTiet: `gạch đầu dòng "${gachRong[0]}" toàn từ chức năng, không có gì để đối chiếu với dàn ý` };
  const dongChuDe = dong.find((d) => !d.startsWith('·')) || '';
  const tuChuDe = tuNoiDung(dongChuDe).filter((t) => t !== 'describe' && t !== 'should');
  if (!tuChuDe.length) return { dat: false, ten, chiTiet: 'dòng chủ đề của thẻ không có từ nội dung nào' };

  const chamChuDe = (bai) => { const s = boTu(bai); return tuChuDe.some((t) => s.has(t)); };
  const soGachCham = (bai) => { const s = boTu(bai); return gach.filter((g) => tuNoiDung(g).some((t) => s.has(t))).length; };

  if (!chamChuDe(ck.dapAnDung)) return { dat: false, ten, chiTiet: 'dàn ý đúng không nhắc tới chủ đề của thẻ' };
  const duDung = soGachCham(ck.dapAnDung);
  if (duDung !== 4) return { dat: false, ten, chiTiet: `dàn ý đúng chỉ chạm ${duDung}/4 gạch đầu dòng` };

  for (const n of ck.nhieu || []) {
    if (n.loai === 'bo-sot') {
      if (!chamChuDe(n.y)) return { dat: false, ten, chiTiet: `nhiễu bỏ sót "${n.y.slice(0, 40)}…" lại lạc luôn chủ đề — sai loại nhiễu đã khai` };
      const c = soGachCham(n.y);
      if (c === 4) return { dat: false, ten, chiTiet: 'đề mập mờ: nhiễu bỏ sót lại chạm đủ cả 4 gạch đầu dòng' };
    } else if (n.loai === 'lac-de') {
      if (chamChuDe(n.y)) return { dat: false, ten, chiTiet: `nhiễu lạc đề "${n.y.slice(0, 40)}…" vẫn nhắc đúng chủ đề của thẻ` };
    } else {
      return { dat: false, ten, chiTiet: `loại nhiễu "${n.loai}" chưa khai báo được` };
    }
  }
  const khop = chuan(ck.dapAnDung) === chuan(dapAn);
  return {
    dat: khop, ten, suyRa: ck.dapAnDung,
    chiTiet: khop
      ? `tách 4 gạch đầu dòng của thẻ: chỉ dàn ý đúng chạm đủ cả 4 và bám chủ đề`
      : `bộ kiểm chọn dàn ý khác với đáp án khai`,
  };
}

const chuan = (s) => String(s || '').trim().replace(/\s+/g, ' ').replace(/\s+([.,?!])/g, '$1');
const bang = (a, b) => chuan(a) === chuan(b);

/**
 * @param {object} ck  phần check.english của bài
 * @param {string} dapAn  đáp án mà bộ sinh khai báo
 * @returns {{dat:boolean, ten:string, chiTiet:string, suyRa?:string}}
 */
function kiemTiengAnh(ck = {}, dapAn = '') {
  const kieu = ck.kieu;

  if (kieu === 'y chinh') return kiemYChinh(ck, dapAn);
  if (kieu === 'suy luan') return kiemSuyLuan(ck, dapAn);
  if (kieu === 'de luan') return kiemDeLuan(ck, dapAn);
  if (kieu === 'the noi') return kiemTheNoi(ck, dapAn);

  if (kieu === 'bi dong') {
    const p = G.phanTichCau(ck.nguon);
    if (!p.ok) return { dat: false, ten: 'câu bị động', chiTiet: `không đọc được câu nguồn: ${p.error}` };
    const suyRa = G.biDong({ cn: p.cn, v: p.v, tn: p.tn, thi: p.thi, coBoi: ck.boi !== false });
    return {
      dat: bang(suyRa, dapAn), ten: 'câu bị động', suyRa,
      chiTiet: bang(suyRa, dapAn) ? `đọc lại câu nguồn rồi tự đổi, ra đúng "${suyRa}"` : `bộ kiểm ra "${suyRa}", đáp án khai "${dapAn}"`,
    };
  }

  if (kieu === 'thi') {
    const p = G.phanTichCau(ck.nguon);
    if (!p.ok) return { dat: false, ten: 'chia thì', chiTiet: `không đọc được câu nguồn: ${p.error}` };
    const suyRa = `${p.cn.viet} ${G.chia(p.v, ck.thiDich, p.cn)} ${p.tn.viet}${ck.trangNgu ? ` ${ck.trangNgu}` : ''}.`;
    return {
      dat: bang(suyRa, dapAn), ten: 'chia thì', suyRa,
      chiTiet: bang(suyRa, dapAn) ? `dò ngược động từ về "${p.v}" rồi chia lại, ra đúng` : `bộ kiểm ra "${suyRa}", đáp án khai "${dapAn}"`,
    };
  }

  if (kieu === 'tuong thuat') {
    const p = G.phanTichCau(ck.nguon);
    if (!p.ok) return { dat: false, ten: 'câu tường thuật', chiTiet: `không đọc được câu nguồn: ${p.error}` };
    const suyRa = G.tuongThuat({ nguoiNoi: ck.nguoiNoi, cn: p.cn, v: p.v, tn: p.tn, thi: p.thi, trangNgu: ck.trangNgu || null });
    return {
      dat: bang(suyRa, dapAn), ten: 'câu tường thuật', suyRa,
      chiTiet: bang(suyRa, dapAn) ? `lùi thì từ "${p.thi}" sang "${G.LUI_THI[p.thi]}", ra đúng` : `bộ kiểm ra "${suyRa}", đáp án khai "${dapAn}"`,
    };
  }

  if (kieu === 'dieu kien') {
    const a = G.phanTichCau(ck.nguonA);
    const b = G.phanTichCau(ck.nguonB);
    if (!a.ok || !b.ok) return { dat: false, ten: 'câu điều kiện', chiTiet: `không đọc được câu nguồn: ${a.error || b.error}` };
    const suyRa = G.dieuKien({ cnA: a.cn, vA: a.v, tnA: a.tn, cnB: b.cn, vB: b.v, tnB: b.tn, loai: ck.loai });
    return {
      dat: bang(suyRa, dapAn), ten: `câu điều kiện loại ${ck.loai}`, suyRa,
      chiTiet: bang(suyRa, dapAn) ? `dựng lại từ hai câu nguồn, ra đúng` : `bộ kiểm ra "${suyRa}", đáp án khai "${dapAn}"`,
    };
  }

  if (kieu === 'quan he') {
    const b = G.phanTichCau(ck.nguonB);
    if (!b.ok) return { dat: false, ten: 'mệnh đề quan hệ', chiTiet: `không đọc được mệnh đề phụ: ${b.error}` };
    const menhDe = `${G.chia(b.v, b.thi, b.cn)} ${b.tn.viet}`;
    const suyRa = G.quanHe({
      danhTu: ck.danhTu, nguoi: ck.nguoi, menhDe,
      cauChinh: ck.cauChinh, xacDinh: ck.xacDinh,
    });
    const dat = bang(suyRa, dapAn);
    // Luật dấu phẩy là chỗ mất điểm chính, nên kiểm riêng một lần nữa.
    const coPhay = /,/.test(chuan(dapAn));
    const dungPhay = ck.xacDinh ? !coPhay : coPhay;
    return {
      dat: dat && dungPhay, ten: 'mệnh đề quan hệ', suyRa,
      chiTiet: !dungPhay
        ? (ck.xacDinh ? 'mệnh đề xác định KHÔNG được có dấu phẩy' : 'mệnh đề không xác định BẮT BUỘC có hai dấu phẩy')
        : dat ? 'nối lại hai câu nguồn, ra đúng' : `bộ kiểm ra "${suyRa}", đáp án khai "${dapAn}"`,
    };
  }

  if (kieu === 'ket hop tu') {
    const dung = dongTuCho(ck.cum);
    if (!dung.length) return { dat: false, ten: 'kết hợp từ', chiTiet: `cụm "${ck.cum}" chưa có trong bảng kết hợp` };
    if (!dung.includes(ck.dapAnDung)) {
      return { dat: false, ten: 'kết hợp từ', chiTiet: `"${ck.dapAnDung} ${ck.cum}" không có trong bảng; bảng ghi: ${dung.join(', ')}` };
    }
    const nhieuNghia = (ck.nhieu || []).filter((v) => dung.includes(v));
    if (nhieuNghia.length) {
      return { dat: false, ten: 'kết hợp từ', chiTiet: `đề mập mờ: phương án nhiễu ${nhieuNghia.join(', ')} cũng đi được với "${ck.cum}"` };
    }
    if (dung.length > 1) {
      return { dat: false, ten: 'kết hợp từ', chiTiet: `cụm "${ck.cum}" đi được với ${dung.length} động từ, không ra đề một đáp án được` };
    }
    return { dat: bang(ck.dapAnDung, dapAn), ten: 'kết hợp từ', suyRa: ck.dapAnDung, chiTiet: `tra bảng: chỉ "${ck.dapAnDung}" đi được với "${ck.cum}", mọi phương án nhiễu đều sai` };
  }

  return { dat: false, ten: 'tiếng Anh', chiTiet: `chưa hỗ trợ kiểu kiểm "${kieu}"` };
}

module.exports = { kiemTiengAnh, chuan, tuNoiDung, cauCua, goc, DAU_HIEU_DE, DAU_HIEU_LUAN };
