'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐO ĐỘ KHÓ CỦA VĂN BẢN TIẾNG VIỆT
 * ═══════════════════════════════════════════════════════════════════════════
 *  Một đề toán lớp 3 viết bằng câu bốn mươi tiếng thì học sinh trượt ở khâu
 *  ĐỌC chứ không phải khâu TOÁN. Đo được chỗ đó thì sửa được.
 *
 *  Đo cái gì — và vì sao đo được:
 *   · Số tiếng mỗi câu. Tiếng Việt viết rời từng tiếng nên đếm chính xác,
 *     không phải ước lượng âm tiết như tiếng Anh.
 *   · Tỉ lệ tiếng có vần khó (nguyên âm đôi kèm âm cuối: "nghiêng", "chuyện").
 *     Tính bằng bộ tách âm tiết, không bằng cảm tính.
 *   · Mật độ mệnh đề: đếm các từ nối ("và", "nhưng", "nếu", "thì"…).
 *   · Tỉ lệ tiếng dài từ 5 chữ cái trở lên.
 *
 *  MỘT LỜI THẬT VỀ NGƯỠNG THEO LỚP. Bảng NGUONG_LOP bên dưới là QUY ƯỚC BIÊN
 *  TẬP, không phải số đo từ một kho ngữ liệu chuẩn — hệ thống này chưa có kho
 *  ngữ liệu đủ lớn để hiệu chỉnh (xem thongKeTheoLop(): kho học liệu hiện chỉ
 *  có vài bài mỗi lớp, và đề toán thì câu chữ rất khuôn mẫu). Bảng này sửa
 *  được bằng cấu hình. Hàm thongKeTheoLop() trả về SỐ ĐO THẬT của kho để khi
 *  nào kho đủ dày thì hiệu chỉnh lại bằng dữ liệu chứ không bằng phỏng đoán.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { parseSyllable } = require('../voice/phonemizer');
const { cacCau, cacTieng } = require('./chinhta');
const { round } = require('../utils');

/** Từ nối làm câu dài thêm một mệnh đề. */
const TU_NOI = ['và', 'nhưng', 'hoặc', 'nếu', 'thì', 'mà', 'vì', 'nên', 'rằng',
  'khi', 'để', 'dù', 'tuy', 'còn', 'song', 'bởi', 'do', 'nhờ', 'tại'];

/**
 * Ngưỡng số tiếng trung bình mỗi câu theo lớp — QUY ƯỚC BIÊN TẬP.
 * toiDa là trần cho MỘT câu; trungBinh là mức mong muốn của cả bài.
 */
const NGUONG_LOP = {
  1: { trungBinh: 7, toiDa: 12, vanKho: 0.10 },
  2: { trungBinh: 9, toiDa: 15, vanKho: 0.12 },
  3: { trungBinh: 11, toiDa: 18, vanKho: 0.15 },
  4: { trungBinh: 13, toiDa: 22, vanKho: 0.18 },
  5: { trungBinh: 14, toiDa: 24, vanKho: 0.20 },
  6: { trungBinh: 16, toiDa: 26, vanKho: 0.22 },
  7: { trungBinh: 17, toiDa: 28, vanKho: 0.24 },
  8: { trungBinh: 18, toiDa: 30, vanKho: 0.26 },
  9: { trungBinh: 19, toiDa: 32, vanKho: 0.28 },
  10: { trungBinh: 21, toiDa: 34, vanKho: 0.30 },
  11: { trungBinh: 22, toiDa: 36, vanKho: 0.32 },
  12: { trungBinh: 24, toiDa: 38, vanKho: 0.34 },
};

/** Một tiếng có vần khó không: nguyên âm đôi đi kèm âm cuối. */
function vanKho(tieng) {
  const p = parseSyllable(String(tieng).toLowerCase());
  if (!p.ok) return false;
  return (p.nucleus.kind !== 'mono' && !!p.coda) || (!!p.glide && !!p.coda);
}

/**
 * Bỏ công thức khỏi văn bản trước khi đo: công thức không phải lời văn.
 * Thay bằng MỘT tiếng duy nhất. Nếu thay bằng cụm hai tiếng như "công thức"
 * thì mỗi công thức tự cộng thêm một tiếng vào phép đo, và một đề bài ngắn
 * đầy công thức bị chấm là câu dài — sai chỗ mà rất khó nhìn ra.
 */
function boCongThuc(text) {
  return String(text || '')
    .replace(/\$[^$]*\$/g, ' X ')
    .replace(/[0-9]+([.,][0-9]+)?/g, ' X ');
}

/**
 * Đo một đoạn văn.
 * @returns {{soCau, soTieng, tiengMoiCau, cauDaiNhat, tiLeVanKho, matDoMenhDe, tiLeTiengDai}}
 */
function doDoc(text) {
  const goc = String(text || '');
  const van = boCongThuc(goc);
  const cau = cacCau(van).filter((c) => c.replace(/[^\p{L}]/gu, '').length > 0);
  const tieng = cacTieng(van).map((t) => t.tu);

  const theoCau = cau.map((c) => cacTieng(c).length);
  const soTieng = tieng.length || 0;
  const soCau = cau.length || 0;
  const kho = tieng.filter(vanKho).length;
  const dai = tieng.filter((t) => t.length >= 5).length;
  const noi = tieng.filter((t) => TU_NOI.includes(t.toLowerCase())).length;

  return {
    soCau,
    soTieng,
    tiengMoiCau: soCau ? round(soTieng / soCau, 1) : 0,
    cauDaiNhat: theoCau.length ? Math.max(...theoCau) : 0,
    theoCau,
    tiLeVanKho: soTieng ? round(kho / soTieng, 3) : 0,
    matDoMenhDe: soCau ? round(noi / soCau, 2) : 0,
    tiLeTiengDai: soTieng ? round(dai / soTieng, 3) : 0,
    soCongThuc: (goc.match(/\$[^$]*\$/g) || []).length,
  };
}

/**
 * Văn bản này có vừa sức học sinh lớp `lop` không.
 * Trả về từng phép đo kèm ngưỡng, để người sửa biết phải cắt câu nào.
 */
function hopVoiLop(text, lop, { nguong = NGUONG_LOP } = {}) {
  const l = Number(lop);
  const n = nguong[l];
  if (!n) return { ok: false, error: 'KHÔNG_CÓ_NGƯỠNG_CHO_LỚP_NÀY', lop, coLop: Object.keys(nguong).map(Number) };
  const d = doDoc(text);
  const loi = [];

  if (d.tiengMoiCau > n.trungBinh) {
    loi.push({
      muc: d.tiengMoiCau > n.trungBinh * 1.4 ? 'LOI' : 'CANH_BAO',
      ma: 'CAU_DAI',
      moTa: `Trung bình ${d.tiengMoiCau} tiếng/câu, ngưỡng lớp ${l} là ${n.trungBinh}`,
      cach: 'Cắt câu dài thành hai câu ngắn.',
    });
  }
  if (d.cauDaiNhat > n.toiDa) {
    const i = d.theoCau.indexOf(d.cauDaiNhat);
    loi.push({
      muc: 'LOI',
      ma: 'CAU_VUOT_TRAN',
      moTa: `Có câu dài ${d.cauDaiNhat} tiếng (câu ${i + 1}), trần của lớp ${l} là ${n.toiDa}`,
      cach: 'Tách câu đó ra.',
    });
  }
  if (d.tiLeVanKho > n.vanKho) {
    loi.push({
      muc: 'CANH_BAO',
      ma: 'NHIEU_VAN_KHO',
      moTa: `${Math.round(d.tiLeVanKho * 100)}% tiếng có vần khó, ngưỡng lớp ${l} là ${Math.round(n.vanKho * 100)}%`,
      cach: 'Thay bằng từ quen thuộc hơn với lứa tuổi.',
    });
  }
  if (d.matDoMenhDe > 2.5) {
    loi.push({ muc: 'CANH_BAO', ma: 'NHIEU_MENH_DE', moTa: `Trung bình ${d.matDoMenhDe} từ nối mỗi câu`, cach: 'Bớt mệnh đề phụ.' });
  }

  const soLoi = loi.filter((x) => x.muc === 'LOI').length;
  return {
    ok: soLoi === 0,
    lop: l,
    doDo: d,
    nguong: n,
    loi,
    diem: Math.max(0, 100 - soLoi * 20 - (loi.length - soLoi) * 7),
    ketLuan: soLoi === 0
      ? (loi.length ? `Đọc được với lớp ${l}, nhưng nên sửa ${loi.length} chỗ.` : `Vừa sức lớp ${l}.`)
      : `Quá sức lớp ${l} — phải sửa trước khi dùng.`,
  };
}

/** Lớp phù hợp nhất với văn bản, theo chính bảng ngưỡng. */
function doanLop(text, { nguong = NGUONG_LOP } = {}) {
  const d = doDoc(text);
  if (!d.soCau) return { ok: false, error: 'KHÔNG_CÓ_CÂU_NÀO' };
  const hop = Object.entries(nguong)
    .filter(([, n]) => d.tiengMoiCau <= n.trungBinh && d.cauDaiNhat <= n.toiDa)
    .map(([l]) => Number(l));
  return {
    ok: true,
    lopThapNhat: hop.length ? Math.min(...hop) : null,
    doDo: d,
    ghiChu: hop.length
      ? `Văn bản vừa sức từ lớp ${Math.min(...hop)} trở lên.`
      : 'Văn bản dài hơn ngưỡng của mọi lớp trong bảng — nên cắt câu.',
  };
}

/**
 * SỐ ĐO THẬT của kho học liệu theo lớp.
 * Dùng để đối chiếu với bảng quy ước, và để hiệu chỉnh lại bảng khi kho đã đủ
 * dày. Trả kèm cỡ mẫu và lời cảnh báo khi mẫu quá nhỏ — số đo trên ba bài
 * không nói lên điều gì.
 */
function thongKeTheoLop(bank, { toiThieu = 30 } = {}) {
  if (!bank) return { ok: false, error: 'CHƯA_GẮN_KHO_HỌC_LIỆU' };
  const { FORM_INDEX } = require('../curriculum/hierarchy');
  const theo = new Map();
  for (const f of FORM_INDEX.values()) {
    const lop = Number((f.code.match(/^M(\d+)/) || [])[1]);
    if (!lop) continue;
    for (const b of bank.query({ formCode: f.code, limit: 200 })) {
      const d = doDoc(b.stem);
      if (!d.soCau) continue;
      if (!theo.has(lop)) theo.set(lop, []);
      theo.get(lop).push(d.tiengMoiCau);
    }
  }
  const hang = [...theo.entries()].sort((a, b) => a[0] - b[0]).map(([lop, ds]) => {
    const tb = ds.reduce((s, x) => s + x, 0) / ds.length;
    const sd = Math.sqrt(ds.reduce((s, x) => s + (x - tb) ** 2, 0) / ds.length);
    return {
      lop, coMau: ds.length,
      tiengMoiCau: round(tb, 1), doLech: round(sd, 1),
      quyUoc: NGUONG_LOP[lop] ? NGUONG_LOP[lop].trungBinh : null,
      duMau: ds.length >= toiThieu,
    };
  });
  const du = hang.filter((h) => h.duMau).length;
  return {
    ok: true,
    hang,
    coLop: hang.length,
    duMauDeHieuChinh: du === hang.length && hang.length >= 9,
    ghiChu: du === hang.length && hang.length >= 9
      ? 'Kho đã đủ dày để hiệu chỉnh bảng ngưỡng bằng số đo thật.'
      : `Mới ${du}/${hang.length} lớp đủ ${toiThieu} bài. Bảng ngưỡng vẫn là quy ước biên tập, `
        + 'chưa phải số đo — gieo thêm học liệu rồi hãy hiệu chỉnh.',
  };
}

module.exports = { doDoc, hopVoiLop, doanLop, thongKeTheoLop, vanKho, NGUONG_LOP, TU_NOI };
