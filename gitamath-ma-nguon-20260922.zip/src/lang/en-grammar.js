'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HÌNH THÁI VÀ CÚ PHÁP TIẾNG ANH — để SINH và để KIỂM bài ngữ pháp
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bài ngữ pháp tiếng Anh không kiểm được bằng bộ kiểm chứng toán học, nên
 *  nếu không có bộ này thì mọi bài tiếng Anh sẽ vào kho mà KHÔNG ai giải lại.
 *  Đó là điều hệ thống không cho phép.
 *
 *  Cách làm ở đây đúng theo nguyên tắc đã dùng cho môn toán — hai đường độc
 *  lập phải gặp nhau:
 *
 *    đường 1 (bộ sinh)  GHÉP câu đích từ các mảnh đã biết: chủ ngữ, động từ
 *                       đã chia, tân ngữ, trạng ngữ.
 *    đường 2 (bộ kiểm)  ĐỌC LẠI câu nguồn như một người học đọc đề: tách câu
 *                       thành thành phần, tra từ điển hình thái, rồi tự biến
 *                       đổi. Không dùng lại một mảnh nào của đường 1.
 *
 *  Hai đường cho ra khác nhau nghĩa là có lỗi, và bài bị chặn ngay tại cửa
 *  kho. Đây là phép kiểm thật, không phải dấu tick cho có.
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ── ĐỘNG TỪ BẤT QUY TẮC ─────────────────────────────────────────────────────
// [quá khứ đơn, quá khứ phân từ]. Động từ không có ở đây sẽ được chia bằng
// luật bên dưới — đúng như cách người học được dạy.
const BAT_QUY_TAC = {
  be: ['was', 'been'], begin: ['began', 'begun'], bring: ['brought', 'brought'],
  build: ['built', 'built'], buy: ['bought', 'bought'], catch: ['caught', 'caught'],
  choose: ['chose', 'chosen'], come: ['came', 'come'], cut: ['cut', 'cut'],
  do: ['did', 'done'], draw: ['drew', 'drawn'], drink: ['drank', 'drunk'],
  drive: ['drove', 'driven'], eat: ['ate', 'eaten'], fall: ['fell', 'fallen'],
  feel: ['felt', 'felt'], find: ['found', 'found'], forget: ['forgot', 'forgotten'],
  get: ['got', 'got'], give: ['gave', 'given'], go: ['went', 'gone'],
  grow: ['grew', 'grown'], have: ['had', 'had'], hear: ['heard', 'heard'],
  hold: ['held', 'held'], keep: ['kept', 'kept'], know: ['knew', 'known'],
  lead: ['led', 'led'], leave: ['left', 'left'], lose: ['lost', 'lost'],
  make: ['made', 'made'], mean: ['meant', 'meant'], meet: ['met', 'met'],
  pay: ['paid', 'paid'], put: ['put', 'put'], read: ['read', 'read'],
  ride: ['rode', 'ridden'], run: ['ran', 'run'], say: ['said', 'said'],
  see: ['saw', 'seen'], sell: ['sold', 'sold'], send: ['sent', 'sent'],
  sing: ['sang', 'sung'], sit: ['sat', 'sat'], sleep: ['slept', 'slept'],
  speak: ['spoke', 'spoken'], spend: ['spent', 'spent'], stand: ['stood', 'stood'],
  take: ['took', 'taken'], teach: ['taught', 'taught'], tell: ['told', 'told'],
  think: ['thought', 'thought'], understand: ['understood', 'understood'],
  win: ['won', 'won'], write: ['wrote', 'written'],
};

const NGUYEN_AM = 'aeiou';
const laNguyenAm = (c) => NGUYEN_AM.includes(c);

/** Ngôi thứ ba số ít ở thì hiện tại đơn: he plays, she watches, it flies. */
function ngoiBa(v) {
  if (v === 'be') return 'is';
  if (v === 'have') return 'has';
  if (v === 'do') return 'does';
  if (v === 'go') return 'goes';
  if (/(s|x|z|ch|sh)$/.test(v)) return `${v}es`;
  if (/[^aeiou]y$/.test(v)) return `${v.slice(0, -1)}ies`;
  return `${v}s`;
}

/** Nhân đôi phụ âm cuối khi từ một âm tiết kết thúc bằng phụ âm–nguyên âm–phụ âm. */
function nhanDoi(v) {
  if (v.length < 3) return false;
  const [a, b, c] = [v.at(-3), v.at(-2), v.at(-1)];
  if (laNguyenAm(c) || c === 'w' || c === 'x' || c === 'y') return false;
  if (!laNguyenAm(b)) return false;
  if (laNguyenAm(a)) return false;
  // Chỉ nhân đôi với từ một âm tiết — đếm cụm nguyên âm để ước lượng số âm tiết.
  const cum = v.match(/[aeiou]+/g) || [];
  return cum.length === 1;
}

function quaKhu(v) {
  if (BAT_QUY_TAC[v]) return BAT_QUY_TAC[v][0];
  if (v.endsWith('e')) return `${v}d`;
  if (/[^aeiou]y$/.test(v)) return `${v.slice(0, -1)}ied`;
  if (nhanDoi(v)) return `${v}${v.at(-1)}ed`;
  return `${v}ed`;
}

function phanTu(v) {
  if (BAT_QUY_TAC[v]) return BAT_QUY_TAC[v][1];
  return quaKhu(v);
}

function dangIng(v) {
  if (v.endsWith('ie')) return `${v.slice(0, -2)}ying`;
  if (v.endsWith('e') && v !== 'be' && !v.endsWith('ee')) return `${v.slice(0, -1)}ing`;
  if (nhanDoi(v)) return `${v}${v.at(-1)}ing`;
  return `${v}ing`;
}

// ── CHỦ NGỮ ─────────────────────────────────────────────────────────────────
// so: 'it' = số ít ngôi ba (chia động từ thêm s), 'nhieu' = số nhiều,
//     'toi' = I, 'ban' = you/we/they.
const CHU_NGU = [
  { viet: 'He', so: 'it', be: 'is', beQK: 'was', tanNgu: 'him', soHuu: 'his' },
  { viet: 'She', so: 'it', be: 'is', beQK: 'was', tanNgu: 'her', soHuu: 'her' },
  { viet: 'They', so: 'nhieu', be: 'are', beQK: 'were', tanNgu: 'them', soHuu: 'their' },
  { viet: 'We', so: 'nhieu', be: 'are', beQK: 'were', tanNgu: 'us', soHuu: 'our' },
  { viet: 'I', so: 'toi', be: 'am', beQK: 'was', tanNgu: 'me', soHuu: 'my' },
  { viet: 'You', so: 'nhieu', be: 'are', beQK: 'were', tanNgu: 'you', soHuu: 'your' },
  { viet: 'My brother', so: 'it', be: 'is', beQK: 'was', tanNgu: 'my brother', soHuu: "my brother's" },
  { viet: 'The teacher', so: 'it', be: 'is', beQK: 'was', tanNgu: 'the teacher', soHuu: "the teacher's" },
  { viet: 'The students', so: 'nhieu', be: 'are', beQK: 'were', tanNgu: 'the students', soHuu: "the students'" },
  { viet: 'Our class', so: 'it', be: 'is', beQK: 'was', tanNgu: 'our class', soHuu: "our class's" },
];

const CHU_NGU_THEO_TU = new Map(CHU_NGU.map((c) => [c.viet.toLowerCase(), c]));

/** Chia động từ theo thì và chủ ngữ. */
function chia(v, thi, cn) {
  switch (thi) {
    case 'hien tai don':
      return cn.so === 'it' ? ngoiBa(v) : v;
    case 'qua khu don':
      return v === 'be' ? cn.beQK : quaKhu(v);
    case 'hien tai tiep dien':
      return `${cn.be} ${dangIng(v)}`;
    case 'hien tai hoan thanh':
      return `${cn.so === 'it' ? 'has' : 'have'} ${phanTu(v)}`;
    case 'tuong lai don':
      return `will ${v}`;
    default:
      return v;
  }
}

// ── TÂN NGỮ ─────────────────────────────────────────────────────────────────
// be: dạng động từ "to be" khi cụm này làm chủ ngữ của câu bị động.
const TAN_NGU = [
  { viet: 'the letter', be: 'is', beQK: 'was' },
  { viet: 'the room', be: 'is', beQK: 'was' },
  { viet: 'the homework', be: 'is', beQK: 'was' },
  { viet: 'the windows', be: 'are', beQK: 'were' },
  { viet: 'this book', be: 'is', beQK: 'was' },
  { viet: 'these books', be: 'are', beQK: 'were' },
  { viet: 'the question', be: 'is', beQK: 'was' },
  { viet: 'the machine', be: 'is', beQK: 'was' },
  { viet: 'the report', be: 'is', beQK: 'was' },
  { viet: 'the pictures', be: 'are', beQK: 'were' },
];

const TAN_NGU_THEO_TU = new Map(TAN_NGU.map((t) => [t.viet.toLowerCase(), t]));

// ── CÂU BỊ ĐỘNG ─────────────────────────────────────────────────────────────
/**
 * Chủ động → bị động. Nhận vào các MẢNH (dùng khi sinh đề) hoặc một CÂU
 * (dùng khi kiểm) — hàm phanTichCau ở dưới lo phần tách câu.
 */
function biDong({ cn, v, tn, thi, coBoi = true }) {
  const be = thi === 'qua khu don' ? tn.beQK
    : thi === 'hien tai don' ? tn.be
      : thi === 'hien tai hoan thanh' ? `${tn.be === 'are' ? 'have' : 'has'} been`
        : thi === 'tuong lai don' ? 'will be'
          : `${tn.be} being`;
  const hoa = tn.viet[0].toUpperCase() + tn.viet.slice(1);
  const boi = coBoi ? ` by ${cn.tanNgu}` : '';
  return `${hoa} ${be} ${phanTu(v)}${boi}.`;
}

// ── CÂU ĐIỀU KIỆN ───────────────────────────────────────────────────────────
// loai 1: có thật ở hiện tại/tương lai · loai 2: giả định trái hiện tại
// loai 3: giả định trái quá khứ
function dieuKien({ cnA, vA, tnA, cnB, vB, tnB, loai }) {
  const dk = (() => {
    if (loai === 1) return `${cnA.viet} ${chia(vA, 'hien tai don', cnA)} ${tnA.viet}`;
    if (loai === 2) return `${cnA.viet} ${vA === 'be' ? 'were' : quaKhu(vA)} ${tnA.viet}`;
    return `${cnA.viet} had ${phanTu(vA)} ${tnA.viet}`;
  })();
  const kq = (() => {
    if (loai === 1) return `${cnB.viet.toLowerCase()} will ${vB} ${tnB.viet}`;
    if (loai === 2) return `${cnB.viet.toLowerCase()} would ${vB} ${tnB.viet}`;
    return `${cnB.viet.toLowerCase()} would have ${phanTu(vB)} ${tnB.viet}`;
  })();
  return `If ${dk.charAt(0).toLowerCase()}${dk.slice(1)}, ${kq}.`;
}

// ── MỆNH ĐỀ QUAN HỆ ─────────────────────────────────────────────────────────
// xacDinh = true  → mệnh đề XÁC ĐỊNH, không có dấu phẩy, dùng được "that"
// xacDinh = false → mệnh đề KHÔNG xác định, BẮT BUỘC có hai dấu phẩy
function quanHe({ danhTu, nguoi, menhDe, cauChinh, xacDinh }) {
  const dai = nguoi ? 'who' : 'which';
  if (xacDinh) return cauChinh.replace('§', `${danhTu} ${dai} ${menhDe}`);
  return cauChinh.replace('§', `${danhTu}, ${dai} ${menhDe},`);
}

// ── CÂU TƯỜNG THUẬT ─────────────────────────────────────────────────────────
// Lùi thì: hiện tại đơn → quá khứ đơn; quá khứ đơn → quá khứ hoàn thành;
// will → would. Trạng ngữ chỉ thời gian và đại từ cũng phải đổi theo.
const LUI_THI = {
  'hien tai don': 'qua khu don',
  'hien tai tiep dien': 'qua khu tiep dien',
  'qua khu don': 'qua khu hoan thanh',
  'hien tai hoan thanh': 'qua khu hoan thanh',
  'tuong lai don': 'tuong lai trong qua khu',
};
const DOI_TRANG_NGU = {
  today: 'that day', tonight: 'that night', now: 'then',
  yesterday: 'the day before', tomorrow: 'the next day',
  'this week': 'that week', 'last week': 'the week before', 'next week': 'the following week',
  here: 'there', ago: 'before',
};

function chiaLui(v, thiMoi, cn) {
  switch (thiMoi) {
    case 'qua khu don': return v === 'be' ? cn.beQK : quaKhu(v);
    case 'qua khu hoan thanh': return `had ${phanTu(v)}`;
    case 'qua khu tiep dien': return `${cn.beQK} ${dangIng(v)}`;
    case 'tuong lai trong qua khu': return `would ${v}`;
    default: return v;
  }
}

function tuongThuat({ nguoiNoi, cn, v, tn, thi, trangNgu = null }) {
  const thiMoi = LUI_THI[thi] || thi;
  const cnMoi = cn.viet === 'I' ? { ...cn, viet: 'he', beQK: 'was', so: 'it' }
    : cn.viet === 'We' ? { ...cn, viet: 'they', beQK: 'were', so: 'nhieu' }
      : { ...cn, viet: cn.viet.toLowerCase() };
  const tn2 = trangNgu ? ` ${DOI_TRANG_NGU[trangNgu] || trangNgu}` : '';
  return `${nguoiNoi} said that ${cnMoi.viet} ${chiaLui(v, thiMoi, cnMoi)} ${tn.viet}${tn2}.`;
}

// ── ĐỌC LẠI MỘT CÂU (đường độc lập dùng cho khâu kiểm) ──────────────────────
/**
 * Tách một câu chủ động đơn giản thành chủ ngữ · động từ đã chia · tân ngữ,
 * rồi TRA NGƯỢC về động từ gốc và thì. Hàm này KHÔNG nhận tham số nào của bộ
 * sinh — nó chỉ nhìn vào chuỗi câu, đúng như người học nhìn vào đề.
 * @returns {{ok, cn, v, thi, tn}|{ok:false,error}}
 */
function phanTichCau(cau) {
  const s = String(cau || '').trim().replace(/\.$/, '');
  const thap = s.toLowerCase();

  // Chủ ngữ: khớp cụm dài nhất trong danh sách chủ ngữ đã biết.
  let cn = null; let sau = null;
  for (const c of [...CHU_NGU].sort((a, b) => b.viet.length - a.viet.length)) {
    const k = c.viet.toLowerCase();
    if (thap === k || thap.startsWith(`${k} `)) { cn = c; sau = s.slice(c.viet.length).trim(); break; }
  }
  if (!cn) return { ok: false, error: 'KHÔNG_NHẬN_RA_CHỦ_NGỮ', cau: s };

  // Tân ngữ: khớp cụm dài nhất ở CUỐI câu.
  let tn = null; let giua = null;
  for (const t of [...TAN_NGU].sort((a, b) => b.viet.length - a.viet.length)) {
    const k = t.viet.toLowerCase();
    if (sau.toLowerCase().endsWith(k)) { tn = t; giua = sau.slice(0, sau.length - t.viet.length).trim(); break; }
  }
  if (!tn) return { ok: false, error: 'KHÔNG_NHẬN_RA_TÂN_NGỮ', cau: s };
  if (!giua) return { ok: false, error: 'KHÔNG_CÓ_ĐỘNG_TỪ', cau: s };

  // Động từ: dò ngược từ hình thái về động từ gốc và thì.
  const tu = giua.split(/\s+/);
  const doDang = (dang) => {
    for (const goc of DONG_TU_DUNG_DUOC) {
      if (chia(goc, dang, cn) === giua) return goc;
    }
    return null;
  };
  for (const dang of ['hien tai don', 'qua khu don', 'hien tai hoan thanh', 'hien tai tiep dien', 'tuong lai don']) {
    const g = doDang(dang);
    if (g) return { ok: true, cn, v: g, thi: dang, tn, tho: tu };
  }
  return { ok: false, error: 'KHÔNG_NHẬN_RA_ĐỘNG_TỪ', cau: s, giua };
}

// Động từ dùng được trong bài: đều là ngoại động từ, đi với tân ngữ được.
const DONG_TU_DUNG_DUOC = [
  'write', 'read', 'clean', 'finish', 'answer', 'repair', 'send', 'check',
  'open', 'close', 'paint', 'take', 'make', 'build', 'bring', 'find',
  'keep', 'lose', 'teach', 'give', 'show', 'watch', 'carry', 'study',
];

module.exports = {
  BAT_QUY_TAC, CHU_NGU, TAN_NGU, DONG_TU_DUNG_DUOC, LUI_THI, DOI_TRANG_NGU,
  CHU_NGU_THEO_TU, TAN_NGU_THEO_TU,
  ngoiBa, quaKhu, phanTu, dangIng, chia, chiaLui,
  biDong, dieuKien, quanHe, tuongThuat, phanTichCau,
};
