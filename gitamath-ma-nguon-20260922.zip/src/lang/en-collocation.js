'use strict';
/**
 * KẾT HỢP TỪ TIẾNG ANH (collocation) — bảng tra chép tay.
 *
 * Người Việt học tiếng Anh sai kết hợp từ vì DỊCH TỪNG TỪ: "làm bài tập" ra
 * "make homework", "làm ảnh" ra "make a photo". Không có luật nào suy ra được
 * kết hợp đúng — đây là chỗ bắt buộc phải có DỮ LIỆU, và dữ liệu phải do
 * người biên soạn, không phải do máy đoán.
 *
 * Bảng dưới liệt kê các kết hợp ĐÚNG. Một cụm danh từ có thể đi với nhiều
 * động từ (break a promise / keep a promise / make a promise đều đúng) — bảng
 * ghi đủ, và bộ kiểm dùng chính điều đó để chặn những bài ra đề mập mờ.
 */
const KET_HOP = {
  do: ['homework', 'housework', 'the washing-up', 'exercise', 'research', 'business', 'a favour', 'your best', 'the shopping'],
  make: ['a mistake', 'a decision', 'progress', 'an effort', 'noise', 'friends', 'a phone call', 'money', 'a mess', 'a promise', 'a cake'],
  take: ['a photo', 'a break', 'a shower', 'a seat', 'notes', 'part', 'care', 'medicine', 'an exam', 'a risk', 'a bus'],
  have: ['breakfast', 'a good time', 'a look', 'a rest', 'a party', 'a problem', 'an idea', 'a shower', 'a break'],
  give: ['a speech', 'advice', 'a hand', 'an example', 'permission', 'a lift'],
  pay: ['attention', 'a visit', 'a compliment', 'the bill'],
  catch: ['a cold', 'a bus', 'fire', 'a train'],
  keep: ['a promise', 'a secret', 'calm', 'in touch', 'a diary'],
  break: ['a promise', 'the law', 'a record', 'the news', 'a habit'],
  save: ['time', 'money', 'energy', 'a seat'],
};

/** Mọi động từ đi được với cụm này. Trả mảng rỗng nghĩa là cụm chưa có trong bảng. */
function dongTuCho(cum) {
  const c = String(cum || '').trim().toLowerCase();
  return Object.entries(KET_HOP).filter(([, ds]) => ds.includes(c)).map(([v]) => v);
}

/** Các cụm CHỈ đi với đúng một động từ — chỉ những cụm này mới ra đề được. */
function cumDuyNhat() {
  const dem = new Map();
  for (const [v, ds] of Object.entries(KET_HOP)) {
    for (const c of ds) {
      if (!dem.has(c)) dem.set(c, []);
      dem.get(c).push(v);
    }
  }
  return [...dem.entries()].filter(([, vs]) => vs.length === 1).map(([cum, vs]) => ({ cum, dung: vs[0] }));
}

module.exports = { KET_HOP, dongTuCho, cumDuyNhat };
