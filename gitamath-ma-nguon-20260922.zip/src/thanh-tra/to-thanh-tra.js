'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TỔ THANH TRA — 10 trợ lý AI, 10 lượt mỗi ngày
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Mục đích: bắt lỗi TRƯỚC khi nó thành sự cố. Nên mười lượt rải đều trong
 *  ngày chứ không dồn một lúc: một lỗi sinh ra lúc 9 giờ sáng mà tới nửa đêm
 *  mới có người soi thì nó đã kịp làm hỏng cả ngày dữ liệu.
 *
 *  BA NGUYÊN TẮC, viết ra vì chúng quyết định tổ này có giá trị hay chỉ là
 *  một cái đồng hồ kêu:
 *
 *  1. MỖI THANH TRA VIÊN CÓ MỘT VIỆC RIÊNG, KHÔNG CHỒNG NHAU. Mười người
 *     cùng chạy `npm test` thì chỉ tốn mười lần điện. Mười mặt khác nhau của
 *     hệ thống mới là mười lượt soi.
 *
 *  2. KHÔNG TỰ SỬA. Thanh tra ghi biên bản và báo động; sửa là việc của người
 *     có thẩm quyền. Một tổ vừa soi vừa tự vá là một tổ có thể lặng lẽ giấu
 *     đi thứ nó vừa làm hỏng.
 *
 *  3. IM LẶNG KHÔNG PHẢI LÀ ĐẠT. Lượt nào chạy hỏng, hết giờ, hoặc không
 *     soi được thì tính là KHÔNG ĐẠT kèm lý do — chứ không bỏ qua. Một lượt
 *     không chạy trông giống hệt một lượt sạch nếu không ai phân biệt.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');

/**
 * Mười thanh tra viên, mười mặt khác nhau.
 *   ma        mã bất biến
 *   khoi      khối trong 500 trợ lý AI mà người này thuộc về
 *   soi       thứ người này soi
 *   hong      hỏng ở đây thì hệ thống mất gì
 *   mucNang   'chan' = phát hiện là phải dừng việc; 'bao' = ghi và báo
 */
const THANH_TRA_VIEN = [
  {
    ma: 'TT01', ten: 'Soi độ bền dữ liệu', khoi: 'CODE', mucNang: 'chan',
    soi: 'Ảnh chụp và nhật ký của mọi bộ sưu tập có khớp nhau không, có bản ghi mồ côi không.',
    hong: 'Mất dữ liệu khách hàng, không dựng lại được.',
  },
  {
    ma: 'TT02', ten: 'Soi cổng quyền', khoi: 'CODE', mucNang: 'chan',
    soi: 'Có cổng API nào tụt xuống công khai ngoài danh sách đã khai không.',
    hong: 'Dữ liệu khách hàng và khu điều hành mở cho người lạ.',
  },
  {
    ma: 'TT03', ten: 'Soi bức tường Cây Tiền', khoi: 'BUSINESS', mucNang: 'chan',
    soi: 'Trang công khai và khu riêng có lộ chữ nào của bảng phân loại gia đình không.',
    hong: 'Gia đình đọc thấy mình bị xếp hạng — hỏng thứ hệ thống tồn tại để tạo ra.',
  },
  {
    ma: 'TT04', ten: 'Soi dòng tiền', khoi: 'BUSINESS', mucNang: 'chan',
    soi: 'Chi phí hôm nay và tháng này so với trần ngân sách; bảng giá có quá hạn cập nhật không.',
    hong: 'Đốt sạch ngân sách trong một đêm mà không ai biết.',
  },
  {
    ma: 'TT05', ten: 'Soi luật đo của bộ khảo sát', khoi: 'RESEARCH', mucNang: 'chan',
    soi: 'Có công cụ tự khai nào lọt vào miền quyết định nội dung học không.',
    hong: 'Tính cách bắt đầu quyết định đứa trẻ được học gì.',
  },
  {
    ma: 'TT06', ten: 'Soi kho học liệu', khoi: 'MATH', mucNang: 'bao',
    soi: 'Bài đã phát hành có còn chứng cứ máy tự giải lại không; ô nào mỏng dưới ngưỡng.',
    hong: 'Học viên nhận bài sai đáp số, hoặc gặp lại đúng một bài suốt cả tuần.',
  },
  {
    ma: 'TT07', ten: 'Soi ngôn ngữ học liệu', khoi: 'VIETNAMESE', mucNang: 'bao',
    soi: 'Chữ trong kho và trên trang có đạt chuẩn tiếng Việt theo đúng lớp không.',
    hong: 'Trẻ đọc câu sai chính tả và học theo.',
  },
  {
    ma: 'TT08', ten: 'Soi sức khoẻ đội hình', khoi: 'CODE', mucNang: 'bao',
    soi: 'Trợ lý nào đang bị cách ly, hàng đợi sâu bao nhiêu, có ai treo quá 120 giây không.',
    hong: 'Việc dồn ứ, nhiệm vụ rơi im lặng.',
  },
  {
    ma: 'TT09', ten: 'Soi riêng tư dữ liệu trẻ', khoi: 'RESEARCH', mucNang: 'chan',
    soi: 'Kết quả sàng lọc tâm lý có lưu câu thô không, có vai nào đọc vượt quyền không.',
    hong: 'Lộ dữ liệu nhạy cảm của trẻ — thứ không thu hồi lại được.',
  },
  {
    ma: 'TT10', ten: 'Soi chuỗi giá trị', khoi: 'BUSINESS', mucNang: 'bao',
    soi: 'Các tầng của cây giá trị có còn nối liền nhau không, chặng nào đứt mạch.',
    hong: 'Học viên đi tới giữa lộ trình rồi không còn đường đi tiếp.',
  },
];

const VIEN_INDEX = new Map(THANH_TRA_VIEN.map((v) => [v.ma, v]));

/**
 * Mười lượt trong ngày, rải đều từ 6 giờ tới 23 giờ.
 *
 * Giờ chọn có chủ ý: lượt đầu trước giờ học buổi sáng (bắt lỗi qua đêm), lượt
 * cuối sau khi học viên đã nghỉ (soi trọn một ngày dữ liệu). Khoảng giữa dày
 * hơn vào giờ cao điểm 19–21 giờ.
 */
const LICH = [
  { luot: 1, gio: 6, phut: 0, vi: 'Trước giờ học sáng — bắt lỗi phát sinh qua đêm' },
  { luot: 2, gio: 8, phut: 0, vi: 'Đầu buổi sáng' },
  { luot: 3, gio: 10, phut: 0, vi: 'Giữa buổi sáng' },
  { luot: 4, gio: 12, phut: 0, vi: 'Giữa trưa — trước khi tải chiều lên' },
  { luot: 5, gio: 14, phut: 0, vi: 'Đầu buổi chiều' },
  { luot: 6, gio: 16, phut: 0, vi: 'Cuối buổi chiều' },
  { luot: 7, gio: 18, phut: 0, vi: 'Trước giờ cao điểm tối' },
  { luot: 8, gio: 20, phut: 0, vi: 'Giữa giờ cao điểm — dày hơn vì tải cao nhất' },
  { luot: 9, gio: 21, phut: 30, vi: 'Cuối giờ cao điểm' },
  { luot: 10, gio: 23, phut: 0, vi: 'Chốt ngày — soi trọn một ngày dữ liệu' },
];

/**
 * Lượt nào giao cho ai.
 *
 * Năm việc mức 'chan' được soi ở MỌI lượt, vì hỏng ở đó là hỏng ngay. Năm việc
 * mức 'bao' xoay vòng, mỗi lượt hai người — mười lượt thì mỗi người được soi
 * bốn lần một ngày, đủ dày mà không tốn vô ích.
 */
function phanCong(luot) {
  const chan = THANH_TRA_VIEN.filter((v) => v.mucNang === 'chan').map((v) => v.ma);
  const bao = THANH_TRA_VIEN.filter((v) => v.mucNang === 'bao').map((v) => v.ma);
  const i = (Number(luot) - 1 + bao.length) % bao.length;
  const xoay = [bao[i], bao[(i + 1) % bao.length]];
  return { moiLuot: chan, xoayVong: xoay, tatCa: [...chan, ...xoay] };
}

/** Lịch đầy đủ của một ngày: mười lượt, ai soi gì. */
function lichNgay() {
  return LICH.map((l) => {
    const pc = phanCong(l.luot);
    return {
      ...l,
      gioChu: `${String(l.gio).padStart(2, '0')}:${String(l.phut).padStart(2, '0')}`,
      vien: pc.tatCa.map((ma) => {
        const v = VIEN_INDEX.get(ma);
        return { ma, ten: v.ten, mucNang: v.mucNang, soi: v.soi };
      }),
      soVien: pc.tatCa.length,
    };
  });
}

/** Biểu thức cron cho từng lượt, dùng khi cắm vào bộ lập lịch thật. */
function cron() {
  return LICH.map((l) => ({ luot: l.luot, cron: `${l.phut} ${l.gio} * * *`, vi: l.vi }));
}

/**
 * Chạy một lượt thanh tra.
 *
 * @param {object} o.viec   bảng hàm soi: { TT01: () => ({dat, chiTiet}), ... }
 * @param {number} o.luot
 *
 * Hàm nào thiếu, ném lỗi, hay trả về thứ không đọc được đều tính KHÔNG ĐẠT —
 * xem nguyên tắc 3 ở đầu tệp.
 */
async function chayLuot({ viec = {}, luot = 1, bayGio = Date.now() } = {}) {
  const pc = phanCong(luot);
  const ket = [];
  for (const ma of pc.tatCa) {
    const v = VIEN_INDEX.get(ma);
    const t0 = Date.now();
    if (typeof viec[ma] !== 'function') {
      ket.push({ ma, ten: v.ten, mucNang: v.mucNang, dat: false, chiTiet: 'CHƯA CÓ phép soi cho mục này', ms: 0 });
      continue;
    }
    try {
      const r = await viec[ma]();
      const dat = !!(r && r.dat);
      ket.push({
        ma, ten: v.ten, mucNang: v.mucNang, dat,
        chiTiet: (r && r.chiTiet) || (dat ? 'đạt' : 'không đạt, không nói lý do'),
        ms: Date.now() - t0,
      });
    } catch (e) {
      ket.push({ ma, ten: v.ten, mucNang: v.mucNang, dat: false, chiTiet: `phép soi ném lỗi: ${e.message}`, ms: Date.now() - t0 });
    }
  }

  const hong = ket.filter((x) => !x.dat);
  const chanHong = hong.filter((x) => x.mucNang === 'chan');
  return {
    luot, luc: bayGio,
    gio: (() => {
      const l = LICH.find((x) => x.luot === luot);
      return l ? `${String(l.gio).padStart(2, '0')}:${String(l.phut).padStart(2, '0')}` : null;
    })(),
    soVien: ket.length,
    ket,
    soDat: ket.length - hong.length,
    soKhongDat: hong.length,
    // Phát hiện mức 'chan' là phải dừng việc, không phải ghi rồi đi tiếp.
    phaiDungViec: chanHong.length > 0,
    ketLuan: chanHong.length
      ? `DỪNG VIỆC: ${chanHong.length} phát hiện mức chặn — ${chanHong.map((x) => x.ten).join(', ')}.`
      : hong.length
        ? `${hong.length} mục cần xem lại: ${hong.map((x) => x.ten).join(', ')}.`
        : `Cả ${ket.length} mục đều đạt.`,
    // Thanh tra KHÔNG tự sửa. Nói rõ trong chính biên bản.
    khongTuSua: 'Tổ thanh tra ghi biên bản và báo động, không tự vá. Sửa là việc của người có thẩm quyền.',
  };
}

/** Gộp nhiều lượt trong ngày thành một biên bản ngày. */
function bienBanNgay(cacLuot = []) {
  const tong = cacLuot.reduce((s, l) => s + l.soVien, 0);
  const hong = cacLuot.reduce((s, l) => s + l.soKhongDat, 0);
  const dung = cacLuot.filter((l) => l.phaiDungViec);
  const thieuLuot = LICH.length - cacLuot.length;
  return {
    soLuotDaChay: cacLuot.length,
    soLuotTheoLich: LICH.length,
    soLuotChuaChay: thieuLuot,
    tongMucSoi: tong,
    soKhongDat: hong,
    tiLeDat: tong ? round((tong - hong) / tong, 3) : 0,
    soLuotPhaiDungViec: dung.length,
    ketLuan: thieuLuot > 0
      ? `CHƯA ĐỦ LƯỢT: mới chạy ${cacLuot.length}/${LICH.length} lượt. `
        + 'Lượt không chạy trông giống hệt lượt sạch, nên đây tính là thiếu chứ không tính là đạt.'
      : dung.length
        ? `${dung.length}/${LICH.length} lượt có phát hiện mức chặn.`
        : `Đủ ${LICH.length} lượt, không lượt nào phải dừng việc.`,
  };
}

module.exports = { THANH_TRA_VIEN, VIEN_INDEX, LICH, phanCong, lichNgay, cron, chayLuot, bienBanNgay };
