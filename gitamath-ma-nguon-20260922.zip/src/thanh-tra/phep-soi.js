'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MƯỜI PHÉP SOI THẬT của tổ thanh tra
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mỗi phép soi đọc trạng thái THẬT của hệ thống đang chạy và trả
 *  {dat, chiTiet}. Không phép nào được tự sửa gì — xem nguyên tắc 2 ở
 *  src/thanh-tra/to-thanh-tra.js.
 *
 *  Phép nào chưa đo được thì trả dat:false kèm lý do, KHÔNG trả dat:true cho
 *  đẹp bảng. Một bảng mười ô xanh mà ba ô trong đó chưa từng soi gì là thứ
 *  nguy hiểm hơn một bảng có ba ô đỏ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');

/**
 * @param {object} N hệ thống đang chạy
 * @returns {object} bảng mã thanh tra viên → hàm soi
 */
function phepSoi(N) {
  return {
    // ── TT01: độ bền dữ liệu ────────────────────────────────────────────
    TT01: () => {
      const dir = N.cfg && N.cfg.DB && N.cfg.DB.dir ? N.cfg.DB.dir : path.join(__dirname, '..', '..', 'data', 'db');
      if (!fs.existsSync(dir)) return { dat: false, chiTiet: `không thấy thư mục dữ liệu ${dir}` };
      const hong = [];
      let soBang = 0;
      for (const f of fs.readdirSync(dir)) {
        if (!f.endsWith('.snap.json')) continue;
        soBang++;
        const ten = f.replace('.snap.json', '');
        try {
          const snap = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
          if (typeof snap.count !== 'number' || !Array.isArray(snap.docs)) { hong.push(`${ten}: ảnh chụp sai hình dạng`); continue; }
          if (snap.count !== snap.docs.length) hong.push(`${ten}: count ${snap.count} ≠ ${snap.docs.length} bản ghi`);
        } catch (e) { hong.push(`${ten}: ảnh chụp ĐỌC KHÔNG ĐƯỢC (${e.message})`); }
        // Tệp tạm còn sót nghĩa là một lần gộp đã đứt giữa chừng.
        if (fs.existsSync(path.join(dir, `${ten}.snap.json.tmp`))) hong.push(`${ten}: còn tệp tạm — lần gộp trước đứt giữa chừng`);
      }

      // Ảnh chụp hệ thống là đường lui DUY NHẤT khi tệp dữ liệu hỏng. Lượt
      // thanh tra này từng bỏ sót đúng chỗ ấy: bộ đếm giờ tự chụp không chạy,
      // nên số ảnh là 0 trong khi chính sách giữ ảnh vẫn nằm đủ trong sổ tay.
      // Một đường lui có trong tài liệu mà không có trên đĩa là không có.
      if (N.snapshots) {
        const tuDong = !!N.snapshots._timer;
        if (!tuDong) hong.push('KHÔNG tự chụp ảnh định kỳ — chỉ có ảnh bấm tay');
        const ds = N.snapshots.snapshots || [];
        if (!ds.length) hong.push('chưa có ảnh chụp nào để lui về');
        else {
          const moiNhat = Math.max(...ds.map((x) => x.at || 0));
          const gio = (Date.now() - moiNhat) / 3_600_000;
          if (gio > 24) hong.push(`ảnh chụp gần nhất đã ${Math.round(gio)} giờ trước`);
        }
      }
      const soAnh = N.snapshots ? (N.snapshots.snapshots || []).length : 0;
      return {
        dat: hong.length === 0,
        chiTiet: hong.length ? hong.slice(0, 3).join(' · ')
          : `${soBang} bảng · ảnh chụp khớp số bản ghi · không có tệp tạm sót · ${soAnh} ảnh lui về được`,
      };
    },

    // ── TT02: cổng quyền ────────────────────────────────────────────────
    TT02: () => {
      const cq = require('../api/cong-quyen');
      const createRouter = require('../api/router');
      const { routes } = createRouter(N);
      const mo = routes.filter((r) => cq.mucCua(r) === 'cong-khai');
      const ngoaiDanhSach = mo.filter((r) => !cq.CONG_KHAI.has(`${r.method} ${r.pattern}`));
      // Cổng để VÀO được phép mở; cổng đổi dữ liệu nghiệp vụ thì không.
      // Hai cổng khuôn mặt: một cái phát thách thức trong bộ nhớ, một cái mở
      // phiên — đúng việc /accounts/login vẫn làm. Gắn và gỡ khuôn mặt vẫn
      // đòi phiên đang đăng nhập.
      const ghi = mo.filter((r) => r.method !== 'GET'
        && !/login|logout|initialize|khuon-mat\/(xin-)?dang-nhap/.test(r.pattern));
      return {
        dat: ngoaiDanhSach.length === 0 && ghi.length === 0,
        chiTiet: ngoaiDanhSach.length ? `${ngoaiDanhSach.length} cổng công khai ngoài danh sách đã khai`
          : ghi.length ? `${ghi.length} cổng GHI đang mở: ${ghi.map((r) => r.pattern).join(', ')}`
            : `${routes.length} cổng · ${mo.length} công khai, đều nằm trong danh sách đã khai`,
      };
    },

    // ── TT03: bức tường Cây Tiền ────────────────────────────────────────
    TT03: () => {
      const tuong = require('../cay-tien/buc-tuong');
      const site = require('../web/site');
      const hong = [];
      let soTrang = 0;
      for (const d of site.moiDuongDan()) {
        soTrang++;
        try {
          const kq = site.dinhTuyen(N, d, {}, 'soi');
          const r = tuong.soiRoRi(kq && kq.html ? kq.html : '');
          if (!r.sach) hong.push(`${d} lộ "${r.roRi[0].cum}"`);
        } catch (e) { hong.push(`${d}: ${e.message}`); }
        if (hong.length >= 3) break;
      }
      // Và bức tường phải CÓ RĂNG, không chỉ im lặng.
      const canRang = !tuong.soiRoRi('nhóm Cây tiền').sach && tuong.soiRoRi('Cây giá trị').sach;
      return {
        dat: hong.length === 0 && canRang,
        chiTiet: hong.length ? hong.join(' · ')
          : !canRang ? 'bức tường MẤT RĂNG: không bắt được chuỗi rò rỉ thử'
            : `${soTrang} trang công khai sạch · phép soi vẫn bắt được chuỗi rò rỉ thử`,
      };
    },

    // ── TT04: dòng tiền ─────────────────────────────────────────────────
    TT04: () => {
      if (!N.soCai) return { dat: false, chiTiet: 'CHƯA gắn sổ cái dòng tiền vào hệ thống' };
      const bb = N.soCai.bienBan();
      const { BANG_GIA } = require('../dong-tien/so-cai');
      const tuoiNgay = Math.floor((Date.now() - Date.parse(BANG_GIA.capNhat)) / 86400000);
      const vuot = bb.tong.thang > bb.nganSach.thang || bb.tong.ngay > bb.nganSach.ngay;
      const giaCu = tuoiNgay > 120;
      return {
        dat: !vuot && !giaCu,
        chiTiet: vuot ? `VƯỢT TRẦN: ngày ${bb.tong.ngay}/${bb.nganSach.ngay} · tháng ${bb.tong.thang}/${bb.nganSach.thang} USD`
          : giaCu ? `bảng giá mô hình đã ${tuoiNgay} ngày chưa cập nhật — con số ngân sách không còn tin được`
            : `ngày ${bb.tong.ngay}/${bb.nganSach.ngay} · tháng ${bb.tong.thang}/${bb.nganSach.thang} USD · `
              + `${bb.chuaCoNguon.length} khoản chưa nối nguồn (đã nêu rõ)`,
      };
    },

    // ── TT05: luật đo của bộ khảo sát ───────────────────────────────────
    TT05: () => {
      const luat = require('../khao-sat/hien-phap-do');
      const lot = ['DISC', 'MBTI', 'THAN_SO'].filter((m) => luat.duocAnhHuong(m, 'noi-dung').ok);
      const thanSoLot = luat.MIEN.filter((m) => luat.duocAnhHuong('THAN_SO', m).ok);
      return {
        dat: lot.length === 0 && thanSoLot.length === 0,
        chiTiet: lot.length ? `LỌT: ${lot.join(', ')} đang quyết định được nội dung học`
          : thanSoLot.length ? `thần số học lọt vào miền: ${thanSoLot.join(', ')}`
            : 'ba công cụ tự khai về tính cách đều bị chặn khỏi miền nội dung',
      };
    },

    // ── TT06: kho học liệu ──────────────────────────────────────────────
    TT06: () => {
      if (!N.bank) return { dat: false, chiTiet: 'chưa gắn kho học liệu' };
      const pub = N.bank.query({ limit: 5000 }).filter((x) => x.status === 'PUBLISHED');
      // Trường đúng là verification.match (bộ kiểm giải lại cho cùng kết quả),
      // không phải .verified. Bản đầu của phép soi này đọc sai tên trường và
      // báo động giả 546/546 bài — một phép soi báo động giả cũng là lỗi, vì
      // nó dạy người đọc bỏ qua biên bản.
      const khongChung = pub.filter((x) => !x.verification || x.verification.machine !== true || x.verification.match !== true);
      const c = N.seeder ? N.seeder.coverage() : null;
      const mong = c ? (c.empty || []).length : 0;
      return {
        dat: khongChung.length === 0 && mong === 0,
        chiTiet: khongChung.length ? `${khongChung.length} bài đã phát hành mà THIẾU chứng cứ máy tự giải lại`
          : mong ? `${mong} ô (dạng × tầng) còn trống`
            : `${pub.length} bài phát hành, bài nào cũng có chứng cứ · không ô nào trống`,
      };
    },

    // ── TT07: ngôn ngữ học liệu ─────────────────────────────────────────
    TT07: () => {
      if (!N.linguist) return { dat: false, chiTiet: 'chưa gắn nhà khoa học ngôn ngữ' };
      const r = N.linguist.auditKho({ limitMoiDang: 12 });
      return {
        dat: r.ok === true && r.khongDat === 0,
        chiTiet: r.ok === false ? `soi hỏng: ${r.error}`
          : r.khongDat ? `${r.khongDat}/${r.soBai} bài có lỗi chặn`
            : `${r.soBai} bài · 0 lỗi chặn`,
      };
    },

    // ── TT08: sức khoẻ đội hình ─────────────────────────────────────────
    TT08: () => {
      if (!N.shield) return { dat: false, chiTiet: 'chưa gắn lá chắn chống nhiễu' };
      const f = N.shield.fleetReadiness();
      const treo = N.agents ? N.agents.filter((a) => a.state === 'SUSPENDED').length : 0;
      return {
        dat: f.readiness >= 0.95 && treo === 0,
        chiTiet: treo ? `${treo} trợ lý đang bị treo`
          : f.readiness < 0.95 ? `sẵn sàng đội hình chỉ ${Math.round(f.readiness * 100)}%`
            : `sẵn sàng ${Math.round(f.readiness * 100)}% · 0 trợ lý bị treo`,
      };
    },

    // ── TT09: riêng tư dữ liệu trẻ ──────────────────────────────────────
    TT09: () => {
      const { RIENG_TU } = require('../khao-sat/kho');
      const tl = RIENG_TU.TAM_LY_HOC_DUONG;
      const hong = [];
      if (tl.luuCauTho) hong.push('sàng lọc tâm lý đang lưu câu thô');
      if (tl.aiDoc.includes('giao-vien')) hong.push('giáo viên đọc được dữ liệu tâm lý');
      // Và kiểm trên dữ liệu THẬT đang nằm trong kho.
      if (N.khaoSat) {
        const banGhi = N.khaoSat.repo ? N.khaoSat.repo.filter((x) => x.congCu === 'TAM_LY_HOC_DUONG') : [];
        const coCauTho = banGhi.filter((x) => x.cauTraLoi);
        if (coCauTho.length) hong.push(`${coCauTho.length} bản ghi tâm lý ĐANG CHỨA câu trả lời thô`);
      }
      return {
        dat: hong.length === 0,
        chiTiet: hong.length ? hong.join(' · ')
          : 'luật riêng tư đúng · không bản ghi tâm lý nào chứa câu thô · giáo viên bị chặn',
      };
    },

    // ── TT10: chuỗi giá trị ─────────────────────────────────────────────
    TT10: () => {
      const cgt = require('../nha/cay-gia-tri');
      const c = cgt.cayGiaTri();
      const hong = [];
      c.tang.forEach((t, i) => {
        if (t.thu !== i + 1) hong.push(`tầng đứt mạch ở vị trí ${i + 1}`);
        if (!t.veTinh || !t.veTinh.length) hong.push(`tầng ${t.thu} không gắn năng lực nào`);
      });
      const { MOC } = require('../khao-sat/nam-hoc');
      let truoc = -1;
      for (const m of MOC) {
        if (m.phuPhamVi < truoc) hong.push(`mốc ${m.ma} phủ hẹp hơn mốc trước`);
        truoc = m.phuPhamVi;
      }
      return {
        dat: hong.length === 0,
        chiTiet: hong.length ? hong.slice(0, 3).join(' · ')
          : `${c.soTang} tầng cây giá trị liền mạch · ${MOC.length} mốc năm học phủ tăng dần tới 100%`,
      };
    },
  };
}

module.exports = { phepSoi };
