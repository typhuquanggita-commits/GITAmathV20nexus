'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  THẦN SỐ HỌC — phép tính trên ngày sinh và tên
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  NÓI THẲNG NGAY DÒNG ĐẦU, vì đây là điều quan trọng nhất của tệp này:
 *
 *      Thần số học KHÔNG đo gì cả. Không có bằng chứng khoa học nào cho thấy
 *      nó dự đoán được tính cách, năng lực hay kết quả học tập. Con số dưới
 *      đây được tính đúng theo quy ước của thần số học, và chỉ có thế.
 *
 *  Vậy vì sao tệp này vẫn tồn tại? Vì gia đình hỏi, và một hệ thống im lặng
 *  trước câu hỏi của gia đình thì gia đình sẽ đi tra ở chỗ khác — nơi không ai
 *  nói kèm câu cảnh báo nào. Nên hệ thống tính, in kèm cảnh báo, và KHÓA CỨNG
 *  con số ấy khỏi mọi quyết định về việc học: trong src/khao-sat/hien-phap-do.js,
 *  THAN_SO có danh sách miền ảnh hưởng RỖNG — rỗng hoàn toàn, kể cả miền
 *  'cach-noi'. Cho nó ảnh hưởng tới cách nói cũng là để nó ảnh hưởng tới cách
 *  người lớn nhìn một đứa trẻ, và đó chính là tác hại cần chặn.
 *
 *  Phần mô tả từng con số dưới đây viết ở thì "người ta thường nói", không
 *  viết ở thì khẳng định — vì đó đúng là trạng thái của tri thức này.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { deaccent } = require('../utils');

/** Số bậc thầy giữ nguyên, không rút tiếp — theo đúng quy ước thần số học. */
const SO_BAC_THAY = [11, 22, 33];

/** Rút một số về một chữ số, giữ lại 11 / 22 / 33. */
function rutSo(n) {
  let x = Math.abs(Math.trunc(Number(n) || 0));
  const buoc = [x];
  while (x > 9 && !SO_BAC_THAY.includes(x)) {
    x = String(x).split('').reduce((s, c) => s + Number(c), 0);
    buoc.push(x);
  }
  return { so: x, buoc };
}

/** Bảng chữ cái Pythagore: A=1 … I=9, J=1 … R=9, S=1 … Z=8. */
function giaTriChu(ch) {
  const c = ch.toUpperCase();
  if (c < 'A' || c > 'Z') return 0;
  return ((c.charCodeAt(0) - 65) % 9) + 1;
}

const NGUYEN_AM = new Set(['A', 'E', 'I', 'O', 'U', 'Y']);

/**
 * Bỏ dấu tiếng Việt trước khi tính.
 *
 * Thần số học ra đời với bảng chữ cái Latin không dấu, nên tên tiếng Việt phải
 * bỏ dấu mới tính được. Đây là một QUY ƯỚC do hệ thống chọn, không phải một
 * chân lý: "Tuấn" và "Tuân" bỏ dấu đều thành "TUAN" và cho cùng con số. Hệ
 * thống nói ra điều đó thay vì giấu đi, vì nó cho thấy phép tính này thô tới
 * mức nào.
 */
function chuanTen(ten) {
  return deaccent(String(ten || '')).toUpperCase().replace(/[^A-Z\s]/g, ' ').replace(/\s+/g, ' ').trim();
}

/** Số đường đời — cộng toàn bộ chữ số của ngày, tháng, năm sinh. */
function duongDoi(ngaySinh) {
  const m = String(ngaySinh || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return { ok: false, error: 'NGÀY_SINH_PHẢI_DẠNG_YYYY-MM-DD' };
  const [, nam, thang, ngay] = m;
  const d = rutSo(Number(ngay));
  const t = rutSo(Number(thang));
  const n = rutSo(Number(nam));
  const cong = d.so + t.so + n.so;
  const cuoi = rutSo(cong);
  return {
    ok: true, so: cuoi.so,
    cachTinh: `ngày ${ngay}→${d.so} · tháng ${thang}→${t.so} · năm ${nam}→${n.so} · `
      + `${d.so}+${t.so}+${n.so}=${cong}${cuoi.buoc.length > 1 ? `→${cuoi.so}` : ''}`,
  };
}

/** Số sứ mệnh — cộng giá trị mọi chữ cái trong họ tên. */
function suMenh(hoTen) {
  const ten = chuanTen(hoTen);
  if (!ten) return { ok: false, error: 'THIẾU_HỌ_TÊN' };
  const tong = [...ten].reduce((s, c) => s + giaTriChu(c), 0);
  const cuoi = rutSo(tong);
  return { ok: true, so: cuoi.so, tenDaBoDau: ten, cachTinh: `tổng chữ cái = ${tong}${cuoi.buoc.length > 1 ? ` → ${cuoi.so}` : ''}` };
}

/** Số linh hồn — chỉ cộng nguyên âm. */
function linhHon(hoTen) {
  const ten = chuanTen(hoTen);
  if (!ten) return { ok: false, error: 'THIẾU_HỌ_TÊN' };
  const tong = [...ten].filter((c) => NGUYEN_AM.has(c)).reduce((s, c) => s + giaTriChu(c), 0);
  const cuoi = rutSo(tong);
  return { ok: true, so: cuoi.so, cachTinh: `tổng nguyên âm = ${tong}${cuoi.buoc.length > 1 ? ` → ${cuoi.so}` : ''}` };
}

/** Số nhân cách — chỉ cộng phụ âm. */
function nhanCach(hoTen) {
  const ten = chuanTen(hoTen);
  if (!ten) return { ok: false, error: 'THIẾU_HỌ_TÊN' };
  const tong = [...ten].filter((c) => !NGUYEN_AM.has(c) && c !== ' ').reduce((s, c) => s + giaTriChu(c), 0);
  const cuoi = rutSo(tong);
  return { ok: true, so: cuoi.so, cachTinh: `tổng phụ âm = ${tong}${cuoi.buoc.length > 1 ? ` → ${cuoi.so}` : ''}` };
}

/**
 * Mô tả từng số, viết ở thì "người ta thường nói" — không viết ở thì khẳng
 * định, vì đó đúng là trạng thái của tri thức này.
 */
const MO_TA = {
  1: 'Người ta thường gắn số 1 với sự chủ động và muốn đi đầu.',
  2: 'Người ta thường gắn số 2 với sự hoà hợp và để ý tới người khác.',
  3: 'Người ta thường gắn số 3 với cách biểu đạt và sự vui vẻ.',
  4: 'Người ta thường gắn số 4 với sự chắc chắn và nền nếp.',
  5: 'Người ta thường gắn số 5 với sự thay đổi và thích cái mới.',
  6: 'Người ta thường gắn số 6 với trách nhiệm và chăm lo cho người thân.',
  7: 'Người ta thường gắn số 7 với sự suy ngẫm và thích tìm hiểu tận gốc.',
  8: 'Người ta thường gắn số 8 với tổ chức và mục tiêu lớn.',
  9: 'Người ta thường gắn số 9 với sự bao dung và quan tâm chuyện chung.',
  11: 'Số 11 được coi là số bậc thầy, người ta thường gắn với trực giác.',
  22: 'Số 22 được coi là số bậc thầy, người ta thường gắn với khả năng dựng việc lớn.',
  33: 'Số 33 được coi là số bậc thầy, người ta thường gắn với việc dạy dỗ và giúp người.',
};

const CANH_BAO = 'Thần số học không có bằng chứng khoa học về khả năng dự đoán tính cách hay kết quả học tập. '
  + 'Hệ thống tính con số này vì gia đình hỏi, và KHÔNG dùng nó vào bất kỳ quyết định nào về việc học của em. '
  + 'Đừng dùng con số này để nói với một đứa trẻ rằng em hợp hay không hợp với môn nào.';

/**
 * Tính trọn bộ. Luôn trả kèm `canhBao` và `dungVaoViec: 'không'` — hai trường
 * này là phần bắt buộc của kết quả, không phải phần trang trí.
 */
function tinh({ hoTen, ngaySinh } = {}) {
  const dd = duongDoi(ngaySinh);
  const sm = suMenh(hoTen);
  const lh = linhHon(hoTen);
  const nc = nhanCach(hoTen);
  const loi = [dd, sm, lh, nc].filter((x) => !x.ok).map((x) => x.error);
  if (loi.length) return { ok: false, loi, canhBao: CANH_BAO };

  const con = [
    { ma: 'duong-doi', ten: 'Số đường đời', so: dd.so, cachTinh: dd.cachTinh, moTa: MO_TA[dd.so] },
    { ma: 'su-menh', ten: 'Số sứ mệnh', so: sm.so, cachTinh: sm.cachTinh, moTa: MO_TA[sm.so] },
    { ma: 'linh-hon', ten: 'Số linh hồn', so: lh.so, cachTinh: lh.cachTinh, moTa: MO_TA[lh.so] },
    { ma: 'nhan-cach', ten: 'Số nhân cách', so: nc.so, cachTinh: nc.cachTinh, moTa: MO_TA[nc.so] },
  ];

  return {
    ok: true,
    tenDaBoDau: sm.tenDaBoDau,
    con,
    // Ba trường dưới đây đi kèm kết quả tới mọi nơi nó xuất hiện.
    canhBao: CANH_BAO,
    dungVaoViec: 'không',
    quyUoc: 'Tên tiếng Việt được BỎ DẤU trước khi tính, vì bảng chữ cái của thần số học không có dấu. '
      + 'Nghĩa là "Tuấn" và "Tuân" cho cùng một con số — phép tính này thô tới mức đó.',
  };
}

module.exports = { rutSo, giaTriChu, chuanTen, duongDoi, suMenh, linhHon, nhanCach, tinh, MO_TA, CANH_BAO, SO_BAC_THAY };
