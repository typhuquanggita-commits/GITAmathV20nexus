'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LỘ TRÌNH CÁ NHÂN HOÁ THEO CHẶNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Sáu chặng bám đúng sáu mốc của năm học (src/khao-sat/nam-hoc.js). Mỗi chặng
 *  kết thúc bằng MỘT BÀI TEST CỬA, và chặng cuối là BÀI THI TỔNG KẾT ở mức vận
 *  dụng cao. Không qua cửa thì không sang chặng sau — nhưng "không qua" ở đây
 *  KHÔNG phải trượt: nó có nghĩa là chặng ấy được kéo dài và nội dung được
 *  chỉnh, vì mục tiêu là học được chứ không phải đi cho hết lịch.
 *
 *  ĐIỀU LÀM TỆP NÀY KHÁC MỘT BỘ SINH LỘ TRÌNH THÔNG THƯỜNG: mỗi lần nó lấy
 *  một con số từ hồ sơ khảo sát, nó phải XIN PHÉP luật đo trước
 *  (duocAnhHuong), và ghi lại vết vào `vetNguon` — ai ảnh hưởng tới trường
 *  nào. Nhờ vậy câu hỏi "vì sao lộ trình của con tôi lại thế này" luôn có câu
 *  trả lời tra được, và câu hỏi "MBTI của con có ảnh hưởng tới bài không" có
 *  câu trả lời bằng dữ liệu chứ không bằng lời hứa.
 *
 *  Khi một công cụ bị luật đo từ chối, hệ thống KHÔNG im lặng bỏ qua. Nó ghi
 *  vào `daTuChoi` để người đọc thấy rằng luật đã chặn thật.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { duocAnhHuong } = require('./hien-phap-do');
const namHoc = require('./nam-hoc');
const { round } = require('../utils');

/** Nhịp mặc định khi chưa có căn cứ nào để chỉnh. */
const NHIP_CHUAN = { buoiMoiTuan: 4, phutMoiBuoi: 40 };

/** Điều kiện qua cửa mỗi chặng, trên chính đề phân loại nhóm giỏi. */
const CUA = {
  tiLeDungToiThieu: 0.55,
  // Không chỉ nhìn tổng: phải làm được phần vận dụng cao, nếu không thì em chỉ
  // đang gom điểm ở phần dễ của một đề vốn đã ít phần dễ.
  tiLeVanDungCaoToiThieu: 0.35,
};

/**
 * Dựng lộ trình.
 *
 * @param {object} o
 *   hoSo    đầu ra của ho-so.dungHoSo()
 *   lop, mon, mocBatDau
 */
function dungLoTrinh({ hoSo = null, lop = null, mon = 'math', mocBatDau = 'DAU_HK1', nguoiLonDaNoiChuyen = null } = {}) {
  if (!hoSo || !hoSo.ok) return { ok: false, error: 'THIẾU_HỒ_SƠ_KHẢO_SÁT' };
  // Cửa an toàn. Không phải "cấm vĩnh viễn" — mà là BẮT BUỘC CÓ NGƯỜI LỚN ĐI
  // TRƯỚC. Muốn qua cửa thì phải khai ai đã nói chuyện và nói khi nào, và tên
  // người ấy được ghi vào lộ trình. Một cái cửa mở được bằng cách bấm "bỏ qua"
  // thì không phải cửa; một cái cửa không bao giờ mở được thì người ta sẽ tắt
  // hẳn bài sàng lọc đi, và thế còn tệ hơn.
  if (hoSo.canNguoiLonNgay) {
    const xn = nguoiLonDaNoiChuyen;
    const du = xn && typeof xn === 'object' && xn.ten && xn.vai && xn.luc;
    if (!du) {
      return {
        ok: false, error: 'CẦN_NGƯỜI_LỚN_TRƯỚC',
        reason: 'Sàng lọc tâm lý có miền vượt ngưỡng cần báo ngay. Người lớn nói chuyện với em trước, '
          + 'rồi mới dựng lộ trình. Dựng lịch học dày lên cho một em đang thấy không an toàn ở trường là làm hỏng thêm.',
        canGi: 'Truyền nguoiLonDaNoiChuyen = { ten, vai, luc } — ai đã nói chuyện, với vai trò gì, vào lúc nào. '
          + 'Tên người ấy sẽ được ghi vào lộ trình.',
      };
    }
  }
  if (!hoSo.duDeDungLoTrinh) {
    return { ok: false, error: 'CHƯA_ĐỦ_CĂN_CỨ', reason: hoSo.ketLuan };
  }
  const l = Number(lop != null ? lop : hoSo.lop);
  if (!Number.isInteger(l) || l < 1 || l > 12) {
    // Không đoán lớp từ tuổi hay từ tên tài khoản. Lộ trình cả năm dựng trên
    // một con số đoán sai thì sai từ chặng đầu tới chặng cuối, và không ai
    // biết là nó sai vì bảng vẫn hiện ra đầy đủ.
    return {
      ok: false, error: 'CHƯA_BIẾT_LỚP',
      reason: 'Hệ thống chưa biết học viên đang học lớp mấy, nên chưa chọn được phạm vi kiến thức '
        + 'cho từng chặng. Đây là con số quyết định toàn bộ lộ trình, nên hệ thống không đoán.',
      canGi: 'Phụ huynh vào phòng "Chọn đích" trên bản đồ lộ trình để khai lớp và mục tiêu của con.',
    };
  }

  const lay = (ma) => (hoSo.phan.find((p) => p.ma === ma) || {}).ketQua || null;
  const vetNguon = [];
  const daTuChoi = [];

  /** Xin phép dùng một công cụ cho một miền. Ghi vết dù được hay không. */
  const xinPhep = (ma, mien, truong, viec) => {
    const g = duocAnhHuong(ma, mien);
    if (!g.ok) { daTuChoi.push({ congCu: ma, mien, truong, lyDo: g.reason || g.error }); return false; }
    vetNguon.push({ congCu: ma, mien, truong, viec });
    return true;
  };

  // ── NHỊP ────────────────────────────────────────────────────────────────
  const nhip = { ...NHIP_CHUAN };
  const pph = lay('PHUONG_PHAP_HOC');
  const tly = lay('TAM_LY_HOC_DUONG');

  if (pph && pph.ok && xinPhep('PHUONG_PHAP_HOC', 'nhip', 'phutMoiBuoi', 'rút buổi khi tập trung yếu')) {
    const tt = (pph.mien || []).find((m) => m.ma === 'TAP_TRUNG');
    if (tt && tt.duCanCu && tt.tuKhai < 2) { nhip.phutMoiBuoi = 20; nhip.buoiMoiTuan = 6; }
  }
  if (tly && tly.ok && xinPhep('TAM_LY_HOC_DUONG', 'nhip', 'buoiMoiTuan', 'giảm tải khi áp lực hoặc giấc ngủ vượt ngưỡng')) {
    const nang = (tly.mien || []).filter((m) => m.duCanCu && m.muc === 'dang-chu-y' && (m.ma === 'AP_LUC' || m.ma === 'GIAC_NGU'));
    if (nang.length) {
      nhip.buoiMoiTuan = Math.max(2, nhip.buoiMoiTuan - 1);
      nhip.ghiChu = `Giảm một buổi mỗi tuần vì ${nang.map((x) => x.ten.toLowerCase()).join(' và ')} đang ở mức đáng chú ý. `
        + 'Giảm tải là một quyết định học tập, không phải một sự nhân nhượng.';
    }
  }

  // ── CÁCH NÓI ────────────────────────────────────────────────────────────
  const cachNoi = [];
  const disc = lay('DISC');
  if (disc && disc.ok && disc.nhomTroi && xinPhep('DISC', 'cach-noi', 'cachNoi', 'chọn giọng phản hồi')) {
    cachNoi.push({ nguon: 'DISC', chu: disc.khiHoc, coiChung: disc.deMatDiem });
  }
  const mbti = lay('MBTI');
  if (mbti && mbti.ok && xinPhep('MBTI', 'cach-noi', 'cachNoi', 'chọn hình thức luyện tập')) {
    const ei = (mbti.chieu || []).find((c) => c.cap === 'EI');
    if (ei && ei.nghiengVe && !ei.satRanh) {
      cachNoi.push({
        nguon: 'MBTI',
        chu: ei.nghiengVe === 'E'
          ? 'Ưu tiên hình thức giảng lại và học cặp, vì em lấy lại sức khi trao đổi.'
          : 'Chừa khoảng yên tĩnh không bị ngắt, vì em lấy lại sức khi ở một mình.',
        coiChung: 'Đây là thiên hướng em tự nhận, không phải một quy định. Vẫn phải học đủ mọi dạng bài như nhau.',
      });
    }
  }
  // Thần số học được XIN PHÉP một cách có chủ ý, dù biết chắc sẽ bị từ chối.
  // Xin rồi bị chặn thì có vết trong `daTuChoi`, và người đọc thấy luật chặn
  // thật. Bỏ qua âm thầm thì không ai kiểm được là nó có bị dùng hay không.
  if (lay('THAN_SO')) xinPhep('THAN_SO', 'cach-noi', 'cachNoi', 'không được phép — ghi lại để chứng minh luật có chặn');

  // ── NỘI DUNG: sáu chặng ─────────────────────────────────────────────────
  const batDau = namHoc.MOC.findIndex((m) => m.ma === mocBatDau);
  if (batDau < 0) return { ok: false, error: 'KHÔNG_CÓ_MỐC_NÀY', mocBatDau };

  const nl = lay('NANG_LUC_MON');
  let mienYeu = [];
  if (pph && pph.ok && xinPhep('PHUONG_PHAP_HOC', 'noi-dung', 'cachGiaoBai', 'đổi cách giao bài theo miền yếu')) {
    mienYeu = (pph.mien || []).filter((m) => m.duCanCu && m.yeu);
  }
  if (nl) xinPhep('NANG_LUC_MON', 'noi-dung', 'phamVi', 'chọn dạng bài theo kết quả đề năng lực');

  const chang = namHoc.MOC.slice(batDau).map((m, i) => {
    const de = namHoc.moTaDe({ lop: l, mocMa: m.ma, mon, soCau: m.ma === 'CUOI_HK2' ? 30 : 20 });
    const cuoiCung = m.ma === 'CUOI_HK2';
    return {
      thu: i + 1,
      moc: m.ma, ten: m.ten, thang: m.thang, tuan: m.tuan.slice(),
      vaiTro: m.vaiTro,
      mucTieu: de.ok ? de.phamVi.danhSach : [],
      soDangPhaiThao: de.ok ? de.phamVi.danhSach.length : 0,
      nhip: { ...nhip },
      cachGiaoBai: mienYeu.map((x) => x.khiYeu),
      baiTestCua: de.ok ? {
        tenDe: cuoiCung ? `Thi tổng kết — ${m.ten}, mức vận dụng cao` : `Test cửa chặng ${i + 1} — ${m.ten}`,
        laThiTongKet: cuoiCung,
        tongCau: de.tongCau,
        theoMuc: de.theoMuc,
        phamVi: de.phamVi.quyTac,
        dieuKienQua: cuoiCung
          ? `Đúng ≥ ${Math.round(CUA.tiLeDungToiThieu * 100)}% tổng đề VÀ ≥ ${Math.round(CUA.tiLeVanDungCaoToiThieu * 100)}% phần 4★–5★.`
          : `Đúng ≥ ${Math.round(CUA.tiLeDungToiThieu * 100)}% tổng đề VÀ ≥ ${Math.round(CUA.tiLeVanDungCaoToiThieu * 100)}% phần 4★–5★.`,
        nhac: de.nhac,
      } : null,
      khongQuaThiSao: cuoiCung
        ? 'Chưa qua thì lùi kỳ thi tổng kết, vá đúng phần 4★–5★ còn hụt rồi thi lại. Không hạ chuẩn đề.'
        : 'Chưa qua thì KÉO DÀI chặng này chứ không bỏ qua: chặng sau dựng trên chặng này, đi tiếp là xây trên nền rỗng.',
    };
  });

  return {
    ok: true,
    hocVienId: hoSo.hocVienId, hoTen: hoSo.hoTen, lop: l, mon,
    // Ghi lại ai đã đi trước khi cửa an toàn mở. Trường này theo lộ trình suốt
    // đời nó, để sau này còn tra được là quy trình đã được làm thật.
    cuaAnToan: hoSo.canNguoiLonNgay
      ? { daMo: true, boi: nguoiLonDaNoiChuyen, ghiChu: 'Cửa an toàn đã mở sau khi có người lớn nói chuyện với em.' }
      : { daMo: false, boi: null, ghiChu: 'Không có miền nào cần báo ngay.' },
    soChang: chang.length,
    nhip,
    cachNoi,
    chang,
    // Hai danh sách dưới đây là phần kiểm toán được của lộ trình.
    vetNguon,
    daTuChoi,
    ketLuan: `Lộ trình ${chang.length} chặng cho lớp ${l}, mỗi chặng một bài test cửa, `
      + `chặng cuối là bài thi tổng kết ở mức vận dụng cao. `
      + `${vetNguon.length} lần dùng kết quả khảo sát, ${daTuChoi.length} lần bị luật đo chặn.`,
    doiChieu: 'Mọi trường trong lộ trình này đều tra ngược được về công cụ nào ảnh hưởng — xem vetNguon.',
  };
}

/** Chấm một bài test cửa và nói rõ qua hay chưa, vì sao. */
function chamCua({ soDung = 0, tongCau = 0, dungVanDungCao = 0, tongVanDungCao = 0 } = {}) {
  if (!tongCau) return { ok: false, error: 'THIẾU_TỔNG_CÂU' };
  const tiLe = soDung / tongCau;
  const tiLeCao = tongVanDungCao ? dungVanDungCao / tongVanDungCao : 0;
  const quaTong = tiLe >= CUA.tiLeDungToiThieu;
  const quaCao = tiLeCao >= CUA.tiLeVanDungCaoToiThieu;
  const qd = namHoc.quyDoiHocLuc(tiLe);
  return {
    ok: true,
    tiLeDung: round(tiLe, 3), tiLeVanDungCao: round(tiLeCao, 3),
    qua: quaTong && quaCao,
    quaTong, quaCao,
    uocLuongHocLuc: qd.ok ? qd.hocLuc : null,
    uocLuongTruong: qd.ok ? qd.uocLuongTruong : null,
    viSao: quaTong && quaCao
      ? 'Đạt cả hai điều kiện: tổng đề và riêng phần vận dụng cao.'
      : !quaTong && !quaCao
        ? 'Chưa đạt cả tổng đề lẫn phần vận dụng cao — chặng này cần kéo dài.'
        : quaTong
          ? 'Đủ tổng đề nhưng hụt phần 4★–5★: em đang gom điểm ở phần dễ của một đề vốn đã ít phần dễ. '
            + 'Chặng sau sẽ dựng trên đúng phần còn hụt đó.'
          : 'Làm tốt phần khó nhưng hụt tổng đề — thường là mất điểm ở chỗ không đáng, nên bước tự soát được siết lại.',
    nhac: namHoc.NHAC,
  };
}

module.exports = { NHIP_CHUAN, CUA, dungLoTrinh, chamCua };
