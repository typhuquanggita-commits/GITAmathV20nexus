'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MBTI — BỐN CẶP THIÊN HƯỚNG, TRONG BỐI CẢNH HỌC TẬP
 * ═══════════════════════════════════════════════════════════════════════════
 *    E ↔ I  Lấy lại sức bằng việc ở cùng người khác, hay bằng việc ở một mình
 *    S ↔ N  Bám vào cái cụ thể trước mắt, hay bám vào quy luật phía sau
 *    T ↔ F  Quyết bằng lập luận nhất quán, hay bằng ảnh hưởng tới người khác
 *    J ↔ P  Thích chốt sớm cho yên, hay thích để ngỏ cho linh hoạt
 *
 *  NÓI TRƯỚC ĐIỂM YẾU, vì nó quan trọng hơn kết quả:
 *
 *  MBTI cắt mỗi chiều thành hai nửa tại một điểm giữa, trong khi câu trả lời
 *  của người thật phân bố liên tục và dồn quanh chính điểm giữa ấy. Hệ quả:
 *  một người ở sát ranh giới làm lại sau vài tuần có thể ra loại khác, và đó
 *  là điểm yếu ĐÃ BIẾT của công cụ, không phải lỗi của người làm bài.
 *
 *  Nên hệ thống làm ba việc mà bản MBTI thương mại thường không làm:
 *    1. Luôn in ĐỘ NGHIÊNG của từng cặp, không chỉ in bốn chữ cái.
 *    2. Cặp nào nghiêng dưới ngưỡng thì ghi thẳng là "sát ranh giới", và bốn
 *       chữ cái được ghi kèm dấu hỏi ở đúng vị trí đó.
 *    3. KHÔNG dùng loại MBTI để quyết định học viên học gì. Xem
 *       src/khao-sat/hien-phap-do.js — MBTI chỉ được chạm miền 'cach-noi'.
 *
 *  Ba mươi hai câu viết tay cho bối cảnh học đường Việt Nam. Mỗi câu là một
 *  tình huống chọn một trong hai, không phải thang đồng ý — thang đồng ý ở
 *  lứa tuổi này thường ra "cái nào cũng đúng một nửa".
 * ═══════════════════════════════════════════════════════════════════════════
 */

const CAP = {
  EI: {
    ma: 'EI', trai: 'E', phai: 'I',
    tenTrai: 'Hướng ngoại', tenPhai: 'Hướng nội',
    hoi: 'Lấy lại sức bằng cách nào?',
  },
  SN: {
    ma: 'SN', trai: 'S', phai: 'N',
    tenTrai: 'Cụ thể', tenPhai: 'Khái quát',
    hoi: 'Bám vào cái trước mắt hay quy luật phía sau?',
  },
  TF: {
    ma: 'TF', trai: 'T', phai: 'F',
    tenTrai: 'Lập luận', tenPhai: 'Cảm nhận',
    hoi: 'Quyết bằng lẽ phải hay bằng ảnh hưởng tới người?',
  },
  JP: {
    ma: 'JP', trai: 'J', phai: 'P',
    tenTrai: 'Chốt sớm', tenPhai: 'Để ngỏ',
    hoi: 'Thích chốt kế hoạch hay thích linh hoạt?',
  },
};

/** [cặp, câu hỏi, đáp án phía TRÁI, đáp án phía PHẢI] */
const CAU = [
  ['EI', 'Sau một buổi học nhóm ba tiếng, em thấy', 'phấn chấn, muốn học tiếp', 'mệt, muốn ngồi một mình một lúc'],
  ['EI', 'Khi bí một bài, việc đầu tiên em làm là', 'hỏi ngay một người', 'tự vật lộn thêm một lúc đã'],
  ['EI', 'Em nhớ bài lâu hơn khi', 'giảng lại cho người khác nghe', 'viết lại một mình trong yên tĩnh'],
  ['EI', 'Giờ ra chơi, em thường', 'ra sân với nhóm bạn', 'ngồi lại lớp hoặc đi với một bạn thân'],
  ['EI', 'Khi cô hỏi cả lớp, em', 'nói ra rồi mới nghĩ tiếp', 'nghĩ xong trong đầu rồi mới nói'],
  ['EI', 'Chỗ học em thấy dễ tập trung nhất là', 'thư viện có người qua lại', 'phòng riêng đóng cửa'],
  ['EI', 'Em thích bài tập dạng', 'thuyết trình trước lớp', 'viết báo cáo nộp cô'],
  ['EI', 'Khi vui vì được điểm cao, em', 'kể ngay cho bạn', 'giữ trong lòng, về nhà mới kể'],

  ['SN', 'Đọc một đề toán, em chú ý trước tiên tới', 'các con số và dữ kiện cụ thể', 'dạng bài này giống dạng nào đã gặp'],
  ['SN', 'Em học thuộc công thức bằng cách', 'làm thật nhiều bài dùng công thức đó', 'hiểu công thức ấy từ đâu ra'],
  ['SN', 'Cô giảng một khái niệm mới, em muốn nghe', 'ví dụ cụ thể trước', 'ý tưởng chung trước'],
  ['SN', 'Khi làm bài văn, em mạnh ở phần', 'tả chi tiết, dẫn chứng cụ thể', 'nêu ý lớn, liên hệ mở rộng'],
  ['SN', 'Em tin vào', 'điều mình đã tự làm và thấy', 'điều suy ra được từ quy luật'],
  ['SN', 'Sách em thích đọc thường', 'kể chuyện có thật, có chi tiết', 'đặt ra giả định, tưởng tượng'],
  ['SN', 'Khi học lịch sử, em nhớ tốt hơn', 'mốc thời gian và sự kiện', 'nguyên nhân và hệ quả'],
  ['SN', 'Trước một bài tập lớn, em', 'bắt đầu từ phần đầu tiên và làm tuần tự', 'phác ra bức tranh chung rồi mới điền'],

  ['TF', 'Bạn thân làm sai bài mà nộp rồi, em', 'nói thẳng là sai chỗ nào', 'cân nhắc xem nói lúc này bạn có buồn không'],
  ['TF', 'Em thấy một lời nhận xét là tốt khi nó', 'đúng, dù nghe khó chịu', 'đúng và nói theo cách người nghe nhận được'],
  ['TF', 'Khi chia nhóm, em ưu tiên', 'chia theo việc, ai mạnh phần nào làm phần đó', 'chia sao cho không ai bị bỏ lại'],
  ['TF', 'Em khó chịu nhất khi', 'người ta lập luận mâu thuẫn', 'người ta đối xử không công bằng với ai đó'],
  ['TF', 'Điểm số với em là', 'một thước đo cần chính xác', 'một chuyện có thể làm người ta tổn thương'],
  ['TF', 'Khi tranh luận với bạn, em tập trung vào', 'ai có lý hơn', 'làm sao cả hai vẫn vui vẻ'],
  ['TF', 'Cô phê bình trước lớp, em nghĩ tới trước tiên', 'nội dung cô phê có đúng không', 'cảm giác của mình và của bạn bè nhìn vào'],
  ['TF', 'Em chọn người làm nhóm trưởng là người', 'làm việc chắc tay nhất', 'được cả nhóm quý nhất'],

  ['JP', 'Bài tập có hạn nộp thứ Sáu, em thường xong vào', 'thứ Ba, thứ Tư', 'thứ Năm tối hoặc thứ Sáu'],
  ['JP', 'Bàn học của em', 'gọn theo một chỗ cố định', 'bày ra theo việc đang làm'],
  ['JP', 'Em thấy thoải mái hơn khi', 'lịch tuần đã chốt xong', 'còn để trống vài buổi cho linh hoạt'],
  ['JP', 'Kế hoạch ôn thi của em', 'chia sẵn từng ngày học gì', 'tuỳ hôm đó thấy phần nào yếu thì học'],
  ['JP', 'Khi đi chơi xa cùng lớp, em muốn', 'biết trước lịch trình từng giờ', 'tới nơi rồi tính'],
  ['JP', 'Em thấy dễ chịu khi một việc', 'đã kết thúc hẳn', 'vẫn còn có thể sửa'],
  ['JP', 'Với một bài luận, em', 'lập dàn ý rồi mới viết', 'viết trước, sắp xếp sau'],
  ['JP', 'Cô đổi hạn nộp lùi lại một tuần, em', 'hơi tiếc vì đã làm xong rồi', 'mừng vì có thêm thời gian'],
];

const MA_CAP = ['EI', 'SN', 'TF', 'JP'];
/** Dưới ngưỡng này thì coi là SÁT RANH GIỚI — chữ cái ghi kèm dấu hỏi. */
const NGUONG_NGHIENG = 0.20;

/** Sinh đề. Phía trái/phải được ĐỔI CHỖ ở câu chẵn để vị trí không thành gợi ý. */
function deBai() {
  return CAU.map(([cap, hoi, trai, phai], i) => {
    const doi = i % 2 === 1;
    return {
      so: i + 1,
      cap,
      hoi,
      luaChon: doi
        ? [{ ma: CAP[cap].phai, chu: phai }, { ma: CAP[cap].trai, chu: trai }]
        : [{ ma: CAP[cap].trai, chu: trai }, { ma: CAP[cap].phai, chu: phai }],
    };
  });
}

/**
 * Chấm.
 * @param {Array<{so:number, chon:string}>} traLoi  chon là một chữ cái E/I/S/N/T/F/J/P
 */
function cham(traLoi = []) {
  const dem = { E: 0, I: 0, S: 0, N: 0, T: 0, F: 0, J: 0, P: 0 };
  const theoCap = { EI: 0, SN: 0, TF: 0, JP: 0 };
  const loi = [];
  const da = new Set();

  for (const t of traLoi) {
    const so = Number(t.so);
    const c = CAU[so - 1];
    if (!c) { loi.push(`câu ${t.so} không có trong đề`); continue; }
    if (da.has(so)) { loi.push(`câu ${so} trả lời hai lần`); continue; }
    const cap = CAP[c[0]];
    if (t.chon !== cap.trai && t.chon !== cap.phai) { loi.push(`câu ${so} chọn "${t.chon}" không thuộc cặp ${c[0]}`); continue; }
    da.add(so);
    dem[t.chon] += 1;
    theoCap[c[0]] += 1;
  }

  // Mỗi cặp phải đủ ít nhất sáu trên tám câu. Kiểm THEO TỪNG CẶP chứ không
  // theo tổng: trả lời đủ ba mươi hai câu nhưng bỏ trắng cả cặp J/P thì tổng
  // vẫn đẹp mà chữ cái thứ tư là bịa.
  const doiMoiCap = 6;
  const capThieu = MA_CAP.filter((k) => theoCap[k] < doiMoiCap);
  if (capThieu.length) {
    return {
      ok: false, duCanCu: false, theoCap, loi,
      ghiChu: `Chưa đủ câu ở ${capThieu.length} cặp (${capThieu.map((k) => `${k}: ${theoCap[k]}/8`).join(', ')}). `
        + `Mỗi cặp cần ít nhất ${doiMoiCap} câu. Thiếu một cặp thì chữ cái ở vị trí đó là bịa, `
        + 'dù ba chữ còn lại có chắc tới đâu.',
    };
  }

  const chieu = MA_CAP.map((k) => {
    const c = CAP[k];
    const t = dem[c.trai];
    const p = dem[c.phai];
    const tong = t + p;
    const nghiengVe = t === p ? null : (t > p ? c.trai : c.phai);
    const doNghieng = tong ? Math.abs(t - p) / tong : 0;
    const satRanh = doNghieng < NGUONG_NGHIENG || nghiengVe === null;
    return {
      cap: k, hoi: c.hoi,
      tenTrai: c.tenTrai, tenPhai: c.tenPhai,
      diemTrai: t, diemPhai: p,
      nghiengVe, doNghieng: Math.round(doNghieng * 100) / 100, satRanh,
    };
  });

  // Chữ cái ở cặp sát ranh giới ghi kèm dấu hỏi. Bốn chữ trơn tru là lời hứa
  // chắc chắn mà dữ liệu không đỡ nổi.
  const loai = chieu.map((c) => (c.nghiengVe || '?') + (c.satRanh && c.nghiengVe ? '?' : '')).join('');
  const loaiGon = chieu.map((c) => c.nghiengVe || '?').join('');
  const soSatRanh = chieu.filter((c) => c.satRanh).length;

  return {
    ok: true, duCanCu: true,
    loai, loaiGon, chieu, theoCap, loi,
    soSatRanh,
    ghiChu: soSatRanh
      ? `${soSatRanh}/4 cặp SÁT RANH GIỚI (đánh dấu ?). Ở những cặp đó, làm lại sau vài tuần rất có thể ra chữ khác — `
        + 'đây là điểm yếu đã biết của công cụ, không phải lỗi của em.'
      : 'Cả bốn cặp đều nghiêng rõ. Dù vậy đây vẫn là điều em TỰ NÓI về mình, không phải một phép đo năng lực.',
    canhBao: 'Loại MBTI KHÔNG được dùng để quyết định em học dạng bài nào hay học tới tầng nào.',
  };
}

module.exports = { CAP, CAU, MA_CAP, NGUONG_NGHIENG, deBai, cham };
