'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỘ KHẢO SÁT Ở MẶT TRONG — dựng đề, nhận bài, chấm, lưu
 * ═══════════════════════════════════════════════════════════════════════════
 *  Tệp này đứng giữa trang web và các bộ chấm. Nó làm đúng bốn việc và không
 *  làm gì khác: dựng đề cho trang, đọc biểu mẫu POST, gọi bộ chấm tương ứng,
 *  rồi đưa kết quả cho kho lưu theo đúng luật riêng tư của từng bộ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { CONG_CU_INDEX } = require('./hien-phap-do');
const { RIENG_TU } = require('./kho');
const { tangCua, TANG } = require('./ho-so');
const disc = require('./disc');
const mbti = require('./mbti');
const tamLy = require('./tam-ly-hoc-duong');
const phuongPhap = require('./phuong-phap-hoc');

/**
 * Sáu bộ, ánh xạ mã công cụ ↔ đường dẫn và bộ chấm.
 *   kieu  quyết định trang vẽ biểu mẫu kiểu gì
 */
const BO = {
  'phuong-phap': { ma: 'PHUONG_PHAP_HOC', kieu: 'thang', mod: phuongPhap },
  disc: { ma: 'DISC', kieu: 'tu-bo', mod: disc },
  mbti: { ma: 'MBTI', kieu: 'hai-lua', mod: mbti },
  'tam-ly': { ma: 'TAM_LY_HOC_DUONG', kieu: 'thang', mod: tamLy },
};
const DUONG_THEO_MA = new Map(Object.entries(BO).map(([d, b]) => [b.ma, d]));

/** Danh sách cho trang tổng, kèm trạng thái đã làm hay chưa. */
function danhSach({ daLam = {} } = {}) {
  const ra = [];
  for (const [ma, c] of CONG_CU_INDEX) {
    const duong = DUONG_THEO_MA.get(ma) || null;
    const t = tangCua(ma);
    const ban = daLam[ma] || null;
    ra.push({
      ma, duong, ten: c.ten,
      tang: t, tenTang: TANG[t].ten,
      doDuoc: c.doDuoc, khongDoDuoc: c.khongDoDuoc,
      duocDungDe: c.anhHuong.slice(),
      soCau: duong ? BO[duong].mod.deBai().length : 0,
      lamDuoc: !!duong,
      // Hai bộ không có biểu mẫu ở đây, và nói rõ vì sao thay vì hiện một nút hỏng.
      viSaoChuaLamDuoc: duong ? null
        : ma === 'NANG_LUC_MON'
          ? 'Bộ này là ĐỀ THI, làm ở phần lộ trình theo từng chặng chứ không làm ở đây.'
          : 'Bộ này chỉ cần ngày sinh và họ tên, nhập ở phần hồ sơ.',
      daLam: !!ban,
      daLamLuc: ban ? new Date(ban.luc).toISOString().slice(0, 10) : null,
    });
  }
  return ra.sort((a, b) => a.tang - b.tang || a.ma.localeCompare(b.ma));
}

/** Dựng một bộ đề cho trang làm bài. */
function deBai(duong) {
  const b = BO[duong];
  if (!b) return null;
  const c = CONG_CU_INDEX.get(b.ma);
  const lt = RIENG_TU[b.ma];
  return {
    ma: duong, maCongCu: b.ma, kieu: b.kieu,
    ten: c.ten, doDuoc: c.doDuoc, khongDoDuoc: c.khongDoDuoc, ghiChu: c.ghiChu,
    riengTu: lt.luuCauTho
      ? `Ai đọc được kết quả: ${lt.aiDoc.join(', ')}.`
      : `Ai đọc được kết quả: ${lt.aiDoc.join(', ')}. Hệ thống KHÔNG lưu từng câu trả lời, chỉ lưu kết quả theo miền.`,
    cau: b.mod.deBai(),
  };
}

/**
 * Đọc biểu mẫu POST thành mảng câu trả lời của đúng bộ ấy.
 * Biểu mẫu urlencoded cho mọi giá trị là chuỗi, nên chỗ này chịu trách nhiệm
 * đổi kiểu — và chịu trách nhiệm KHÔNG đoán khi thiếu.
 */
function docBieuMau(duong, form = {}) {
  const b = BO[duong];
  if (!b) return { ok: false, error: 'KHÔNG_CÓ_BỘ_NÀY' };
  const de = b.mod.deBai();
  const traLoi = [];
  const thieu = [];

  for (const c of de) {
    if (b.kieu === 'tu-bo') {
      const d = form[`dung_${c.so}`];
      const i = form[`it_${c.so}`];
      if (!d || !i) { thieu.push(c.so); continue; }
      traLoi.push({ so: c.so, dungNhat: String(d), itDungNhat: String(i) });
    } else if (b.kieu === 'hai-lua') {
      const v = form[`c_${c.so}`];
      if (!v) { thieu.push(c.so); continue; }
      traLoi.push({ so: c.so, chon: String(v) });
    } else {
      const v = form[`c_${c.so}`];
      if (v === undefined || v === '') { thieu.push(c.so); continue; }
      const n = Number(v);
      if (!Number.isInteger(n)) { thieu.push(c.so); continue; }
      traLoi.push({ so: c.so, diem: n });
    }
  }
  return { ok: true, traLoi, thieu, tongCau: de.length };
}

/** Chấm một bộ. `metrics` chỉ dùng cho bộ phương pháp học. */
function cham(duong, traLoi, { metrics = null } = {}) {
  const b = BO[duong];
  if (!b) return { ok: false, error: 'KHÔNG_CÓ_BỘ_NÀY' };
  return b.ma === 'PHUONG_PHAP_HOC' ? b.mod.cham(traLoi, { metrics }) : b.mod.cham(traLoi);
}

/**
 * Rút kết quả thành vài dòng đọc được cho trang "đã nộp".
 * Mỗi bộ có cách nói riêng; gộp chung thành một dòng chung chung thì trang kết
 * quả nói y hệt nhau cho cả bốn bộ và chẳng ai đọc.
 */
function tomTat(duong, kq) {
  const b = BO[duong];
  const dong = [];
  if (!kq || kq.ok === false) {
    return { motCau: 'Chưa chấm được bài này.', ketLuan: kq && kq.ghiChu ? kq.ghiChu : '', dong };
  }
  if (b.ma === 'DISC') {
    if (!kq.duCanCu) return { motCau: 'Chưa đủ câu để chấm.', ketLuan: kq.ghiChu, dong };
    for (const x of kq.xep) dong.push({ nhan: `${x.ten}:`, chu: `${x.diem} điểm` });
    return {
      motCau: kq.nhomTroi ? `Nhóm nổi hơn cả: ${kq.tenNhomTroi}.` : 'Bốn nhóm ngang nhau — không có nhóm trội.',
      ketLuan: kq.ghiChu, dong,
    };
  }
  if (b.ma === 'MBTI') {
    if (!kq.duCanCu) return { motCau: 'Chưa đủ câu để chấm.', ketLuan: kq.ghiChu, dong };
    for (const c of kq.chieu) {
      dong.push({
        nhan: `${c.tenTrai} ↔ ${c.tenPhai}:`,
        chu: `nghiêng về ${c.nghiengVe || 'giữa'} ${Math.round(c.doNghieng * 100)}%${c.satRanh ? ' (sát ranh giới)' : ''}`,
      });
    }
    return { motCau: `Loại: ${kq.loai}`, ketLuan: kq.ghiChu, dong };
  }
  if (b.ma === 'TAM_LY_HOC_DUONG') {
    for (const m of kq.mien.filter((x) => x.duCanCu)) {
      dong.push({ nhan: `${m.ten}:`, chu: m.muc === 'binh-thuong' ? 'bình thường' : m.muc === 'nhe' ? 'nhẹ' : 'đáng chú ý' });
    }
    return {
      motCau: kq.canNguoiLonNgay ? 'Có miền cần người lớn biết ngay.' : 'Đã ghi nhận sáu miền.',
      ketLuan: kq.ketLuan, canNguoiLonNgay: kq.canNguoiLonNgay, dong,
    };
  }
  // Phương pháp học
  for (const m of kq.mien.filter((x) => x.duCanCu)) {
    dong.push({
      nhan: `${m.ten}:`,
      chu: `tự chấm ${m.tuKhai}/4${m.datVet != null ? ` · dấu vết thật ${m.datVet}/4` : ' · chưa đối chiếu được'}`,
    });
  }
  return { motCau: kq.ketLuan, ketLuan: kq.ghiChu, dong };
}

module.exports = { BO, DUONG_THEO_MA, danhSach, deBai, docBieuMau, cham, tomTat };
