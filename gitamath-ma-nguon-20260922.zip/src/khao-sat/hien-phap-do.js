'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LUẬT ĐO — công cụ nào được phép quyết định điều gì
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Bộ khảo sát này gộp sáu công cụ rất khác nhau về SỨC NẶNG BẰNG CHỨNG. Một
 *  bài kiểm tra toán chấm được đúng sai; một bảng hỏi tính cách chỉ ghi lại
 *  điều người ta TỰ NÓI về mình; thần số học thì không đo gì cả. Trộn cả sáu
 *  vào một "hồ sơ" rồi để chúng cùng quyết định học viên học gì là cách nhanh
 *  nhất biến một hệ thống đo lường thành một cái máy bói có giao diện đẹp.
 *
 *  Nên tệp này ra trước mọi tệp khác trong thư mục, và nó là LUẬT:
 *
 *    1. Mỗi công cụ khai rõ ĐO ĐƯỢC GÌ và KHÔNG ĐO ĐƯỢC GÌ.
 *    2. Mỗi công cụ khai rõ được phép ảnh hưởng tới MIỀN nào.
 *    3. Bộ dựng lộ trình GỌI HÀM duocAnhHuong() trước khi dùng bất kỳ kết quả
 *       khảo sát nào. Không có ngoại lệ, và có mục kiểm chứng minh điều đó.
 *
 *  BỐN MIỀN mà một kết quả có thể ảnh hưởng tới:
 *    · 'noi-dung'   — học viên học DẠNG BÀI nào, ở TẦNG nào
 *    · 'nhip'       — nhịp học: mấy buổi một tuần, mỗi buổi bao lâu
 *    · 'cach-noi'   — cách trình bày, cách động viên, cách viết nhận xét
 *    · 'canh-bao'   — báo cho người lớn biết để trò chuyện
 *
 *  Ranh giới quan trọng nhất trong cả tệp: CHỈ hai công cụ có bằng chứng về
 *  hành vi học tập — bài kiểm tra năng lực môn học và khảo sát phương pháp học
 *  — mới được chạm vào miền 'noi-dung'. Tính cách không quyết định học viên
 *  phải học dạng bài nào. Một em hướng nội vẫn phải học đủ phương trình bậc
 *  hai như một em hướng ngoại, và gợi ý ngược lại là phân biệt đối xử được
 *  bọc trong ngôn ngữ tâm lý học.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const MIEN = ['noi-dung', 'nhip', 'cach-noi', 'canh-bao'];

/**
 * Sáu công cụ.
 *   ma            mã bất biến
 *   ten           tên hiển thị
 *   loai          'do-luong' (có đúng sai) | 'tu-khai' (người tự nói về mình)
 *                 | 'van-hoa' (không đo gì, thuộc về văn hoá)
 *   doDuoc        thứ công cụ này THẬT SỰ nói được
 *   khongDoDuoc   thứ nó KHÔNG nói được — viết ra để không ai dùng quá tay
 *   anhHuong      các miền nó được phép ảnh hưởng
 *   canNguoi      true nếu kết quả bắt buộc phải qua người thật trước khi dùng
 *   ghiChu        cảnh báo phải hiện kèm mọi lần in kết quả
 */
const CONG_CU = [
  {
    ma: 'NANG_LUC_MON',
    ten: 'Đề đánh giá năng lực môn học',
    loai: 'do-luong',
    doDuoc: 'Học viên làm được gì trên bài có đáp án đúng sai, ở mức vận dụng và vận dụng cao.',
    khongDoDuoc: 'Không nói được vì sao làm sai, và không đo được nỗ lực hay hoàn cảnh.',
    anhHuong: ['noi-dung', 'nhip', 'cach-noi'],
    canNguoi: false,
    ghiChu: 'Điểm của một buổi. Một buổi mệt cho một con số thấp hơn thực lực — nên hệ thống nhìn xu hướng nhiều buổi.',
  },
  {
    ma: 'PHUONG_PHAP_HOC',
    ten: 'Khảo sát tư duy, kỹ năng và phương pháp học',
    loai: 'tu-khai',
    doDuoc: 'Thói quen học mà học viên tự nhận, và đối chiếu được với dấu vết thật trong hệ thống.',
    khongDoDuoc: 'Không đo được năng lực. Người học kém phương pháp vẫn có thể giỏi.',
    // Được chạm 'noi-dung' vì thói quen học quyết định BÀI GIAO RA SAO (ôn giãn
    // cách, bắt viết bước, khoá gợi ý) — và vì từng mục của nó đối chiếu được
    // với dấu vết thật, không chỉ là lời tự khai.
    anhHuong: ['noi-dung', 'nhip', 'cach-noi'],
    canNguoi: false,
    ghiChu: 'Đây là điều học viên TỰ NÓI về mình. Hệ thống đối chiếu lại với dấu vết thật và báo chỗ lệch.',
  },
  {
    ma: 'DISC',
    ten: 'Khảo sát phong cách hành vi DISC',
    loai: 'tu-khai',
    doDuoc: 'Phong cách hành vi học viên tự nhận trong bối cảnh học tập.',
    khongDoDuoc: 'Không đo năng lực, không đoán được kết quả học, và không nói được học viên "là người thế nào".',
    anhHuong: ['cach-noi'],
    canNguoi: false,
    ghiChu: 'Thang ipsative: điểm bốn nhóm so với NHAU trong cùng một người, không so được giữa hai người.',
  },
  {
    ma: 'MBTI',
    ten: 'Khảo sát thiên hướng MBTI',
    loai: 'tu-khai',
    doDuoc: 'Thiên hướng lựa chọn mà học viên tự nhận trên bốn cặp đối lập.',
    khongDoDuoc: 'Không đo năng lực, không dự đoán thành tích, và không phải một chẩn đoán.',
    anhHuong: ['cach-noi'],
    canNguoi: false,
    ghiChu: 'Làm lại sau vài tuần có thể ra loại khác — đây là điểm yếu đã biết của công cụ này, không phải lỗi người làm bài.',
  },
  {
    ma: 'THAN_SO',
    ten: 'Thần số học',
    loai: 'van-hoa',
    doDuoc: 'Không đo gì cả. Đây là một phép tính trên ngày sinh và tên, thuộc về văn hoá.',
    khongDoDuoc: 'Không đo tính cách, không đo năng lực, không dự đoán được bất cứ điều gì về việc học.',
    // Danh sách RỖNG, và đây là chỗ quan trọng nhất của cả tệp. Thần số học
    // không được chạm vào bất kỳ miền nào — kể cả 'cach-noi'. Cho nó ảnh hưởng
    // tới cách nói cũng là để nó ảnh hưởng tới cách người lớn nhìn đứa trẻ.
    anhHuong: [],
    canNguoi: false,
    ghiChu: 'Không có bằng chứng khoa học nào cho thấy thần số học dự đoán được tính cách hay kết quả học tập. '
      + 'Hệ thống tính ra con số vì gia đình hỏi, và nói thẳng rằng nó không dùng con số ấy vào việc gì.',
  },
  {
    ma: 'TAM_LY_HOC_DUONG',
    ten: 'Sàng lọc tâm lý học đường',
    loai: 'tu-khai',
    doDuoc: 'Mức độ học viên tự thấy căng thẳng, lo âu thi cử, khó ngủ, hay thấy không an toàn ở trường.',
    khongDoDuoc: 'KHÔNG chẩn đoán bệnh. Một bảng hỏi không thay được người có chuyên môn.',
    anhHuong: ['nhip', 'cach-noi', 'canh-bao'],
    canNguoi: true,
    ghiChu: 'Đây là SÀNG LỌC, không phải chẩn đoán. Vượt ngưỡng nghĩa là cần một người lớn ngồi xuống nói chuyện, '
      + 'không nghĩa là có bệnh.',
  },
];

const CONG_CU_INDEX = new Map(CONG_CU.map((c) => [c.ma, c]));

/**
 * Công cụ `ma` có được phép ảnh hưởng tới miền `mien` không?
 *
 * Mọi chỗ dùng kết quả khảo sát đều phải đi qua hàm này. Trả về lý do bằng
 * chữ khi từ chối, để chỗ gọi khỏi tự chế thông báo và khỏi lặng lẽ bỏ qua.
 */
function duocAnhHuong(ma, mien) {
  const c = CONG_CU_INDEX.get(ma);
  if (!c) return { ok: false, error: 'KHÔNG_CÓ_CÔNG_CỤ_NÀY', ma };
  if (!MIEN.includes(mien)) return { ok: false, error: 'KHÔNG_CÓ_MIỀN_NÀY', mien };
  if (!c.anhHuong.includes(mien)) {
    return {
      ok: false, error: 'CÔNG_CỤ_KHÔNG_ĐƯỢC_CHẠM_MIỀN_NÀY',
      reason: `${c.ten} không được phép ảnh hưởng tới "${mien}". ${c.khongDoDuoc}`,
    };
  }
  return { ok: true, canNguoi: c.canNguoi };
}

/** Bảng luật đo, in kèm mọi hồ sơ để người đọc biết con số nào nặng con số nào nhẹ. */
function luatDo() {
  return {
    soCongCu: CONG_CU.length,
    mien: MIEN.slice(),
    congCu: CONG_CU.map((c) => ({ ...c, anhHuong: c.anhHuong.slice() })),
    // Hai câu này in ra cùng mọi hồ sơ. Chúng là phần quan trọng nhất của hồ sơ.
    loiDauBang: 'Sáu công cụ dưới đây KHÔNG cùng sức nặng. Chỉ hai công cụ — đề đánh giá năng lực môn học '
      + 'và khảo sát phương pháp học — được phép quyết định học viên học dạng bài nào. '
      + 'Bốn công cụ còn lại nói về cách nói chuyện với học viên, hoặc không nói gì cả.',
    soDuocQuyetNoiDung: CONG_CU.filter((c) => c.anhHuong.includes('noi-dung')).length,
  };
}

module.exports = { MIEN, CONG_CU, CONG_CU_INDEX, duocAnhHuong, luatDo };
