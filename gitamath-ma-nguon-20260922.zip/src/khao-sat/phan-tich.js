'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  PHÂN TÍCH BẢNG KHẢO SÁT — thang điểm, chuỗi vấn đề, nguyện vọng
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Bốn bộ khảo sát cho ra bốn bảng số rời rạc. Tệp này biến chúng thành thứ
 *  người chăm sóc dùng được: MỘT chuỗi vấn đề xếp theo thứ tự nên gỡ, và MỘT
 *  lộ trình bám đúng NGUYỆN VỌNG gia đình nói ra.
 *
 *  BA ĐIỀU QUYẾT ĐỊNH CHẤT LƯỢNG CỦA TỆP NÀY
 *
 *  1. THỨ TỰ GỠ, KHÔNG PHẢI DANH SÁCH. Đưa cho phụ huynh sáu vấn đề cùng lúc
 *     thì họ không gỡ vấn đề nào. Chuỗi ở đây xếp theo CĂN NGUYÊN: vấn đề nào
 *     gỡ xong làm nhẹ luôn vấn đề khác thì đứng trước. Ngủ không đủ đứng trước
 *     tập trung kém, vì gỡ giấc ngủ thì tập trung tự khá lên; làm ngược lại
 *     thì loay hoay mãi.
 *
 *  2. NGUYỆN VỌNG LÀ ĐẦU VÀO, KHÔNG PHẢI PHẦN TRANG TRÍ. Gia đình muốn "con
 *     vào lớp 10 trường công" khác hẳn gia đình muốn "con bớt sợ môn toán".
 *     Cùng một bảng điểm, hai nguyện vọng ấy phải ra hai lộ trình khác nhau,
 *     nếu không thì hỏi nguyện vọng làm gì.
 *
 *  3. KHÔNG GỘP ĐIỂM SÁU BỘ THÀNH MỘT SỐ. Một "chỉ số tổng hợp 78/100" trộn
 *     bài kiểm tra có đáp án với bảng hỏi tính cách là một con số vô nghĩa mà
 *     trông rất thuyết phục. Thang điểm ở đây chấm TỪNG MẶT, và nói rõ mặt nào
 *     nặng mặt nào nhẹ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');
const { duocAnhHuong } = require('./hien-phap-do');

/**
 * NGUYỆN VỌNG — gia đình chọn một, và lựa chọn ấy đổi thứ tự ưu tiên.
 *   uuTien   mặt nào được đẩy lên trước khi xếp chuỗi vấn đề
 *   doiGi    câu nói thẳng cho gia đình biết chọn cái này thì đổi gì
 */
const NGUYEN_VONG = {
  THI_CHUYEN_CAP: {
    ma: 'THI_CHUYEN_CAP', ten: 'Thi chuyển cấp hoặc thi vào trường mong muốn',
    uuTien: ['TOC_DO', 'NEN_KIEN_THUC', 'NHIP'],
    doiGi: 'Lộ trình bám mốc thi thật, luyện đề có bấm giờ sớm hơn, và chấp nhận nhịp dày hơn.',
  },
  LAY_LAI_GOC: {
    ma: 'LAY_LAI_GOC', ten: 'Lấy lại phần gốc đang hổng',
    uuTien: ['NEN_KIEN_THUC', 'PHUONG_PHAP', 'NHIP'],
    doiGi: 'Lùi phạm vi về lớp dưới, bỏ phần nâng cao cho tới khi nền chắc. Điểm trước mắt có thể chưa lên.',
  },
  BOT_SO_HOC: {
    ma: 'BOT_SO_HOC', ten: 'Con bớt sợ, bớt căng thẳng với việc học',
    uuTien: ['TAM_LY', 'NHIP', 'PHUONG_PHAP'],
    doiGi: 'Giảm tải trước, hạ độ khó một bậc, và đo tiến bộ bằng nhịp đi chứ không bằng điểm.',
  },
  TU_HOC: {
    ma: 'TU_HOC', ten: 'Con tự học được, không cần kèm',
    uuTien: ['PHUONG_PHAP', 'NHIP', 'NEN_KIEN_THUC'],
    doiGi: 'Giảm dần gợi ý, bắt viết căn cứ từng bước, chấp nhận chậm hơn trong vài tuần đầu.',
  },
  DI_DUONG_DAI: {
    ma: 'DI_DUONG_DAI', ten: 'Đi đường dài, chưa vội mốc nào',
    uuTien: ['NHIP', 'PHUONG_PHAP', 'NEN_KIEN_THUC'],
    doiGi: 'Nhịp nhẹ và đều, ưu tiên giữ hứng thú hơn là phủ nhanh chương trình.',
  },
};

/**
 * SÁU MẶT được chấm riêng. Mỗi mặt khai rõ lấy số từ đâu và NẶNG hay NHẸ.
 *   suckNang  'do-luong' số có đáp án đúng sai · 'tu-khai-doi-chieu' tự khai
 *             nhưng đối chiếu được · 'tu-khai' chỉ là lời tự nói
 */
const MAT = {
  NEN_KIEN_THUC: { ma: 'NEN_KIEN_THUC', ten: 'Nền kiến thức', suckNang: 'do-luong', tu: 'NANG_LUC_MON' },
  TOC_DO: { ma: 'TOC_DO', ten: 'Tốc độ làm bài', suckNang: 'do-luong', tu: 'PHUONG_PHAP_HOC' },
  PHUONG_PHAP: { ma: 'PHUONG_PHAP', ten: 'Phương pháp học', suckNang: 'tu-khai-doi-chieu', tu: 'PHUONG_PHAP_HOC' },
  NHIP: { ma: 'NHIP', ten: 'Nhịp học', suckNang: 'tu-khai-doi-chieu', tu: 'PHUONG_PHAP_HOC' },
  TAM_LY: { ma: 'TAM_LY', ten: 'Trạng thái tâm lý', suckNang: 'tu-khai', tu: 'TAM_LY_HOC_DUONG' },
  CACH_LAM_VIEC: { ma: 'CACH_LAM_VIEC', ten: 'Cách làm việc hợp với em', suckNang: 'tu-khai', tu: 'DISC' },
};

/** Thang điểm chung cho mọi mặt: 0–100, chia bốn dải có tên. */
const DAI = [
  { tu: 0, den: 40, ma: 'CAN_GO', ten: 'Cần gỡ trước', mau: 'do' },
  { tu: 40, den: 60, ma: 'DANG_YEU', ten: 'Đang yếu', mau: 'cam' },
  { tu: 60, den: 80, ma: 'ON', ten: 'Ổn', mau: 'lam' },
  { tu: 80, den: 101, ma: 'MANH', ten: 'Mạnh', mau: 'luc' },
];
const daiCua = (d) => DAI.find((x) => d >= x.tu && d < x.den) || DAI[0];

/**
 * CHUỖI CĂN NGUYÊN — mặt nào gỡ xong làm nhẹ mặt nào.
 * Dùng để xếp thứ tự gỡ: mặt đứng TRƯỚC trong chuỗi được gỡ trước.
 */
const CAN_NGUYEN = [
  { truoc: 'TAM_LY', sau: 'NHIP', vi: 'Đang căng thẳng hoặc thiếu ngủ thì giữ nhịp là việc bất khả.' },
  { truoc: 'NHIP', sau: 'NEN_KIEN_THUC', vi: 'Không đi đều thì vá nền bao nhiêu cũng rơi lại.' },
  { truoc: 'NHIP', sau: 'PHUONG_PHAP', vi: 'Phương pháp chỉ thành thói quen khi có nhịp lặp.' },
  { truoc: 'NEN_KIEN_THUC', sau: 'TOC_DO', vi: 'Chưa chắc nền thì luyện tốc độ là luyện làm sai nhanh hơn.' },
  { truoc: 'PHUONG_PHAP', sau: 'TOC_DO', vi: 'Không biết bỏ câu khó đi tiếp thì bấm giờ chỉ gây hoảng.' },
];

/** Thứ hạng căn nguyên: số nhỏ = gốc rễ hơn, gỡ trước. */
function bacCanNguyen() {
  const bac = {};
  for (const m of Object.keys(MAT)) bac[m] = 0;
  // Lặp đủ số cạnh là hội tụ với đồ thị nhỏ và không có chu trình.
  for (let i = 0; i < CAN_NGUYEN.length; i++) {
    for (const c of CAN_NGUYEN) if (bac[c.sau] <= bac[c.truoc]) bac[c.sau] = bac[c.truoc] + 1;
  }
  return bac;
}

/** Chấm sáu mặt từ các kết quả khảo sát thật. */
function chamSauMat(ketQua = {}) {
  const pp = ketQua.PHUONG_PHAP_HOC || null;
  const tl = ketQua.TAM_LY_HOC_DUONG || null;
  const disc = ketQua.DISC || null;
  const nl = ketQua.NANG_LUC_MON || null;

  const layMien = (kq, ma) => {
    if (!kq || !Array.isArray(kq.mien)) return null;
    const m = kq.mien.find((x) => x.ma === ma);
    return m && m.duCanCu ? m : null;
  };
  const tbMien = (kq, cacMa) => {
    const ds = cacMa.map((x) => layMien(kq, x)).filter(Boolean);
    if (!ds.length) return null;
    const tong = ds.reduce((s, m) => s + (m.tuKhai != null ? m.tuKhai : m.diemTrungBinh), 0);
    return tong / ds.length;
  };

  const ra = [];
  const them = (ma, diem, nguon, thieu) => {
    const M = MAT[ma];
    if (diem == null) { ra.push({ ...M, duCanCu: false, thieu: thieu || 'chưa làm bộ khảo sát tương ứng' }); return; }
    const d = round(Math.max(0, Math.min(100, diem)), 1);
    ra.push({ ...M, duCanCu: true, diem: d, dai: daiCua(d), nguon });
  };

  // Nền kiến thức: từ đề năng lực môn học (tỉ lệ đúng × 100).
  them('NEN_KIEN_THUC',
    nl && typeof nl.tiLeDung === 'number' ? nl.tiLeDung * 100 : null,
    'đề đánh giá năng lực môn học', 'chưa làm đề đánh giá năng lực môn học');

  // Tốc độ: miền quản lý thời gian, ưu tiên DẤU VẾT THẬT nếu có.
  const td = layMien(pp, 'THOI_GIAN');
  them('TOC_DO',
    td ? (td.datVet != null ? td.datVet : td.tuKhai) / 4 * 100 : null,
    td && td.datVet != null ? 'dấu vết thật' : 'lời tự khai', 'chưa làm khảo sát phương pháp học');

  // Phương pháp: trung bình các miền kỹ năng học.
  const ppTb = tbMien(pp, ['KE_HOACH', 'GHI_CHEP', 'ON_GIAN_CACH', 'TU_KIEM', 'LOI_SAI', 'DOC_DE']);
  them('PHUONG_PHAP', ppTb != null ? ppTb / 4 * 100 : null, 'khảo sát phương pháp học', 'chưa làm khảo sát phương pháp học');

  // Nhịp: miền lập kế hoạch và tập trung.
  const nhipTb = tbMien(pp, ['KE_HOACH', 'TAP_TRUNG']);
  them('NHIP', nhipTb != null ? nhipTb / 4 * 100 : null, 'khảo sát phương pháp học', 'chưa làm khảo sát phương pháp học');

  // Tâm lý: điểm CÀNG CAO ở bảng sàng lọc là CÀNG CĂNG, nên đảo chiều.
  //
  // Và KHÔNG lấy trung bình sáu miền. Trung bình làm chìm mất miền nặng: một
  // em mất ngủ ở mức 4/4 mà năm miền kia đều nhẹ sẽ ra điểm tâm lý "ổn", đúng
  // lúc giấc ngủ đang phá hỏng mọi thứ khác. Đây là cùng một lỗi đã phải sửa ở
  // điểm rủi ro rời bỏ, và nó sai ở đây vì đúng lý do ấy: sáu miền này KHÔNG
  // bù trừ cho nhau. Nên lấy MIỀN NẶNG NHẤT, và nêu tên nó ra.
  const tlDs = tl && Array.isArray(tl.mien) ? tl.mien.filter((m) => m.duCanCu) : [];
  const nangNhat = tlDs.length ? tlDs.reduce((a, b) => (b.diemTrungBinh > a.diemTrungBinh ? b : a)) : null;
  them('TAM_LY',
    nangNhat ? (1 - nangNhat.diemTrungBinh / 4) * 100 : null,
    nangNhat ? `miền nặng nhất: ${nangNhat.ten} (${nangNhat.diemTrungBinh}/4), đảo chiều — điểm cao là đang ổn`
      : 'sàng lọc tâm lý học đường',
    'chưa làm sàng lọc tâm lý');
  if (nangNhat) {
    const m = ra.find((x) => x.ma === 'TAM_LY');
    if (m) { m.mienNangNhat = { ma: nangNhat.ma, ten: nangNhat.ten, muc: nangNhat.muc, diem: nangNhat.diemTrungBinh }; }
  }

  // Cách làm việc: DISC không có thang so được giữa người, nên KHÔNG chấm điểm.
  const M = MAT.CACH_LAM_VIEC;
  ra.push(disc && disc.duCanCu
    ? { ...M, duCanCu: true, diem: null, nhomTroi: disc.nhomTroi, tenNhomTroi: disc.tenNhomTroi,
      khongChamDiem: 'DISC là thang ipsative — so được bốn nhóm trong một người, KHÔNG so được giữa hai người. '
        + 'Nên mặt này mô tả cách làm việc, không cho điểm.' }
    : { ...M, duCanCu: false, thieu: 'chưa làm khảo sát DISC' });

  return ra;
}

/**
 * Chuỗi vấn đề: xếp theo CĂN NGUYÊN trước, rồi mới tới điểm thấp, rồi mới tới
 * nguyện vọng của gia đình.
 */
function chuoiVanDe(sauMat, nguyenVong = null) {
  const bac = bacCanNguyen();
  const nv = NGUYEN_VONG[nguyenVong] || null;
  const uu = nv ? nv.uuTien : [];
  const can = sauMat.filter((m) => m.duCanCu && m.diem != null && m.diem < 60);

  const xep = can.slice().sort((a, b) => {
    // 1. gốc rễ hơn thì gỡ trước
    if (bac[a.ma] !== bac[b.ma]) return bac[a.ma] - bac[b.ma];
    // 2. gia đình nói muốn gì thì đẩy cái đó lên
    const ia = uu.indexOf(a.ma); const ib = uu.indexOf(b.ma);
    if (ia !== ib) return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    // 3. thấp hơn thì trước
    return a.diem - b.diem;
  });

  return xep.map((m, i) => {
    const goc = CAN_NGUYEN.find((c) => c.sau === m.ma && xep.some((x) => x.ma === c.truoc));
    return {
      thu: i + 1, ma: m.ma, ten: m.ten, diem: m.diem, dai: m.dai,
      suckNang: m.suckNang,
      viSaoThuTuNay: goc
        ? `Đứng sau "${MAT[goc.truoc].ten}" vì: ${goc.vi}`
        : uu.includes(m.ma)
          ? `Đẩy lên vì gia đình chọn nguyện vọng "${nv.ten}".`
          : 'Trong những mặt cần gỡ lần này, không mặt nào phải gỡ trước mặt này.',
      // Nói rõ mặt này nặng hay nhẹ, để người đọc biết tin tới đâu.
      tinToiDau: m.suckNang === 'do-luong' ? 'Số có đáp án đúng sai — tin được.'
        : m.suckNang === 'tu-khai-doi-chieu' ? 'Lời tự khai, có đối chiếu với dấu vết thật.'
          : 'Chỉ là lời em tự nói về mình.',
    };
  });
}

/**
 * Biên bản phân tích đầy đủ.
 * @param {object} o {ketQua, nguyenVong, ghiChuGiaDinh}
 */
function phanTich({ ketQua = {}, nguyenVong = null, ghiChuGiaDinh = '' } = {}) {
  const sauMat = chamSauMat(ketQua);
  const chuoi = chuoiVanDe(sauMat, nguyenVong);
  const nv = NGUYEN_VONG[nguyenVong] || null;
  const thieu = sauMat.filter((m) => !m.duCanCu);
  const doLuong = sauMat.filter((m) => m.duCanCu && m.suckNang === 'do-luong');

  // Nguyện vọng KHÔNG được tự ý đổi nội dung học. Xin phép luật đo cho minh bạch.
  const xinPhep = duocAnhHuong('PHUONG_PHAP_HOC', 'noi-dung');

  return {
    nguyenVong: nv ? { ...nv } : null,
    ghiChuGiaDinh: String(ghiChuGiaDinh || '').slice(0, 500),
    sauMat,
    chuoiVanDe: chuoi,
    soMatThieuCanCu: thieu.length,
    matThieuCanCu: thieu.map((m) => ({ ma: m.ma, ten: m.ten, thieu: m.thieu })),
    // KHÔNG có "chỉ số tổng hợp". Nói rõ vì sao không có.
    khongCoChiSoTongHop: 'Hệ thống KHÔNG gộp sáu mặt thành một con số. Trộn bài kiểm tra có đáp án với '
      + 'bảng hỏi tính cách cho ra một chỉ số trông rất thuyết phục mà không nói lên điều gì.',
    ketLuan: chuoi.length
      ? `${chuoi.length} mặt cần gỡ, theo thứ tự: ${chuoi.map((c) => c.ten).join(' → ')}.`
        + (nv ? ` Thứ tự này đã tính tới nguyện vọng "${nv.ten}".` : ' Chưa chọn nguyện vọng — thứ tự đang theo căn nguyên chung.')
      : doLuong.length || sauMat.some((m) => m.duCanCu)
        ? 'Không mặt nào dưới ngưỡng cần gỡ.'
        : 'Chưa đủ căn cứ: chưa làm bộ khảo sát nào cho ra số.',
    hopLuat: xinPhep.ok,
  };
}

module.exports = { NGUYEN_VONG, MAT, DAI, CAN_NGUYEN, daiCua, bacCanNguyen, chamSauMat, chuoiVanDe, phanTich };
