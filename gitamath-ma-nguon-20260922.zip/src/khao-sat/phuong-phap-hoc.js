'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHẢO SÁT TƯ DUY · KỸ NĂNG · PHƯƠNG PHÁP HỌC
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Đây là công cụ TỰ KHAI DUY NHẤT được phép chạm vào miền 'noi-dung' (xem
 *  src/khao-sat/hien-phap-do.js), và nó được phép vì một lý do cụ thể: gần như
 *  mọi mục của nó ĐỐI CHIẾU LẠI ĐƯỢC với dấu vết thật trong hệ thống.
 *
 *  Học viên khai "em luôn tự soát lại bài trước khi nộp", còn bộ quan sát ghi
 *  tỉ lệ sai do ẩu là 40%. Hai con số ấy va nhau, và CHỖ VA NHAU mới là thứ
 *  đáng giá nhất của cả bài khảo sát — đáng giá hơn cả hai con số đứng riêng.
 *  Một bảng hỏi tự khai không có đối chiếu thì chỉ đo được hình ảnh người ta
 *  muốn có về mình.
 *
 *  Nên kết quả luôn có ba phần: ĐIỂM TỰ KHAI · DẤU VẾT THẬT · CHỖ LỆCH. Và
 *  khi hệ thống chưa có dấu vết để đối chiếu thì nó nói thẳng là chưa đối
 *  chiếu được, chứ không im lặng để điểm tự khai trôi qua như sự thật.
 *
 *  Tám miền, mỗi miền ba câu. Thang 0–4 theo tần suất.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round } = require('../utils');

const THANG = [
  { diem: 0, chu: 'Gần như không bao giờ' },
  { diem: 1, chu: 'Thỉnh thoảng' },
  { diem: 2, chu: 'Khoảng một nửa số lần' },
  { diem: 3, chu: 'Phần lớn các lần' },
  { diem: 4, chu: 'Gần như luôn luôn' },
];

/**
 * Tám miền.
 *   doiChieu  tên phép đối chiếu với dấu vết thật; null nghĩa là CHƯA đối chiếu được
 *   khiYeu    hệ thống đổi cách giao bài ra sao khi miền này yếu
 */
const MIEN = {
  KE_HOACH: {
    ma: 'KE_HOACH', ten: 'Lập kế hoạch học',
    doiChieu: 'deuBuoi',
    khiYeu: 'Chia mục tiêu tuần thành việc từng ngày, mỗi ngày một việc làm xong được trong một buổi.',
  },
  THOI_GIAN: {
    ma: 'THOI_GIAN', ten: 'Quản lý thời gian làm bài',
    doiChieu: 'tocDo',
    khiYeu: 'Bật đồng hồ đếm ngược cho từng câu, và luyện riêng phần phân bổ giờ trước khi luyện đề đủ.',
  },
  GHI_CHEP: {
    ma: 'GHI_CHEP', ten: 'Ghi chép và hệ thống hoá',
    doiChieu: null,
    khiYeu: 'Mỗi dạng bài kết thúc bằng một thẻ tóm tắt do chính em viết: nhận ra dạng bằng dấu hiệu nào.',
  },
  ON_GIAN_CACH: {
    ma: 'ON_GIAN_CACH', ten: 'Ôn tập giãn cách',
    doiChieu: 'quayLai',
    khiYeu: 'Hệ thống tự chen bài cũ vào buổi mới theo lịch giãn cách, không chờ em tự nhớ quay lại.',
  },
  TU_KIEM: {
    ma: 'TU_KIEM', ten: 'Tự kiểm tra lại bài',
    doiChieu: 'saiDoAu',
    khiYeu: 'Thêm bước soát bắt buộc: thay nghiệm ngược vào, kiểm đơn vị, trước khi được bấm nộp.',
  },
  LOI_SAI: {
    ma: 'LOI_SAI', ten: 'Xử lý bài sai',
    doiChieu: 'xemLaiBaiSai',
    khiYeu: 'Bài sai được đưa lại kèm đúng bẫy đã mắc, và buổi sau mở bằng chính bài đó.',
  },
  TAP_TRUNG: {
    ma: 'TAP_TRUNG', ten: 'Tập trung khi học',
    doiChieu: 'buoiNgan',
    khiYeu: 'Rút buổi xuống còn hai mươi phút và tăng số buổi, thay vì giữ buổi dài mà mất tập trung giữa chừng.',
  },
  DOC_DE: {
    ma: 'DOC_DE', ten: 'Đọc và phân tích đề',
    doiChieu: 'nhanhMaSai',
    khiYeu: 'Bắt gạch chân dữ kiện và viết câu hỏi của đề ra trước khi được làm.',
  },
};

/** [miền, câu]. Câu viết ở ngôi thứ nhất, mô tả HÀNH VI, không hỏi về phẩm chất. */
const CAU = [
  ['KE_HOACH', 'Đầu tuần em biết tuần này mình sẽ học những phần nào'],
  ['KE_HOACH', 'Em học vào những khung giờ cố định trong ngày'],
  ['KE_HOACH', 'Khi kế hoạch vỡ, em xếp lại phần còn lại thay vì bỏ luôn'],

  ['THOI_GIAN', 'Làm đề có bấm giờ, em làm hết đề trước khi hết giờ'],
  ['THOI_GIAN', 'Em biết mình nên dành bao nhiêu phút cho một câu'],
  ['THOI_GIAN', 'Gặp câu khó, em bỏ qua làm câu sau rồi mới quay lại'],

  ['GHI_CHEP', 'Sau mỗi dạng bài, em ghi lại cách nhận ra dạng đó'],
  ['GHI_CHEP', 'Vở của em tìm lại được một công thức trong vòng một phút'],
  ['GHI_CHEP', 'Em viết lại bằng lời của mình, không chép nguyên lời cô'],

  ['ON_GIAN_CACH', 'Em quay lại bài của tuần trước chứ không chỉ học bài mới'],
  ['ON_GIAN_CACH', 'Trước kỳ thi, em ôn rải nhiều ngày chứ không dồn một đêm'],
  ['ON_GIAN_CACH', 'Em tự kiểm lại phần đã học từ lâu xem còn nhớ không'],

  ['TU_KIEM', 'Trước khi nộp, em soát lại phép tính'],
  ['TU_KIEM', 'Em thay đáp số ngược vào đề để kiểm'],
  ['TU_KIEM', 'Em kiểm đơn vị và điều kiện của bài trước khi kết luận'],

  ['LOI_SAI', 'Bài sai, em tìm ra mình sai ở BƯỚC nào'],
  ['LOI_SAI', 'Em phân biệt được sai vì chưa hiểu và sai vì ẩu'],
  ['LOI_SAI', 'Em làm lại đúng bài đã sai sau vài hôm'],

  ['TAP_TRUNG', 'Em học liền được hai mươi phút mà không đụng điện thoại'],
  ['TAP_TRUNG', 'Khi học, em để điện thoại ngoài tầm với'],
  ['TAP_TRUNG', 'Em nhận ra lúc mình bắt đầu mất tập trung'],

  ['DOC_DE', 'Em đọc hết đề trước khi đặt bút'],
  ['DOC_DE', 'Em gạch chân dữ kiện và điều đề hỏi'],
  ['DOC_DE', 'Em kiểm lại xem mình có trả lời đúng câu hỏi của đề không'],
];

const MA_MIEN = Object.keys(MIEN);
const CAU_TOI_THIEU_MOI_MIEN = 2;

function deBai() {
  return CAU.map(([mien, hoi], i) => ({
    so: i + 1, mien, tenMien: (MIEN[mien] || {}).ten || mien, hoi, thang: THANG.map((t) => ({ ...t })),
  }));
}

/**
 * Rút DẤU VẾT THẬT từ bộ quan sát, quy về cùng thang 0–4 để so được với lời
 * tự khai. Mỗi phép quy đổi viết rõ ở đây chứ không giấu trong công thức.
 */
function dauVetThat(metrics) {
  if (!metrics || !metrics.items) return null;
  const m = metrics;
  const thang4 = (x) => round(Math.max(0, Math.min(1, x)) * 4, 2);
  return {
    // Đi đều: số buổi trên tổng — chuẩn theo nhịp mong muốn 3 buổi/tuần trong 4 tuần.
    deuBuoi: m.sessions != null ? thang4(m.sessions / 12) : null,
    // Tốc độ: làm đúng nhịp đề thì medianSpeedRatio quanh 1; chậm thì tụt điểm.
    tocDo: m.medianSpeedRatio != null ? thang4(1.2 - m.medianSpeedRatio) : null,
    // Sai do ẩu cao nghĩa là tự kiểm kém.
    saiDoAu: m.carelessRate != null ? thang4(1 - m.carelessRate) : null,
    // Nhanh mà sai nghĩa là đọc đề vội.
    nhanhMaSai: m.fastWrongRate != null ? thang4(1 - m.fastWrongRate / 0.4) : null,
    // Buổi ngắn dưới 15 phút là dấu hiệu mất tập trung.
    buoiNgan: m.avgSessionMinutes != null ? thang4(m.avgSessionMinutes / 25) : null,
    // Hai phép dưới đây hệ thống CHƯA đo tách bạch được, nên để null thay vì
    // suy từ một con số gần đúng rồi trình bày như đã đo.
    quayLai: null,
    xemLaiBaiSai: null,
  };
}

/**
 * Chấm, kèm đối chiếu.
 * @param {Array<{so:number,diem:number}>} traLoi
 * @param {object} o {metrics} — số liệu thật từ bộ quan sát học viên
 */
function cham(traLoi = [], { metrics = null } = {}) {
  const gom = {};
  for (const k of MA_MIEN) gom[k] = [];
  const loi = [];
  const da = new Set();

  for (const t of traLoi) {
    const so = Number(t.so);
    const c = CAU[so - 1];
    if (!c || !MIEN[c[0]]) { loi.push(`câu ${t.so} không có trong đề`); continue; }
    if (da.has(so)) { loi.push(`câu ${so} trả lời hai lần`); continue; }
    const d = Number(t.diem);
    if (!Number.isInteger(d) || d < 0 || d > 4) { loi.push(`câu ${so} có điểm ${t.diem} ngoài thang 0–4`); continue; }
    da.add(so);
    gom[c[0]].push(d);
  }

  const vet = dauVetThat(metrics);
  const mien = MA_MIEN.map((k) => {
    const m = MIEN[k];
    const ds = gom[k];
    if (ds.length < CAU_TOI_THIEU_MOI_MIEN) {
      return { ma: k, ten: m.ten, duCanCu: false, soCau: ds.length, ghiChu: `mới ${ds.length} câu, cần ${CAU_TOI_THIEU_MOI_MIEN}` };
    }
    const tuKhai = round(ds.reduce((s, x) => s + x, 0) / ds.length, 2);
    const that = vet && m.doiChieu ? vet[m.doiChieu] : null;
    const lech = that == null ? null : round(tuKhai - that, 2);
    return {
      ma: k, ten: m.ten, duCanCu: true, soCau: ds.length,
      tuKhai,
      datVet: that,
      lech,
      // Lệch từ 1,5 điểm trở lên là chỗ đáng ngồi xuống nói chuyện: em tin một
      // đằng, dấu vết nói một nẻo, và cái tin sai ấy mới là thứ cản đường.
      lechDangKe: lech != null && Math.abs(lech) >= 1.5,
      yeu: tuKhai < 2,
      khiYeu: tuKhai < 2 ? m.khiYeu : null,
      chuaDoiChieu: that == null,
      viSaoChuaDoiChieu: that == null
        ? (m.doiChieu == null
          ? 'Hệ thống chưa có cách đo miền này bằng dấu vết — chỉ có lời tự khai.'
          : 'Chưa đủ dấu vết học để đối chiếu.')
        : null,
    };
  });

  const chamDuoc = mien.filter((x) => x.duCanCu);
  const yeu = chamDuoc.filter((x) => x.yeu);
  const lech = chamDuoc.filter((x) => x.lechDangKe);
  const chuaSo = chamDuoc.filter((x) => x.chuaDoiChieu);

  return {
    ok: true,
    soCauTraLoi: da.size, tongCau: CAU.filter((c) => MIEN[c[0]]).length,
    mien,
    mienYeu: yeu.map((x) => x.ma),
    // Chỗ lệch để TRƯỚC danh sách miền yếu trong kết luận, vì nó đáng giá hơn.
    choLech: lech.map((x) => ({
      ma: x.ma, ten: x.ten, tuKhai: x.tuKhai, datVet: x.datVet,
      chu: x.lech > 0
        ? `Em tự chấm ${x.tuKhai}/4 nhưng dấu vết thật cho ${x.datVet}/4 — em đang tin mình làm việc này tốt hơn thực tế.`
        : `Em tự chấm ${x.tuKhai}/4 nhưng dấu vết thật cho ${x.datVet}/4 — em đang làm tốt hơn em nghĩ.`,
    })),
    soChuaDoiChieu: chuaSo.length,
    ketLuan: lech.length
      ? `${lech.length} miền LỆCH giữa lời tự khai và dấu vết thật: ${lech.map((x) => x.ten).join(', ')}. `
        + 'Chỗ lệch đáng nói hơn cả điểm cao hay thấp.'
      : yeu.length
        ? `${yeu.length} miền còn yếu: ${yeu.map((x) => x.ten).join(', ')}.`
        : chamDuoc.length ? 'Không miền nào dưới ngưỡng yếu.' : 'Chưa đủ câu trả lời để chấm.',
    ghiChu: vet
      ? `Đã đối chiếu với dấu vết thật; ${chuaSo.length}/${chamDuoc.length} miền chưa đối chiếu được.`
      : 'CHƯA đối chiếu được với dấu vết nào — toàn bộ bảng dưới đây là điều em tự nói về mình.',
    loi,
  };
}

module.exports = { THANG, MIEN, CAU, MA_MIEN, deBai, cham, dauVetThat };
