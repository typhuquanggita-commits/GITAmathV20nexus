'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SƠ ĐỒ TƯ DUY BA CHIỀU — dựng từ chương trình THẬT, không bịa một nút nào
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Mọi nút trong sơ đồ này là một dạng toán CÓ THẬT trong chương trình, và
 *  mọi đường nối là một quan hệ tiên quyết ĐÃ KHAI trong src/curriculum.
 *  Không nút nào sinh ra cho đẹp hình, không đường nào nối cho đỡ trống.
 *
 *  Hệ quả có chủ ý: sơ đồ này XẤU ở đúng những chỗ chương trình còn thưa.
 *  Một chùm nút không có đường nối nào nghĩa là mảng ấy chưa ai khai quan hệ
 *  tiên quyết — và nhìn thấy chỗ thưa ấy đáng giá hơn một hình tròn đều đẹp
 *  mắt che mất nó.
 *
 *  BA CÁCH DỰNG, cho ba việc học khác nhau:
 *
 *      toan-canh    cả 104 dạng, xếp theo tầng. Để nhìn toàn cảnh chương
 *                   trình và thấy chỗ nào dày chỗ nào thưa.
 *      duong-di     đường từ một dạng ngược về mọi dạng phải biết trước. Để
 *                   trả lời "muốn học cái này thì cần gì".
 *      quanh-mot    một dạng và hàng xóm gần nó. Để ôn một chủ đề.
 *
 *  VÌ SAO BA CHIỀU CHỨ KHÔNG PHẢI HAI. Đồ thị tiên quyết của 104 dạng có
 *  nhiều cạnh cắt nhau; vẽ phẳng thì thành một búi chỉ rối. Trải ra ba chiều
 *  và cho xoay được thì người học tự tìm được góc nhìn mà ở đó đường đi rõ
 *  ra. Đây là lý do kỹ thuật, không phải lý do trang trí.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const H = require('../curriculum/hierarchy');
const { viTriTruXoan } = require('./khong-gian');

/**
 * Màu theo nhóm. Lấy từ bảng màu của hệ, không tự chọn thêm màu mới.
 *
 * Bản đầu chỉ có bốn nhóm toán theo lớp, nên MƯỜI TÁM dạng tiếng Anh và liên
 * môn rơi vào màu mặc định xám và KHÔNG xuất hiện trong chú thích — người xem
 * đếm chú thích ra 86 trong khi hình có 104 chấm, mà không hiểu 18 chấm xám
 * kia là gì. Chú thích thiếu một phần dữ liệu còn tệ hơn không có chú thích.
 */
const MAU_KHOI = {
  TH1: '#4da3ff', TH2: '#3ddc97', THCS: '#f5c542', THPT: '#ff6b6b',
  ANH: '#7c5cff', LIENMON: '#ff9f43',
};
const MAU_MAC_DINH = '#8fa0c8';

/** Tên đọc được của từng nhóm, cho chú thích. */
const TEN_KHOI = {
  TH1: 'Tiểu học 1–3', TH2: 'Tiểu học 4–5', THCS: 'THCS', THPT: 'THPT',
  ANH: 'Tiếng Anh', LIENMON: 'Liên môn',
};

/** Nhóm của một dạng, suy từ mã dạng. Mọi dạng đều phải có nhóm. */
function khoiCua(ma) {
  const m = String(ma);
  if (m.startsWith('E.')) return 'ANH';
  if (m.startsWith('X.')) return 'LIENMON';
  const lop = Number(m.match(/^M(\d+)/)?.[1] || 0);
  if (lop <= 0) return null;
  if (lop <= 3) return 'TH1';
  if (lop <= 5) return 'TH2';
  if (lop <= 9) return 'THCS';
  return 'THPT';
}

/**
 * Dựng sơ đồ.
 *
 * @param {object} o
 * @param {'toan-canh'|'duong-di'|'quanh-mot'} o.kieu
 * @param {string} o.goc  mã dạng làm gốc, bắt buộc với hai kiểu sau
 * @param {number} o.banKinhQuanh  quanh-mot: đi xa mấy bước
 */
function dung({ kieu = 'toan-canh', goc = null, banKinhQuanh = 1 } = {}) {
  const tatCa = H.FORMS;
  const chiMuc = new Map(tatCa.map((f) => [f.code, f]));

  if (kieu !== 'toan-canh') {
    if (!goc) return { ok: false, loi: 'THIEU_DANG_GOC', lyDo: `Kiểu "${kieu}" cần một mã dạng làm gốc.` };
    if (!chiMuc.has(goc)) {
      return { ok: false, loi: 'KHONG_CO_DANG', lyDo: `Không có dạng "${goc}" trong chương trình.` };
    }
  }

  let chon;
  if (kieu === 'toan-canh') {
    chon = tatCa;
  } else if (kieu === 'duong-di') {
    // Đi NGƯỢC theo quan hệ tiên quyết: muốn học dạng này thì phải biết gì.
    const da = new Set();
    const hang = [goc];
    while (hang.length) {
      const m = hang.shift();
      if (da.has(m)) continue;
      da.add(m);
      const f = chiMuc.get(m);
      for (const p of (f && f.prereq) || []) if (chiMuc.has(p)) hang.push(p);
    }
    chon = tatCa.filter((f) => da.has(f.code));
  } else {
    // Hàng xóm hai chiều, đi xa tối đa banKinhQuanh bước.
    const buoc = new Map([[goc, 0]]);
    const hang = [goc];
    const nguoc = new Map();
    for (const f of tatCa) {
      for (const p of f.prereq || []) {
        if (!nguoc.has(p)) nguoc.set(p, []);
        nguoc.get(p).push(f.code);
      }
    }
    while (hang.length) {
      const m = hang.shift();
      const d = buoc.get(m);
      if (d >= banKinhQuanh) continue;
      const f = chiMuc.get(m);
      for (const k of [...((f && f.prereq) || []), ...(nguoc.get(m) || [])]) {
        if (chiMuc.has(k) && !buoc.has(k)) { buoc.set(k, d + 1); hang.push(k); }
      }
    }
    chon = tatCa.filter((f) => buoc.has(f.code));
  }

  const coTrongSoDo = new Set(chon.map((f) => f.code));

  // Xếp theo TẦNG, lấy mốc dưới của khoảng tầng — đó là tầng sớm nhất học được.
  const theoTang = new Map();
  for (const f of chon) {
    const t = Array.isArray(f.levelRange) ? f.levelRange[0] : 0;
    if (!theoTang.has(t)) theoTang.set(t, []);
    theoTang.get(t).push(f);
  }
  const cacTang = [...theoTang.keys()].sort((a, b) => a - b);

  const nut = [];
  for (const [chiSoTang, t] of cacTang.entries()) {
    const ds = theoTang.get(t);
    // Sắp theo mã để vị trí TẤT ĐỊNH: cùng dữ liệu vào thì cùng hình ra.
    ds.sort((a, b) => a.code.localeCompare(b.code));
    for (const [i, f] of ds.entries()) {
      const khoi = khoiCua(f.code);
      nut.push({
        ma: f.code,
        ten: f.name,
        tang: t,
        khoi,
        mau: MAU_KHOI[khoi] || MAU_MAC_DINH,
        laGoc: f.code === goc,
        soBay: (f.traps || []).length,
        soCanTruoc: (f.prereq || []).length,
        ...viTriTruXoan(i, ds.length, chiSoTang, cacTang.length),
      });
    }
  }

  const canh = [];
  for (const f of chon) {
    for (const p of f.prereq || []) {
      if (coTrongSoDo.has(p)) canh.push({ tu: p, den: f.code });
    }
  }

  // Nút không có đường nối nào: chỗ chương trình còn thưa. Đếm và nói ra.
  const coCanh = new Set(canh.flatMap((c) => [c.tu, c.den]));
  const lacLoi = nut.filter((n) => !coCanh.has(n.ma));

  return {
    ok: true,
    kieu,
    goc,
    nut,
    canh,
    thongKe: {
      soNut: nut.length,
      soCanh: canh.length,
      soTang: cacTang.length,
      soNutLacLoi: lacLoi.length,
      theoKhoi: Object.fromEntries(
        Object.keys(MAU_KHOI).map((k) => [k, nut.filter((n) => n.khoi === k).length]).filter(([, v]) => v),
      ),
      // Nút chưa xếp được nhóm. Phải bằng 0 — có mục kiểm canh.
      soNutChuaCoNhom: nut.filter((n) => !n.khoi).length,
    },
    ghiChu: lacLoi.length
      ? `${lacLoi.length} dạng chưa khai quan hệ tiên quyết nên đứng rời. Đây là chỗ chương trình còn thưa, không phải lỗi vẽ.`
      : null,
  };
}

/** Danh sách dạng để người dùng chọn gốc. */
function dsDang() {
  return H.FORMS.map((f) => ({
    ma: f.code, ten: f.name, khoi: khoiCua(f.code),
    tang: Array.isArray(f.levelRange) ? f.levelRange[0] : 0,
  }));
}

/**
 * Soi chính bộ dựng này.
 *
 * Canh đúng những chỗ một sơ đồ kiến thức hỏng: nối tới nút không tồn tại,
 * tự nối vào chính mình, và vị trí không tất định.
 */
function soi() {
  const loi = [];
  const s = dung({ kieu: 'toan-canh' });
  const co = new Set(s.nut.map((n) => n.ma));

  for (const c of s.canh) {
    if (!co.has(c.tu) || !co.has(c.den)) loi.push(`cạnh trỏ ra ngoài sơ đồ: ${c.tu} → ${c.den}`);
    if (c.tu === c.den) loi.push(`dạng tự nối vào chính mình: ${c.tu}`);
  }
  const maTrung = s.nut.map((n) => n.ma).filter((m, i, a) => a.indexOf(m) !== i);
  if (maTrung.length) loi.push(`mã dạng trùng: ${[...new Set(maTrung)].join(', ')}`);

  // Chú thích phải đếm đủ. Thiếu một nhóm thì người xem đếm chấm ra một số,
  // đọc chú thích ra một số khác, và không hiểu phần chênh là gì.
  const chuaCoNhom = s.nut.filter((n) => !n.khoi);
  if (chuaCoNhom.length) {
    loi.push(`${chuaCoNhom.length} dạng chưa xếp được nhóm nên vắng mặt trong chú thích: `
      + `${chuaCoNhom.slice(0, 3).map((n) => n.ma).join(', ')}`);
  }
  const tongChuThich = Object.values(s.thongKe.theoKhoi).reduce((a, b) => a + b, 0);
  if (tongChuThich !== s.nut.length) {
    loi.push(`chú thích đếm ${tongChuThich} mà sơ đồ có ${s.nut.length} nút`);
  }

  // Tất định: dựng hai lần phải ra y hệt tới từng chữ số.
  const lai = dung({ kieu: 'toan-canh' });
  if (JSON.stringify(s.nut) !== JSON.stringify(lai.nut)) loi.push('vị trí nút KHÔNG tất định');

  return {
    dat: loi.length === 0,
    loi,
    soNut: s.nut.length,
    soCanh: s.canh.length,
    soNutLacLoi: s.thongKe.soNutLacLoi,
  };
}

module.exports = { dung, dsDang, soi, khoiCua, MAU_KHOI, TEN_KHOI };
