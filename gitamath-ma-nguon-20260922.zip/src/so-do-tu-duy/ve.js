'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  VẼ SƠ ĐỒ BA CHIỀU RA SVG — dựng ở máy chủ, in ra giấy được
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Một tệp SVG thuần: không JavaScript bên trong, không phông chữ ngoài,
 *  không gọi ra mạng. Mở bằng trình duyệt nào cũng được, nhúng vào báo cáo
 *  được, in ra giấy được, và lưu lại thì mười năm sau vẫn mở ra đúng như thế.
 *
 *  THỨ TỰ VẼ LÀ THỨ TỰ CHE KHUẤT. SVG vẽ theo thứ tự trong tệp, cái sau đè
 *  lên cái trước. Nên xếp xa trước gần sau là đã có che khuất, không cần bộ
 *  đệm chiều sâu. Cạnh vẽ trước nút vì cạnh luôn nằm dưới.
 *
 *  CHỮ CHỈ HIỆN Ở NÚT GẦN, VÀ CHỈ KHI KHÔNG ĐÈ LÊN NHÃN KHÁC.
 *
 *  Lọc theo chiều sâu thôi là chưa đủ: bản đầu chỉ bỏ nhãn của nút xa, và
 *  hình dựng ra vẫn có một vùng giữa dày đặc chữ chồng lên chữ — nhìn thấy
 *  ngay khi chụp màn hình. Ở vùng ấy không đọc được một nhãn nào, nên hai
 *  mươi nhãn chồng nhau cho ít thông tin hơn năm nhãn rời.
 *
 *  Nay mỗi nhãn phải xin một ô chữ nhật trên màn hình; ô nào đè lên ô đã cấp
 *  thì nhãn ấy bị bỏ. Xét theo thứ tự GẦN TRƯỚC, nên nút gần luôn thắng nút
 *  xa — đúng thứ tự mắt người ưu tiên.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { chieuDanhSach, moTheoSau } = require('./khong-gian');
const { round } = require('../utils');

const thoat = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

/** Nút gần hơn mốc này thì hiện chữ. */
const NGUONG_HIEN_CHU = 60;

/** Lề chừa quanh hình, và lề dưới rộng hơn vì chú thích nằm ở đó. */
const LE = 18;
const LE_DUOI = 34;

/**
 * Kéo cả hình cho vừa khung.
 *
 * Phép chiếu phối cảnh phóng to nút ở gần, nên ở một số góc xoay hình trụ
 * chìa ra NGOÀI khung: dựng hình 1100×720 ở góc mặc định thì hàng nút dưới
 * cùng rơi xuống y = 745, tức là bị cắt mất. Trên màn hình nó chỉ là một
 * hàng chấm cụt; in ra giấy thì mất hẳn một tầng kiến thức mà không ai biết.
 *
 * Nên sau khi chiếu, đo lại hộp bao THẬT rồi thu cả hình về cho vừa. Thu đều
 * cả hai chiều để không méo, và thu luôn tỉ lệ từng nút để chấm và chữ nhỏ
 * theo — nếu chỉ dời toạ độ mà giữ nguyên bán kính thì mép hình lại chìa ra.
 */
function khopVaoKhung(ds, rong, cao) {
  if (!ds.length) return ds;
  const bk = (n) => Math.max(2.5, (n.laGoc ? 11 : 6.5) * n.tiLe);
  let trai = Infinity;
  let phai = -Infinity;
  let tren = Infinity;
  let duoi = -Infinity;
  for (const n of ds) {
    const r = bk(n);
    trai = Math.min(trai, n.man.x - r);
    phai = Math.max(phai, n.man.x + r);
    tren = Math.min(tren, n.man.y - r);
    duoi = Math.max(duoi, n.man.y + r);
  }
  const rongCo = rong - LE * 2;
  const caoCo = cao - LE - LE_DUOI;
  const heSo = Math.min(1, rongCo / Math.max(1, phai - trai), caoCo / Math.max(1, duoi - tren));
  const dx = LE + rongCo / 2 - ((trai + phai) / 2) * heSo;
  const dy = LE + caoCo / 2 - ((tren + duoi) / 2) * heSo;
  return ds.map((n) => ({
    ...n,
    man: { x: round(n.man.x * heSo + dx, 2), y: round(n.man.y * heSo + dy, 2) },
    tiLe: round(n.tiLe * heSo, 4),
  }));
}

/**
 * Vẽ.
 *
 * @param {object} soDo kết quả của so-do.dung()
 * @param {object} o
 * @param {number} o.gocDoc   xoay trái phải, radian
 * @param {number} o.gocNgang xoay lên xuống, radian
 * @param {number} o.rong
 * @param {number} o.cao
 * @param {boolean} o.nen  vẽ nền tối; false thì trong suốt, để nhúng vào trang sáng
 */
function ve(soDo, { gocDoc = 0.6, gocNgang = 0.28, rong = 900, cao = 640, nen = true, hienChuHet = false } = {}) {
  if (!soDo || !soDo.ok) return '<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"></svg>';

  const tamX = rong / 2;
  const tamY = cao / 2;
  const tho = chieuDanhSach(soDo.nut, { gocDoc, gocNgang, tamX, tamY });
  const chieu = khopVaoKhung(tho, rong, cao);
  const viTri = new Map(chieu.map((n) => [n.ma, n]));

  // ── Cạnh ──
  // Vẽ trước tất cả, vì cạnh luôn nằm dưới nút. Cạnh nào có một đầu bị bỏ
  // (nằm sau mắt) thì bỏ luôn cạnh ấy — vẽ nửa cạnh còn tệ hơn không vẽ.
  const canh = [];
  for (const c of soDo.canh) {
    const a = viTri.get(c.tu);
    const b = viTri.get(c.den);
    if (!a || !b) continue;
    const sauTB = (a.sau + b.sau) / 2;
    const mo = round(moTheoSau(sauTB) * 0.55, 3);
    const day = round(Math.max(0.5, 1.6 * ((a.tiLe + b.tiLe) / 2)), 2);
    canh.push({ sau: sauTB, d: `<line x1="${a.man.x}" y1="${a.man.y}" x2="${b.man.x}" y2="${b.man.y}" `
      + `stroke="#6f86b8" stroke-opacity="${mo}" stroke-width="${day}"/>` });
  }
  canh.sort((x, y) => y.sau - x.sau);

  // ── Nút ──
  //
  // Xét NHÃN theo thứ tự gần trước (chieu xếp xa trước, nên đảo lại), để nút
  // gần luôn giành được chỗ. Còn hình tròn vẫn vẽ theo thứ tự xa trước để
  // giữ đúng che khuất.
  const oDaCap = [];
  const xinO = (x, y, rong2, cao2) => {
    const o = { t: x, p: x + rong2, tr: y - cao2 / 2, d: y + cao2 / 2 };
    // Nhãn chìa ra ngoài khung thì bị cắt mất một nửa chữ, mà nửa mã dạng
    // còn khó hiểu hơn không có chữ nào. Bỏ luôn.
    if (o.t < 2 || o.p > rong - 2 || o.tr < 2 || o.d > cao - LE_DUOI) return false;
    for (const c of oDaCap) {
      if (o.t < c.p && o.p > c.t && o.tr < c.d && o.d > c.tr) return false;
    }
    oDaCap.push(o);
    return true;
  };
  const choHienChu = new Set();
  // Nút GỐC xin chỗ TRƯỚC MỌI NÚT KHÁC.
  //
  // Lỗi có thật, chỉ lộ ra khi mở trang bằng trình duyệt: ở kiểu "đường đi",
  // nút gốc nằm sát một hàng xóm gần hơn, nên hàng xóm giành được ô chữ và
  // gốc mất nhãn. Người học nhìn vào hình không biết mình đang tra dạng nào —
  // đúng thứ duy nhất họ cần biết ở màn hình ấy.
  //
  // Thứ tự "gần trước" đúng với mọi nút khác, nhưng gốc không xếp hàng theo
  // chiều sâu: nó là câu hỏi, các nút còn lại là câu trả lời.
  const theoThuTuXin = [...chieu].reverse();
  theoThuTuXin.sort((a, b) => (b.laGoc ? 1 : 0) - (a.laGoc ? 1 : 0));
  for (const n of theoThuTuXin) {
    if (!hienChuHet && !n.laGoc && n.sau >= NGUONG_HIEN_CHU) continue;
    const r = Math.max(2.5, (n.laGoc ? 11 : 6.5) * n.tiLe);
    const co = Math.max(7.5, 11.5 * n.tiLe);
    // Bề rộng ước lượng: chữ hệ thống rộng khoảng 0,58 lần cỡ chữ.
    if (xinO(n.man.x + r + 4, n.man.y, n.ma.length * co * 0.58, co * 1.25)) {
      choHienChu.add(n.ma);
    }
  }

  const nut = [];
  for (const n of chieu) {
    const mo = moTheoSau(n.sau);
    const r = round(Math.max(2.5, (n.laGoc ? 11 : 6.5) * n.tiLe), 2);
    const viend = n.laGoc ? ' stroke="#ffffff" stroke-width="2"' : '';
    nut.push(`<circle cx="${n.man.x}" cy="${n.man.y}" r="${r}" fill="${n.mau}" fill-opacity="${mo}"${viend}>`
      + `<title>${thoat(n.ma)} — ${thoat(n.ten)}</title></circle>`);
    if (choHienChu.has(n.ma)) {
      const co = round(Math.max(7.5, 11.5 * n.tiLe), 1);
      nut.push(`<text x="${round(n.man.x + r + 4, 2)}" y="${round(n.man.y + 3.5, 2)}" `
        + `font-size="${co}" fill="#dbe4f7" fill-opacity="${round(mo, 3)}" `
        + `font-family="system-ui,sans-serif">${thoat(n.ma)}</text>`);
    }
  }

  const nenSvg = nen ? `<rect width="${rong}" height="${cao}" fill="#0b1020"/>` : '';
  const chuThich = Object.entries(soDo.thongKe.theoKhoi || {}).map(([k, v], i) => {
    const mau = require('./so-do').MAU_KHOI[k] || '#8fa0c8';
    const x = 14 + i * 96;
    return `<circle cx="${x}" cy="${cao - 16}" r="5" fill="${mau}"/>`
      + `<text x="${x + 10}" y="${cao - 12}" font-size="11" fill="#8fa0c8" `
      + `font-family="system-ui,sans-serif">${thoat(k)} · ${v}</text>`;
  }).join('');

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${rong} ${cao}" width="${rong}" height="${cao}" `
    + `role="img" aria-label="Sơ đồ tư duy ba chiều: ${soDo.thongKe.soNut} dạng toán, ${soDo.thongKe.soCanh} quan hệ tiên quyết">`
    + nenSvg
    + `<g>${canh.map((c) => c.d).join('')}</g>`
    + `<g>${nut.join('')}</g>`
    + chuThich
    + '</svg>';
}

module.exports = { ve, NGUONG_HIEN_CHU };
