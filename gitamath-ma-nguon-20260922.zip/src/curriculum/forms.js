'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DANH MỤC DẠNG BÀI — biên soạn tay, bám Chương trình GDPT 2018
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mỗi dạng là một đơn vị kiến thức KIỂM TRA ĐỘC LẬP ĐƯỢC. Không dạng nào
 *  sinh ra bằng cách ghép tổ hợp chủ đề — từng dòng dưới đây là một quyết
 *  định sư phạm: dạy cái gì, sau cái gì, học viên hay sai ở đâu, làm trong
 *  bao lâu là đạt.
 *
 *  code        MÔN.LỚP.CHỦĐỀ.DẠNG — khoá bất biến, đổi tên hiển thị thì được,
 *              đổi mã thì hỏng toàn bộ dữ liệu học tập đã tích luỹ.
 *  levelRange  [tầng thấp nhất, tầng cao nhất] dạng này còn có ý nghĩa.
 *  prereq      phải thạo trước. Là cạnh của đồ thị học — có kiểm tra chu trình.
 *  traps       lỗi sai điển hình. Dùng để GỌI TÊN chỗ hiểu sai của học viên,
 *              không phải để trang trí. Mỗi bẫy phải quan sát được trong bài làm.
 *  norm        thời gian chuẩn (giây) của học viên đạt chuẩn tầng giữa.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const FORMS = [
  // ══════════════════════ TOÁN TIỂU HỌC ══════════════════════════════════════
  // ── Lớp 1 ──
  { code: 'M1.SO.DEM20', name: 'Đếm, đọc, viết số trong phạm vi 20', levelRange: [0, 1], prereq: [], traps: ['đọc "mười một" thành "một mươi một"', 'viết ngược chữ số hàng chục'], norm: 60 },
  { code: 'M1.TINH.CONGTRU10', name: 'Cộng trừ trong phạm vi 10', levelRange: [0, 2], prereq: ['M1.SO.DEM20'], traps: ['đếm cả số xuất phát khi đếm thêm', 'nhầm dấu cộng với dấu trừ'], norm: 45 },
  { code: 'M1.TINH.CONGTRU20', name: 'Cộng trừ trong phạm vi 20 (qua 10)', levelRange: [1, 3], prereq: ['M1.TINH.CONGTRU10'], traps: ['tách số sai khi cộng qua 10', 'quên nhớ 1'], norm: 75 },
  { code: 'M1.HINH.NHANDANG', name: 'Nhận dạng hình vuông, tròn, tam giác, chữ nhật', levelRange: [0, 1], prereq: [], traps: ['gọi hình vuông là chữ nhật và ngược lại', 'lẫn khi hình bị xoay'], norm: 45 },
  { code: 'M1.DO.DODAI', name: 'Đo độ dài bằng đơn vị xăng-ti-mét', levelRange: [0, 2], prereq: ['M1.SO.DEM20'], traps: ['đặt thước không khớp vạch 0'], norm: 60 },

  // ── Lớp 2 ──
  { code: 'M2.SO.DEM100', name: 'Số có hai chữ số — cấu tạo, so sánh, sắp thứ tự', levelRange: [0, 2], prereq: ['M1.SO.DEM20'], traps: ['so sánh theo hàng đơn vị trước', 'nhầm số chục với số đơn vị'], norm: 75 },
  { code: 'M2.TINH.CONGTRU100', name: 'Cộng trừ có nhớ trong phạm vi 100', levelRange: [1, 3], prereq: ['M1.TINH.CONGTRU20', 'M2.SO.DEM100'], traps: ['quên nhớ sang hàng chục', 'trừ có nhớ mà không giảm hàng chục'], norm: 110 },
  { code: 'M2.NHAN.BANG25', name: 'Bảng nhân 2, 3, 4, 5', levelRange: [1, 3], prereq: ['M2.TINH.CONGTRU100'], traps: ['đọc thuộc nhưng không hiểu nhân là cộng nhiều lần'], norm: 60 },
  { code: 'M2.DO.DONVI', name: 'Đơn vị đo độ dài, khối lượng, thời gian và đổi đơn vị', levelRange: [1, 3], prereq: ['M1.DO.DODAI'], traps: ['đổi sai bậc 10 giữa các đơn vị', 'nhầm kg với g'], norm: 90 },
  { code: 'M2.GIAI.CO LOIVAN', name: 'Giải toán có lời văn một phép tính', levelRange: [1, 3], prereq: ['M2.TINH.CONGTRU100'], traps: ['chọn sai phép tính do bám từ khoá máy móc', 'thiếu lời giải và đơn vị'], norm: 120 },

  // ── Lớp 3 ──
  { code: 'M3.NHAN.BANG69', name: 'Bảng nhân 6, 7, 8, 9 và nhân số có hai chữ số', levelRange: [1, 3], prereq: ['M2.NHAN.BANG25'], traps: ['đặt tính lệch hàng khi nhân', 'quên cộng phần nhớ'], norm: 105 },
  { code: 'M3.CHIA.CODU', name: 'Phép chia hết và phép chia có dư', levelRange: [2, 4], prereq: ['M3.NHAN.BANG69'], traps: ['để số dư lớn hơn hoặc bằng số chia', 'quên viết số dư'], norm: 135 },
  { code: 'M3.HINH.CHUVI', name: 'Chu vi hình chữ nhật, hình vuông', levelRange: [1, 3], prereq: ['M1.HINH.NHANDANG', 'M2.DO.DONVI'], traps: ['cộng thiếu một cặp cạnh', 'quên đơn vị đo'], norm: 105 },
  { code: 'M3.THOIGIAN.XEMGIO', name: 'Xem đồng hồ, tính khoảng thời gian', levelRange: [1, 3], prereq: ['M2.DO.DONVI'], traps: ['tính khoảng thời gian qua mốc 12 giờ', 'nhầm giờ chiều với giờ sáng'], norm: 90 },
  { code: 'M3.GIAI.HAIPHEPTINH', name: 'Giải toán có lời văn hai phép tính', levelRange: [2, 4], prereq: ['M2.GIAI.CO LOIVAN', 'M3.CHIA.CODU'], traps: ['làm sai thứ tự hai bước', 'trả lời câu hỏi trung gian thay vì câu hỏi cuối'], norm: 165 },

  // ── Lớp 4 ──
  { code: 'M4.SO.LONHON', name: 'Số tự nhiên lớn — đọc, viết, so sánh, làm tròn', levelRange: [1, 3], prereq: ['M2.SO.DEM100'], traps: ['đọc sai lớp nghìn/triệu', 'làm tròn nhìn sai chữ số quyết định'], norm: 90 },
  { code: 'M4.CHIAHET.DAUHIEU', name: 'Dấu hiệu chia hết cho 2, 3, 5, 9', levelRange: [2, 4], prereq: ['M3.CHIA.CODU'], traps: ['áp dấu hiệu chia 3 cho phép chia 9', 'chỉ xét chữ số cuối khi xét chia 3'], norm: 90 },
  { code: 'M4.PHANSO.KHAINIEM', name: 'Phân số — khái niệm, rút gọn, quy đồng', levelRange: [2, 4], prereq: ['M4.CHIAHET.DAUHIEU'], traps: ['rút gọn chỉ tử hoặc chỉ mẫu', 'quy đồng xong quên đổi tử'], norm: 150 },
  { code: 'M4.PHANSO.CONGTRU', name: 'Cộng trừ phân số', levelRange: [2, 5], prereq: ['M4.PHANSO.KHAINIEM'], traps: ['cộng thẳng tử với tử, mẫu với mẫu'], norm: 165 },
  { code: 'M4.TRUNGBINH.CONG', name: 'Tìm số trung bình cộng', levelRange: [2, 4], prereq: ['M3.CHIA.CODU'], traps: ['chia cho số hạng sai', 'quên tính tổng trước khi chia'], norm: 120 },
  { code: 'M4.HINH.GOC', name: 'Góc nhọn, góc tù, góc bẹt và hai đường thẳng vuông góc, song song', levelRange: [1, 3], prereq: ['M1.HINH.NHANDANG'], traps: ['nhận định góc bằng mắt thay vì đo', 'nhầm vuông góc với cắt nhau'], norm: 90 },

  // ── Lớp 5 ──
  { code: 'M5.THAPPHAN.KHAINIEM', name: 'Số thập phân — đọc, viết, so sánh', levelRange: [2, 4], prereq: ['M4.PHANSO.KHAINIEM'], traps: ['so sánh theo độ dài phần thập phân', 'bỏ quên chữ số 0 ở giữa'], norm: 105 },
  { code: 'M5.THAPPHAN.BONPHEP', name: 'Bốn phép tính với số thập phân', levelRange: [2, 5], prereq: ['M5.THAPPHAN.KHAINIEM'], traps: ['đặt dấu phẩy lệch khi nhân', 'quên dời dấu phẩy khi chia cho số thập phân'], norm: 180 },
  { code: 'M5.TISO.PHANTRAM', name: 'Tỉ số phần trăm và ba bài toán cơ bản', levelRange: [3, 6], prereq: ['M5.THAPPHAN.BONPHEP'], traps: ['lấy nhầm số làm mốc 100%', 'tăng rồi giảm cùng số phần trăm tưởng về chỗ cũ'], norm: 240 },
  { code: 'M5.HINH.DIENTICH', name: 'Diện tích tam giác, hình thang, hình tròn', levelRange: [2, 5], prereq: ['M3.HINH.CHUVI'], traps: ['quên chia 2 ở tam giác và hình thang', 'lấy đường kính thay bán kính'], norm: 195 },
  { code: 'M5.HINH.THETICH', name: 'Thể tích hình hộp chữ nhật, hình lập phương', levelRange: [3, 5], prereq: ['M5.HINH.DIENTICH'], traps: ['nhầm diện tích xung quanh với toàn phần', 'đổi đơn vị thể tích sai bậc 1000'], norm: 210 },
  { code: 'M5.CHUYENDONG.DEU', name: 'Toán chuyển động đều', levelRange: [3, 6], prereq: ['M5.THAPPHAN.BONPHEP'], traps: ['không đổi phút sang giờ', 'cộng vận tốc khi chuyển động cùng chiều'], norm: 270 },

  // ══════════════════════ TOÁN THCS ══════════════════════════════════════════
  // ── Lớp 6 ──
  { code: 'M6.SONGUYEN.CONGTRU', name: 'Số nguyên âm — cộng, trừ, quy tắc dấu ngoặc', levelRange: [1, 4], prereq: ['M4.SO.LONHON'], traps: ['sai dấu khi bỏ ngoặc có dấu trừ đằng trước', 'nhầm trừ một số âm với cộng'], norm: 150 },
  { code: 'M6.LUYTHUA.TUNHIEN', name: 'Luỹ thừa với số mũ tự nhiên', levelRange: [2, 4], prereq: ['M3.NHAN.BANG69'], traps: ['cộng số mũ khi nhân cơ số khác nhau', 'tính 2³ thành 2×3'], norm: 120 },
  { code: 'M6.UOCBOI.UCLNBCNN', name: 'Ước chung lớn nhất, bội chung nhỏ nhất', levelRange: [2, 5], prereq: ['M4.CHIAHET.DAUHIEU', 'M6.LUYTHUA.TUNHIEN'], traps: ['lấy chung cả thừa số riêng khi tìm ƯCLN', 'nhầm quy tắc ƯCLN với BCNN'], norm: 180 },
  { code: 'M6.PHANSO.NHANCHIA', name: 'Nhân, chia phân số và hỗn số', levelRange: [2, 5], prereq: ['M4.PHANSO.CONGTRU'], traps: ['quên nghịch đảo khi chia', 'không đổi hỗn số trước khi nhân'], norm: 165 },
  { code: 'M6.HINH.TRUCQUAN', name: 'Hình học trực quan — hình phẳng và hình khối cơ bản', levelRange: [1, 3], prereq: ['M4.HINH.GOC'], traps: ['đếm sót mặt/cạnh của khối', 'nhầm hình lăng trụ với hình hộp'], norm: 135 },
  { code: 'M6.THONGKE.BANG', name: 'Thu thập và biểu diễn dữ liệu bằng bảng, biểu đồ', levelRange: [1, 4], prereq: [], traps: ['đọc sai tỉ lệ trục', 'bỏ sót đơn vị của dữ liệu'], norm: 150 },

  // ── Lớp 7 ──
  { code: 'M7.SOHUUTI.PHEPTINH', name: 'Số hữu tỉ và các phép tính', levelRange: [2, 5], prereq: ['M6.SONGUYEN.CONGTRU', 'M6.PHANSO.NHANCHIA'], traps: ['sai dấu khi nhân chia số âm', 'quên thứ tự thực hiện phép tính'], norm: 180 },
  { code: 'M7.TILE.THUCDAY', name: 'Tỉ lệ thức và dãy tỉ số bằng nhau', levelRange: [3, 6], prereq: ['M7.SOHUUTI.PHEPTINH'], traps: ['nhân chéo sai vị trí', 'dùng dãy tỉ số khi mẫu có thể bằng 0'], norm: 210 },
  { code: 'M7.DAILUONG.TILE', name: 'Đại lượng tỉ lệ thuận, tỉ lệ nghịch', levelRange: [3, 6], prereq: ['M7.TILE.THUCDAY'], traps: ['nhầm tỉ lệ nghịch thành tỉ lệ thuận', 'lập sai hệ số tỉ lệ'], norm: 225 },
  { code: 'M7.DATHUC.MOTBIEN', name: 'Biểu thức đại số và đa thức một biến', levelRange: [2, 5], prereq: ['M7.SOHUUTI.PHEPTINH'], traps: ['thu gọn nhầm hạng tử không đồng dạng', 'sắp xếp sai bậc'], norm: 180 },
  { code: 'M7.TAMGIAC.BANGNHAU', name: 'Các trường hợp bằng nhau của tam giác', levelRange: [2, 6], prereq: ['M6.HINH.TRUCQUAN'], traps: ['dùng "cạnh–cạnh–góc" như một trường hợp bằng nhau', 'ghi sai thứ tự đỉnh tương ứng'], norm: 300 },
  { code: 'M7.XACSUAT.THUCNGHIEM', name: 'Xác suất thực nghiệm của biến cố', levelRange: [2, 5], prereq: ['M6.THONGKE.BANG'], traps: ['lẫn số lần xảy ra với xác suất', 'quên tổng xác suất bằng 1'], norm: 165 },

  // ── Lớp 8 ──
  { code: 'M8.HANGDANGTHUC.BAY', name: 'Bảy hằng đẳng thức đáng nhớ', levelRange: [2, 5], prereq: ['M7.DATHUC.MOTBIEN'], traps: ['khai triển (a−b)² thiếu số hạng giữa', 'nhầm a³−b³ với (a−b)³'], norm: 150 },
  { code: 'M8.PHANTICH.DATHUC', name: 'Phân tích đa thức thành nhân tử', levelRange: [3, 6], prereq: ['M8.HANGDANGTHUC.BAY'], traps: ['dừng khi chưa phân tích triệt để', 'nhóm hạng tử sai dấu'], norm: 240 },
  { code: 'M8.PHANTHUC.RUTGON', name: 'Phân thức đại số — rút gọn và bốn phép tính', levelRange: [3, 6], prereq: ['M8.PHANTICH.DATHUC'], traps: ['rút gọn khi chưa phân tích thành nhân tử', 'quên điều kiện mẫu khác 0'], norm: 270 },
  { code: 'M8.PT.BACNHAT', name: 'Phương trình bậc nhất một ẩn và phương trình đưa được về bậc nhất', levelRange: [2, 5], prereq: ['M7.DATHUC.MOTBIEN'], traps: ['chuyển vế mà quên đổi dấu', 'chia hai vế cho biểu thức có thể bằng 0'], norm: 180 },
  { code: 'M8.GIAI.LAPPT', name: 'Giải bài toán bằng cách lập phương trình', levelRange: [2, 6], prereq: ['M8.PT.BACNHAT'], traps: ['đặt ẩn không kèm điều kiện', 'quên đối chiếu nghiệm với điều kiện thực tế'], norm: 330 },
  { code: 'M8.TAMGIAC.DONGDANG', name: 'Tam giác đồng dạng và các trường hợp', levelRange: [3, 7], prereq: ['M7.TAMGIAC.BANGNHAU'], traps: ['lập tỉ số cạnh không tương ứng', 'nhầm đồng dạng với bằng nhau'], norm: 330 },
  { code: 'M8.PYTAGO.UNGDUNG', name: 'Định lý Pythagore và ứng dụng', levelRange: [2, 5], prereq: ['M7.TAMGIAC.BANGNHAU'], traps: ['áp dụng cho tam giác không vuông', 'nhận nhầm cạnh huyền'], norm: 195 },
  { code: 'M8.HINHKHOI.THETICH', name: 'Hình chóp đều, lăng trụ đứng — diện tích và thể tích', levelRange: [3, 6], prereq: ['M5.HINH.THETICH', 'M8.PYTAGO.UNGDUNG'], traps: ['nhầm trung đoạn với chiều cao', 'quên chia 3 ở thể tích hình chóp'], norm: 300 },

  // ── Lớp 9 (đã có, giữ nguyên mã) ──
  { code: 'M9.CAN.RUTGON', name: 'Rút gọn biểu thức chứa căn', levelRange: [3, 6], prereq: ['M8.PHANTHUC.RUTGON'], traps: ['quên điều kiện xác định', 'sai dấu khi trục căn thức'], norm: 240 },
  { code: 'M9.CAN.DKXD', name: 'Tìm điều kiện xác định của biểu thức chứa căn', levelRange: [3, 5], prereq: ['M8.PHANTHUC.RUTGON'], traps: ['bỏ sót mẫu khác 0'], norm: 120 },
  { code: 'M9.PT2.GIAI', name: 'Giải phương trình bậc hai một ẩn', levelRange: [2, 4], prereq: ['M8.PT.BACNHAT'], traps: ['tính nhầm ∆', 'quên trường hợp a=0'], norm: 150 },
  { code: 'M9.PT2.THAMSO', name: 'Phương trình bậc hai chứa tham số', levelRange: [4, 7], prereq: ['M9.PT2.GIAI'], traps: ['quên xét a=0', 'thiếu điều kiện ∆≥0'], norm: 420 },
  { code: 'M9.PT2.VIET', name: 'Hệ thức Vi-ét và ứng dụng', levelRange: [4, 9], prereq: ['M9.PT2.GIAI'], traps: ['dùng Vi-ét khi chưa có nghiệm', 'sai dấu S và P'], norm: 360 },
  { code: 'M9.HPT.BACNHAT', name: 'Hệ phương trình bậc nhất hai ẩn', levelRange: [2, 5], prereq: ['M8.PT.BACNHAT'], traps: ['nhầm dấu khi cộng đại số', 'bỏ sót ràng buộc nghiệm phải là số nguyên dương'], norm: 180 },
  { code: 'M9.HAMSO.PARABOL', name: 'Hàm số y=ax² và tương giao với đường thẳng', levelRange: [3, 7], prereq: ['M9.PT2.GIAI'], traps: ['quên xét ∆ khi tìm giao điểm'], norm: 360 },
  { code: 'M9.HH.DUONGTRON.TIEPTUYEN', name: 'Tiếp tuyến của đường tròn', levelRange: [3, 7], prereq: ['M8.TAMGIAC.DONGDANG'], traps: ['thiếu chứng minh vuông góc bán kính'], norm: 420 },
  { code: 'M9.HH.TUGIAC.NOITIEP', name: 'Tứ giác nội tiếp', levelRange: [4, 8], prereq: ['M9.HH.DUONGTRON.TIEPTUYEN'], traps: ['nhầm góc nội tiếp và góc ở tâm'], norm: 480 },
  { code: 'M9.TOANTHUCTE.CHUYENDONG', name: 'Giải bài toán bằng cách lập phương trình — chuyển động', levelRange: [3, 6], prereq: ['M9.PT2.GIAI', 'M8.GIAI.LAPPT'], traps: ['sai đơn vị', 'thiếu điều kiện ẩn dương'], norm: 360 },

  // ══════════════════════ TOÁN THPT ══════════════════════════════════════════
  // ── Lớp 10 ──
  { code: 'M10.MENHDE.TAPHOP', name: 'Mệnh đề và tập hợp', levelRange: [0, 3], prereq: [], traps: ['nhầm phủ định của mệnh đề chứa lượng từ'], norm: 150 },
  { code: 'M10.BPT.BAC2', name: 'Bất phương trình bậc hai và dấu tam thức', levelRange: [3, 6], prereq: ['M9.PT2.GIAI'], traps: ['sai bảng xét dấu', 'quên đổi chiều khi nhân số âm'], norm: 300 },
  { code: 'M10.HAMSO.BAC2', name: 'Hàm số bậc hai và đồ thị parabol', levelRange: [3, 6], prereq: ['M9.HAMSO.PARABOL'], traps: ['xác định sai toạ độ đỉnh', 'nhầm bề lõm khi a âm'], norm: 270 },
  { code: 'M10.VECTO.TICHVOHUONG', name: 'Tích vô hướng của hai vectơ', levelRange: [3, 7], prereq: [], traps: ['nhầm góc giữa hai vectơ'], norm: 300 },
  { code: 'M10.LUONGGIAC.HETHUC', name: 'Hệ thức lượng trong tam giác', levelRange: [3, 7], prereq: ['M8.PYTAGO.UNGDUNG'], traps: ['dùng định lý sin khi thiếu dữ kiện'], norm: 360 },
  { code: 'M10.THONGKE.SOLIEU', name: 'Thống kê và xử lý số liệu', levelRange: [1, 4], prereq: ['M6.THONGKE.BANG'], traps: ['nhầm trung vị với trung bình'], norm: 240 },
  { code: 'M10.TOHOP.XACSUAT', name: 'Quy tắc đếm, hoán vị, chỉnh hợp, tổ hợp', levelRange: [3, 7], prereq: ['M10.MENHDE.TAPHOP'], traps: ['dùng chỉnh hợp khi thứ tự không quan trọng', 'đếm trùng do không loại trường hợp giao'], norm: 300 },
  { code: 'M10.TOADO.DUONGTHANG', name: 'Phương trình đường thẳng trong mặt phẳng toạ độ', levelRange: [3, 6], prereq: ['M10.VECTO.TICHVOHUONG'], traps: ['nhầm vectơ pháp tuyến với vectơ chỉ phương'], norm: 270 },

  // ── Lớp 11 ──
  { code: 'M11.LUONGGIAC.PHUONGTRINH', name: 'Phương trình lượng giác cơ bản và thường gặp', levelRange: [3, 7], prereq: ['M10.LUONGGIAC.HETHUC'], traps: ['thiếu họ nghiệm k2π', 'chia hai vế cho cos x mà chưa xét cos x = 0'], norm: 330 },
  { code: 'M11.DAYSO.CAPSO', name: 'Dãy số, cấp số cộng, cấp số nhân', levelRange: [3, 6], prereq: ['M7.DAILUONG.TILE'], traps: ['nhầm công sai với công bội', 'dùng công thức tổng n số hạng sai chỉ số', 'nhầm chỉ số n với n trừ 1 ở số hạng tổng quát'], norm: 270 },
  { code: 'M11.GIOIHAN.DAYHAM', name: 'Giới hạn của dãy số và hàm số', levelRange: [3, 7], prereq: ['M11.DAYSO.CAPSO'], traps: ['khử dạng vô định sai', 'kết luận giới hạn khi hai phía khác nhau'], norm: 300 },
  { code: 'M11.DAOHAM.QUYTAC', name: 'Đạo hàm — định nghĩa và quy tắc tính', levelRange: [3, 6], prereq: ['M11.GIOIHAN.DAYHAM'], traps: ['quên đạo hàm hàm hợp', 'sai công thức đạo hàm thương', 'sai quy tắc đạo hàm của luỹ thừa'], norm: 240 },
  { code: 'M11.KHONGGIAN.SONGSONG', name: 'Quan hệ song song trong không gian', levelRange: [3, 6], prereq: ['M8.HINHKHOI.THETICH'], traps: ['kết luận song song khi hai đường chéo nhau', 'thiếu điều kiện hai đường cắt nhau khi chứng minh song song mặt phẳng'], norm: 360 },
  { code: 'M11.KHONGGIAN.VUONGGOC', name: 'Quan hệ vuông góc, góc và khoảng cách trong không gian', levelRange: [4, 9], prereq: ['M11.KHONGGIAN.SONGSONG'], traps: ['dựng sai hình chiếu vuông góc', 'nhầm góc giữa đường và mặt với góc giữa hai mặt'], norm: 480 },
  { code: 'M11.XACSUAT.BIENCO', name: 'Xác suất của biến cố — quy tắc cộng và nhân', levelRange: [3, 7], prereq: ['M10.TOHOP.XACSUAT'], traps: ['cộng xác suất hai biến cố không xung khắc', 'nhân xác suất hai biến cố không độc lập'], norm: 300 },

  // ── Lớp 12 ──
  { code: 'M12.KHAOSAT.HAMSO', name: 'Khảo sát và vẽ đồ thị hàm số', levelRange: [3, 6], prereq: ['M11.DAOHAM.QUYTAC'], traps: ['thiếu tiệm cận', 'sai bảng biến thiên'], norm: 480 },
  { code: 'M12.CUCTRI.THAMSO', name: 'Cực trị hàm số chứa tham số', levelRange: [5, 9], prereq: ['M12.KHAOSAT.HAMSO'], traps: ['quên điều kiện y\' đổi dấu'], norm: 540 },
  { code: 'M12.GTLN.GTNN', name: 'Giá trị lớn nhất, nhỏ nhất của hàm số trên một đoạn', levelRange: [3, 6], prereq: ['M12.KHAOSAT.HAMSO'], traps: ['bỏ quên giá trị tại hai đầu mút', 'xét điểm tới hạn ngoài đoạn'], norm: 330 },
  { code: 'M12.MU.LOGARIT', name: 'Phương trình, bất phương trình mũ và lôgarit', levelRange: [3, 7], prereq: ['M6.LUYTHUA.TUNHIEN', 'M10.BPT.BAC2'], traps: ['quên điều kiện cơ số và đối số', 'không đổi chiều bất phương trình khi cơ số nhỏ hơn 1', 'giữ lại nghiệm âm của ẩn phụ là một luỹ thừa'], norm: 360 },
  { code: 'M12.NGUYENHAM.COBAN', name: 'Nguyên hàm — bảng nguyên hàm cơ bản', levelRange: [3, 6], prereq: ['M11.DAOHAM.QUYTAC'], traps: ['quên hằng số C', 'nhầm nguyên hàm của 1/x'], norm: 240 },
  { code: 'M12.TICHPHAN.DOIBIEN', name: 'Tích phân đổi biến số', levelRange: [4, 7], prereq: ['M12.NGUYENHAM.COBAN'], traps: ['quên đổi cận'], norm: 300 },
  { code: 'M12.TICHPHAN.TUNGPHAN', name: 'Tích phân từng phần', levelRange: [5, 9], prereq: ['M12.TICHPHAN.DOIBIEN'], traps: ['chọn u, dv sai thứ tự ưu tiên', 'mất dấu trừ ở lần lấy từng phần thứ hai'], norm: 360 },
  { code: 'M12.UNGDUNG.TICHPHAN', name: 'Ứng dụng tích phân — diện tích hình phẳng, thể tích khối tròn xoay', levelRange: [5, 9], prereq: ['M12.TICHPHAN.DOIBIEN'], traps: ['không tách đoạn khi hàm đổi dấu', 'quên bình phương bán kính khi tính thể tích'], norm: 420 },
  { code: 'M12.SOPHUC.PHUONGTRINH', name: 'Phương trình trên tập số phức', levelRange: [4, 7], prereq: ['M9.PT2.GIAI'], traps: ['bỏ nghiệm phức liên hợp'], norm: 240 },
  { code: 'M12.KHOIDADIEN.THETICH', name: 'Thể tích khối đa diện', levelRange: [4, 7], prereq: ['M11.KHONGGIAN.VUONGGOC'], traps: ['xác định sai chân đường cao', 'nhầm diện tích đáy'], norm: 420 },
  { code: 'M12.TRONXOAY.NON TRU CAU', name: 'Khối nón, khối trụ, khối cầu', levelRange: [4, 7], prereq: ['M12.KHOIDADIEN.THETICH'], traps: ['nhầm đường sinh với chiều cao', 'quên nửa góc ở đỉnh'], norm: 390 },
  { code: 'M12.OXYZ.MATPHANG', name: 'Phương trình mặt phẳng trong không gian Oxyz', levelRange: [3, 7], prereq: ['M10.TOADO.DUONGTHANG'], traps: ['nhầm vectơ pháp tuyến'], norm: 300 },
  { code: 'M12.OXYZ.DUONGTHANG', name: 'Phương trình đường thẳng trong không gian Oxyz', levelRange: [4, 7], prereq: ['M12.OXYZ.MATPHANG'], traps: ['nhầm tham số của hai đường khác nhau khi xét cắt nhau'], norm: 330 },
  { code: 'M12.OXYZ.MATCAU', name: 'Mặt cầu và vị trí tương đối', levelRange: [4, 9], prereq: ['M12.OXYZ.MATPHANG'], traps: ['sai công thức khoảng cách tâm đến mặt phẳng', 'lấy sai dấu toạ độ tâm mặt cầu'], norm: 360 },

  // ══════════════════════ TIẾNG ANH ══════════════════════════════════════════
  { code: 'E.VOCAB.COLLOCATION', name: 'Kết hợp từ thường gặp (collocation)', levelRange: [1, 6], prereq: [], traps: ['dịch từng từ từ tiếng Việt sang'], norm: 90 },
  { code: 'E.GRAMMAR.TENSE', name: 'Hệ thống thì trong tiếng Anh', levelRange: [0, 4], prereq: [], traps: ['nhầm hiện tại hoàn thành với quá khứ đơn'], norm: 120 },
  { code: 'E.GRAMMAR.PASSIVE', name: 'Câu bị động', levelRange: [2, 5], prereq: ['E.GRAMMAR.TENSE'], traps: ['quên đổi thì của động từ to be', 'bị động với động từ không có tân ngữ'], norm: 135 },
  { code: 'E.GRAMMAR.CONDITIONAL', name: 'Câu điều kiện', levelRange: [2, 6], prereq: ['E.GRAMMAR.TENSE'], traps: ['lẫn loại 2 và loại 3'], norm: 150 },
  { code: 'E.GRAMMAR.RELATIVE', name: 'Mệnh đề quan hệ', levelRange: [3, 6], prereq: ['E.GRAMMAR.TENSE'], traps: ['thiếu dấu phẩy ở mệnh đề không xác định'], norm: 150 },
  { code: 'E.GRAMMAR.REPORTED', name: 'Câu tường thuật', levelRange: [3, 6], prereq: ['E.GRAMMAR.TENSE'], traps: ['lùi thì máy móc khi sự việc còn đúng', 'quên đổi trạng từ chỉ thời gian'], norm: 165 },
  { code: 'E.READING.MAINIDEA', name: 'Đọc hiểu — ý chính và bố cục đoạn', levelRange: [2, 7], prereq: ['E.VOCAB.COLLOCATION'], traps: ['chọn chi tiết phụ làm ý chính'], norm: 200 },
  { code: 'E.READING.INFERENCE', name: 'Đọc hiểu — câu hỏi suy luận', levelRange: [4, 9], prereq: ['E.READING.MAINIDEA'], traps: ['chọn đáp án đúng nhưng không được nêu trong bài'], norm: 240 },
  { code: 'E.LISTENING.DETAIL', name: 'Nghe lấy thông tin chi tiết', levelRange: [2, 8], prereq: [], traps: ['bẫy đổi thông tin phút chót'], norm: 180 },
  { code: 'E.WRITING.TASK1', name: 'Viết mô tả số liệu (IELTS Task 1)', levelRange: [4, 8], prereq: ['E.GRAMMAR.PASSIVE'], traps: ['liệt kê hết số liệu thay vì chọn nét nổi bật', 'thiếu câu tổng quan'], norm: 1200 },
  { code: 'E.WRITING.TASK2', name: 'Viết luận học thuật (IELTS Task 2 / SAT essay)', levelRange: [5, 9], prereq: ['E.GRAMMAR.CONDITIONAL', 'E.WRITING.TASK1'], traps: ['lạc đề', 'thiếu ví dụ cụ thể'], norm: 2400 },
  { code: 'E.SPEAKING.PART2', name: 'Nói theo chủ đề có chuẩn bị (IELTS Part 2)', levelRange: [4, 8], prereq: ['E.VOCAB.COLLOCATION'], traps: ['học thuộc lòng làm mất tự nhiên', 'lạc sang ý khác của đề'], norm: 300 },

  // ══════════════════════ TƯ DUY / ĐGNL ══════════════════════════════════════
  { code: 'X.LOGIC.SUYLUAN', name: 'Suy luận logic nhiều bước', levelRange: [3, 9], prereq: [], traps: ['đảo ngược mệnh đề kéo theo', 'kết luận khi chưa đối chiếu hết dữ kiện', 'dừng ở trường hợp đầu tiên thấy hợp lý'], norm: 180 },
  { code: 'X.LOGIC.DAYSO', name: 'Nhận diện quy luật dãy số', levelRange: [2, 9], prereq: [], traps: ['dừng ở quy luật bậc nhất khi thực tế là bậc hai', 'chốt quy luật khi mới thử một cặp số', 'tìm một quy luật chung cho dãy đan xen hai quy luật'], norm: 150 },
  { code: 'X.LOGIC.SAPXEP', name: 'Bài toán sắp xếp, ghép cặp theo điều kiện', levelRange: [3, 9], prereq: ['X.LOGIC.SUYLUAN'], traps: ['bỏ sót một phương án thoả mãn', 'coi điều kiện cần là điều kiện đủ', 'gán giá trị theo thứ tự tên nhắc trong đề', 'đếm trùng các cách xếp đối xứng nhau'], norm: 270 },
  { code: 'X.SOLIEU.BIEUDO', name: 'Đọc và xử lý biểu đồ, bảng số liệu', levelRange: [2, 7], prereq: ['M6.THONGKE.BANG'], traps: ['nhầm phần trăm tương đối và tuyệt đối'], norm: 210 },
  { code: 'X.KHTN.CONGTHUC', name: 'Vận dụng công thức Lý – Hoá – Sinh', levelRange: [2, 7], prereq: [], traps: ['sai đơn vị chuẩn SI'], norm: 180 },
  { code: 'X.DOCHIEU.KHOAHOC', name: 'Đọc hiểu văn bản khoa học và rút kết luận', levelRange: [4, 9], prereq: ['X.SOLIEU.BIEUDO'], traps: ['suy diễn vượt quá dữ liệu bài cho', 'đọc nhầm dòng hoặc nhầm cột của bảng số liệu', 'lấy giá trị sau làm mẫu số khi tính phần trăm thay đổi', 'so sánh hai số liệu khác đơn vị mà không quy đổi', 'coi tương quan giữa hai số liệu là quan hệ nhân quả'], norm: 300 },
];

module.exports = FORMS;
