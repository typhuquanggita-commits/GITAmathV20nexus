'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SỔ MÀN HÌNH — đọc từ chính mã giao diện, không khai tay
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Mỗi màn hình cần ba thứ để dựng được một video hướng dẫn đúng:
 *      · màn này để làm gì
 *      · vai nào mở được
 *      · nó gọi những cổng API nào
 *
 *  Thứ nhất phải viết tay — không máy nào đọc được ý định của một trang. Hai
 *  thứ sau thì TUYỆT ĐỐI không viết tay, mà QUÉT từ mã đang chạy.
 *
 *  Lý do rất cụ thể: bảng quyền viết tay lệch khỏi mã ngay lần sửa đầu tiên,
 *  và lúc ấy video hướng dẫn sẽ dạy người xem một điều SAI về quyền của chính
 *  họ. Một video dạy sai còn tệ hơn không có video — người xem tin nó.
 *
 *  Nên: quét tệp giao diện tìm mọi lượt gọi API, tra từng cổng qua đúng bảng
 *  cổng quyền của hệ, rồi lấy mức CAO NHẤT. Màn hình nào gọi một cổng quản
 *  trị thì nó là màn quản trị, dù người viết nghĩ gì.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');

const THU_MUC_UI = path.join(__dirname, '..', '..', 'ui');

/**
 * Màn này để làm gì — phần DUY NHẤT viết tay, vì không máy nào đọc được.
 * Mô tả phải nói việc người dùng làm, không nói tính năng hệ thống có.
 */
const VIEC_CUA_MAN = {
  'cong.html': {
    ten: 'Cổng vào',
    de: 'Chọn nơi cần vào. Mỗi cánh cửa là một nhóm việc khác nhau.',
    viec: ['Chọn đúng khu mình cần', 'Xem hệ thống đang chạy bản nào'],
  },
  'hoc-vien.html': {
    ten: 'Góc học tập',
    de: 'Nơi học viên làm bài, xem lộ trình và theo dõi tiến bộ của chính mình.',
    viec: ['Làm bài luyện tập', 'Xem mình đang ở tầng nào', 'Xem dạng nào còn hổng'],
  },
  'giao-vien.html': {
    ten: 'Phòng giáo viên',
    de: 'Nơi giáo viên xem lớp mình dạy, từng học viên, và duyệt học liệu.',
    viec: ['Mở lớp phụ trách', 'Xem học viên cần chú ý', 'Giao bài', 'Duyệt học liệu'],
  },
  'hanh-trinh.html': {
    ten: 'Hành trình của tôi',
    de: 'Tầng đang ở, chặng của chu kỳ chín mươi ngày, và buổi học hôm nay.',
    viec: ['Xem chặng hiện tại', 'Mở buổi học hôm nay', 'Đọc tổng kết đo bằng số liệu thật'],
  },
  'bai-giang.html': {
    ten: 'Xưởng bài giảng',
    de: 'Gõ một chủ đề, nhận về một tệp video có hình có tiếng.',
    viec: ['Soạn dàn ý từ kho đã thẩm định', 'Chọn giọng đọc', 'Dựng video và tải về'],
  },
  'khoa-hoc-toan.html': {
    ten: 'Bàn làm việc Toán',
    de: 'Giải và trình bày chuẩn sách giáo khoa, thẩm định bốn cấp.',
    viec: ['Nhập đề bài', 'Xem lời giải trình bày chuẩn', 'Biên tập phiếu học tập'],
  },
  'tieng-viet.html': {
    ten: 'Bàn soát tiếng Việt',
    de: 'Soát học liệu bốn cấp: chính tả, văn phong, độ đọc, từ vựng theo lớp.',
    viec: ['Dán đoạn cần soát', 'Đọc lỗi theo từng cấp', 'Sửa theo gợi ý'],
  },
  'so-do-3d.html': {
    ten: 'Sơ đồ tư duy ba chiều',
    de: 'Cả chương trình trải trong không gian ba chiều, xoay được bằng chuột.',
    viec: ['Kéo chuột để xoay', 'Dò đường "muốn học cái này cần biết gì trước"',
      'Ôn quanh một dạng', 'Tải hình về để in'],
  },
  'tro-chuyen.html': {
    ten: 'Hỏi trợ lý',
    de: 'Khung hỏi đáp đọc dữ liệu thật. Mỗi câu trả lời hiện rõ đã tra những nguồn nào.',
    viec: ['Gõ câu hỏi', 'Đọc phần vết dưới mỗi câu trả lời',
      'Báo trục trặc để hệ thống ghi thành phiếu'],
  },
  'index.html': {
    ten: 'Trung tâm chỉ huy',
    de: 'Nơi Super Admin điều phối trợ lý AI chuyên môn, bảo mật, khôi phục.',
    viec: ['Xem toàn cảnh hệ thống', 'Tổng động viên', 'Chụp ảnh hệ thống', 'Xem nhật ký'],
  },
};

const TEN_MUC = {
  'cong-khai': 'ai cũng xem được',
  'hoc-vien': 'cần đăng nhập học viên',
  'giao-vien': 'cần tài khoản giáo viên',
  'quan-tri': 'chỉ quản trị',
};
const THU_BAC_MUC = { 'cong-khai': 0, 'hoc-vien': 1, 'giao-vien': 2, 'quan-tri': 3 };

/**
 * Gom mã của một màn: tệp HTML CỘNG mọi tệp kịch bản nó thật sự nạp.
 *
 * Bản đầu đoán tên tệp kèm bằng cách đổi đuôi .html thành .js. Cách đoán ấy
 * sai ở hai màn có thật: trung tâm chỉ huy nạp ui/app.js, còn cổng vào không
 * có tệp kèm nào. Hệ quả là bộ quét đọc ra KHÔNG cổng API nào cho một màn gọi
 * hàng chục cổng — và mức quyền của màn ấy bị hạ xuống "ai cũng xem được".
 *
 * Một video hướng dẫn dạy sai về quyền còn tệ hơn không có video. Nên đọc
 * thẳng thẻ <script src> chứ không đoán.
 */
function gomMa(tep) {
  const duong = path.join(THU_MUC_UI, tep);
  if (!fs.existsSync(duong)) return { chu: '', kem: [], thieu: [] };
  const html = fs.readFileSync(duong, 'utf8');
  const kem = [];
  const thieu = [];
  let chu = html;
  for (const m of html.matchAll(/<script[^>]+src="\/ui\/([^"]+)"/g)) {
    const f = path.join(THU_MUC_UI, m[1]);
    if (fs.existsSync(f)) { kem.push(m[1]); chu += `\n${fs.readFileSync(f, 'utf8')}`; }
    else thieu.push(m[1]);
  }
  return { chu, kem, thieu };
}

/**
 * Bỏ phần chú thích trước khi quét.
 *
 * Bộ quét bản đầu đọc cả chú thích, nên ví dụ minh hoạ `api('/duong/dan')`
 * nằm trong phần mô tả của hạ tầng giao diện chung bị đếm như một lượt gọi
 * thật — và nó xuất hiện ở MỌI màn, vì màn nào cũng nạp tệp chung ấy. Tám
 * màn cùng báo một lỗi giống hệt nhau là dấu hiệu lỗi nằm ở bộ quét.
 */
function boChuThich(chu) {
  return String(chu)
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/(^|[^:'"`\\])\/\/[^\n]*/g, '$1');
}

/**
 * Quét một tệp tìm mọi lượt gọi API, KÈM PHƯƠNG THỨC.
 *
 * Phương thức không phải chi tiết vụn. Bảng cổng công khai của hệ này khai
 * theo cặp "PHƯƠNG THỨC + đường dẫn": `POST /accounts/login` là công khai,
 * còn nhóm ACCOUNTS nói chung ở mức quản trị. Bộ quét bản đầu bỏ qua phương
 * thức rồi lấy mức CAO NHẤT trong các cổng trùng đường dẫn — thế là cổng
 * đăng nhập công khai bị đọc thành cổng quản trị, và MỌI màn có thanh đăng
 * nhập đều bị gắn nhãn "chỉ quản trị".
 *
 * Hậu quả không nhỏ: video hướng dẫn sẽ nói với một học viên rằng màn sơ đồ
 * tư duy là màn quản trị, trong khi em ấy mở được.
 *
 * Quy ước của hạ tầng giao diện này (ui/common.js dòng 13): `api(path)` là
 * GET, `api(path, body)` là POST, và tham số thứ ba ghi đè cả hai.
 */
function quetGoiApi(chuThoWithComments) {
  const chu = boChuThich(chuThoWithComments);
  const ra = new Map();
  const them = (duongTho, phuongThuc) => {
    // Phần nội suy `${...}` là MỘT ĐOẠN đường dẫn dựng lúc chạy, nên đổi nó
    // thành dấu sao chứ không cắt bỏ đuôi. Bản đầu cắt tại ${ nên
    // `/learner/${id}/portrait` teo lại thành `/learner/` — mất hẳn phần
    // đuôi, và cổng ấy thành "không tra được" dù mã giao diện viết đúng.
    const d = duongTho.replace(/\$\{[^}]*\}/g, '*').split('?')[0].trim();
    if (!d.startsWith('/') || d.startsWith('/ui/') || d.length <= 1) return;
    const cu = ra.get(d) || new Set();
    cu.add(phuongThuc);
    ra.set(d, cu);
  };

  // api('/x') · api('/x', body) · api('/x', body, 'DELETE') · G.api(...)
  for (const m of chu.matchAll(/\b(?:G\.)?api\(\s*[`'"]([^`'"]+)[`'"]\s*(,\s*([^)]*))?\)/g)) {
    const sauDauPhay = (m[3] || '').trim();
    const ghiDe = sauDauPhay.match(/['"](GET|POST|PUT|PATCH|DELETE)['"]\s*$/i);
    if (ghiDe) them(m[1], ghiDe[1].toUpperCase());
    else them(m[1], m[2] ? 'POST' : 'GET');
  }
  // fetch('/x', {method:'POST'})
  for (const m of chu.matchAll(/\bfetch\(\s*[`'"]([^`'"]+)[`'"]\s*(?:,\s*\{([^}]*)\})?/g)) {
    const pt = (m[2] || '').match(/method\s*:\s*['"](\w+)['"]/i);
    them(m[1], pt ? pt[1].toUpperCase() : 'GET');
  }
  // <img src="/x?..."> gọi thẳng một cổng — luôn là GET
  for (const m of chu.matchAll(/src="(\/[a-z0-9\-/.]+)\?/gi)) them(m[1], 'GET');

  return [...ra.entries()].map(([duong, pt]) => ({ duong, phuongThuc: [...pt].sort() }));
}

/** Tra một lượt gọi (đường dẫn + phương thức) qua bảng cổng quyền thật. */
function mucCuaGoi({ duong, phuongThuc }, routes, cq) {
  let cao = null;
  // Cả hai bên đều có chỗ thay được: cổng khai `:id`, lượt gọi khai `*`.
  // Quy cả hai về cùng một dấu rồi so — không bên nào phải đoán bên kia.
  const chuan = (x) => x.replace(/:[A-Za-z0-9_]+/g, '\u0001').replace(/\*/g, '\u0001');
  const goiChuan = chuan(duong).replace(/\/$/, '/\u0001');
  // Phần nội suy ở CUỐI mà không đứng sau dấu gạch chéo thường là chuỗi truy
  // vấn nối vào, chứ không phải một đoạn đường dẫn: api(`/org/classes${q}`)
  // với q = "?limit=50". Nên thử luôn bản đã bỏ đuôi ấy.
  const goiKhongDuoi = /[^/]\u0001$/.test(goiChuan) ? goiChuan.replace(/\u0001$/, '') : null;
  for (const r of routes) {
    if (!phuongThuc.includes(r.method)) continue;
    const rc = chuan(r.pattern);
    const khop = rc === goiChuan || (goiKhongDuoi != null && rc === goiKhongDuoi);
    if (khop) {
      const m = cq.mucCua(r);
      if (cao == null || THU_BAC_MUC[m] > THU_BAC_MUC[cao]) cao = m;
    }
  }
  return cao;
}

/**
 * Dựng sổ màn hình.
 *
 * @param {object} N hệ đang chạy — cần để lấy bảng cổng thật
 */
function dungSo(N) {
  const cq = require('../api/cong-quyen');
  const { routes } = require('../api/router')(N);

  const ra = [];
  for (const [tep, v] of Object.entries(VIEC_CUA_MAN)) {
    if (!fs.existsSync(path.join(THU_MUC_UI, tep))) continue;
    const { chu, kem, thieu } = gomMa(tep);
    const goi = quetGoiApi(chu);
    const theoMuc = goi.map((g) => ({ ...g, muc: mucCuaGoi(g, routes, cq) }));
    const biet = theoMuc.filter((x) => x.muc);
    let mucCao = 'cong-khai';
    for (const x of biet) if (THU_BAC_MUC[x.muc] > THU_BAC_MUC[mucCao]) mucCao = x.muc;

    ra.push({
      tep, ...v,
      duong: `/ui/${tep}`,
      tepKem: kem, tepKemThieu: thieu,
      mucQuyen: mucCao,
      quyenDocDuoc: TEN_MUC[mucCao],
      soCongGoi: goi.length,
      congKhongTraDuoc: theoMuc.filter((x) => !x.muc).map((x) => `${x.phuongThuc.join('/')} ${x.duong}`),
      congTheoMuc: Object.fromEntries(
        Object.keys(THU_BAC_MUC).map((m) => [m, biet.filter((x) => x.muc === m).length]).filter(([, n]) => n),
      ),
    });
  }
  return ra;
}

/** Soi sổ: bắt đúng chỗ một sổ màn hình hỏng lặng lẽ. */
function soi(N) {
  const so = dungSo(N);
  const loi = [];
  if (so.length !== Object.keys(VIEC_CUA_MAN).length) {
    loi.push(`khai ${Object.keys(VIEC_CUA_MAN).length} màn mà chỉ tìm thấy ${so.length} tệp`);
  }
  for (const m of so) {
    if (!m.de || m.de.length < 20) loi.push(`màn ${m.tep} mô tả quá ngắn`);
    if (!m.viec.length) loi.push(`màn ${m.tep} không khai việc nào người dùng làm`);
    // Cổng gọi mà không tra được là chỗ mù: hoặc đường dẫn viết sai trong
    // giao diện, hoặc bảng cổng thiếu. Cả hai đều phải sửa, không bỏ qua.
    if (m.congKhongTraDuoc.length) {
      loi.push(`màn ${m.tep} gọi ${m.congKhongTraDuoc.length} đường không tra được: ${m.congKhongTraDuoc.slice(0, 3).join(', ')}`);
    }
    if (m.tepKemThieu.length) {
      loi.push(`màn ${m.tep} nạp tệp không có: ${m.tepKemThieu.join(', ')}`);
    }
    // ── Mục canh bộ quét, không canh màn hình ──
    //
    // Một màn có chữ "api(" trong mã mà bộ quét đọc ra KHÔNG cổng nào thì
    // hỏng là bộ quét, không phải màn. Bản đầu hỏng đúng kiểu ấy và im lặng:
    // màn đọc ra 0 cổng, mức quyền tụt xuống công khai, và mọi thứ vẫn xanh.
    if (/\bapi\(/.test(gomMa(m.tep).chu) && m.soCongGoi === 0) {
      loi.push(`màn ${m.tep} có lượt gọi API trong mã mà bộ quét đọc ra 0 — hỏng ở bộ quét`);
    }
  }
  // Mọi tệp giao diện có thật đều phải được khai — thêm trang mà quên khai thì
  // trang ấy không có video hướng dẫn, và không ai phát hiện ra.
  for (const f of fs.readdirSync(THU_MUC_UI)) {
    if (f.endsWith('.html') && !VIEC_CUA_MAN[f]) loi.push(`có tệp ui/${f} mà sổ màn hình chưa khai`);
  }
  return { dat: loi.length === 0, loi, soMan: so.length };
}

module.exports = { dungSo, soi, gomMa, boChuThich, mucCuaGoi, VIEC_CUA_MAN, TEN_MUC, THU_BAC_MUC, quetGoiApi };
