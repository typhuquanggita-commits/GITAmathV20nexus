'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  XƯỞNG VIDEO HƯỚNG DẪN — dựng bằng chính bộ máy tiếng nói của hệ này
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Xưởng này KHÔNG viết lại một bộ dựng video mới. Hệ đã có sẵn đúng hai thứ
 *  cần dùng, cả hai đã chạy thật và đã có bộ kiểm riêng:
 *
 *      src/voice/    tổng hợp tiếng Việt: âm vị học, đọc số, đọc toán,
 *                    500 hồ sơ giọng, hậu kỳ phòng thu bằng JavaScript
 *      src/nexus/    dựng khung hình và ghi thẳng tệp AVI (MJPEG + PCM),
 *                    không cần ffmpeg, không gọi dịch vụ ngoài
 *
 *  Nên việc của xưởng này chỉ là: soạn kịch bản đúng vai → đưa vào đường ống
 *  sẵn có → nhận về tệp video. Viết lại cái đã có là cách chắc chắn nhất để
 *  có hai bộ dựng lệch nhau.
 *
 *  ── "GIỌNG CHUẨN CHẤT LƯỢNG" NGHĨA LÀ GÌ Ở ĐÂY ──────────────────────────
 *
 *  Nói rõ, vì hai chữ "chất lượng" dễ hiểu thành hai thứ khác hẳn nhau:
 *
 *  ĐƯỢC:  giọng tổng hợp tại máy, đọc đúng âm tiết tiếng Việt, đúng thanh
 *         điệu, đọc được số và ký hiệu toán, qua hậu kỳ phòng thu (nén, lọc
 *         xì, cân âm lượng theo chuẩn BS.1770). Chạy không cần mạng, không
 *         cần khoá, chi phí bằng không, và TẤT ĐỊNH — cùng kịch bản ra cùng
 *         tệp âm thanh.
 *
 *  KHÔNG ĐƯỢC:  giọng người thật thu phòng. Không mô hình sinh giọng nào ở
 *         đây bằng được một phát thanh viên. Đó là giới hạn có thật và nói
 *         thẳng ra, chứ không gọi tránh đi.
 *
 *  Nên xưởng để sẵn một đường THAY GIỌNG: ai có bản thu người thật thì nạp
 *  vào đúng chương, video dùng bản thu ấy; chương nào chưa có thì dùng giọng
 *  máy. Không phải chọn một trong hai.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');

const manHinh = require('./man-hinh');
const kichBan = require('./kich-ban');

/** Giọng mặc định theo vai người xem. */
const GIONG_THEO_VAI = {
  LEARNER: { gioiTinh: 'nu', moTa: 'giọng nữ ấm, nhịp chậm — nói với trẻ' },
  PARENT: { gioiTinh: 'nu', moTa: 'giọng nữ rõ ràng, nhịp vừa' },
  TEACHER: { gioiTinh: 'nam', moTa: 'giọng nam điềm, nhịp vừa' },
  ADMIN: { gioiTinh: 'nam', moTa: 'giọng nam gọn, nhịp nhanh hơn' },
};

class XuongVideo {
  /**
   * @param {object} o
   * @param {object} o.N hệ đang chạy — cần baiGiang và voice
   */
  constructor({ N, thuMucRa = null } = {}) {
    this.N = N;
    this.thuMucRa = thuMucRa || process.env.VIDEO_HD_DIR
      || path.join(process.env.LESSON_OUT_DIR || path.join(__dirname, '..', '..', 'data'), 'video-huong-dan');
    this.daDung = new Map();
    this.banThuNguoi = new Map();   // "man|vai|chuong" → đường dẫn tệp tiếng
    this.thongKe = { dung: 0, msTong: 0, giayTieng: 0 };
  }

  /** Danh mục: mọi cặp màn × vai, kèm kịch bản đã soạn. */
  danhMuc() {
    const ds = manHinh.dungSo(this.N);
    const b = kichBan.soanBo(ds);
    return {
      ok: b.ok,
      soMan: ds.length,
      soVai: Object.keys(kichBan.VAI).length,
      soVideo: b.soVideo,
      hong: b.hong,
      muc: b.kichBan.map((k) => ({
        ma: `${k.man.replace(/\.html$/, '')}--${k.vai}`,
        man: k.man, ten: k.ten, vai: k.vai, tenVai: k.tenVai,
        duQuyen: k.duQuyen, mucQuyenMan: k.mucQuyenMan,
        soChuong: k.tomTat.soChuong, soTu: k.tomTat.soTu, giayUocTinh: k.tomTat.giayUocTinh,
        daDung: this.daDung.has(`${k.man}|${k.vai}`),
      })),
    };
  }

  layKichBan(manTep, vai) {
    const ds = manHinh.dungSo(this.N);
    const man = ds.find((m) => m.tep === manTep);
    if (!man) return { ok: false, loi: 'KHONG_CO_MAN', manTep };
    return kichBan.soan(man, vai);
  }

  /**
   * Dựng một video.
   *
   * Đi qua đúng đường ống bài giảng đã có: soạn dàn ý từ kịch bản → dựng.
   */
  async dung(manTep, vai, { kho = 'hd', giongId = null } = {}) {
    if (!this.N.baiGiang) return { ok: false, loi: 'CHUA_CO_XUONG_BAI_GIANG' };
    const k = this.layKichBan(manTep, vai);
    if (!k.ok) return k;

    const t0 = Date.now();
    const dan = this.N.baiGiang.soanTuKichBan(k.loiDoc, {
      tieuDe: `${k.ten} — hướng dẫn cho ${k.tenVai}`,
    });
    if (!dan.ok) return { ok: false, loi: 'SOAN_DAN_Y_HONG', chiTiet: dan };

    const bg = await this.N.baiGiang.dung(dan, { kho, giongId });
    if (!bg.ok) return { ok: false, loi: 'DUNG_VIDEO_HONG', chiTiet: bg };

    const ban = {
      ma: `${manTep.replace(/\.html$/, '')}--${vai}`,
      man: manTep, vai, ten: k.ten, tenVai: k.tenVai,
      duQuyen: k.duQuyen, mucQuyenMan: k.mucQuyenMan,
      soChuong: k.chuong.length,
      giay: bg.giay, soKhung: bg.soKhung, rong: bg.rong, cao: bg.cao, byte: bg.byte,
      taiVe: bg.taiVe, baiGiangId: bg.id,
      mocThoiGian: bg.mocThoiGian,
      giongMay: true,
      banThuNguoi: this.soBanThuNguoi(manTep, vai),
      dungLuc: new Date().toISOString(), ms: Date.now() - t0,
    };
    this.daDung.set(`${manTep}|${vai}`, ban);
    this.thongKe.dung += 1;
    this.thongKe.msTong += ban.ms;
    this.thongKe.giayTieng += bg.giay || 0;
    return { ok: true, ...ban };
  }

  /**
   * Nạp một bản thu người thật cho MỘT chương.
   *
   * Không thay cả video — thay đúng chương ấy. Chương nào chưa có bản thu thì
   * vẫn dùng giọng máy, nên bộ video không bao giờ rơi vào cảnh "có một nửa".
   */
  napBanThu(manTep, vai, chuong, duongTep) {
    const k = this.layKichBan(manTep, vai);
    if (!k.ok) return k;
    const i = Number(chuong);
    if (!Number.isInteger(i) || i < 1 || i > k.chuong.length) {
      return { ok: false, loi: 'CHUONG_KHONG_CO', coChuong: k.chuong.length };
    }
    if (!fs.existsSync(duongTep)) return { ok: false, loi: 'KHONG_CO_TEP', duongTep };
    this.banThuNguoi.set(`${manTep}|${vai}|${i}`, duongTep);
    return { ok: true, man: manTep, vai, chuong: i, tep: path.basename(duongTep) };
  }

  soBanThuNguoi(manTep, vai) {
    let n = 0;
    for (const khoa of this.banThuNguoi.keys()) if (khoa.startsWith(`${manTep}|${vai}|`)) n += 1;
    return n;
  }

  /** Kịch bản dạng văn bản, để gửi cho phát thanh viên thu. */
  xuatKichBanChu(manTep, vai) {
    const k = this.layKichBan(manTep, vai);
    if (!k.ok) return k;
    const dong = [
      `KỊCH BẢN LỜI ĐỌC — ${k.ten} · hướng dẫn cho ${k.tenVai}`,
      `Giọng đề xuất: ${GIONG_THEO_VAI[vai].moTa}`,
      'Nhịp đọc: khoảng 150 từ mỗi phút. Nghỉ nửa giây giữa các câu.',
      `Tổng: ${k.tomTat.soChuong} chương · ${k.tomTat.soTu} từ · ước chừng ${k.tomTat.giayUocTinh} giây.`,
      '',
      '─'.repeat(60),
      '',
    ];
    for (const [i, c] of k.chuong.entries()) {
      dong.push(`[CHƯƠNG ${i + 1}] ${c.ten}`, '', c.loi, '');
    }
    return { ok: true, chu: dong.join('\n'), soChuong: k.chuong.length };
  }

  status() {
    const dm = this.danhMuc();
    return {
      soMan: dm.soMan, soVai: dm.soVai, soVideoCoThe: dm.soVideo,
      daDung: this.daDung.size,
      soBanThuNguoi: this.banThuNguoi.size,
      thuMucRa: this.thuMucRa,
      giongMay: {
        nguon: 'src/voice — tổng hợp tại máy, không gọi dịch vụ ngoài',
        tatDinh: true, chiPhi: 0, canMang: false,
        gioiHan: 'Không bằng được giọng phát thanh viên thu phòng. '
          + 'Ai có bản thu người thật thì nạp vào đúng chương, video dùng bản thu ấy.',
      },
      dinhDang: 'AVI (MJPEG + PCM) — mở bằng VLC, mpv hoặc Windows Media Player',
      thongKe: this.thongKe,
    };
  }
}

module.exports = XuongVideo;
module.exports.GIONG_THEO_VAI = GIONG_THEO_VAI;
