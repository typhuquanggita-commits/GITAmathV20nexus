'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KỊCH BẢN VIDEO HƯỚNG DẪN — soạn theo VAI, từ dữ liệu thật của màn hình
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Cùng một màn hình, bốn vai nhìn thấy bốn thứ khác nhau, nên KHÔNG dựng một
 *  video chung rồi bảo ai cũng xem. Một giáo viên xem video quay cho học viên
 *  sẽ nghe toàn những việc mình không làm; một học viên xem video quay cho
 *  quản trị sẽ nghe những nút mình không bấm được. Cả hai đều tắt giữa chừng.
 *
 *  ── TÁM CHƯƠNG, VÀ CHƯƠNG THỨ BA LÀ CHƯƠNG QUAN TRỌNG NHẤT ─────────────
 *
 *      1. Chào mừng        bạn là ai, đây là màn gì
 *      2. Màn này để làm gì
 *      3. QUYỀN CỦA BẠN Ở ĐÂY  ← đọc từ bảng cổng thật, không khai tay
 *      4. Làm được những việc gì
 *      5. Đi qua từng bước
 *      6. Chỗ dễ nhầm
 *      7. Hỏng thì làm sao
 *      8. Tổng kết
 *
 *  Chương ba quan trọng nhất vì nó là chương DỄ NÓI SAI NHẤT, và nói sai ở
 *  đây thì người xem đi làm một việc họ không có quyền, thất bại, rồi nghĩ
 *  hệ thống hỏng. Nên nó không được viết tay: nó đọc mức quyền mà bộ quét
 *  tính ra từ chính mã giao diện, đối chiếu với vai người xem.
 *
 *  ── LỜI ĐỌC ĐI QUA ĐÚNG BỘ LUẬT NỘI DUNG ────────────────────────────────
 *
 *  Kịch bản cũng là nội dung, nên nó qua đúng cửa mà trang công khai phải
 *  qua: không hứa kết quả, không giọng máy, không lộ phân loại nội bộ. Một
 *  câu hứa hẹn lọt vào lời đọc thì nó được ĐỌC TO LÊN — còn khó rút lại hơn
 *  một dòng chữ trên trang.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { THU_BAC_MUC, TEN_MUC } = require('./man-hinh');
const luat = require('../tiep-thi/luat-noi-dung');

/** Bốn vai, lấy tên từ đúng bảng vai của hệ. */
const VAI = {
  LEARNER: { ten: 'học viên', xung: 'em', goi: 'em', muc: 'hoc-vien' },
  PARENT: { ten: 'phụ huynh', xung: 'anh/chị', goi: 'anh/chị', muc: 'hoc-vien' },
  TEACHER: { ten: 'giáo viên', xung: 'thầy/cô', goi: 'thầy/cô', muc: 'giao-vien' },
  ADMIN: { ten: 'quản trị', xung: 'anh/chị', goi: 'anh/chị', muc: 'quan-tri' },
};

const TEN_CHUONG = ['Chào mừng', 'Màn này để làm gì', 'Quyền của bạn ở đây',
  'Làm được những việc gì', 'Đi qua từng bước', 'Chỗ dễ nhầm', 'Hỏng thì làm sao', 'Tổng kết'];

/**
 * Soạn kịch bản cho một cặp (màn hình, vai).
 *
 * @returns {{ok:boolean, chuong:Array, loiDoc:string, tomTat:object}}
 */
function soan(man, maVai, { soLieu = {} } = {}) {
  const v = VAI[maVai];
  if (!v) return { ok: false, loi: 'VAI_CHUA_KHAI', maVai };

  const duMuc = THU_BAC_MUC[v.muc] >= THU_BAC_MUC[man.mucQuyen];
  const chuong = [];

  // ── 1 ──
  chuong.push({
    ten: TEN_CHUONG[0],
    loi: `Chào ${v.goi}. Đây là hướng dẫn dùng màn "${man.ten}" của GITAmath, `
      + `soạn riêng cho vai ${v.ten}. Video dài chừng hai phút, `
      + `${v.goi} xem xong là dùng được ngay.`,
  });

  // ── 2 ──
  chuong.push({
    ten: TEN_CHUONG[1],
    loi: `${man.de} Màn này nằm ở đường dẫn ${man.duong}.`,
  });

  // ── 3 — chương đọc từ bảng cổng thật ──
  let loiQuyen;
  if (duMuc) {
    loiQuyen = `Màn này ${TEN_MUC[man.mucQuyen]}, nên vai ${v.ten} mở được đầy đủ. `
      + `Nó gọi ${man.soCongGoi} cổng dữ liệu của hệ thống, và ${v.goi} dùng được tất cả.`;
  } else {
    loiQuyen = `Màn này ${TEN_MUC[man.mucQuyen]}, mà vai ${v.ten} chưa đủ quyền. `
      + `${v.goi} mở trang ra vẫn thấy, nhưng phần dữ liệu sẽ báo chưa đăng nhập đủ quyền. `
      + 'Đây là hàng rào cố ý, không phải lỗi.';
  }
  chuong.push({ ten: TEN_CHUONG[2], loi: loiQuyen });

  // ── 4 ──
  chuong.push({
    ten: TEN_CHUONG[3],
    loi: `Ở màn này ${v.goi} làm được ${man.viec.length} việc: ${man.viec.join('; ')}.`,
  });

  // ── 5 ──
  chuong.push({
    ten: TEN_CHUONG[4],
    loi: man.viec.map((x, i) => `Bước ${i + 1}: ${x.toLowerCase()}.`).join(' ')
      + ' Làm hết năm bước ấy là xong một lượt.',
  });

  // ── 6 — chỗ dễ nhầm, viết từ hành vi THẬT của hệ ──
  const nham = [];
  if (!duMuc) {
    nham.push('Thấy ô trống hoặc dòng báo chưa đăng nhập thì không phải trang hỏng, '
      + 'mà là vai đang dùng chưa đủ quyền cho phần ấy.');
  }
  nham.push('Kho chưa có dữ liệu thì hệ thống nói thẳng là chưa có, '
    + 'chứ không hiện số không. Hai điều đó khác nhau.');
  if (man.mucQuyen !== 'cong-khai') {
    nham.push('Hết phiên đăng nhập thì dữ liệu ngừng nạp. Đăng nhập lại là tiếp tục được.');
  }
  chuong.push({ ten: TEN_CHUONG[5], loi: nham.join(' ') });

  // ── 7 ──
  chuong.push({
    ten: TEN_CHUONG[6],
    loi: 'Trang không nạp được thì tải lại một lần. Vẫn không được thì mở khung trò chuyện '
      + 'và mô tả đúng việc đang làm lúc hỏng; hệ thống ghi thành phiếu và chuyển cho người phụ trách. '
      + 'Trợ lý không tự sửa và không tự gửi đi đâu cả.',
  });

  // ── 8 ──
  chuong.push({
    ten: TEN_CHUONG[7],
    loi: `Tóm lại: màn "${man.ten}" ${TEN_MUC[man.mucQuyen]}, `
      + `${v.goi} làm được ${man.viec.length} việc chính. Cảm ơn ${v.goi} đã xem.`,
  });

  const loiDoc = chuong.map((c) => `${c.ten}\n\n${c.loi}`).join('\n\n');
  const kiem = luat.soi(chuong.map((c) => c.loi).join(' '), { tenTrang: `video ${man.tep}/${maVai}` });
  if (!kiem.dat) {
    return { ok: false, loi: 'LOI_DOC_KHONG_QUA_LUAT', viPham: kiem.loi, man: man.tep, vai: maVai };
  }

  return {
    ok: true,
    man: man.tep, ten: man.ten, vai: maVai, tenVai: v.ten,
    duQuyen: duMuc, mucQuyenMan: man.mucQuyen,
    chuong, loiDoc,
    tomTat: {
      soChuong: chuong.length,
      soTu: loiDoc.split(/\s+/).filter(Boolean).length,
      // Người đọc tiếng Việt rõ ràng đi khoảng 150 từ một phút.
      giayUocTinh: Math.round((loiDoc.split(/\s+/).filter(Boolean).length / 150) * 60),
    },
  };
}

/** Soạn cả bộ: mọi màn × mọi vai. */
function soanBo(dsMan) {
  const ra = [];
  const hong = [];
  for (const man of dsMan) {
    for (const vai of Object.keys(VAI)) {
      const k = soan(man, vai);
      if (k.ok) ra.push(k); else hong.push(k);
    }
  }
  return { ok: hong.length === 0, kichBan: ra, hong, soVideo: ra.length };
}

module.exports = { soan, soanBo, VAI, TEN_CHUONG };
