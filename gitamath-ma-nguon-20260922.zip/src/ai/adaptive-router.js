'use strict';
/**
 * Adaptive Router — Contextual Bandit với Thompson Sampling (Beta-Bernoulli).
 * reward = quality*w1 − cost*w2 − latency*w3 (V20 §2.2).
 * Trạng thái alpha/beta lưu trong Store nên sống sót qua restart khi chạy Redis.
 */

const cfg = require('../config');
const { round, clamp, viKey, seededRandom } = require('../utils');

const ARMS = [
  { id: 'groq-fast', provider: 'groq', tier: 'fast', cost: 0.1, quality: 0.6 },
  { id: 'groq-balanced', provider: 'groq', tier: 'balanced', cost: 0.3, quality: 0.8 },
  { id: 'cerebras-fast', provider: 'cerebras', tier: 'fast', cost: 0.1, quality: 0.65 },
  { id: 'google-fast', provider: 'google', tier: 'fast', cost: 0.2, quality: 0.8 },
  { id: 'google-strong', provider: 'google', tier: 'strong', cost: 0.5, quality: 0.95 },
  { id: 'nvidia-balanced', provider: 'nvidia', tier: 'balanced', cost: 0.2, quality: 0.85 },
  { id: 'openai-strong', provider: 'openai', tier: 'strong', cost: 1.0, quality: 1.0 },
  { id: 'anthropic-strong', provider: 'anthropic', tier: 'strong', cost: 1.0, quality: 1.0 },
];

class AdaptiveRouter {
  constructor({ store, llmRouter }) {
    this.store = store;
    this.llm = llmRouter;
    this.epsilon = cfg.ROUTER.epsilon;
    this.w = cfg.ROUTER.weights;
    this.stats = { routes: 0, explorations: 0, exploitations: 0, rewards: 0, totalReward: 0 };
    // Thăm dò (exploration) của bandit bắt buộc phải có yếu tố ngẫu nhiên, nhưng hệ thống
    // này KHÔNG dùng Math.random(): dùng mulberry32 có seed, nên cùng một seed thì chuỗi
    // quyết định lặp lại y hệt — kiểm định lại được, dựng lại được, không có may rủi ẩn.
    this.seed = process.env.ROUTER_SEED || 'gita-nexus-v20-router';
    this._rand = seededRandom(this.seed);
  }

  analyzeQuery(query) {
    const q = String(query);
    const k = viKey(q); // khớp được cả tiếng Việt có dấu lẫn không dấu
    const len = q.length;
    const words = q.split(/\s+/).filter(Boolean).length;
    const hasMath = /[+\-*/=<>∫∑√]/.test(q) || /\b(toan|phuong trinh|dinh ly|tich phan|dao ham|bat dang thuc|hinh hoc|dai so)\b/.test(k);
    const hasCode = /\b(function|class|api|code|bug|python|javascript|typescript|thuat toan|lap trinh)\b/.test(k);
    const hasCreative = /\b(viet|sang tao|story|tho|bai luan|kich ban)\b/.test(k);
    const ambiguous = /\b(maybe|perhaps|co le|khong chac)\b/.test(k) || /\?{2,}/.test(q);
    return {
      length: len,
      words,
      complexity: round(Math.min(1, len / 2000 + words / 200), 3),
      domain: hasMath ? 'math' : hasCode ? 'code' : hasCreative ? 'creative' : 'general',
      ambiguity: ambiguous ? 0.8 : 0.2,
      features: [len / 2000, words / 200, +hasMath, +hasCode, +hasCreative, +ambiguous],
    };
  }

  _normal() {
    let u = 0, v = 0;
    while (u === 0) u = this._rand();
    while (v === 0) v = this._rand();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  _gamma(shape) {
    if (shape < 1) return this._gamma(1 + shape) * Math.pow(this._rand(), 1 / shape);
    const d = shape - 1 / 3;
    const c = 1 / Math.sqrt(9 * d);
    // Marsaglia–Tsang; vòng lặp có chặn trên để không bao giờ treo.
    for (let guard = 0; guard < 1000; guard++) {
      let x, v;
      do { x = this._normal(); v = 1 + c * x; } while (v <= 0);
      v = v * v * v;
      const u = this._rand();
      if (u < 1 - 0.0331 * x * x * x * x) return d * v;
      if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
    }
    return d;
  }

  _betaSample(alpha, beta) {
    const g1 = this._gamma(alpha);
    const g2 = this._gamma(beta);
    return g1 / (g1 + g2 || 1);
  }

  /** Chỉ xét arm có provider khả dụng; nếu không có arm nào thì trả arm rẻ nhất để LLMRouter tự fallback. */
  _candidates() {
    const avail = new Set(this.llm ? this.llm.available() : []);
    const usable = ARMS.filter((a) => avail.has(a.provider));
    return usable.length ? usable : ARMS.slice(0, 1);
  }

  async selectArm() {
    this.stats.routes++;
    const arms = this._candidates();

    if (this._rand() < this.epsilon) {
      this.stats.explorations++;
      return arms[Math.floor(this._rand() * arms.length)];
    }

    const samples = [];
    for (const arm of arms) {
      const h = await this.store.hgetall(`bandit:${arm.id}`);
      const alpha = Math.max(1, parseInt(h.alpha || '1', 10));
      const beta = Math.max(1, parseInt(h.beta || '1', 10));
      samples.push({ arm, sample: this._betaSample(alpha, beta) });
    }
    samples.sort((a, b) => b.sample - a.sample);
    this.stats.exploitations++;
    return samples[0].arm;
  }

  async route(query) {
    const analysis = this.analyzeQuery(query);
    const arm = await this.selectArm();
    return { ok: true, arm, analysis, provider: arm.provider, tier: arm.tier };
  }

  /** Cập nhật hậu nghiệm. reward ∈ [0,1] sau khi chuẩn hoá. */
  async updateReward(armId, { quality = 0.8, cost = 0.2, latencyMs = 1000 } = {}) {
    const latencyPenalty = clamp(latencyMs / 30000, 0, 1);
    const raw = quality * this.w.quality - cost * this.w.cost - latencyPenalty * this.w.latency;
    const reward = clamp(raw / this.w.quality, 0, 1);

    const key = `bandit:${armId}`;
    // Gieo tiên nghiệm Beta(1,1) ở lần ghi đầu tiên để trials đếm đúng.
    const existing = await this.store.hgetall(key);
    if (!existing.alpha) await this.store.hset(key, 'alpha', 1);
    if (!existing.beta) await this.store.hset(key, 'beta', 1);
    if (reward > 0.5) await this.store.hincrby(key, 'alpha', 1);
    else await this.store.hincrby(key, 'beta', 1);

    this.stats.rewards++;
    this.stats.totalReward += reward;

    // Suy giảm để bandit không đóng băng — thích ứng khi nhà cung cấp đổi hiệu năng.
    const h = await this.store.hgetall(key);
    const total = parseInt(h.alpha || '1', 10) + parseInt(h.beta || '1', 10);
    if (total > cfg.ROUTER.decayAt) {
      await this.store.hset(key, 'alpha', Math.max(1, Math.floor(parseInt(h.alpha, 10) * 0.5)));
      await this.store.hset(key, 'beta', Math.max(1, Math.floor(parseInt(h.beta, 10) * 0.5)));
    }
    return { ok: true, armId, reward: round(reward) };
  }

  async armStats() {
    const out = [];
    for (const arm of ARMS) {
      const h = await this.store.hgetall(`bandit:${arm.id}`);
      const alpha = Math.max(1, parseInt(h.alpha || '1', 10));
      const beta = Math.max(1, parseInt(h.beta || '1', 10));
      out.push({
        id: arm.id, provider: arm.provider, tier: arm.tier,
        alpha, beta,
        posteriorMean: round(alpha / (alpha + beta), 3),
        trials: alpha + beta - 2,
      });
    }
    return out.sort((a, b) => b.posteriorMean - a.posteriorMean);
  }

  status() {
    return {
      ...this.stats,
      epsilon: this.epsilon,
      weights: this.w,
      arms: ARMS.length,
      candidates: this._candidates().length,
      avgReward: this.stats.rewards ? round(this.stats.totalReward / this.stats.rewards) : 0,
    };
  }
}

module.exports = AdaptiveRouter;
module.exports.ARMS = ARMS;
