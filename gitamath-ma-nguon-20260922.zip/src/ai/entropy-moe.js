'use strict';
/**
 * Entropy MoE — Adaptive-K theo entropy định tuyến (V20 §2.7).
 * H thấp (chắc chắn) → K=1, tiết kiệm ~87% compute. H cao → K=4, hợp nhất bằng judge.
 */

const { round, shortHash, viKey } = require('../utils');

/** Từ khoá viết ở dạng KHÔNG DẤU; truy vấn được chuẩn hoá bằng viKey() trước khi đối chiếu. */
const EXPERTS = {
  math: { name: 'Mathematician', keywords: ['toan', 'chung minh', 'dinh ly', 'phuong trinh', 'tich phan', 'dao ham'] },
  code: { name: 'Coder', keywords: ['code', 'function', 'bug', 'python', 'javascript', 'api', 'thuat toan'] },
  tutor: { name: 'Tutor', keywords: ['giai thich', 'day', 'hoc', 'hieu', 'vi du', 'huong dan'] },
  research: { name: 'Researcher', keywords: ['nghien cuu', 'phan tich', 'paper', 'khao sat', 'so sanh'] },
  business: { name: 'Strategist', keywords: ['chien luoc', 'business', 'market', 'doanh thu', 'kinh doanh'] },
  creative: { name: 'Creative', keywords: ['viet', 'sang tao', 'story', 'tho', 'kich ban'] },
  vietnamese: { name: 'VietnameseExpert', keywords: ['tieng viet', 'ngu phap', 'dich', 'chinh ta'] },
  analyst: { name: 'DataAnalyst', keywords: ['du lieu', 'thong ke', 'bieu do', 'chart', 'so lieu'] },
};

const K_THRESHOLDS = [
  { maxEntropy: 0.3, k: 1 },
  { maxEntropy: 0.5, k: 2 },
  { maxEntropy: 0.7, k: 3 },
  { maxEntropy: Infinity, k: 4 },
];

class EntropyMoE {
  constructor({ llmRouter, maxMemory = 1000 }) {
    this.llm = llmRouter;
    this.memory = new Map();
    this.maxMemory = maxMemory;
    this.stats = { routes: 0, expertCalls: 0, memoryHits: 0, sumK: 0, computeSavedPct: 0 };
  }

  routingDistribution(task) {
    const lower = viKey(task);
    const scores = {};
    for (const [id, e] of Object.entries(EXPERTS)) {
      let s = 0;
      for (const kw of e.keywords) if (lower.includes(kw)) s += 1;
      scores[id] = s + 0.1; // làm mượt, tránh chia 0
    }
    const total = Object.values(scores).reduce((a, b) => a + b, 0);
    const probs = {};
    for (const [k, v] of Object.entries(scores)) probs[k] = v / total;
    return probs;
  }

  /** Entropy chuẩn hoá về [0,1]. */
  entropy(probs) {
    let H = 0;
    for (const p of Object.values(probs)) if (p > 0) H -= p * Math.log2(p);
    const maxH = Math.log2(Object.keys(probs).length);
    return maxH > 0 ? H / maxH : 0;
  }

  selectK(entropy) {
    for (const t of K_THRESHOLDS) if (entropy < t.maxEntropy) return t.k;
    return 4;
  }

  async route(task, { forceK = null, mergeStrategy = 'judge' } = {}) {
    this.stats.routes++;
    const key = shortHash(String(task).slice(0, 200), 16);

    if (this.memory.has(key) && !forceK) {
      this.stats.memoryHits++;
      const m = this.memory.get(key);
      this.stats.sumK += m.k;
      // Hình dạng phản hồi phải giống hệt đường không cache: luôn có k và entropy.
      return this._run(task, m.ids, mergeStrategy, { entropy: m.entropy, k: m.k, cached: true });
    }

    const probs = this.routingDistribution(task);
    const H = this.entropy(probs);
    const k = forceK || this.selectK(H);
    const ids = Object.entries(probs).sort((a, b) => b[1] - a[1]).slice(0, k).map(([id]) => id);

    this.memory.set(key, { ids, k, entropy: round(H, 3) });
    if (this.memory.size > this.maxMemory) this.memory.delete(this.memory.keys().next().value);

    const maxK = Object.keys(EXPERTS).length;
    this.stats.sumK += k;
    this.stats.computeSavedPct = round(((maxK - this.stats.sumK / this.stats.routes) / maxK) * 100, 1);

    return this._run(task, ids, mergeStrategy, { entropy: round(H, 3), k, distribution: probs });
  }

  async _run(task, expertIds, mergeStrategy, meta) {
    const results = await Promise.all(expertIds.map(async (id) => {
      const e = EXPERTS[id];
      this.stats.expertCalls++;
      const r = await this.llm.call({
        task: 'complex_reasoning',
        prompt: task,
        system: `Bạn là ${e.name}. Trả lời chuyên sâu, chính xác, dùng LaTeX cho công thức.`,
        temperature: 0.5,
        maxTokens: 1200,
      });
      return { expertId: id, name: e.name, ok: r.ok, text: r.ok ? r.text : null, ms: r.ms, provider: r.provider };
    }));

    const valid = results.filter((r) => r.ok);
    if (!valid.length) return { ok: false, error: 'ALL_EXPERTS_FAILED', experts: expertIds };

    let output;
    if (valid.length === 1 || mergeStrategy === 'best') output = valid[0].text;
    else output = await this._judge(task, valid);

    return {
      ok: true,
      output,
      experts: valid.map((v) => ({ id: v.expertId, name: v.name, ms: v.ms, provider: v.provider })),
      ...meta,
    };
  }

  async _judge(task, results) {
    const prompt =
      `Tổng hợp câu trả lời từ ${results.length} chuyên gia thành MỘT câu trả lời tốt nhất.\n\n` +
      `## Yêu cầu\n${String(task).slice(0, 400)}\n\n` +
      results.map((r) => `### ${r.name}\n${String(r.text).slice(0, 800)}`).join('\n\n');
    const r = await this.llm.call({
      task: 'complex_reasoning', prompt,
      system: 'Chỉ trả về câu trả lời tổng hợp cuối cùng, không giải thích quá trình.',
      temperature: 0.3, maxTokens: 1600,
    });
    return r.ok ? r.text : results.map((x) => x.text).join('\n\n---\n\n');
  }

  listExperts() { return Object.entries(EXPERTS).map(([id, e]) => ({ id, ...e })); }

  status() {
    return {
      experts: Object.keys(EXPERTS).length,
      routes: this.stats.routes,
      expertCalls: this.stats.expertCalls,
      memoryHits: this.stats.memoryHits,
      memorySize: this.memory.size,
      avgK: this.stats.routes ? round(this.stats.sumK / this.stats.routes, 2) : 0,
      computeSavedPct: this.stats.computeSavedPct,
    };
  }
}

module.exports = EntropyMoE;
module.exports.EXPERTS = EXPERTS;
module.exports.K_THRESHOLDS = K_THRESHOLDS;
