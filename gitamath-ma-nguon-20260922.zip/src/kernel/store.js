'use strict';
/**
 * Store: lớp trừu tượng KV + Hash + Sorted-set nhẹ.
 * Không có REDIS_URL  → MemoryStore (đầy đủ chức năng, có TTL, có dọn rác).
 * Có REDIS_URL + ioredis → RedisStore.
 * Cùng một giao diện, phần còn lại của hệ thống không biết đang chạy trên cái nào.
 */

const cfg = require('../config');
const L = require('../logger');

class MemoryStore {
  constructor() {
    this.kind = 'memory';
    this.kv = new Map(); // key -> { v, exp }
    this.hash = new Map(); // key -> Map(field -> value)
    this._gc = setInterval(() => this._sweep(), 30_000);
    if (this._gc.unref) this._gc.unref();
  }

  _sweep() {
    const now = Date.now();
    for (const [k, e] of this.kv) if (e.exp && e.exp < now) this.kv.delete(k);
  }

  _alive(entry) {
    if (!entry) return false;
    if (entry.exp && entry.exp < Date.now()) return false;
    return true;
  }

  async get(key) {
    const e = this.kv.get(key);
    if (!this._alive(e)) { this.kv.delete(key); return null; }
    return e.v;
  }

  async set(key, value, ttlSec) {
    this.kv.set(key, { v: value, exp: ttlSec ? Date.now() + ttlSec * 1000 : 0 });
    return 'OK';
  }

  async del(key) { return this.kv.delete(key) ? 1 : 0; }

  async incrBy(key, n = 1) {
    const cur = Number((await this.get(key)) || 0) + n;
    await this.set(key, String(cur));
    return cur;
  }

  async hgetall(key) {
    const m = this.hash.get(key);
    return m ? Object.fromEntries(m) : {};
  }

  async hget(key, field) {
    const m = this.hash.get(key);
    return m ? (m.get(field) ?? null) : null;
  }

  async hset(key, field, value) {
    if (!this.hash.has(key)) this.hash.set(key, new Map());
    this.hash.get(key).set(field, String(value));
    return 1;
  }

  async hincrby(key, field, n = 1) {
    if (!this.hash.has(key)) this.hash.set(key, new Map());
    const m = this.hash.get(key);
    const cur = Number(m.get(field) || 0) + n;
    m.set(field, String(cur));
    return cur;
  }

  async keys(prefix) {
    const out = [];
    for (const [k, e] of this.kv) if (k.startsWith(prefix) && this._alive(e)) out.push(k);
    return out;
  }

  async ping() { return 'PONG'; }

  async close() { clearInterval(this._gc); }

  status() {
    return { kind: this.kind, keys: this.kv.size, hashes: this.hash.size };
  }
}

class RedisStore {
  constructor(client) {
    this.kind = 'redis';
    this.r = client;
  }
  async get(key) { return this.r.get(key); }
  async set(key, value, ttlSec) {
    return ttlSec ? this.r.set(key, value, 'EX', ttlSec) : this.r.set(key, value);
  }
  async del(key) { return this.r.del(key); }
  async incrBy(key, n = 1) { return this.r.incrby(key, n); }
  async hgetall(key) { return this.r.hgetall(key); }
  async hget(key, field) { return this.r.hget(key, field); }
  async hset(key, field, value) { return this.r.hset(key, field, value); }
  async hincrby(key, field, n = 1) { return this.r.hincrby(key, field, n); }
  async keys(prefix) { return this.r.keys(prefix + '*'); }
  async ping() { return this.r.ping(); }
  async close() { try { await this.r.quit(); } catch { /* đã đóng */ } }
  status() { return { kind: this.kind, url: cfg.REDIS_URL.replace(/:[^:@]*@/, ':***@') }; }
}

function createStore() {
  if (cfg.REDIS_URL) {
    try {
      // require động: ioredis là phụ thuộc tuỳ chọn.
      const IORedis = require('ioredis');
      const client = new IORedis(cfg.REDIS_URL, {
        maxRetriesPerRequest: null,
        enableReadyCheck: false,
        lazyConnect: false,
      });
      client.on('error', (e) => L.warn('Redis:', e.message));
      L.ok('Store: Redis');
      return new RedisStore(client);
    } catch (e) {
      L.warn(`Store: không nạp được ioredis (${e.message}) — chuyển sang in-memory`);
    }
  }
  L.ok('Store: in-memory (không cần hạ tầng ngoài)');
  return new MemoryStore();
}

module.exports = { createStore, MemoryStore, RedisStore };
