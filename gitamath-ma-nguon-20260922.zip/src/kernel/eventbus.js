'use strict';
/** EventBus an toàn: handler lỗi không làm sập hệ thống (khắc phục lỗi #1 báo cáo IRON). */

const { EventEmitter } = require('node:events');
const L = require('../logger');

class SafeEventBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(500);
    this.stats = { emitted: 0, delivered: 0, handlerErrors: 0, byEvent: Object.create(null) };
  }

  safeEmit(event, payload) {
    this.stats.emitted++;
    this.stats.byEvent[event] = (this.stats.byEvent[event] || 0) + 1;
    const handlers = this.listeners(event);
    for (const h of handlers) {
      try {
        h(payload);
        this.stats.delivered++;
      } catch (e) {
        this.stats.handlerErrors++;
        L.warn(`EventBus: handler lỗi trên "${event}"`, e.message);
      }
    }
    return handlers.length;
  }

  status() {
    const top = Object.entries(this.stats.byEvent)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15);
    return {
      emitted: this.stats.emitted,
      delivered: this.stats.delivered,
      handlerErrors: this.stats.handlerErrors,
      distinctEvents: Object.keys(this.stats.byEvent).length,
      topEvents: top,
    };
  }
}

module.exports = new SafeEventBus();
module.exports.SafeEventBus = SafeEventBus;
