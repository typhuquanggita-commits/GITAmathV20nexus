'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BÁO CÁO & PHÂN TÍCH
 * ═══════════════════════════════════════════════════════════════════════════
 *  Ba cấp báo cáo, mỗi cấp trả lời một câu hỏi khác nhau:
 *
 *   HỌC VIÊN  — em này đang ở đâu, tiến hay lùi, cần gì tiếp theo
 *   LỚP       — lớp phân hoá thế nào, ai tụt lại, dạng nào cả lớp cùng yếu
 *   HỆ THỐNG  — kho học liệu có đủ không, chỗ nào hổng, máy đang gánh nổi không
 *
 *  Nguyên tắc chung:
 *   · Mỗi con số đi kèm CỠ MẪU. Tỉ lệ 100% trên 2 bài không phải là 100%.
 *   · Mẫu nhỏ thì nói thẳng là chưa đủ căn cứ, không kết luận.
 *   · Mọi báo cáo xuất được ra CSV để mang đi họp.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round, percentile } = require('../utils');
const { LEVELS, FORM_INDEX, formsForLevel } = require('../curriculum/hierarchy');
const { toCSV } = require('../data/portability');
const { MASTERY_THRESHOLD } = require('../learner/mastery');

const MIN_SAMPLE = 10;   // dưới ngưỡng này thì mọi tỉ lệ đều kèm cảnh báo

class ReportService {
  constructor({
    profiles, mastery, telemetry, behavior, bank, seeder,
    org, classes, learners, attempts, exams, accounts, roadmap,
    kpi = null, capacity = null, agents = null,
  }) {
    Object.assign(this, {
      profiles, mastery, telemetry, behavior, bank, seeder,
      org, classes, learners, attempts, exams, accounts, roadmap, kpi, capacity, agents,
    });
    this.stats = { generated: 0, exported: 0 };
  }

  _note(n) {
    return n >= MIN_SAMPLE ? null
      : `Chỉ có ${n} lượt làm bài — các tỉ lệ dưới đây chưa đủ căn cứ để kết luận.`;
  }

  // ── 1. BÁO CÁO HỌC VIÊN ──────────────────────────────────────────────────

  learner(learnerId, { days = 30 } = {}) {
    const rec = this.profiles?.get(learnerId);
    if (!rec) return { ok: false, error: 'LEARNER_NOT_FOUND' };
    this.stats.generated++;

    const since = Date.now() - days * 86400000;
    const all = (this.telemetry?.attemptsOf(learnerId) || []).slice().sort((a, b) => (a.at || 0) - (b.at || 0));
    const window = all.filter((a) => (a.at || 0) >= since);
    const correct = window.filter((a) => a.correct).length;
    const mastMap = this.mastery?.map(learnerId) || {};

    // Theo dạng
    const byForm = {};
    for (const a of window) {
      const f = (byForm[a.formCode] ??= { formCode: a.formCode, name: FORM_INDEX.get(a.formCode)?.name || a.formCode, items: 0, correct: 0, hints: 0, msTotal: 0, msCount: 0 });
      f.items++;
      if (a.correct) f.correct++;
      f.hints += a.hintsUsed || 0;
      if (a.ms) { f.msTotal += a.ms; f.msCount++; }
    }
    const forms = Object.values(byForm).map((f) => ({
      ...f,
      accuracy: round(f.correct / f.items, 3),
      mastery: round(mastMap[f.formCode] ?? 0, 3),
      avgSeconds: f.msCount ? round(f.msTotal / f.msCount / 1000, 1) : null,
      mastered: (mastMap[f.formCode] ?? 0) >= MASTERY_THRESHOLD,
      enough: f.items >= 5,
    })).sort((a, b) => a.accuracy - b.accuracy);

    // Theo tuần, để thấy đường đi
    const weeks = [];
    for (let w = Math.ceil(days / 7) - 1; w >= 0; w--) {
      const from = Date.now() - (w + 1) * 7 * 86400000;
      const to = Date.now() - w * 7 * 86400000;
      const slice = all.filter((a) => (a.at || 0) >= from && (a.at || 0) < to);
      weeks.push({
        label: `Tuần -${w}`,
        items: slice.length,
        accuracy: slice.length ? round(slice.filter((a) => a.correct).length / slice.length, 3) : null,
      });
    }

    const behaviorReport = this.behavior?.fullReport(learnerId);
    const exams = (this.exams?.by?.('learnerId', learnerId) || [])
      .sort((a, b) => (b.at || 0) - (a.at || 0)).slice(0, 5)
      .map((e) => ({ at: new Date(e.at).toISOString(), kind: e.kind, level: e.level, passed: e.passed, score: e.score }));

    const rm = this.roadmap?.progress?.(learnerId);

    return {
      ok: true,
      kind: 'LEARNER',
      generatedAt: new Date().toISOString(),
      periodDays: days,
      learner: {
        id: learnerId,
        fullName: rec.fullName,
        grade: rec.grade,
        classId: rec.classId || null,
        level: rec.currentLevel ?? 0,
        levelName: LEVELS[rec.currentLevel ?? 0]?.name,
      },
      volume: {
        itemsInPeriod: window.length,
        itemsAllTime: all.length,
        activeDays: new Set(window.map((a) => new Date(a.at).toDateString())).size,
      },
      performance: {
        correct,
        accuracy: window.length ? round(correct / window.length, 3) : null,
        sampleSize: window.length,
        note: this._note(window.length),
        medianSpeedRatio: percentile(window.map((a) => a.speedRatio).filter((x) => x != null), 50),
        hintRate: window.length ? round(window.filter((a) => (a.hintsUsed || 0) > 0).length / window.length, 3) : null,
      },
      mastery: this.mastery?.summary(learnerId) || null,
      byForm: forms,
      weakest: forms.filter((f) => f.enough && f.accuracy < 0.6).slice(0, 5),
      strongest: forms.filter((f) => f.mastered).slice(-5).reverse(),
      trend: behaviorReport?.trend || null,
      behaviors: behaviorReport?.patterns || [],
      alerts: behaviorReport?.anomalies?.flags || [],
      recommendedActions: behaviorReport?.actions || [],
      weeklyVolume: weeks,
      recentExams: exams,
      roadmap: rm?.ok ? { week: rm.week, contentProgress: rm.contentProgress, onTrack: rm.onTrack } : null,
      summary: this._learnerSummary(rec, window, correct, forms, behaviorReport),
    };
  }

  _learnerSummary(rec, window, correct, forms, b) {
    if (!window.length) return `${rec.fullName} chưa làm bài nào trong kỳ báo cáo.`;
    const acc = correct / window.length;
    const parts = [
      `${rec.fullName} làm ${window.length} bài, đúng ${Math.round(acc * 100)}%`
      + (window.length < MIN_SAMPLE ? ' (cỡ mẫu còn nhỏ)' : '') + '.',
    ];
    const weak = forms.filter((f) => f.enough && f.accuracy < 0.6);
    if (weak.length) parts.push(`Yếu nhất ở: ${weak.slice(0, 3).map((f) => f.name).join('; ')}.`);
    const mastered = forms.filter((f) => f.mastered);
    if (mastered.length) parts.push(`Đã thạo ${mastered.length} dạng.`);
    if (b?.trend?.enough) parts.push(`Xu hướng ${b.trend.direction.toLowerCase()}.`);
    if (b?.anomalies?.flags?.length) parts.push(`Có ${b.anomalies.flags.length} dấu hiệu cần giáo viên xem lại.`);
    return parts.join(' ');
  }

  // ── 2. BÁO CÁO LỚP ───────────────────────────────────────────────────────

  classReport(classId, { days = 30 } = {}) {
    const cls = this.classes?.get(classId);
    if (!cls) return { ok: false, error: 'CLASS_NOT_FOUND' };
    this.stats.generated++;

    const ids = cls.learnerIds || [];
    const rows = ids.map((id) => {
      const r = this.learner(id, { days });
      if (!r.ok) return null;
      return {
        id,
        fullName: r.learner.fullName,
        level: r.learner.level,
        items: r.volume.itemsInPeriod,
        accuracy: r.performance.accuracy,
        mastered: r.mastery?.formsMastered ?? 0,
        trend: r.trend?.enough ? r.trend.direction : 'CHƯA ĐỦ DỮ LIỆU',
        alerts: r.alerts.length,
        activeDays: r.volume.activeDays,
      };
    }).filter(Boolean);

    const active = rows.filter((r) => r.items > 0);
    const withEnough = rows.filter((r) => r.items >= MIN_SAMPLE);
    const accs = withEnough.map((r) => r.accuracy).filter((x) => x != null).sort((a, b) => a - b);

    // Dạng cả lớp cùng yếu — đây là chỗ đáng dạy lại cho cả lớp.
    const formAgg = {};
    for (const id of ids) {
      for (const f of (this.learner(id, { days }).byForm || [])) {
        const g = (formAgg[f.formCode] ??= { formCode: f.formCode, name: f.name, items: 0, correct: 0, learners: 0 });
        g.items += f.items;
        g.correct += f.correct;
        g.learners++;
      }
    }
    const classWeak = Object.values(formAgg)
      .filter((g) => g.items >= MIN_SAMPLE && g.learners >= Math.max(2, Math.ceil(ids.length * 0.3)))
      .map((g) => ({ ...g, accuracy: round(g.correct / g.items, 3) }))
      .filter((g) => g.accuracy < 0.6)
      .sort((a, b) => a.accuracy - b.accuracy);

    const levels = rows.map((r) => r.level);
    const byLevel = levels.reduce((m, l) => { m[`L${l}`] = (m[`L${l}`] || 0) + 1; return m; }, {});

    return {
      ok: true,
      kind: 'CLASS',
      generatedAt: new Date().toISOString(),
      periodDays: days,
      class: {
        id: classId, name: cls.name, grade: cls.grade,
        size: ids.length, schoolYear: cls.schoolYear,
        teacherId: cls.teacherId,
      },
      participation: {
        active: active.length,
        inactive: ids.length - active.length,
        activeRate: ids.length ? round(active.length / ids.length, 3) : 0,
        inactiveLearners: rows.filter((r) => r.items === 0).map((r) => ({ id: r.id, fullName: r.fullName })),
      },
      performance: {
        measurable: withEnough.length,
        note: withEnough.length < ids.length
          ? `${ids.length - withEnough.length}/${ids.length} em chưa đủ ${MIN_SAMPLE} bài nên không tính vào các tỉ lệ dưới đây.`
          : null,
        median: accs.length ? round(percentile(accs, 50), 3) : null,
        p25: accs.length ? round(percentile(accs, 25), 3) : null,
        p75: accs.length ? round(percentile(accs, 75), 3) : null,
        spread: accs.length ? round(percentile(accs, 75) - percentile(accs, 25), 3) : null,
      },
      levelSpread: { byLevel, min: Math.min(...levels), max: Math.max(...levels) },
      needAttention: rows
        .filter((r) => r.alerts > 0 || r.trend === 'ĐANG XUỐNG' || (r.items >= MIN_SAMPLE && r.accuracy < 0.5) || r.items === 0)
        .sort((a, b) => (b.alerts - a.alerts) || ((a.accuracy ?? 1) - (b.accuracy ?? 1))),
      topPerformers: rows.filter((r) => r.items >= MIN_SAMPLE && r.accuracy >= 0.85).sort((a, b) => b.accuracy - a.accuracy).slice(0, 5),
      classWideWeakForms: classWeak.slice(0, 8),
      learners: rows.sort((a, b) => String(a.fullName).localeCompare(String(b.fullName), 'vi')),
      summary: this._classSummary(cls, rows, active, accs, classWeak),
    };
  }

  _classSummary(cls, rows, active, accs, classWeak) {
    const parts = [`Lớp ${cls.name} có ${rows.length} em, ${active.length} em có hoạt động trong kỳ.`];
    if (accs.length) {
      parts.push(`Trung vị độ chính xác ${Math.round(percentile(accs, 50) * 100)}%, `
        + `khoảng phân hoá ${Math.round((percentile(accs, 75) - percentile(accs, 25)) * 100)} điểm phần trăm.`);
    } else {
      parts.push('Chưa đủ dữ liệu để nói về độ chính xác của lớp.');
    }
    if (rows.length - active.length > 0) parts.push(`${rows.length - active.length} em chưa làm bài nào — cần liên hệ trước.`);
    if (classWeak.length) parts.push(`Cả lớp cùng yếu ở: ${classWeak.slice(0, 3).map((f) => f.name).join('; ')} — nên dạy lại chung.`);
    return parts.join(' ');
  }

  // ── 3. BÁO CÁO HỆ THỐNG ──────────────────────────────────────────────────

  system() {
    this.stats.generated++;
    const items = this.bank ? [...this.bank.items.values()] : [];
    const byStatus = {};
    const byLevel = {};
    const byStars = {};
    for (const it of items) {
      byStatus[it.status] = (byStatus[it.status] || 0) + 1;
      if (it.status !== 'PUBLISHED') continue;
      const [lo, hi] = it.servesLevels || [it.level, it.level];
      for (let l = lo; l <= hi; l++) byLevel[`L${l}`] = (byLevel[`L${l}`] || 0) + 1;
      byStars[`${it.stars}★`] = (byStars[`${it.stars}★`] || 0) + 1;
    }
    const cov = this.seeder?.coverage?.() || null;

    // Bài khó thật vs khó khai báo — hiệu chỉnh độ khó bằng dữ liệu thật.
    const calibration = items
      .filter((it) => (it.attempts || 0) >= 30)
      .map((it) => {
        const p = it.correct / it.attempts;
        const expected = { 1: 0.9, 2: 0.8, 3: 0.65, 4: 0.45, 5: 0.25 }[it.stars] ?? 0.6;
        return { id: it.id, formCode: it.formCode, stars: it.stars, attempts: it.attempts, pValue: round(p, 3), expected, drift: round(p - expected, 3) };
      })
      .filter((x) => Math.abs(x.drift) > 0.2)
      .sort((a, b) => Math.abs(b.drift) - Math.abs(a.drift));

    const learnerRows = this.learners ? this.learners.all() : [];
    const activeLearners = learnerRows.filter((l) => (this.telemetry?.attemptsOf(l.id) || []).length > 0);

    return {
      ok: true,
      kind: 'SYSTEM',
      generatedAt: new Date().toISOString(),
      content: {
        total: items.length,
        byStatus,
        publishedByLevel: byLevel,
        publishedByStars: byStars,
        coverage: cov,
        emptySlots: cov?.empty || [],
        thinSlots: cov?.thin || [],
        needsHumanReview: byStatus.REVIEWED || 0,
        calibrationDrift: calibration.slice(0, 20),
      },
      people: {
        users: this.accounts?.status?.().users ?? 0,
        byRole: this.accounts?.status?.().byRole ?? {},
        learners: learnerRows.length,
        activeLearners: activeLearners.length,
        classes: this.classes?.count?.() ?? 0,
        unassignedLearners: learnerRows.filter((l) => !l.classId).length,
      },
      usage: {
        totalAttempts: learnerRows.reduce((s, l) => s + (this.telemetry?.attemptsOf(l.id) || []).length, 0),
        exams: this.exams?.count?.() ?? 0,
        roadmaps: this.roadmap?.status?.().roadmaps ?? 0,
      },
      fleet: this.kpi ? this.kpi.system() : null,
      capacity: this.capacity ? this.capacity.status().global : null,
      findings: this._systemFindings(cov, byStatus, calibration, learnerRows, activeLearners),
    };
  }

  _systemFindings(cov, byStatus, calibration, learners, active) {
    const out = [];
    if (cov && cov.empty.length) {
      out.push({
        severity: 'cao',
        what: `${cov.empty.length} ô (dạng × tầng) chưa có bài nào`,
        detail: cov.empty.slice(0, 6).join(', '),
        action: 'Biên soạn thêm bản thiết kế cho các ô này — không được hạ chuẩn chống trùng để lấp.',
      });
    }
    if (cov && cov.thin.length) {
      out.push({
        severity: 'vừa',
        what: `${cov.thin.length} ô chỉ có 1–2 bài`,
        detail: cov.thin.slice(0, 6).map((t) => t.slot).join(', '),
        action: 'Học viên làm lại đúng vài bài sẽ thành học thuộc. Cần thêm bản thiết kế.',
      });
    }
    if ((byStatus.REVIEWED || 0) > 0) {
      out.push({
        severity: 'vừa',
        what: `${byStatus.REVIEWED} bài đang chờ người duyệt`,
        detail: 'Bài từ 4★ trở lên máy chỉ xác nhận được đáp số.',
        action: 'Giáo viên vào mục Học liệu để duyệt.',
      });
    }
    if (calibration.length) {
      out.push({
        severity: 'vừa',
        what: `${calibration.length} bài có độ khó thực tế lệch xa mức khai báo`,
        detail: calibration.slice(0, 3).map((c) => `${c.id} khai ${c.stars}★ nhưng ${Math.round(c.pValue * 100)}% làm đúng`).join('; '),
        action: 'Hiệu chỉnh lại bậc sao theo dữ liệu thật.',
      });
    }
    const idle = learners.length - active.length;
    if (idle > 0) {
      out.push({
        severity: idle > learners.length / 2 ? 'cao' : 'thấp',
        what: `${idle}/${learners.length} học viên chưa làm bài nào`,
        detail: '',
        action: 'Kiểm tra lại việc cấp tài khoản và nhắc lớp.',
      });
    }
    if (!out.length) out.push({ severity: 'thấp', what: 'Không có vấn đề nổi bật', detail: '', action: '' });
    return out;
  }

  // ── Xuất CSV ─────────────────────────────────────────────────────────────

  exportCSV(kind, id = null, opts = {}) {
    this.stats.exported++;
    if (kind === 'class') {
      const r = this.classReport(id, opts);
      if (!r.ok) return r;
      return {
        ok: true, filename: `bao-cao-lop-${id}.csv`,
        content: toCSV(r.learners.map((x) => ({
          ma: x.id, ho_ten: x.fullName, tang: `L${x.level}`,
          so_bai: x.items, ti_le_dung: x.accuracy == null ? '' : Math.round(x.accuracy * 100) + '%',
          dang_da_thao: x.mastered, xu_huong: x.trend, so_ngay_hoc: x.activeDays, canh_bao: x.alerts,
        })), ['ma', 'ho_ten', 'tang', 'so_bai', 'ti_le_dung', 'dang_da_thao', 'xu_huong', 'so_ngay_hoc', 'canh_bao']),
      };
    }
    if (kind === 'learner') {
      const r = this.learner(id, opts);
      if (!r.ok) return r;
      return {
        ok: true, filename: `bao-cao-hoc-vien-${id}.csv`,
        content: toCSV(r.byForm.map((f) => ({
          dang: f.formCode, ten_dang: f.name, so_bai: f.items, so_dung: f.correct,
          ti_le_dung: Math.round(f.accuracy * 100) + '%', muc_thao: Math.round(f.mastery * 100) + '%',
          giay_trung_binh: f.avgSeconds ?? '', da_thao: f.mastered ? 'có' : 'chưa',
        })), ['dang', 'ten_dang', 'so_bai', 'so_dung', 'ti_le_dung', 'muc_thao', 'giay_trung_binh', 'da_thao']),
      };
    }
    if (kind === 'system') {
      const r = this.system();
      return {
        ok: true, filename: 'bao-cao-he-thong.csv',
        content: toCSV(r.findings.map((f) => ({
          muc_do: f.severity, van_de: f.what, chi_tiet: f.detail, nen_lam: f.action,
        })), ['muc_do', 'van_de', 'chi_tiet', 'nen_lam']),
      };
    }
    return { ok: false, error: 'UNKNOWN_REPORT', kinds: ['learner', 'class', 'system'] };
  }

  status() { return { ...this.stats, minSample: MIN_SAMPLE }; }
}

module.exports = ReportService;
module.exports.MIN_SAMPLE = MIN_SAMPLE;
