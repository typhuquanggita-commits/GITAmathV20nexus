'use strict';
/** HTTP API — 24 nhóm endpoint theo thiết kế V20, định tuyến tường minh. */

const fs = require('node:fs');
const path = require('node:path');
const cfg = require('../config');
const { DIVISIONS, RANKS, ALLOCATION, validateTaxonomy } = require('../agents/taxonomy');
const { assignmentTable } = require('../agents/roster');
const { round } = require('../utils');

// Tệp video vừa dựng được giữ tạm ở đây để tải về ngay mà không phải đọc lại
// đĩa. Giới hạn 8 tệp: video bài giảng cỡ chục MB, giữ nhiều là ăn hết RAM.
const _videoCache = new Map();

function createRouter(N) {
  const routes = [];
  const add = (method, pattern, handler, group) => routes.push({ method, pattern, handler, group });

  // ═══ NHÓM 1 — CORE ═══════════════════════════════════════════════════
  add('GET', '/', () => ({
    name: 'GITAmath Nexus',
    version: cfg.VERSION,
    agents: N.agents.length,
    squads: N.squads.length,
    mode: N.llm.available().includes('mock') && N.llm.available().length === 1 ? 'MOCK' : 'LIVE',
    uptimeSec: Math.round(process.uptime()),
    endpoints: routes.length,
    groups: [...new Set(routes.map((r) => r.group))],
  }), 'CORE');

  // Bản sao của "/" nhưng KHÔNG bao giờ trả HTML — dùng cho máy gọi API và
  // cho lệnh kiểm tra sức khoẻ, khỏi phụ thuộc vào thoả thuận nội dung.
  add('GET', '/api', () => ({
    name: 'GITAmath Nexus',
    version: cfg.VERSION,
    agents: N.agents.length,
    squads: N.squads.length,
    endpoints: routes.length,
    groups: [...new Set(routes.map((r) => r.group))],
    trangCongKhai: cfg.WEB.bat ? '/' : null,
  }), 'CORE');

  add('GET', '/health', async () => {
    const kpi = N.kpi.system();
    const providers = N.llm.available();
    const checks = {
      store: (await N.store.ping().catch(() => null)) ? 'up' : 'down',
      llmProviders: providers.length > 0 ? 'up' : 'down',
      queue: N.queue.waiting < cfg.QUEUE.backlogAlert ? 'up' : 'degraded',
      agents: N.agents.length === cfg.AGENT_TOTAL ? 'up' : 'degraded',
      auditChain: N.audit.verify().ok ? 'up' : 'down',
      kpi: kpi.tasks === 0 ? 'idle' : kpi.successRate >= cfg.KPI.successRate ? 'up' : 'degraded',
    };
    const down = Object.values(checks).filter((v) => v === 'down').length;
    const degraded = Object.values(checks).filter((v) => v === 'degraded').length;
    return {
      status: down ? 'unhealthy' : degraded ? 'degraded' : 'healthy',
      version: cfg.VERSION,
      uptimeSec: Math.round(process.uptime()),
      checks,
      store: N.store.status(),
      llm: N.llm.status(),
      queue: N.queue.status(),
      agents: N.runtime.status(),
      capacity: N.capacity.status().global,
      kpi,
      governance: {
        constitution: N.constitution.status(),
        heart: N.heart.status(),
        guardrails: N.guardrails.status(),
        safePrompt: N.safePrompt.status(),
        auditChain: N.audit.status(),
      },
      cache: N.cache.status().total,
      memoryMB: round(process.memoryUsage().heapUsed / 1048576, 1),
    };
  }, 'CORE');

  add('POST', '/chat', async (req, body) => {
    const input = body.input ?? body.prompt;
    if (!input) return { status: 400, body: { ok: false, error: 'MISSING_INPUT' } };
    const rl = N.guardrails.rateLimit(`chat:${req.ip}`);
    if (!rl.ok) return { status: 429, body: { ok: false, error: 'RATE_LIMIT', retryAfterMs: rl.retryAfterMs } };

    const mode = body.mode || 'sync';
    if (mode === 'async') return N.orchestrator.createRun({ ...body, input, mode: body.execMode || 'sync' });
    if (mode === 'entropy-moe') return N.moe.route(input, { forceK: body.k });
    if (mode === 'team') return N.scheduler.team({ type: body.taskType || 'vietnamese', input, workers: body.workers });
    return N.scheduler.dispatch({ type: body.taskType || 'vietnamese', input, requester: body.tenantId });
  }, 'CORE');

  // ═══ NHÓM 2 — ORCHESTRATOR ═══════════════════════════════════════════
  add('POST', '/orchestrator/runs', (req, body) => N.orchestrator.createRun(body), 'ORCHESTRATOR');
  add('GET', '/orchestrator/runs/:id', (req) => N.orchestrator.getRun(req.params.id), 'ORCHESTRATOR');
  add('GET', '/orchestrator/status', () => N.orchestrator.status(), 'ORCHESTRATOR');

  // ═══ NHÓM 3 — 500 AGENT ══════════════════════════════════════════════
  add('GET', '/agents', (req) => {
    const { division, rank, squad, state, limit = '50', offset = '0' } = req.query;
    let list = N.agents;
    if (division) list = list.filter((a) => a.division === division.toUpperCase());
    if (rank) list = list.filter((a) => a.rank === rank.toUpperCase());
    if (squad) list = list.filter((a) => a.squad === squad || a.squadName === squad);
    if (state) list = list.filter((a) => a.state === state.toUpperCase());
    const off = +offset, lim = Math.min(+limit, 500);
    return {
      ok: true, total: list.length, offset: off, limit: lim,
      items: list.slice(off, off + lim).map((a) => ({
        id: a.id, division: a.division, squad: a.squadName, rank: a.rank, rankName: a.rankName,
        specialty: a.specialty, tier: a.tier, state: a.state,
        capacity: a.capacity, permissions: a.permissions,
      })),
    };
  }, 'AGENTS');

  add('GET', '/agents/assignment', () => ({ ok: true, ...assignmentTable(N.agents), matrix: ALLOCATION, taxonomy: validateTaxonomy() }), 'AGENTS');

  add('GET', '/agents/divisions', () => ({
    ok: true,
    divisions: Object.values(DIVISIONS).map((d) => ({
      ...d,
      allocation: ALLOCATION[d.id],
      squadCount: d.squads.length,
    })),
  }), 'AGENTS');

  add('GET', '/agents/ranks', () => ({ ok: true, ranks: Object.values(RANKS) }), 'AGENTS');

  add('GET', '/agents/squads', (req) => {
    let list = N.squads;
    if (req.query.division) list = list.filter((s) => s.division === req.query.division.toUpperCase());
    return { ok: true, total: list.length, items: list };
  }, 'AGENTS');

  add('GET', '/agents/kpi', (req) => {
    const by = req.query.by;
    if (by && ['division', 'squad', 'rank'].includes(by)) return { ok: true, by, groups: N.kpi.groupBy(by) };
    return { ok: true, system: N.kpi.system() };
  }, 'AGENTS');

  add('GET', '/agents/efficiency', (req) => ({
    ok: true,
    system: { efficiency: N.kpi.system().efficiency, utilization: N.kpi.system().utilization },
    byDivision: N.kpi.groupBy('division'),
    bySquad: N.kpi.groupBy('squad'),
    byRank: N.kpi.groupBy('rank'),
    leaderboard: N.kpi.leaderboard(+(req.query.limit || 20), 'efficiency'),
  }), 'AGENTS');

  add('GET', '/agents/capacity', () => ({ ok: true, ...N.capacity.status() }), 'AGENTS');
  add('GET', '/agents/leaderboard', (req) => ({ ok: true, items: N.kpi.leaderboard(+(req.query.limit || 20), req.query.by || 'kpiScore') }), 'AGENTS');
  add('GET', '/agents/scheduler', () => ({ ok: true, ...N.scheduler.status() }), 'AGENTS');

  add('GET', '/agents/:id', (req) => {
    const a = N.runtime.get(req.params.id.toUpperCase());
    if (!a) return { status: 404, body: { ok: false, error: 'AGENT_NOT_FOUND' } };
    return { ok: true, agent: a, kpi: N.kpi.agent(a.id), freeSlots: N.capacity.freeSlots(a.id) };
  }, 'AGENTS');

  add('POST', '/agents/:id/run', (req, body) => N.runtime.run(req.params.id.toUpperCase(), body), 'AGENTS');
  add('POST', '/agents/dispatch', (req, body) => N.scheduler.dispatch(body), 'AGENTS');
  add('POST', '/agents/team', (req, body) => N.scheduler.team(body), 'AGENTS');
  add('POST', '/agents/:id/coach', (req) => N.runtime.coach(req.params.id.toUpperCase()), 'AGENTS');
  add('POST', '/agents/:id/coach/apply', (req, body) => N.runtime.applyPrompt(req.params.id.toUpperCase(), body.prompt), 'AGENTS');
  add('POST', '/agents/:id/coach/rollback', (req) => N.runtime.rollbackPrompt(req.params.id.toUpperCase()), 'AGENTS');

  // ═══ NHÓM 4 — GOVERNANCE ═════════════════════════════════════════════
  add('GET', '/constitution/articles', (req) => {
    if (req.query.id) {
      const a = N.constitution.get(req.query.id);
      return a ? { ok: true, article: a } : { status: 404, body: { ok: false, error: 'NOT_FOUND' } };
    }
    return { ok: true, version: N.constitution.version, total: N.constitution.articles.length, chapters: N.constitution.byChapter(), articles: N.constitution.articles };
  }, 'GOVERNANCE');

  add('POST', '/constitution/validate', (req, body) => N.constitution.validate(body.action, body.ctx || {}), 'GOVERNANCE');
  add('GET', '/constitution/status', () => N.constitution.status(), 'GOVERNANCE');
  add('GET', '/heart/axioms', () => ({ ok: true, axioms: N.heart.getAxioms(), nesBoundaries: N.heart.getNesBoundaries(), stats: N.heart.status() }), 'GOVERNANCE');
  add('POST', '/heart/check', (req, body) => ({
    input: body.input ? N.heart.validateInput(body.input) : null,
    output: body.output ? N.heart.validateOutput(body.output) : null,
  }), 'GOVERNANCE');
  add('POST', '/guardrails/check', (req, body) => N.guardrails.checkInput(body.input || ''), 'GOVERNANCE');
  add('POST', '/safe-prompt/build', (req, body) => N.safePrompt.build(body.input || ''), 'GOVERNANCE');

  // ═══ NHÓM 5 — COMPLIANCE & AUDIT ═════════════════════════════════════
  add('GET', '/compliance/report', () => N.audit.report(), 'COMPLIANCE');
  add('GET', '/audit/verify', () => N.audit.verify(), 'COMPLIANCE');
  add('GET', '/audit/query', (req) => N.audit.query({ ...req.query, limit: +(req.query.limit || 50) }), 'COMPLIANCE');
  add('GET', '/events', (req) => N.eventStore.read({ stream: req.query.stream, type: req.query.type, limit: +(req.query.limit || 50) }), 'COMPLIANCE');

  // ═══ NHÓM 6 — INTELLIGENCE ═══════════════════════════════════════════
  add('POST', '/entropy-moe/route', (req, body) => N.moe.route(body.input, { forceK: body.k, mergeStrategy: body.merge }), 'INTELLIGENCE');
  add('GET', '/entropy-moe/experts', () => ({ ok: true, experts: N.moe.listExperts(), status: N.moe.status() }), 'INTELLIGENCE');
  add('POST', '/entropy-moe/analyze', (req, body) => {
    const probs = N.moe.routingDistribution(body.input || '');
    const H = N.moe.entropy(probs);
    return { ok: true, entropy: round(H, 4), k: N.moe.selectK(H), distribution: probs };
  }, 'INTELLIGENCE');
  add('POST', '/adaptive/route', (req, body) => N.adaptiveRouter.route(body.input || ''), 'INTELLIGENCE');
  add('GET', '/adaptive/arms', async () => ({ ok: true, arms: await N.adaptiveRouter.armStats(), status: N.adaptiveRouter.status() }), 'INTELLIGENCE');
  add('POST', '/cache/classify', (req, body) => ({ ok: true, category: N.cache.classify(body.query || body.input || '') }), 'INTELLIGENCE');
  add('GET', '/cache/status', () => N.cache.status(), 'INTELLIGENCE');

  // ═══ NHÓM 7 — OPS & OBSERVABILITY ════════════════════════════════════
  add('GET', '/otel/traces', (req) => ({ ok: true, traces: N.otel.getRecent(+(req.query.limit || 30)) }), 'OPS');
  add('GET', '/otel/traces/:id', (req) => {
    const t = N.otel.getTrace(req.params.id);
    return t ? { ok: true, trace: t } : { status: 404, body: { ok: false, error: 'TRACE_NOT_FOUND' } };
  }, 'OPS');
  add('GET', '/otel/anomalies', () => ({ ok: true, anomalies: N.otel.detectAnomalies(), status: N.otel.status() }), 'OPS');
  add('GET', '/queue/status', () => N.queue.status(), 'OPS');
  add('GET', '/bus/status', () => N.bus.status(), 'OPS');
  add('GET', '/llm/status', () => N.llm.status(), 'OPS');

  add('GET', '/metrics', () => {
    const k = N.kpi.system();
    const c = N.capacity.status();
    const q = N.queue.status();
    const lines = [
      `# HELP nexus_uptime_seconds Thời gian chạy`,
      `# TYPE nexus_uptime_seconds gauge`,
      `nexus_uptime_seconds ${Math.round(process.uptime())}`,
      `# TYPE nexus_agents_total gauge`,
      `nexus_agents_total ${N.agents.length}`,
      `# TYPE nexus_agent_tasks_total counter`,
      `nexus_agent_tasks_total ${k.tasks}`,
      `# TYPE nexus_agent_success_rate gauge`,
      `nexus_agent_success_rate ${k.successRate}`,
      `# TYPE nexus_agent_kpi_score gauge`,
      `nexus_agent_kpi_score ${k.kpiScore}`,
      `# TYPE nexus_agent_efficiency gauge`,
      `nexus_agent_efficiency ${k.efficiency}`,
      `# TYPE nexus_agent_utilization gauge`,
      `nexus_agent_utilization ${k.utilization}`,
      `# TYPE nexus_agent_below_target gauge`,
      `nexus_agent_below_target ${k.belowTarget}`,
      `# TYPE nexus_constitution_violations_total counter`,
      `nexus_constitution_violations_total ${k.violations}`,
      `# TYPE nexus_capacity_running gauge`,
      `nexus_capacity_running ${c.global.running}`,
      `# TYPE nexus_queue_waiting gauge`,
      `nexus_queue_waiting ${q.waiting}`,
      `# TYPE nexus_llm_providers_available gauge`,
      `nexus_llm_providers_available ${N.llm.available().length}`,
      `# TYPE nexus_cost_usd_total counter`,
      `nexus_cost_usd_total ${k.costUsd}`,
      `# TYPE nexus_cache_hit_rate gauge`,
      `nexus_cache_hit_rate ${N.cache.status().total.hitRate}`,
    ];
    for (const g of N.kpi.groupBy('division')) {
      lines.push(`nexus_division_kpi_score{division="${g.division}"} ${g.kpiScore}`);
      lines.push(`nexus_division_tasks_total{division="${g.division}"} ${g.tasks}`);
    }

    // Chỉ số ban quản trị quan hệ gia đình. Thêm vào ĐÂY chứ không dựng một
    // bộ xuất chỉ số thứ hai: hai bộ xuất thì có hai nơi phải sửa mỗi lần đổi
    // tên chỉ số, và một trong hai nơi sẽ bị quên.
    if (N.crm) {
      const cs = N.crm.status();
      const hc = cs.hangCho || {};
      const tt = hc.theoTrangThai || {};
      lines.push(
        `# HELP crm_luot_total Số lượt đã chạy qua ban quan hệ gia đình`,
        `# TYPE crm_luot_total counter`,
        `crm_luot_total ${cs.dem.luot}`,
        `# TYPE crm_khong_doc_ra_total counter`,
        `crm_khong_doc_ra_total ${cs.dem.khongDocRa}`,
        `# TYPE crm_can_nguoi_duyet_total counter`,
        `crm_can_nguoi_duyet_total ${cs.dem.canNguoi}`,
        `# TYPE crm_bi_chan_total counter`,
        `crm_bi_chan_total ${cs.dem.bichan}`,
        `# HELP crm_tuong_chan_total Số câu trả lời bị bức tường giữ lại`,
        `# TYPE crm_tuong_chan_total counter`,
        `crm_tuong_chan_total ${cs.dem.tuongChan}`,
        `# TYPE crm_duyet_dang_cho gauge`,
        `crm_duyet_dang_cho ${tt.cho || 0}`,
        `# HELP crm_duyet_het_han_total Việc hết hạn chờ mà không ai quyết`,
        `# TYPE crm_duyet_het_han_total counter`,
        `crm_duyet_het_han_total ${tt['het-han'] || 0}`,
        `# TYPE crm_tro_ly_bi_khoa gauge`,
        `crm_tro_ly_bi_khoa ${cs.quanTri.soTroLyBiKhoa}`,
        `# HELP crm_toan_ban_dung Ban có đang bị Super Admin dừng không`,
        `# TYPE crm_toan_ban_dung gauge`,
        `crm_toan_ban_dung ${cs.quanTri.dangDung ? 1 : 0}`,
        `# HELP crm_chi_so_co_nguon_do Tỷ lệ chỉ số KPI đã nối được nguồn đo`,
        `# TYPE crm_chi_so_co_nguon_do gauge`,
        `crm_chi_so_co_nguon_do ${cs.kpi.doPhuChiSo ? cs.kpi.doPhuChiSo.tyLeCoNguon : 0}`,
      );
      if (cs.kpi.diemTrungBinh != null) {
        lines.push(`# TYPE crm_diem_trung_binh gauge`, `crm_diem_trung_binh ${cs.kpi.diemTrungBinh}`);
      }
    }

    return { contentType: 'text/plain; version=0.0.4', raw: lines.join('\n') + '\n' };
  }, 'OPS');

  // ═══ NHÓM 8 — SUPER ADMIN & BẢO MẬT 15 TẦNG ═════════════════════════
  add('GET', '/superadmin/status', () => ({ ok: true, ...N.vault.status() }), 'SUPERADMIN');
  add('GET', '/superadmin/layers', () => ({ ok: true, layers: require('../security/superadmin-vault').LAYERS, destructive: [...require('../security/superadmin-vault').DESTRUCTIVE] }), 'SUPERADMIN');
  add('POST', '/superadmin/initialize', (req, body) => N.vault.initialize(body), 'SUPERADMIN');
  add('POST', '/superadmin/login', (req, body) => N.vault.login({ ...body, ip: req.ip, userAgent: req.headers['user-agent'] || '' }), 'SUPERADMIN');
  add('POST', '/superadmin/logout', (req, body) => N.vault.logout(body.token), 'SUPERADMIN');
  add('POST', '/superadmin/step-up', (req, body) => N.vault.stepUp(body.token, body), 'SUPERADMIN');
  add('POST', '/superadmin/authorize', (req, body) => N.vault.authorize(body.token, body.command, body.args || {}, body.signature ?? null), 'SUPERADMIN');
  add('POST', '/superadmin/approve-dual', (req, body) => N.vault.approveDual(body.requestId, body.approver), 'SUPERADMIN');
  add('POST', '/superadmin/break-glass', (req, body) => N.vault.breakGlass(body.key, body.reason), 'SUPERADMIN');

  // ═══ NHÓM 9 — KHÔI PHỤC & BẢO LƯU ════════════════════════════════════
  add('GET', '/recovery/status', () => ({ ok: true, ...N.recovery.status() }), 'RECOVERY');
  add('POST', '/recovery/start', (req, body) => N.recovery.start({ ...body, ip: req.ip }), 'RECOVERY');
  add('POST', '/recovery/share', (req, body) => N.recovery.submitShare(body.challengeId, body.share), 'RECOVERY');
  add('POST', '/recovery/complete', (req, body) => N.recovery.complete(body.challengeId, body), 'RECOVERY');
  add('POST', '/recovery/regenerate-codes', (req, body) => N.recovery.regenerateRecoveryCodes(body.token), 'RECOVERY');
  add('POST', '/recovery/restore-system', (req, body) => N.recovery.restoreSystem(body.selector || {}, { dryRun: !!body.dryRun, actor: body.actor || 'superadmin' }), 'RECOVERY');
  add('GET', '/snapshots', (req) => ({ ok: true, items: N.snapshots.list({ limit: +(req.query.limit || 30) }), status: N.snapshots.status() }), 'RECOVERY');
  add('GET', '/snapshots/timeline', () => ({ ok: true, timeline: N.snapshots.timeline() }), 'RECOVERY');
  add('GET', '/snapshots/verify', (req) => N.snapshots.verify(req.query.id || null), 'RECOVERY');
  add('POST', '/snapshots/take', (req, body) => N.snapshots.take({ label: body.label || 'manual', note: body.note }), 'RECOVERY');

  // ═══ NHÓM 10 — CHỐNG NHIỄU ═══════════════════════════════════════════
  add('GET', '/resilience/status', () => ({ ok: true, ...N.shield.status() }), 'RESILIENCE');
  add('GET', '/resilience/fleet', () => ({ ok: true, ...N.shield.fleetReadiness(), byDivision: N.shield.divisionHealth() }), 'RESILIENCE');
  add('GET', '/resilience/unhealthy', (req) => ({ ok: true, items: N.shield.unhealthy(+(req.query.limit || 30)) }), 'RESILIENCE');
  add('POST', '/resilience/filter', (req, body) => N.shield.filterInput(body.input || ''), 'RESILIENCE');
  add('POST', '/resilience/quarantine', (req, body) => N.shield.quarantine(body.agentId, body.ms, body.reason), 'RESILIENCE');
  add('POST', '/resilience/release', (req, body) => N.shield.release(body.agentId), 'RESILIENCE');
  add('POST', '/resilience/heal-all', () => N.shield.healAll(), 'RESILIENCE');

  // ═══ NHÓM 11 — TỔNG ĐỘNG VIÊN · CHẤT VẤN · HỢP ĐỒNG ══════════════════
  add('GET', '/mission/playbooks', () => ({ ok: true, playbooks: N.mobilization.playbooks() }), 'COMMAND');
  add('POST', '/mission/plan', (req, body) => N.mobilization.plan(body), 'COMMAND');
  add('POST', '/mission/execute', (req, body) => N.mobilization.execute(body), 'COMMAND');
  add('GET', '/mission', (req) => ({ ok: true, items: N.mobilization.list({ limit: +(req.query.limit || 20) }), status: N.mobilization.status() }), 'COMMAND');
  add('GET', '/mission/:id', (req) => {
    const m = N.mobilization.get(req.params.id);
    return m ? { ok: true, mission: m } : { status: 404, body: { ok: false, error: 'MISSION_NOT_FOUND' } };
  }, 'COMMAND');
  add('POST', '/debate/run', (req, body) => N.debate.run(body), 'COMMAND');
  add('GET', '/debate/status', () => ({ ok: true, ...N.debate.status() }), 'COMMAND');
  add('GET', '/debate/:id', (req) => {
    const d = N.debate.get(req.params.id);
    return d ? { ok: true, debate: d } : { status: 404, body: { ok: false, error: 'DEBATE_NOT_FOUND' } };
  }, 'COMMAND');
  add('POST', '/handoff/run', (req, body) => N.handoff.run(body), 'COMMAND');
  add('GET', '/handoff', (req) => ({ ok: true, items: N.handoff.list(req.query), status: N.handoff.status() }), 'COMMAND');

  // ═══ NHÓM 12 — CHƯƠNG TRÌNH & HỌC LIỆU ═══════════════════════════════
  add('GET', '/curriculum/hierarchy', () => {
    const h = require('../curriculum/hierarchy');
    return { ok: true, blocks: h.BLOCKS, levels: h.LEVELS, difficulty: h.DIFFICULTY, forms: h.FORMS, check: h.validateHierarchy() };
  }, 'CURRICULUM');
  add('GET', '/curriculum/forms', (req) => {
    const h = require('../curriculum/hierarchy');
    const lv = req.query.level != null ? Number(req.query.level) : null;
    const list = lv != null ? h.formsForLevel(lv, { subject: req.query.subject, grade: req.query.grade ? Number(req.query.grade) : null }) : h.FORMS;
    return { ok: true, total: list.length, items: list };
  }, 'CURRICULUM');
  add('GET', '/curriculum/order', () => ({ ok: true, ...require('../curriculum/hierarchy').learningOrder() }), 'CURRICULUM');
  add('GET', '/curriculum/standards', (req) => {
    const st = require('../curriculum/standards');
    if (req.query.level != null) return { ok: true, standard: st.standardFor(Number(req.query.level)) };
    return { ok: true, standards: st.LEVEL_STANDARDS, criteria: st.CRITERIA, check: st.validateStandards() };
  }, 'CURRICULUM');
  add('GET', '/bank/status', () => ({ ok: true, ...N.bank.status() }), 'CURRICULUM');
  add('GET', '/bank/coverage', (req) => ({ ok: true, ...N.bank.coverage({ minPerCell: +(req.query.min || 5) }) }), 'CURRICULUM');
  add('GET', '/bank/items', (req) => ({
    ok: true,
    // Tham số trên URL luôn là chuỗi; không ép kiểu thì lọc theo tầng và bậc sao
    // sẽ không khớp gì cả và trả về kho rỗng.
    items: N.bank.query({
      formCode: req.query.formCode || null,
      level: req.query.level != null && req.query.level !== '' ? Number(req.query.level) : null,
      stars: req.query.stars != null && req.query.stars !== '' ? Number(req.query.stars) : null,
      subject: req.query.subject || null,
      status: req.query.status || 'PUBLISHED',
      limit: +(req.query.limit || 20),
    }),
  }), 'CURRICULUM');
  add('GET', '/bank/items/:id', (req) => {
    const it = N.bank.get(req.params.id);
    return it ? { ok: true, item: it } : { ok: false, error: 'ITEM_NOT_FOUND' };
  }, 'CURRICULUM');
  add('POST', '/bank/items/:id/publish', (req, body) => {
    const r = N.bank.publish(req.params.id, body.by || 'teacher');
    if (r.ok) N.seeder._persist(N.bank.get(req.params.id));
    return r;
  }, 'CURRICULUM');
  add('POST', '/bank/items/:id/retire', (req, body) => N.bank.retire?.(req.params.id, body.by || 'teacher', body.reason || '') || { ok: false, error: 'NOT_SUPPORTED' }, 'CURRICULUM');
  add('POST', '/bank/draft', (req, body) => N.bank.draft(body), 'CURRICULUM');
  add('POST', '/authoring/produce', (req, body) => N.authoring.produce(body), 'CURRICULUM');
  add('POST', '/authoring/batch', (req, body) => N.authoring.produceBatch(body.cells || N.bank.coverage().topGaps, body), 'CURRICULUM');
  add('GET', '/authoring/status', () => ({ ok: true, ...N.authoring.status() }), 'CURRICULUM');
  add('POST', '/notation/check', (req, body) => require('../content/notation').enforce(body.expr || ''), 'CURRICULUM');
  add('POST', '/quality/score', (req, body) => require('../content/quality').score(body.item || {}, body.critic || {}), 'CURRICULUM');

  // ═══ NHÓM 13 — HỌC VIÊN ══════════════════════════════════════════════
  add('POST', '/learner/register', (req, body) => N.profiles.register(body.userId, body), 'LEARNER');
  add('GET', '/learner', (req) => ({ ok: true, items: N.profiles.list({ limit: +(req.query.limit || 50) }), status: N.profiles.status() }), 'LEARNER');
  add('GET', '/learner/:id/portrait', (req) => N.profiles.portrait(req.params.id), 'LEARNER');
  add('GET', '/learner/:id/promotion', (req) => N.profiles.evaluateLevel(req.params.id), 'LEARNER');
  add('POST', '/learner/:id/promote', (req) => N.profiles.promote(req.params.id), 'LEARNER');
  add('POST', '/learner/:id/action', (req, body) => N.telemetry.action(req.params.id, body.type, body.payload || {}), 'LEARNER');
  add('POST', '/learner/:id/attempt', (req, body) => {
    const t = N.telemetry.attempt(req.params.id, body);
    const m = N.mastery.update(req.params.id, body);
    if (body.itemId) N.bank.recordAttempt(body.itemId, { correct: !!body.correct, ms: body.ms || 0 });
    return { ok: true, telemetry: t.attempt, mastery: m };
  }, 'LEARNER');
  add('GET', '/learner/:id/behaviors', (req) => ({ ok: true, ...N.telemetry.behaviors(req.params.id) }), 'LEARNER');
  add('GET', '/learner/:id/mastery', (req) => ({
    ok: true, summary: N.mastery.summary(req.params.id), weakest: N.mastery.weakest(req.params.id),
    due: N.mastery.due(req.params.id), zpd: N.mastery.zpd(req.params.id),
  }), 'LEARNER');
  add('POST', '/learner/:id/exit-exam', (req, body) => N.profiles.recordExitExam(req.params.id, body.level, body.score), 'LEARNER');
  add('POST', '/learner/:id/session-result', (req, body) => N.profiles.recordSessionPassed(req.params.id, !!body.passed), 'LEARNER');

  // ═══ NHÓM 14 — CHU KỲ 90 NGÀY ════════════════════════════════════════
  add('POST', '/cycle/:id/start', (req, body) => N.cycle90.start(req.params.id, body || {}), 'CYCLE');
  add('GET', '/cycle/:id', (req) => N.cycle90.view(req.params.id), 'CYCLE');
  add('GET', '/cycle/:id/today', (req) => N.cycle90.todayPlan(req.params.id, { itemsPerSession: +(req.query.items || 20) }), 'CYCLE');
  add('POST', '/cycle/:id/log-phase', (req) => N.cycle90.logPhase(req.params.id), 'CYCLE');
  add('GET', '/cycle/:id/strategy', (req) => ({ ok: true, ...N.cycle90.decideStrategy(req.params.id) }), 'CYCLE');
  add('POST', '/cycle/:id/close', (req) => N.cycle90.close(req.params.id), 'CYCLE');
  add('GET', '/cycle-config', () => ({ ok: true, phases: require('../learner/cycle90').PHASES, rules: require('../learner/cycle90').STRATEGY_RULES.map((r) => ({ id: r.id, name: r.name, reason: r.reason, shift: r.shift })) }), 'CYCLE');

  // ═══ NHÓM 15 — TÀI KHOẢN & PHÂN QUYỀN ════════════════════════════════
  add('GET', '/accounts/roles', () => ({ ok: true, roles: Object.values(require('../security/accounts').ROLES), permissions: require('../security/accounts').PERMISSIONS }), 'ACCOUNTS');
  add('GET', '/accounts/status', () => ({ ok: true, ...N.accounts.status() }), 'ACCOUNTS');
  add('GET', '/accounts', (req) => ({ ok: true, ...N.accounts.list({ role: req.query.role || null, limit: +(req.query.limit || 100), offset: +(req.query.offset || 0) }) }), 'ACCOUNTS');
  add('GET', '/accounts/:id', (req) => {
    const u = N.accounts.get(req.params.id);
    return u ? { ok: true, user: u } : { ok: false, error: 'NOT_FOUND' };
  }, 'ACCOUNTS');
  add('POST', '/accounts', (req, body) => N.accounts.create(body), 'ACCOUNTS');
  add('POST', '/accounts/login', (req, body) => N.accounts.login({ ...body, ip: req.ip, userAgent: req.headers['user-agent'] || '' }), 'ACCOUNTS');
  add('POST', '/accounts/logout', (req, body) => N.accounts.logout(body.token), 'ACCOUNTS');
  add('POST', '/accounts/authorize', (req, body) => N.accounts.authorize(body.token, body.permission, body.target || {}), 'ACCOUNTS');
  add('POST', '/accounts/:id/password', (req, body) => N.accounts.changePassword(req.params.id, body.oldPassword, body.newPassword), 'ACCOUNTS');
  add('POST', '/accounts/:id/reset-password', (req, body) => N.accounts.resetPassword(req.params.id, body.by || 'admin'), 'ACCOUNTS');
  add('POST', '/accounts/:id/active', (req, body) => N.accounts.setActive(req.params.id, !!body.active, body.by || 'admin'), 'ACCOUNTS');
  add('POST', '/accounts/:id/link-learner', (req, body) => N.accounts.linkLearner(req.params.id, body.learnerId, body.by || 'admin'), 'ACCOUNTS');
  add('POST', '/accounts/:id/assign-class', (req, body) => N.accounts.assignClass(req.params.id, body.classId, body.by || 'admin'), 'ACCOUNTS');

  // ═══ NHÓM 16 — TRƯỜNG · LỚP · NHÓM ═══════════════════════════════════
  add('GET', '/org/status', () => ({ ok: true, ...N.org.status() }), 'ORG');
  add('GET', '/org/schools', () => ({ ok: true, items: N.org.listSchools() }), 'ORG');
  add('POST', '/org/schools', (req, body) => N.org.createSchool(body), 'ORG');
  add('GET', '/org/classes', (req) => ({ ok: true, ...N.org.listClasses({
    teacherId: req.query.teacherId || null, schoolId: req.query.schoolId || null,
    grade: req.query.grade || null, schoolYear: req.query.schoolYear || null,
    limit: +(req.query.limit || 100), offset: +(req.query.offset || 0),
  }) }), 'ORG');
  add('POST', '/org/classes', (req, body) => N.org.createClass(body), 'ORG');
  add('GET', '/org/classes/:id', (req) => {
    const c = N.org.getClass(req.params.id);
    return c ? { ok: true, class: c } : { ok: false, error: 'CLASS_NOT_FOUND' };
  }, 'ORG');
  add('GET', '/org/classes/:id/roster', (req) => N.org.roster(req.params.id), 'ORG');
  add('POST', '/org/classes/:id/teacher', (req, body) => N.org.assignTeacher(req.params.id, body.teacherId, body.by || 'admin'), 'ORG');
  add('POST', '/org/classes/:id/enroll', (req, body) => N.org.enroll(req.params.id, body.learnerId, body.by || 'admin', body.reason || ''), 'ORG');
  add('POST', '/org/classes/:id/remove', (req, body) => N.org.remove(req.params.id, body.learnerId, body.by || 'admin', body.reason || ''), 'ORG');
  add('POST', '/org/classes/:id/groups', (req, body) => N.org.createGroup(req.params.id, body), 'ORG');
  add('POST', '/org/classes/:id/auto-group', (req, body) => N.org.autoGroupByLevel(req.params.id, body || {}), 'ORG');

  // ═══ NHÓM 17 — NHẬP / XUẤT ═══════════════════════════════════════════
  add('GET', '/io/status', () => ({ ok: true, ...N.portability.status() }), 'IO');
  add('GET', '/io/learner-template', () => {
    const t = N.portability.learnerTemplate();
    return { raw: t.content, contentType: 'text/csv; charset=utf-8' };
  }, 'IO');
  add('POST', '/io/import-learners', (req, body) => N.portability.importLearners(body.csv || '', {
    classId: body.classId || null, dryRun: body.dryRun !== false,
    by: body.by || 'admin', allowUpdate: !!body.allowUpdate,
  }), 'IO');
  add('GET', '/io/export-learners', (req) => {
    const r = N.portability.exportLearners({ classId: req.query.classId || null, format: req.query.format || 'csv' });
    return r.format === 'csv' ? { raw: r.content, contentType: 'text/csv; charset=utf-8' } : r;
  }, 'IO');
  add('GET', '/io/export-items', (req) => {
    const r = N.portability.exportItems({ formCode: req.query.formCode || null, status: req.query.status || null, format: req.query.format || 'csv' });
    return r.format === 'csv' ? { raw: r.content, contentType: 'text/csv; charset=utf-8' } : r;
  }, 'IO');

  // ═══ NHÓM 18 — BIÊN SOẠN & THẨM ĐỊNH TOÁN HỌC ════════════════════════
  add('GET', '/authoring/blueprints', () => {
    const { BLUEPRINTS } = require('../content/blueprint');
    return { ok: true, count: BLUEPRINTS.length, items: BLUEPRINTS.map((b) => ({
      id: b.id, formCode: b.formCode, intent: b.intent, targetTrap: b.targetTrap,
      context: b.context, stars: b.stars, levels: b.levels,
    })) };
  }, 'AUTHORING');
  add('POST', '/authoring/generate', (req, body) => N.generator.generate({
    formCode: body.formCode, level: body.level, count: body.count || 5,
    stars: body.stars ?? null, seed: body.seed || 'gita-v20',
    authorId: body.authorId || 'API', dryRun: body.dryRun !== false,
  }), 'AUTHORING');
  add('POST', '/authoring/seed', (req, body) => N.seeder.seed({
    perBlueprintLevel: body.perBlueprintLevel || 3, seed: body.seed || 'gita-seed-v20', dryRun: body.dryRun !== false,
  }), 'AUTHORING');
  add('GET', '/authoring/coverage', () => ({ ok: true, ...N.seeder.coverage() }), 'AUTHORING');
  add('GET', '/authoring/generator-status', () => ({ ok: true, ...N.generator.status() }), 'AUTHORING');
  add('POST', '/math/verify', (req, body) => N.mathVerifier.verifyItem(body), 'AUTHORING');
  add('POST', '/math/solve', (req, body) => N.mathVerifier.solve(body.equation, body.variable || 'x'), 'AUTHORING');
  add('POST', '/math/equivalent', (req, body) => N.mathVerifier.equivalent(body.a, body.b, { domain: body.domain || null }), 'AUTHORING');
  add('POST', '/math/check-roots', (req, body) => N.mathVerifier.checkRoots(body.equation, body.answer, body.variable || 'x'), 'AUTHORING');

  // ═══ NHÓM 19 — CHẨN ĐOÁN · LUYỆN TẬP · THI ═══════════════════════════
  add('GET', '/placement/status', () => ({ ok: true, ...N.placement.status() }), 'ASSESS');
  add('POST', '/placement/start', (req, body) => N.placement.start(body), 'ASSESS');
  add('POST', '/placement/answer', (req, body) => N.placement.answer(body), 'ASSESS');
  add('GET', '/placement/:id', (req) => {
    const s = N.placement.get(req.params.id);
    return s ? { ok: true, session: s } : { ok: false, error: 'SESSION_NOT_FOUND' };
  }, 'ASSESS');

  add('GET', '/practice/status', () => ({ ok: true, ...N.practice.status() }), 'ASSESS');
  add('POST', '/practice/plan', (req, body) => ({ ok: true, ...N.practice.plan(body) }), 'ASSESS');
  add('POST', '/practice/start', (req, body) => N.practice.start(body), 'ASSESS');
  add('POST', '/practice/answer', (req, body) => N.practice.answer(body), 'ASSESS');
  add('POST', '/practice/finish', (req, body) => N.practice.finish(body.sessionId, body.reason || 'NGƯỜI_DÙNG_DỪNG'), 'ASSESS');
  add('POST', '/practice/grade', (req, body) => N.practice.grade(body.itemId, body.answer), 'ASSESS');

  add('GET', '/exam/status', () => ({ ok: true, ...N.examService.status() }), 'ASSESS');
  add('POST', '/exam/build', (req, body) => {
    const p = N.examService.build(body);
    return p.ok ? { ...p, items: p.items.map((i) => ({ id: i.id, formCode: i.formCode, stars: i.stars, level: i.level })) } : p;
  }, 'ASSESS');
  add('POST', '/exam/start', (req, body) => N.examService.start(body), 'ASSESS');
  add('POST', '/exam/answer', (req, body) => N.examService.submitAnswer(body), 'ASSESS');
  add('POST', '/exam/submit', (req, body) => N.examService.submit(body), 'ASSESS');
  add('GET', '/exam/:id', (req) => {
    const e = N.examService.get(req.params.id);
    return e ? { ok: true, exam: e } : { ok: false, error: 'EXAM_NOT_FOUND' };
  }, 'ASSESS');
  add('GET', '/promotion/:learnerId', (req) => N.examService.evaluatePromotion(req.params.learnerId, req.query.level != null ? +req.query.level : null), 'ASSESS');
  add('POST', '/promotion/:learnerId', (req, body) => N.examService.promote(req.params.learnerId, { by: body.by || 'system', force: !!body.force }), 'ASSESS');

  // ═══ NHÓM 20 — HÀNH VI & LỘ TRÌNH ════════════════════════════════════
  add('GET', '/behavior/:learnerId', (req) => N.behavior.fullReport(req.params.learnerId), 'INSIGHT');
  add('GET', '/behavior/:learnerId/guessing', (req) => N.behavior.guessing(req.params.learnerId), 'INSIGHT');
  add('GET', '/behavior/:learnerId/attention', (req) => N.behavior.attentionSpan(req.params.learnerId), 'INSIGHT');
  add('GET', '/behavior/:learnerId/anomalies', (req) => N.behavior.anomalies(req.params.learnerId), 'INSIGHT');
  add('GET', '/behavior/:learnerId/rhythm', (req) => N.behavior.rhythm(req.params.learnerId), 'INSIGHT');
  add('GET', '/behavior/:learnerId/trend', (req) => N.behavior.trend(req.params.learnerId, { window: +(req.query.window || 20) }), 'INSIGHT');

  add('GET', '/roadmap/status', () => ({ ok: true, ...N.roadmap.status() }), 'INSIGHT');
  add('POST', '/roadmap/generate', (req, body) => N.roadmap.generate(body), 'INSIGHT');
  add('GET', '/roadmap/:learnerId', (req) => {
    const r = N.roadmap.get(req.params.learnerId);
    return r ? { ok: true, roadmap: r } : { ok: false, error: 'NO_ROADMAP' };
  }, 'INSIGHT');
  add('GET', '/roadmap/:learnerId/this-week', (req) => N.roadmap.thisWeek(req.params.learnerId), 'INSIGHT');
  add('GET', '/roadmap/:learnerId/progress', (req) => N.roadmap.progress(req.params.learnerId), 'INSIGHT');
  add('POST', '/roadmap/:learnerId/weekly-review', (req, body) => N.roadmap.weeklyReview(req.params.learnerId, body || {}), 'INSIGHT');

  // ═══ NHÓM 21 — BÁO CÁO ═══════════════════════════════════════════════
  add('GET', '/reports/status', () => ({ ok: true, ...N.reports.status() }), 'REPORT');
  // Chuỗi giá trị và điểm chạm. Bảng chuỗi luôn trả được vì nó là thiết kế;
  // phần ĐO thì phụ thuộc dữ liệu học viên thật, và chặng nào chưa đủ người sẽ
  // trả đúng chữ "chưa đủ căn cứ" kèm cỡ mẫu, không trả một tỉ lệ lấp chỗ.
  // ═══ BỘ KHẢO SÁT VÀ LỘ TRÌNH CÁ NHÂN HOÁ ════════════════════════════
  // Các tay xử lý dưới đây là HÀM THUẦN: nhận câu trả lời, trả kết quả, KHÔNG
  // ghi xuống đĩa. Với sàng lọc tâm lý học đường, việc không lưu chính là bảo
  // đảm riêng tư mạnh nhất — thứ không được lưu thì không rò được.
  const KHAO_SAT = {
    disc: () => require('../khao-sat/disc'),
    mbti: () => require('../khao-sat/mbti'),
    'tam-ly': () => require('../khao-sat/tam-ly-hoc-duong'),
    'phuong-phap': () => require('../khao-sat/phuong-phap-hoc'),
  };
  add('GET', '/khao-sat/luat-do', () => ({ ok: true, ...require('../khao-sat/hien-phap-do').luatDo() }), 'KHAOSAT');
  // Hai cổng nam-hoc đăng ký TRƯỚC cổng có tham số ':ma'. Bộ định tuyến khớp
  // theo thứ tự đăng ký, nên để sau thì '/khao-sat/nam-hoc/de' sẽ rơi vào
  // ':ma' = 'nam-hoc' và trả về "không có bộ khảo sát này".
  add('GET', '/khao-sat/nam-hoc/moc', () => ({ ok: true, moc: require('../khao-sat/nam-hoc').MOC }), 'KHAOSAT');
  add('GET', '/khao-sat/nam-hoc/de', (req) => require('../khao-sat/nam-hoc').moTaDe({
    lop: Number(req.query.lop), mocMa: req.query.moc, mon: req.query.mon || 'math',
    soCau: Number(req.query.soCau || 20),
  }), 'KHAOSAT');
  add('GET', '/khao-sat/:ma/de', (req) => {
    const m = KHAO_SAT[req.params.ma];
    if (!m) return { ok: false, error: 'KHÔNG_CÓ_BỘ_KHẢO_SÁT_NÀY', ma: req.params.ma };
    return { ok: true, ma: req.params.ma, cau: m().deBai() };
  }, 'KHAOSAT');
  add('POST', '/khao-sat/:ma/cham', (req, body) => {
    const m = KHAO_SAT[req.params.ma];
    if (!m) return { ok: false, error: 'KHÔNG_CÓ_BỘ_KHẢO_SÁT_NÀY', ma: req.params.ma };
    const traLoi = (body && body.traLoi) || [];
    const opt = req.params.ma === 'phuong-phap' && body && body.hocVienId
      ? { metrics: N.telemetry.metrics(body.hocVienId) }
      : {};
    return { ok: true, ...m().cham(traLoi, opt) };
  }, 'KHAOSAT');
  add('POST', '/khao-sat/than-so', (req, body) => require('../khao-sat/than-so').tinh(body || {}), 'KHAOSAT');
  add('POST', '/khao-sat/ho-so', (req, body) => require('../khao-sat/ho-so').dungHoSo(body || {}), 'KHAOSAT');
  add('POST', '/khao-sat/lo-trinh', (req, body) => {
    const { dungHoSo } = require('../khao-sat/ho-so');
    const { dungLoTrinh } = require('../khao-sat/lo-trinh-ca-nhan');
    const b = body || {};
    const hoSo = b.hoSo && b.hoSo.ok ? b.hoSo : dungHoSo(b);
    return dungLoTrinh({ ...b, hoSo });
  }, 'KHAOSAT');

  // ═══ CÂY GIÁ TRỊ — MẶT KHÁCH HÀNG ═══════════════════════════════════
  // Mở cho mọi vai. Đây là thứ gia đình ĐƯỢC BIẾT: năm tầng và thứ nhận được
  // khi đi hết. Không có một chữ nào của Cây Tiền ở đây, và có mục kiểm quét
  // để chứng minh chứ không chỉ hứa.
  add('GET', '/cay-gia-tri', () => {
    const { cayGiaTri } = require('../nha/cay-gia-tri');
    return { ok: true, ...cayGiaTri() };
  }, 'REPORT');

  // Lưới 50 ô: 5 tầng × 10 cấp. Cùng mặt khách hàng với /cay-gia-tri, chỉ chi
  // tiết hơn một bậc. Mỗi ô tự khai bằng chứng của nó là mốc cứng hay mốc mềm.
  add('GET', '/cay-gia-tri/luoi', () => {
    const C50 = require('../matran/cay-50');
    return { ok: true, ...C50.luoi() };
  }, 'REPORT');
  add('GET', '/cay-gia-tri/o/:tang/:cap', (req) => {
    const C50 = require('../matran/cay-50');
    const tang = Number(req.params.tang);
    const cap = Number(req.params.cap);
    if (!Number.isInteger(tang) || tang < 1 || tang > 5 || !Number.isInteger(cap) || cap < 1 || cap > 10) {
      return { ok: false, error: 'Ô không có thật: tầng 1..5, cấp 1..10.' };
    }
    return { ok: true, o: C50.o(tang, cap) };
  }, 'REPORT');

  // ═══ AN TOÀN — CỔNG TUỔI, NỀN MÓNG, KHOÁ RIÊNG ═════════════════════
  // Cổng tuổi là cổng CHẶN, nên nó phải gọi được từ mọi nơi trong hệ thống.
  // Bảng đăng ký và kết quả soi nền móng thì là tài liệu vận hành.
  add('GET', '/an-toan/cong-tuoi', () => ({ ok: true, ...require('../an-toan/cong-tuoi').bang() }), 'ANTOAN');
  add('POST', '/an-toan/cong-tuoi/hoi', (req, body) => {
    const CT = require('../an-toan/cong-tuoi');
    const b = body || {};
    return { ok: true, ketQua: CT.choVao({
      maTinhNang: b.maTinhNang, tuoi: b.tuoi ?? null,
      cachBiet: b.cachBiet || 'KHONG_BIET', dongYGiamHo: b.dongYGiamHo || null,
    }) };
  }, 'ANTOAN');
  add('GET', '/an-toan/nen-mong', () => ({ ok: true, ...require('../an-toan/nen-mong').soiNenMong() }), 'ANTOAN');
  add('GET', '/an-toan/khoa-rieng', () => ({ ok: true, ...require('../an-toan/khoa-rieng').bang() }), 'ANTOAN');
  add('GET', '/an-toan/soi-thiet-ke', () => ({ ok: true, ...require('../an-toan/soi-thiet-ke').bang() }), 'ANTOAN');

  // ═══ THẺ ĐIỂM CÂN BẰNG — NỘI BỘ ĐIỀU HÀNH ══════════════════════════
  // Bản đồ chiến lược, sổ rủi ro và bảng nghĩa vụ pháp lý là tài liệu điều
  // hành: chúng nói rõ ta đang phòng những gì và chưa phòng được gì. Nhóm
  // CHIENLUOC mặc định mức 'quan-tri'.
  add('GET', '/chien-luoc/the-diem', () => ({ ok: true, ...require('../chien-luoc/the-diem').theDiem() }), 'CHIENLUOC');
  add('GET', '/chien-luoc/ban-do', () => ({ ok: true, ...require('../chien-luoc/ban-do').banDo() }), 'CHIENLUOC');
  add('GET', '/chien-luoc/chuoi/:ma', (req) => {
    const BD = require('../chien-luoc/ban-do');
    const ma = String(req.params.ma).toUpperCase();
    if (!BD.MT_INDEX.has(ma)) return { ok: false, error: `Không có mục tiêu "${req.params.ma}".` };
    return { ok: true, mucTieu: BD.MT_INDEX.get(ma), chuoi: BD.chuoiTu(ma) };
  }, 'CHIENLUOC');
  add('GET', '/chien-luoc/thuoc-do', () => ({ ok: true, ...require('../chien-luoc/thuoc-do').bangThuocDo() }), 'CHIENLUOC');
  add('GET', '/chien-luoc/rui-ro', () => {
    const RR = require('../chien-luoc/rui-ro');
    return { ok: true, muc: RR.MUC, ruiRo: RR.RUI_RO, soi: RR.soiRuiRo() };
  }, 'CHIENLUOC');
  add('GET', '/chien-luoc/an-toan', () => ({ ok: true, ...require('../chien-luoc/an-toan').anToan() }), 'CHIENLUOC');
  add('GET', '/chien-luoc/ra-soat', () => ({ ok: true, ...require('../chien-luoc/ra-soat').nhipRaSoat() }), 'CHIENLUOC');

  // ═══ HỆ THỐNG TRẢI NGHIỆM KHÁCH HÀNG — NỘI BỘ ĐIỀU HÀNH ════════════
  // Khung, tình huống, kênh và lưới điểm chạm là tài liệu vận hành: nó nói rõ
  // ta canh những gì và KHÔNG canh những gì. Đó là bản đồ, và bản đồ không
  // treo ngoài cửa. Nhóm TRAINGHIEM mặc định mức 'quan-tri'.
  add('GET', '/trai-nghiem/khung', () => ({ ok: true, ...require('../trai-nghiem/khung').khung() }), 'TRAINGHIEM');
  add('GET', '/trai-nghiem/tinh-huong', () => {
    const TH = require('../trai-nghiem/tinh-huong');
    return { ok: true, nhom: TH.NHOM, muc: TH.MUC, soTinhHuong: TH.TINH_HUONG.length,
      tinhHuong: TH.TINH_HUONG, banDoPhatHien: TH.banDoPhatHien() };
  }, 'TRAINGHIEM');
  add('GET', '/trai-nghiem/tinh-huong/:ma', (req) => {
    const TH = require('../trai-nghiem/tinh-huong');
    const t = TH.INDEX.get(String(req.params.ma).toUpperCase());
    return t ? { ok: true, tinhHuong: t, muc: TH.MUC[t.muc], nhom: TH.NHOM[t.nhom] }
      : { ok: false, error: `Không có tình huống "${req.params.ma}".` };
  }, 'TRAINGHIEM');
  add('GET', '/trai-nghiem/kenh', () => ({ ok: true, kenh: require('../trai-nghiem/kenh').KENH }), 'TRAINGHIEM');
  add('GET', '/trai-nghiem/luoi', () => {
    // KHÔNG trả cả 10.000 ô: nặng vô ích và không ai đọc hết. Trả thống kê
    // thật kèm một ít ô mẫu; muốn ô nào thì gọi đích danh ô ấy.
    const l = require('../trai-nghiem/luoi-cham').luoi({ mau: 3 });
    return { ok: true, ...l };
  }, 'TRAINGHIEM');
  add('GET', '/trai-nghiem/diem-cham/:tang/:cap/:tinhHuong/:kenh', (req) => {
    const LC = require('../trai-nghiem/luoi-cham');
    const d = LC.diemCham(Number(req.params.tang), Number(req.params.cap),
      req.params.tinhHuong, req.params.kenh);
    return d ? { ok: true, diemCham: d }
      : { ok: false, error: 'Không có ô này: tầng 1..5, cấp 1..10, tình huống TH01..TH40, kênh K1..K5.' };
  }, 'TRAINGHIEM');
  add('GET', '/trai-nghiem/trao-quyen', () => {
    const TQ = require('../trai-nghiem/trao-quyen');
    return { ok: true, quyen: TQ.QUYEN, trangThai: TQ.trangThai() };
  }, 'TRAINGHIEM');
  add('GET', '/trai-nghiem/phuc-hoi', () => ({ ok: true, buoc: require('../trai-nghiem/phuc-hoi').BUOC }), 'TRAINGHIEM');
  add('GET', '/trai-nghiem/do-luong', () => ({ ok: true, ...require('../trai-nghiem/do-luong').bangDo() }), 'TRAINGHIEM');

  // ═══ SỔ TAY QUY TRÌNH — NỘI BỘ ĐIỀU HÀNH ═══════════════════════════
  // Nhóm QUYTRINH mặc định mức 'quan-tri'. Sổ tay nói rõ cổng nào đóng thế nào
  // và tệp nào giữ dữ liệu gì — đó là bản đồ, và bản đồ không treo ngoài cửa.
  add('GET', '/quy-trinh/so-tay', () => {
    const ST = require('../quy-trinh/so-tay');
    return { ok: true, ...ST.soTay() };
  }, 'QUYTRINH');
  add('GET', '/quy-trinh/kich-ban/:ma', (req) => {
    const ST = require('../quy-trinh/so-tay');
    const k = ST.KICH_BAN_INDEX.get(String(req.params.ma).toUpperCase());
    return k ? { ok: true, kichBan: k, muc: ST.MUC[k.muc] }
      : { ok: false, error: `Không có kịch bản "${req.params.ma}".` };
  }, 'QUYTRINH');
  add('GET', '/quy-trinh/theo-thanh-tra/:ma', (req) => {
    const ST = require('../quy-trinh/so-tay');
    const ds = ST.theoThanhTra(String(req.params.ma).toUpperCase());
    return { ok: true, maVien: String(req.params.ma).toUpperCase(), soKichBan: ds.length, kichBan: ds };
  }, 'QUYTRINH');

  // ═══ CÂY TIỀN — NỘI BỘ ĐIỀU HÀNH, CHỈ VAI QUẢN TRỊ ══════════════════
  // Bộ định tuyến này không có lớp xác thực chung, nên MỖI tay xử lý dưới đây
  // tự gõ cửa. Thiếu một lần gọi choVaoYeuCau là thủng tường.
  const tuong = require('../cay-tien/buc-tuong');
  const canhCua = (req) => {
    const g = tuong.choVaoYeuCau(N, req);
    return g.ok ? null : { ok: false, error: g.error, reason: g.reason };
  };
  add('GET', '/cay-tien/khung', (req) => canhCua(req) || {
    ok: true, ...require('../cay-tien/khung').khung(),
  }, 'CAYTIEN');
  add('GET', '/cay-tien/vuon', (req) => canhCua(req) || {
    ok: true,
    ...require('../cay-tien/phan-loai').soiVuon({ telemetry: N.telemetry, mastery: N.mastery }),
  }, 'CAYTIEN');
  add('GET', '/cay-tien/gia-dinh/:id', (req) => canhCua(req) || {
    ok: true,
    ...require('../cay-tien/phan-loai').xepNhom(N.telemetry, req.params.id, { mastery: N.mastery }),
  }, 'CAYTIEN');

  add('GET', '/reports/chuoi-gia-tri', () => {
    const { chuoiGiaTri } = require('../nexus/diem-cham');
    const chuoi = chuoiGiaTri();
    return { ok: true, soChang: chuoi.length, chang: chuoi };
  }, 'REPORT');
  add('GET', '/reports/diem-cham', (req) => {
    const { bienBanDiemCham } = require('../nexus/diem-cham');
    const mau = Number(req.query.mau || 0);
    return { ok: true, ...bienBanDiemCham(N.telemetry, mau > 0 ? { mauToiThieu: mau } : {}) };
  }, 'REPORT');
  add('GET', '/reports/system', () => N.reports.system(), 'REPORT');
  add('GET', '/reports/class/:id', (req) => N.reports.classReport(req.params.id, { days: +(req.query.days || 30) }), 'REPORT');
  add('GET', '/reports/learner/:id', (req) => N.reports.learner(req.params.id, { days: +(req.query.days || 30) }), 'REPORT');
  add('GET', '/reports/export/:kind', (req) => {
    const r = N.reports.exportCSV(req.params.kind, req.query.id || null, { days: +(req.query.days || 30) });
    return r.ok ? { raw: r.content, contentType: 'text/csv; charset=utf-8' } : r;
  }, 'REPORT');

  // ═══ NHÓM 22 — GIỌNG NÓI GIẢNG VIÊN ═════════════════════════════════
  add('GET', '/voice/status', () => ({ ok: true, ...N.voice.status() }), 'VOICE');
  add('GET', '/voice/voices', (req) => ({
    ok: true,
    ...N.voice.listVoices({
      division: req.query.division || null,
      gender: req.query.gender || null,
      limit: Math.min(500, +(req.query.limit || 50)),
      offset: +(req.query.offset || 0),
    }),
  }), 'VOICE');
  add('GET', '/voice/voices/:voiceId', (req) => {
    const v = N.voice.voice(req.params.voiceId);
    return v ? { ok: true, voice: v } : { ok: false, error: 'VOICE_NOT_FOUND', voiceId: req.params.voiceId };
  }, 'VOICE');
  add('GET', '/voice/agent/:agentId', (req) => {
    const v = N.voice.voiceOfAgent(req.params.agentId);
    return v ? { ok: true, voice: v } : { ok: false, error: 'AGENT_NOT_FOUND', agentId: req.params.agentId };
  }, 'VOICE');

  // Soi trước khi đọc: câu này sẽ được đọc thành gì, có âm tiết nào lạ không.
  add('POST', '/voice/inspect', (req, body) => N.voice.inspect(body.text, { voiceId: body.voiceId }), 'VOICE');

  // Trả JSON kèm âm thanh base64 — dùng cho giao diện web.
  add('POST', '/voice/speak', async (req, body) => {
    const r = await N.voice.speak(body.text, {
      voiceId: body.voiceId, agentId: body.agentId, division: body.division,
      level: body.level != null ? +body.level : null, learnerId: body.learnerId || null,
      rate: body.rate != null ? +body.rate : null, prefer: body.provider || null,
      audible: body.audibleMark !== false,
    });
    if (!r.ok) return r;
    const { wav, ...rest } = r;
    return { ...rest, ok: true, audioBase64: wav.toString('base64'), bytes: wav.length };
  }, 'VOICE');

  // Trả thẳng tệp WAV — dùng cho thẻ <audio src="...">.
  add('GET', '/voice/say', async (req) => {
    const r = await N.voice.speak(req.query.text, {
      voiceId: req.query.voiceId || null, agentId: req.query.agentId || null,
      level: req.query.level != null ? +req.query.level : null,
      learnerId: req.query.learnerId || null,
      rate: req.query.rate != null ? +req.query.rate : null,
      audible: req.query.mark !== '0',
    });
    if (!r.ok) return r;
    return { raw: r.wav, contentType: r.mime || 'audio/wav' };
  }, 'VOICE');

  // ── PHÁT ÂM TIẾNG ANH ────────────────────────────────────────────────────
  // Nhóm này phục vụ dạy phát âm: phiên âm IPA, chẩn đoán lỗi người Việt,
  // cặp tối thiểu, và đọc thành tiếng bằng bộ tổng hợp formant.
  add('GET', '/en/phien-am', (req) => {
    if (!req.query.tu) return { status: 400, body: { ok: false, error: 'THIẾU_TỪ', need: ['tu'] } };
    return N.voice.phienAmAnh(req.query.tu, { giong: req.query.giong || 'Anh' });
  }, 'PHATAM');

  add('POST', '/en/phien-am-cau', (req, body) => {
    if (!body.text) return { status: 400, body: { ok: false, error: 'THIẾU_NỘI_DUNG', need: ['text'] } };
    return N.voice.phienAmCauAnh(body.text, { giong: body.giong || 'Anh', nhanh: body.nhanh !== false });
  }, 'PHATAM');

  add('GET', '/en/chan-doan', (req) => {
    if (!req.query.tu) return { status: 400, body: { ok: false, error: 'THIẾU_TỪ', need: ['tu'] } };
    return N.voice.chanDoanAnh(req.query.tu, { giong: req.query.giong || 'Anh' });
  }, 'PHATAM');

  add('GET', '/en/the-doi-lap', (req) => ({
    ok: true,
    theDoiLap: N.voice.theDoiLapAnh({ toiThieu: req.query.toiThieu != null ? +req.query.toiThieu : 2 }),
  }), 'PHATAM');

  add('GET', '/en/bai-hoc-am', (req) => {
    const { am1, am2 } = req.query;
    if (!am1 || !am2) return { status: 400, body: { ok: false, error: 'THIẾU_ÂM', need: ['am1', 'am2'] } };
    const r = N.voice.baiHocAmAnh(am1, am2, { soCap: req.query.soCap != null ? +req.query.soCap : 8 });
    return r.ok ? { ok: true, ...r } : { status: 404, body: r };
  }, 'PHATAM');

  // Trả thẳng WAV — dùng cho thẻ <audio>.
  add('GET', '/en/doc', (req) => {
    if (!req.query.text) return { status: 400, body: { ok: false, error: 'THIẾU_NỘI_DUNG', need: ['text'] } };
    const r = N.voice.docAnh(req.query.text, {
      giong: req.query.giong || 'Anh',
      nhanh: req.query.nhanh !== '0',
      rate: req.query.rate != null ? +req.query.rate : 1.0,
    });
    if (!r.ok) return r;
    return { raw: r.wav, contentType: 'audio/wav' };
  }, 'PHATAM');

  add('GET', '/en/doc-cap', (req) => {
    const { tu1, tu2 } = req.query;
    if (!tu1 || !tu2) return { status: 400, body: { ok: false, error: 'THIẾU_TỪ', need: ['tu1', 'tu2'] } };
    const r = N.voice.docCapAnh(tu1, tu2, { giong: req.query.giong || 'Anh' });
    if (!r.ok) return r;
    return { raw: r.wav, contentType: 'audio/wav' };
  }, 'PHATAM');

  // Đọc phần [NGHE]…[/NGHE] của một bài nghe trong kho.
  add('GET', '/en/bai-nghe/:itemId', (req) => {
    const it = N.bank.get(req.params.itemId);
    if (!it) return { status: 404, body: { ok: false, error: 'KHÔNG_CÓ_BÀI', itemId: req.params.itemId } };
    const r = N.voice.docBaiNghe(it.stem, { giong: req.query.giong || 'Anh' });
    if (!r.ok) return { status: 400, body: r };
    return { raw: r.wav, contentType: 'audio/wav' };
  }, 'PHATAM');

  // Kịch bản giảng bài. render=1 thì trả kèm từng đoạn âm thanh.
  add('POST', '/voice/narrate', async (req, body) => {
    const target = body.item || body.itemId;
    if (!target) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['itemId hoặc item'] } };
    const r = await N.voice.narrateItem(target, {
      level: body.level != null ? +body.level : 3,
      mode: body.mode || 'chua',
      learnerId: body.learnerId || null,
      agentId: body.agentId || null,
      voiceId: body.voiceId || null,
      render: !!body.render,
      disclose: body.disclose !== false,
    });
    if (!r.ok || !r.audio) return r;
    const { audio, ...rest } = r;
    return { ...rest, audio: audio.map((a) => ({ role: a.role, ms: a.ms, pauseAfterMs: a.pauseAfterMs, audioBase64: a.wav.toString('base64') })) };
  }, 'VOICE');

  add('POST', '/voice/narrate-text', (req, body) => N.voice.narration.forText(body.text, {
    level: body.level != null ? +body.level : 5, disclose: !!body.disclose,
  }), 'VOICE');

  // ── Pháp lý ──
  add('GET', '/voice/disclosure', () => ({ ok: true, ...require('../voice/compliance').DISCLOSURE }), 'VOICE');
  add('GET', '/voice/compliance', () => ({ ok: true, ...N.voice.compliance.status() }), 'VOICE');
  add('GET', '/voice/consent-kinds', () => ({ ok: true, kinds: Object.values(require('../voice/compliance').CONSENT_KINDS) }), 'VOICE');
  add('POST', '/voice/consent', (req, body) => N.voice.compliance.consents.grant(body), 'VOICE');
  add('GET', '/voice/consent/:subjectId', (req) => ({
    ok: true, subjectId: req.params.subjectId,
    consents: N.voice.compliance.consents.ofSubject(req.params.subjectId),
  }), 'VOICE');
  add('POST', '/voice/consent/:consentId/revoke', (req, body) =>
    N.voice.compliance.consents.revoke(req.params.consentId, body.reason || 'chủ thể yêu cầu'), 'VOICE');
  add('POST', '/voice/forget', (req, body) => {
    if (!body.subjectId) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['subjectId'] } };
    return N.voice.compliance.forget(body.subjectId, { reason: body.reason });
  }, 'VOICE');
  add('POST', '/voice/verify-audio', (req, body) => {
    if (!body.audioBase64) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['audioBase64'] } };
    return N.voice.compliance.verifyAudio(Buffer.from(body.audioBase64, 'base64'));
  }, 'VOICE');
  add('GET', '/voice/audit', (req) => ({ ok: true, entries: N.voice.compliance.audit.recent(+(req.query.limit || 50)), chain: N.voice.compliance.audit.verify() }), 'VOICE');
  add('POST', '/voice/retention-sweep', (req, body) => N.voice.compliance.sweepRetention({
    retentionDays: body.retentionDays != null ? +body.retentionDays : undefined,
  }), 'VOICE');
  add('POST', '/voice/cache/clear', () => ({ ok: true, cleared: N.voice.cache.clear() }), 'VOICE');

  // ── Tuyến chuyên biệt và hậu kỳ phòng thu ──
  add('GET', '/voice/pipelines', () => ({
    ok: true,
    speech: N.voice.speechPipeline.status(),
    singing: N.voice.singingPipeline.status(),
    conversion: N.voice.conversionPipeline.status(),
  }), 'VOICE');
  add('GET', '/voice/studio/presets', () => ({ ok: true, engine: 'JS_DSP', presets: require('../voice/dsp').StudioChain.presets() }), 'VOICE');
  add('POST', '/voice/studio/master', (req, body) => {
    if (!body.audioBase64) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['audioBase64'] } };
    const r = N.voice.master(Buffer.from(body.audioBase64, 'base64'), { preset: body.preset || 'giang-bai' });
    if (!r.ok) return r;
    const { wav, ...rest } = r;
    return { ...rest, ok: true, audioBase64: wav.toString('base64'), bytes: wav.length };
  }, 'VOICE');

  // ── Nhạc lý: ký âm chữ ⇄ tệp MIDI ──
  add('POST', '/voice/music/parse', (req, body) => {
    const M = require('../voice/music');
    if (body.midiBase64) {
      const m = M.parseMidi(Buffer.from(body.midiBase64, 'base64'));
      if (!m.ok) return m;
      const lead = M.extractLeadLine(m.notes, { track: body.track ?? null, channel: body.channel ?? null });
      return { ok: true, source: 'midi', format: m.format, bpm: m.bpm, tracks: m.tracks,
        totalNotes: m.notes.length, leadNotes: lead.length, totalMs: m.totalMs, notes: lead.slice(0, 400) };
    }
    if (!body.melody) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['melody hoặc midiBase64'] } };
    const m = M.parseMelody(body.melody, { bpm: body.bpm != null ? +body.bpm : 90 });
    return m.ok ? { ok: true, source: 'ký âm chữ', ...m } : { ok: false, error: 'KÝ_ÂM_SAI', errors: m.errors };
  }, 'VOICE');
  add('POST', '/voice/music/export-midi', (req, body) => {
    const M = require('../voice/music');
    if (!body.melody) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['melody'] } };
    const bpm = body.bpm != null ? +body.bpm : 90;
    const m = M.parseMelody(body.melody, { bpm });
    if (!m.ok) return { ok: false, error: 'KÝ_ÂM_SAI', errors: m.errors };
    const buf = M.writeMidi(m.notes, { bpm });
    return { ok: true, bpm, notes: m.notes.length, bytes: buf.length, midiBase64: buf.toString('base64') };
  }, 'VOICE');

  // ── Hát ──
  add('GET', '/voice/song/styles', () => ({
    ok: true,
    styles: Object.entries(require('../voice/singing').STYLES).map(([id, s]) => ({ id, name: s.name, vibrato: s.vibratoDepth, toneBlend: s.toneBlend, note: `rung ${s.vibratoRate}Hz · luyến ${s.portamentoMs}ms` })),
    ranges: Object.entries(require('../voice/music').RANGES).map(([id, r]) => ({ id, name: r.name, lo: r.lo, hi: r.hi })),
  }), 'VOICE');
  add('POST', '/voice/song/check', (req, body) => {
    if (!body.lyrics) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['lyrics'] } };
    return N.voice.checkSong({
      lyrics: body.lyrics, melody: body.melody || null,
      midi: body.midiBase64 ? Buffer.from(body.midiBase64, 'base64') : null,
      bpm: body.bpm != null ? +body.bpm : 90, range: body.range || null,
      track: body.track ?? null, channel: body.channel ?? null,
    });
  }, 'VOICE');
  add('POST', '/voice/song/sing', async (req, body) => {
    if (!body.lyrics) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['lyrics'] } };
    const r = await N.voice.sing({
      lyrics: body.lyrics, melody: body.melody || null, midi: body.midiBase64 || null,
      bpm: body.bpm != null ? +body.bpm : 90, style: body.style || 'pop',
      range: body.range || null, voiceId: body.voiceId || null, agentId: body.agentId || null,
      learnerId: body.learnerId || null, studio: body.studio !== false, preset: body.preset || null,
      track: body.track ?? null, channel: body.channel ?? null, lang: body.lang || 'vi',
    });
    if (!r.ok) return r;
    const { wav, ...rest } = r;
    return { ...rest, ok: true, audioBase64: wav.toString('base64'), bytes: wav.length };
  }, 'VOICE');
  add('POST', '/voice/song/convert', async (req, body) => {
    if (!body.audioBase64) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['audioBase64'] } };
    const r = await N.voice.convertSinging({
      sourceWav: Buffer.from(body.audioBase64, 'base64'),
      singerId: body.singerId || null, targetOwnerId: body.targetOwnerId || null,
      targetVoice: body.targetVoice || '', pitchShift: body.pitchShift != null ? +body.pitchShift : 0,
      studio: body.studio !== false, preset: body.preset || 'hat-pop',
    });
    if (!r.ok) return r;
    const { wav, ...rest } = r;
    return { ...rest, ok: true, audioBase64: wav.toString('base64'), bytes: wav.length };
  }, 'VOICE');

  // ═══ NHÓM 23 — SẢN XUẤT PHIM ════════════════════════════════════════
  add('GET', '/film/status', () => ({ ok: true, ...N.film.status() }), 'FILM');
  add('GET', '/film/models', () => ({ ok: true, models: require('../film/models').lietKe(), uuTien: Object.entries(require('../film/models').UU_TIEN).map(([id, u]) => ({ id, ten: u.name })) }), 'FILM');
  add('GET', '/film/sample-script', () => {
    const p = path.join(__dirname, '..', '..', 'kich-ban-mau', 'nguoi-thay-cuoi-cung.txt');
    if (!fs.existsSync(p)) return { ok: false, error: 'NOT_FOUND' };
    return { raw: fs.readFileSync(p, 'utf8'), contentType: 'text/plain; charset=utf-8' };
  }, 'FILM');

  // Đọc kịch bản mà không tạo dự án — dùng để soi nhanh khi đang viết.
  add('POST', '/film/parse', (req, body) => {
    if (!body.kichBan) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['kichBan'] } };
    return require('../film/screenplay').docKichBan(body.kichBan);
  }, 'FILM');

  // NẤC 1 — tiền kỳ, không tốn đồng nào
  add('POST', '/film/prepare', (req, body) => {
    if (!body.kichBan) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['kichBan'] } };
    return N.film.chuanBi(body.kichBan, {
      uuTien: body.uuTien || undefined,
      phongCach: body.phongCach || null,
      nganSachUsd: body.nganSachUsd != null ? +body.nganSachUsd : null,
      ghiDeNhanVat: body.ghiDeNhanVat || {},
    });
  }, 'FILM');

  add('GET', '/film/projects', (req) => N.film.danhSach({ limit: Math.min(100, +(req.query.limit || 30)) }), 'FILM');
  add('GET', '/film/projects/:id', (req) => {
    const d = N.film.layDuAn(req.params.id);
    if (!d.ok) return d;
    return { ok: true, ...N.film._tomTat(d), canhQuay: d.canhQuay, kichBan: { canh: d.kichBan.canh.length, thongKe: d.kichBan.thongKe } };
  }, 'FILM');
  add('GET', '/film/projects/:id/shots', (req) => {
    const d = N.film.layDuAn(req.params.id);
    return d.ok ? { ok: true, duAn: d.id, canhQuay: d.canhQuay } : d;
  }, 'FILM');
  add('POST', '/film/projects/:id/delete', (req) => N.film.xoaDuAn(req.params.id), 'FILM');

  // NẤC 2 — bản nháp: đường tiếng thật + bảng phân cảnh + phim nháp
  add('POST', '/film/projects/:id/draft', async (req, body) => {
    const r = await N.film.dungNhap(req.params.id, { preset: body.preset || 'phat-thanh', keoTheoTieng: body.tieng !== false });
    if (!r.ok) return r;
    const { duongTiengWav, phimNhapHtml, bangPhanCanh, ghepPhim, edl, ...rest } = r;
    return {
      ...rest, ok: true,
      duongTiengBase64: duongTiengWav ? duongTiengWav.toString('base64') : null,
      bangPhanCanh: bangPhanCanh.map((b) => b.id),
      coPhimNhap: true, coEdl: true, coKichBanGhep: true,
    };
  }, 'FILM');

  // Xem phim nháp ngay trên trình duyệt
  add('GET', '/film/projects/:id/animatic', async (req) => {
    const r = await N.film.dungNhap(req.params.id, { keoTheoTieng: req.query.tieng !== '0' });
    if (!r.ok) return r;
    return { raw: r.phimNhapHtml, contentType: 'text/html; charset=utf-8' };
  }, 'FILM');
  add('GET', '/film/projects/:id/soundtrack', async (req) => {
    const r = await N.film.dungNhap(req.params.id);
    if (!r.ok) return r;
    if (!r.duongTiengWav) return { ok: false, error: 'CHƯA_CÓ_ĐƯỜNG_TIẾNG' };
    return { raw: r.duongTiengWav, contentType: 'audio/wav' };
  }, 'FILM');
  add('GET', '/film/projects/:id/storyboard/:shot', (req) => {
    const d = N.film.layDuAn(req.params.id);
    if (!d.ok) return d;
    const cq = d.canhQuay.find((c) => c.id === req.params.shot);
    if (!cq) return { ok: false, error: 'NOT_FOUND', canhQuay: req.params.shot };
    return { raw: require('../film/storyboard').veKhung(cq, d.nhanVat, { rong: 960, cao: 540 }), contentType: 'image/svg+xml; charset=utf-8' };
  }, 'FILM');
  add('GET', '/film/projects/:id/edl', (req) => {
    const d = N.film.layDuAn(req.params.id);
    if (!d.ok) return d;
    return { raw: require('../film/assemble').dungEDL(d.canhQuay, { tieuDe: d.tieuDe }), contentType: 'text/plain; charset=utf-8' };
  }, 'FILM');
  add('GET', '/film/projects/:id/ffmpeg', (req) => {
    const d = N.film.layDuAn(req.params.id);
    if (!d.ok) return d;
    const g = require('../film/assemble').dungKichBanGhep(d.canhQuay, { tenPhim: d.id.toLowerCase() });
    return { raw: g.sh, contentType: 'text/x-shellscript; charset=utf-8' };
  }, 'FILM');

  // NẤC 3 — dựng thật, có chốt chi tiêu
  add('POST', '/film/projects/:id/render', async (req, body) => N.film.dungThat(req.params.id, {
    xacNhan: !!body.xacNhan,
    tranUsd: body.tranUsd != null ? +body.tranUsd : null,
    chiCanhQuay: Array.isArray(body.chiCanhQuay) ? body.chiCanhQuay : null,
  }), 'FILM');

  // ═══ NHÓM 24 — XƯỞNG ẢNH ════════════════════════════════════════════
  add('GET', '/photo/status', () => ({ ok: true, ...N.photo.status() }), 'PHOTO');
  add('GET', '/photo/cameras', () => ({
    ok: true,
    mayAnh: require('../photo/profiles').lietKeMayAnh(),
    phim: require('../photo/profiles').lietKePhim(),
  }), 'PHOTO');
  add('GET', '/photo/compositions', (req) => {
    const { boCucCho, KIEU_ANH, BO_CUC } = require('../photo/composition');
    const k = req.query.kieuAnh;
    return {
      ok: true,
      kieuAnh: Object.entries(KIEU_ANH).map(([id, ten]) => ({ id, ten })),
      boCuc: k ? boCucCho(k) : Object.entries(BO_CUC).map(([id, b]) => ({ id, ten: b.ten, chuThe: b.chuThe, hop: b.hop })),
    };
  }, 'PHOTO');
  add('GET', '/photo/compare-cameras', (req) => {
    const { soSanh } = require('../photo/profiles');
    const { lechDuKien } = require('../photo/qc');
    const a = req.query.a || 'Hasselblad';
    const b = req.query.b || 'ARRI';
    return { ok: true, a, b, khacBiet: soSanh(a, b), chatMauChuY: { [a]: lechDuKien(a, 'Khong'), [b]: lechDuKien(b, 'Khong') } };
  }, 'PHOTO');

  // Tầng 1–2: dựng prompt, chọn bố cục, vẽ khung dựng — không cần mạng
  add('POST', '/photo/prepare', (req, body) => {
    if (!body.moTa) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['moTa'] } };
    const r = N.photo.chuanBi(body.moTa, body);
    if (!r.ok) return r;
    const { khungDung, ...rest } = r;
    return { ...rest, ok: true, khungDungByte: khungDung.length };
  }, 'PHOTO');
  add('POST', '/photo/framing', (req, body) => {
    if (!body.moTa) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['moTa'] } };
    const r = N.photo.chuanBi(body.moTa, body);
    return r.ok ? { raw: r.khungDung, contentType: 'image/svg+xml; charset=utf-8' } : r;
  }, 'PHOTO');

  // Tầng 3–8: hậu kỳ trên ảnh có sẵn — không cần mạng, không cần khoá
  add('POST', '/photo/enhance', (req, body) => {
    if (!body.anhBase64) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['anhBase64'] } };
    const r = N.photo.hauKy(Buffer.from(body.anhBase64, 'base64'), body);
    if (!r.ok) return r;
    const x = N.photo.xuat(r.anh, { mayAnh: r.mayAnh, exif: r.exif });
    const { anh, ...rest } = r;
    return {
      ...rest, ok: true,
      pngBase64: body.traPng === false ? null : x.png.toString('base64'),
      jpegBase64: x.jpeg.toString('base64'),
      bytePng: x.bytePng, byteJpeg: x.byteJpeg, sieuDuLieu: x.sieuDuLieu,
    };
  }, 'PHOTO');
  add('POST', '/photo/measure', (req, body) => {
    if (!body.anhBase64) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['anhBase64'] } };
    const d = N.photo.doc(Buffer.from(body.anhBase64, 'base64'));
    if (!d.ok) return d;
    // Đo xong là ĐO THÀNH CÔNG, kể cả khi ảnh chấm điểm thấp. Trả `ok:false`
    // ở đây thì lớp HTTP hiểu nhầm thành lỗi gọi API và trả 400 — người dùng
    // tưởng gửi sai, trong khi thực ra chỉ là ảnh chưa đạt.
    const { ok: dat, ...ketQua } = require('../photo/qc').soat(
      { width: d.width, height: d.height, data: d.data },
      { mayAnh: body.mayAnh || null, phim: body.phim || null },
    );
    return { ok: true, dang: d.dang, dat, ...ketQua };
  }, 'PHOTO');

  // Cửa 3: sinh ảnh qua dịch vụ ngoài rồi chạy tiếp tầng 3–8
  add('POST', '/photo/generate', async (req, body) => {
    if (!body.moTa) return { status: 400, body: { ok: false, error: 'MISSING_INPUT', need: ['moTa'] } };
    const r = await N.photo.tao(body.moTa, body);
    if (!r.ok) return r;
    const x = N.photo.xuat(r.anh, { mayAnh: r.mayAnh, exif: r.exif });
    const { anh, ke, ...rest } = r;
    return {
      ...rest, ok: true,
      prompt: ke.prompt, boCuc: ke.boCucTen, ongKinh: ke.ongKinhTen, anhSang: ke.anhSangTen,
      jpegBase64: x.jpeg.toString('base64'), byteJpeg: x.byteJpeg,
    };
  }, 'PHOTO');
  add('GET', '/photo/jobs', (req) => N.photo.danhSach({ limit: Math.min(100, +(req.query.limit || 30)) }), 'PHOTO');

  // ═══ NHÓM 25 — BÀI GIẢNG ═════════════════════════════════════════════
  // Một lệnh: học liệu (hoặc kịch bản, hoặc chủ đề) → khung hình → giọng đọc
  // → tệp video xem được. Tất cả chạy trong tiến trình: không ffmpeg, không
  // dịch vụ ngoài, không tính tiền.
  add('GET', '/lesson/status', () => ({ ok: true, ...N.baiGiang.status() }), 'BAIGIANG');

  // Danh mục dạng bài dựng được ngay từ kho đã thẩm định — không cần khoá.
  add('GET', '/lesson/forms', (req) => {
    const { FORM_INDEX } = require('../curriculum/hierarchy');
    const tim = String(req.query.tim || '').toLowerCase().trim();
    const ds = [...FORM_INDEX.values()]
      .filter((f) => !tim || f.code.toLowerCase().includes(tim) || f.name.toLowerCase().includes(tim))
      .map((f) => ({ ma: f.code, ten: f.name, tang: f.levelRange, soBay: (f.traps || []).length }));
    return { ok: true, tong: ds.length, items: ds.slice(0, Math.min(500, +(req.query.limit || 100))) };
  }, 'BAIGIANG');

  // Gõ chủ đề bằng tiếng Việt → dạng bài khớp nhất trong chương trình.
  add('GET', '/lesson/match', (req) => {
    const q = String(req.query.chuDe || req.query.q || '').trim();
    if (!q) return { status: 400, body: { ok: false, error: 'THIẾU_CHỦ_ĐỀ', need: ['chuDe'] } };
    return { ok: true, chuDe: q, ...N.baiGiang.timDang(q) };
  }, 'BAIGIANG');

  // Soạn dàn ý mà KHÔNG dựng video — xem trước rồi mới quyết định dựng.
  add('POST', '/lesson/outline', async (req, body) => {
    if (body.maDang) return N.baiGiang.soanTuKho(body.maDang, body);
    if (body.kichBan) return N.baiGiang.soanTuKichBan(body.kichBan, body);
    if (body.chuDe) return N.baiGiang.soanBangMoHinh(body.chuDe, body);
    return {
      status: 400,
      body: { ok: false, error: 'THIẾU_NGUỒN_NỘI_DUNG', need: ['maDang | kichBan | chuDe'] },
    };
  }, 'BAIGIANG');

  // Dựng thật. Tệp video có thể vài chục MB nên mặc định KHÔNG nhét vào JSON:
  // trả siêu dữ liệu + mốc thời gian, tải tệp riêng ở /lesson/:id/video.
  add('POST', '/lesson/build', async (req, body) => {
    const r = await N.baiGiang.tao({ ...body, thuMuc: body.luuDia === false ? null : cfg.BAIGIANG.thuMuc });
    if (!r.ok) return r;
    const { video, khungAnh, ...meta } = r;
    _videoCache.set(meta.id, video);
    if (_videoCache.size > 8) _videoCache.delete(_videoCache.keys().next().value);
    return { ...meta, ok: true, taiVe: `/lesson/${meta.id}/video` };
  }, 'BAIGIANG');

  add('GET', '/lesson/jobs', (req) => N.baiGiang.danhSach({ limit: Math.min(100, +(req.query.limit || 30)) }), 'BAIGIANG');
  add('GET', '/lesson/:id', (req) => N.baiGiang.lay(req.params.id), 'BAIGIANG');

  // Tệp video: ưu tiên bộ nhớ đệm phiên này, hết đệm thì đọc lại từ đĩa.
  add('GET', '/lesson/:id/video', (req) => {
    const id = req.params.id;
    const dem = _videoCache.get(id);
    if (dem) return { raw: dem, contentType: 'video/x-msvideo' };
    const tep = path.join(cfg.BAIGIANG.thuMuc, id, 'bai-giang.avi');
    if (!fs.existsSync(tep)) return { ok: false, error: 'KHÔNG_TÌM_THẤY_TỆP_VIDEO', id };
    return { raw: fs.readFileSync(tep), contentType: 'video/x-msvideo' };
  }, 'BAIGIANG');

  // ═══ NHÓM 26 — KHOA HỌC TOÁN ═════════════════════════════════════════
  // Đọc vị đề · pháp đồ giải · nhiều cách giải · trình bày chuẩn sách giáo
  // khoa · phiếu học tập. Toàn bộ phần tính toán chạy bằng bộ máy toán nội
  // bộ: không cần khoá, không cần mạng, và kết quả kiểm lại được.
  //
  // Đặt dưới /scientist chứ không phải /math: nhánh /math đã thuộc về bộ xác
  // minh học liệu (nhóm AUTHORING, /math/verify · /math/solve · /math/
  // check-roots). Hai route cùng đường dẫn thì route đăng ký trước thắng và
  // route sau chết lặng — một lỗi không có thông báo nào báo cho biết.
  add('GET', '/scientist/status', () => ({ ok: true, ...N.scientist.status() }), 'KHOAHOC');

  add('POST', '/scientist/analyze', (req, body) => {
    if (!body.deBai) return { status: 400, body: { ok: false, error: 'THIẾU_ĐỀ_BÀI', need: ['deBai'] } };
    return N.scientist.docVi(body.deBai);
  }, 'KHOAHOC');

  add('POST', '/scientist/plan', (req, body) => {
    if (!body.deBai) return { status: 400, body: { ok: false, error: 'THIẾU_ĐỀ_BÀI', need: ['deBai'] } };
    const dv = N.scientist.docVi(body.deBai);
    if (!dv.ok) return dv;
    return { ...N.scientist.phapDo(dv), docVi: dv };
  }, 'KHOAHOC');

  add('POST', '/scientist/solve', (req, body) => {
    if (!body.deBai) return { status: 400, body: { ok: false, error: 'THIẾU_ĐỀ_BÀI', need: ['deBai'] } };
    return N.scientist.giaiDaCach(body.deBai);
  }, 'KHOAHOC');

  add('POST', '/scientist/present', (req, body) => {
    if (!body.deBai) return { status: 400, body: { ok: false, error: 'THIẾU_ĐỀ_BÀI', need: ['deBai'] } };
    return N.scientist.trinhBay(body.deBai, { cach: +(body.cach || 1) });
  }, 'KHOAHOC');

  add('POST', '/scientist/worksheet', (req, body) => {
    const d = body.maDang || body.chuDe;
    if (!d) return { status: 400, body: { ok: false, error: 'THIẾU_ĐỀ_BÀI', need: ['maDang hoặc chuDe'] } };
    const p = N.scientist.phieuHocTap(d, { soBai: Math.min(20, +(body.soBai || 8)) });
    if (!p.ok) return p;
    return body.dangChu ? { raw: N.scientist.phieuRaChu(p), contentType: 'text/markdown; charset=utf-8' } : p;
  }, 'KHOAHOC');

  add('POST', '/scientist/method', (req, body) => {
    if (!body.vanDe) return { status: 400, body: { ok: false, error: 'THIẾU_MÔ_TẢ_VẤN_ĐỀ', need: ['vanDe'] } };
    return N.scientist.ghepPhuongPhap(body.vanDe, { soDeXuat: Math.min(8, +(body.soDeXuat || 4)) });
  }, 'KHOAHOC');

  add('GET', '/scientist/methods', () => {
    const { PHUONG_PHAP } = require('../math/scientist');
    return { ok: true, tong: Object.keys(PHUONG_PHAP).length,
      items: Object.entries(PHUONG_PHAP).map(([id, p]) => ({ id, ten: p.ten, nhom: p.nhom, moTa: p.moTa })) };
  }, 'KHOAHOC');

  add('POST', '/scientist/cross-subject', async (req, body) => {
    if (!body.chuDe) return { status: 400, body: { ok: false, error: 'THIẾU_ĐỀ_BÀI', need: ['chuDe'] } };
    return N.scientist.lienMon(body.chuDe);
  }, 'KHOAHOC');

  // Hai cửa soát dùng chung cho mọi nội dung toán của hệ thống.
  add('POST', '/scientist/normalize', (req, body) => {
    const { chuanHoa, kiemKyHieu } = require('../math/kyhieu');
    if (typeof body.text !== 'string') return { status: 400, body: { ok: false, error: 'THIẾU_VĂN_BẢN', need: ['text'] } };
    const ra = chuanHoa(body.text, body);
    return { ok: true, vao: body.text, ra, doiKhac: ra !== body.text, soat: kiemKyHieu(ra) };
  }, 'KHOAHOC');

  add('POST', '/scientist/validate', (req, body) => {
    const { thamDinh } = require('../math/thamdinh');
    if (typeof body.text !== 'string') return { status: 400, body: { ok: false, error: 'THIẾU_VĂN_BẢN', need: ['text'] } };
    // Thẩm định XONG là gọi thành công, kể cả khi bài không đạt. Để `ok` của
    // kết quả thẩm định tràn ra ngoài thì lớp HTTP trả 400 và người gọi tưởng
    // mình gửi sai — đúng cái bẫy đã gặp ở /photo/measure.
    const kq = thamDinh(body.text, { loai: body.loai || 'bai-giai' });
    return { ...kq, ok: true, dat: kq.dat };
  }, 'KHOAHOC');

  // ═══ NHÓM 27 — KHOA HỌC NGÔN NGỮ ═════════════════════════════════════
  // Chuẩn tiếng Việt cho học liệu: chính tả theo luật cấu tạo âm tiết, văn
  // phong sách giáo khoa, độ đọc theo lớp, từ vựng theo lớp. Chạy hoàn toàn
  // trong tiến trình, không cần khoá.
  add('GET', '/lang/status', () => ({ ok: true, ...N.linguist.status() }), 'NGONNGU');

  add('POST', '/lang/check', (req, body) => {
    if (typeof body.text !== 'string') return { status: 400, body: { ok: false, error: 'THIẾU_VĂN_BẢN', need: ['text'] } };
    // Soát XONG là gọi thành công, kể cả khi văn bản không đạt.
    const r = N.linguist.soat(body.text, { lop: body.lop || null, loai: body.loai || 'tu-do', kieuDau: body.kieuDau || 'tudo' });
    return { ...r, ok: true, dat: r.dat };
  }, 'NGONNGU');

  add('POST', '/lang/normalize', (req, body) => {
    if (typeof body.text !== 'string') return { status: 400, body: { ok: false, error: 'THIẾU_VĂN_BẢN', need: ['text'] } };
    const ra = N.linguist.chuanHoa(body.text, { kieuDau: body.kieuDau || null });
    return { ok: true, vao: body.text, ra, doiKhac: ra !== body.text };
  }, 'NGONNGU');

  add('POST', '/lang/readability', (req, body) => {
    if (typeof body.text !== 'string') return { status: 400, body: { ok: false, error: 'THIẾU_VĂN_BẢN', need: ['text'] } };
    const { doDoc, hopVoiLop, doanLop } = require('../lang/docde');
    if (body.lop) {
      const r = hopVoiLop(body.text, body.lop);
      return r.error ? r : { ...r, ok: true, vuaSuc: r.ok };
    }
    return { ok: true, doDo: doDoc(body.text), ...doanLop(body.text) };
  }, 'NGONNGU');

  add('POST', '/lang/syllables', (req, body) => {
    if (typeof body.text !== 'string') return { status: 400, body: { ok: false, error: 'THIẾU_VĂN_BẢN', need: ['text'] } };
    return N.linguist.amTiet(body.text);
  }, 'NGONNGU');

  add('POST', '/lang/sentences', (req, body) => {
    if (typeof body.text !== 'string') return { status: 400, body: { ok: false, error: 'THIẾU_VĂN_BẢN', need: ['text'] } };
    return N.linguist.phanTichCau(body.text);
  }, 'NGONNGU');

  add('GET', '/lang/vocabulary/:lop', (req) => N.linguist.tuVung.theoLop(req.params.lop), 'NGONNGU');
  add('GET', '/lang/term', (req) => {
    const t = String(req.query.tu || '').trim();
    if (!t) return { status: 400, body: { ok: false, error: 'THIẾU_VĂN_BẢN', need: ['tu'] } };
    const v = N.linguist.tuVung.capDo(t);
    return { ok: true, tu: t, ...(v ? { lopDay: v.lop, nguon: v.nguon } : { lopDay: null, ghiChu: 'Không có trong từ vựng toán của chương trình.' }) };
  }, 'NGONNGU');

  add('POST', '/lang/lesson', (req, body) => {
    const d = body.maDang || body.chuDe;
    if (!d) return { status: 400, body: { ok: false, error: 'THIẾU_NGUỒN_NỘI_DUNG', need: ['maDang hoặc chuDe'] } };
    const b = N.linguist.baiHoc4KyNang(d, { soBai: Math.min(10, +(body.soBai || 3)) });
    if (!b.ok) return b;
    return body.dangChu ? { raw: N.linguist.baiHocRaChu(b), contentType: 'text/markdown; charset=utf-8' } : b;
  }, 'NGONNGU');

  add('GET', '/lang/audit-bank', (req) => N.linguist.auditKho({
    limitMoiDang: Math.min(200, +(req.query.limit || 50)),
    chiLoi: req.query.tatCa !== '1',
  }), 'NGONNGU');

  add('GET', '/lang/diagnose/:learnerId', (req) => N.linguist.chanDoan(req.params.learnerId), 'NGONNGU');

  // ═══ ĐĂNG NHẬP BẰNG KHUÔN MẶT THẬT ══════════════════════════════════
  //
  // Bốn cổng ĐĂNG KÝ và QUẢN LÝ đòi phiên đang đăng nhập — tin cậy phải bắt
  // nguồn từ một lần xác thực đã có. Hai cổng ĐĂNG NHẬP phải công khai, vì
  // chính chúng là chỗ người dùng vào.

  add('GET', '/khuon-mat', () => (N.khuonMat
    ? { ok: true, ...N.khuonMat.status() }
    : { status: 503, body: { ok: false, error: 'CHUA_BAT' } }), 'KHUONMAT');

  add('POST', '/khuon-mat/xin-dang-ky', (req) => {
    const t = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
      || require('../api/cong-quyen').docCookie(req.headers.cookie, 'gita_token');
    const r = N.accounts.xinDangKyKhuonMat(t);
    return r.ok ? r : { status: 401, body: r };
  }, 'KHUONMAT');

  add('POST', '/khuon-mat/dang-ky', (req, body) => {
    const t = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
      || require('../api/cong-quyen').docCookie(req.headers.cookie, 'gita_token');
    const r = N.accounts.ghiKhuonMat(t, body, { dongYGiamHo: body.dongYGiamHo || null, ip: req.ip });
    return r.ok ? r : { status: r.error === 'INVALID_SESSION' ? 401 : 400, body: r };
  }, 'KHUONMAT');

  add('GET', '/khuon-mat/may', (req) => {
    const t = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
      || require('../api/cong-quyen').docCookie(req.headers.cookie, 'gita_token');
    const r = N.accounts.dsKhuonMat(t);
    return r.ok ? r : { status: 401, body: r };
  }, 'KHUONMAT');

  add('DELETE', '/khuon-mat/may/:maKhoa', (req) => {
    const t = (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
      || require('../api/cong-quyen').docCookie(req.headers.cookie, 'gita_token');
    const r = N.accounts.goKhuonMat(t, req.params.maKhoa);
    return r.ok ? r : { status: r.error === 'INVALID_SESSION' ? 401 : 404, body: r };
  }, 'KHUONMAT');

  // ── Hai cổng vào, công khai ──
  add('POST', '/khuon-mat/xin-dang-nhap', (req, body) => {
    const r = N.accounts.xinDangNhapKhuonMat({ username: body.username || null });
    return r.ok ? r : { status: 503, body: r };
  }, 'KHUONMATVAO');

  add('POST', '/khuon-mat/dang-nhap', (req, body) => {
    const r = N.accounts.dangNhapKhuonMat({ ...body, ip: req.ip, userAgent: req.headers['user-agent'] || '' });
    return r.ok ? r : { status: r.error === 'LOCKED_OUT' ? 429 : 401, body: r };
  }, 'KHUONMATVAO');

  // ═══ SƠ ĐỒ TƯ DUY BA CHIỀU ══════════════════════════════════════════
  //
  // Mở cho học viên: đây là công cụ HỌC, và dữ liệu nó vẽ là chương trình
  // công khai — không có một chữ nào về một em nhỏ cụ thể nào.

  add('GET', '/so-do-3d/dang', () => {
    const S = require('../so-do-tu-duy/so-do');
    return { ok: true, tong: S.dsDang().length, dang: S.dsDang() };
  }, 'SODO3D');

  add('GET', '/so-do-3d', (req) => {
    const S = require('../so-do-tu-duy/so-do');
    const r = S.dung({
      kieu: req.query.kieu || 'toan-canh',
      goc: req.query.goc || null,
      banKinhQuanh: Math.min(3, Math.max(1, +(req.query.buoc || 1))),
    });
    return r.ok ? r : { status: 400, body: r };
  }, 'SODO3D');

  /** Trả thẳng tệp SVG: nhúng vào trang được, tải về in ra giấy được. */
  add('GET', '/so-do-3d/hinh.svg', (req) => {
    const S = require('../so-do-tu-duy/so-do');
    const V = require('../so-do-tu-duy/ve');
    const r = S.dung({
      kieu: req.query.kieu || 'toan-canh',
      goc: req.query.goc || null,
      banKinhQuanh: Math.min(3, Math.max(1, +(req.query.buoc || 1))),
    });
    if (!r.ok) return { status: 400, body: r };
    const so = (v, mac) => (Number.isFinite(+v) ? +v : mac);
    return {
      contentType: 'image/svg+xml; charset=utf-8',
      raw: V.ve(r, {
        gocDoc: so(req.query.doc, 0.6),
        gocNgang: so(req.query.ngang, 0.28),
        rong: Math.min(2000, so(req.query.rong, 900)),
        cao: Math.min(2000, so(req.query.cao, 640)),
        nen: req.query.nen !== '0',
        hienChuHet: req.query.chu === 'het',
      }),
    };
  }, 'SODO3D');

  add('GET', '/so-do-3d/soi', () => {
    const S = require('../so-do-tu-duy/so-do');
    return { ok: true, ...S.soi() };
  }, 'SODO3D');

  // ═══ TRỢ LÝ TRÒ CHUYỆN ══════════════════════════════════════════════
  //
  // Mỗi lượt đi qua chín cửa. Vai lấy từ PHIÊN ĐANG ĐĂNG NHẬP, không lấy từ
  // thân yêu cầu — để người gửi không tự khai mình là giáo viên.

  const canTroChuyen = () => (N.hopNhat ? null : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } });

  add('GET', '/tro-chuyen', () => canTroChuyen() || { ok: true, ...N.hopNhat.chat.status() }, 'TROCHUYEN');

  add('POST', '/tro-chuyen/hoi', async (req, body) => {
    const chan = canTroChuyen();
    if (chan) return chan;
    const phien = require('../api/cong-quyen').phienCua(N, req.headers);
    const r = await N.hopNhat.hoi({
      cauHoi: String(body.cauHoi || body.message || ''),
      vai: (phien && phien.role) || 'GUEST',
      nguoiHocId: (phien && (phien.learnerId || phien.userId)) || null,
      phienId: body.phienId || null,
    });
    return r;
  }, 'TROCHUYEN');

  add('GET', '/tro-chuyen/cong-cu', () => (N.hopNhat
    ? { ok: true, congCu: require('../tro-chuyen/cong-cu').danhSach(N) }
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'TROCHUYEN');

  add('GET', '/tro-chuyen/bang-viec', () => {
    const K = require('../tro-chuyen/khien-viec');
    return { ok: true, bangViec: K.BANG_VIEC, camTuyetDoi: K.CAM_TUYET_DOI, soi: K.soiBang() };
  }, 'TROCHUYEN');

  add('GET', '/tro-chuyen/so-cong-chung', (req) => (N.hopNhat
    ? {
      ok: true,
      ...N.hopNhat.chat.so.status(),
      khoaCongKhai: N.hopNhat.chat.so.khoaCongKhai(),
      kiem: N.hopNhat.chat.so.kiemCaCuon(),
      ganDay: N.hopNhat.chat.so.ganDay({ gioiHan: Math.min(200, +(req.query.limit || 50)) }),
    }
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'TIEPTHI');

  // ═══ TIẾP THỊ NỘI DUNG ══════════════════════════════════════════════

  add('GET', '/tiep-thi', () => (N.hopNhat
    ? { ok: true, ...N.hopNhat.status() }
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'TIEPTHI');

  add('GET', '/tiep-thi/trang', () => (N.hopNhat
    ? { ok: true, ...N.hopNhat.soanTrang() }
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'TIEPTHI');

  add('POST', '/tiep-thi/soi-noi-dung', (req, body) => {
    const r = require('../tiep-thi/luat-noi-dung').soi(body.noiDung ?? body.chu ?? '');
    return { ok: true, ...r };
  }, 'TIEPTHI');

  add('GET', '/tiep-thi/do-thi', () => (N.hopNhat
    ? { ok: true, ...N.hopNhat.doThi.soi(), status: N.hopNhat.doThi.status() }
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'TIEPTHI');

  add('POST', '/tiep-thi/vong-cai-tien', () => (N.hopNhat
    ? { ok: true, ...N.hopNhat.chayVongCaiTien() }
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'TIEPTHI');

  add('POST', '/tiep-thi/phan-hoi', (req, body) => (N.hopNhat
    ? N.hopNhat.ghiPhanHoi({ mang: body.mang, sacThai: body.sacThai, chu: body.chu })
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'TIEPTHI');

  add('GET', '/tiep-thi/soi', () => (N.hopNhat
    ? { ok: true, ...N.hopNhat.soi() }
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'TIEPTHI');

  // ═══ VIDEO HƯỚNG DẪN ════════════════════════════════════════════════

  const canVideo = () => (N.xuongVideo ? null : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } });

  add('GET', '/video-huong-dan', () => canVideo() || { ok: true, ...N.xuongVideo.status() }, 'VIDEOHD');

  add('GET', '/video-huong-dan/danh-muc', () => canVideo() || { ok: true, ...N.xuongVideo.danhMuc() }, 'VIDEOHD');

  add('GET', '/video-huong-dan/kich-ban', (req) => canVideo()
    || N.xuongVideo.layKichBan(req.query.man, req.query.vai), 'VIDEOHD');

  /** Kịch bản dạng văn bản, để gửi phát thanh viên thu giọng người thật. */
  add('GET', '/video-huong-dan/kich-ban.txt', (req) => {
    if (!N.xuongVideo) return { status: 503, body: { ok: false, error: 'CHUA_DUNG' } };
    const r = N.xuongVideo.xuatKichBanChu(req.query.man, req.query.vai);
    if (!r.ok) return { status: 400, body: r };
    return { contentType: 'text/plain; charset=utf-8', raw: r.chu };
  }, 'VIDEOHD');

  add('POST', '/video-huong-dan/dung', async (req, body) => {
    if (!N.xuongVideo) return { status: 503, body: { ok: false, error: 'CHUA_DUNG' } };
    const r = await N.xuongVideo.dung(body.man, body.vai, { kho: body.kho || 'hd', giongId: body.giongId || null });
    return r.ok ? r : { status: 400, body: r };
  }, 'VIDEOHD');

  add('GET', '/video-huong-dan/man-hinh', () => (N.xuongVideo
    ? { ok: true, man: require('../xuong-video/man-hinh').dungSo(N), soi: require('../xuong-video/man-hinh').soi(N) }
    : { status: 503, body: { ok: false, error: 'CHUA_DUNG' } }), 'VIDEOHD');

  // ═══ CHỐNG LỪA ĐẢO ══════════════════════════════════════════════════
  const veCua = (req) => (req.headers.authorization || '').replace(/^Bearer\s+/i, '')
    || require('../api/cong-quyen').docCookie(req.headers.cookie, 'gita_token');

  add('GET', '/chong-lua-dao', () => (N.chongLuaDao
    ? { ok: true, ...N.chongLuaDao.status() }
    : { status: 503, body: { ok: false, error: 'CHUA_BAT' } }), 'ANTOAN');

  add('GET', '/chong-lua-dao/tinh-hinh', () => (N.chongLuaDao
    ? { ok: true, ...N.chongLuaDao.tinhHinh() }
    : { status: 503, body: { ok: false, error: 'CHUA_BAT' } }), 'ANTOAN');

  add('GET', '/chong-lua-dao/dau-hieu', (req) => (N.chongLuaDao
    ? { ok: true, dauHieu: N.chongLuaDao.dauHieuGanDay({ gioiHan: Math.min(200, +(req.query.limit || 50)) }) }
    : { status: 503, body: { ok: false, error: 'CHUA_BAT' } }), 'ANTOAN');

  /** Việc nguy hiểm này có làm được không — giao diện hỏi trước khi hiện nút. */
  add('GET', '/chong-lua-dao/cho-lam/:viec', (req) => {
    if (!N.chongLuaDao) return { status: 503, body: { ok: false, error: 'CHUA_BAT' } };
    return { ok: true, ...N.accounts.choLamViecNguyHiem(veCua(req), req.params.viec) };
  }, 'ANTOANVIEC');

  /** Danh sách máy của chính mình. Chỉ thấy máy của mình, không thấy của ai khác. */
  add('GET', '/chong-lua-dao/may-cua-toi', (req) => {
    if (!N.chongLuaDao) return { status: 503, body: { ok: false, error: 'CHUA_BAT' } };
    const p = N.accounts.session(veCua(req));
    if (!p) return { status: 401, body: { ok: false, error: 'INVALID_SESSION' } };
    return { ok: true, may: N.chongLuaDao.dsMay(p.userId) };
  }, 'ANTOANVIEC');

  /** Đổi mật khẩu QUA CỔNG việc nguy hiểm. */
  add('POST', '/chong-lua-dao/doi-mat-khau', (req, body) => {
    const r = N.accounts.doiMatKhauCoCanh(veCua(req), body.matKhauCu, body.matKhauMoi);
    return r.ok ? r : { status: r.error === 'CAN_XAC_THUC_LAI' ? 403 : 400, body: r };
  }, 'ANTOANVIEC');

  // ═══ NHÓM 28 — QUẢN TRỊ QUAN HỆ GIA ĐÌNH (CRM) ═══════════════════════
  //
  // Hai mức quyền, và ranh giới giữa chúng là ranh giới thật:
  //
  //   CRM        — quản trị viên dùng hằng ngày: hỏi việc, mở hồ sơ, duyệt.
  //   CRMSUPER   — chỉ Super Admin: cấp quyền, khoá trợ lý, dừng cả ban.
  //
  // Tách thành hai nhóm chứ không dùng chung một mức, vì một người duyệt được
  // một lá thư không đương nhiên được phép hạ mức tự chủ của ba mươi trợ lý.

  const canCrm = () => {
    if (!N.crm) return { status: 503, body: { ok: false, error: 'CRM_CHUA_DUNG' } };
    return null;
  };

  add('GET', '/crm', () => {
    const c = canCrm(); if (c) return c;
    return { ok: true, ...N.crm.status() };
  }, 'CRM');

  add('GET', '/crm/tro-ly', (req) => {
    const c = canCrm(); if (c) return c;
    const { DS, CAP, MIEN } = require('../crm/so-tro-ly');
    const cap = req.query.cap ? Number(req.query.cap) : null;
    const mien = req.query.mien || null;
    let ds = DS;
    if (cap) ds = ds.filter((t) => t.cap === cap);
    if (mien) ds = ds.filter((t) => t.mien === mien);
    return {
      ok: true, tong: ds.length, cap: CAP, mien: MIEN,
      troLy: ds.map((t) => ({
        ma: t.ma, ten: t.ten, cap: t.cap, mien: t.mien, moTa: t.moTa,
        tuChuToiDa: t.tuChuToiDa, congCu: t.congCu,
        khungNghiepVu: t.khungNghiepVu, soChiSo: t.kpi.length,
        mucThatHienTai: N.crm.quanTri.mucThatCua(t.ma),
      })),
    };
  }, 'CRM');

  add('GET', '/crm/cong-cu', () => {
    const c = canCrm(); if (c) return c;
    return { ok: true, ...N.crm.congCu.status(), congCu: N.crm.congCu.danhSach() };
  }, 'CRM');

  add('POST', '/crm/hoi', async (req, body) => {
    const c = canCrm(); if (c) return c;
    if (!body.cauHoi) return { status: 400, body: { ok: false, error: 'THIẾU_CÂU_HỎI', need: ['cauHoi'] } };
    const r = await N.crm.chay({
      cauHoi: String(body.cauHoi),
      phienId: body.phienId || null,
      boi: (req.phien && req.phien.username) || body.boi || 'khong-ro',
      boiCanh: body.boiCanh || {},
    });
    return r.ok ? r : { status: r.loi === 'KHONG_DOC_RA_Y_DINH' ? 400 : 409, body: r };
  }, 'CRM');

  // ── Kho dữ liệu ──
  add('GET', '/crm/tong-quan', () => {
    const c = canCrm(); if (c) return c;
    return { ok: true, ...N.crm.kho.tongQuan() };
  }, 'CRM');

  add('POST', '/crm/gia-dinh', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kho.moGiaDinh(body);
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  add('GET', '/crm/gia-dinh', (req) => {
    const c = canCrm(); if (c) return c;
    const ds = req.query.chang ? N.crm.kho.giaDinh.by('chang', req.query.chang) : N.crm.kho.giaDinh.all();
    return { ok: true, tong: ds.length, giaDinh: ds.slice(0, Math.min(+(req.query.limit || 50), 200)) };
  }, 'CRM');

  add('GET', '/crm/gia-dinh/:id', (req) => {
    const c = canCrm(); if (c) return c;
    const gd = N.crm.kho.giaDinh.get(req.params.id);
    if (!gd) return { status: 404, body: { ok: false, error: 'NOT_FOUND' } };
    return {
      ok: true, giaDinh: gd,
      diem: N.crm.kho.diemCua(gd.id),
      hocPhi: N.crm.kho.congNo({ giaDinhId: gd.id }),
      tuongTac: N.crm.kho.tuongTac.by('giaDinhId', gd.id).slice(-20),
    };
  }, 'CRM');

  add('POST', '/crm/gia-dinh/:id/chang', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kho.chuyenChang(req.params.id, body.chang, { boi: (req.phien && req.phien.username) || 'khong-ro' });
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  add('POST', '/crm/hoc-phi', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kho.ghiKyHocPhi(body);
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  add('POST', '/crm/hoc-phi/:id/trang-thai', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kho.capNhatHocPhi(req.params.id, body.trangThai, { boi: (req.phien && req.phien.username) || 'khong-ro' });
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  add('GET', '/crm/cong-no', (req) => {
    const c = canCrm(); if (c) return c;
    return { ok: true, ...N.crm.kho.congNo({ giaDinhId: req.query.giaDinhId || null }) };
  }, 'CRM');

  add('POST', '/crm/yeu-cau', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kho.moYeuCau(body);
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  add('POST', '/crm/yeu-cau/:id/buoc', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kho.ghiBuocPhucHoi(req.params.id, body.buoc, { ghiChu: body.ghiChu || null });
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  add('POST', '/crm/chien-dich', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kho.moChienDich(body);
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  add('GET', '/crm/chien-dich/:id/hieu-qua', (req) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kho.hieuQuaChienDich(req.params.id);
    return r.ok ? r : { status: 404, body: r };
  }, 'CRM');

  // ── Hàng chờ duyệt ──
  add('GET', '/crm/duyet', (req) => {
    const c = canCrm(); if (c) return c;
    return { ok: true, bangDo: N.crm.choDuyet.bangDo(), dangCho: N.crm.choDuyet.dangCho({ troLyMa: req.query.troLy || null }) };
  }, 'CRM');

  add('GET', '/crm/duyet/:id', (req) => {
    const c = canCrm(); if (c) return c;
    const v = N.crm.choDuyet.get(req.params.id);
    return v ? { ok: true, viecCho: v } : { status: 404, body: { ok: false, error: 'NOT_FOUND' } };
  }, 'CRM');

  add('POST', '/crm/duyet/:id/quyet', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.quyetViecCho(req.params.id, {
      trangThai: body.trangThai,
      nguoiQuyet: (req.phien && req.phien.username) || body.nguoiQuyet,
      ghiChu: body.ghiChu || null,
    });
    return r.ok ? r : { status: 409, body: r };
  }, 'CRM');

  // ── KPI và tín hiệu ──
  add('GET', '/crm/kpi', () => {
    const c = canCrm(); if (c) return c;
    return { ok: true, ...N.crm.kpi.bangDiem() };
  }, 'CRM');

  add('GET', '/crm/kpi/:troLy', (req) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.kpi.cham(req.params.troLy);
    return r.ok ? r : { status: 404, body: r };
  }, 'CRM');

  add('GET', '/crm/tin-hieu', () => {
    const c = canCrm(); if (c) return c;
    return {
      ok: true, bangTong: N.crm.tinHieu.bangTong(),
      troLyBiTuChoi: N.crm.tinHieu.troLyBiTuChoi(),
      yDinhPhaiHoiMoHinh: N.crm.tinHieu.yDinhPhaiHoiMoHinh(),
    };
  }, 'CRM');

  // ── Lịch việc chạy nền ──
  add('GET', '/crm/lich-viec', () => {
    if (!N.lichCrm) return { status: 503, body: { ok: false, error: 'CRM_CHUA_DUNG' } };
    return { ok: true, ...N.lichCrm.status() };
  }, 'CRM');

  add('POST', '/crm/lich-viec/:ma/chay', async (req) => {
    if (!N.lichCrm) return { status: 503, body: { ok: false, error: 'CRM_CHUA_DUNG' } };
    const r = await N.lichCrm.chayNgay(req.params.ma);
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  // ── Hợp tác với lực lượng 500 và các nhà khoa học ──
  add('GET', '/crm/hop-tac', () => {
    const c = canCrm(); if (c) return c;
    return { ok: true, ...N.crm.hopTac.status() };
  }, 'CRM');

  add('POST', '/crm/hop-tac/giao-viec', async (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = body.to === true
      ? await N.crm.hopTac.giaoToViec(body)
      : await N.crm.hopTac.giaoMotViec(body);
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  add('POST', '/crm/hop-tac/nha-khoa-hoc', async (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = await N.crm.hopTac.hoiNhaKhoaHoc(body);
    return r.ok ? r : { status: 400, body: r };
  }, 'CRM');

  // ── MỤC QUẢN TRỊ SUPER ADMIN ─────────────────────────────────────────
  add('GET', '/crm/quan-tri', () => {
    const c = canCrm(); if (c) return c;
    return { ok: true, ...N.crm.quanTri.banDieuKhien() };
  }, 'CRMSUPER');

  add('GET', '/crm/quan-tri/quyen', () => {
    const c = canCrm(); if (c) return c;
    return { ok: true, ...N.crm.quanTri.bangQuyen() };
  }, 'CRMSUPER');

  add('POST', '/crm/quan-tri/han-muc', (req, body) => {
    const c = canCrm(); if (c) return c;
    const boi = (req.phien && req.phien.username) || body.boi;
    const r = body.bo === true
      ? N.crm.quanTri.boHanMuc(body.troLy, { boi })
      : N.crm.quanTri.hanMuc(body.troLy, body.muc, { boi, lyDo: body.lyDo || null });
    return r.ok ? r : { status: 400, body: r };
  }, 'CRMSUPER');

  add('POST', '/crm/quan-tri/khoa', (req, body) => {
    const c = canCrm(); if (c) return c;
    const boi = (req.phien && req.phien.username) || body.boi;
    const r = body.mo === true
      ? N.crm.quanTri.moKhoa(body.troLy, { boi })
      : N.crm.quanTri.khoa(body.troLy, { boi, lyDo: body.lyDo || null });
    return r.ok ? r : { status: 400, body: r };
  }, 'CRMSUPER');

  add('POST', '/crm/quan-tri/nguong', (req, body) => {
    const c = canCrm(); if (c) return c;
    const r = N.crm.quanTri.datNguong({
      canNguoi: body.canNguoi != null ? body.canNguoi : null,
      chan: body.chan != null ? body.chan : null,
      boi: (req.phien && req.phien.username) || body.boi,
    });
    return r.ok ? r : { status: 400, body: r };
  }, 'CRMSUPER');

  add('POST', '/crm/quan-tri/dung', (req, body) => {
    const c = canCrm(); if (c) return c;
    const boi = (req.phien && req.phien.username) || body.boi;
    const r = body.chayLai === true
      ? N.crm.quanTri.chayLaiToanBan({ boi })
      : N.crm.quanTri.dungToanBan({ boi, lyDo: body.lyDo || null });
    return r.ok ? r : { status: 400, body: r };
  }, 'CRMSUPER');


  // ── Bộ so khớp route ──
  function match(method, pathname) {
    for (const r of routes) {
      if (r.method !== method) continue;
      if (!r.pattern.includes(':')) {
        if (r.pattern === pathname) return { route: r, params: {} };
        continue;
      }
      const pp = r.pattern.split('/');
      const up = pathname.split('/');
      if (pp.length !== up.length) continue;
      const params = {};
      let ok = true;
      for (let i = 0; i < pp.length; i++) {
        if (pp[i].startsWith(':')) params[pp[i].slice(1)] = decodeURIComponent(up[i]);
        else if (pp[i] !== up[i]) { ok = false; break; }
      }
      if (ok) return { route: r, params };
    }
    return null;
  }

  return { routes, match };
}

module.exports = createRouter;
