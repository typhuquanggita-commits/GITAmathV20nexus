'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  KHUNG HÌNH BÀI GIẢNG — vẽ thật, để xuất ra được tệp video thật
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế lấy ảnh minh hoạ từ dịch vụ sinh ảnh ngoài. Hỏng ở hai chỗ:
 *  không có mạng thì không có khung hình nào, và mô hình sinh ảnh vẽ công
 *  thức toán ra chữ nguệch ngoạc — thứ tệ nhất có thể đưa lên màn hình lớp học.
 *
 *  Nên khung hình bài giảng được VẼ, không được SINH: nền, tiêu đề, lời
 *  giảng, công thức, thanh tiến độ, số trang. Tất cả bằng điểm ảnh thật, tất
 *  định, không cần mạng. Có ảnh do mô hình sinh ra thì dùng làm nền — nhưng
 *  chữ vẫn do hệ thống vẽ đè lên, vì chữ phải đọc được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { taoAnh } = require('../photo/png');
const { veChu, veDoan, ngatDong, rongChuoi, caoDong } = require('../photo/chu');
const { doiKichThuoc } = require('../photo/image');

/** Bảng màu — một bộ duy nhất cho cả bài giảng, để không nhức mắt. */
const MAU = {
  nen: [14, 18, 28],
  nenPhu: [22, 28, 42],
  vien: [42, 52, 74],
  chu: [232, 238, 248],
  chuMo: [150, 162, 184],
  nhan: [255, 190, 96],
  xanh: [110, 231, 168],
  do: [255, 122, 122],
  lam: [124, 196, 255],
};

const px = (anh, x, y, mau, mo = 1) => {
  if (x < 0 || y < 0 || x >= anh.width || y >= anh.height) return;
  const i = (y * anh.width + x) * 4;
  anh.data[i] = Math.round(anh.data[i] * (1 - mo) + mau[0] * mo);
  anh.data[i + 1] = Math.round(anh.data[i + 1] * (1 - mo) + mau[1] * mo);
  anh.data[i + 2] = Math.round(anh.data[i + 2] * (1 - mo) + mau[2] * mo);
};

function hinhChuNhat(anh, x, y, w, h, mau, mo = 1) {
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) px(anh, x + i, y + j, mau, mo);
}

function vienHCN(anh, x, y, w, h, mau, day = 1) {
  for (let d = 0; d < day; d++) {
    for (let i = 0; i < w; i++) { px(anh, x + i, y + d, mau); px(anh, x + i, y + h - 1 - d, mau); }
    for (let j = 0; j < h; j++) { px(anh, x + d, y + j, mau); px(anh, x + w - 1 - d, y + j, mau); }
  }
}

function duong(anh, x0, y0, x1, y1, mau, day = 1) {
  const dx = Math.abs(x1 - x0); const dy = Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1; const sy = y0 < y1 ? 1 : -1;
  let err = dx - dy;
  let x = x0; let y = y0;
  for (;;) {
    for (let o = 0; o < day; o++) { px(anh, x, y + o, mau); px(anh, x + o, y, mau); }
    if (x === x1 && y === y1) break;
    const e2 = 2 * err;
    if (e2 > -dy) { err -= dy; x += sx; }
    if (e2 < dx) { err += dx; y += sy; }
  }
}

/** Nền có dải sáng chéo nhẹ — đỡ phẳng lì mà không rối mắt. */
function veNen(anh) {
  const { width: W, height: H } = anh;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const t = (x / W) * 0.6 + (y / H) * 0.4;
      const i = (y * W + x) * 4;
      anh.data[i] = Math.round(MAU.nen[0] + t * 12);
      anh.data[i + 1] = Math.round(MAU.nen[1] + t * 14);
      anh.data[i + 2] = Math.round(MAU.nen[2] + t * 20);
      anh.data[i + 3] = 255;
    }
  }
}

/** Thanh trên và thanh dưới: tên bài, số trang, tiến độ. */
function veKhung(anh, { tieuDeNho, trang, tongTrang, tienDo }) {
  const { width: W, height: H } = anh;
  const co = Math.max(1, Math.round(W / 640));
  hinhChuNhat(anh, 0, 0, W, 5 * co, MAU.nhan);
  hinhChuNhat(anh, 0, H - 22 * co, W, 22 * co, MAU.nenPhu, 0.9);
  if (tieuDeNho) veChu(anh, tieuDeNho, 12 * co, H - 17 * co, { mau: MAU.chuMo, co });
  if (trang) {
    const s = `${trang}/${tongTrang}`;
    veChu(anh, s, W - rongChuoi(s, co) - 12 * co, H - 17 * co, { mau: MAU.chuMo, co });
  }
  if (tienDo != null) {
    const w = Math.round(W * Math.max(0, Math.min(1, tienDo)));
    hinhChuNhat(anh, 0, H - 3 * co, w, 3 * co, MAU.nhan);
  }
}

/** Khung mở đầu: tên bài giảng lớn giữa màn hình. */
function khungTieuDe({ rong = 1280, cao = 720, tieuDe, phuDe = '', nhan = 'GITAmath Nexus V20' }) {
  const anh = taoAnh(rong, cao);
  veNen(anh);
  const co = Math.max(2, Math.round(rong / 190));
  const coPhu = Math.max(1, Math.round(rong / 420));

  const dong = ngatDong(tieuDe, rong - 120, co);
  let y = Math.round(cao / 2 - (dong.length * (caoDong(co) + 10 * coPhu)) / 2 - 20);
  for (const d of dong) {
    veChu(anh, d, Math.round((rong - rongChuoi(d, co)) / 2), y, { mau: MAU.chu, co });
    y += caoDong(co) + 10 * coPhu;
  }
  if (phuDe) {
    y += 8 * coPhu;
    const dp = ngatDong(phuDe, rong - 160, coPhu);
    for (const d of dp) {
      veChu(anh, d, Math.round((rong - rongChuoi(d, coPhu)) / 2), y, { mau: MAU.nhan, co: coPhu });
      y += caoDong(coPhu) + 6;
    }
  }
  const cn = Math.max(1, Math.round(rong / 640));
  veChu(anh, nhan, Math.round((rong - rongChuoi(nhan, cn)) / 2), cao - 60 * cn, { mau: MAU.chuMo, co: cn });
  hinhChuNhat(anh, Math.round(rong / 2 - 60 * cn), y + 14 * cn, 120 * cn, 3 * cn, MAU.nhan);
  return anh;
}

/**
 * Khung nội dung: đầu đề + các ý + ô công thức.
 * @param {object} o {tieuDe, cacY[], congThuc, ghiChu, trang, tongTrang, tienDo, anhNen}
 */
function khungNoiDung({
  rong = 1280, cao = 720, tieuDe = '', cacY = [], congThuc = null, ghiChu = null,
  tieuDeNho = '', trang = null, tongTrang = null, tienDo = null, anhNen = null, mauDauDe = null,
}) {
  const anh = taoAnh(rong, cao);
  if (anhNen) {
    const n = anhNen.width === rong && anhNen.height === cao ? anhNen : doiKichThuoc(anhNen, rong, cao);
    n.data.copy(anh.data);
    // Phủ một lớp tối để chữ nổi lên — không có lớp này thì ảnh nền nào cũng nuốt chữ.
    for (let i = 0; i < anh.data.length; i += 4) {
      anh.data[i] = Math.round(anh.data[i] * 0.34 + MAU.nen[0] * 0.66);
      anh.data[i + 1] = Math.round(anh.data[i + 1] * 0.34 + MAU.nen[1] * 0.66);
      anh.data[i + 2] = Math.round(anh.data[i + 2] * 0.34 + MAU.nen[2] * 0.66);
    }
  } else {
    veNen(anh);
  }

  const co = Math.max(1, Math.round(rong / 640));
  const coDe = co * 2;
  const le = 36 * co;
  let y = 42 * co;

  if (tieuDe) {
    for (const d of ngatDong(tieuDe, rong - le * 2, coDe)) {
      veChu(anh, d, le, y, { mau: mauDauDe || MAU.nhan, co: coDe });
      y += caoDong(coDe) + 6 * co;
    }
    duong(anh, le, y + 2 * co, le + 90 * co, y + 2 * co, MAU.nhan, 2 * co);
    y += 18 * co;
  }

  for (const yTu of cacY) {
    const chuoi = typeof yTu === 'string' ? yTu : yTu.chu;
    const mau = (typeof yTu === 'object' && yTu.mau) || MAU.chu;
    hinhChuNhat(anh, le, y + 5 * co, 4 * co, 4 * co, MAU.nhan);
    const r = veDoan(anh, chuoi, le + 14 * co, y, rong - le * 2 - 14 * co, { mau, co, giatDong: 3 });
    y += r.cao + 9 * co;
  }

  if (congThuc) {
    const hCT = caoDong(coDe) + 24 * co;
    hinhChuNhat(anh, le, y, rong - le * 2, hCT, MAU.nenPhu, 0.92);
    vienHCN(anh, le, y, rong - le * 2, hCT, MAU.vien, co);
    const ct = String(congThuc);
    const coCT = rongChuoi(ct, coDe) > rong - le * 2 - 30 * co ? co : coDe;
    veChu(anh, ct, Math.round((rong - rongChuoi(ct, coCT)) / 2), y + Math.round((hCT - caoDong(coCT)) / 2), { mau: MAU.lam, co: coCT });
    y += hCT + 12 * co;
  }

  if (ghiChu) {
    veDoan(anh, ghiChu, le, y, rong - le * 2, { mau: MAU.chuMo, co, giatDong: 3 });
  }

  veKhung(anh, { tieuDeNho, trang, tongTrang, tienDo });
  return anh;
}

/** Khung kết: nhắc lại điều cần nhớ. */
function khungKet({ rong = 1280, cao = 720, cauChot = '', nhan = 'GITAmath' }) {
  const anh = taoAnh(rong, cao);
  veNen(anh);
  const co = Math.max(1, Math.round(rong / 520));
  const dong = ngatDong(cauChot, rong - 140 * co / co, co);
  let y = Math.round(cao / 2 - (dong.length * (caoDong(co) + 8)) / 2);
  for (const d of dong) {
    veChu(anh, d, Math.round((rong - rongChuoi(d, co)) / 2), y, { mau: MAU.chu, co });
    y += caoDong(co) + 8;
  }
  const cn = Math.max(1, Math.round(rong / 640));
  veChu(anh, nhan, Math.round((rong - rongChuoi(nhan, cn)) / 2), cao - 70 * cn, { mau: MAU.nhan, co: cn });
  return anh;
}

module.exports = { khungTieuDe, khungNoiDung, khungKet, veNen, veKhung, hinhChuNhat, vienHCN, duong, MAU };
