'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SỔ TAY QUY TRÌNH — kịch bản xử lý, ai làm gì, và nối vào đâu
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  VẤN ĐỀ TỆP NÀY GIẢI. Hệ thống có rất nhiều cơ chế an toàn nằm rải rác:
 *  cổng quyền, bức tường Cây Tiền, cửa an toàn của sàng lọc tâm lý, ngân sách
 *  dòng tiền, tổ thanh tra. Mỗi cái đúng việc của nó. Nhưng khi một sự cố
 *  THẬT xảy ra lúc 22 giờ, người trực không có thời gian đọc mã để biết phải
 *  làm gì trước, gọi ai, và cái gì tuyệt đối không được làm.
 *
 *  Nên mỗi kịch bản dưới đây trả lời đúng bốn câu, theo đúng thứ tự:
 *      DẤU HIỆU  →  LÀM NGAY  →  AI QUYẾT  →  CẤM LÀM
 *
 *  "CẤM LÀM" là mục quan trọng nhất và hay bị bỏ nhất. Phần lớn sự cố nhỏ
 *  thành sự cố lớn vì người trực làm một việc tưởng là cứu chữa.
 *
 *  Mỗi kịch bản NỐI THẲNG tới lệnh và tệp cụ thể, để người trực gõ được ngay
 *  chứ không phải đi tìm. Có mục kiểm đòi mọi đường dẫn khai ở đây phải tồn
 *  tại thật — tài liệu trỏ vào tệp không còn là tài liệu tệ hơn không có.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/** Mức khẩn của một kịch bản. */
const MUC = {
  DO: { ma: 'DO', ten: 'Đỏ — dừng việc ngay', trongBaoLau: 'trong 15 phút' },
  CAM: { ma: 'CAM', ten: 'Cam — xử trong ca', trongBaoLau: 'trong ca trực' },
  VANG: { ma: 'VANG', ten: 'Vàng — xử trong ngày', trongBaoLau: 'trong 24 giờ' },
};

const KICH_BAN = [
  {
    ma: 'KB01', ten: 'Nghi ngờ mất dữ liệu', muc: 'DO',
    dauHieu: [
      'Thanh tra TT01 báo ảnh chụp không khớp số bản ghi, hoặc còn tệp .snap.json.tmp',
      'Số bản ghi của một bảng tụt so với hôm trước',
      'Khởi động lại rồi mà dữ liệu vừa ghi biến mất',
    ],
    lamNgay: [
      'DỪNG mọi tiến trình đang ghi: tắt máy chủ, không khởi động lại.',
      'Sao chép NGUYÊN THƯ MỤC data/db sang một chỗ khác trước khi làm bất cứ gì.',
      'Xem nhật ký .log còn không — nhật ký còn thì dựng lại được.',
      'Chạy: node bin/gita.js to-thanh-tra để xem bảng nào hỏng.',
    ],
    aiQuyet: 'Quản trị hệ thống. Khôi phục ảnh chụp cần hai người duyệt (dual control).',
    camLam: [
      'CẤM khởi động lại máy chủ "xem thử" — mỗi lần khởi động có thể gộp đè lên nhật ký còn tốt.',
      'CẤM sửa tay tệp .snap.json khi máy chủ đang chạy.',
      'CẤM xoá tệp .snap.json.tmp trước khi đã sao lưu — nó có thể là bản mới nhất còn nguyên.',
    ],
    lienQuan: ['src/data/repository.js', 'src/thanh-tra/phep-soi.js'],
    lenh: ['node bin/gita.js to-thanh-tra'],
  },
  {
    ma: 'KB02', ten: 'Rò rỉ dữ liệu ra ngoài', muc: 'DO',
    dauHieu: [
      'Thanh tra TT02 báo có cổng công khai ngoài danh sách đã khai',
      'Thanh tra TT03 báo trang công khai lộ chữ của bảng phân loại gia đình',
      'Thanh tra TT09 báo bản ghi tâm lý chứa câu trả lời thô',
    ],
    lamNgay: [
      'Xác định phạm vi: cổng nào, trang nào, bao nhiêu bản ghi.',
      'Đóng cổng bằng cách khai lại mức trong src/api/cong-quyen.js rồi khởi động lại.',
      'Chạy npm run verify để chắc mục BỨC TƯỜNG và CỔNG QUYỀN đã xanh trở lại.',
      'Ghi sự việc vào nhật ký kiểm toán, kèm khoảng thời gian cổng mở.',
    ],
    aiQuyet: 'Quản trị hệ thống. Nếu có dữ liệu trẻ em bị lộ thì phải báo gia đình.',
    camLam: [
      'CẤM nới bảng từ cấm hoặc danh sách công khai để mục kiểm xanh lại.',
      'CẤM tắt mục kiểm đang báo đỏ.',
      'CẤM báo "đã xử lý" khi chưa biết cổng đã mở bao lâu.',
    ],
    lienQuan: ['src/api/cong-quyen.js', 'src/cay-tien/buc-tuong.js', 'src/khao-sat/kho.js'],
    lenh: ['npm run verify', 'node bin/gita.js to-thanh-tra'],
  },
  {
    ma: 'KB03', ten: 'Chi phí mô hình tăng đột biến', muc: 'CAM',
    dauHieu: [
      'Thanh tra TT04 báo vượt trần ngày hoặc tháng',
      'Sổ cái cảnh báo đã dùng trên 80% ngân sách',
      'Một đợt huy động chạy lâu bất thường',
    ],
    lamNgay: [
      'Chạy: node bin/gita.js dong-tien để xem khoản nào tăng.',
      'Hạ trần ngày qua biến môi trường NGAN_SACH_NGAY_USD rồi khởi động lại — trần chặn thật, không chỉ cảnh báo.',
      'Xem có vòng lặp gọi mô hình không: kiểm nhật ký nhiệm vụ gần nhất.',
    ],
    aiQuyet: 'Quản trị hệ thống cho mức ngân sách. Chủ hệ thống cho việc nâng trần.',
    camLam: [
      'CẤM nâng trần để việc chạy tiếp khi chưa biết vì sao tăng.',
      'CẤM tắt cửa ngân sách.',
      'CẤM suy ra doanh thu để biện minh cho chi phí — hệ thống CHƯA có dữ liệu doanh thu.',
    ],
    lienQuan: ['src/dong-tien/so-cai.js'],
    lenh: ['node bin/gita.js dong-tien'],
  },
  {
    ma: 'KB04', ten: 'Sàng lọc tâm lý báo cần người lớn ngay', muc: 'DO',
    dauHieu: [
      'Kết quả sàng lọc có miền "Cảm giác an toàn ở trường" vượt ngưỡng',
      'Lộ trình trả về CẦN_NGƯỜI_LỚN_TRƯỚC',
    ],
    lamNgay: [
      'Báo phụ huynh và giáo viên chủ nhiệm trong ngày.',
      'Một người lớn ngồi xuống nói chuyện với em TRƯỚC, không dựng lộ trình.',
      'Ghi lại ai đã nói chuyện: truyền nguoiLonDaNoiChuyen = { ten, vai, luc }.',
    ],
    aiQuyet: 'Phụ huynh và nhà trường. Hệ thống KHÔNG quyết việc này.',
    camLam: [
      'CẤM khai tên giả cho qua cửa an toàn.',
      'CẤM đọc kết quả sàng lọc tâm lý cho giáo viên bộ môn — luật riêng tư không cho.',
      'CẤM ghi bất kỳ tên bệnh nào vào hồ sơ. Đây là sàng lọc, không phải chẩn đoán.',
      'CẤM tăng nhịp học cho em đang ở trạng thái này.',
    ],
    lienQuan: ['src/khao-sat/tam-ly-hoc-duong.js', 'src/khao-sat/lo-trinh-ca-nhan.js', 'src/khao-sat/kho.js'],
    lenh: [],
  },
  {
    ma: 'KB05', ten: 'Học liệu sai đáp số lọt ra ngoài', muc: 'DO',
    dauHieu: [
      'Thanh tra TT06 báo có bài phát hành thiếu chứng cứ máy tự giải lại',
      'Học viên hoặc giáo viên báo một bài sai đáp án',
    ],
    lamNgay: [
      'Rút bài khỏi kho ngay: POST /bank/items/:id/retire.',
      'Chạy node bin/gita.js thanh-tra để xem còn bài nào cùng bản thiết kế bị sai.',
      'Sửa bản thiết kế, không sửa riêng một bài — sai ở bản thiết kế thì mọi bài sinh ra đều sai.',
    ],
    aiQuyet: 'Quản trị hệ thống rút bài. Nhà khoa học toán duyệt bản sửa.',
    camLam: [
      'CẤM sửa đáp án cho khớp bài — phải sửa chỗ sinh ra bài.',
      'CẤM nới cổng phát hành để bài đi tiếp.',
    ],
    lienQuan: ['src/content/blueprint.js', 'src/math/verifier.js', 'src/content/seeder.js'],
    lenh: ['node bin/gita.js thanh-tra', 'node bin/gita.js kho-de'],
  },
  {
    ma: 'KB06', ten: 'Trợ lý AI bị treo hoặc đội hình tụt sẵn sàng', muc: 'CAM',
    dauHieu: [
      'Thanh tra TT08 báo sẵn sàng đội hình dưới 95% hoặc có trợ lý bị treo',
      'Nhiệm vụ báo mảnh việc chưa làm được',
    ],
    lamNgay: [
      'Xem GET /resilience/unhealthy để biết ai đang bị cách ly.',
      'Nếu do trần công suất: xem luotDoiCongSuat và luotChuyenNguoi trong bản tóm tắt nhiệm vụ.',
      'Chữa: POST /resilience/heal-all.',
    ],
    aiQuyet: 'Quản trị hệ thống.',
    camLam: [
      'CẤM nâng trần công suất để "cho chạy được" khi chưa biết vì sao chạm trần.',
      'CẤM coi mảnh việc chưa làm là đã xong.',
    ],
    lienQuan: ['src/security/resilience.js', 'src/command/mobilization.js'],
    lenh: ['node bin/gita.js to-thanh-tra'],
  },
  {
    ma: 'KB07', ten: 'Gia đình yêu cầu xoá dữ liệu', muc: 'VANG',
    dauHieu: ['Gia đình yêu cầu xoá kết quả khảo sát hoặc dữ liệu học của con'],
    lamNgay: [
      'Xác minh người yêu cầu đúng là phụ huynh của học viên đó.',
      'Xoá thật: N.khaoSat.xoa(hocVienId) — hoặc kèm { congCu } nếu chỉ xoá một bộ.',
      'Ghi việc xoá vào nhật ký kiểm toán, kèm ai yêu cầu và xoá những gì.',
      'Trả lời gia đình bằng số bản ghi đã xoá, không trả lời chung chung.',
    ],
    aiQuyet: 'Quản trị hệ thống, sau khi xác minh.',
    camLam: [
      'CẤM chỉ ẩn đi mà không xoá.',
      'CẤM xoá mà không ghi nhật ký — sau này không chứng minh được đã làm đúng.',
    ],
    lienQuan: ['src/khao-sat/kho.js'],
    lenh: [],
  },
  {
    ma: 'KB08', ten: 'Lượt thanh tra không chạy', muc: 'VANG',
    dauHieu: ['Biên bản ngày báo CHƯA ĐỦ LƯỢT', 'Một lượt không để lại biên bản nào'],
    lamNgay: [
      'Chạy bù ngay lượt bị thiếu: node bin/gita.js to-thanh-tra --luot=N.',
      'Tìm vì sao lượt ấy không chạy: bộ lập lịch, hay máy chủ đang tắt.',
    ],
    aiQuyet: 'Quản trị hệ thống.',
    camLam: [
      'CẤM coi lượt không chạy là lượt sạch. Hai thứ đó trông giống hệt nhau và khác hẳn nhau.',
    ],
    lienQuan: ['src/thanh-tra/to-thanh-tra.js'],
    lenh: ['node bin/gita.js to-thanh-tra --ca-ngay'],
  },
];

const KICH_BAN_INDEX = new Map(KICH_BAN.map((k) => [k.ma, k]));

/** Sổ tay đầy đủ, xếp theo mức khẩn. */
function soTay() {
  const thuTu = { DO: 0, CAM: 1, VANG: 2 };
  const ds = KICH_BAN.slice().sort((a, b) => thuTu[a.muc] - thuTu[b.muc] || a.ma.localeCompare(b.ma));
  return {
    soKichBan: ds.length,
    muc: Object.values(MUC),
    kichBan: ds.map((k) => ({ ...k, tenMuc: MUC[k.muc].ten, trongBaoLau: MUC[k.muc].trongBaoLau })),
    theoMuc: Object.fromEntries(Object.keys(MUC).map((m) => [m, ds.filter((k) => k.muc === m).length])),
    nguyenTac: 'Mỗi kịch bản trả lời bốn câu theo đúng thứ tự: DẤU HIỆU → LÀM NGAY → AI QUYẾT → CẤM LÀM. '
      + 'Mục CẤM LÀM quan trọng nhất: phần lớn sự cố nhỏ thành lớn vì người trực làm một việc tưởng là cứu chữa.',
  };
}

/** Tra kịch bản theo mã thanh tra viên — nối tổ thanh tra với sổ tay. */
function theoThanhTra(maVien) {
  const noi = {
    TT01: ['KB01'], TT02: ['KB02'], TT03: ['KB02'], TT04: ['KB03'],
    TT05: ['KB02'], TT06: ['KB05'], TT07: ['KB05'], TT08: ['KB06'],
    TT09: ['KB02', 'KB04'], TT10: ['KB05'],
  };
  return (noi[maVien] || []).map((ma) => KICH_BAN_INDEX.get(ma)).filter(Boolean);
}

module.exports = { MUC, KICH_BAN, KICH_BAN_INDEX, soTay, theoThanhTra };
