'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  PHÂN CẢNH QUAY — và đo thời lượng bằng tiếng nói thật
 * ═══════════════════════════════════════════════════════════════════════════
 *  Chỗ hỏng kinh điển của phim dựng bằng AI: cảnh dài 4 giây mà lời thoại đọc
 *  mất 7 giây. Xem phim mới phát hiện, mà lúc đó đã trả tiền dựng video rồi.
 *
 *  Hệ thống này có sẵn bộ phiên âm tiếng Việt, nên thời lượng lời thoại KHÔNG
 *  phải ước lượng theo số chữ — nó được ĐO: tách từng âm tiết, cộng trường độ
 *  từng âm vị, cộng chỗ ngắt ở dấu câu. Thời lượng cảnh quay được đặt theo
 *  con số đo được, cộng khoảng lấy đà đầu cảnh và khoảng lặng cuối cảnh.
 *
 *  Nhờ vậy khâu soát chất lượng bắt được lỗi "thoại tràn khỏi cảnh" TRƯỚC khi
 *  gọi bất kỳ API tốn tiền nào.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { phonemize } = require('../voice/phonemizer');
const { toSpeech } = require('../voice/speech-text');
const { chonModel } = require('./models');
const { nhacToi } = require('./characters');
const { round, clamp } = require('../utils');

/** Cỡ cảnh — tên tiếng Việt kèm cụm tiếng Anh cho prompt. */
const CO_CANH = {
  'thiet-lap': { ten: 'Cảnh thiết lập', anh: 'establishing wide shot', giayGoi: 6 },
  'toan-canh': { ten: 'Toàn cảnh', anh: 'wide shot', giayGoi: 5 },
  'trung-canh': { ten: 'Trung cảnh', anh: 'medium shot', giayGoi: 5 },
  'can-canh': { ten: 'Cận cảnh', anh: 'close-up shot', giayGoi: 4 },
  'dac-ta': { ten: 'Đặc tả', anh: 'extreme close-up', giayGoi: 3 },
};

const CHUYEN_DONG = {
  'tinh': { ten: 'Máy tĩnh', anh: 'static camera' },
  'lia': { ten: 'Lia ngang', anh: 'slow pan' },
  'zoom': { ten: 'Zoom chậm', anh: 'slow push in' },
  'theo-doi': { ten: 'Theo dõi', anh: 'tracking shot' },
  'nang': { ten: 'Nâng máy', anh: 'slow crane up' },
};

/** Khoảng đệm quanh lời thoại — người thật không nói ngay khi cảnh vừa cắt vào. */
const DEM_DAU_MS = 500;
const DEM_CUOI_MS = 700;
const GIAY_TOI_THIEU = 3;
const GIAY_TOI_DA = 12;     // dài hơn thì cắt thành nhiều cảnh

/**
 * ĐO thời lượng đọc một câu thoại — không ước lượng theo số chữ.
 * @returns {{ms, syllables, spoken, unknown}}
 */
function doThoiLuongThoai(loi, { rate = 0.95 } = {}) {
  const t = toSpeech(loi);
  const spoken = t.ok ? t.text : String(loi);
  const ph = phonemize(spoken, { rate });
  return { ms: ph.estimatedMs, syllables: ph.syllables, spoken, unknown: ph.unknown };
}

/** Thời lượng cho một đoạn hành động: theo lượng thông tin người xem phải tiếp nhận. */
function giayChoHanhDong(moTa, laThietLap) {
  const tu = String(moTa).trim().split(/\s+/).filter(Boolean).length;
  const base = laThietLap ? 4.5 : 3.2;
  return round(clamp(base + tu * 0.12, GIAY_TOI_THIEU, 9), 1);
}

/** Dựng prompt hình ảnh tiếng Anh — luôn chèn nguyên văn khoá ngoại hình. */
function dungPrompt({ co, chuyenDong, canh, khoaNhanVat, hanhDong, phongCach }) {
  const c = CO_CANH[co] || CO_CANH['trung-canh'];
  const cd = CHUYEN_DONG[chuyenDong] || CHUYEN_DONG['tinh'];
  const noi = canh.noiQuay ? canh.noiQuay.anh : 'interior';
  const phan = [
    c.anh,
    khoaNhanVat.length ? khoaNhanVat.join('; ') : null,
    hanhDong || null,
    `${noi} ${canh.diaDiemAnh || canh.diaDiem}`,
    canh.thoiDiem.anh,
    cd.anh,
    phongCach || 'cinematic film still, shallow depth of field, photorealistic, 4K, Vietnamese setting',
  ];
  return phan.filter(Boolean).join(', ');
}

/**
 * Phân cảnh quay cho cả phim.
 * @param {object} kichBan kết quả docKichBan()
 * @param {Array} hoSoNhanVat kết quả dungHoSo().nhanVat
 * @param {object} o {uuTien, phongCach, rate}
 */
function phanCanhQuay(kichBan, hoSoNhanVat, { uuTien = 'can-bang', phongCach = null, rate = 0.95 } = {}) {
  const tra = new Map(hoSoNhanVat.map((h) => [h.id, h]));
  const canhQuay = [];
  const canhBao = [];
  let stt = 0;

  // Người nói liền hai câu mà giữ nguyên cỡ cảnh thì phim lặp hình — đây
  // đúng là chỗ khâu soát chất lượng bắt được "trùng prompt". Xử ngay ở đây
  // bằng cách đổi cỡ cảnh, giống hệt cách dựng phim thật làm.
  let nguoiNoiTruoc = null;
  let luanPhien = 0;

  for (const canh of kichBan.canh) {
    const daThietLap = { xong: false };

    for (const khoi of canh.khoi) {
      stt++;
      const idCanhQuay = `q${String(stt).padStart(3, '0')}`;

      if (khoi.kind === 'hanhDong') {
        const laThietLap = !daThietLap.xong;
        daThietLap.xong = true;
        const co = laThietLap ? 'thiet-lap' : 'trung-canh';
        // Nhân vật xuất hiện trong đoạn tả này (để chèn khoá ngoại hình).
        const trongCanh = nhacToi(khoi.moTa, hoSoNhanVat);
        const giay = giayChoHanhDong(khoi.moTa, laThietLap);
        canhQuay.push(_lam({
          id: idCanhQuay, stt, canh, khoi, co, chuyenDong: laThietLap ? 'zoom' : 'tinh',
          giay, thoai: null, nhanVat: trongCanh, tra, phongCach, uuTien,
          moTaViet: khoi.moTa,
        }));
        continue;
      }

      // ── Cảnh có lời thoại: thời lượng do ĐO tiếng nói quyết định ──
      const do_ = doThoiLuongThoai(khoi.loi, { rate });
      const canGiay = round((do_.ms + DEM_DAU_MS + DEM_CUOI_MS) / 1000, 1);
      const giay = round(clamp(canGiay, GIAY_TOI_THIEU, GIAY_TOI_DA), 1);
      if (canGiay > GIAY_TOI_DA) {
        canhBao.push({
          canhQuay: idCanhQuay, loai: 'THOẠI_DÀI_HƠN_MỘT_CẢNH',
          note: `Lời thoại đọc mất ${round(do_.ms / 1000, 1)}s, dài hơn trần ${GIAY_TOI_DA}s cho một cảnh quay. `
            + 'Hãy tách câu thoại, hoặc cắt thành hai cảnh (cận cảnh người nói + phản ứng người nghe).',
          giayCan: canGiay,
        });
      }
      const nv = tra.get(khoi.nhanVat);
      if (khoi.nhanVat === nguoiNoiTruoc) luanPhien++; else luanPhien = 0;
      nguoiNoiTruoc = khoi.nhanVat;
      const coThoai = ['can-canh', 'trung-canh', 'dac-ta'][luanPhien % 3];
      const cdThoai = ['tinh', 'zoom', 'tinh'][luanPhien % 3];
      canhQuay.push(_lam({
        id: idCanhQuay, stt, canh, khoi,
        co: coThoai, chuyenDong: cdThoai, giay,
        thoai: { nhanVat: khoi.nhanVat, tenNhanVat: khoi.tenNhanVat, loi: khoi.loi, huongDan: khoi.huongDan },
        nhanVat: nv ? [nv.id] : [], tra, phongCach, uuTien,
        moTaViet: `${khoi.tenNhanVat} nói: "${khoi.loi}"`,
        doThoai: { ms: do_.ms, giay: round(do_.ms / 1000, 1), amTiet: do_.syllables, docLa: do_.spoken, khongDocDuoc: do_.unknown },
      }));
      daThietLap.xong = true;
    }
  }

  const tongGiay = round(canhQuay.reduce((a, c) => a + c.giay, 0), 1);
  return {
    ok: true,
    canhQuay,
    canhBao,
    tongGiay,
    tongPhut: round(tongGiay / 60, 2),
    soCanh: kichBan.canh.length,
    soCanhQuay: canhQuay.length,
    giayThoai: round(canhQuay.filter((c) => c.thoai).reduce((a, c) => a + c.doThoai.giay, 0), 1),
  };
}

function _lam({ id, stt, canh, co, chuyenDong, giay, thoai, nhanVat, tra, phongCach, uuTien, moTaViet, doThoai = null }) {
  const khoa = nhanVat.map((x) => tra.get(x)).filter(Boolean).map((h) => h.khoaNgoaiHinh);
  const prompt = dungPrompt({
    co, chuyenDong, canh, khoaNhanVat: khoa,
    hanhDong: thoai ? 'speaking, natural lip movement' : null,
    phongCach,
  });
  const cq = {
    id, stt,
    canh: canh.so,
    boiCanh: `${canh.noiQuay ? canh.noiQuay.name : 'Trong nhà'} — ${canh.diaDiem}`,
    thoiDiem: canh.thoiDiem.name,
    co, coTen: (CO_CANH[co] || CO_CANH['trung-canh']).ten,
    chuyenDong, chuyenDongTen: (CHUYEN_DONG[chuyenDong] || CHUYEN_DONG['tinh']).ten,
    giay,
    moTaViet,
    nhanVat,
    thoai,
    doThoai,
    prompt,
  };
  const m = chonModel(cq, { uuTien });
  cq.model = m.ok ? m.model.id : null;
  cq.modelTen = m.ok ? m.model.ten : null;
  cq.viChonModel = m.ok ? m.vi : (m.goi || m.error);
  cq.giaDuTinh = m.ok ? m.gia : 0;
  return cq;
}

/** Cắt một cảnh quay quá dài thành nhiều cảnh nối tiếp. */
function catCanhQuay(canhQuay, tranGiay = GIAY_TOI_DA) {
  if (canhQuay.giay <= tranGiay) return [canhQuay];
  const so = Math.ceil(canhQuay.giay / tranGiay);
  const moi = round(canhQuay.giay / so, 1);
  const coLuanPhien = ['can-canh', 'trung-canh'];
  return Array.from({ length: so }, (_, i) => ({
    ...canhQuay,
    id: `${canhQuay.id}-${i + 1}`,
    giay: moi,
    co: i === 0 ? canhQuay.co : coLuanPhien[i % 2],
    moTaViet: `${canhQuay.moTaViet} (phần ${i + 1}/${so})`,
    catTu: canhQuay.id,
  }));
}

module.exports = {
  phanCanhQuay, doThoiLuongThoai, giayChoHanhDong, dungPrompt, catCanhQuay,
  CO_CANH, CHUYEN_DONG, GIAY_TOI_DA, GIAY_TOI_THIEU,
};
