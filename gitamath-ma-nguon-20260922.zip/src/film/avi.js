'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  AVI — ghi tệp video CÓ TIẾNG, viết thẳng bằng JavaScript
 * ═══════════════════════════════════════════════════════════════════════════
 *  Đây là mảnh còn thiếu của cả hệ thống. Trước bản này, khâu dựng phim dừng
 *  ở "phim nháp" mở bằng trình duyệt: xem được nhịp nhưng không phải một tệp
 *  video gửi cho ai được. Bản thiết kế giao việc ghép cho ffmpeg, mà máy chủ
 *  không có ffmpeg và cả dự án có luật không phụ thuộc chạy thật.
 *
 *  Nhưng AVI thì ghi được bằng tay. Nó là RIFF — vài khối lồng nhau, mỗi
 *  khối một tiêu đề cố định:
 *
 *    RIFF 'AVI '
 *      LIST 'hdrl'   avih (thông số phim) + strl×2 (luồng hình, luồng tiếng)
 *      LIST 'movi'   00dc = một khung hình JPEG · 01wb = tiếng của khung đó
 *      idx1          bảng tra vị trí từng khối, để tua được
 *
 *  Hình dùng MJPEG (mỗi khung là một tệp JPEG rời — đã có bộ mã hoá ở
 *  src/photo/jpeg.js), tiếng dùng PCM 16-bit (đúng thứ bộ tổng hợp giọng
 *  đang sinh ra). Cả hai đều là định dạng cũ và đơn giản, đổi lại: mở được
 *  bằng VLC, mpv, Windows Media Player, và ffmpeg nếu người dùng có.
 *
 *  Đánh đổi phải nói rõ: MJPEG không nén theo thời gian nên tệp nặng hơn
 *  H.264 khoảng năm tới mười lần. Đây là cái giá của "chạy được ngay, không
 *  cần cài gì". Ai có ffmpeg thì vẫn nên chuyển mã lại cho nhẹ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { ghiJPEG } = require('../photo/jpeg');
const { round } = require('../utils');

const fourcc = (s) => Buffer.from(s, 'ascii');
const u32 = (n) => { const b = Buffer.alloc(4); b.writeUInt32LE(n >>> 0, 0); return b; };
const u16 = (n) => { const b = Buffer.alloc(2); b.writeUInt16LE(n & 0xffff, 0); return b; };

/** Một khối RIFF: mã bốn ký tự + độ dài + thân, đệm cho chẵn byte. */
function khoi(ma, than) {
  const le = than.length % 2 === 1 ? Buffer.concat([than, Buffer.alloc(1)]) : than;
  return Buffer.concat([fourcc(ma), u32(than.length), le]);
}

function danhSach(kieu, cacKhoi) {
  const than = Buffer.concat(cacKhoi);
  return Buffer.concat([fourcc('LIST'), u32(than.length + 4), fourcc(kieu), than]);
}

/** avih — thông số chung của cả phim. */
function _avih({ fps, soKhung, rong, cao, byteMoiGiay, soLuong = 2 }) {
  const b = Buffer.alloc(56);
  b.writeUInt32LE(Math.round(1_000_000 / fps), 0);     // số micro giây một khung
  b.writeUInt32LE(byteMoiGiay, 4);
  b.writeUInt32LE(0, 8);
  b.writeUInt32LE(0x10 | 0x100, 12);                   // có bảng tra + xen kẽ chuẩn
  b.writeUInt32LE(soKhung, 16);
  b.writeUInt32LE(0, 20);
  // Khai đúng số luồng thật: phim câm mà khai hai luồng thì trình phát đi tìm
  // luồng tiếng không có, có máy báo tệp hỏng.
  b.writeUInt32LE(soLuong, 24);
  b.writeUInt32LE(rong * cao * 3, 28);
  b.writeUInt32LE(rong, 32);
  b.writeUInt32LE(cao, 36);
  return khoi('avih', b);
}

/** strh — tiêu đề một luồng. */
function _strh({ kieu, handler, scale, rate, length, mauByte, demXuat, rong = 0, cao = 0 }) {
  const b = Buffer.alloc(56);
  fourcc(kieu).copy(b, 0);
  if (handler) fourcc(handler).copy(b, 4); else b.writeUInt32LE(1, 4);
  b.writeUInt32LE(0, 8);
  b.writeUInt16LE(0, 12); b.writeUInt16LE(0, 14);
  b.writeUInt32LE(0, 16);
  b.writeUInt32LE(scale, 20);
  b.writeUInt32LE(rate, 24);
  b.writeUInt32LE(0, 28);
  b.writeUInt32LE(length, 32);
  b.writeUInt32LE(demXuat, 36);
  b.writeUInt32LE(0xffffffff, 40);                     // chất lượng: mặc định
  b.writeUInt32LE(mauByte, 44);
  b.writeUInt16LE(0, 48); b.writeUInt16LE(0, 50);
  b.writeUInt16LE(rong, 52); b.writeUInt16LE(cao, 54);
  return khoi('strh', b);
}

/** strf cho luồng hình — BITMAPINFOHEADER. */
function _strfVideo(rong, cao) {
  const b = Buffer.alloc(40);
  b.writeUInt32LE(40, 0);
  b.writeInt32LE(rong, 4);
  b.writeInt32LE(cao, 8);
  b.writeUInt16LE(1, 12);
  b.writeUInt16LE(24, 14);
  fourcc('MJPG').copy(b, 16);
  b.writeUInt32LE(rong * cao * 3, 20);
  return khoi('strf', b);
}

/** strf cho luồng tiếng — WAVEFORMATEX, PCM. */
function _strfAudio({ kenh, tanSo, bit }) {
  const b = Buffer.alloc(18);
  b.writeUInt16LE(1, 0);                               // 1 = PCM không nén
  b.writeUInt16LE(kenh, 2);
  b.writeUInt32LE(tanSo, 4);
  b.writeUInt32LE((tanSo * kenh * bit) / 8, 8);
  b.writeUInt16LE((kenh * bit) / 8, 12);
  b.writeUInt16LE(bit, 14);
  b.writeUInt16LE(0, 16);
  return khoi('strf', b);
}

/**
 * Ghi một tệp AVI hoàn chỉnh.
 *
 * @param {object} o
 * @param {Array<Buffer>} o.khungJPEG  các khung hình đã mã hoá JPEG
 * @param {Int16Array|Float32Array|null} o.tieng  mẫu tiếng (mono)
 * @param {number} o.fps
 * @param {number} o.rong, o.cao
 * @param {number} o.tanSo  tần số lấy mẫu của tiếng
 */
function ghiAVI({ khungJPEG, tieng = null, fps = 12, rong, cao, tanSo = 22050 }) {
  if (!khungJPEG || !khungJPEG.length) return { ok: false, error: 'KHÔNG_CÓ_KHUNG_HÌNH' };
  const soKhung = khungJPEG.length;
  const kenh = 1;
  const bit = 16;

  // Tiếng về Int16 — PCM trong AVI là số nguyên có dấu.
  let pcm = null;
  if (tieng && tieng.length) {
    pcm = tieng instanceof Int16Array
      ? tieng
      : Int16Array.from(tieng, (x) => Math.max(-32768, Math.min(32767, Math.round(x * 32767))));
  }
  const mauMoiKhung = pcm ? Math.floor(tanSo / fps) : 0;

  // ── Thân phim: xen kẽ một khung hình rồi tới tiếng của đúng khung đó ──
  const cacKhoi = [];
  const bangTra = [];
  let viTri = 4;                                        // tính từ mã 'movi'

  for (let i = 0; i < soKhung; i++) {
    const v = khoi('00dc', khungJPEG[i]);
    bangTra.push({ ma: '00dc', co: 0x10, offset: viTri, dai: khungJPEG[i].length });
    viTri += v.length;
    cacKhoi.push(v);

    if (pcm) {
      const tu = i * mauMoiKhung;
      const den = Math.min(pcm.length, tu + mauMoiKhung);
      if (den > tu) {
        const than = Buffer.from(pcm.buffer, pcm.byteOffset + tu * 2, (den - tu) * 2);
        const a = khoi('01wb', than);
        bangTra.push({ ma: '01wb', co: 0x10, offset: viTri, dai: than.length });
        viTri += a.length;
        cacKhoi.push(a);
      }
    }
  }

  // Tiếng còn thừa (dài hơn hình) được gắn vào cuối thay vì cắt bỏ.
  if (pcm && pcm.length > soKhung * mauMoiKhung) {
    const tu = soKhung * mauMoiKhung;
    const than = Buffer.from(pcm.buffer, pcm.byteOffset + tu * 2, (pcm.length - tu) * 2);
    const a = khoi('01wb', than);
    bangTra.push({ ma: '01wb', co: 0x10, offset: viTri, dai: than.length });
    viTri += a.length;
    cacKhoi.push(a);
  }

  const movi = danhSach('movi', cacKhoi);

  // ── idx1: bảng tra, thiếu nó thì trình phát không tua được ──
  const idx = Buffer.alloc(bangTra.length * 16);
  bangTra.forEach((e, i) => {
    fourcc(e.ma).copy(idx, i * 16);
    idx.writeUInt32LE(e.co, i * 16 + 4);
    idx.writeUInt32LE(e.offset, i * 16 + 8);
    idx.writeUInt32LE(e.dai, i * 16 + 12);
  });

  const tongByteHinh = khungJPEG.reduce((s, b) => s + b.length, 0);
  const byteMoiGiay = Math.round((tongByteHinh / soKhung) * fps + (pcm ? tanSo * 2 : 0));

  const hdrl = danhSach('hdrl', [
    _avih({ fps, soKhung, rong, cao, byteMoiGiay, soLuong: pcm ? 2 : 1 }),
    danhSach('strl', [
      _strh({ kieu: 'vids', handler: 'MJPG', scale: 1, rate: fps, length: soKhung, mauByte: 0, demXuat: Math.max(...khungJPEG.map((b) => b.length)), rong, cao }),
      _strfVideo(rong, cao),
    ]),
    ...(pcm ? [danhSach('strl', [
      _strh({ kieu: 'auds', handler: null, scale: (kenh * bit) / 8, rate: (tanSo * kenh * bit) / 8, length: pcm.length, mauByte: (kenh * bit) / 8, demXuat: mauMoiKhung * 2 }),
      _strfAudio({ kenh, tanSo, bit }),
    ])] : []),
  ]);

  const than = Buffer.concat([fourcc('AVI '), hdrl, movi, khoi('idx1', idx)]);
  const tep = Buffer.concat([fourcc('RIFF'), u32(than.length), than]);

  return {
    ok: true,
    tep,
    soKhung,
    fps,
    giay: round(soKhung / fps, 2),
    rong, cao,
    coTieng: !!pcm,
    tieng: pcm ? { tanSo, kenh, bit, mau: pcm.length, giay: round(pcm.length / tanSo, 2) } : null,
    byte: tep.length,
    byteMoiGiay,
    note: 'MJPEG + PCM: mở được bằng VLC/mpv, không cần cài gì. Nặng hơn H.264 nhiều lần.',
  };
}

/**
 * Đọc lại tệp AVI — dùng để tự kiểm tra tệp mình vừa ghi.
 * `layKhoi: true` trả về luôn từng khối hình và khối tiếng, để kiểm tra được
 * đến tận nội dung (mỗi khung có giải nén ra JPEG được không, đường tiếng dài
 * bao nhiêu giây thật) chứ không chỉ tin vào con số ghi trong tiêu đề.
 */
function docAVI(buf, { layKhoi = false } = {}) {
  if (!Buffer.isBuffer(buf) || buf.length < 32) return { ok: false, error: 'TỆP_QUÁ_NGẮN' };
  if (buf.toString('ascii', 0, 4) !== 'RIFF' || buf.toString('ascii', 8, 12) !== 'AVI ') {
    return { ok: false, error: 'KHÔNG_PHẢI_TỆP_AVI' };
  }
  const kichThuocKhai = buf.readUInt32LE(4);
  let p = 12;
  let avih = null;
  const luong = [];
  let soKhoiHinh = 0;
  let soKhoiTieng = 0;
  let byteTieng = 0;
  let coBangTra = false;
  const khoiHinh = [];
  const khoiTieng = [];

  const quet = (tu, den, trongMovi) => {
    let q = tu;
    while (q + 8 <= den) {
      const ma = buf.toString('ascii', q, q + 4);
      const len = buf.readUInt32LE(q + 4);
      if (ma === 'LIST') {
        const kieu = buf.toString('ascii', q + 8, q + 12);
        quet(q + 12, Math.min(den, q + 8 + len), kieu === 'movi');
      } else if (ma === 'avih') {
        avih = {
          microGiayMoiKhung: buf.readUInt32LE(q + 8),
          soKhung: buf.readUInt32LE(q + 8 + 16),
          soLuong: buf.readUInt32LE(q + 8 + 24),
          rong: buf.readUInt32LE(q + 8 + 32),
          cao: buf.readUInt32LE(q + 8 + 36),
        };
      } else if (ma === 'strh') {
        luong.push({
          kieu: buf.toString('ascii', q + 8, q + 12),
          handler: buf.toString('ascii', q + 12, q + 16),
          dai: buf.readUInt32LE(q + 8 + 32),
        });
      } else if (ma === 'idx1') {
        coBangTra = true;
      } else if (trongMovi) {
        if (ma.endsWith('dc')) {
          soKhoiHinh++;
          if (layKhoi) khoiHinh.push(buf.subarray(q + 8, q + 8 + len));
        } else if (ma.endsWith('wb')) {
          soKhoiTieng++;
          byteTieng += len;
          if (layKhoi) khoiTieng.push(buf.subarray(q + 8, q + 8 + len));
        }
      }
      q += 8 + len + (len % 2);
    }
  };
  quet(p, buf.length, false);

  if (!avih) return { ok: false, error: 'AVI_THIẾU_TIÊU_ĐỀ_AVIH' };
  return {
    ok: true,
    rong: avih.rong, cao: avih.cao,
    soKhung: avih.soKhung,
    fps: round(1_000_000 / avih.microGiayMoiKhung, 2),
    soLuong: avih.soLuong,
    luong,
    soKhoiHinh,
    soKhoiTieng,
    byteTieng,
    coBangTra,
    kichThuocKhaiDung: kichThuocKhai + 8 === buf.length,
    // Tên cũ giữ lại cho mã đang gọi: trước đây hai trường này là số đếm.
    khoiHinh: layKhoi ? khoiHinh : soKhoiHinh,
    khoiTieng: layKhoi ? khoiTieng : soKhoiTieng,
  };
}

/** Tiện ích: dựng AVI thẳng từ danh sách ảnh RGBA. */
function tuAnh({ anhList, tieng = null, fps = 12, tanSo = 22050, chatLuongJpeg = 88 }) {
  if (!anhList || !anhList.length) return { ok: false, error: 'KHÔNG_CÓ_ẢNH' };
  const rong = anhList[0].width;
  const cao = anhList[0].height;
  const khac = anhList.find((a) => a.width !== rong || a.height !== cao);
  if (khac) return { ok: false, error: 'CÁC_KHUNG_KHÔNG_CÙNG_KÍCH_THƯỚC', goi: 'Mọi khung phải cùng độ phân giải.' };
  const khungJPEG = anhList.map((a) => ghiJPEG(a, { chatLuong: chatLuongJpeg }));
  return ghiAVI({ khungJPEG, tieng, fps, rong, cao, tanSo });
}

module.exports = { ghiAVI, docAVI, tuAnh };
