'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HỒ SƠ NHÂN VẬT — khoá ngoại hình để mặt không đổi giữa các cảnh
 * ═══════════════════════════════════════════════════════════════════════════
 *  Lỗi lớn nhất của phim dựng bằng AI: sang cảnh sau nhân vật thành người
 *  khác. Nguyên nhân gần như luôn giống nhau — mỗi cảnh viết một prompt mô tả
 *  ngoại hình một kiểu.
 *
 *  Cách chặn: mỗi nhân vật có MỘT chuỗi mô tả duy nhất ("khoá ngoại hình"),
 *  sinh ra một lần rồi CHÈN NGUYÊN VĂN vào mọi prompt có nhân vật đó. Khoá
 *  được băm lại để kiểm tra: prompt nào thiếu khoá là hệ thống phát hiện ngay
 *  ở khâu soát chất lượng, chứ không đợi xem phim mới biết.
 *
 *  Mô tả được rút từ chính kịch bản bằng luật (tuổi, tóc, kính, trang phục…),
 *  nên không có khoá LLM vẫn dựng được hồ sơ. Có LLM thì phần mô tả được viết
 *  mượt hơn, nhưng khoá vẫn do hệ thống giữ.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { sha256, viKey, round } = require('../utils');

/** Từ khoá ngoại hình trong tiếng Việt → cụm tiếng Anh cho prompt hình ảnh. */
const NET_NGOAI_HINH = [
  { keys: ['toc bac', 'bac dau', 'toc trang'], vi: 'tóc bạc', anh: 'silver grey hair' , nhom: 'toc' },
  { keys: ['toc den'], vi: 'tóc đen', anh: 'black hair' , nhom: 'toc' },
  { keys: ['toc tet hai bim', 'tet hai bim', 'hai bim'], vi: 'tóc tết hai bím', anh: 'hair in twin braids' , nhom: 'toc' },
  { keys: ['toc dai'], vi: 'tóc dài', anh: 'long hair' , nhom: 'toc' },
  { keys: ['toc ngan'], vi: 'tóc ngắn', anh: 'short hair' , nhom: 'toc' },
  { keys: ['hoi bac', 'muoi tieu'], vi: 'tóc muối tiêu', anh: 'salt and pepper hair' , nhom: 'toc' },
  { keys: ['deo kinh gong vang', 'kinh gong vang'], vi: 'kính gọng vàng', anh: 'gold-rimmed glasses' , nhom: 'kinh' },
  { keys: ['deo kinh', 'kinh can'], vi: 'đeo kính', anh: 'wearing glasses' , nhom: 'kinh' },
  { keys: ['ao so mi trang'], vi: 'áo sơ mi trắng', anh: 'white dress shirt' , nhom: 'trang-phuc' },
  { keys: ['ao dai'], vi: 'áo dài', anh: 'traditional Vietnamese ao dai' , nhom: 'trang-phuc' },
  { keys: ['dong phuc hoc sinh', 'ao dong phuc', 'dong phuc'], vi: 'đồng phục học sinh', anh: 'school uniform' , nhom: 'trang-phuc' },
  { keys: ['ao ba ba'], vi: 'áo bà ba', anh: 'traditional ba ba shirt' , nhom: 'trang-phuc' },
  { keys: ['non la'], vi: 'nón lá', anh: 'conical leaf hat' , nhom: 'mu' },
  { keys: ['rau'], vi: 'có râu', anh: 'with a beard' , nhom: 'rau' },
  { keys: ['nga mau', 'cu ky', 'sờn'], vi: 'trang phục cũ', anh: 'worn faded clothing' , nhom: 'tinh-trang' },
  { keys: ['nu cuoi tuoi', 'cuoi tuoi'], vi: 'nụ cười tươi', anh: 'bright smile' , nhom: 'net-mat' },
  { keys: ['hien tu', 'phuc hau'], vi: 'nét hiền', anh: 'kind gentle face' , nhom: 'net-mat' },
  { keys: ['nep nhan'], vi: 'nhiều nếp nhăn', anh: 'deep wrinkles' , nhom: 'net-mat' },
  { keys: ['gay'], vi: 'gầy', anh: 'slim build' , nhom: 'voc' },
  { keys: ['cao lon', 'vam vo'], vi: 'vóc lớn', anh: 'tall sturdy build' , nhom: 'voc' },
];

/**
 * Suy giới tính từ cách gọi — chỉ để chọn giọng, và luôn ghi đè được.
 * So theo TỪ chứ không so theo chuỗi con: "có" trong đoạn tả mà đem so với
 * "cô " thì thầy giáo thành nữ.
 */
const TU_NU = new Set(['co', 'ba', 'chi', 'me', 'ma', 'nu', 'gai', 'bi', 'chau gai', 'nang']);
const TU_NAM = new Set(['ong', 'anh', 'chu', 'bo', 'cha', 'thay', 'nam', 'trai', 'cau', 'bac']);

/** Suy tuổi từ chữ trong kịch bản: "khoảng 60 tuổi", "10 tuổi". */
function doTuoi(text) {
  const m = String(text).match(/(\d{1,3})\s*tuổi/i);
  if (m) return Number(m[1]);
  const k = viKey(text);
  if (/\b(cu|lao|gia)\b/.test(k)) return 70;
  if (/be gai|be trai|co be|cau be|thieu nhi/.test(k)) return 10;
  if (/thanh nien|sinh vien/.test(k)) return 22;
  return null;
}

function doGioiTinh(ten, moTa) {
  const tuTen = viKey(ten).split(/\s+/).filter(Boolean);
  // Tên vai là căn cứ chắc nhất: "THẦY GIÁO", "CÔ BÉ", "BÀ CỤ".
  for (const t of tuTen) { if (TU_NU.has(t)) return 'nữ'; if (TU_NAM.has(t)) return 'nam'; }
  // Không có tín hiệu trong tên thì mới dò đoạn tả, cũng theo từ.
  const tuMoTa = viKey(moTa).split(/\s+/).filter(Boolean);
  for (const t of tuMoTa) { if (TU_NU.has(t)) return 'nữ'; if (TU_NAM.has(t)) return 'nam'; }
  return 'nam';
}

/** Rút các nét ngoại hình có thật trong kịch bản — không bịa thêm nét nào. */
function rutNetNgoaiHinh(text) {
  const k = viKey(text);
  const net = [];
  // Mỗi nhóm chỉ lấy nét ĐẦU TIÊN khớp, vì bảng xếp nét cụ thể trước nét
  // chung. "kính gọng vàng" đã khớp thì không thêm "đeo kính" nữa — prompt
  // lặp hai lần cùng một ý làm mô hình vẽ hai cặp kính.
  const daNhom = new Set();
  for (const n of NET_NGOAI_HINH) {
    if (n.nhom && daNhom.has(n.nhom)) continue;
    for (const key of n.keys) {
      if (k.includes(key)) { net.push(n); if (n.nhom) daNhom.add(n.nhom); break; }
    }
  }
  return net;
}

/**
 * Gom những đoạn hành động thật sự tả nhân vật này.
 *
 * Hai luật, vì kịch bản tiếng Việt gọi nhân vật hai kiểu khác nhau:
 *  1) Trong dòng thoại là tên vai viết hoa — "THẦY GIÁO".
 *  2) Trong đoạn tả lại là danh xưng đời thường — "một ông giáo già".
 * Bắt phải trùng ĐỦ mọi chữ trong tên thì không bao giờ khớp. Nên: trùng MỘT
 * chữ có nghĩa là đủ làm ứng viên, CỘNG THÊM luật vị trí — đoạn ngay trước
 * lời thoại ĐẦU TIÊN của nhân vật gần như luôn là đoạn giới thiệu họ.
 */
function gomMoTa(kichBan, nhanVat) {
  const tuTen = viKey(nhanVat.ten).split(/\s+/).filter((w) => w.length > 2);
  const doan = [];
  const them = (s) => { if (s && !doan.includes(s)) doan.push(s); };

  // Luật 1 — nhắc tên trong đoạn tả
  for (const canh of kichBan.canh) {
    for (const khoi of canh.khoi) {
      if (khoi.kind !== 'hanhDong') continue;
      const k = viKey(khoi.moTa);
      if (tuTen.some((w) => k.includes(w))) them(khoi.moTa);
    }
  }

  // Luật 2 — hai đoạn tả ngay trước lời thoại đầu tiên
  let xong = false;
  for (const canh of kichBan.canh) {
    if (xong) break;
    const truoc = [];
    for (const khoi of canh.khoi) {
      if (khoi.kind === 'hanhDong') { truoc.push(khoi.moTa); continue; }
      if (khoi.kind === 'thoai' && khoi.nhanVat === nhanVat.id) {
        for (const m of truoc.slice(-2)) them(m);
        xong = true;
        break;
      }
      if (khoi.kind === 'thoai') truoc.length = 0;   // đoạn tả đó là của người khác
    }
  }
  return doan;
}

/**
 * Dựng hồ sơ cho toàn bộ nhân vật.
 * @param {object} kichBan kết quả của docKichBan()
 * @param {object} o {ghiDe: {nvId: {gioiTinh, tuoi, ngoaiHinh, voiceId}}}
 */
function dungHoSo(kichBan, { ghiDe = {} } = {}) {
  const ho = [];
  for (const nv of kichBan.nhanVat) {
    const g = ghiDe[nv.id] || {};
    const doanMoTa = gomMoTa(kichBan, nv);
    const moTaGoc = g.ngoaiHinh || doanMoTa.join(' ');
    const net = rutNetNgoaiHinh(moTaGoc);
    const tuoi = g.tuoi ?? doTuoi(moTaGoc) ?? null;
    const gioiTinh = g.gioiTinh || doGioiTinh(nv.ten, moTaGoc);

    // ── KHOÁ NGOẠI HÌNH: một chuỗi duy nhất, chèn nguyên văn vào mọi prompt ──
    const tuoiAnh = tuoi == null ? '' : tuoi >= 60 ? `elderly Vietnamese ${gioiTinh === 'nữ' ? 'woman' : 'man'} around ${tuoi}`
      : tuoi <= 12 ? `Vietnamese ${gioiTinh === 'nữ' ? 'girl' : 'boy'} around ${tuoi} years old`
        : `Vietnamese ${gioiTinh === 'nữ' ? 'woman' : 'man'} around ${tuoi}`;
    const phan = [tuoiAnh || `Vietnamese ${gioiTinh === 'nữ' ? 'woman' : 'man'}`, ...net.map((n) => n.anh)];
    const khoaNgoaiHinh = phan.filter(Boolean).join(', ');

    ho.push({
      id: nv.id,
      ten: nv.ten,
      soLuotThoai: nv.soLuotThoai,
      gioiTinh,
      tuoi,
      netNgoaiHinh: net.map((n) => n.vi),
      moTaViet: net.length ? `${tuoi ? `khoảng ${tuoi} tuổi, ` : ''}${net.map((n) => n.vi).join(', ')}`
        : (moTaGoc.slice(0, 160) || 'Kịch bản chưa tả ngoại hình'),
      khoaNgoaiHinh,
      maKhoa: sha256(khoaNgoaiHinh).slice(0, 12),
      thieuMoTa: net.length < 2,
      huongDanDienXuat: nv.huongDan,
      // Bốn góc tham chiếu để dựng ảnh nhân vật trước khi quay.
      anhThamChieu: [
        { goc: 'Chính diện', prompt: `${khoaNgoaiHinh}, front view facing camera, neutral expression, plain background, photorealistic portrait, 8K` },
        { goc: 'Nghiêng', prompt: `${khoaNgoaiHinh}, side profile view, plain background, photorealistic portrait, 8K` },
        { goc: 'Cận mặt', prompt: `${khoaNgoaiHinh}, close-up face portrait, soft even lighting, photorealistic, 8K` },
        { goc: 'Toàn thân', prompt: `${khoaNgoaiHinh}, full body standing, plain background, photorealistic, 8K` },
      ],
      // Giữ lại chính những đoạn kịch bản đã dùng để dựng hồ sơ: khâu phân
      // cảnh cần biết đoạn tả nào là của ai, mà so tên thì không khớp ("THẦY
      // GIÁO" trong dòng thoại nhưng "một ông giáo già" trong đoạn tả).
      doanMoTa,
      giongNoi: g.voiceId || null,     // gán ở bước dựng tiếng
    });
  }

  const thieu = ho.filter((h) => h.thieuMoTa);
  return {
    ok: true,
    nhanVat: ho,
    canhBao: thieu.map((h) => ({
      nhanVat: h.id, loai: 'THIẾU_MÔ_TẢ_NGOẠI_HÌNH',
      note: `Kịch bản tả "${h.ten}" quá sơ sài (${h.netNgoaiHinh.length} nét). Mặt sẽ đổi giữa các cảnh. `
        + 'Hãy thêm mô tả vào kịch bản hoặc truyền ghiDe.ngoaiHinh.',
    })),
  };
}

/** Kiểm tra một prompt có mang đủ khoá ngoại hình của các nhân vật trong cảnh không. */
function soatKhoa(prompt, nhanVatTrongCanh, hoSo) {
  const thieu = [];
  for (const id of nhanVatTrongCanh || []) {
    const h = hoSo.find((x) => x.id === id);
    if (!h) { thieu.push({ id, ly: 'KHÔNG_CÓ_HỒ_SƠ' }); continue; }
    if (!String(prompt).includes(h.khoaNgoaiHinh)) thieu.push({ id, ten: h.ten, ly: 'PROMPT_THIẾU_KHOÁ_NGOẠI_HÌNH' });
  }
  return { ok: thieu.length === 0, thieu };
}

/**
 * Đoạn mô tả này nhắc tới những nhân vật nào.
 *
 * Không đủ nếu chỉ hỏi "đoạn này có nằm trong hồ sơ nhân vật không": đoạn tả
 * căn phòng ngay trước lời thoại cũng bị gom vào hồ sơ, mà toàn cảnh lớp học
 * trống thì không được gắn khoá ngoại hình của thầy giáo — gắn vào là khâu
 * soát chất lượng đi tìm một người không có trong khung hình.
 *
 * Nên: trùng một chữ có nghĩa trong tên, HOẶC đoạn đó tả ít nhất hai nét
 * ngoại hình đúng của nhân vật này.
 */
function nhacToi(moTa, hoSo) {
  const k = viKey(moTa);
  const netTrongDoan = new Set(rutNetNgoaiHinh(moTa).map((n) => n.vi));
  const ra = [];
  for (const h of hoSo) {
    const tu = viKey(h.ten).split(/\s+/).filter((w) => w.length > 2);
    if (tu.length && tu.some((w) => k.includes(w))) { ra.push(h.id); continue; }
    const trung = (h.netNgoaiHinh || []).filter((n) => netTrongDoan.has(n)).length;
    if (trung >= 2) ra.push(h.id);
  }
  return ra;
}

module.exports = { dungHoSo, soatKhoa, nhacToi, rutNetNgoaiHinh, doTuoi, doGioiTinh, NET_NGOAI_HINH };
