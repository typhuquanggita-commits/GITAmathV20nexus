'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐỌC KỊCH BẢN PHIM — bằng luật, không bằng mô hình
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế GITAfilm giao việc đọc kịch bản cho LLM rồi bắt nó trả JSON.
 *  Cách đó có ba chỗ hỏng:
 *    1. không có khoá API thì không đọc được kịch bản — kể cả kịch bản đúng
 *       chuẩn, ai cũng đọc được bằng mắt
 *    2. mô hình sinh JSON không ổn định: cùng một kịch bản, hai lần chạy ra
 *       hai bản phân cảnh khác nhau, không dựng lại được
 *    3. mô hình lặng lẽ bịa: thêm nhân vật không có trong kịch bản, đổi lời
 *       thoại cho "mượt hơn"
 *
 *  Kịch bản điện ảnh là VĂN BẢN CÓ CẤU TRÚC — tiêu đề cảnh, dòng nhân vật,
 *  lời thoại, hành động — nên đọc được bằng luật, tất định, không bịa.
 *  LLM chỉ được dùng để LÀM GIÀU (gợi ý góc máy, dịch prompt hình ảnh), và
 *  khi không có khoá thì phần làm giàu bị bỏ qua chứ phim vẫn dựng được.
 *
 *  Định dạng nhận vào (chuẩn kịch bản Việt):
 *      TIÊU ĐỀ: …            THỂ LOẠI: …
 *      CẢNH 1 - INT. LỚP HỌC CŨ - CHIỀU MUỘN
 *      <đoạn mô tả hành động>
 *      THẦY GIÁO (lẩm bẩm): "Ba mươi năm rồi…"
 *      HẾT
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { viKey, round } = require('../utils');

/** Trong/ngoài cảnh. */
const NOI_QUAY = {
  'INT': { code: 'INT', name: 'Trong nhà', anh: 'interior' },
  'NỘI': { code: 'INT', name: 'Trong nhà', anh: 'interior' },
  'NOI': { code: 'INT', name: 'Trong nhà', anh: 'interior' },
  'EXT': { code: 'EXT', name: 'Ngoài trời', anh: 'exterior' },
  'NGOẠI': { code: 'EXT', name: 'Ngoài trời', anh: 'exterior' },
  'NGOAI': { code: 'EXT', name: 'Ngoài trời', anh: 'exterior' },
};

/** Thời điểm trong ngày → ánh sáng để viết prompt hình ảnh. */
const THOI_DIEM = [
  { keys: ['binh minh', 'rang dong'], name: 'Bình minh', anh: 'dawn, soft pink light' },
  { keys: ['sang som'], name: 'Sáng sớm', anh: 'early morning, cool light' },
  { keys: ['sang'], name: 'Buổi sáng', anh: 'morning, bright natural light' },
  { keys: ['trua'], name: 'Buổi trưa', anh: 'midday, hard overhead sunlight' },
  { keys: ['chieu muon', 'xe chieu'], name: 'Chiều muộn', anh: 'late afternoon, golden hour' },
  { keys: ['chieu'], name: 'Buổi chiều', anh: 'afternoon, warm light' },
  { keys: ['hoang hon'], name: 'Hoàng hôn', anh: 'sunset, orange rim light' },
  { keys: ['toi'], name: 'Buổi tối', anh: 'evening, warm practical lights' },
  { keys: ['dem khuya', 'nua dem'], name: 'Đêm khuya', anh: 'late night, moonlight, deep shadows' },
  { keys: ['dem'], name: 'Ban đêm', anh: 'night, low key lighting' },
  { keys: ['ngay'], name: 'Ban ngày', anh: 'daylight' },
];

function nhanThoiDiem(text) {
  const k = viKey(String(text || ''));
  for (const t of THOI_DIEM) for (const key of t.keys) if (k.includes(key)) return t;
  return { name: String(text || 'Ban ngày').trim() || 'Ban ngày', anh: 'natural light' };
}

/** Dòng tiêu đề cảnh: "CẢNH 1 - INT. LỚP HỌC CŨ - CHIỀU MUỘN" */
const RE_CANH = /^\s*(?:CẢNH|CANH|SCENE)\s*(\d+)\s*[-–—:.]\s*(.+)$/i;
/** Dòng nhân vật: "THẦY GIÁO (lẩm bẩm): lời" — tên viết hoa, tối đa 5 từ. */
const RE_THOAI = /^\s*([A-ZÀ-Ỹ][A-ZÀ-Ỹ0-9\s.'-]{1,40})\s*(?:\(([^)]*)\))?\s*:\s*(.+)$/;
/** Dòng đầu tệp: "TIÊU ĐỀ: …" */
const RE_META = /^\s*(TIÊU ĐỀ|TIEU DE|THỂ LOẠI|THE LOAI|TÁC GIẢ|TAC GIA|THỜI LƯỢNG|THOI LUONG)\s*:\s*(.+)$/i;

const META_KEY = {
  'tieu de': 'tieuDe', 'the loai': 'theLoai', 'tac gia': 'tacGia', 'thoi luong': 'thoiLuongMongMuon',
};

/** Bỏ dấu ngoặc kép quanh lời thoại — kịch bản Việt hay viết cả hai kiểu. */
function boNgoacKep(s) {
  const t = String(s).trim();
  if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith('“') && t.endsWith('”'))
    || (t.startsWith("'") && t.endsWith("'"))) return t.slice(1, -1).trim();
  return t;
}

/** Tên nhân vật → mã ổn định, không phụ thuộc thứ tự xuất hiện. */
function maNhanVat(ten) {
  const k = viKey(ten).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  return `nv-${k || 'vo-danh'}`;
}

/**
 * Đọc một kịch bản thành cấu trúc.
 * @param {string} text nội dung kịch bản
 * @returns {object} {ok, tieuDe, theLoai, nhanVat[], canh[], canhBao[], thongKe}
 */
function docKichBan(text) {
  const raw = String(text || '');
  if (!raw.trim()) return { ok: false, error: 'KỊCH_BẢN_RỖNG' };

  const lines = raw.split(/\r?\n/);
  const meta = {};
  const canh = [];
  const nhanVatMap = new Map();
  const canhBao = [];
  let cur = null;
  let soDong = 0;

  const dongVaoCanh = (kind, payload, line) => {
    if (!cur) {
      // Có nội dung trước khi mở cảnh đầu tiên: dựng một cảnh mở đầu chứ
      // không vứt đi — nhiều người viết quên dòng "CẢNH 1".
      cur = { so: 1, tieuDeGoc: 'MỞ ĐẦU', noiQuay: null, diaDiem: 'Không ghi rõ', thoiDiem: nhanThoiDiem(''), khoi: [] };
      canhBao.push({ dong: line, loai: 'THIẾU_TIÊU_ĐỀ_CẢNH', note: 'Có nội dung trước dòng "CẢNH 1" — đã gom vào cảnh mở đầu.' });
      canh.push(cur);
    }
    cur.khoi.push({ ...payload, kind, dong: line });
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const t = line.trim();
    soDong++;
    if (!t) continue;
    if (/^\s*(HẾT|HET|THE END|KẾT THÚC)\s*\.?\s*$/i.test(t)) break;

    const m = t.match(RE_META);
    if (m && !cur) { meta[META_KEY[viKey(m[1])] || viKey(m[1])] = m[2].trim(); continue; }

    const c = t.match(RE_CANH);
    if (c) {
      const head = c[2].trim();
      // "INT. LỚP HỌC CŨ - CHIỀU MUỘN"
      const parts = head.split(/\s*[-–—]\s*/);
      let noi = null;
      let diaDiem = parts[0] || '';
      const mNoi = diaDiem.match(/^\s*(INT|EXT|NỘI|NOI|NGOẠI|NGOAI)\s*\.?\s*(.*)$/i);
      if (mNoi) { noi = NOI_QUAY[mNoi[1].toUpperCase()] || null; diaDiem = mNoi[2].trim(); }
      const thoi = nhanThoiDiem(parts.slice(1).join(' - '));
      cur = {
        so: Number(c[1]) || canh.length + 1,
        tieuDeGoc: head,
        noiQuay: noi,
        diaDiem: diaDiem || 'Không ghi rõ',
        thoiDiem: thoi,
        khoi: [],
      };
      canh.push(cur);
      if (!noi) canhBao.push({ dong: i + 1, loai: 'THIẾU_NỘI_NGOẠI', note: `Cảnh ${cur.so} không ghi INT./EXT. — mặc định coi là trong nhà.` });
      continue;
    }

    const d = t.match(RE_THOAI);
    // Dòng nhân vật phải VIẾT HOA và ngắn; nếu không thì đó là câu mô tả có
    // dấu hai chấm, đừng nhầm thành lời thoại.
    if (d && d[1].trim().split(/\s+/).length <= 5 && d[1] === d[1].toUpperCase()) {
      const ten = d[1].trim().replace(/\s+/g, ' ');
      const id = maNhanVat(ten);
      if (!nhanVatMap.has(id)) nhanVatMap.set(id, { id, ten, soLuotThoai: 0, huongDan: new Set() });
      const nv = nhanVatMap.get(id);
      nv.soLuotThoai++;
      if (d[2]) nv.huongDan.add(d[2].trim().toLowerCase());
      dongVaoCanh('thoai', { nhanVat: id, tenNhanVat: ten, huongDan: d[2] ? d[2].trim() : null, loi: boNgoacKep(d[3]) }, i + 1);
      continue;
    }

    dongVaoCanh('hanhDong', { moTa: t }, i + 1);
  }

  if (!canh.length) return { ok: false, error: 'KHÔNG_TÌM_THẤY_CẢNH_NÀO', goi: 'Mỗi cảnh bắt đầu bằng dòng "CẢNH 1 - INT. ĐỊA ĐIỂM - THỜI GIAN".' };

  const nhanVat = [...nhanVatMap.values()].map((n) => ({
    ...n, huongDan: [...n.huongDan],
  })).sort((a, b) => b.soLuotThoai - a.soLuotThoai);

  // Cảnh không có nhân vật nào nói mà cũng không có hành động thì là cảnh rỗng.
  for (const s of canh) {
    if (!s.khoi.length) canhBao.push({ loai: 'CẢNH_RỖNG', note: `Cảnh ${s.so} không có nội dung.` });
  }

  const soThoai = canh.reduce((a, s) => a + s.khoi.filter((k) => k.kind === 'thoai').length, 0);
  const soHanhDong = canh.reduce((a, s) => a + s.khoi.filter((k) => k.kind === 'hanhDong').length, 0);

  return {
    ok: true,
    tieuDe: meta.tieuDe || 'Phim chưa đặt tên',
    theLoai: meta.theLoai || 'Chưa phân loại',
    tacGia: meta.tacGia || null,
    thoiLuongMongMuon: meta.thoiLuongMongMuon || null,
    nhanVat,
    canh,
    canhBao,
    thongKe: {
      dong: soDong, canh: canh.length, nhanVat: nhanVat.length,
      luotThoai: soThoai, doanHanhDong: soHanhDong,
      tuThoai: canh.reduce((a, s) => a + s.khoi.filter((k) => k.kind === 'thoai')
        .reduce((b, k) => b + k.loi.split(/\s+/).length, 0), 0),
    },
  };
}

module.exports = { docKichBan, nhanThoiDiem, maNhanVat, NOI_QUAY, THOI_DIEM };
