'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỰNG PHIM — cái gì làm được ngay, cái gì phải chờ
 * ═══════════════════════════════════════════════════════════════════════════
 *  Bản thiết kế gốc ghép phim bằng ffmpeg. Máy chủ này không có ffmpeg, và
 *  quan trọng hơn: chưa có KHOÁ API thì chưa có một mét phim nào để ghép.
 *  Nếu chỉ có đúng một đường đó thì hệ thống ngồi không cho tới khi người
 *  dùng nạp tiền.
 *
 *  Nên khâu dựng chia làm ba thứ, theo đúng thứ tự làm được:
 *
 *   1. ĐƯỜNG TIẾNG — làm được NGAY. Toàn bộ lời thoại được đọc bằng bộ giọng
 *      tiếng Việt của hệ thống, đặt đúng mốc thời gian của từng cảnh, ghép
 *      thành một tệp WAV duy nhất. Đây là đường tiếng thật của phim.
 *   2. PHIM NHÁP (animatic) — làm được NGAY. Bảng phân cảnh chạy theo đúng
 *      mốc thời gian, đồng bộ với đường tiếng, xuất ra một trang HTML mở bằng
 *      trình duyệt là xem được. Đạo diễn duyệt nhịp phim trước khi tiêu tiền.
 *   3. BẢN DỰNG CUỐI — cần clip video thật (có khoá API) và cần ffmpeg. Hệ
 *      thống sinh sẵn danh sách EDL, tệp concat và kịch bản ffmpeg; có clip
 *      là chạy một lệnh ra phim.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { toWav, fromWav, SAMPLE_RATE } = require('../voice/synth');
const { StudioChain } = require('../voice/dsp');
const { veBang } = require('./storyboard');
const { round } = require('../utils');

const esc = (s) => String(s ?? '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

/** Mốc thời gian dạng 00:00:05:12 (giờ:phút:giây:khung, 25 khung/giây). */
function timecode(giay, fps = 25) {
  const t = Math.max(0, giay);
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  // Khung hình trong timecode luôn CẮT, không làm tròn — làm tròn lên là
  // nhảy sang giây sau ở đúng nửa giây, hai phần mềm dựng đọc ra hai mốc khác nhau.
  const f = Math.floor((t - Math.floor(t)) * fps) % fps;
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${p(h)}:${p(m)}:${p(s)}:${p(f)}`;
}

/** Bảng mốc thời gian của cả phim. */
function dungMocThoiGian(canhQuay) {
  let at = 0;
  return canhQuay.map((c) => {
    const row = { ...c, batDau: round(at, 2), ketThuc: round(at + c.giay, 2), tcVao: timecode(at), tcRa: timecode(at + c.giay) };
    at += c.giay;
    return row;
  });
}

/**
 * ĐƯỜNG TIẾNG — đọc toàn bộ lời thoại, đặt đúng mốc, ghép thành một WAV.
 * @param {object} o {canhQuay, hoSoNhanVat, voice (VoiceService), learnerId}
 */
async function dungDuongTieng(canhQuay, hoSoNhanVat, { voice, preset = 'phat-thanh', demDauMs = 500 } = {}) {
  if (!voice) return { ok: false, error: 'CHƯA_GẮN_DỊCH_VỤ_GIỌNG' };
  const moc = dungMocThoiGian(canhQuay);
  const tongGiay = moc.length ? moc[moc.length - 1].ketThuc : 0;
  const sr = SAMPLE_RATE;
  const track = new Float32Array(Math.max(1, Math.ceil(tongGiay * sr)));
  const doan = [];

  for (const c of moc) {
    if (!c.thoai) continue;
    const nv = hoSoNhanVat.find((h) => h.id === c.thoai.nhanVat);
    const r = await voice.speak(c.thoai.loi, {
      voiceId: nv && nv.giongNoi ? nv.giongNoi : null,
      purpose: 'bai-dai',
      audible: false,          // dấu nghe được sẽ đóng một lần cho cả phim
      useCache: true,
    });
    if (!r.ok) { doan.push({ canhQuay: c.id, ok: false, loi: r.error }); continue; }
    const pcm = fromWav(r.wav);
    if (!pcm) { doan.push({ canhQuay: c.id, ok: false, loi: 'KHÔNG_ĐỌC_ĐƯỢC_WAV' }); continue; }

    const batDau = Math.round((c.batDau + demDauMs / 1000) * sr);
    const con = track.length - batDau;
    const n = Math.min(pcm.samples.length, Math.max(0, con));
    for (let i = 0; i < n; i++) track[batDau + i] += pcm.samples[i];

    doan.push({
      canhQuay: c.id, ok: true, nhanVat: c.thoai.tenNhanVat, giongNoi: r.voiceId,
      batDau: round(c.batDau + demDauMs / 1000, 2), ms: r.ms,
      tranRaNgoai: pcm.samples.length > con,
    });
  }

  // Chuẩn độ vang cho cả đường tiếng, không phải từng câu — nếu chuẩn riêng
  // từng câu thì câu to câu nhỏ, nghe như ghép từ nhiều buổi thu.
  const master = StudioChain.process(track, sr, { preset });
  return {
    ok: true,
    wav: toWav(master.samples, sr),
    sampleRate: sr,
    giay: round(tongGiay, 2),
    doan,
    tranRaNgoai: doan.filter((d) => d.tranRaNgoai).length,
    master: { preset: master.preset, before: master.before, after: master.after, steps: master.steps.length },
  };
}

/**
 * PHIM NHÁP — trang HTML tự chạy: khung phân cảnh đổi theo đúng mốc thời
 * gian, đồng bộ với đường tiếng. Mở bằng trình duyệt là xem được.
 */
function dungPhimNhap({ tieuDe, canhQuay, hoSoNhanVat, audioBase64 = null, duToan = null, qc = null }) {
  const moc = dungMocThoiGian(canhQuay);
  const bang = veBang(canhQuay, hoSoNhanVat, { rong: 960, cao: 540 });
  const tong = moc.length ? moc[moc.length - 1].ketThuc : 0;

  const khung = moc.map((c, i) => {
    const svg = bang[i].svg.replace(/<\?xml[^>]*\?>/g, '');
    return `<figure class="k" data-tu="${c.batDau}" data-den="${c.ketThuc}" id="k${i}">${svg}
      <figcaption>${esc(c.tcVao)} → ${esc(c.tcRa)} · ${esc(c.moTaViet).slice(0, 120)}</figcaption></figure>`;
  }).join('\n');

  const bangCanh = moc.map((c) => `<tr><td>${esc(c.id)}</td><td>${esc(c.tcVao)}</td><td>${c.giay}s</td>
    <td>${esc(c.coTen)}</td><td>${esc(c.boiCanh)}</td><td>${esc(c.modelTen || '—')}</td>
    <td>${c.thoai ? `“${esc(c.thoai.loi)}”` : ''}</td></tr>`).join('');

  return `<!DOCTYPE html>
<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(tieuDe)} — phim nháp</title>
<style>
:root{color-scheme:dark;--nen:#0c0e13;--the:#161a23;--vach:#262c3a;--chu:#e8ebf2;--mo:#98a2b6;--nhan:#ffb457}
*{box-sizing:border-box}body{margin:0;background:var(--nen);color:var(--chu);font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}
header{padding:18px 20px;border-bottom:1px solid var(--vach);display:flex;gap:16px;align-items:center;flex-wrap:wrap;position:sticky;top:0;background:var(--nen);z-index:5}
h1{font-size:19px;margin:0}.mo{color:var(--mo);font-size:13px}
main{max-width:1000px;margin:0 auto;padding:20px}
.k{margin:0 0 26px;display:none}.k.on{display:block}.k svg{width:100%;height:auto;border-radius:10px;border:1px solid var(--vach)}
figcaption{color:var(--mo);font-size:12.5px;margin-top:8px}
.dieu{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:8px 0 18px}
button{background:var(--the);color:var(--chu);border:1px solid var(--vach);border-radius:8px;padding:8px 14px;font:inherit;cursor:pointer}
button.chinh{background:var(--nhan);color:#1a1205;border-color:var(--nhan);font-weight:600}
#thanh{flex:1;min-width:200px;height:6px;background:var(--the);border-radius:3px;overflow:hidden}
#thanh i{display:block;height:100%;width:0;background:var(--nhan)}
table{width:100%;border-collapse:collapse;margin-top:14px;font-size:13px}
th,td{padding:7px 9px;border-bottom:1px solid var(--vach);text-align:left;vertical-align:top}
th{color:var(--mo);font-weight:600}
.the{background:var(--the);border:1px solid var(--vach);border-radius:10px;padding:14px 16px;margin-bottom:16px}
audio{width:100%;margin-top:10px}
</style></head><body>
<header>
  <h1>🎬 ${esc(tieuDe)}</h1>
  <span class="mo">phim nháp · ${moc.length} cảnh quay · ${round(tong, 1)}s${duToan ? ` · dự toán $${duToan.usd}` : ''}${qc ? ` · soát ${esc(qc.xep)} ${qc.diem}/100` : ''}</span>
</header>
<main>
  <div class="dieu">
    <button class="chinh" id="chay">▶︎ Chạy</button>
    <button id="lui">◀︎</button><button id="toi">▶︎</button>
    <span id="dongHo" class="mo">00:00:00:00</span>
    <span id="thanh"><i></i></span>
  </div>
  ${audioBase64 ? `<audio id="tieng" controls src="data:audio/wav;base64,${audioBase64}"></audio>` : '<p class="mo">Chưa có đường tiếng.</p>'}
  ${khung}
  <div class="the"><h2 style="font-size:15px;margin:0 0 8px">Bảng cảnh quay</h2>
    <table><thead><tr><th>Mã</th><th>Vào</th><th>Dài</th><th>Cỡ cảnh</th><th>Bối cảnh</th><th>Mô hình</th><th>Lời thoại</th></tr></thead>
    <tbody>${bangCanh}</tbody></table></div>
  <p class="mo">Âm thanh trong trang này do máy tổng hợp (nội dung AI, có đóng dấu).</p>
</main>
<script>
const KHUNG=${JSON.stringify(moc.map((c) => ({ tu: c.batDau, den: c.ketThuc })))};
const TONG=${round(tong, 2)};
const tieng=document.getElementById('tieng');
let t=0,chay=false,moc0=0,i=-1;
const tc=(x)=>{const p=(n)=>String(n).padStart(2,'0');return p(x/3600|0)+':'+p((x%3600)/60|0)+':'+p(x%60|0)+':'+p(Math.round((x-(x|0))*25)%25)};
function hien(n){if(n===i)return;i=n;document.querySelectorAll('.k').forEach((e,j)=>e.classList.toggle('on',j===n));}
function ve(){document.getElementById('dongHo').textContent=tc(t);
  document.querySelector('#thanh i').style.width=(TONG?t/TONG*100:0).toFixed(2)+'%';
  let n=KHUNG.findIndex(k=>t>=k.tu&&t<k.den); if(n<0)n=t>=TONG?KHUNG.length-1:0; hien(n);}
function nhip(){if(!chay)return; t=tieng?tieng.currentTime:(performance.now()-moc0)/1000;
  if(t>=TONG){t=TONG;dung();} ve(); if(chay)requestAnimationFrame(nhip);}
function batDau(){chay=true;moc0=performance.now()-t*1000;if(tieng){tieng.currentTime=t;tieng.play().catch(()=>{});}
  document.getElementById('chay').textContent='❚❚ Dừng';requestAnimationFrame(nhip);}
function dung(){chay=false;if(tieng)tieng.pause();document.getElementById('chay').textContent='▶︎ Chạy';}
document.getElementById('chay').onclick=()=>chay?dung():batDau();
document.getElementById('toi').onclick=()=>{const n=Math.min(KHUNG.length-1,i+1);t=KHUNG[n].tu;if(tieng)tieng.currentTime=t;ve();};
document.getElementById('lui').onclick=()=>{const n=Math.max(0,i-1);t=KHUNG[n].tu;if(tieng)tieng.currentTime=t;ve();};
ve();
</script></body></html>`;
}

/** Danh sách dựng (EDL) theo kiểu CMX3600 rút gọn — mở được bằng phần mềm dựng. */
function dungEDL(canhQuay, { tieuDe = 'PHIM', fps = 25 } = {}) {
  const moc = dungMocThoiGian(canhQuay);
  const dong = [`TITLE: ${tieuDe}`, 'FCM: NON-DROP FRAME', ''];
  moc.forEach((c, i) => {
    const n = String(i + 1).padStart(3, '0');
    dong.push(`${n}  AX       V     C        ${timecode(0, fps)} ${timecode(c.giay, fps)} ${c.tcVao} ${c.tcRa}`);
    dong.push(`* FROM CLIP NAME: ${c.id}.mp4`);
    if (c.thoai) dong.push(`* COMMENT: ${c.thoai.tenNhanVat}: ${c.thoai.loi}`);
    dong.push('');
  });
  return dong.join('\n');
}

/** Tệp concat và kịch bản ffmpeg — có clip là chạy được ngay một lệnh. */
function dungKichBanGhep(canhQuay, { tenPhim = 'phim', thuMucClip = './clip', chatLuong = 'hd' } = {}) {
  const concat = canhQuay.map((c) => `file '${thuMucClip}/${c.id}.mp4'`).join('\n');
  const doPhanGiai = chatLuong === '4k' ? '3840:2160' : '1920:1080';
  const mahoa = chatLuong === '4k' ? 'libx265' : 'libx264';
  const sh = `#!/usr/bin/env bash
# Ghép phim "${tenPhim}" — sinh tự động, chạy được khi đã có đủ clip trong ${thuMucClip}/
set -euo pipefail

command -v ffmpeg >/dev/null || { echo "Chưa cài ffmpeg: https://ffmpeg.org/"; exit 1; }

THIEU=0
while read -r _ f; do
  f="\${f%\\'}"; f="\${f#\\'}"
  [ -f "$f" ] || { echo "Thiếu clip: $f"; THIEU=1; }
done < danh-sach-clip.txt
[ "$THIEU" -eq 0 ] || { echo "Dừng: còn clip chưa dựng."; exit 1; }

# 1) Nối các clip
ffmpeg -f concat -safe 0 -i danh-sach-clip.txt -c copy -y noi-tam.mp4

# 2) Ghép đường tiếng và xuất bản cuối
ffmpeg -i noi-tam.mp4 -i duong-tieng.wav \\
  -vf "scale=${doPhanGiai}:force_original_aspect_ratio=decrease,pad=${doPhanGiai}:(ow-iw)/2:(oh-ih)/2,eq=contrast=1.06:saturation=1.08" \\
  -c:v ${mahoa} -preset medium -crf 18 \\
  -c:a aac -b:a 256k -shortest -movflags +faststart \\
  -y "${tenPhim}-${chatLuong}.mp4"

echo "Xong: ${tenPhim}-${chatLuong}.mp4"
`;
  return { concat, sh, tenTep: { concat: 'danh-sach-clip.txt', sh: 'ghep-phim.sh' } };
}

module.exports = {
  dungMocThoiGian, dungDuongTieng, dungPhimNhap, dungEDL, dungKichBanGhep, timecode,
};
