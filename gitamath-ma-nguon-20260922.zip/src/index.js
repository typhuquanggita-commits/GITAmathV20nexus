'use strict';
/**
 * GITAmath Nexus V20 — điểm khởi động.
 * boot() lắp toàn bộ hệ thống và trả về đối tượng N dùng chung cho HTTP server và test.
 */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const cfg = require('./config');
const L = require('./logger');
const bus = require('./kernel/eventbus');

const { createStore } = require('./kernel/store');
const Queue = require('./kernel/queue');
const EventStore = require('./kernel/event-store');
const { Database } = require('./data/repository');

const Constitution = require('./governance/constitution');
const Heart = require('./governance/heart');
const Guardrails = require('./governance/guardrails');
const SafeMetaPrompt = require('./governance/safe-meta-prompt');
const AuditChain = require('./governance/audit-chain');

const LLMRouter = require('./ai/llm-router');
const AdaptiveRouter = require('./ai/adaptive-router');
const CategoryCache = require('./ai/category-cache');
const EntropyMoE = require('./ai/entropy-moe');

const { buildRoster } = require('./agents/roster');
const KPITracker = require('./agents/kpi');
const CapacityGovernor = require('./agents/capacity');
const AgentRuntime = require('./agents/runtime');
const Scheduler = require('./agents/scheduler');

const SuperAdminVault = require('./security/superadmin-vault');
const AccountService = require('./security/accounts');
const KhuonMat = require('./an-toan/khuon-mat');
const ChongLuaDao = require('./an-toan/chong-lua-dao');
const Organization = require('./school/organization');
const Portability = require('./data/portability');
const RecoveryService = require('./security/recovery');
const SnapshotStore = require('./security/snapshot');
const ResilienceShield = require('./security/resilience');

const { validateHierarchy } = require('./curriculum/hierarchy');
const { validateStandards } = require('./curriculum/standards');
const ItemBank = require('./content/item-bank');
const { VoiceService } = require('./voice/service');
const { FilmService } = require('./film/service');
const { PhotoService } = require('./photo/service');
const { BaiGiangPipeline } = require('./nexus/bai-giang');
const { MathScientist } = require('./math/scientist');
const { LanguageScientist } = require('./lang/scientist');
const AuthoringPipeline = require('./content/authoring');
const ItemGenerator = require('./content/generator');
const BankSeeder = require('./content/seeder');
const MathVerifier = require('./math/verifier');
const { validateBlueprints } = require('./content/blueprint');
const Telemetry = require('./learner/telemetry');
const congQuyen = require('./api/cong-quyen');

/**
 * Gốc được phép gọi API chéo miền. Khai qua biến môi trường CORS_ORIGINS, cách
 * nhau bằng dấu phẩy. Mặc định RỖNG — không mở cho ai.
 *
 * Bản trước trả 'access-control-allow-origin: *' cho mọi phản hồi. Khi API còn
 * mở toang thì điều đó chỉ thừa; từ lúc API có xác thực, nó thành một lời mời:
 * bất kỳ trang nào cũng thử gọi hộ người đang đăng nhập.
 */
const GOC_CHO_PHEP = new Set(
  String(process.env.CORS_ORIGINS || '').split(',').map((x) => x.trim()).filter(Boolean),
);
const KhoKhaoSat = require('./khao-sat/kho');
const SoCai = require('./dong-tien/so-cai');
const DieuPhoiCRM = require('./crm/dieu-phoi');
const LichViecCRM = require('./crm/lich-viec');
const DieuPhoiHopNhat = require('./tiep-thi/dieu-phoi');
const XuongVideoHuongDan = require('./xuong-video/xuong');
const Mastery = require('./learner/mastery');
const ProfileStore = require('./learner/profile');
const Cycle90 = require('./learner/cycle90');
const PlacementService = require('./learner/placement');
const PracticeEngine = require('./learner/practice');
const ExamService = require('./learner/exam');
const BehaviorAnalyzer = require('./learner/behavior');
const RoadmapService = require('./learner/roadmap');
const ReportService = require('./report/reports');
const HandoffRegistry = require('./command/handoff');
const DebateEngine = require('./command/debate');
const MobilizationEngine = require('./command/mobilization');

const Orchestrator = require('./orchestrator');
const OTelGenAI = require('./observability/otel-genai');
const createRouter = require('./api/router');

async function boot({ quiet = false } = {}) {
  const t0 = Date.now();

  // ── Tầng 1: Governance ──
  const constitution = new Constitution();
  const heart = new Heart();
  const guardrails = new Guardrails();
  const safePrompt = new SafeMetaPrompt();

  // ── Tầng 2: State ──
  // Store = trạng thái vận hành ngắn hạn (cache, bandit, hàng đợi).
  // Database = dữ liệu nghiệp vụ phải sống sót tắt máy (người dùng, học viên, học liệu).
  const db = new Database({
    dir: process.env.DB_DIR || path.join(__dirname, '..', 'data', 'db'),
    sync: /^(1|true|yes)$/i.test(process.env.DB_FSYNC || ''),
  });
  const users = db.collection('users', { indexes: ['role', 'username', 'email'] });
  const learners = db.collection('learners', { indexes: ['classId', 'grade', 'level', 'userId'] });
  const classes = db.collection('classes', { indexes: ['teacherId', 'grade', 'schoolId'] });
  const schools = db.collection('schools', { indexes: [] });
  const items = db.collection('items', { indexes: ['formCode', 'stars', 'level', 'status'] });
  const attempts = db.collection('attempts', { indexes: ['learnerId', 'itemId', 'sessionId'] });
  const practices = db.collection('practices', { indexes: ['learnerId', 'state'] });
  const exams = db.collection('exams', { indexes: ['learnerId', 'level', 'kind'] });

  const store = createStore();
  const queue = new Queue();
  const eventStore = new EventStore({ store });
  const audit = new AuditChain({ eventStore, guardrails });

  // ── Tầng 3: Intelligence ──
  const otel = new OTelGenAI({ enabled: true });
  const llm = new LLMRouter();
  const adaptiveRouter = new AdaptiveRouter({ store, llmRouter: llm });
  const cache = new CategoryCache({ store });
  const moe = new EntropyMoE({ llmRouter: llm });

  // ── Lực lượng 500 trợ lý AI chuyên môn ──
  const { agents, squads, check } = buildRoster();
  if (agents.length !== cfg.AGENT_TOTAL) {
    throw new Error(`Số agent ${agents.length} ≠ chỉ tiêu ${cfg.AGENT_TOTAL}`);
  }
  const kpi = new KPITracker({ agents });
  const capacity = new CapacityGovernor({ agents });
  const runtime = new AgentRuntime({
    agents, kpi, capacity, llm, adaptiveRouter,
    constitution, heart, guardrails, safePrompt, cache, audit, otel,
  });
  const shield = new ResilienceShield({ agents, capacity, runtime, queue, scheduler: null });
  runtime.shield = shield;
  const scheduler = new Scheduler({ agents, runtime, kpi, capacity, queue, shield }).attachQueue();
  shield.scheduler = scheduler;

  // ── Bảo mật Super Admin · khôi phục · bảo lưu phiên bản ──
  const vault = new SuperAdminVault({ audit, constitution });
  const snapshots = new SnapshotStore({
    dir: process.env.SNAPSHOT_DIR || null,
    intervalMs: Number(process.env.SNAPSHOT_INTERVAL_MS || 15 * 60_000),
    collect: () => ({
      agents: agents.map((a) => ({ id: a.id, state: a.state, systemPrompt: a.systemPrompt, suspendedUntil: a.suspendedUntil })),
      kpi: Object.fromEntries([...kpi.byAgent.entries()].map(([id, m]) => [id, { tasks: m.tasks, ok: m.ok, failed: m.failed, costUsd: m.costUsd }])),
      bandit: {},
      health: [...shield.health.values()].map((h) => ({ agentId: h.agentId, state: h.state, consecutiveFailures: h.consecutiveFailures })),
      db: db.export(),
      meta: { version: cfg.VERSION, agents: agents.length, at: Date.now() },
    }),
    apply: (data) => {
      let restored = 0;
      for (const a of data.agents || []) {
        const cur = runtime.get(a.id);
        if (cur) { cur.state = a.state; cur.systemPrompt = a.systemPrompt; cur.suspendedUntil = a.suspendedUntil || 0; restored++; }
      }
      for (const h of data.health || []) {
        const cur = shield.health.get(h.agentId);
        if (cur) { cur.state = h.state; cur.consecutiveFailures = h.consecutiveFailures; }
      }
      const dbBack = data.db ? db.import(data.db) : { collections: 0, docs: 0 };
      return {
        agentsRestored: restored,
        healthRestored: (data.health || []).length,
        dataCollections: dbBack.collections,
        dataDocs: dbBack.docs,
      };
    },
  });
  // Bật chụp ảnh ĐỊNH KỲ.
  //
  // Trước lượt thanh tra này, SnapshotStore được dựng với autoStart mặc định
  // là false và không ai gọi .start(). Hệ quả: chính sách giữ ảnh (12 ảnh
  // trong giờ gần nhất, 24 trong ngày, 30 trong tháng) có đủ trong mã và
  // trong sổ tay vận hành, nhưng số ảnh tự chụp là KHÔNG. Chỉ có ảnh do
  // người bấm tay, và ảnh an toàn chụp ngay trước mỗi lần khôi phục.
  //
  // Nghĩa là: hỏng tệp dữ liệu vào một ngày không ai bấm nút thì không có gì
  // để khôi phục về. Một cơ chế an toàn CÓ TRONG TÀI LIỆU mà KHÔNG CHẠY còn
  // nguy hiểm hơn không có, vì người vận hành tin là mình đang được che.
  //
  // SNAPSHOT_AUTO=0 tắt hẳn — dành cho môi trường chạy thử, nơi ghi ảnh mỗi
  // mười lăm phút chỉ tổ rác đĩa.
  if (!/^(0|false|no)$/i.test(process.env.SNAPSHOT_AUTO || '')) snapshots.start();

  const recovery = new RecoveryService({ vault, snapshots, audit });

  // ── Tài khoản người dùng hằng ngày & tổ chức dạy học ──
  // ── Đăng nhập bằng khuôn mặt thật ──
  //
  // Định danh máy chủ (rpId) và danh sách gốc được phép PHẢI khớp với tên
  // miền thật lúc chạy, nếu không trình duyệt từ chối ngay ở phía nó. Mặc
  // định là localhost để chạy thử và để bản cài trên máy tính dùng được ngay;
  // chạy trên tên miền thật thì khai WEBAUTHN_RP_ID và WEBAUTHN_ORIGINS.
  //
  // Một điều kiện của chuẩn, ghi ra để không ai phải mò: ngoài localhost,
  // WebAuthn CHỈ chạy trên HTTPS. Đây là ràng buộc của trình duyệt, không
  // phải lựa chọn của hệ thống này.
  const rpId = process.env.WEBAUTHN_RP_ID || 'localhost';
  const cacGoc = (process.env.WEBAUTHN_ORIGINS
    || `http://localhost:${cfg.PORT},http://127.0.0.1:${cfg.PORT}`)
    .split(',').map((x) => x.trim()).filter(Boolean);
  const khuonMat = new KhuonMat({ tenMay: rpId, cacGoc, tenHienThi: 'GITAmath' });

  const chongLuaDao = new ChongLuaDao({ nhatKy: audit });
  const accounts = new AccountService({ users, learners, classes, audit, khuonMat, chongLuaDao });
  const org = new Organization({ schools, classes, learners, users, audit });
  const portability = new Portability({ learners, classes, items, users, org, audit });

  // ── Chương trình · học liệu · học viên ──
  const hierarchyCheck = validateHierarchy();
  const standardsCheck = validateStandards();
  if (!hierarchyCheck.ok) throw new Error(`Danh mục dạng không hợp lệ:\n - ${hierarchyCheck.errors.join('\n - ')}`);
  if (!standardsCheck.ok) throw new Error(`Chuẩn tầng không hợp lệ:\n - ${standardsCheck.errors.join('\n - ')}`);

  const blueprintCheck = validateBlueprints(require('./curriculum/hierarchy').FORM_INDEX);
  if (!blueprintCheck.ok) throw new Error(`Bản thiết kế bài không hợp lệ:\n - ${blueprintCheck.errors.join('\n - ')}`);

  const bank = new ItemBank();
  const authoring = new AuthoringPipeline({ bank, scheduler, runtime, constitution });
  const mathVerifier = new MathVerifier();
  const generator = new ItemGenerator({ bank, verifier: mathVerifier, audit });
  const seeder = new BankSeeder({ bank, generator, items, audit });

  // Kho học liệu: có sẵn trên đĩa thì nạp lại; chưa có thì gieo ngay để hệ
  // thống dùng được từ lần chạy đầu, không cần ai bấm nút.
  const restored = seeder.restore();
  let seedResult = null;
  if (restored.total === 0 && process.env.SEED_BANK !== '0') {
    seedResult = seeder.seed({ perBlueprintLevel: Number(process.env.SEED_PER_SLOT || 3), quiet: true });
  } else if (restored.total > 0 && process.env.SEED_BANK !== '0') {
    // Kho đã có thì KHÔNG gieo lại, nhưng vẫn phải bổ sung: bản thiết kế mới
    // biên soạn từ lần chạy trước, và bài đang chờ mà nay đã đạt cổng phát
    // hành. Thiếu bước này thì cài đặt đang chạy sẽ mãi phục vụ kho cũ.
    seedResult = seeder.boSung({ perSlot: Number(process.env.SEED_PER_SLOT || 3), quiet: true });
  }
  // Mặt trong của hệ thống: ngôi nhà thịnh vượng, nơi từng gia đình đi theo
  // trục thẳng. Tách hẳn khỏi trang công khai vì nó có trạng thái và danh tính.
  const matTrongNha = new MatTrongNha({
    kho: db.collection('nha-truc', { indexes: ['trucId'] }),
    nhatKy: audit,
  });

  const telemetry = new Telemetry();
  // Kết quả khảo sát phải SỐNG QUA lần khởi động lại, nếu không học viên làm
  // xong bài rồi hồ sơ vẫn rỗng và lộ trình cá nhân hoá vĩnh viễn không dựng
  // được. Bản dựng đầu không có chỗ này, và đó là lỗi chứ không phải tính năng
  // riêng tư — riêng tư nằm ở luật đọc trong src/khao-sat/kho.js.
  const khaoSat = new KhoKhaoSat({ repo: db.collection('khao-sat', { indexes: ['hocVienId', 'congCu'] }) });
  // Sổ cái dòng tiền. Ghi được chi phí vận hành đo được, và TỪ CHỐI ghi những
  // khoản chưa nối nguồn (doanh thu, nhân sự, hạ tầng) thay vì bịa số cho đủ bảng.
  const soCai = new SoCai({ repo: db.collection('dong-tien', { indexes: ['khoan', 'ngay', 'thang'] }) });
  const mastery = new Mastery();
  const profiles = new ProfileStore({ telemetry, mastery, repo: learners });
  const cycle90 = new Cycle90({ telemetry, mastery, profiles });
  const placement = new PlacementService({ bank, profiles, telemetry, mastery, exams, audit });
  const practice = new PracticeEngine({
    bank, mastery, telemetry, profiles, verifier: mathVerifier, practices, attempts, audit,
  });
  const behavior = new BehaviorAnalyzer({ telemetry, mastery, bank });
  const roadmap = new RoadmapService({ profiles, mastery, telemetry, behavior, bank, practices, audit });
  const reports = new ReportService({
    profiles, mastery, telemetry, behavior, bank, seeder,
    org, classes, learners, attempts, exams, accounts, roadmap,
  });
  const examService = new ExamService({
    bank, mastery, telemetry, profiles, attempts, exams, verifier: mathVerifier, audit,
  });

  // ── Giọng nói giảng viên: mỗi trợ lý AI một giọng, có lớp pháp lý đi kèm ──
  const voice = new VoiceService({ agents, db, bank, bus });

  // ── Sản xuất phim: kịch bản → phân cảnh → bản nháp xem được → dựng thật ──
  const film = new FilmService({ voice, db, llm, bus });

  // ── Xưởng ảnh: prompt → khung dựng → tám tầng hậu kỳ → soát và xuất ──
  const photo = new PhotoService({ db, bus });

  // ── Bài giảng: học liệu → khung hình → giọng đọc → tệp video, một lệnh ──
  const baiGiang = new BaiGiangPipeline({ bank, voice, photo, llm, db, bus });

  // ── Nhà khoa học toán: đọc vị đề · pháp đồ · đa cách giải · trình bày ──
  const scientist = new MathScientist({ llm, bank, roadmap, cycle90, bus });

  // ── Nhà khoa học ngôn ngữ: chính tả · văn phong · độ đọc · từ vựng ──
  const linguist = new LanguageScientist({ bank, voice, llm, telemetry, behavior, mastery, bus });

  // ── Chỉ huy: hợp đồng giao việc · chất vấn chéo · tổng động viên ──
  const handoff = new HandoffRegistry({ runtime, scheduler, audit });
  const debate = new DebateEngine({ runtime, scheduler, audit });
  const mobilization = new MobilizationEngine({
    agents, scheduler, runtime, kpi, capacity, shield, handoff, debate, audit, constitution,
  });

  // ── Tầng 4: Orchestration ──
  reports.kpi = kpi;
  reports.capacity = capacity;
  reports.agents = agents;

  const orchestrator = new Orchestrator({
    store, queue, cache, adaptiveRouter, guardrails, constitution, heart,
    safePrompt, moe, llm, scheduler, eventStore, otel,
  }).startWorker(20);

  const N = {
    cfg, bus, store, queue, eventStore, audit,
    db, users, learners, classes, schools, items, attempts, practices, exams,
    constitution, heart, guardrails, safePrompt,
    llm, adaptiveRouter, cache, moe, otel,
    agents, squads, kpi, capacity, runtime, scheduler, orchestrator,
    shield, vault, snapshots, recovery, accounts, org, portability, khuonMat, chongLuaDao,
    bank, authoring, telemetry, mastery, profiles, cycle90, placement, practice, examService, behavior, roadmap, reports,
    generator, seeder, mathVerifier, blueprintCheck, seedResult, bankRestored: restored,
    voice, film, photo, baiGiang, scientist, linguist,
    handoff, debate, mobilization,
    matTrongNha, khaoSat, soCai, crm: null, lichCrm: null,
    hopNhat: null, xuongVideo: null,
    hierarchyCheck, standardsCheck,
    bootMs: Date.now() - t0,
    taxonomyCheck: check,
    async shutdown() {
      queue.stop();
      guardrails.stop();
      capacity.stop();
      shield.stop();
      accounts.stop();
      snapshots.stop();
      if (N.lichCrm) N.lichCrm.tat();
      profiles.persistAll();
      db.close();
      await store.close();
    },
  };

  // Tự phát hiện agent dưới ngưỡng KPI → gợi ý coach (điều A18)
  bus.on('kpi:below_target', ({ agentId, kpiScore }) => {
    L.warn(`KPI dưới ngưỡng: ${agentId} (${kpiScore}) — cần coach`);
  });

  await eventStore.append('system', 'boot', { version: cfg.VERSION, agents: agents.length, ms: N.bootMs });

  if (!quiet) {
    const mode = llm.available().length === 1 && llm.available()[0] === 'mock' ? 'MOCK' : 'LIVE';
    L.banner([
      `GITAmath NEXUS V${cfg.VERSION}`,
      ``,
      `Trợ lý AI      : ${agents.length} chuyên gia · ${squads.length} tổ chuyên môn · 6 khối · 6 cấp bậc`,
      `Công suất      : ${agents.reduce((s, a) => s + a.capacity.maxConcurrent, 0)} slot · ` +
      `${agents.reduce((s, a) => s + a.capacity.tasksPerHour, 0).toLocaleString('vi-VN')} task/giờ danh định`,
      `Trần đồng thời : ${cfg.AGENT_GLOBAL_CONCURRENCY} · ${cfg.AGENT_TOKENS_PER_MIN.toLocaleString('vi-VN')} token/phút`,
      `Hiến pháp      : ${constitution.articles.length} điều · HEART ${Object.keys(heart.getAxioms()).length} axiom`,
      `Tài khoản      : ${accounts.status().users} người dùng · ${Object.keys(AccountService.ROLES).length} vai · ${org.status().classes} lớp · ${org.status().enrolled} học viên đã biên chế`,
      `Bảo mật        : Super Admin ${SuperAdminVault.LAYERS.length} tầng · chống nhiễu 7 cơ chế · ${snapshots.snapshots.length} ảnh chụp`,
      `Học liệu       : ${bank.items.size} bài · ${seeder.status().byStatus.PUBLISHED || 0} đã phát hành · `
      + `${blueprintCheck.blueprints} bản thiết kế · độ phủ ${Math.round(seeder.coverage().ratio * 100)}%`,
      `Chương trình   : ${hierarchyCheck.forms} dạng · ${hierarchyCheck.levels} tầng · ${standardsCheck.criteria} tiêu chí lên tầng`,
      `Giọng nói      : ${voice.profiles.stats().total} giọng (${voice.profiles.stats().agentVoices} giảng viên) · `
      + `bộ tổng hợp ${voice.providers.status().effective} · dấu AI ${cfg.VOICE.watermark ? 'BẬT' : 'TẮT'} · `
      + `pháp lý ${voice.compliance.checklist().ok ? 'đủ 7/7' : 'THIẾU'}`,
      `Làm phim       : ${film.status().moHinh.length} mô hình dựng video · `
      + `cổng thật ${film.status().cong.that.sanSang ? 'SẴN SÀNG' : 'chưa có khoá (vẫn dựng được bản nháp)'} · `
      + `trần chi tiêu $${cfg.FILM.tranChiTieuUsd}`,
      `Khoa học ngôn ngữ: soát 4 cấp chính tả · văn phong · độ đọc · từ vựng · `
      + `${linguist.status().tuVung.tongThuatNgu.toLocaleString('vi-VN')} thuật ngữ tra được cấp lớp · không cần khoá`,
      `Khoa học toán  : giải và trình bày chuẩn sách giáo khoa · ký hiệu Unicode quốc tế · `
      + `thẩm định 4 cấp có thay nghiệm ngược · ${scientist.status().phuongPhapHoc} phương pháp học · không cần khoá`,
      `Bài giảng      : ${baiGiang.status().nguonNoiDung.filter((n) => !n.canKhoa).length}/3 nguồn nội dung chạy không cần khoá · `
      + `${Object.keys(require('./nexus/bai-giang').KHO).join(' · ')} · xuất ${baiGiang.status().dinhDangXuat}`,
      `Xưởng ảnh      : ${photo.status().mayAnh.length} hồ sơ máy ảnh · ${photo.status().phim.length} giả lập phim · `
      + `đọc PNG/JPEG và hậu kỳ 8 tầng không cần ffmpeg · sinh ảnh qua ${photo.status().cong.duongDi.chon || 'chưa có cổng'}`,
      `Chỉ huy        : ${mobilization.playbooks().length} kịch bản tổng động viên · chất vấn chéo · hợp đồng giao việc`,
      `Store          : ${store.status().kind} · dữ liệu bền vững: ${db.status().collections} bộ sưu tập, ${db.status().totalDocs} bản ghi`,
      `CRM            : ${require('./crm/so-tro-ly').DS.length} trợ lý AI chuyên môn · `
      + `${require('./crm/dinh-tuyen').soiBang ? '' : ''}${Object.keys(require('./crm/dinh-tuyen').BANG_Y_DINH).length} loại việc đọc được · `
      + 'mức chạm ra ngoài luôn qua người duyệt',
      `LLM            : ${mode} (${llm.available().join(', ')})`,
      `Khởi động      : ${N.bootMs}ms`,
    ]);
    if (mode === 'MOCK') {
      L.warn('Chưa có API key — đang dùng provider mock tất định. Đặt GROQ_API_KEY hoặc GOOGLE_API_KEY trong .env để gọi mô hình thật.');
    }
  }

  // Mặt trong cần đọc phiên đăng nhập, mà bộ tài khoản chỉ có sau khi N dựng
  // xong. Trỏ ngược vào đây thay vì đảo thứ tự khởi tạo — đảo thứ tự thì lại
  // vướng chỗ khác, còn trỏ ngược một lần thì rõ ràng và chỉ có một chỗ.
  matTrongNha.N = N;

  // ── Ban quản trị quan hệ gia đình ──
  //
  // Dựng SAU khi N xong, vì ba mươi trợ lý CRM đọc dữ liệu thật của cả hệ:
  // kho học viên, kho khảo sát, sổ cái dòng tiền, lực lượng 500 trợ lý và hai
  // nhà khoa học. Dựng trước thì họ cầm một cái N rỗng và mọi công cụ đều trả
  // về "chưa có nguồn" — đúng cú pháp mà sai sự thật.
  N.crm = new DieuPhoiCRM({ N });
  N.lichCrm = new LichViecCRM({ crm: N.crm });
  if (!/^(0|false|no)$/i.test(process.env.CRM_LICH_VIEC || '')) N.lichCrm.bat();

  // ── Hợp nhất trò chuyện và nội dung ──
  //
  // Cũng dựng SAU N, và vì đúng lý do ấy: mười hai công cụ của trợ lý trò
  // chuyện đọc kho học viên, kho học liệu, chương trình và sơ đồ tư duy. Dựng
  // sớm thì mọi công cụ trả về "chưa có nguồn" — đúng cú pháp mà sai sự thật.
  //
  // Mô hình nhỏ để nhắc lại: chỉ nối khi hệ thật sự có mô hình chạy được.
  // Không có thì hàng rào ở lớp 2 khai thẳng là nó đang ở chế độ rút gọn, chứ
  // không im lặng tụt xuống rồi vẫn báo "năm lớp đang chạy".
  const coMoHinh = !!(N.llm && N.llm.available().filter((x) => x !== 'mock').length);
  N.hopNhat = new DieuPhoiHopNhat({
    N,
    nhacLai: coMoHinh
      ? (chu) => N.llm.call({
        task: 'classify',
        prompt: require('./tro-chuyen/hang-rao').loiDan(chu),
        temperature: 0,
      }).then((r) => String(r.text || r.content || ''))
      : null,
    khoaRieng: process.env.CHU_KY_SO_KHOA_RIENG || null,
  });
  N.hopNhat.soanTrang();

  // ── Xưởng video hướng dẫn ──
  N.xuongVideo = new XuongVideoHuongDan({ N });

  return N;
}

// ── HTTP server ──
const UI_DIR = path.join(__dirname, '..', 'ui');
const web = require('./web/site');
const MatTrongNha = require('./web/nha');

/**
 * Ánh xạ mã lỗi nghiệp vụ → mã HTTP.
 * Đăng nhập sai PHẢI trả 401, không được trả 200 kèm {ok:false}: tường lửa,
 * proxy và bộ đếm chặn brute-force đều nhìn vào mã HTTP chứ không đọc thân phản hồi.
 */
const ERROR_STATUS = {
  // 401 — chưa/không xác thực được
  INVALID_CREDENTIALS: 401, INVALID_TOTP: 401, INVALID_SESSION: 401, MFA_REQUIRED: 401,
  NOT_INITIALIZED: 401, INVALID_BREAK_GLASS_KEY: 401, INVALID_SIGNATURE: 401,
  SIGNATURE_REQUIRED: 401, VERIFICATION_FAILED: 401,
  // 403 — đã biết anh là ai, nhưng chưa đủ điều kiện
  STEP_UP_REQUIRED: 403, DUAL_CONTROL_PENDING: 403, DUAL_CONTROL_WAITING: 403,
  CONSTITUTION_BLOCK: 403, BREAK_GLASS_ALREADY_USED: 403, ALREADY_APPROVED_BY_YOU: 403,
  PERMISSION_DENIED: 403, FORBIDDEN: 403,
  // 404 — không có đối tượng
  NOT_FOUND: 404, AGENT_NOT_FOUND: 404, MISSION_NOT_FOUND: 404, DEBATE_NOT_FOUND: 404,
  SNAPSHOT_NOT_FOUND: 404, REQUEST_NOT_FOUND: 404, TRACE_NOT_FOUND: 404,
  CONTRACT_NOT_FOUND: 404, LEARNER_NOT_FOUND: 404, UI_FILE_NOT_FOUND: 404,
  CLASS_NOT_FOUND: 404, SCHOOL_NOT_FOUND: 404, TEACHER_NOT_FOUND: 404, GROUP_NOT_FOUND: 404,
  SESSION_NOT_FOUND: 404, EXAM_NOT_FOUND: 404, ITEM_NOT_FOUND: 404, RUN_NOT_FOUND: 404,
  NO_ROADMAP: 404, NO_CYCLE: 404, NO_OPEN_CYCLE: 404, NO_HISTORY: 404, UNKNOWN_FORM: 404,
  UNKNOWN_LEVEL: 404, NO_FORMS_AT_LEVEL: 404, NO_BLUEPRINT: 404, NO_ITEMS: 404,
  // 405 / 409 / 410
  WRONG_METHOD: 405, UNKNOWN_METHOD: 405,
  ALREADY_INITIALIZED: 409, DUPLICATE_SHARE: 409, WRONG_STATE: 409,
  CLASS_EXISTS: 409, SCHOOL_EXISTS: 409, GROUP_EXISTS: 409, USERNAME_TAKEN: 409,
  ALREADY_ENROLLED: 409, ALREADY_ANSWERED: 409, CLASS_FULL: 409, CYCLE_ALREADY_OPEN: 409,
  RUN_ALREADY_STARTED: 409, SESSION_FINISHED: 409, EXAM_FINISHED: 409,
  ACCOUNT_DISABLED: 403, NOT_ELIGIBLE: 403, RETAKE_TOO_SOON: 429, TIME_UP: 410,
  CHALLENGE_EXPIRED: 410, EXPIRED: 410,
  // 429 — bị chặn vì tần suất
  LOCKED_OUT: 429, TOO_MANY_ATTEMPTS: 429, RATE_LIMIT: 429, CAPACITY_LIMIT: 429,
  NOISE_REJECTED: 429, BACKPRESSURE: 429,
  // ── Giọng nói giảng viên ──
  VOICE_NOT_FOUND: 404, KHÔNG_TÌM_THẤY_BÀI: 404, KHÔNG_TÌM_THẤY: 404, KHÔNG_CÓ_GIỌNG: 404,
  KHÔNG_CÓ_KHO_BÀI: 404,
  // Chưa có/hết hạn/đã rút đồng ý là chuyện quyền, không phải chuyện cú pháp.
  CHƯA_CÓ_ĐỒNG_Ý: 403, ĐỒNG_Ý_HẾT_HẠN: 403, ĐÃ_RÚT_ĐỒNG_Ý: 403,
  // Khu điều hành: không đủ quyền là 403, KHÔNG phải 404. Trả 404 nghe có vẻ
  // kín hơn, nhưng nó nói dối về việc đường dẫn có tồn tại hay không, và một
  // người quản trị thật đang gõ đúng đường sẽ tưởng mình gõ sai.
  KHÔNG_ĐỦ_QUYỀN: 403,
  // Bộ khảo sát: hỏi một bộ đề hoặc một mốc không có thật là 404, không phải
  // 400 — người gọi gõ đúng cú pháp, chỉ là thứ họ hỏi không tồn tại.
  KHÔNG_CÓ_BỘ_KHẢO_SÁT_NÀY: 404, KHÔNG_CÓ_MỐC_NÀY: 404, KHÔNG_CÓ_CÔNG_CỤ_NÀY: 404,
  KHÔNG_CÓ_MIỀN_NÀY: 404,
  // Thiếu căn cứ để dựng lộ trình là 409: yêu cầu hợp lệ, nhưng trạng thái hệ
  // thống chưa cho phép làm việc ấy.
  CHƯA_ĐỦ_CĂN_CỨ: 409, CẦN_NGƯỜI_LỚN_TRƯỚC: 409, THIẾU_HỒ_SƠ_KHẢO_SÁT: 409,
  CHƯA_ĐĂNG_NHẬP: 401, CHƯA_BIẾT_LỚP: 409,
  NGƯỜI_HÁT_GỐC_CHƯA_ĐỒNG_Ý: 403, CHỦ_GIỌNG_ĐÍCH_CHƯA_ĐỒNG_Ý: 403,
  THIẾU_NGƯỜI_HÁT_GỐC: 400, THIẾU_CHỦ_GIỌNG_ĐÍCH: 400, THIẾU_BẢN_THU_GỐC: 400,
  THIẾU_LỜI: 400, THIẾU_GIAI_ĐIỆU: 400, KÝ_ÂM_SAI: 400, BÀI_QUÁ_DÀI: 413,
  BÀI_RỘNG_HƠN_QUÃNG_GIỌNG: 422, TỆP_MIDI_KHÔNG_CÓ_NỐT_NÀO: 422,
  KHÔNG_PHẢI_TỆP_MIDI: 415, CHƯA_HỖ_TRỢ_CHIA_NHỊP_SMPTE: 415,
  CHƯA_CÓ_BỘ_ĐỔI_GIỌNG: 501, BỘ_ĐỔI_GIỌNG_CHƯA_SẴN_SÀNG: 503,
  CHƯA_HỖ_TRỢ_NGÔN_NGỮ: 501, TẤT_CẢ_NHÀ_CUNG_CẤP_ĐỀU_HỎNG: 503,
  THIẾU_ĐỒNG_Ý_NGƯỜI_GIÁM_HỘ: 403, THIẾU_VĂN_BẢN: 400, CHƯA_XÁC_MINH_TUỔI: 400,
  LOẠI_ĐỒNG_Ý_KHÔNG_HỢP_LỆ: 400, THIẾU_CHỦ_THỂ: 400, THIẾU_NỘI_DUNG: 400, THIẾU_BÀI: 400,
  QUÁ_DÀI: 413, BUỔI_HỌC_KHÔNG_CÓ_BÀI: 400,
  ĐÃ_RÚT_TRƯỚC_ĐÓ: 409,
  KHÔNG_NHÀ_CUNG_CẤP_NÀO_CHẠY: 503,
  KHÔNG_CÓ_DẤU: 422, DẤU_BỊ_CẮT: 422, KHÔNG_ĐỌC_ĐƯỢC_WAV: 422,
  // ── Làm phim ──
  KỊCH_BẢN_RỖNG: 400, KHÔNG_TÌM_THẤY_CẢNH_NÀO: 422, KHÔNG_TÌM_THẤY_DỰ_ÁN: 404,
  PHIM_QUÁ_DÀI: 413, KHÔNG_CÓ_CẢNH_NÀO_ĐỂ_DỰNG: 400,
  CHƯA_QUA_SOÁT_CHẤT_LƯỢNG: 422, VƯỢT_TRẦN_CHI_TIÊU: 402,
  CHƯA_XÁC_NHẬN_CHI_TIÊU: 402, CHƯA_CÓ_CỔNG_DỰNG_VIDEO: 503,
  CHƯA_CÓ_DỰ_TOÁN: 400, CHƯA_GẮN_DỊCH_VỤ_GIỌNG: 500,
  // ── Xưởng ảnh ──
  THIẾU_MÔ_TẢ: 400, THIẾU_TỆP_ẢNH: 400, TỆP_QUÁ_LỚN: 413,
  CHƯA_HỖ_TRỢ_ĐỊNH_DẠNG: 415, KHÔNG_PHẢI_TỆP_PNG: 415, KHÔNG_PHẢI_TỆP_JPEG: 415,
  CHƯA_HỖ_TRỢ_JPEG_LŨY_TIẾN: 415, CHƯA_HỖ_TRỢ_PNG_XEN_KẼ: 415,
  DỮ_LIỆU_ẢNH_BỊ_CẮT: 422, PNG_THIẾU_IHDR: 422, PNG_KHÔNG_CÓ_DỮ_LIỆU_ẢNH: 422,
  KHÔNG_CỔNG_NÀO_TẠO_ĐƯỢC_ẢNH: 503,
  // ── Bài giảng ──
  KHÔNG_TÌM_THẤY_BÀI_GIẢNG: 404, KHÔNG_TÌM_THẤY_TỆP_VIDEO: 404, KHÔNG_CÓ_DẠNG_BÀI: 404,
  THIẾU_NGUỒN_NỘI_DUNG: 400, THIẾU_DÀN_Ý: 400, KỊCH_BẢN_RỖNG: 400,
  CHƯA_GẮN_KHO_HỌC_LIỆU: 500, CHƯA_GẮN_MÔ_HÌNH_NGÔN_NGỮ: 500,
  CHƯA_CÓ_KHOÁ_MÔ_HÌNH: 503, MÔ_HÌNH_KHÔNG_TRẢ_LỜI: 502, MÔ_HÌNH_TRẢ_VỀ_KHÔNG_ĐỌC_ĐƯỢC: 502,
  KHÔNG_CÓ_KHUNG_HÌNH: 400, KHÔNG_CÓ_ẢNH: 400, CÁC_KHUNG_KHÔNG_CÙNG_KÍCH_THƯỚC: 422,
  KÝ_HIỆU_TOÁN_KHÔNG_ĐẠT: 422,
  // ── Nhà khoa học toán ──
  THIẾU_ĐỀ_BÀI: 400, CHƯA_ĐỌC_VỊ_ĐỀ: 400, THIẾU_MÔ_TẢ_VẤN_ĐỀ: 400,
  KHÔNG_RÚT_ĐƯỢC_PHƯƠNG_TRÌNH: 422, KHÔNG_GIẢI_ĐƯỢC: 422,
  KHO_CHƯA_CÓ_BÀI_CHO_DẠNG_NÀY: 404, KHÔNG_CÓ_DẠNG_BÀI_KHỚP: 404,
  CẦN_MÃ_HỌC_VIÊN: 400, CHƯA_CÓ_KẾT_NỐI_CHO_CHỦ_ĐỀ_NÀY: 404,
  // ── Nhà khoa học ngôn ngữ ──
  KHÔNG_CÓ_NGƯỠNG_CHO_LỚP_NÀY: 400, KHÔNG_CÓ_CÂU_NÀO: 400,
  THIẾU_MÃ_HỌC_VIÊN: 400, CHƯA_GẮN_DỮ_LIỆU_HỌC: 500, CHƯA_CÓ_DỮ_LIỆU_HỌC: 404,
  KHÔNG_PHẢI_TỆP_AVI: 415, AVI_THIẾU_TIÊU_ĐỀ_AVIH: 422, TỆP_QUÁ_NGẮN: 422,
};
const statusForError = (code) => ERROR_STATUS[code] || 400;

function createServer(N) {
  const router = createRouter(N);

  return http.createServer(async (req, res) => {
    const started = Date.now();
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const send = (status, payload, contentType = 'application/json; charset=utf-8') => {
      // Buffer đi thẳng: tệp WAV giọng nói mà bị JSON.stringify là hỏng tệp.
      const body = Buffer.isBuffer(payload) ? payload
        : typeof payload === 'string' ? payload
        : JSON.stringify(payload, null, 2);
      // Gốc được phép gọi chéo, lấy từ cấu hình. Rỗng nghĩa là không mở cho ai.
      const gocXin = String(req.headers.origin || '');
      const goc = gocXin && GOC_CHO_PHEP.has(gocXin) ? gocXin : null;
      res.writeHead(status, {
        'content-type': contentType,
        ...(Buffer.isBuffer(body) ? { 'content-length': String(body.length) } : {}),
        'x-response-time': `${Date.now() - started}ms`,
        'x-nexus-version': cfg.VERSION,
        'x-content-type-options': 'nosniff',
        'referrer-policy': 'no-referrer',
        // CORS: chỉ mở cho các gốc đã khai trong cấu hình. Mở '*' trên một API
        // đã có xác thực là mời mọi trang web trên đời gọi hộ người dùng đang
        // đăng nhập. Không khai gốc nào thì không mở cho ai — API này dành cho
        // máy chủ và công cụ dòng lệnh, không dành cho trang web lạ.
        ...(goc ? {
          'access-control-allow-origin': goc,
          'access-control-allow-credentials': 'true',
          vary: 'origin',
          'access-control-allow-headers': 'content-type, authorization',
          'access-control-allow-methods': 'GET,POST,OPTIONS',
        } : {}),
      });
      res.end(body);
    };

    if (req.method === 'OPTIONS') return send(204, '');

    // ── Màn hình quản trị quan hệ gia đình ──
    //
    // Đặt TRƯỚC cả khu riêng của gia đình và trang công khai, vì trang này
    // hiển thị đúng những cách phân loại mà bức tường sinh ra để giữ lại. Để
    // rơi xuống dưới thì nó thành một trang công khai và ai cũng xem được.
    //
    // Canh cửa bằng CHÍNH bức tường Cây Tiền, không dựng một lớp canh thứ hai:
    // hai lớp canh cho cùng một thứ thì sớm muộn có một lớp lạc hậu, và không
    // ai biết lớp nào đang thật sự chặn.
    if (N.crm && url.pathname.startsWith('/quan-tri/crm') && req.method === 'GET') {
      const tuongCT = require('./cay-tien/buc-tuong');
      const cho = tuongCT.choVaoYeuCau(N, {
        headers: req.headers,
        query: Object.fromEntries(url.searchParams),
      });
      if (!cho.ok) {
        const chu = `${cho.error}: ${cho.reason}`;
        res.writeHead(cho.error === 'CHƯA_ĐĂNG_NHẬP' ? 401 : 403, {
          'content-type': 'text/plain; charset=utf-8',
          'cache-control': 'no-store, private',
          'x-robots-tag': 'noindex, nofollow',
          'content-length': Buffer.byteLength(chu),
        });
        return res.end(chu);
      }
      const nonceQT = require('node:crypto').randomBytes(16).toString('base64');
      const tr = require('./crm/trang').xemTrang(N.crm, N.lichCrm, url.pathname, nonceQT);
      if (tr && tr.html) {
        res.writeHead(200, {
          'x-nexus-version': cfg.VERSION,
          'x-content-type-options': 'nosniff',
          'x-frame-options': 'SAMEORIGIN',
          'referrer-policy': 'same-origin',
          'cache-control': 'no-store, private',
          'x-robots-tag': 'noindex, nofollow, noarchive',
          'content-security-policy': `default-src 'self'; style-src 'self' 'nonce-${nonceQT}'; `
            + `script-src 'none'; img-src 'self' data:; font-src 'self'; `
            + "connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'; object-src 'none'",
          'content-type': 'text/html; charset=utf-8',
          'content-length': Buffer.byteLength(tr.html),
        });
        return res.end(tr.html);
      }
    }

    // ── Mặt trong: ngôi nhà thịnh vượng ──
    // Đặt trước trang công khai vì /nha là khu riêng có danh tính; để rơi
    // xuống dưới thì nó thành trang công khai và ai cũng xem được nhà người
    // khác. Đây cũng là chỗ duy nhất trong máy chủ nhận biểu mẫu HTML.
    if (N.matTrongNha && url.pathname.startsWith('/nha')) {
      const nonceNha = require('node:crypto').randomBytes(16).toString('base64');
      const dauNha = {
        'x-nexus-version': cfg.VERSION,
        'x-content-type-options': 'nosniff',
        'x-frame-options': 'SAMEORIGIN',
        'referrer-policy': 'same-origin',
        // Khu riêng thì tuyệt đối không được lưu đệm ở proxy hay trình duyệt:
        // trang mang nội dung của đúng một gia đình tại đúng một bước.
        'cache-control': 'no-store, private',
        'content-security-policy': `default-src 'self'; style-src 'self' 'nonce-${nonceNha}'; `
          + `script-src 'none'; img-src 'self' data:; font-src 'self'; `
          + "connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'; object-src 'none'",
      };

      // ── CHỐNG GIẢ MẠO BIỂU MẪU (CSRF) ────────────────────────────────
      // Khu riêng xác thực bằng COOKIE, nên trình duyệt tự gửi cookie kèm mọi
      // biểu mẫu — kể cả biểu mẫu nằm trên một trang web lạ. Không chặn thì
      // một trang bất kỳ có thể nộp hộ bài sàng lọc tâm lý của một đứa trẻ
      // đang đăng nhập, hoặc đẩy lộ trình học của em đi tiếp.
      //
      // Chặn bằng HAI lớp độc lập, chi tiết ở src/web/chong-gia-mao.js.
      const chan403 = (chu) => {
        res.writeHead(403, { ...dauNha, 'content-type': 'text/plain; charset=utf-8', 'content-length': Buffer.byteLength(chu) });
        return res.end(chu);
      };

      if (req.method === 'POST') {
        // ── LỚP 1: dấu vết nguồn ────────────────────────────────────────
        // Dùng đúng thứ trình duyệt đã gửi sẵn: Sec-Fetch-Site nói yêu cầu
        // đến từ cùng gốc hay không, Origin nói gốc ấy là gốc nào. Trình
        // duyệt cũ không gửi Sec-Fetch-Site thì rơi về so Origin với Host.
        const site = String(req.headers['sec-fetch-site'] || '');
        const goc = String(req.headers.origin || '');
        let cungGoc;
        if (site) cungGoc = site === 'same-origin' || site === 'none';
        else if (goc) { try { cungGoc = new URL(goc).host === String(req.headers.host || ''); } catch { cungGoc = false; } }
        else cungGoc = false; // không có dấu hiệu nào thì KHÔNG cho, vì đây là cổng ghi
        if (!cungGoc) return chan403('Biểu mẫu này chỉ nhận từ chính trang của hệ thống.');

        // Đọc thân yêu cầu MỘT lần ở đây, vì lớp 2 cần đọc vé nằm trong thân.
        const chunks = [];
        let co = 0;
        for await (const c of req) {
          co += c.length;
          if (co > 200_000) return send(413, { ok: false, error: 'PAYLOAD_TOO_LARGE' });
          chunks.push(c);
        }
        const duLieu = Object.fromEntries(new URLSearchParams(Buffer.concat(chunks).toString('utf8')));

        // ── LỚP 2: vé trong biểu mẫu ────────────────────────────────────
        // Hai lớp hỏng theo hai cách khác nhau, nên mới có hai lớp: lớp 1 tin
        // vào việc trình duyệt gửi đúng tiêu đề; lớp 2 không tin gì ngoài
        // việc trang lạ không đọc được cookie của gốc này.
        //
        // Chưa đăng nhập thì KHÔNG đòi vé: không có phiên nghĩa là không có gì
        // để giả mạo hộ, và yêu cầu ấy dưới kia cũng chỉ được đẩy về trang
        // đăng nhập chứ không ghi gì.
        const CGM = require('./web/chong-gia-mao');
        const tokenPhien = require('./web/nha').docCookie(req.headers.cookie, 'gita_token')
          || String(req.headers.authorization || '').replace(/^Bearer\s+/i, '')
          || null;
        if (tokenPhien && !CGM.kiemVe(tokenPhien, duLieu[CGM.TEN_O])) {
          return chan403('Biểu mẫu đã cũ hoặc không phải của phiên này. Hãy mở lại trang và nộp lần nữa.');
        }

        const ra = N.matTrongNha.nhanNop(url.pathname, duLieu, { req, nonce: nonceNha });
        if (ra && ra.html) {
          // Nộp bài khảo sát trả THẲNG trang kết quả. Kết quả khảo sát không
          // có đường dẫn riêng để xem lại — tạo ra một đường dẫn như thế là
          // tạo ra một trang ai có link cũng mở được.
          res.writeHead(200, { ...dauNha, 'content-type': 'text/html; charset=utf-8', 'content-length': Buffer.byteLength(ra.html) });
          return res.end(ra.html);
        }
        if (ra) {
          // 303 để trình duyệt đổi sang GET: nạp lại trang sau khi nộp thì
          // chỉ xem lại, không nộp thêm lần nữa.
          res.writeHead(303, { ...dauNha, location: ra.chuyenToi });
          return res.end();
        }
      }

      if (req.method === 'GET') {
        const traNha = N.matTrongNha.xemTrang(
          url.pathname, Object.fromEntries(url.searchParams), { req, nonce: nonceNha },
        );
        if (traNha && traNha.html) {
          res.writeHead(200, {
            ...dauNha,
            'content-type': 'text/html; charset=utf-8',
            'content-length': Buffer.byteLength(traNha.html),
          });
          return res.end(traNha.html);
        }
      }
    }

    // ── Trang công khai: dựng sẵn ở máy chủ, đứng TRƯỚC mọi thứ khác ──
    // Đặt trước vì đây là thứ công cụ tìm kiếm và người lạ gặp đầu tiên; đặt
    // sau thì mọi đường dẫn lạ đều rơi vào JSON 404 của API, và cả trang web
    // không có lối vào nào đọc được.
    if (cfg.WEB.bat && req.method === 'GET') {
      // Đường dẫn "/" là chỗ duy nhất trang công khai và API dùng chung. Chia
      // theo thứ người gọi yêu cầu: trình duyệt xin text/html thì trả trang,
      // máy gọi API vẫn nhận đúng khối JSON như trước. Mọi đường dẫn công
      // khai khác không đụng vào nhóm endpoint nào nên trả trang luôn.
      const xinHtml = String(req.headers.accept || '').includes('text/html');
      const laGoc = url.pathname === '/' || url.pathname === '';
      // Nonce sinh mới cho MỖI lượt tải: nonce dùng lại thì kẻ tấn công đoán
      // được và chính sách bảo mật mất tác dụng.
      const nonce = require('node:crypto').randomBytes(16).toString('base64');
      const trang = (laGoc && !xinHtml)
        ? null
        : web.dinhTuyen(N, url.pathname, Object.fromEntries(url.searchParams), nonce);
      if (trang) {
        const than = trang.html || trang.raw;
        const kieu = trang.html ? 'text/html; charset=utf-8' : trang.kieu;
        res.writeHead(200, {
          'content-type': kieu,
          'content-length': Buffer.byteLength(than),
          'cache-control': 'public, max-age=600, stale-while-revalidate=86400',
          'x-nexus-version': cfg.VERSION,
          'x-content-type-options': 'nosniff',
          'x-frame-options': 'SAMEORIGIN',
          'referrer-policy': 'strict-origin-when-cross-origin',
          'permissions-policy': 'geolocation=(), microphone=(), camera=(), interest-cohort=()',
          // Trang công khai không tải gì từ tên miền khác, nên khoá chặt được.
          // Không còn 'unsafe-inline': mọi khối mã trong trang đều mang nonce
          // của đúng lượt tải này. Mở 'unsafe-inline' là vô hiệu hoá gần hết
          // tác dụng chặn mã lạ của chính sách.
          'content-security-policy': `default-src 'self'; style-src 'self' 'nonce-${nonce}'; `
            + `script-src 'self' 'nonce-${nonce}'; img-src 'self' data:; font-src 'self'; `
            + "connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'; object-src 'none'",
        });
        return res.end(than);
      }
    }

    // ── Giao diện web: phục vụ tệp tĩnh từ thư mục ui/ ──
    // Vào /ui thì đưa về cổng chọn vai, đừng bắt người dùng tự đoán đường dẫn.
    if (url.pathname === '/ui' || url.pathname === '/ui/') {
      res.writeHead(302, { location: '/ui/cong.html', 'x-nexus-version': cfg.VERSION });
      return res.end();
    }
    if (url.pathname.startsWith('/ui/')) {
      const rel = url.pathname.slice(4) || 'index.html';
      const file = path.join(UI_DIR, path.normalize(rel).replace(/^(\.\.[/\\])+/, ''));
      if (!file.startsWith(UI_DIR)) return send(403, { ok: false, error: 'FORBIDDEN' });
      if (fs.existsSync(file) && fs.statSync(file).isFile()) {
        const ext = path.extname(file).toLowerCase();
        const type = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' }[ext] || 'application/octet-stream';
        return send(200, fs.readFileSync(file, ext === '.png' || ext === '.ico' ? null : 'utf8'), type);
      }
      return send(404, { ok: false, error: 'UI_FILE_NOT_FOUND', path: url.pathname });
    }

    const m = router.match(req.method, url.pathname);
    if (!m) {
      // Trình duyệt vào nhầm đường dẫn thì phải thấy một trang đọc được, chứ
      // không phải một khối JSON. Máy gọi API vẫn nhận JSON như cũ.
      const muonHtml = cfg.WEB.bat && req.method === 'GET'
        && String(req.headers.accept || '').includes('text/html');
      if (muonHtml) {
        const than = web.trangKhongCo(url.pathname);
        res.writeHead(404, {
          'content-type': 'text/html; charset=utf-8',
          'content-length': Buffer.byteLength(than),
          'x-nexus-version': cfg.VERSION,
          'x-content-type-options': 'nosniff',
          'referrer-policy': 'strict-origin-when-cross-origin',
        });
        return res.end(than);
      }
      return send(404, {
        ok: false, error: 'NOT_FOUND', path: url.pathname,
        hint: 'GET / để xem danh sách nhóm endpoint',
      });
    }

    let body = {};
    if (req.method === 'POST') {
      try {
        const chunks = [];
        let size = 0;
        for await (const c of req) {
          size += c.length;
          if (size > 2_000_000) return send(413, { ok: false, error: 'PAYLOAD_TOO_LARGE' });
          chunks.push(c);
        }
        const raw = Buffer.concat(chunks).toString('utf8');
        body = raw ? JSON.parse(raw) : {};
      } catch {
        return send(400, { ok: false, error: 'INVALID_JSON' });
      }
    }

    // ── CỔNG QUYỀN — mọi cổng đều đi qua đây, không có ngoại lệ ──────────
    // Trước bản rà soát của quản trị hệ thống, chỗ này không có gì cả: 295
    // trong 300 cổng mở cho bất kỳ ai, kể cả POST /accounts với role ADMIN.
    // Luật quyền nay nằm ở src/api/cong-quyen.js, một chỗ duy nhất.
    const quyen = congQuyen.kiemQuyen(N, m.route, req.headers, body);
    if (!quyen.ok) {
      return send(quyen.status, { ok: false, error: quyen.error, reason: quyen.reason });
    }
    if (quyen.khoiTao) {
      // Tài khoản quản trị ĐẦU TIÊN của một hệ thống mới. Ghi thật to, vì đây
      // là lần duy nhất một cổng quản trị mở cho người chưa đăng nhập.
      L.warn(`CỬA KHỞI TẠO: tạo tài khoản quản trị đầu tiên từ ${req.socket.remoteAddress || 'không rõ'}`);
      try {
        await N.audit.record({
          actor: 'KHOI_TAO', actorRole: 'SYSTEM', action: 'accounts.bootstrap_admin',
          verdict: 'ALLOW', severity: 3, detail: { ip: req.socket.remoteAddress || 'unknown' },
        });
      } catch { /* nhật ký kiểm toán hỏng không được chặn việc khởi tạo */ }
    }

    const ctx = {
      params: m.params,
      query: Object.fromEntries(url.searchParams),
      ip: req.socket.remoteAddress || 'unknown',
      headers: req.headers,
      // Tay xử lý nào cần biết ai đang gọi thì đọc ở đây, không tự dò cookie
      // lại một lần nữa mỗi nơi một kiểu.
      phien: quyen.phien,
      mucQuyen: quyen.muc,
    };

    try {
      const out = await m.route.handler(ctx, body);
      if (out && out.raw !== undefined) return send(200, out.raw, out.contentType);
      if (out && out.status && out.body !== undefined) return send(out.status, out.body);
      // Kết quả nghiệp vụ thất bại phải đi kèm mã HTTP đúng nghĩa.
      if (out && out.ok === false) return send(statusForError(out.error), out);
      return send(200, out);
    } catch (e) {
      L.error(`API ${req.method} ${url.pathname}`, e.message);
      return send(500, { ok: false, error: 'INTERNAL_ERROR', message: e.message });
    }
  });
}

async function main() {
  process.on('unhandledRejection', (e) => L.error('unhandledRejection', e?.message || String(e)));
  process.on('uncaughtException', (e) => { L.error('uncaughtException', e?.message); process.exit(1); });

  const N = await boot();
  const server = createServer(N);

  server.listen(cfg.PORT, cfg.HOST, () => {
    L.ok(`HTTP đang lắng nghe http://${cfg.HOST}:${cfg.PORT}`);
    L.ok(`Giao diện chỉ huy: http://localhost:${cfg.PORT}/ui/index.html`);
    L.info(`Thử API: curl -s localhost:${cfg.PORT}/agents/assignment | head -40`);
  });

  const shutdown = async (sig) => {
    L.warn(`Nhận ${sig} — đang dừng an toàn…`);
    server.close();
    await N.queue.drainAll(5000);
    await N.shutdown();
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

if (require.main === module) main();

module.exports = { boot, createServer };
