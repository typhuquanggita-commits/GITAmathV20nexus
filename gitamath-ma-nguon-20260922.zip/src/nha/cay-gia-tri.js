'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CÂY GIÁ TRỊ — NĂM TẦNG, MẶT KHÁCH HÀNG
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Đây là cây DUY NHẤT gia đình được nhìn thấy. Nó trả lời đúng một câu hỏi
 *  mà phụ huynh nào cũng hỏi và ít hệ thống nào dám trả lời bằng chữ cụ thể:
 *
 *      "Đi hết chương trình này thì con tôi ĐƯỢC GÌ?"
 *
 *  Năm tầng dưới đây không phải năm gói bán. Chúng là năm THỨ HỌC VIÊN LÀM
 *  ĐƯỢC, xếp theo thứ tự phải có cái trước mới có cái sau, và mỗi tầng kèm
 *  một dấu hiệu QUAN SÁT ĐƯỢC để gia đình tự kiểm chứng ở nhà — không cần
 *  tin lời hệ thống.
 *
 *  BA ĐIỀU TỆP NÀY KHÔNG ĐƯỢC LÀM
 *    1. Không hứa điểm số. "Con sẽ đạt 1200 HSA" là câu không ai giữ được, và
 *       một lời hứa như thế biến mọi tầng phía dưới thành đường tắt để lách.
 *       Tầng ở đây hứa NĂNG LỰC, và năng lực thì kiểm chứng được.
 *    2. Không nhắc tiền, không nhắc gói, không nhắc xếp hạng gia đình. Việc
 *       xếp nhóm nằm ở src/cay-tien/ và có bức tường riêng canh.
 *    3. Không nói tầng nào "dễ". Học viên đọc thấy một tầng bị gọi là dễ mà
 *       mình chưa qua được thì thôi không đi tiếp.
 * ═══════════════════════════════════════════════════════════════════════════
 */

/**
 * Năm tầng.
 *   thu        thứ tự, 1..5
 *   ten        tên tầng — động từ, vì tầng là việc làm được, không phải danh hiệu
 *   cauHoi     câu hỏi tầng này trả lời cho gia đình
 *   duoc       thứ học viên làm được khi qua tầng
 *   dauHieu    dấu hiệu gia đình tự quan sát được ở nhà
 *   heThongLam việc hệ thống làm để đưa học viên qua tầng
 *   veTinh     năng lực (vệ tinh trên bản đồ) tầng này bồi
 */
const TANG = [
  {
    thu: 1,
    ten: 'Nhìn thật',
    cauHoi: 'Con tôi đang thực sự đứng ở đâu?',
    duoc: 'Biết mình chắc chỗ nào, hổng chỗ nào, bằng bài làm chứ không bằng cảm giác.',
    dauHieu: 'Con nói được tên phần mình yếu, thay vì nói chung chung là "con kém toán".',
    heThongLam: 'Đo đầu vào bằng bài thật, dựng bản đồ lộ trình riêng, chỉ đúng chỗ hổng.',
    veTinh: ['nhin-that'],
  },
  {
    thu: 2,
    ten: 'Chắc gốc',
    cauHoi: 'Vá xong những lỗ hổng cũ chưa?',
    duoc: 'Làm đúng ổn định phần nền của các lớp dưới, không còn sai đi sai lại một chỗ.',
    dauHieu: 'Bài cũ làm lại sau hai tuần vẫn đúng, không cần xem lại lời giải.',
    heThongLam: 'Đưa lại đúng bài đã sai kèm bẫy đã mắc, lặp giãn cách cho tới khi vững.',
    veTinh: ['nen-tang-toan', 'tu-vung', 'ngu-phap'],
  },
  {
    thu: 3,
    ten: 'Đi đều',
    cauHoi: 'Học có thành nếp chưa, hay vẫn phải nhắc?',
    duoc: 'Ngồi vào bàn đúng giờ mà không cần ai giục, và giữ được nhịp qua tuần bận.',
    dauHieu: 'Phụ huynh thôi phải nhắc; con tự mở bài.',
    heThongLam: 'Chia mục tiêu thành việc nhỏ vừa sức mỗi ngày, đóng buổi bằng một câu tiến bộ cụ thể.',
    veTinh: ['nhip-luyen'],
  },
  {
    thu: 4,
    ten: 'Làm được đề thật',
    cauHoi: 'Vào phòng thi thì sao?',
    duoc: 'Làm đúng số câu trong đúng số phút của đề thật, giữ được bình tĩnh khi gặp câu lạ.',
    dauHieu: 'Con làm hết đề trong giờ quy định, không bỏ trắng phần cuối.',
    heThongLam: 'Luyện theo ma trận đề thật của từng hệ chuẩn, bấm giờ đúng như đề, soi lại chỗ mất giờ.',
    veTinh: ['toc-do-lam-bai', 'xu-ly-so-lieu', 'doc-hieu'],
  },
  {
    thu: 5,
    ten: 'Tự đi',
    cauHoi: 'Rời hệ thống rồi con có tự học được không?',
    duoc: 'Gặp bài chưa từng gặp thì tự chọn hướng, tự soát lại, tự biết mình sai ở đâu.',
    dauHieu: 'Con giải được bài ngoài chương trình và giải thích được vì sao làm thế.',
    heThongLam: 'Giảm dần gợi ý, bắt viết căn cứ từng bước, giao bài mở không có mẫu sẵn.',
    veTinh: ['tu-duy-logic', 'viet-hoc-thuat', 'phat-am'],
  },
];

const TANG_INDEX = new Map(TANG.map((t) => [t.thu, t]));

/**
 * Thứ gia đình nhận được khi đi hết cả năm tầng.
 *
 * Viết bằng chữ của phụ huynh, và cố ý KHÔNG có con số điểm nào. Thứ giữ được
 * sau kỳ thi là năng lực, không phải điểm của một buổi sáng.
 */
const QUA = [
  'Một đứa trẻ biết tự ngồi vào bàn, và biết bắt đầu từ đâu khi gặp bài khó.',
  'Một bản đồ năng lực có thật, kiểm chứng được bằng bài làm, không phải bằng lời khen.',
  'Một nếp học giữ được sau khi rời hệ thống — đây là thứ khó tạo nhất và bền nhất.',
  'Một cách nói về việc học trong nhà: nói bằng chỗ mạnh chỗ yếu cụ thể, thay vì bằng điểm số và trách móc.',
];

/** Bảng năm tầng cho mặt khách hàng. Không tham số, không phụ thuộc dữ liệu ai. */
function cayGiaTri() {
  return {
    soTang: TANG.length,
    tang: TANG.map((t) => ({ ...t, veTinh: t.veTinh.slice() })),
    qua: QUA.slice(),
    loiMo: 'Năm tầng dưới đây là năm thứ con làm được, xếp theo thứ tự phải có cái trước '
      + 'mới có cái sau. Mỗi tầng kèm một dấu hiệu gia đình tự quan sát được ở nhà.',
  };
}

/**
 * Học viên đang ở tầng nào của CÂY GIÁ TRỊ.
 *
 * Quy tắc cố ý bảo thủ: chỉ công nhận một tầng khi có DẤU VẾT của tầng đó, và
 * khi thiếu dấu vết thì trả về `null` kèm chữ "chưa đủ căn cứ" chứ không đoán
 * lên cho đẹp. Một gia đình được khen đã qua tầng 3 trong khi con vẫn phải
 * giục mỗi tối sẽ mất niềm tin vào mọi thứ còn lại của hệ thống.
 *
 * @param {object} o {tienDoTruc, metrics, mastery} — đều là số ĐÃ ĐO, không ước lượng
 */
function tangHienTai({ tienDoTruc = null, metrics = null, mastery = null } = {}) {
  const thieu = [];
  if (!metrics || !metrics.items) thieu.push('chưa có bài làm nào được ghi nhận');
  if (!tienDoTruc) thieu.push('chưa bắt đầu lộ trình nào');
  if (thieu.length) {
    return { tang: null, duCanCu: false, ghiChu: `Chưa đủ căn cứ để nói con đang ở tầng nào: ${thieu.join('; ')}.` };
  }

  const m = metrics;
  const mas = mastery || {};
  // Tầng 1 tính từ lúc có lộ trình và có bài đo đầu vào — đó chính là "nhìn thật".
  let thu = 1;
  // Tầng 2: phần nền đã thạo quá nửa số dạng đã chạm.
  if ((mas.formsTouched || 0) >= 5 && (mas.formsMastered || 0) / Math.max(mas.formsTouched || 1, 1) >= 0.5) thu = 2;
  // Tầng 3: nhịp đều — từ 8 buổi trở lên và tỉ lệ bỏ bài thấp.
  if (thu >= 2 && (m.sessions || 0) >= 8 && (m.skipRate || 0) <= 0.1) thu = 3;
  // Tầng 4: làm được đề thật — đủ nhanh và đủ đúng.
  if (thu >= 3 && (m.accuracy || 0) >= 0.75 && (m.medianSpeedRatio != null && m.medianSpeedRatio <= 1.1)) thu = 4;
  // Tầng 5: tự đi — gần như không xin gợi ý, không xem trước lời giải.
  if (thu >= 4 && (m.hintRate || 0) <= 0.15 && (m.peekRate || 0) <= 0.1 && (m.avgThinkingSteps || 0) >= 3) thu = 5;

  const t = TANG_INDEX.get(thu);
  return {
    tang: thu,
    ten: t.ten,
    duCanCu: true,
    duoc: t.duoc,
    dauHieu: t.dauHieu,
    tiepTheo: TANG_INDEX.get(thu + 1) ? {
      thu: thu + 1,
      ten: TANG_INDEX.get(thu + 1).ten,
      cauHoi: TANG_INDEX.get(thu + 1).cauHoi,
      heThongLam: TANG_INDEX.get(thu + 1).heThongLam,
    } : null,
    ghiChu: thu === 5
      ? 'Đã đi hết năm tầng. Việc còn lại là giữ nếp.'
      : `Đang ở tầng ${thu}/5. Tầng kế tiếp cần dấu hiệu chứ không cần thêm thời gian.`,
  };
}

module.exports = { TANG, TANG_INDEX, QUA, cayGiaTri, tangHienTai };
