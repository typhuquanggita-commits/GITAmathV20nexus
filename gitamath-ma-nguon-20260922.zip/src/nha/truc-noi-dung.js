'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MƯỜI TRỤC HỌC — TOÁN VÀ TIẾNG ANH
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mỗi phòng trên bản đồ là một trục thẳng, và mỗi trục bám vào CẤU TRÚC ĐỀ
 *  THẬT của hệ chuẩn tương ứng: đúng số câu, đúng số phút, đúng thang điểm.
 *  Số liệu lấy từ `src/matran/chuan.js`, không chép tay lại — chép tay thì
 *  hai nơi sẽ lệch nhau sau lần sửa đầu tiên.
 *
 *  MỖI BƯỚC PHẢI ĐỂ LẠI MỘT CON SỐ HOẶC MỘT VẬT.
 *  Học mà không đo thì tháng sau không biết đã khá lên chưa. Nên phần lớn đầu
 *  ra ở đây là SỐ: số câu đúng, số phút, số dạng đạt. Có số thì bước so sánh ở
 *  cuối mỗi trục mới có nghĩa, và trợ lý AI mới nói được điều cụ thể.
 *
 *  MỖI TRỤC MỘT HÌNH DẠNG RIÊNG.
 *  Trục HSA đi theo một phần thi; trục SPT đi theo trọng số; trục SAT đi theo
 *  cơ chế thích ứng; trục Olympiad đi theo phép đổi dạng bài. Đóng chung một
 *  khuôn rồi thay chữ thì người học qua phòng thứ hai là nhận ra ngay.
 *
 *  BƯỚC KHÔNG ĐƯỢC HÉ BƯỚC SAU — có phép soi chạy trên mọi trục ở mọi vị trí.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { CHUAN_INDEX } = require('../matran/chuan');

/** Lấy số liệu thật của một phần thi, để đề bài trong trục không chép tay. */
function phan(chuanId, phanId) {
  const c = CHUAN_INDEX.get(chuanId);
  const p = c && c.phan.find((x) => x.id === phanId);
  return p || { cau: 0, phut: 0, ten: '' };
}
const thang = (chuanId) => (CHUAN_INDEX.get(chuanId) || { thang: [0, 0] }).thang;

const TRUC = [

  // ══ MÁI — CHỌN ĐÍCH ════════════════════════════════════════════════════
  {
    id: 'chon-dich',
    ten: 'Chốt một đích và một mốc thời gian',
    motCau: 'Một đích tại một thời điểm, có điểm mục tiêu và có ngày.',
    chang: [
      {
        id: 'ghi-dich',
        ten: 'Ghi đích và ngày',
        nhiemVu: 'Viết đích đang nhắm tới và ngày phải đạt. Đích phải là một kỳ thi có thật hoặc một mốc lớp học có thật, không viết chung chung.',
        viSao: 'Không có ngày thì mọi việc đều lùi được sang tuần sau, và lộ trình không tính ra được số buổi mỗi tuần.',
        dauRa: { kieu: 'chu', nhan: 'Đích và ngày phải đạt' },
        xongKhi: 'Có tên đích và một ngày cụ thể.',
        phut: 5,
      },
      {
        id: 'chan-doan-dau-vao',
        ten: 'Làm bài chẩn đoán đầu vào',
        nhiemVu: 'Làm bài chẩn đoán mà hệ thống dựng riêng cho đích này. Làm hết sức, không tra cứu, không dừng giữa chừng. Ghi lại tầng mà máy chấm ra.',
        viSao: 'Tầng đầu vào là mốc gốc; thiếu nó thì mọi tiến bộ về sau chỉ là cảm giác chứ không so được với gì.',
        dauRa: { kieu: 'so', nhan: 'Tầng đầu vào máy chấm được' },
        xongKhi: 'Có một con số tầng từ 0 đến 9.',
        phut: 45,
      },
      {
        id: 'khoang-cach',
        ten: 'Đo khoảng cách tới đích',
        nhiemVu: 'Hệ thống quy đổi tầng đầu vào ra khoảng điểm của đích. So khoảng đó với điểm mục tiêu và ghi lại còn cách mấy bậc.',
        viSao: 'Biết còn mấy bậc thì mới chia được thời gian; không biết thì hoặc học cầm chừng, hoặc dồn ép tới kiệt sức.',
        dauRa: { kieu: 'so', nhan: 'Số bậc còn thiếu' },
        xongKhi: 'Có một con số từ 0 trở lên.',
        phut: 10,
      },
      {
        id: 'chia-thoi-gian',
        ten: 'Chia thời gian cho từng bậc',
        nhiemVu: 'Đếm số tuần còn lại tới ngày đã ghi, chia cho số bậc còn thiếu. Ghi số tuần dành cho mỗi bậc.',
        viSao: 'Phép chia này cho biết kế hoạch có khả thi không. Ra dưới hai tuần một bậc thì hoặc phải lùi ngày, hoặc phải hạ mục tiêu — biết sớm còn kịp chọn.',
        dauRa: { kieu: 'so', nhan: 'Số tuần cho mỗi bậc' },
        xongKhi: 'Có một con số tuần.',
        phut: 10,
      },
      {
        id: 'so-buoi-moi-tuan',
        ten: 'Chốt số buổi mỗi tuần',
        nhiemVu: 'Chọn số buổi học mỗi tuần mà chắc chắn giữ được kể cả tuần bận nhất. Ghi số buổi và các thứ trong tuần.',
        viSao: 'Kế hoạch chọn theo tuần lý tưởng thì vỡ ngay tuần thứ hai. Chọn theo tuần bận nhất thì giữ được cả chặng.',
        dauRa: { kieu: 'chu', nhan: 'Số buổi mỗi tuần và các thứ cố định' },
        xongKhi: 'Có số buổi và các thứ cụ thể trong tuần.',
        phut: 10,
      },
      {
        id: 'nguoi-kiem',
        ten: 'Chốt người kiểm và mốc kiểm đầu tiên',
        nhiemVu: 'Ghi tên một người sẽ hỏi tiến độ, và ngày hỏi lần đầu trong vòng hai tuần tới.',
        viSao: 'Việc không có người hỏi là việc tự nguyện, và việc tự nguyện thường bị bỏ trước tiên khi bận.',
        dauRa: { kieu: 'chu', nhan: 'Tên người kiểm và ngày kiểm' },
        xongKhi: 'Có một tên người và một ngày.',
        phut: 5,
      },
    ],
  },

  // ══ TOÁN PHỔ THÔNG ═════════════════════════════════════════════════════
  {
    id: 'toan-pho-thong',
    ten: 'Chắc gốc toán theo đúng lớp',
    motCau: 'Vá chỗ hổng trước, đi tiếp sau.',
    chang: [
      {
        id: 'chon-lop',
        ten: 'Chọn lớp đang học',
        nhiemVu: 'Ghi lớp đang học. Nếu đang hổng nhiều thì ghi lớp thấp hơn một bậc — học lại phần gốc nhanh hơn học tiếp phần ngọn.',
        viSao: 'Chương trình toán xếp theo tiên quyết: dạng lớp trên dựa lên dạng lớp dưới, nên chọn sai lớp là học mãi không vào.',
        dauRa: { kieu: 'so', nhan: 'Lớp sẽ học' },
        xongKhi: 'Có một số từ 1 đến 12.',
        phut: 5,
      },
      {
        id: 'chan-doan-lop',
        ten: 'Làm bài chẩn đoán của lớp đó',
        nhiemVu: 'Làm bài chẩn đoán phủ đủ các dạng của lớp đã chọn. Ghi số dạng đạt trên tổng số dạng.',
        viSao: 'Chẩn đoán phủ đủ dạng thì chỗ hổng lộ ra theo từng dạng, chứ không chỉ ra một điểm số nói chung.',
        dauRa: { kieu: 'so', nhan: 'Số dạng đạt' },
        xongKhi: 'Có một con số dạng đạt.',
        phut: 40,
      },
      {
        id: 'xep-dang-hong',
        ten: 'Xếp các dạng chưa đạt theo thứ tự tiên quyết',
        nhiemVu: 'Liệt kê các dạng chưa đạt, xếp dạng nào là tiên quyết của dạng nào lên trước. Hệ thống có sẵn quan hệ tiên quyết để đối chiếu.',
        viSao: 'Vá dạng ngọn trước khi vá dạng gốc thì vá xong lại hổng, vì dạng ngọn dựa lên dạng gốc.',
        dauRa: { kieu: 'danh-sach', nhan: 'Các dạng chưa đạt, xếp theo thứ tự', toiThieu: 1 },
        xongKhi: 'Có danh sách đã xếp thứ tự.',
        phut: 15,
      },
      {
        id: 'va-dang-dau',
        ten: 'Vá dạng đứng đầu danh sách',
        nhiemVu: 'Luyện đúng dạng đứng đầu cho tới khi đạt ngưỡng của tầng. Không nhảy sang dạng khác giữa chừng. Ghi số buổi đã luyện.',
        viSao: 'Luyện dàn trải nhiều dạng cùng lúc thì dạng nào cũng dở dang; dồn vào một dạng thì có chỗ đạt được và có đà đi tiếp.',
        dauRa: { kieu: 'so', nhan: 'Số buổi đã luyện dạng đó' },
        xongKhi: 'Dạng đó đạt ngưỡng và có con số buổi.',
        phut: 120,
      },
      {
        id: 'chan-doan-lai',
        ten: 'Làm lại bài chẩn đoán',
        nhiemVu: 'Làm lại bài chẩn đoán của chính lớp đó. Ghi số dạng đạt lần này.',
        viSao: 'Đo lại bằng đúng thước cũ thì hiệu hai con số là tiến bộ thật, không phụ thuộc cảm giác của hôm đo.',
        dauRa: { kieu: 'so', nhan: 'Số dạng đạt lần hai' },
        xongKhi: 'Có con số lần hai.',
        phut: 40,
      },
      {
        id: 'quyet-dinh-di-tiep',
        ten: 'Quyết định lên lớp tiếp hay vá tiếp',
        nhiemVu: 'So hai con số. Nếu còn dạng chưa đạt thì quay lại vá; nếu đã đủ thì ghi lớp tiếp theo sẽ học. Ghi quyết định kèm hai con số làm căn cứ.',
        viSao: 'Quyết định bằng số thì không ai phải tranh luận, và học viên thấy rõ vì sao mình được đi tiếp hay phải ở lại.',
        dauRa: { kieu: 'chu', nhan: 'Quyết định và hai con số căn cứ' },
        xongKhi: 'Có quyết định rõ ràng kèm cả hai con số.',
        phut: 10,
      },
    ],
  },

  // ══ TIẾNG ANH NỀN ══════════════════════════════════════════════════════
  {
    id: 'tieng-anh-nen',
    ten: 'Xây bốn kỹ năng theo bậc của lớp',
    motCau: 'Đúng bậc CEFR của lớp, không nhảy cóc sang luyện thi.',
    chang: [
      {
        id: 'bac-cefr',
        ten: 'Xác định bậc CEFR theo lớp',
        nhiemVu: 'Ghi lớp đang học. Hệ thống trả về bậc CEFR ứng với lớp đó, kèm mục tiêu vốn từ và số giờ của bậc.',
        viSao: 'Bậc CEFR quyết định độ khó của mọi bài sau đó. Học trên bậc thì nản, học dưới bậc thì phí thời gian.',
        dauRa: { kieu: 'so', nhan: 'Lớp đang học' },
        xongKhi: 'Có một số từ 1 đến 12.',
        phut: 5,
      },
      {
        id: 'do-von-tu',
        ten: 'Đo vốn từ hiện có',
        nhiemVu: 'Làm bài đo vốn từ. Ghi số từ ước lượng mà bài đo trả về.',
        viSao: 'Vốn từ là thứ chặn cả bốn kỹ năng: thiếu từ thì nghe không ra, đọc không kịp, nói và viết đều bí.',
        dauRa: { kieu: 'so', nhan: 'Số từ ước lượng' },
        xongKhi: 'Có một con số từ vựng.',
        phut: 20,
      },
      {
        id: 'do-phat-am',
        ten: 'Đo phát âm bằng cặp tối thiểu',
        nhiemVu: 'Nghe và phân biệt năm cặp âm dễ lẫn mà hệ thống chọn theo lỗi thường gặp của người Việt. Ghi số cặp phân biệt đúng.',
        viSao: 'Không phân biệt được âm khi nghe thì cũng không phát ra được khi nói; đây là gốc của cả nghe lẫn nói.',
        dauRa: { kieu: 'so', nhan: 'Số cặp phân biệt đúng trên năm' },
        xongKhi: 'Có một con số từ 0 đến 5.',
        phut: 15,
      },
      {
        id: 'chon-ky-nang-yeu',
        ten: 'Chọn kỹ năng yếu nhất trong bốn',
        nhiemVu: 'Nhìn hai con số vừa đo và kết quả bốn kỹ năng, chọn đúng một kỹ năng yếu nhất để tập trung. Ghi tên kỹ năng và lý do bằng số.',
        viSao: 'Luyện đều cả bốn kỹ năng thì không kỹ năng nào lên rõ; dồn vào kỹ năng yếu nhất thì mức chung lên nhanh nhất.',
        dauRa: { kieu: 'chu', nhan: 'Kỹ năng yếu nhất và lý do bằng số' },
        xongKhi: 'Có một kỹ năng và một con số làm căn cứ.',
        phut: 10,
      },
      {
        id: 'luyen-bay-ngay',
        ten: 'Luyện kỹ năng đó bảy ngày',
        nhiemVu: 'Bảy ngày liền, mỗi ngày luyện đúng kỹ năng đã chọn. Ghi số phút thật của từng ngày, ghi cả ngày bằng không.',
        viSao: 'Ngày bằng không là dữ liệu quan trọng nhất: nó chỉ ra điều kiện nào làm việc học đứt, và đó mới là chỗ cần sửa.',
        dauRa: { kieu: 'danh-sach', nhan: 'Số phút của bảy ngày', toiThieu: 7, toiDa: 7 },
        xongKhi: 'Có đủ bảy con số.',
        phut: 15,
      },
      {
        id: 'do-lai-ky-nang',
        ten: 'Đo lại kỹ năng vừa luyện',
        nhiemVu: 'Làm lại đúng bài đo của kỹ năng đó. Ghi con số mới và hiệu so với lần đầu.',
        viSao: 'Đo lại bằng đúng bài cũ thì hiệu hai con số loại được yếu tố may rủi của đề.',
        dauRa: { kieu: 'so', nhan: 'Hiệu số so với lần đo đầu' },
        xongKhi: 'Có một hiệu số, kể cả khi bằng không hoặc âm.',
        phut: 20,
      },
    ],
  },

  // ══ HSA ════════════════════════════════════════════════════════════════
  {
    id: 'hsa',
    ten: 'Luyện phần toán của kỳ thi Đánh giá năng lực',
    motCau: `Đúng ${phan('hsa', 'p1-toan').cau} câu trong ${phan('hsa', 'p1-toan').phut} phút, như đề thật.`,
    chang: [
      {
        id: 'diem-muc-tieu',
        ten: 'Ghi điểm mục tiêu trên thang một nghìn ba trăm',
        nhiemVu: `Ghi số điểm nhắm tới trong thang ${thang('hsa')[0]} đến ${thang('hsa')[1]}. Hệ thống đổi số đó ra tầng tương ứng.`,
        viSao: 'Điểm mục tiêu phải nằm trong thang thật của kỳ thi, nếu không thì mọi phép quy đổi về sau đều lệch.',
        dauRa: { kieu: 'so', nhan: 'Điểm mục tiêu' },
        xongKhi: `Có một con số trong khoảng ${thang('hsa')[0]} đến ${thang('hsa')[1]}.`,
        phut: 5,
      },
      {
        id: 'lam-phan-toan',
        ten: 'Làm phần toán đúng số câu và đúng giờ',
        nhiemVu: `Làm ${phan('hsa', 'p1-toan').cau} câu trong ${phan('hsa', 'p1-toan').phut} phút, bấm giờ thật, không dừng giữa chừng. Ghi số câu đúng.`,
        viSao: 'Làm không bấm giờ thì kết quả không nói được gì về phòng thi, vì phần lớn điểm mất ở đó là do hết giờ chứ không do không biết.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng' },
        xongKhi: `Có một con số từ 0 đến ${phan('hsa', 'p1-toan').cau}.`,
        phut: 75,
      },
      {
        id: 'tach-loai-sai',
        ten: 'Tách câu sai thành hai loại',
        nhiemVu: 'Với mỗi câu sai, ghi nó thuộc loại nào: chưa biết cách làm, hay biết nhưng không kịp giờ. Ghi số câu của từng loại.',
        viSao: 'Hai loại sai cần hai cách chữa khác hẳn nhau. Gộp chung lại rồi luyện nhiều hơn thì loại thứ hai không đỡ được chút nào.',
        dauRa: { kieu: 'danh-sach', nhan: 'Số câu chưa biết cách và số câu không kịp giờ', toiThieu: 2, toiDa: 2 },
        xongKhi: 'Có đúng hai con số, cộng lại bằng tổng số câu sai.',
        phut: 20,
      },
      {
        id: 'luyen-dung-nhom',
        ten: 'Luyện đúng nhóm sai nhiều hơn',
        nhiemVu: 'Nhóm nào nhiều câu hơn thì luyện nhóm đó. Chưa biết cách thì học lại dạng; không kịp giờ thì luyện bấm giờ từng câu. Ghi số buổi đã luyện.',
        viSao: 'Chữa đúng loại bệnh mới hết bệnh. Luyện thêm đề khi đang mắc lỗi tốc độ chỉ làm mệt thêm mà điểm không đổi.',
        dauRa: { kieu: 'so', nhan: 'Số buổi đã luyện' },
        xongKhi: 'Có một con số buổi từ 1 trở lên.',
        phut: 180,
      },
      {
        id: 'lam-lai-phan-toan',
        ten: 'Làm lại phần toán, vẫn đúng giờ ấy',
        nhiemVu: `Làm lại ${phan('hsa', 'p1-toan').cau} câu trong ${phan('hsa', 'p1-toan').phut} phút với đề mới. Ghi số câu đúng lần này.`,
        viSao: 'Đề mới cùng cấu trúc loại được việc nhớ đáp án, nên hiệu hai lần là tiến bộ thật.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng lần hai' },
        xongKhi: 'Có con số lần hai.',
        phut: 75,
      },
      {
        id: 'quy-ra-khoang-diem',
        ten: 'Quy kết quả ra khoảng điểm',
        nhiemVu: 'Hệ thống quy số câu đúng ra tầng, rồi quy tầng ra khoảng điểm. So khoảng đó với điểm mục tiêu và ghi còn cách mấy bậc.',
        viSao: 'Hệ thống chỉ nói khoảng, không nói một con số điểm — một con số đơn lẻ là thứ chưa ai đo được và không nên hứa.',
        dauRa: { kieu: 'so', nhan: 'Số bậc còn cách mục tiêu' },
        xongKhi: 'Có một con số từ 0 trở lên.',
        phut: 10,
      },
    ],
  },

  // ══ TSA ════════════════════════════════════════════════════════════════
  {
    id: 'tsa',
    ten: 'Luyện tư duy theo nhịp đề Bách khoa',
    motCau: `Tám mươi câu trong ${CHUAN_INDEX.get('tsa').tongPhut} phút — nhịp mới là thứ phải luyện.`,
    chang: [
      {
        id: 'muc-tieu-tram',
        ten: 'Ghi điểm mục tiêu trên thang một trăm',
        nhiemVu: `Ghi số điểm nhắm tới trong thang ${thang('tsa')[0]} đến ${thang('tsa')[1]}, và ngày thi dự kiến.`,
        viSao: 'Thang một trăm chia mười nấc, nên mục tiêu quy ngay ra được tầng và ra số bậc phải đi.',
        dauRa: { kieu: 'chu', nhan: 'Điểm mục tiêu và ngày thi' },
        xongKhi: 'Có một con số điểm và một ngày.',
        phut: 5,
      },
      {
        id: 'lam-phan-mot',
        ten: 'Làm phần toán và tư duy logic',
        nhiemVu: `Làm ${phan('tsa', 'p1-toan-logic').cau} câu trong ${phan('tsa', 'p1-toan-logic').phut} phút. Ghi số câu đúng.`,
        viSao: 'Phần này chiếm một phần tư số câu và là phần phân loại mạnh nhất của đề.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng phần một' },
        xongKhi: `Có số câu đúng phần toán và tư duy logic, từ 0 đến ${phan('tsa', 'p1-toan-logic').cau}.`,
        phut: 40,
      },
      {
        id: 'do-nhip',
        ten: 'Đo nhịp làm bài',
        nhiemVu: `Chia ${phan('tsa', 'p1-toan-logic').phut} phút cho ${phan('tsa', 'p1-toan-logic').cau} câu để ra số phút chuẩn mỗi câu. Ghi số phút thật mà mình đã dùng cho câu chậm nhất.`,
        viSao: 'Một câu chậm gấp ba lần nhịp chuẩn ăn mất thời gian của hai câu khác. Biết câu nào chậm thì biết câu nào nên bỏ qua trong phòng thi.',
        dauRa: { kieu: 'so', nhan: 'Số phút của câu chậm nhất' },
        xongKhi: 'Có một con số phút.',
        phut: 10,
      },
      {
        id: 'lam-doc-hieu',
        ten: 'Làm phần đọc hiểu',
        nhiemVu: `Làm ${phan('tsa', 'p2-doc-hieu').cau} câu trong ${phan('tsa', 'p2-doc-hieu').phut} phút. Ghi số câu đúng.`,
        viSao: 'Đọc hiểu có nhịp gấp hơn phần toán, nên nó là chỗ nhiều người mất điểm dù đọc được.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng phần đọc hiểu' },
        xongKhi: `Có số câu đúng phần đọc hiểu, từ 0 đến ${phan('tsa', 'p2-doc-hieu').cau}.`,
        phut: 30,
      },
      {
        id: 'phan-nao-keo-xuong',
        ten: 'Xác định phần nào kéo điểm xuống',
        nhiemVu: 'Tính tỉ lệ đúng của từng phần đã làm. Ghi tên phần có tỉ lệ thấp hơn cùng con số tỉ lệ.',
        viSao: 'So bằng tỉ lệ chứ không so bằng số câu: hai phần khác số câu thì số câu đúng không so thẳng với nhau được.',
        dauRa: { kieu: 'chu', nhan: 'Phần yếu hơn và tỉ lệ đúng của nó' },
        xongKhi: 'Có tên một phần và một tỉ lệ phần trăm.',
        phut: 10,
      },
      {
        id: 'luyen-roi-do-lai',
        ten: 'Luyện phần đó rồi đo lại đúng phần ấy',
        nhiemVu: 'Luyện đúng phần vừa xác định, rồi làm lại đúng phần ấy với đề mới và đúng số phút cũ. Ghi tỉ lệ đúng mới.',
        viSao: 'Đo lại đúng phần đã luyện thì biết cách luyện có tác dụng hay không, thay vì chỉ thấy tổng điểm nhúc nhích.',
        dauRa: { kieu: 'so', nhan: 'Tỉ lệ đúng mới, tính bằng phần trăm' },
        xongKhi: 'Có một con số phần trăm.',
        phut: 90,
      },
    ],
  },

  // ══ SPT ════════════════════════════════════════════════════════════════
  {
    id: 'spt',
    ten: 'Luyện theo trọng số của đề chuyên biệt',
    motCau: 'Trọng số quyết định nên dồn sức vào đâu, không phải cảm giác.',
    chang: [
      {
        id: 'muc-tieu-spt',
        ten: 'Ghi điểm mục tiêu trên thang một nghìn hai trăm',
        nhiemVu: `Ghi số điểm nhắm tới trong thang ${thang('spt')[0]} đến ${thang('spt')[1]}.`,
        viSao: 'Thang của kỳ thi này khác hẳn hai kỳ thi kia, nên phải ghi đúng thang thì quy đổi mới có nghĩa.',
        dauRa: { kieu: 'so', nhan: 'Điểm mục tiêu' },
        xongKhi: `Có một con số trong khoảng ${thang('spt')[0]} đến ${thang('spt')[1]}.`,
        phut: 5,
      },
      {
        id: 'doc-trong-so',
        ten: 'Đọc trọng số bốn phần',
        nhiemVu: 'Hệ thống hiện trọng số thật của bốn phần. Ghi lại phần nào có trọng số cao nhất và cao bao nhiêu.',
        viSao: 'Một phần trọng số ba mươi phần trăm đáng đầu tư gấp rưỡi phần hai mươi phần trăm, dù cả hai đều khó như nhau.',
        dauRa: { kieu: 'chu', nhan: 'Phần trọng số cao nhất và con số trọng số' },
        xongKhi: 'Có tên một phần và một con số trọng số.',
        phut: 10,
      },
      {
        id: 'lam-toan-tu-duy',
        ten: 'Làm phần toán và tư duy logic',
        nhiemVu: `Làm ${phan('spt', 'math_logic').cau} câu trong ${phan('spt', 'math_logic').phut} phút. Ghi số câu đúng.`,
        viSao: 'Đây là phần trọng số cao nhất của đề, nên nó được làm trước khi còn tỉnh táo nhất.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng phần toán' },
        xongKhi: `Có một con số từ 0 đến ${phan('spt', 'math_logic').cau}.`,
        phut: 75,
      },
      {
        id: 'lam-tieng-anh-spt',
        ten: 'Làm phần tiếng Anh',
        nhiemVu: `Làm ${phan('spt', 'english').cau} câu trong ${phan('spt', 'english').phut} phút. Ghi số câu đúng.`,
        viSao: 'Phần tiếng Anh có số câu nhiều hơn mà thời gian ít hơn phần toán, nên nhịp ở đây gấp hơn hẳn.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng phần tiếng Anh' },
        xongKhi: `Có một con số từ 0 đến ${phan('spt', 'english').cau}.`,
        phut: 60,
      },
      {
        id: 'nhan-trong-so',
        ten: 'Nhân tỉ lệ đúng với trọng số rồi cộng lại',
        nhiemVu: 'Với mỗi phần đã làm, lấy tỉ lệ đúng nhân với trọng số của phần đó, rồi cộng các tích lại. Ghi con số cuối.',
        viSao: 'Cộng thẳng số câu đúng của các phần là sai, vì mỗi phần đóng góp vào điểm cuối theo một trọng số khác nhau.',
        dauRa: { kieu: 'so', nhan: 'Tổng sau khi nhân trọng số' },
        xongKhi: 'Có một con số.',
        phut: 15,
      },
      {
        id: 'chon-phan-de-nang',
        ten: 'Chọn một phần để nâng, lý do bằng trọng số',
        nhiemVu: 'Với mỗi phần, tính xem nâng tỉ lệ đúng thêm mười phần trăm thì điểm cuối tăng bao nhiêu. Chọn phần cho mức tăng lớn nhất. Ghi tên phần và con số tăng.',
        viSao: 'Phần yếu nhất chưa chắc là phần đáng nâng nhất — trọng số mới quyết định chỗ nào bỏ công ra được nhiều nhất.',
        dauRa: { kieu: 'chu', nhan: 'Phần sẽ nâng và mức tăng điểm tính được' },
        xongKhi: 'Có tên một phần và một con số.',
        phut: 20,
      },
    ],
  },

  // ══ SAT ════════════════════════════════════════════════════════════════
  {
    id: 'sat',
    ten: 'Luyện theo cơ chế thích ứng hai mô-đun',
    motCau: 'Mô-đun đầu quyết định trần điểm của mô-đun sau.',
    chang: [
      {
        id: 'muc-tieu-sat',
        ten: 'Ghi điểm mục tiêu trên thang một nghìn sáu trăm',
        nhiemVu: `Ghi số điểm nhắm tới trong thang ${thang('sat')[0]} đến ${thang('sat')[1]}, và ngày thi dự kiến.`,
        viSao: 'Thang bắt đầu từ bốn trăm chứ không từ không, nên đặt mục tiêu dưới bốn trăm là đặt sai thang.',
        dauRa: { kieu: 'chu', nhan: 'Điểm mục tiêu và ngày thi' },
        xongKhi: `Có một con số trong khoảng ${thang('sat')[0]} đến ${thang('sat')[1]} và một ngày.`,
        phut: 5,
      },
      {
        id: 'lam-math',
        ten: 'Làm phần Math',
        nhiemVu: `Làm ${phan('sat', 'math').cau} câu trong ${phan('sat', 'math').phut} phút. Ghi số câu đúng.`,
        viSao: 'Phần Math chiếm một nửa thang điểm, và là phần người học tiếng Việt thường ghi điểm tốt hơn.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng phần Math' },
        xongKhi: `Có một con số từ 0 đến ${phan('sat', 'math').cau}.`,
        phut: 70,
      },
      {
        id: 'hieu-thich-ung',
        ten: 'Hiểu cơ chế thích ứng',
        nhiemVu: 'Đọc giải thích về cách chấm thích ứng, rồi viết lại bằng lời của mình: vì sao làm tốt mô-đun đầu lại quan trọng hơn làm tốt mô-đun sau.',
        viSao: 'Không hiểu cơ chế thì học viên dồn sức sai chỗ: cố gỡ ở mô-đun sau trong khi trần điểm đã bị khoá từ mô-đun đầu.',
        dauRa: { kieu: 'chu', nhan: 'Giải thích bằng lời của mình' },
        xongKhi: 'Có một đoạn giải thích nhắc tới cả hai mô-đun.',
        phut: 15,
      },
      {
        id: 'lam-rw',
        ten: 'Làm phần Reading and Writing',
        nhiemVu: `Làm ${phan('sat', 'rw').cau} câu trong ${phan('sat', 'rw').phut} phút. Ghi số câu đúng.`,
        viSao: 'Phần này nhịp gấp hơn Math, và đây là chỗ người học tiếng Việt thường mất điểm nhiều nhất.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng phần Reading and Writing' },
        xongKhi: `Có một con số từ 0 đến ${phan('sat', 'rw').cau}.`,
        phut: 64,
      },
      {
        id: 'tach-ba-loai-loi',
        ten: 'Tách lỗi thành ba loại',
        nhiemVu: 'Với mỗi câu sai, xếp vào một trong ba loại: đọc sai yêu cầu đề, không kịp giờ, chưa biết kiến thức. Ghi số câu của từng loại.',
        viSao: 'Ba loại lỗi này cần ba cách chữa khác hẳn nhau; gộp lại rồi làm thêm đề thì chỉ loại thứ ba đỡ được.',
        dauRa: { kieu: 'danh-sach', nhan: 'Số câu của ba loại lỗi', toiThieu: 3, toiDa: 3 },
        xongKhi: 'Có đúng ba con số, cộng lại bằng tổng số câu sai.',
        phut: 25,
      },
      {
        id: 'chua-loai-nhieu-nhat',
        ten: 'Chữa loại lỗi nhiều nhất rồi đo lại',
        nhiemVu: 'Luyện đúng cách chữa cho loại lỗi nhiều nhất, rồi làm lại phần đó với đề mới. Ghi số câu đúng mới.',
        viSao: 'Chữa đúng loại lỗi chiếm đa số thì điểm nhảy rõ; chữa loại thiểu số thì công sức gần như không hiện ra trên điểm.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng sau khi chữa' },
        xongKhi: 'Có một con số.',
        phut: 120,
      },
    ],
  },

  // ══ IELTS ══════════════════════════════════════════════════════════════
  {
    id: 'ielts',
    ten: 'Đo đủ bốn kỹ năng rồi mới chọn chỗ nâng',
    motCau: 'Band cuối là trung bình bốn kỹ năng, nên kỹ năng thấp nhất kéo cả band.',
    chang: [
      {
        id: 'band-muc-tieu',
        ten: 'Ghi band mục tiêu',
        nhiemVu: `Ghi band nhắm tới trong thang ${thang('ielts')[0]} đến ${thang('ielts')[1]}, và ngày thi dự kiến.`,
        viSao: 'Band mục tiêu quyết định mức từ vựng và độ phức tạp cấu trúc phải luyện, nên phải chốt trước khi học.',
        dauRa: { kieu: 'chu', nhan: 'Band mục tiêu và ngày thi' },
        xongKhi: `Có một con số trong khoảng ${thang('ielts')[0]} đến ${thang('ielts')[1]} và một ngày.`,
        phut: 5,
      },
      {
        id: 'lam-listening',
        ten: 'Làm Listening',
        nhiemVu: `Làm ${phan('ielts', 'listening').cau} câu trong ${phan('ielts', 'listening').phut} phút, nghe đúng một lần như thi thật. Ghi số câu đúng.`,
        viSao: 'Nghe lại lần hai làm kết quả đẹp lên nhưng không nói được gì về phòng thi, nơi chỉ có đúng một lần nghe.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng Listening' },
        xongKhi: `Có số câu đúng phần Listening, từ 0 đến ${phan('ielts', 'listening').cau}.`,
        phut: 35,
      },
      {
        id: 'lam-reading',
        ten: 'Làm Reading',
        nhiemVu: `Làm ${phan('ielts', 'reading').cau} câu trong ${phan('ielts', 'reading').phut} phút. Ghi số câu đúng.`,
        viSao: 'Reading không có thời gian chép đáp án riêng, nên phải luyện ghi thẳng trong lúc làm.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng Reading' },
        xongKhi: `Có số câu đúng phần Reading, từ 0 đến ${phan('ielts', 'reading').cau}.`,
        phut: 60,
      },
      {
        id: 'viet-task-hai',
        ten: 'Viết bài luận và tự chấm theo bốn tiêu chí',
        nhiemVu: 'Viết một bài luận trong bốn mươi phút, rồi tự chấm theo đúng bốn tiêu chí chính thức mà hệ thống hiện ra. Ghi bốn điểm thành phần.',
        viSao: 'Tự chấm theo đúng bốn tiêu chí dạy người học nhìn bài mình bằng mắt giám khảo, thay vì chỉ cảm thấy bài hay hoặc dở.',
        dauRa: { kieu: 'danh-sach', nhan: 'Bốn điểm thành phần theo bốn tiêu chí', toiThieu: 4, toiDa: 4 },
        xongKhi: 'Có đúng bốn điểm thành phần của bài viết.',
        phut: 55,
      },
      {
        id: 'noi-va-tu-cham',
        ten: 'Nói theo chủ đề và tự chấm',
        nhiemVu: 'Chuẩn bị một phút, nói hai phút về chủ đề hệ thống đưa, có ghi âm. Nghe lại và tự chấm theo bốn tiêu chí của phần nói. Ghi bốn điểm thành phần.',
        viSao: 'Nghe lại chính giọng mình là cách nhanh nhất nhận ra lỗi phát âm và chỗ ngập ngừng, nhanh hơn mọi lời nhận xét.',
        dauRa: { kieu: 'danh-sach', nhan: 'Bốn điểm thành phần phần nói', toiThieu: 4, toiDa: 4 },
        xongKhi: 'Có đúng bốn điểm thành phần của phần nói.',
        phut: 20,
      },
      {
        id: 'trung-binh-bon-ky-nang',
        ten: 'Lấy trung bình bốn kỹ năng',
        nhiemVu: 'Quy bốn kết quả về band, lấy trung bình, so với band mục tiêu. Ghi band hiện tại và kỹ năng thấp nhất.',
        viSao: 'Band cuối là trung bình bốn kỹ năng, nên một kỹ năng tụt lại kéo cả band xuống dù ba kỹ năng kia đã tốt.',
        dauRa: { kieu: 'chu', nhan: 'Band hiện tại và kỹ năng thấp nhất' },
        xongKhi: 'Có một con số band và tên một kỹ năng.',
        phut: 15,
      },
    ],
  },

  // ══ OLYMPIAD ═══════════════════════════════════════════════════════════
  {
    id: 'olympiad',
    ten: 'Tập đổi dạng bài toán khó',
    motCau: 'Bài năm sao không dài hơn, mà phải đổi sang dạng khác mới giải được.',
    chang: [
      {
        id: 'chon-bai-kho',
        ten: 'Chọn một bài chưa giải được',
        nhiemVu: 'Chọn một bài năm sao trong kho mà mình chưa giải được. Ghi mã bài.',
        viSao: 'Bài đã giải được không rèn được gì; chỗ học nằm đúng ở bài đang bế tắc.',
        dauRa: { kieu: 'chu', nhan: 'Mã bài đã chọn' },
        xongKhi: 'Có một mã bài.',
        phut: 5,
      },
      {
        id: 'liet-ke-dieu-kien',
        ten: 'Liệt kê mọi điều kiện đề cho',
        nhiemVu: 'Viết ra từng điều kiện đề cho, mỗi điều kiện một dòng. Kể cả điều kiện tưởng như thừa.',
        viSao: 'Bài khó thường khoá ở một điều kiện bị đọc lướt qua. Tách thành từng dòng thì không bỏ sót được dòng nào.',
        dauRa: { kieu: 'danh-sach', nhan: 'Các điều kiện đề cho', toiThieu: 2 },
        xongKhi: 'Có ít nhất hai dòng điều kiện.',
        phut: 15,
      },
      {
        id: 'thu-di-thang',
        ten: 'Thử đi thẳng và ghi chỗ bế tắc',
        nhiemVu: 'Giải theo cách nghĩ đầu tiên. Khi bế tắc thì dừng lại và ghi rõ bế tắc ở bước nào, thiếu điều gì.',
        viSao: 'Phải chạm vào bế tắc thì phép đổi dạng ở bước sau mới có chỗ bám; đọc lời giải ngay thì không học được cách nghĩ.',
        dauRa: { kieu: 'chu', nhan: 'Chỗ bế tắc và thứ còn thiếu' },
        xongKhi: 'Có mô tả cụ thể chỗ bế tắc.',
        phut: 30,
      },
      {
        id: 'doi-dang-bai',
        ten: 'Đổi bài toán sang dạng khác',
        nhiemVu: 'Thử một phép đổi dạng: đặt ẩn phụ, đổi biến, đếm bù trừ, hoặc xét trường hợp. Ghi phép đổi đã chọn và bài toán sau khi đổi.',
        viSao: 'Đây là kỹ năng phân biệt bài bốn sao với bài năm sao — đi thẳng thì bế tắc, đổi dạng thì bài thành quen thuộc.',
        dauRa: { kieu: 'chu', nhan: 'Phép đổi dạng và bài toán sau khi đổi' },
        xongKhi: 'Có tên phép đổi và dạng mới của bài toán.',
        phut: 30,
      },
      {
        id: 'viet-lai-loi-giai',
        ten: 'Viết lại lời giải cho người khác đọc',
        nhiemVu: 'Viết lời giải đầy đủ, mỗi bước nêu rõ căn cứ. Viết sao cho bạn cùng lớp đọc là hiểu, không cần hỏi thêm.',
        viSao: 'Viết cho người khác đọc bắt buộc phải nêu căn cứ từng bước, và chính lúc đó mới lộ ra bước nào mình còn đang đoán.',
        dauRa: { kieu: 'chu', nhan: 'Lời giải đầy đủ có căn cứ từng bước' },
        xongKhi: 'Lời giải có nêu căn cứ cho mỗi bước biến đổi.',
        phut: 30,
      },
      {
        id: 'bai-thu-hai',
        ten: 'Giải bài thứ hai cùng phép đổi dạng',
        nhiemVu: 'Tìm một bài khác cần đúng phép đổi dạng vừa dùng. Giải trong nửa thời gian của bài đầu. Ghi số phút đã dùng.',
        viSao: 'Giải được bài thứ hai nhanh hơn mới là dấu hiệu đã nắm được phép đổi dạng, chứ không phải may mắn ở bài đầu.',
        dauRa: { kieu: 'so', nhan: 'Số phút dùng cho bài thứ hai' },
        xongKhi: 'Có một con số phút.',
        phut: 25,
      },
    ],
  },

  // ══ NỀN — LUYỆN HẰNG NGÀY ══════════════════════════════════════════════
  {
    id: 'luyen-hang-ngay',
    ten: 'Biến chỗ yếu thành bài của hôm nay',
    motCau: 'Mười câu hôm nay hơn một trăm câu để dành cuối tuần.',
    chang: [
      {
        id: 'doc-cho-yeu',
        ten: 'Đọc chỗ yếu nhất hệ thống ghi',
        nhiemVu: 'Mở chân dung năng lực, đọc dạng bài có tỉ lệ đúng thấp nhất của đích đang theo. Ghi mã dạng và tỉ lệ.',
        viSao: 'Hệ thống đã ghi lại mọi lần làm bài, nên chỗ yếu là dữ liệu chứ không phải cảm giác của hôm nay.',
        dauRa: { kieu: 'chu', nhan: 'Mã dạng yếu nhất và tỉ lệ đúng' },
        xongKhi: 'Có một mã dạng và một tỉ lệ.',
        phut: 5,
      },
      {
        id: 'lam-muoi-cau',
        ten: 'Làm mười câu của dạng đó',
        nhiemVu: 'Làm đúng mười câu thuộc dạng vừa đọc. Bấm giờ. Ghi số câu đúng.',
        viSao: 'Mười câu đủ để thấy xu hướng mà vẫn gọn trong một buổi; nhiều hơn thì dễ bỏ dở, ít hơn thì kết quả nhiễu.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng trên mười' },
        xongKhi: 'Có số câu đúng của lần làm thứ nhất, từ 0 đến 10.',
        phut: 25,
      },
      {
        id: 'doc-can-cu-bo-sot',
        ten: 'Đọc lời giải và ghi căn cứ đã bỏ sót',
        nhiemVu: 'Với mỗi câu sai, đọc lời giải và ghi lại CĂN CỨ mà mình đã bỏ sót — định lý nào, điều kiện nào, quy tắc nào.',
        viSao: 'Chép lại lời giải thì lần sau vẫn sai; ghi lại căn cứ bị bỏ sót mới là thứ mang sang bài khác được.',
        dauRa: { kieu: 'danh-sach', nhan: 'Các căn cứ đã bỏ sót', toiThieu: 1 },
        xongKhi: 'Mỗi câu sai có ít nhất một căn cứ được ghi.',
        phut: 20,
      },
      {
        id: 'lam-muoi-cau-khac',
        ten: 'Làm mười câu khác cùng dạng',
        nhiemVu: 'Làm mười câu mới cùng dạng, hệ thống dựng đề khác. Ghi số câu đúng.',
        viSao: 'Đề khác cùng dạng loại được việc nhớ đáp án, nên hiệu hai lần phản ánh đúng phần đã học được.',
        dauRa: { kieu: 'so', nhan: 'Số câu đúng lần hai' },
        xongKhi: 'Có số câu đúng của lần làm thứ hai, từ 0 đến 10.',
        phut: 25,
      },
      {
        id: 'so-hai-lan',
        ten: 'So hai lần làm',
        nhiemVu: 'Ghi hiệu giữa hai lần. Ghi cả khi hiệu bằng không hoặc âm.',
        viSao: 'Hiệu âm là tín hiệu có ích: nó nói cách học hiện tại chưa vào, và cần đổi cách chứ không phải cố thêm.',
        dauRa: { kieu: 'so', nhan: 'Hiệu giữa hai lần' },
        xongKhi: 'Có một con số, kể cả số âm.',
        phut: 5,
      },
      {
        id: 'doi-cach-hay-giu',
        ten: 'Đổi cách học hay giữ nguyên',
        nhiemVu: 'Hiệu dương thì ghi giữ nguyên cách học. Hiệu bằng không hoặc âm thì chọn một cách khác: học lại lý thuyết, xem bài mẫu, hoặc hỏi giáo viên. Ghi quyết định.',
        viSao: 'Có quy tắc sẵn thì không phải tranh luận mỗi buổi, và học viên không tự trách mình khi con số chưa lên.',
        dauRa: { kieu: 'chu', nhan: 'Quyết định cho buổi sau' },
        xongKhi: 'Có một quyết định rõ ràng.',
        phut: 5,
      },
    ],
  },
];

const TRUC_INDEX = new Map(TRUC.map((t) => [t.id, t]));

module.exports = { TRUC, TRUC_INDEX };
