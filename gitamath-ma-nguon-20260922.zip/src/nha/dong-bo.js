'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ĐỒNG BỘ — MỘT NGUỒN SỰ THẬT CHO CẢ LỘ TRÌNH
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mọi màn hình, mọi trợ lý AI, mọi người tư vấn và mọi giáo viên AI đều hỏi
 *  đúng một hàm: `boiCanh`. Không ai được tự dựng lấy câu trả lời từ dữ liệu
 *  gốc. Đây là toàn bộ cách hệ thống giữ cho bốn vai không kéo bốn hướng.
 *
 *  BẢN ĐỒ LỘ TRÌNH KHÔNG PHẢI MỤC LỤC.
 *  `banDo` trả về từng phòng kèm tiến độ, nhưng KHÔNG kèm nội dung bước nào
 *  của phòng đó — kể cả phòng đang mở dở. Muốn biết trong phòng có gì thì phải
 *  vào phòng. Phòng của vai khác thì khoá, và ổ khoá chỉ nói là chưa tới lượt
 *  vai của mình, không hé một chữ nào bên trong.
 *
 *  NĂNG LỰC SÁNG THEO VIỆC ĐÃ LÀM.
 *  Mười một năng lực quanh bản đồ không bấm vào được. Chúng sáng dần theo tiến
 *  độ của những phòng nuôi chúng, nên người học nhìn một cái là thấy công sức
 *  của mình đọng lại ở đâu — đó là phần thưởng thật, không phải huy hiệu phát
 *  cho có.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const truc = require('./truc');
const nhiemVu = require('./nhiem-vu');
const { PHONG, PHONG_INDEX, VE_TINH, VAI_INDEX, moDuoc } = require('./ban-do');

class NgoiNha {
  /**
   * @param {object} o
   * @param {import('../data/repository').Repository} [o.kho] nơi ghi bền vững
   */
  constructor({ kho = null, nhatKy = null } = {}) {
    this.kho = kho;
    this.nhatKy = nhatKy;
    /** khoá `${nhaId}|${thanhVienId}|${phongId}` → trạng thái trục */
    this.trangThai = new Map();
    this.soLieu = { moPhong: 0, nopBuoc: 0, xongPhong: 0, chanXemTruoc: 0 };
    this._napLai();
  }

  _khoa(nhaId, thanhVienId, phongId) { return `${nhaId}|${thanhVienId}|${phongId}`; }

  _napLai() {
    if (!this.kho) return;
    for (const doc of this.kho.all()) {
      if (doc && doc.trucId) this.trangThai.set(doc.id, doc.trangThai);
    }
  }

  _ghi(khoa, trangThai) {
    this.trangThai.set(khoa, trangThai);
    if (this.kho) this.kho.put({ id: khoa, trucId: trangThai.trucId, trangThai });
  }

  // ── Bản đồ nhà ──────────────────────────────────────────────────────────

  /**
   * Bản đồ ngôi nhà cho một thành viên với một vai.
   * Chỉ có tiến độ, tuyệt đối không có nội dung bước.
   */
  banDo(nhaId, thanhVienId, vaiId) {
    const vai = VAI_INDEX.get(vaiId) || null;
    const phong = PHONG.map((p) => {
      const mo = moDuoc(vaiId, p.id);
      const st = this.trangThai.get(this._khoa(nhaId, thanhVienId, p.id));
      const td = st ? truc.tienDo(st) : null;
      return {
        id: p.id,
        ten: p.ten,
        phu: p.phu,
        moTa: p.moTa,
        viTri: p.viTri,
        mau: p.mau,
        mo,
        // Phòng của vai khác: nói thẳng là chưa tới lượt, không hé nội dung.
        lyDoKhoa: mo ? null : 'Phòng này thuộc vai khác. Đăng nhập đúng vai thì mở.',
        daBatDau: !!st,
        tienDo: td ? { daXong: td.daXong, tong: td.tong, tiLe: td.tiLe, xongTruc: td.xongTruc } : null,
      };
    });

    // Vệ tinh sáng theo trung bình tiến độ của những phòng nuôi nó.
    const veTinh = VE_TINH.map((v) => {
      const nuoiBoi = PHONG.filter((p) => p.nuoi.includes(v.id));
      const diem = nuoiBoi.map((p) => {
        const st = this.trangThai.get(this._khoa(nhaId, thanhVienId, p.id));
        return st ? truc.tienDo(st).tiLe : 0;
      });
      const sang = diem.length ? Math.round(diem.reduce((a, b) => a + b, 0) / diem.length) : 0;
      return {
        id: v.id, ten: v.ten, phu: v.phu, mau: v.mau,
        sang,
        nuoiBoi: nuoiBoi.map((p) => p.ten),
      };
    });

    const soPhongMo = phong.filter((p) => p.mo).length;
    const soXong = phong.filter((p) => p.tienDo && p.tienDo.xongTruc).length;
    return {
      nhaId, thanhVienId,
      vai: vai ? { id: vai.id, ten: vai.ten, moTa: vai.moTa } : null,
      phong, veTinh,
      tomTat: { soPhongMo, soXong, soPhong: phong.length },
    };
  }

  // ── Vào phòng và đi ─────────────────────────────────────────────────────

  /** Mở một phòng. Vai không hợp thì từ chối, và lời từ chối không hé nội dung. */
  moPhong(nhaId, thanhVienId, vaiId, phongId, luc = Date.now()) {
    if (!PHONG_INDEX.has(phongId)) return { ok: false, loi: 'KHONG_CO_PHONG' };
    if (!moDuoc(vaiId, phongId)) {
      this.soLieu.chanXemTruoc++;
      return { ok: false, loi: 'SAI_VAI', vi: 'Phòng này thuộc vai khác. Đăng nhập đúng vai thì mở.' };
    }
    const khoa = this._khoa(nhaId, thanhVienId, phongId);
    if (!this.trangThai.has(khoa)) {
      const r = truc.batDau(phongId, luc);
      if (!r.ok) return { ok: false, loi: r.loi };
      this._ghi(khoa, r.trangThai);
      this.soLieu.moPhong++;
      this.nhatKy?.record?.({
        actor: thanhVienId, action: 'nha.mo-phong', verdict: 'ALLOW', severity: 0,
        detail: { nhaId, phongId, vaiId },
      });
    }
    return { ok: true, boiCanh: this.boiCanh(nhaId, thanhVienId, vaiId, phongId) };
  }

  /** Nộp đầu ra của bước hiện tại. Đây là cách DUY NHẤT để tiến. */
  nopBuoc(nhaId, thanhVienId, vaiId, phongId, dauRa, luc = Date.now()) {
    if (!moDuoc(vaiId, phongId)) return { ok: false, loi: 'SAI_VAI' };
    const khoa = this._khoa(nhaId, thanhVienId, phongId);
    const st = this.trangThai.get(khoa);
    if (!st) return { ok: false, loi: 'CHUA_MO_PHONG' };
    const r = truc.nop(st, dauRa, luc);
    if (!r.ok) return r;
    this._ghi(khoa, r.trangThai);
    this.soLieu.nopBuoc++;
    if (r.xongTruc) {
      this.soLieu.xongPhong++;
      this.nhatKy?.record?.({
        actor: thanhVienId, action: 'nha.xong-phong', verdict: 'ALLOW', severity: 0,
        detail: { nhaId, phongId },
      });
    }
    return { ok: true, vuaXong: r.vuaXong, xongTruc: r.xongTruc, boiCanh: this.boiCanh(nhaId, thanhVienId, vaiId, phongId) };
  }

  // ── Nguồn sự thật ───────────────────────────────────────────────────────

  /**
   * BỐI CẢNH — thứ duy nhất mọi vai được phép hỏi.
   *
   * Trả về chỗ đang đứng, bước hiện tại đã cắt sẵn, và bản giao việc cho cả
   * bốn vai. Bốn bản ấy dựng từ cùng một `hienThi`, nên không thể lệch nhau.
   */
  boiCanh(nhaId, thanhVienId, vaiId, phongId) {
    const khoa = this._khoa(nhaId, thanhVienId, phongId);
    const st = this.trangThai.get(khoa);
    if (!st) return null;
    if (!moDuoc(vaiId, phongId)) return null;
    const v = truc.hienThi(st);
    if (!v) return null;
    return {
      nhaId, thanhVienId, vaiId,
      phongId,
      chang: v,
      giaoViec: nhiemVu.caBonVai(v),
      capNhatLuc: st.capNhatLuc,
    };
  }

  /** Chỗ đang đứng của một thành viên trên toàn nhà — dùng cho người tư vấn. */
  dangODau(nhaId, thanhVienId) {
    const ra = [];
    for (const p of PHONG) {
      const st = this.trangThai.get(this._khoa(nhaId, thanhVienId, p.id));
      if (!st) continue;
      const v = truc.hienThi(st);
      ra.push({
        phongId: p.id, tenPhong: p.ten,
        viTri: v.viTri, tong: v.tong, xong: v.xong,
        // Tên bước hiện tại được nêu ra vì người tư vấn cần biết để hỏi đúng
        // chỗ; bước SAU thì không, đúng luật như mọi vai khác.
        buocHienTai: v.hienTai ? v.hienTai.ten : null,
        capNhatLuc: st.capNhatLuc,
      });
    }
    ra.sort((a, b) => b.capNhatLuc - a.capNhatLuc);
    return { nhaId, thanhVienId, dangMo: ra, ganNhat: ra[0] || null };
  }

  trangThaiHeThong() {
    return {
      soNha: new Set([...this.trangThai.keys()].map((k) => k.split('|')[0])).size,
      soTrucDangMo: this.trangThai.size,
      ...this.soLieu,
    };
  }
}

module.exports = NgoiNha;
