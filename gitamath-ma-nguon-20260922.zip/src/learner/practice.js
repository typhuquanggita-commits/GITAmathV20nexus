'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  PHIÊN LUYỆN TẬP — chọn đúng bài, đúng lúc, đúng mức
 * ═══════════════════════════════════════════════════════════════════════════
 *  Thứ tự ưu tiên khi chọn bài (không phải bốc ngẫu nhiên từ kho):
 *
 *   1. NỢ ÔN TẬP   — dạng tới hạn ôn theo SM-2. Bỏ qua là quên, học lại từ đầu.
 *   2. LỖ HỔNG NỀN — dạng tiên quyết chưa vững mà dạng sắp học đang cần.
 *   3. VÙNG PHÁT TRIỂN GẦN — dạng đang ở giữa "chưa biết" và "đã thạo";
 *      đây là chỗ mỗi phút luyện tập đổi được nhiều tiến bộ nhất.
 *   4. DẠNG MỚI    — theo đúng thứ tự tiên quyết, không nhảy cóc.
 *   5. DUY TRÌ     — dạng đã thạo, thỉnh thoảng nhắc lại để khỏi rơi.
 *
 *  Thích ứng NGAY TRONG PHIÊN:
 *   · Sai 2 bài liên tiếp → hạ một bậc sao và chen một bài cùng dạng dễ hơn.
 *   · Đúng 3 bài liên tiếp không dùng gợi ý → nâng một bậc sao.
 *   · Làm quá nhanh mà sai → nghi đoán mò, chen bài yêu cầu trình bày.
 *   · Quá giờ hoặc dấu hiệu mệt → dừng phiên, không ép.
 *
 *  Chấm bài tự động bằng BỘ KIỂM TRA TOÁN HỌC: học viên viết đáp án theo cách
 *  của mình, máy so tương đương chứ không so chuỗi ký tự.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { id: newId, round, clamp } = require('../utils');
const { FORM_INDEX, LEVELS, formsForLevel, learningOrder } = require('../curriculum/hierarchy');
const { MASTERY_THRESHOLD } = require('./mastery');

const DEFAULT_SIZE = 10;
const MAX_SIZE = 30;
const FATIGUE_MINUTES = 45;
const RUSH_RATIO = 0.25;         // làm dưới 25% thời gian chuẩn là bất thường
const SOURCES = {
  REVIEW: { code: 'REVIEW', name: 'Nợ ôn tập', priority: 1 },
  GAP: { code: 'GAP', name: 'Lỗ hổng nền', priority: 2 },
  ZPD: { code: 'ZPD', name: 'Vùng phát triển gần', priority: 3 },
  NEW: { code: 'NEW', name: 'Dạng mới', priority: 4 },
  MAINTAIN: { code: 'MAINTAIN', name: 'Duy trì', priority: 5 },
};

/**
 * Trần tỉ lệ cho từng nguồn trong một phiên.
 * Vì sao cần: nếu để nguồn ưu tiên cao chiếm hết, học viên có lỗ hổng sẽ chỉ
 * mãi vá nền, không bao giờ thấy cái mới — học mà không tiến thì bỏ cuộc.
 * Ngược lại cũng không cho cái mới lấn hết phần ôn tập.
 */
const SOURCE_CAP = { REVIEW: 0.4, GAP: 0.4, ZPD: 0.4, NEW: 0.4, MAINTAIN: 0.2 };

class PracticeEngine {
  constructor({ bank, mastery, telemetry, profiles, verifier = null, practices = null, attempts = null, audit = null }) {
    this.bank = bank;
    this.mastery = mastery;
    this.telemetry = telemetry;
    this.profiles = profiles;
    this.verifier = verifier;
    this.practices = practices;
    this.attempts = attempts;
    this.audit = audit;
    this.sessions = new Map();
    this.stats = { started: 0, finished: 0, abandoned: 0, itemsServed: 0, autoGraded: 0, needManual: 0 };
  }

  // ── Lập kế hoạch phiên ───────────────────────────────────────────────────

  /**
   * Dựng hàng bài cho một phiên. Trả về danh sách có ghi rõ VÌ SAO chọn bài đó.
   */
  plan({ learnerId, size = DEFAULT_SIZE, level = null, formCodes = null } = {}) {
    const rec = this.profiles?.get(learnerId);
    const lv = level ?? rec?.currentLevel ?? 0;
    const n = clamp(Number(size) || DEFAULT_SIZE, 3, MAX_SIZE);
    const used = new Set();
    const queue = [];

    const perSource = {};
    const capOf = (src) => Math.max(1, Math.round(n * (SOURCE_CAP[src] ?? 1)));

    const take = (formCode, source, stars = null, why = '', atLevel = lv, ignoreCap = false) => {
      if (queue.length >= n) return false;
      if (!ignoreCap && (perSource[source] || 0) >= capOf(source)) return false;
      const pool = this.bank.query({ formCode, level: atLevel, stars, status: 'PUBLISHED', limit: 50, exclude: [...used] })
        .filter((it) => !used.has(it.id));
      if (!pool.length) return false;
      // Chọn tất định: bài ít được làm nhất, hoà thì theo mã.
      const pick = pool.sort((a, b) => (a.attempts || 0) - (b.attempts || 0) || a.id.localeCompare(b.id))[0];
      used.add(pick.id);
      perSource[source] = (perSource[source] || 0) + 1;
      queue.push({ itemId: pick.id, formCode, source, stars: pick.stars, level: pick.level, why });
      return true;
    };

    const allowed = formCodes ? new Set(formCodes) : null;
    const ok = (code) => !allowed || allowed.has(code);

    // 1. Nợ ôn tập
    for (const d of (this.mastery?.due(learnerId, { limit: n }) || [])) {
      if (!ok(d.formCode)) continue;
      take(d.formCode, SOURCES.REVIEW.code, null,
        `Tới hạn ôn${d.overdueDays > 0 ? `, đã quá hạn ${d.overdueDays} ngày` : ''} — để lâu là quên.`);
    }

    // 2. Lỗ hổng nền: dạng tiên quyết của dạng sắp học mà mức thạo còn thấp
    const upcoming = formsForLevel(lv).filter((f) => ok(f.code));
    const mastMap = this.mastery?.map(learnerId) || {};
    const gapCodes = new Set();
    for (const f of upcoming) {
      for (const p of f.prereq || []) {
        if ((mastMap[p] ?? 0) < MASTERY_THRESHOLD && FORM_INDEX.has(p)) gapCodes.add(p);
      }
    }
    for (const code of [...gapCodes].sort()) {
      take(code, SOURCES.GAP.code, null,
        `Là tiền đề của dạng đang học nhưng mức thạo mới ${round((mastMap[code] ?? 0) * 100, 0)}%.`);
    }

    // 3. Vùng phát triển gần
    for (const z of (this.mastery?.zpd(learnerId, { limit: n }) || [])) {
      if (!ok(z.formCode)) continue;
      take(z.formCode, SOURCES.ZPD.code, null,
        `Mức thạo ${round(z.p * 100, 0)}% — đang ở ngưỡng, luyện lúc này hiệu quả nhất.`);
    }

    // 4. Dạng mới theo đúng thứ tự tiên quyết
    if (queue.length < n) {
      const order = learningOrder(upcoming.map((f) => f.code)).order;
      for (const code of order) {
        if (queue.length >= n) break;
        if ((mastMap[code] ?? 0) > 0) continue;                   // đã đụng tới rồi
        const prereq = FORM_INDEX.get(code)?.prereq || [];
        const blocked = prereq.find((p) => (mastMap[p] ?? 0) < 0.5 && FORM_INDEX.has(p));
        if (blocked) continue;                                     // chưa đủ nền thì chưa học
        take(code, SOURCES.NEW.code, null, `Dạng mới ở tầng ${LEVELS[lv].code}, tiên quyết đã đủ.`);
      }
    }

    // 5. Duy trì
    if (queue.length < n) {
      for (const [code, p] of Object.entries(mastMap).sort((a, b) => b[1] - a[1])) {
        if (queue.length >= n) break;
        if (p < MASTERY_THRESHOLD || !ok(code)) continue;
        take(code, SOURCES.MAINTAIN.code, null, `Đã thạo ${round(p * 100, 0)}% — nhắc lại để khỏi rơi.`);
      }
    }

    // 6. Bù cho đủ: nếu các nguồn trên chưa lấp đủ (học viên mới tinh, mọi dạng
    //    đều bị chặn vì chưa có nền), lấy dạng CỬA VÀO — dạng ít tiên quyết chưa
    //    đạt nhất. Không bỏ trống phiên, nhưng cũng không nhảy cóc bừa.
    if (queue.length < n) {
      const unmet = (code) => (FORM_INDEX.get(code)?.prereq || [])
        .filter((pr) => FORM_INDEX.has(pr) && (mastMap[pr] ?? 0) < 0.5).length;
      const entry = upcoming
        .map((f) => ({ code: f.code, unmet: unmet(f.code) }))
        .sort((a, b) => a.unmet - b.unmet || a.code.localeCompare(b.code));
      for (const e of entry) {
        if (queue.length >= n) break;
        take(e.code, e.unmet === 0 ? SOURCES.NEW.code : SOURCES.GAP.code,
          null,
          e.unmet === 0
            ? `Dạng cửa vào của tầng ${LEVELS[lv].code} — không cần tiên quyết nào khác.`
            : `Bắt đầu từ đây dù còn ${e.unmet} tiên quyết chưa vững, vì chưa có dạng nào sẵn sàng hơn.`,
          lv, true);
      }
    }

    // 7. Vẫn thiếu: nới sang tầng kề. Nói rõ là đã nới, không im lặng đổi mức.
    const widened = [];
    if (queue.length < n) {
      for (const d of [-1, 1, -2, 2]) {
        const alt = lv + d;
        if (alt < 0 || alt > 9 || queue.length >= n) continue;
        for (const f of formsForLevel(alt)) {
          if (queue.length >= n || !ok(f.code)) continue;
          const before = queue.length;
          take(f.code, d < 0 ? SOURCES.GAP.code : SOURCES.NEW.code, null,
            d < 0
              ? `Lùi xuống tầng ${LEVELS[alt].code} vì tầng ${LEVELS[lv].code} chưa đủ bài đã phát hành.`
              : `Lấy thêm từ tầng ${LEVELS[alt].code} vì tầng ${LEVELS[lv].code} chưa đủ bài đã phát hành.`,
            alt, true);
          if (queue.length > before) widened.push(alt);
        }
      }
    }

    return {
      level: lv,
      size: queue.length,
      requested: n,
      widenedToLevels: [...new Set(widened)].sort(),
      shortfall: Math.max(0, n - queue.length),
      shortfallReason: queue.length < n
        ? 'Kho chưa đủ bài đã phát hành cho tầng và các dạng đang cần.'
        : null,
      queue,
    };
  }

  // ── Chạy phiên ───────────────────────────────────────────────────────────

  start({ learnerId, size = DEFAULT_SIZE, level = null, formCodes = null } = {}) {
    if (!learnerId) return { ok: false, error: 'MISSING_INPUT', need: ['learnerId'] };
    const p = this.plan({ learnerId, size, level, formCodes });
    if (!p.queue.length) {
      return { ok: false, error: 'NO_ITEMS', hint: 'Kho chưa có bài phù hợp với tầng và dạng đang cần của học viên.' };
    }

    const s = {
      id: newId('PR'),
      learnerId,
      level: p.level,
      queue: p.queue,
      cursor: 0,
      responses: [],
      streakRight: 0,
      streakWrong: 0,
      starAdjust: 0,
      state: 'RUNNING',
      startedAt: Date.now(),
      flags: [],
    };
    this.sessions.set(s.id, s);
    this.stats.started++;
    bus.safeEmit('practice:started', { sessionId: s.id, learnerId, size: p.queue.length });
    this.telemetry?.action(learnerId, 'SESSION_START', { sessionId: s.id, size: p.queue.length });

    return {
      ok: true,
      sessionId: s.id,
      level: p.level,
      levelName: `${LEVELS[p.level].code} — ${LEVELS[p.level].name}`,
      size: p.queue.length,
      composition: this._composition(p.queue),
      plan: p.queue.map((q) => ({ formCode: q.formCode, source: q.source, why: q.why })),
      item: this._present(s, 0),
    };
  }

  _composition(queue) {
    const out = {};
    for (const q of queue) out[q.source] = (out[q.source] || 0) + 1;
    return Object.entries(out).map(([code, count]) => ({
      code, name: SOURCES[code]?.name || code, count,
    })).sort((a, b) => (SOURCES[a.code]?.priority || 9) - (SOURCES[b.code]?.priority || 9));
  }

  _present(s, idx) {
    const q = s.queue[idx];
    if (!q) return null;
    const it = this.bank.get(q.itemId);
    if (!it) return null;
    this.stats.itemsServed++;
    return {
      index: idx + 1,
      total: s.queue.length,
      itemId: it.id,
      formCode: it.formCode,
      formName: it.formName,
      stars: it.stars,
      level: it.level,
      stem: it.stem,
      hints: it.hints,
      normSeconds: it.normSeconds,
      source: q.source,
      sourceName: SOURCES[q.source]?.name || q.source,
      why: q.why,
      traps: it.traps,          // để giao diện nhắc khi học viên sai đúng bẫy
    };
  }

  /**
   * Chấm bài. Học viên có thể viết đáp án theo cách của mình —
   * máy so TƯƠNG ĐƯƠNG chứ không so chuỗi.
   */
  grade(itemId, submitted) {
    const it = this.bank.get(itemId);
    if (!it) return { ok: false, error: 'ITEM_NOT_FOUND' };
    const expected = String(it.answer ?? '').trim();
    const got = String(submitted ?? '').trim();
    if (!got) return { ok: true, correct: false, method: 'EMPTY', reason: 'Chưa nhập đáp án' };

    // Khớp chữ sau khi chuẩn hoá khoảng trắng — trường hợp dễ nhất.
    const norm = (x) => x.replace(/\s+/g, ' ').replace(/\$/g, '').toLowerCase();
    if (norm(expected) === norm(got)) {
      this.stats.autoGraded++;
      return { ok: true, correct: true, method: 'EXACT', reason: 'Khớp đáp án chuẩn' };
    }

    if (this.verifier) {
      // Đáp án dạng tập nghiệm: đối chiếu tập, không đối chiếu cách viết.
      if (it.check?.equation) {
        const r = this.verifier.checkRoots(it.check.equation, got, it.check.variable || 'x');
        if (r.ok) {
          this.stats.autoGraded++;
          return { ok: true, correct: r.correct, method: 'ROOT_SET', reason: r.reason, detail: { missing: r.missing, extra: r.extra } };
        }
      }
      // Đáp án là biểu thức: so tương đương.
      const eq = this.verifier.equivalent(expected, got);
      if (eq.ok && eq.equal !== null) {
        this.stats.autoGraded++;
        return {
          ok: true, correct: eq.equal === true, method: 'EQUIVALENT',
          reason: eq.equal ? 'Viết khác cách nhưng tương đương với đáp án chuẩn' : eq.reason,
        };
      }
    }

    // Không chấm máy được thì NÓI THẲNG, không đoán.
    this.stats.needManual++;
    return {
      ok: true, correct: null, method: 'MANUAL',
      reason: 'Đáp án dạng lời văn hoặc chứng minh — cần giáo viên chấm.',
      expected,
    };
  }

  /**
   * @param {object} o {sessionId, itemId, answer|correct, ms, hintsUsed}
   */
  answer({ sessionId, itemId, answer = null, correct = null, ms = null, hintsUsed = 0 } = {}) {
    const s = this.sessions.get(sessionId);
    if (!s) return { ok: false, error: 'SESSION_NOT_FOUND' };
    if (s.state !== 'RUNNING') return { ok: false, error: 'SESSION_FINISHED', state: s.state };
    const q = s.queue[s.cursor];
    if (!q) return { ok: false, error: 'NO_CURRENT_ITEM' };
    if (itemId && itemId !== q.itemId) return { ok: false, error: 'WRONG_ITEM', expected: q.itemId };

    const it = this.bank.get(q.itemId);
    let grade = null;
    let isCorrect = correct;
    if (isCorrect === null || isCorrect === undefined) {
      grade = this.grade(q.itemId, answer);
      isCorrect = grade.correct;
    }
    if (isCorrect === null) {
      // Chờ giáo viên chấm: ghi lại, không đoán đúng sai, không đụng vào mức thạo.
      s.responses.push({ itemId: q.itemId, formCode: q.formCode, pending: true, answer, ms, hintsUsed, at: Date.now() });
      s.cursor++;
      return {
        ok: true, graded: false, pending: true, grade,
        next: this._afterAnswer(s),
      };
    }

    const hints = clamp(Number(hintsUsed) || 0, 0, 5);
    const spent = ms == null ? null : Math.max(0, Number(ms));
    const norm = (it.normSeconds || 180) * 1000;
    const rushed = spent != null && spent < norm * RUSH_RATIO;
    const careless = rushed && !isCorrect;

    const resp = {
      itemId: q.itemId, formCode: q.formCode, stars: it.stars, level: it.level,
      source: q.source, correct: !!isCorrect, answer, ms: spent, hintsUsed: hints,
      rushed, careless, grade, at: Date.now(),
    };
    s.responses.push(resp);

    // Cập nhật mức thạo và nhật ký
    this.mastery?.update(s.learnerId, { formCode: q.formCode, stars: it.stars, correct: !!isCorrect, hintsUsed: hints, careless });
    this.telemetry?.attempt(s.learnerId, {
      itemId: q.itemId, formCode: q.formCode, correct: !!isCorrect, ms: spent,
      hintsUsed: hints, stars: it.stars, traps: it.traps, answer,
    });
    this.attempts?.put({
      id: `AT-${s.id}-${s.responses.length}`,
      learnerId: s.learnerId, sessionId: s.id, itemId: q.itemId, formCode: q.formCode,
      correct: !!isCorrect, ms: spent, hintsUsed: hints, rushed, at: resp.at,
    });
    this.bank.recordAttempt?.(q.itemId, { correct: !!isCorrect, ms: spent });

    // Nhịp trong phiên
    if (isCorrect) { s.streakRight++; s.streakWrong = 0; } else { s.streakWrong++; s.streakRight = 0; }

    const adapted = this._adapt(s, it, resp);
    s.cursor++;

    const fin = this._shouldStop(s);
    if (fin) return { ok: true, graded: true, correct: !!isCorrect, grade, adapted, ...this.finish(sessionId, fin) };

    return {
      ok: true, graded: true, correct: !!isCorrect, grade,
      feedback: this._feedback(it, resp),
      adapted,
      next: this._afterAnswer(s),
      progress: { done: s.responses.length, total: s.queue.length },
    };
  }

  _afterAnswer(s) {
    const item = this._present(s, s.cursor);
    return item;
  }

  /** Điều chỉnh ngay trong phiên theo nhịp làm bài. */
  _adapt(s, item, resp) {
    const notes = [];

    if (s.streakWrong >= 2) {
      // Đang tắc. Lùi một bước theo thứ tự: dễ hơn cùng dạng → cùng dạng tầng
      // thấp hơn → dạng TIÊN QUYẾT. Lùi về nền là cách gỡ đúng, không phải
      // cho làm tiếp bài cùng mức rồi hy vọng.
      const inQueue = s.queue.map((q) => q.itemId);
      const easier = this._findEasier(item, inQueue);
      s.starAdjust = -1;
      s.flags.push({ at: Date.now(), kind: 'STREAK_WRONG', formCode: item.formCode, rescued: !!easier });
      if (easier) {
        s.queue.splice(s.cursor + 1, 0, {
          itemId: easier.item.id, formCode: easier.item.formCode, source: SOURCES.GAP.code,
          stars: easier.item.stars, level: easier.item.level,
          why: easier.why,
        });
        notes.push(`Sai 2 bài liên tiếp — đã hạ độ khó và chen một bài gỡ (${easier.how}).`);
      } else {
        // Không có bài dễ hơn: phải nói ra, để giáo viên biết kho đang hổng chỗ nào.
        notes.push(`Sai 2 bài liên tiếp ở dạng "${item.formName || item.formCode}" `
          + `nhưng kho chưa có bài dễ hơn để gỡ — cần giáo viên kèm trực tiếp.`);
      }
      s.streakWrong = 0;
    }

    if (s.streakRight >= 3 && resp.hintsUsed === 0) {
      s.starAdjust = 1;
      notes.push('Đúng 3 bài liên tiếp không cần gợi ý — nâng độ khó.');
      // Nâng độ khó cho phần còn lại của hàng bài.
      for (let i = s.cursor + 1; i < s.queue.length; i++) {
        const cur = this.bank.get(s.queue[i].itemId);
        if (!cur) continue;
        const harder = this.bank.query({
          formCode: cur.formCode, level: cur.level, stars: Math.min(5, cur.stars + 1),
          status: 'PUBLISHED', limit: 10, exclude: s.queue.map((q) => q.itemId),
        })[0];
        if (harder) {
          s.queue[i] = { ...s.queue[i], itemId: harder.id, stars: harder.stars, why: 'Nâng độ khó vì đang làm tốt.' };
          break;
        }
      }
      s.streakRight = 0;
    }

    if (resp.rushed && !resp.correct) {
      notes.push('Làm quá nhanh rồi sai — dấu hiệu đoán mò, cần đọc kỹ đề.');
      s.flags.push({ at: Date.now(), kind: 'RUSH', itemId: item.id });
    }

    return notes;
  }

  /**
   * Tìm bài dễ hơn theo ba nấc lùi dần. Trả về null nếu kho thật sự không có,
   * chứ không hạ chuẩn để lấp chỗ trống.
   */
  _findEasier(item, exclude) {
    // Nấc 1: cùng dạng, cùng tầng, ít sao hơn.
    for (let st = item.stars - 1; st >= 1; st--) {
      const hit = this.bank.query({
        formCode: item.formCode, level: item.level, stars: st,
        status: 'PUBLISHED', limit: 5, exclude,
      })[0];
      if (hit) return { item: hit, how: `cùng dạng, ${st}★`, why: `Bài dễ hơn cùng dạng để gỡ chỗ đang tắc.` };
    }
    // Nấc 2: cùng dạng, tầng thấp hơn.
    for (let lv = item.level - 1; lv >= 0; lv--) {
      const hit = this.bank.query({
        formCode: item.formCode, level: lv, status: 'PUBLISHED', limit: 5, exclude,
      })[0];
      if (hit) return { item: hit, how: `cùng dạng, tầng ${LEVELS[lv].code}`, why: `Lùi về tầng ${LEVELS[lv].code} của cùng dạng vì đang sai liên tiếp.` };
    }
    // Nấc 3: dạng tiên quyết — về đúng cái nền đang thiếu.
    for (const pr of FORM_INDEX.get(item.formCode)?.prereq || []) {
      if (!FORM_INDEX.has(pr)) continue;
      for (let lv = item.level; lv >= 0; lv--) {
        const hit = this.bank.query({ formCode: pr, level: lv, status: 'PUBLISHED', limit: 5, exclude })[0];
        if (hit) {
          return {
            item: hit, how: `dạng tiên quyết ${pr}`,
            why: `Lùi về dạng tiên quyết "${FORM_INDEX.get(pr).name}" vì đây mới là chỗ đang hổng.`,
          };
        }
      }
    }
    return null;
  }

  /** Nhận xét ngay sau mỗi bài — nêu đúng chỗ sai, không chỉ "sai rồi". */
  _feedback(item, resp) {
    if (resp.correct) {
      return {
        verdict: 'ĐÚNG',
        note: resp.hintsUsed ? `Đúng, nhưng còn dùng ${resp.hintsUsed} gợi ý — lần sau thử tự làm trước.` : 'Đúng, không cần gợi ý.',
        solutionSteps: item.solutionSteps,
      };
    }
    return {
      verdict: 'CHƯA ĐÚNG',
      note: resp.rushed ? 'Bài này em làm rất nhanh rồi sai — đọc lại đề và trình bày từng bước.'
        : 'Xem lại lời giải mẫu, chú ý đúng chỗ dễ nhầm bên dưới.',
      traps: item.traps,
      solutionSteps: item.solutionSteps,
      answer: item.answer,
    };
  }

  /** Điều kiện dừng: hết bài, quá giờ, hoặc có dấu hiệu mệt. */
  _shouldStop(s) {
    if (s.cursor >= s.queue.length) return 'HẾT_BÀI';
    const minutes = (Date.now() - s.startedAt) / 60000;
    if (minutes > FATIGUE_MINUTES) return 'QUÁ_GIỜ';
    const last5 = s.responses.slice(-5);
    if (last5.length === 5 && last5.every((r) => r.rushed)) return 'DẤU_HIỆU_MỆT';
    return null;
  }

  // ── Kết thúc ─────────────────────────────────────────────────────────────

  finish(sessionId, reason = 'NGƯỜI_DÙNG_DỪNG') {
    const s = this.sessions.get(sessionId);
    if (!s) return { ok: false, error: 'SESSION_NOT_FOUND' };
    if (s.state !== 'RUNNING') return { ok: false, error: 'SESSION_FINISHED', state: s.state };
    s.state = 'DONE';
    s.finishedAt = Date.now();
    this.stats.finished++;

    const graded = s.responses.filter((r) => !r.pending);
    const correct = graded.filter((r) => r.correct).length;
    const pending = s.responses.filter((r) => r.pending).length;
    const byForm = {};
    for (const r of graded) {
      const f = (byForm[r.formCode] ??= { formCode: r.formCode, name: FORM_INDEX.get(r.formCode)?.name, done: 0, correct: 0, hints: 0 });
      f.done++;
      if (r.correct) f.correct++;
      f.hints += r.hintsUsed;
    }
    const totalMs = graded.reduce((n, r) => n + (r.ms || 0), 0);

    const report = {
      ok: true,
      done: true,
      sessionId: s.id,
      learnerId: s.learnerId,
      reason,
      planned: s.queue.length,
      answered: s.responses.length,
      correct,
      pendingManual: pending,
      accuracy: graded.length ? round(correct / graded.length, 3) : 0,
      hintsUsed: graded.reduce((n, r) => n + r.hintsUsed, 0),
      rushedCount: graded.filter((r) => r.rushed).length,
      minutes: round((s.finishedAt - s.startedAt) / 60000, 1),
      avgSecondsPerItem: graded.length ? round(totalMs / graded.length / 1000, 1) : 0,
      byForm: Object.values(byForm).map((f) => ({ ...f, accuracy: round(f.correct / f.done, 3) }))
        .sort((a, b) => a.accuracy - b.accuracy),
      composition: this._composition(s.queue),
      flags: s.flags,
      masterySnapshot: this.mastery?.summary(s.learnerId) || null,
      nextAdvice: this._advice(s, graded, correct),
    };

    this.practices?.put({
      id: s.id, learnerId: s.learnerId, state: 'DONE', level: s.level,
      startedAt: s.startedAt, finishedAt: s.finishedAt, report,
    });
    this.telemetry?.action(s.learnerId, 'SESSION_END', { sessionId: s.id, accuracy: report.accuracy });
    bus.safeEmit('practice:finished', { sessionId: s.id, learnerId: s.learnerId, accuracy: report.accuracy });
    return report;
  }

  _advice(s, graded, correct) {
    const out = [];
    const acc = graded.length ? correct / graded.length : 0;
    if (!graded.length) return ['Chưa làm bài nào nên chưa có gì để nhận xét.'];
    if (acc >= 0.9) out.push('Làm rất tốt. Buổi sau nên tăng độ khó thay vì tăng số lượng bài.');
    else if (acc >= 0.7) out.push('Ổn định. Giữ nhịp này và tập trung vào các dạng còn sai.');
    else if (acc >= 0.4) out.push('Còn chênh vênh. Buổi sau nên quay lại dạng nền trước khi đi tiếp.');
    else out.push('Kết quả thấp. Cần học lại dạng nền có người kèm, không nên tự luyện tiếp ngay.');

    const worst = Object.entries(graded.reduce((m, r) => {
      const f = (m[r.formCode] ??= { done: 0, correct: 0 });
      f.done++; if (r.correct) f.correct++;
      return m;
    }, {})).filter(([, f]) => f.correct / f.done < 0.5).map(([c]) => FORM_INDEX.get(c)?.name || c);
    if (worst.length) out.push(`Cần luyện thêm: ${worst.join('; ')}.`);

    const rushed = graded.filter((r) => r.rushed).length;
    if (rushed >= 3) out.push(`Có ${rushed} bài làm quá nhanh — nhiều khả năng đoán mò, cần rèn thói quen đọc kỹ đề.`);
    const hints = graded.reduce((n, r) => n + r.hintsUsed, 0);
    if (hints >= graded.length) out.push('Dùng gợi ý khá nhiều — thử tự làm trước, chỉ mở gợi ý khi thật sự bí.');
    return out;
  }

  abandon(sessionId) {
    const s = this.sessions.get(sessionId);
    if (!s) return { ok: false, error: 'SESSION_NOT_FOUND' };
    s.state = 'ABANDONED';
    this.stats.abandoned++;
    return { ok: true, sessionId };
  }

  get(sessionId) {
    const s = this.sessions.get(sessionId);
    if (!s) return null;
    return {
      id: s.id, learnerId: s.learnerId, state: s.state, level: s.level,
      planned: s.queue.length, answered: s.responses.length,
      startedAt: new Date(s.startedAt).toISOString(),
    };
  }

  status() {
    return {
      ...this.stats,
      running: [...this.sessions.values()].filter((s) => s.state === 'RUNNING').length,
      sources: Object.values(SOURCES),
      defaultSize: DEFAULT_SIZE,
      fatigueMinutes: FATIGUE_MINUTES,
    };
  }
}

module.exports = PracticeEngine;
module.exports.SOURCES = SOURCES;
module.exports.DEFAULT_SIZE = DEFAULT_SIZE;
module.exports.FATIGUE_MINUTES = FATIGUE_MINUTES;
