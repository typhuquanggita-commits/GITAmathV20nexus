'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CHẨN ĐOÁN ĐẦU VÀO — xếp tầng bằng BÀI ĐO, không hỏi cảm tính
 * ═══════════════════════════════════════════════════════════════════════════
 *  Không hỏi "em thấy mình học lực thế nào". Cho làm bài, đo, rồi mới xếp.
 *
 *  Cách đo (thang bậc thích ứng):
 *   · Xuất phát từ tầng ước lượng theo lớp đang học, KHÔNG phải tầng 0 —
 *     bắt học sinh lớp 9 làm lại bài lớp 3 là phí thời gian và xúc phạm.
 *   · Làm đúng → nâng độ khó. Làm sai → hạ. Bước nhảy nhỏ dần để hội tụ.
 *   · Năng lực θ cập nhật theo mô hình logistic một tham số (Rasch):
 *       P(đúng) = 1 / (1 + e^{-(θ − b)}) với b là tầng của bài.
 *   · Dừng khi sai số chuẩn đủ nhỏ HOẶC đã đủ số bài trần.
 *
 *  Kết quả không chỉ là một con số: kèm điểm mạnh, lỗ hổng theo từng dạng,
 *  và các dạng tiên quyết chưa vững — để lộ trình biết bắt đầu từ đâu.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const { id: newId, round, clamp } = require('../utils');
const { LEVELS, FORM_INDEX, blockOfGrade, formsForLevel } = require('../curriculum/hierarchy');

const MIN_ITEMS = 8;
const MAX_ITEMS = 20;
const SE_TARGET = 0.45;          // sai số chuẩn đủ nhỏ thì dừng
const MAX_SECONDS_PER_ITEM = 600;

/** Tầng khởi điểm ước lượng theo lớp — chỉ là chỗ BẮT ĐẦU ĐO, không phải kết luận. */
function seedLevelForGrade(grade) {
  const g = Number(grade);
  if (!Number.isFinite(g)) return 2;
  // Mốc dò ứng với học viên TRUNG BÌNH của lớp đó, không phải học viên giỏi.
  if (g <= 2) return 0;
  if (g <= 4) return 1;
  if (g <= 6) return 2;
  if (g <= 9) return 3;
  if (g <= 11) return 4;
  return 5;
}

const pCorrect = (theta, b) => 1 / (1 + Math.exp(-(theta - b)));

class PlacementService {
  /**
   * @param {object} o
   * @param {import('../content/item-bank')} o.bank
   * @param {import('./profile')} o.profiles
   * @param {import('./telemetry')} o.telemetry
   * @param {import('../data/repository').Repository} [o.exams]
   */
  constructor({ bank, profiles = null, telemetry = null, mastery = null, exams = null, audit = null }) {
    this.bank = bank;
    this.profiles = profiles;
    this.telemetry = telemetry;
    this.mastery = mastery;
    this.exams = exams;
    this.audit = audit;
    this.sessions = new Map();
    this.stats = { started: 0, completed: 0, abandoned: 0, itemsServed: 0 };
  }

  // ── Bắt đầu ──────────────────────────────────────────────────────────────

  /**
   * @param {object} o {learnerId, grade, subject, maxItems}
   */
  start({ learnerId, grade = null, subject = 'math', maxItems = MAX_ITEMS } = {}) {
    if (!learnerId) return { ok: false, error: 'MISSING_INPUT', need: ['learnerId'] };
    const rec = this.profiles?.get(learnerId);
    const g = grade ?? rec?.grade ?? null;
    if (g == null) return { ok: false, error: 'MISSING_INPUT', need: ['grade'], hint: 'Chưa biết lớp thì chưa biết bắt đầu đo từ đâu' };

    const seed = seedLevelForGrade(g);
    const s = {
      id: newId('PL'),
      learnerId,
      grade: g,
      block: blockOfGrade(Number(g)),
      subject,
      theta: seed,               // năng lực ước lượng, trên cùng thang với tầng
      seedLevel: seed,
      infoSum: 0,                // tổng thông tin Fisher, dùng tính sai số chuẩn
      asked: [],
      responses: [],
      served: new Set(),
      state: 'RUNNING',
      startedAt: Date.now(),
      maxItems: clamp(Number(maxItems) || MAX_ITEMS, MIN_ITEMS, MAX_ITEMS),
    };
    this.sessions.set(s.id, s);
    this.stats.started++;

    const first = this._nextItem(s);
    if (!first) {
      this.sessions.delete(s.id);
      return { ok: false, error: 'NO_ITEMS', hint: 'Kho chưa có bài phù hợp để đo ở dải tầng này' };
    }
    s.served.add(first.id);   // đánh dấu ngay, nếu không bài đầu sẽ bị hỏi lại
    bus.safeEmit('placement:started', { sessionId: s.id, learnerId, seedLevel: seed });
    return {
      ok: true, sessionId: s.id, learnerId,
      seedLevel: seed,
      seedReason: `Lớp ${g} nên bắt đầu đo từ tầng ${LEVELS[seed].code} (${LEVELS[seed].name}), rồi điều chỉnh theo bài làm.`,
      maxItems: s.maxItems,
      item: this._present(first),
      progress: { asked: 1, max: s.maxItems },
    };
  }

  /** Bài kế tiếp: gần độ khó ước lượng nhất, chưa dùng, chọn tất định. */
  _nextItem(s) {
    const target = clamp(Math.round(s.theta), 0, 9);
    // Tìm loang ra hai bên quanh tầng mục tiêu.
    const order = [0, 1, -1, 2, -2, 3, -3, 4, -4];
    for (const d of order) {
      const lv = target + d;
      if (lv < 0 || lv > 9) continue;
      const pool = this.bank.query({
        level: lv, subject: s.subject, status: 'PUBLISHED', limit: 500,
        exclude: [...s.served],
      }).filter((it) => !s.served.has(it.id));
      if (!pool.length) continue;
      // Ưu tiên dạng CHƯA đo, để phủ rộng chứ không hỏi mãi một chủ đề.
      const seenForms = new Set(s.responses.map((r) => r.formCode));
      const fresh = pool.filter((it) => !seenForms.has(it.formCode));
      const chosen = (fresh.length ? fresh : pool).sort((a, b) => a.id.localeCompare(b.id))[0];
      if (chosen) return chosen;
    }
    return null;
  }

  _present(item) {
    return {
      id: item.id,
      formCode: item.formCode,
      formName: item.formName,
      level: item.level,
      stars: item.stars,
      stem: item.stem,
      hints: item.hints,             // học viên được dùng gợi ý, hệ thống có đếm
      normSeconds: item.normSeconds,
      // KHÔNG gửi đáp án và lời giải xuống máy học viên.
    };
  }

  // ── Ghi nhận trả lời ─────────────────────────────────────────────────────

  /**
   * @param {object} o {sessionId, itemId, correct, ms, hintsUsed}
   */
  answer({ sessionId, itemId, correct, ms = null, hintsUsed = 0 } = {}) {
    const s = this.sessions.get(sessionId);
    if (!s) return { ok: false, error: 'SESSION_NOT_FOUND' };
    if (s.state !== 'RUNNING') return { ok: false, error: 'SESSION_FINISHED', state: s.state };
    const item = this.bank.get(itemId);
    if (!item) return { ok: false, error: 'ITEM_NOT_FOUND' };
    if (s.served.has(itemId) && s.responses.some((r) => r.itemId === itemId)) {
      return { ok: false, error: 'ALREADY_ANSWERED' };
    }
    if (typeof correct !== 'boolean') return { ok: false, error: 'MISSING_INPUT', need: ['correct'] };

    const b = item.level;
    const p = pCorrect(s.theta, b);
    const info = p * (1 - p);                       // thông tin Fisher của mô hình Rasch

    // Bước cập nhật nhỏ dần theo số bài đã làm — hội tụ chứ không dao động mãi.
    const k = 1.2 / (1 + 0.25 * s.responses.length);
    s.theta = clamp(s.theta + k * ((correct ? 1 : 0) - p), 0, 9);
    s.infoSum += Math.max(info, 0.03);

    const spent = ms == null ? null : clamp(Number(ms), 0, MAX_SECONDS_PER_ITEM * 1000);
    const resp = {
      itemId, formCode: item.formCode, level: b, stars: item.stars,
      correct, ms: spent, hintsUsed: Number(hintsUsed) || 0,
      pExpected: round(p, 3), thetaAfter: round(s.theta, 3),
      normSeconds: item.normSeconds,
      at: Date.now(),
    };
    s.responses.push(resp);
    this.stats.itemsServed++;

    this.telemetry?.attempt(s.learnerId, {
      itemId, formCode: item.formCode, correct, ms: spent, hintsUsed: resp.hintsUsed, stars: item.stars,
    });
    this.mastery?.update(s.learnerId, { formCode: item.formCode, stars: item.stars, correct, hintsUsed: resp.hintsUsed });

    const se = 1 / Math.sqrt(Math.max(s.infoSum, 0.2));
    const enough = s.responses.length >= MIN_ITEMS && se <= SE_TARGET;
    const maxed = s.responses.length >= s.maxItems;

    if (enough || maxed) return this._finish(s, se, enough ? 'ĐỦ_TIN_CẬY' : 'ĐỦ_SỐ_BÀI');

    const next = this._nextItem(s);
    if (!next) return this._finish(s, se, 'HẾT_BÀI_PHÙ_HỢP');
    s.served.add(next.id);
    return {
      ok: true, done: false,
      item: this._present(next),
      progress: { asked: s.responses.length + 1, max: s.maxItems },
      // Không nói cho học viên biết đúng/sai để không ảnh hưởng tâm lý làm bài tiếp.
      estimate: { theta: round(s.theta, 2), standardError: round(se, 3) },
    };
  }

  // ── Kết luận ─────────────────────────────────────────────────────────────

  _finish(s, se, reason) {
    s.state = 'DONE';
    s.finishedAt = Date.now();
    this.stats.completed++;

    const rs = s.responses;
    const correct = rs.filter((r) => r.correct).length;
    const level = clamp(Math.floor(s.theta), 0, 9);

    // Xếp tầng thận trọng: lấy phần nguyên của θ, nhưng không vượt quá tầng
    // cao nhất mà học viên thật sự làm đúng — đo được đến đâu thì kết luận đến đó.
    const highestCorrect = rs.filter((r) => r.correct).reduce((m, r) => Math.max(m, r.level), -1);
    const placed = highestCorrect < 0 ? 0 : Math.min(level, highestCorrect + 1);

    // Theo dạng
    const byForm = {};
    for (const r of rs) {
      const f = (byForm[r.formCode] ??= { formCode: r.formCode, name: FORM_INDEX.get(r.formCode)?.name || r.formCode, asked: 0, correct: 0, hints: 0, slowCount: 0 });
      f.asked++;
      if (r.correct) f.correct++;
      f.hints += r.hintsUsed;
      if (r.ms && r.normSeconds && r.ms > r.normSeconds * 1000 * 1.5) f.slowCount++;
    }
    const forms = Object.values(byForm).map((f) => ({
      ...f,
      accuracy: round(f.correct / f.asked, 3),
      verdict: f.correct === f.asked && !f.hints ? 'vững'
        : f.correct === 0 ? 'chưa nắm'
          : f.correct / f.asked >= 0.5 ? 'lung lay' : 'yếu',
    })).sort((a, b) => a.accuracy - b.accuracy);

    const weak = forms.filter((f) => f.verdict === 'chưa nắm' || f.verdict === 'yếu');
    const strong = forms.filter((f) => f.verdict === 'vững');

    // Lỗ hổng tiên quyết: dạng yếu nào lại là tiền đề của dạng sắp học.
    const gaps = [];
    const upcoming = formsForLevel(placed).map((f) => f.code);
    for (const w of weak) {
      const dependents = upcoming.filter((c) => (FORM_INDEX.get(c)?.prereq || []).includes(w.formCode));
      if (dependents.length) gaps.push({ formCode: w.formCode, name: w.name, blocks: dependents.slice(0, 5) });
    }

    const result = {
      ok: true, done: true,
      sessionId: s.id,
      learnerId: s.learnerId,
      reason,
      itemsAsked: rs.length,
      correct,
      accuracy: round(correct / rs.length, 3),
      theta: round(s.theta, 2),
      standardError: round(se, 3),
      seedLevel: s.seedLevel,
      placedLevel: placed,
      placedName: `${LEVELS[placed].code} — ${LEVELS[placed].name}`,
      confidence: se <= SE_TARGET ? 'cao' : se <= 0.7 ? 'vừa' : 'thấp',
      highestCorrectLevel: highestCorrect,
      byForm: forms,
      strengths: strong.map((f) => f.name),
      weaknesses: weak.map((f) => f.name),
      prerequisiteGaps: gaps,
      durationSec: Math.round((s.finishedAt - s.startedAt) / 1000),
      recommendation: this._recommend(placed, s, forms, gaps),
    };

    // Ghi tầng đã xếp vào hồ sơ học viên — đây là kết quả đo, không phải khai báo.
    const rec = this.profiles?.get(s.learnerId);
    if (rec) {
      rec.currentLevel = placed;
      rec.placement = { at: Date.now(), level: placed, theta: result.theta, se: result.standardError, itemsAsked: rs.length };
      rec.levelHistory = [...(rec.levelHistory || []), { at: Date.now(), level: placed, by: 'PLACEMENT' }];
      this.profiles.save?.(s.learnerId);
    }
    this.exams?.put({
      id: s.id, learnerId: s.learnerId, kind: 'PLACEMENT', level: placed,
      at: s.finishedAt, result: { ...result, byForm: forms.slice(0, 20) },
    });
    this.audit?.record({
      actor: s.learnerId, action: 'placement.completed', verdict: 'ALLOW', severity: 0,
      detail: { sessionId: s.id, placedLevel: placed, theta: result.theta, items: rs.length },
    });
    bus.safeEmit('placement:completed', { sessionId: s.id, learnerId: s.learnerId, level: placed });
    return result;
  }

  _recommend(placed, s, forms, gaps) {
    const lines = [];
    lines.push(`Bắt đầu lộ trình ở tầng ${LEVELS[placed].code} — ${LEVELS[placed].name}.`);
    if (gaps.length) {
      lines.push(`Phải vá ${gaps.length} lỗ hổng nền trước, vì những dạng này chặn đường các dạng sắp học: `
        + gaps.map((g) => g.name).join('; ') + '.');
    }
    const shaky = forms.filter((f) => f.verdict === 'lung lay');
    if (shaky.length) lines.push(`Cần củng cố thêm: ${shaky.map((f) => f.name).join('; ')}.`);
    const strong = forms.filter((f) => f.verdict === 'vững');
    if (strong.length) lines.push(`Đã vững: ${strong.map((f) => f.name).join('; ')} — không cần học lại.`);
    if (placed < s.seedLevel) {
      lines.push(`Kết quả đo thấp hơn mức thường thấy của lớp ${s.grade}. Nên ưu tiên lấp nền trước khi chạy theo chương trình lớp.`);
    } else if (placed > s.seedLevel) {
      lines.push(`Kết quả đo cao hơn mức thường thấy của lớp ${s.grade}. Có thể đẩy nhanh phần cơ bản.`);
    }
    return lines;
  }

  get(sessionId) {
    const s = this.sessions.get(sessionId);
    if (!s) return null;
    return {
      id: s.id, learnerId: s.learnerId, state: s.state,
      asked: s.responses.length, maxItems: s.maxItems,
      theta: round(s.theta, 2), seedLevel: s.seedLevel,
      startedAt: new Date(s.startedAt).toISOString(),
    };
  }

  abandon(sessionId) {
    const s = this.sessions.get(sessionId);
    if (!s) return { ok: false, error: 'SESSION_NOT_FOUND' };
    s.state = 'ABANDONED';
    this.stats.abandoned++;
    return { ok: true, sessionId };
  }

  status() {
    return {
      ...this.stats,
      running: [...this.sessions.values()].filter((s) => s.state === 'RUNNING').length,
      minItems: MIN_ITEMS, maxItems: MAX_ITEMS, seTarget: SE_TARGET,
    };
  }
}

module.exports = PlacementService;
module.exports.seedLevelForGrade = seedLevelForGrade;
module.exports.MIN_ITEMS = MIN_ITEMS;
module.exports.MAX_ITEMS = MAX_ITEMS;
module.exports.SE_TARGET = SE_TARGET;
