'use strict';
/**
 * MỨC THẠO — Bayesian Knowledge Tracing (BKT) + lịch ôn SM-2.
 *
 *  BKT bốn tham số cho mỗi DẠNG:
 *    pInit  xác suất đã thạo từ đầu
 *    pLearn xác suất học được sau một lần làm
 *    pSlip  đã thạo nhưng vẫn làm sai (ẩu)
 *    pGuess chưa thạo nhưng đoán trúng
 *
 *  pSlip/pGuess điều chỉnh theo độ khó: bài 1★ dễ đoán trúng hơn bài 5★.
 */

const { round, clamp } = require('../utils');
const { FORM_INDEX } = require('../curriculum/hierarchy');

const BKT_DEFAULT = { pInit: 0.15, pLearn: 0.18, pSlip: 0.10, pGuess: 0.20 };

/** Bài càng khó: đoán trúng càng khó, sơ suất càng dễ. */
const BY_STARS = {
  1: { pGuess: 0.30, pSlip: 0.06 },
  2: { pGuess: 0.25, pSlip: 0.08 },
  3: { pGuess: 0.20, pSlip: 0.10 },
  4: { pGuess: 0.14, pSlip: 0.13 },
  5: { pGuess: 0.08, pSlip: 0.16 },
};

const MASTERY_THRESHOLD = 0.85;
const SM2_MIN_EASE = 1.3;

class Mastery {
  constructor() {
    this.state = new Map(); // userId -> Map(formCode -> record)
  }

  _user(userId) {
    if (!this.state.has(userId)) this.state.set(userId, new Map());
    return this.state.get(userId);
  }

  _record(userId, formCode) {
    const u = this._user(userId);
    if (!u.has(formCode)) {
      u.set(formCode, {
        formCode,
        p: BKT_DEFAULT.pInit,
        attempts: 0,
        correct: 0,
        streak: 0,
        // SM-2
        ease: 2.5,
        intervalDays: 0,
        reps: 0,
        lastSeenAt: 0,
        nextDueAt: Date.now(),
        history: [],
      });
    }
    return u.get(formCode);
  }

  /**
   * Cập nhật sau một lượt làm bài.
   * @param {object} a {formCode, stars, correct, hintsUsed, careless}
   */
  update(userId, a) {
    const r = this._record(userId, a.formCode);
    const params = { ...BKT_DEFAULT, ...(BY_STARS[a.stars] || {}) };

    // Dùng gợi ý làm giảm bằng chứng "đã thạo": coi như dễ đoán trúng hơn.
    const pGuess = clamp(params.pGuess + 0.12 * Math.min(a.hintsUsed || 0, 3), 0, 0.6);
    const pSlip = params.pSlip;

    // Hậu nghiệm P(thạo | quan sát)
    const prior = r.p;
    const post = a.correct
      ? (prior * (1 - pSlip)) / (prior * (1 - pSlip) + (1 - prior) * pGuess)
      : (prior * pSlip) / (prior * pSlip + (1 - prior) * (1 - pGuess));

    // Chuyển trạng thái học: có cơ hội học được sau mỗi lần làm
    r.p = round(clamp(post + (1 - post) * params.pLearn, 0, 0.999), 4);

    r.attempts++;
    if (a.correct) { r.correct++; r.streak++; } else { r.streak = 0; }
    r.lastSeenAt = Date.now();

    // ── SM-2: chất lượng hồi tưởng 0..5 ──
    let q;
    if (!a.correct) q = a.careless ? 2 : 1;
    else if ((a.hintsUsed || 0) === 0) q = 5;
    else if (a.hintsUsed === 1) q = 4;
    else q = 3;

    if (q < 3) {
      r.reps = 0;
      r.intervalDays = 1;
    } else {
      r.reps++;
      if (r.reps === 1) r.intervalDays = 1;
      else if (r.reps === 2) r.intervalDays = 6;
      else r.intervalDays = Math.round(r.intervalDays * r.ease);
      r.ease = round(Math.max(SM2_MIN_EASE, r.ease + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))), 3);
    }
    r.nextDueAt = Date.now() + r.intervalDays * 86400000;

    r.history.push({ at: r.lastSeenAt, correct: !!a.correct, stars: a.stars, p: r.p, q });
    if (r.history.length > 200) r.history.shift();

    return {
      ok: true,
      formCode: a.formCode,
      p: r.p,
      delta: round(r.p - prior, 4),
      mastered: r.p >= MASTERY_THRESHOLD,
      streak: r.streak,
      nextDueAt: r.nextDueAt,
      intervalDays: r.intervalDays,
      ease: r.ease,
    };
  }

  get(userId, formCode) { return this._user(userId).get(formCode) || null; }

  /** Bản đồ mức thạo toàn bộ, dùng cho standards.evaluate(). */
  map(userId) {
    const out = {};
    for (const [code, r] of this._user(userId)) out[code] = r.p;
    return out;
  }

  /** Các dạng tới hạn ôn theo SM-2. */
  due(userId, { limit = 20, now = Date.now() } = {}) {
    return [...this._user(userId).values()]
      .filter((r) => r.nextDueAt <= now && r.attempts > 0)
      .sort((a, b) => a.nextDueAt - b.nextDueAt)
      .slice(0, limit)
      .map((r) => ({ formCode: r.formCode, p: r.p, overdueDays: round((now - r.nextDueAt) / 86400000, 1) }));
  }

  /**
   * Vùng phát triển gần: dạng đang ở giữa "chưa biết" và "đã thạo".
   * Đây là nơi việc luyện tập có hiệu quả cao nhất.
   */
  zpd(userId, { lo = 0.30, hi = 0.85, limit = 10 } = {}) {
    return [...this._user(userId).values()]
      .filter((r) => r.p >= lo && r.p < hi)
      .sort((a, b) => b.p - a.p)
      .slice(0, limit)
      .map((r) => ({ formCode: r.formCode, p: r.p, attempts: r.attempts }));
  }

  weakest(userId, limit = 10) {
    return [...this._user(userId).values()]
      .filter((r) => r.attempts >= 3)
      .sort((a, b) => a.p - b.p)
      .slice(0, limit)
      .map((r) => ({
        formCode: r.formCode,
        formName: FORM_INDEX.get(r.formCode)?.name,
        p: r.p,
        attempts: r.attempts,
        accuracy: round(r.correct / r.attempts, 3),
      }));
  }

  summary(userId) {
    const recs = [...this._user(userId).values()];
    const mastered = recs.filter((r) => r.p >= MASTERY_THRESHOLD);
    return {
      formsTouched: recs.length,
      formsMastered: mastered.length,
      avgMastery: recs.length ? round(recs.reduce((s, r) => s + r.p, 0) / recs.length, 4) : 0,
      totalAttempts: recs.reduce((s, r) => s + r.attempts, 0),
      dueNow: this.due(userId, { limit: 999 }).length,
      threshold: MASTERY_THRESHOLD,
    };
  }

  status() {
    return { users: this.state.size, threshold: MASTERY_THRESHOLD, model: 'BKT + SM-2' };
  }
}

module.exports = Mastery;
module.exports.MASTERY_THRESHOLD = MASTERY_THRESHOLD;
module.exports.BKT_DEFAULT = BKT_DEFAULT;
