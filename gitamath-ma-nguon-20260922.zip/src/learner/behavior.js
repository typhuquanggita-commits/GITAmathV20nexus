'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  PHÂN TÍCH HÀNH VI SÂU
 * ═══════════════════════════════════════════════════════════════════════════
 *  Telemetry ghi lại từng thao tác. Lớp này ĐỌC chuỗi thao tác đó theo thời
 *  gian để trả lời những câu mà một con số trung bình không trả lời được:
 *
 *   · Em này đang đoán mò hay thật sự biết làm?
 *   · Làm được bao lâu thì đuối? (ngưỡng chú ý)
 *   · Có dấu hiệu chép đáp án từ đâu đó không?
 *   · Học lúc nào thì hiệu quả nhất?
 *   · Đang tiến lên hay đang tụt?
 *
 *  Nguyên tắc: mỗi kết luận phải kèm BẰNG CHỨNG đếm được và MỨC TIN CẬY.
 *  Không đủ dữ liệu thì nói là chưa đủ, không suy diễn.
 *
 *  Về cảnh báo gian lận: hệ thống KHÔNG kết tội. Nó chỉ nêu dấu hiệu bất
 *  thường kèm số liệu để giáo viên tự xem — quyết định là của con người.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { round, clamp, percentile } = require('../utils');
const { FORM_INDEX } = require('../curriculum/hierarchy');

const MIN_SAMPLES = 12;
const GUESS_FAST_RATIO = 0.3;      // dưới 30% thời gian chuẩn là quá nhanh
const SUSPICIOUS_RATIO = 0.15;     // dưới 15% mà lại đúng bài khó thì đáng xem lại
const FATIGUE_WINDOW = 5;          // so 5 bài đầu với 5 bài cuối phiên

class BehaviorAnalyzer {
  constructor({ telemetry, mastery = null, bank = null }) {
    this.telemetry = telemetry;
    this.mastery = mastery;
    this.bank = bank;
  }

  _attempts(userId) {
    return (this.telemetry.attemptsOf(userId) || []).slice().sort((a, b) => (a.at || 0) - (b.at || 0));
  }

  // ── 1. Đoán mò ───────────────────────────────────────────────────────────

  /**
   * Đoán mò = làm rất nhanh, tỉ lệ đúng không khác gì may rủi, và không
   * có dấu hiệu suy nghĩ (không dùng gợi ý, không sửa lại).
   */
  guessing(userId) {
    const at = this._attempts(userId);
    if (at.length < MIN_SAMPLES) {
      return { ok: true, enough: false, samples: at.length, need: MIN_SAMPLES, verdict: 'CHƯA ĐỦ DỮ LIỆU' };
    }
    const fast = at.filter((a) => a.speedRatio != null && a.speedRatio < GUESS_FAST_RATIO);
    const fastCorrect = fast.filter((a) => a.correct).length;
    const slow = at.filter((a) => a.speedRatio != null && a.speedRatio >= GUESS_FAST_RATIO);
    const slowAcc = slow.length ? slow.filter((a) => a.correct).length / slow.length : null;
    const fastAcc = fast.length ? fastCorrect / fast.length : null;

    const fastShare = round(fast.length / at.length, 3);
    // Dấu hiệu: làm nhanh nhiều, mà làm nhanh lại kém hẳn so với làm chậm.
    const gap = (slowAcc != null && fastAcc != null) ? round(slowAcc - fastAcc, 3) : null;
    const flagged = fastShare >= 0.3 && gap != null && gap >= 0.2;

    return {
      ok: true, enough: true,
      samples: at.length,
      fastShare,
      fastAccuracy: fastAcc == null ? null : round(fastAcc, 3),
      slowAccuracy: slowAcc == null ? null : round(slowAcc, 3),
      accuracyGap: gap,
      verdict: flagged ? 'CÓ DẤU HIỆU ĐOÁN MÒ' : 'KHÔNG THẤY DẤU HIỆU ĐOÁN MÒ',
      confidence: at.length >= 30 ? 'cao' : 'vừa',
      evidence: flagged
        ? `${Math.round(fastShare * 100)}% số bài làm dưới ${GUESS_FAST_RATIO * 100}% thời gian chuẩn; `
          + `những bài đó chỉ đúng ${Math.round((fastAcc || 0) * 100)}% trong khi bài làm kỹ đúng ${Math.round((slowAcc || 0) * 100)}%.`
        : `Tốc độ làm bài và tỉ lệ đúng không cho thấy khác biệt bất thường.`,
      advice: flagged
        ? ['Bắt buộc nhập ít nhất một bước lập luận trước khi nộp.',
          'Khoá nút nộp trong 30 giây đầu với bài từ 3★ trở lên.',
          'Giao bài tự luận ngắn thay cho trắc nghiệm trong 1 tuần.']
        : [],
    };
  }

  // ── 2. Ngưỡng chú ý ──────────────────────────────────────────────────────

  /**
   * Làm tốt được bao lâu thì bắt đầu đuối. Dùng để đặt độ dài buổi học.
   */
  attentionSpan(userId) {
    const sessions = this.telemetry.sessionsOf(userId) || [];
    const at = this._attempts(userId);
    if (at.length < MIN_SAMPLES) {
      return { ok: true, enough: false, samples: at.length, need: MIN_SAMPLES, verdict: 'CHƯA ĐỦ DỮ LIỆU' };
    }

    // Nhóm bài theo phiên bằng khoảng cách thời gian (>20 phút coi là phiên mới).
    const groups = [];
    let cur = [];
    for (let i = 0; i < at.length; i++) {
      if (i > 0 && (at[i].at - at[i - 1].at) > 20 * 60_000) { if (cur.length) groups.push(cur); cur = []; }
      cur.push(at[i]);
    }
    if (cur.length) groups.push(cur);

    const usable = groups.filter((g) => g.length >= FATIGUE_WINDOW * 2);
    if (!usable.length) {
      return {
        ok: true, enough: false, sessionsAnalyzed: 0, groups: groups.length,
        verdict: 'CHƯA ĐỦ PHIÊN DÀI ĐỂ ĐO',
        hint: `Cần ít nhất một phiên từ ${FATIGUE_WINDOW * 2} bài trở lên.`,
      };
    }

    let firstAcc = 0, lastAcc = 0, firstSpeed = 0, lastSpeed = 0, dropPoints = [];
    for (const g of usable) {
      const head = g.slice(0, FATIGUE_WINDOW);
      const tail = g.slice(-FATIGUE_WINDOW);
      firstAcc += head.filter((a) => a.correct).length / head.length;
      lastAcc += tail.filter((a) => a.correct).length / tail.length;
      const hs = head.map((a) => a.speedRatio).filter((x) => x != null);
      const ts = tail.map((a) => a.speedRatio).filter((x) => x != null);
      if (hs.length) firstSpeed += hs.reduce((s, x) => s + x, 0) / hs.length;
      if (ts.length) lastSpeed += ts.reduce((s, x) => s + x, 0) / ts.length;

      // Điểm gãy: bài đầu tiên mà từ đó trở đi sai nhiều hơn đúng.
      for (let i = FATIGUE_WINDOW; i < g.length; i++) {
        const w = g.slice(i - FATIGUE_WINDOW + 1, i + 1);
        if (w.filter((a) => !a.correct).length > w.length / 2) { dropPoints.push(i + 1); break; }
      }
    }
    const n = usable.length;
    const accDrop = round(firstAcc / n - lastAcc / n, 3);
    const slowdown = round(lastSpeed / n - firstSpeed / n, 3);
    const median = dropPoints.length ? Math.round(percentile(dropPoints, 50)) : null;

    return {
      ok: true, enough: true,
      sessionsAnalyzed: n,
      accuracyStart: round(firstAcc / n, 3),
      accuracyEnd: round(lastAcc / n, 3),
      accuracyDrop: accDrop,
      slowdown,
      dropAtItem: median,
      verdict: accDrop >= 0.2 ? 'ĐUỐI RÕ VỀ CUỐI BUỔI' : accDrop >= 0.1 ? 'HƠI ĐUỐI VỀ CUỐI' : 'GIỮ ĐƯỢC PHONG ĐỘ',
      recommendedSessionItems: median ? clamp(median - 1, 5, 25) : (accDrop >= 0.2 ? 8 : 12),
      evidence: `${FATIGUE_WINDOW} bài đầu đúng ${Math.round((firstAcc / n) * 100)}%, `
        + `${FATIGUE_WINDOW} bài cuối đúng ${Math.round((lastAcc / n) * 100)}%`
        + (median ? `; thường bắt đầu sa sút từ bài thứ ${median}.` : '.'),
      advice: accDrop >= 0.2
        ? [`Rút buổi học còn khoảng ${median ? median - 1 : 8} bài.`,
          'Chen nghỉ 3 phút giữa buổi.',
          'Xếp bài khó vào nửa đầu buổi, bài ôn vào nửa sau.']
        : [],
    };
  }

  // ── 3. Dấu hiệu bất thường (KHÔNG kết tội) ───────────────────────────────

  /**
   * Nêu dấu hiệu đáng xem lại. Chỉ nêu dấu hiệu, kèm số liệu.
   * Người quyết định là giáo viên, không phải hệ thống.
   */
  anomalies(userId) {
    const at = this._attempts(userId);
    const flags = [];
    if (at.length < MIN_SAMPLES) {
      return { ok: true, enough: false, samples: at.length, need: MIN_SAMPLES, flags, verdict: 'CHƯA ĐỦ DỮ LIỆU' };
    }

    // a) Đúng bài khó với thời gian phi thực tế
    const impossible = at.filter((a) => a.correct && a.speedRatio != null && a.speedRatio < SUSPICIOUS_RATIO && (a.stars || 1) >= 4);
    if (impossible.length >= 3) {
      flags.push({
        kind: 'TỐC_ĐỘ_PHI_THỰC_TẾ',
        count: impossible.length,
        detail: `${impossible.length} bài từ 4★ làm đúng trong dưới ${SUSPICIOUS_RATIO * 100}% thời gian chuẩn.`,
        note: 'Có thể em đã gặp đúng bài này trước đó, hoặc có nguồn đáp án. Cần hỏi trực tiếp, không kết luận qua số liệu.',
      });
    }

    // b) Nhảy vọt đột ngột không qua quá trình
    if (this.mastery) {
      const byForm = new Map();
      for (const a of at) {
        const arr = byForm.get(a.formCode) || [];
        arr.push(a);
        byForm.set(a.formCode, arr);
      }
      for (const [code, arr] of byForm) {
        if (arr.length < 8) continue;
        const firstHalf = arr.slice(0, Math.floor(arr.length / 2));
        const secondHalf = arr.slice(Math.floor(arr.length / 2));
        const a1 = firstHalf.filter((x) => x.correct).length / firstHalf.length;
        const a2 = secondHalf.filter((x) => x.correct).length / secondHalf.length;
        const fastSecond = secondHalf.filter((x) => x.speedRatio != null && x.speedRatio < GUESS_FAST_RATIO).length / secondHalf.length;
        if (a1 < 0.3 && a2 > 0.9 && fastSecond > 0.5) {
          flags.push({
            kind: 'NHẢY_VỌT_BẤT_THƯỜNG',
            formCode: code,
            formName: FORM_INDEX.get(code)?.name,
            detail: `Dạng này từ đúng ${Math.round(a1 * 100)}% vọt lên ${Math.round(a2 * 100)}%, `
              + `đồng thời tốc độ làm nhanh bất thường.`,
            note: 'Tiến bộ thật thường đi kèm thời gian làm bài ổn định hoặc tăng, không giảm đột ngột.',
          });
        }
      }
    }

    // c) Làm bài vào khung giờ bất thường kéo dài
    const sessions = this.telemetry.sessionsOf(userId) || [];
    const late = sessions.filter((s) => {
      const h = new Date(s.start || s.startedAt || 0).getHours();
      return h >= 23 || h < 5;
    });
    if (sessions.length >= 5 && late.length / sessions.length > 0.5) {
      flags.push({
        kind: 'HỌC_KHUYA_KÉO_DÀI',
        count: late.length,
        detail: `${late.length}/${sessions.length} buổi học diễn ra sau 23 giờ.`,
        note: 'Không phải vấn đề học thuật nhưng ảnh hưởng trực tiếp tới kết quả. Nên báo phụ huynh.',
      });
    }

    return {
      ok: true, enough: true, samples: at.length, flags,
      verdict: flags.length ? 'CÓ DẤU HIỆU CẦN XEM LẠI' : 'KHÔNG THẤY BẤT THƯỜNG',
      disclaimer: 'Đây là DẤU HIỆU, không phải kết luận. Hệ thống không kết tội học viên.',
    };
  }

  // ── 4. Nhịp học và khung giờ hiệu quả ────────────────────────────────────

  rhythm(userId) {
    const at = this._attempts(userId);
    if (at.length < MIN_SAMPLES) return { ok: true, enough: false, samples: at.length, need: MIN_SAMPLES };

    const byHour = new Map();
    const byWeekday = new Map();
    for (const a of at) {
      if (!a.at) continue;
      const d = new Date(a.at);
      const h = d.getHours();
      const w = d.getDay();
      const hb = byHour.get(h) || { n: 0, ok: 0 };
      hb.n++; if (a.correct) hb.ok++;
      byHour.set(h, hb);
      const wb = byWeekday.get(w) || { n: 0, ok: 0 };
      wb.n++; if (a.correct) wb.ok++;
      byWeekday.set(w, wb);
    }
    const hours = [...byHour.entries()]
      .filter(([, v]) => v.n >= 3)
      .map(([h, v]) => ({ hour: h, items: v.n, accuracy: round(v.ok / v.n, 3) }))
      .sort((a, b) => b.accuracy - a.accuracy);
    const WD = ['Chủ nhật', 'Thứ hai', 'Thứ ba', 'Thứ tư', 'Thứ năm', 'Thứ sáu', 'Thứ bảy'];
    const weekdays = [...byWeekday.entries()]
      .filter(([, v]) => v.n >= 3)
      .map(([w, v]) => ({ weekday: WD[w], items: v.n, accuracy: round(v.ok / v.n, 3) }))
      .sort((a, b) => b.accuracy - a.accuracy);

    const gapDays = [];
    for (let i = 1; i < at.length; i++) {
      const d = (at[i].at - at[i - 1].at) / 86400000;
      if (d >= 1) gapDays.push(round(d, 1));
    }
    const medianGap = gapDays.length ? round(percentile(gapDays, 50), 1) : null;

    return {
      ok: true, enough: true,
      bestHours: hours.slice(0, 3),
      worstHours: hours.slice(-2).reverse(),
      bestWeekdays: weekdays.slice(0, 3),
      medianGapDays: medianGap,
      consistency: medianGap == null ? null : medianGap <= 1.5 ? 'đều' : medianGap <= 4 ? 'thất thường' : 'gián đoạn dài',
      advice: medianGap != null && medianGap > 4
        ? ['Khoảng cách giữa các buổi quá xa, kiến thức rơi trước khi kịp củng cố. Nên học ngắn nhưng đều.']
        : [],
    };
  }

  // ── 5. Xu hướng: đang lên hay đang xuống ─────────────────────────────────

  trend(userId, { window = 20 } = {}) {
    const at = this._attempts(userId);
    if (at.length < window) return { ok: true, enough: false, samples: at.length, need: window };
    const recent = at.slice(-window);
    const prior = at.slice(-window * 2, -window);
    const acc = (arr) => (arr.length ? arr.filter((a) => a.correct).length / arr.length : null);
    const a2 = acc(recent);
    const a1 = acc(prior);

    // Hồi quy tuyến tính đơn trên cửa sổ gần nhất để thấy hướng đi.
    const n = recent.length;
    const xs = recent.map((_, i) => i);
    const ys = recent.map((a) => (a.correct ? 1 : 0));
    const mx = xs.reduce((s, x) => s + x, 0) / n;
    const my = ys.reduce((s, y) => s + y, 0) / n;
    const num = xs.reduce((s, x, i) => s + (x - mx) * (ys[i] - my), 0);
    const den = xs.reduce((s, x) => s + (x - mx) ** 2, 0) || 1;
    const slope = num / den;

    const delta = a1 == null ? null : round(a2 - a1, 3);
    // Hướng đi lấy từ HAI tín hiệu: chênh lệch giữa hai cửa sổ (mạnh hơn) và
    // độ dốc bên trong cửa sổ gần nhất. Chỉ nhìn độ dốc thì một cửa sổ toàn
    // đúng sẽ ra "đi ngang" dù vừa nhảy vọt từ 0% — đó là đọc sai dữ liệu.
    const signal = round((delta ?? 0) + slope * n, 3);
    const dir = signal > 0.05 ? 'ĐANG LÊN' : signal < -0.05 ? 'ĐANG XUỐNG' : 'ĐI NGANG';

    return {
      ok: true, enough: true,
      window,
      recentAccuracy: round(a2, 3),
      priorAccuracy: a1 == null ? null : round(a1, 3),
      delta,
      slopePerItem: round(slope, 4),
      signal,
      direction: dir,
      evidence: a1 == null
        ? `Độ chính xác ${window} bài gần nhất là ${Math.round(a2 * 100)}%.`
        : `${window} bài gần nhất đúng ${Math.round(a2 * 100)}%, ${window} bài trước đó đúng ${Math.round(a1 * 100)}%.`,
      advice: dir === 'ĐANG XUỐNG'
        ? ['Dừng đẩy độ khó. Quay lại củng cố dạng nền cho tới khi độ chính xác về ≥ 75%.']
        : dir === 'ĐANG LÊN' ? ['Có thể tăng độ khó một bậc.'] : [],
    };
  }

  // ── Tổng hợp ─────────────────────────────────────────────────────────────

  /** Một bản đọc đầy đủ về hành vi học của một học viên. */
  fullReport(userId) {
    const base = this.telemetry.behaviors(userId);
    const guessing = this.guessing(userId);
    const attention = this.attentionSpan(userId);
    const anomalies = this.anomalies(userId);
    const rhythm = this.rhythm(userId);
    const trend = this.trend(userId);
    const misconceptions = this.telemetry.topMisconceptions(userId, 8);

    const actions = [];
    for (const src of [guessing, attention, rhythm, trend]) {
      for (const a of src.advice || []) actions.push(a);
    }
    for (const b of base.behaviors) actions.push(b.advice);

    return {
      ok: true,
      learnerId: userId,
      samples: base.metrics.items,
      enoughData: base.metrics.items >= MIN_SAMPLES,
      patterns: base.behaviors,
      metrics: base.metrics,
      guessing,
      attentionSpan: attention,
      anomalies,
      rhythm,
      trend,
      misconceptions,
      actions: [...new Set(actions)],
      summary: this._summary(userId, base, guessing, attention, trend, anomalies),
    };
  }

  _summary(userId, base, guessing, attention, trend, anomalies) {
    if (base.metrics.items < MIN_SAMPLES) {
      return `Mới có ${base.metrics.items}/${MIN_SAMPLES} lượt làm bài — chưa đủ để nhận định gì chắc chắn.`;
    }
    const parts = [];
    parts.push(trend.enough ? `Xu hướng: ${trend.direction.toLowerCase()} (${trend.evidence})` : 'Chưa đủ dữ liệu để nói xu hướng.');
    if (guessing.enough && guessing.verdict.includes('CÓ')) parts.push(`Có dấu hiệu đoán mò: ${guessing.evidence}`);
    if (attention.enough && attention.accuracyDrop >= 0.15) {
      parts.push(`Đuối về cuối buổi: ${attention.evidence} Nên rút buổi còn ~${attention.recommendedSessionItems} bài.`);
    }
    if (base.behaviors.length) parts.push(`Mẫu hành vi nổi bật: ${base.behaviors.map((b) => b.name).join('; ')}.`);
    if (anomalies.flags?.length) parts.push(`${anomalies.flags.length} dấu hiệu cần giáo viên xem lại.`);
    return parts.join(' ');
  }

  status() {
    return { minSamples: MIN_SAMPLES, guessFastRatio: GUESS_FAST_RATIO, fatigueWindow: FATIGUE_WINDOW };
  }
}

module.exports = BehaviorAnalyzer;
module.exports.MIN_SAMPLES = MIN_SAMPLES;
module.exports.GUESS_FAST_RATIO = GUESS_FAST_RATIO;
