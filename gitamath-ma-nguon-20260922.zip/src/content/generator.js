'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BỘ BIÊN SOẠN CÓ RÀNG BUỘC
 * ═══════════════════════════════════════════════════════════════════════════
 *  Quy tắc cứng, để không trượt thành "ghép số ngẫu nhiên":
 *
 *   1. DÙNG HẾT Ý ĐỒ TRƯỚC, MỚI ĐẾN THAM SỐ.
 *      Bộ sinh xoay vòng qua tất cả bản thiết kế của dạng. Chỉ khi đã dùng
 *      hết mọi ý đồ sư phạm mới quay lại bản đầu với bộ tham số khác.
 *
 *   2. THAM SỐ PHẢI QUA RÀNG BUỘC TOÁN HỌC.
 *      Không có "random(1,10)". Không gian tham số là danh sách sinh ra bởi
 *      điều kiện toán (∆ chính phương, ƯCLN = 1, số không chính phương…).
 *
 *   3. MÁY TỰ GIẢI LẠI TRƯỚC KHI NHẬN.
 *      Mọi bài đều đi qua MathVerifier. Sai là loại, không ai duyệt tay bù.
 *
 *   4. CHỐNG TRÙNG BA LỚP CHẶN Ở CỬA.
 *      Kể cả khi lặp bản thiết kế, hạn mức khung bài chỉ cho tối đa 3 bài
 *      cùng khung — nên không thể in hàng loạt.
 *
 *   5. TẤT ĐỊNH.
 *      Cùng seed cho cùng bộ bài, từng chữ một. Dựng lại kho được.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { seededRandom, round, fnv1a } = require('../utils');
const { FORM_INDEX } = require('../curriculum/hierarchy');
const { BLUEPRINTS, blueprintsForForm } = require('./blueprint');
const quality = require('./quality');
const MathVerifier = require('../math/verifier');

const MAX_SCAN = 4000;   // trần duyệt không gian tham số cho mỗi bản thiết kế

class ItemGenerator {
  /**
   * @param {object} o
   * @param {import('./item-bank')} o.bank
   * @param {MathVerifier} o.verifier
   */
  constructor({ bank, verifier = null, audit = null } = {}) {
    this.bank = bank;
    this.verifier = verifier || new MathVerifier();
    this.audit = audit;
    this.cursors = new Map();   // blueprintId -> vị trí đã duyệt tới trong không gian tham số
    this.sizes = new Map();     // blueprintId -> số bộ tham số hợp lệ (đếm một lần rồi nhớ)
    this.stats = {
      attempted: 0, accepted: 0,
      rejectedMath: 0, rejectedDuplicate: 0, rejectedQuality: 0, rejectedBank: 0,
      blueprintsUsed: new Set(),
    };
  }

  /** Vị trí bắt đầu trong không gian tham số — tất định theo seed, không phải ngẫu nhiên. */
  _startOffset(blueprintId, seed) {
    return fnv1a(`${blueprintId}|${seed}`) % 997;
  }

  /**
   * Lấy ứng viên thứ k của một bản thiết kế, đi tuần tự qua không gian tham số.
   * Không gian là generator nên duyệt lười, không dựng mảng khổng lồ trong bộ nhớ.
   */
  _candidate(bp, index) {
    let i = 0;
    for (const params of bp.space()) {
      if (i === index) return params;
      i++;
      if (i > MAX_SCAN) break;
    }
    return null;   // đã đi hết không gian
  }

  _spaceSize(bp) {
    if (this.sizes.has(bp.id)) return this.sizes.get(bp.id);
    let n = 0;
    for (const _ of bp.space()) { n++; if (n >= MAX_SCAN) break; }
    this.sizes.set(bp.id, n);
    return n;
  }

  /**
   * Biên soạn một lô bài.
   * @param {object} o
   * @param {string}  o.formCode
   * @param {number}  o.level
   * @param {number}  o.count
   * @param {number}  [o.stars]   lọc theo bậc sao; bỏ trống = mọi bậc hợp tầng
   * @param {string}  o.seed
   * @param {string}  o.authorId
   * @param {boolean} o.dryRun    chỉ soạn và soát, không ghi vào kho
   */
  generate({ formCode, level, count = 5, stars = null, seed = 'gita-v20', authorId = 'GEN', dryRun = false } = {}) {
    const form = FORM_INDEX.get(formCode);
    if (!form) return { ok: false, error: 'UNKNOWN_FORM', formCode };
    if (level < form.levelRange[0] || level > form.levelRange[1]) {
      return { ok: false, error: 'LEVEL_OUT_OF_RANGE', level, allowed: form.levelRange };
    }

    const pool = blueprintsForForm(formCode)
      .filter((b) => level >= b.levels[0] && level <= b.levels[1])
      .filter((b) => stars == null || b.stars === stars)
      .sort((a, b) => a.id.localeCompare(b.id));      // thứ tự tất định

    if (!pool.length) {
      return {
        ok: false, error: 'NO_BLUEPRINT',
        hint: `Chưa có bản thiết kế nào cho ${formCode} ở tầng ${level}${stars ? ` bậc ${stars}★` : ''}. `
          + `Phải biên soạn thêm bản thiết kế, KHÔNG được sinh bừa.`,
        available: blueprintsForForm(formCode).map((b) => ({ id: b.id, levels: b.levels, stars: b.stars })),
      };
    }

    const produced = [];
    const rejected = [];
    const perBlueprint = new Map(pool.map((b) => [b.id, 0]));
    let round1 = 0;                                    // số vòng đã xoay qua toàn bộ bản thiết kế
    let guard = 0;

    // Xoay vòng: bản 1, bản 2, …, bản n, rồi mới quay lại bản 1.
    while (produced.length < count && guard < count * pool.length * 12) {
      const bp = pool[guard % pool.length];
      if (guard > 0 && guard % pool.length === 0) round1++;
      guard++;

      const used = perBlueprint.get(bp.id);
      const size = this._spaceSize(bp);
      perBlueprint.set(bp.id, used + 1);
      if (size === 0) {
        rejected.push({ blueprint: bp.id, reason: 'không gian tham số rỗng — bản thiết kế có ràng buộc quá chặt' });
        continue;
      }
      if (used >= size) {
        rejected.push({ blueprint: bp.id, reason: `đã dùng hết ${size} bộ tham số hợp lệ của bản thiết kế này` });
        continue;
      }
      // Điểm xuất phát do seed quyết định, nhưng luôn nằm TRONG không gian thật.
      const offset = this._startOffset(bp.id, seed) % size;
      const params = this._candidate(bp, (offset + used) % size);
      if (!params) {
        rejected.push({ blueprint: bp.id, reason: 'không lấy được bộ tham số' });
        continue;
      }

      this.stats.attempted++;
      const drawn = bp.render(params);
      const item = {
        formCode,
        level,
        stars: bp.stars,
        stem: drawn.stem,
        solutionSteps: drawn.solutionSteps,
        hints: drawn.hints,
        traps: [bp.targetTrap],
        answer: drawn.answer,
        check: drawn.check,
        blueprintId: bp.id,
        intent: bp.intent,
        context: bp.context,
        // Bản thiết kế phục vụ cả một dải tầng: bài soạn ở tầng 4 vẫn dùng được
        // cho tầng 5, 6 nếu bản thiết kế khai báo như vậy. Đây là thuộc tính của
        // BÀI, không phải của lần sinh — nên phải đi theo bài vào kho.
        servesLevels: [bp.levels[0], bp.levels[1]],
        params,
        authorId,
        source: 'generator',
      };

      // ── Chốt 1: máy tự giải lại ──
      const verdict = this.verifier.verifyItem(item);
      if (!verdict.verified) {
        this.stats.rejectedMath++;
        rejected.push({ blueprint: bp.id, params, reason: `máy kiểm toán học không đạt: ${verdict.reason}` });
        continue;
      }

      // ── Chốt 2: chất lượng tối thiểu do máy chấm ──
      const q = quality.score(item, { correctness: 5 });   // đúng toán đã được chốt 1 xác nhận
      if (q.blockers.length) {
        this.stats.rejectedQuality++;
        rejected.push({
          blueprint: bp.id, params,
          reason: `chưa đạt chuẩn xuất bản: ${q.blockers.map((b) => `${b.name} ${b.got}/${b.required}`).join(', ')}`,
        });
        continue;
      }

      // ── Chốt 3: chống trùng ba lớp, ngay tại cửa kho ──
      if (!dryRun && this.bank) {
        const r = this.bank.draft(item);
        if (!r.ok) {
          if (r.error === 'DUPLICATE') { this.stats.rejectedDuplicate++; rejected.push({ blueprint: bp.id, params, reason: `trùng: ${r.reason} (${r.conflictWith})` }); }
          else { this.stats.rejectedBank++; rejected.push({ blueprint: bp.id, params, reason: `${r.error}${r.reason ? ` — ${r.reason}` : ''}` }); }
          continue;
        }
        // match = kết luận của bộ kiểm tra toán học, không phải lời tự nhận của bộ sinh.
        this.bank.markVerified(r.item.id, {
          verifierId: 'MATH-ENGINE', machine: true,
          match: verdict.verified === true,
          checks: verdict.checks,
          reason: verdict.reason,
        }, 'MATH-ENGINE');
        // Giữ lại xuất xứ biên soạn (bản thiết kế, ý đồ, tham số) bên cạnh bản ghi kho.
        produced.push({ ...item, ...r.item, quality: q, verification: verdict });
      } else {
        produced.push({ ...item, id: `DRY-${produced.length + 1}`, quality: q, verification: verdict });
      }
      this.stats.accepted++;
      this.stats.blueprintsUsed.add(bp.id);
    }

    const byBlueprint = {};
    for (const p of produced) byBlueprint[p.blueprintId] = (byBlueprint[p.blueprintId] || 0) + 1;

    return {
      ok: true,
      formCode,
      level,
      requested: count,
      produced: produced.length,
      rejected: rejected.length,
      dryRun,
      blueprintsAvailable: pool.length,
      blueprintsUsed: Object.keys(byBlueprint).length,
      byBlueprint,
      intents: [...new Set(produced.map((p) => p.intent))],
      items: produced,
      rejections: rejected.slice(0, 20),
      note: produced.length < count
        ? `Chỉ soạn được ${produced.length}/${count} bài. Muốn thêm thì phải có thêm BẢN THIẾT KẾ mới, `
          + `không phải nới lỏng chống trùng.`
        : `Đủ ${produced.length} bài, dùng ${Object.keys(byBlueprint).length}/${pool.length} ý đồ sư phạm khác nhau.`,
    };
  }

  /** Soạn phủ một tầng: đi qua mọi dạng có bản thiết kế ở tầng đó. */
  generateForLevel({ level, perForm = 3, seed = 'gita-v20', authorId = 'GEN', dryRun = false } = {}) {
    const forms = [...new Set(BLUEPRINTS
      .filter((b) => level >= b.levels[0] && level <= b.levels[1])
      .map((b) => b.formCode))].sort();
    const results = [];
    for (const f of forms) {
      results.push(this.generate({ formCode: f, level, count: perForm, seed, authorId, dryRun }));
    }
    const produced = results.reduce((s, r) => s + (r.produced || 0), 0);
    return {
      ok: true, level, forms: forms.length, produced,
      requested: forms.length * perForm,
      coverage: forms.length ? round(produced / (forms.length * perForm), 3) : 0,
      byForm: Object.fromEntries(results.map((r) => [r.formCode, r.produced || 0])),
      details: results,
    };
  }

  status() {
    return {
      ...this.stats,
      blueprintsUsed: this.stats.blueprintsUsed.size,
      blueprintsTotal: BLUEPRINTS.length,
      acceptRate: this.stats.attempted ? round(this.stats.accepted / this.stats.attempted, 3) : 0,
      verifier: this.verifier.status(),
    };
  }
}

module.exports = ItemGenerator;
module.exports.MAX_SCAN = MAX_SCAN;
