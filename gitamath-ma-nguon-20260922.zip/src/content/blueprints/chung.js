'use strict';
/**
 * Tiện ích dùng chung cho các bản thiết kế bài.
 * Tách riêng để blueprint.js và các tệp bản thiết kế theo cấp học cùng dùng
 * được mà không require vòng tròn.
 */

const gcd = (a, b) => (b ? gcd(b, a % b) : Math.abs(a));
const abs = Math.abs;
const sgn = (n) => (n < 0 ? '-' : '+');

/** Viết hệ số trước ẩn cho gọn: 1x → x, −1x → −x. */
function coef(c, sym) {
  if (c === 0) return '';
  if (c === 1) return sym;
  if (c === -1) return `-${sym}`;
  return `${c}${sym}`;
}

/** Ghép hạng tử có dấu: "x^{2} - 5x + 6". */
function poly(terms) {
  let s = '';
  for (const [c, sym] of terms) {
    if (c === 0) continue;
    const body = sym ? coef(abs(c), sym) : String(abs(c));
    if (!s) s = (c < 0 ? '-' : '') + body;
    else s += ` ${sgn(c)} ${body}`;
  }
  return s || '0';
}

/** Phân số LaTeX, tự rút gọn; mẫu 1 thì trả về số nguyên. */
function frac(num, den) {
  if (den === 0) return '\\text{không xác định}';
  let n = num; let d = den;
  if (d < 0) { n = -n; d = -d; }
  const g = gcd(n, d) || 1;
  n /= g; d /= g;
  return d === 1 ? String(n) : `\\dfrac{${n}}{${d}}`;
}

/** Số thập phân viết theo lối Việt Nam: dấu phẩy ngăn phần thập phân. */
function thap(x, soLe = 2) {
  const v = Number(x);
  const s = Number.isInteger(v) ? String(v) : v.toFixed(soLe).replace(/0+$/, '').replace(/\.$/, '');
  return s.replace('.', '{,}');
}

/** Đọc số tự nhiên thành chữ — dùng cho bài đọc/viết số ở tiểu học. */
const HANG_DON = ['không', 'một', 'hai', 'ba', 'bốn', 'năm', 'sáu', 'bảy', 'tám', 'chín'];
function docSo(n) {
  const v = Math.trunc(n);
  if (v < 10) return HANG_DON[v];
  if (v < 20) {
    const dv = v - 10;
    if (dv === 0) return 'mười';
    if (dv === 5) return 'mười lăm';
    if (dv === 1) return 'mười một';
    return `mười ${HANG_DON[dv]}`;
  }
  if (v < 100) {
    const ch = Math.floor(v / 10);
    const dv = v % 10;
    let ra = `${HANG_DON[ch]} mươi`;
    if (dv === 1) ra += ' mốt';
    else if (dv === 5) ra += ' lăm';
    else if (dv === 4) ra += ' tư';
    else if (dv > 0) ra += ` ${HANG_DON[dv]}`;
    return ra;
  }
  if (v < 1000) {
    const tr = Math.floor(v / 100);
    const con = v % 100;
    if (con === 0) return `${HANG_DON[tr]} trăm`;
    if (con < 10) return `${HANG_DON[tr]} trăm lẻ ${HANG_DON[con]}`;
    return `${HANG_DON[tr]} trăm ${docSo(con)}`;
  }
  // Từ nghìn trở lên: đọc theo lớp.
  const lop = [];
  let con = v;
  while (con > 0) { lop.unshift(con % 1000); con = Math.floor(con / 1000); }
  const ten = ['', ' nghìn', ' triệu', ' tỉ'];
  return lop.map((x, i) => {
    const bac = lop.length - 1 - i;
    if (x === 0) return '';
    const doc = bac > 0 && i > 0 ? docBaChuSo(x) : docSo(x);
    return `${doc}${ten[bac] || ''}`;
  }).filter(Boolean).join(' ').trim();
}
function docBaChuSo(x) {
  const tr = Math.floor(x / 100);
  const con = x % 100;
  if (con === 0) return `${HANG_DON[tr]} trăm`;
  if (con < 10) return `${HANG_DON[tr]} trăm lẻ ${HANG_DON[con]}`;
  return `${HANG_DON[tr]} trăm ${docSo(con)}`;
}

/** Giờ phút viết gọn: 7 giờ 45 phút. */
const gioPhut = (g, p) => (p === 0 ? `${g} giờ` : `${g} giờ ${p} phút`);

/** Bộ tên dùng trong đề toán có lời văn — cố định, lấy theo chỉ số. */
const TEN = ['An', 'Bình', 'Chi', 'Dũng', 'Hà', 'Khoa', 'Lan', 'Minh', 'Nam', 'Oanh', 'Phúc', 'Quyên'];
const DO_VAT = [
  { ten: 'quyển vở', dv: 'quyển' }, { ten: 'cái bút', dv: 'cái' },
  { ten: 'quả cam', dv: 'quả' }, { ten: 'viên bi', dv: 'viên' },
  { ten: 'bông hoa', dv: 'bông' }, { ten: 'chiếc kẹo', dv: 'chiếc' },
];

module.exports = { gcd, abs, sgn, coef, poly, frac, thap, docSo, gioPhut, TEN, DO_VAT };
