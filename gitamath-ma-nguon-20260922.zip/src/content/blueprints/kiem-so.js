'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  CÔNG CỤ DỰNG PHÉP KIỂM BẰNG SỐ
 * ═══════════════════════════════════════════════════════════════════════════
 *  Tách riêng khỏi tệp bản thiết kế vì cả THPT, bài nhận biết và bài thách
 *  thức đều cần, mà mỗi nơi giữ một bản sao thì sớm muộn cũng lệch nhau.
 *
 *  Bộ kiểm chứng của hệ thống chỉ biết TÍNH GIÁ TRỊ của biểu thức: nó không
 *  biết đạo hàm, không biết lấy nguyên hàm. Muốn máy kiểm được một bài giải
 *  tích, ta phải viết lại phép kiểm thành một biểu thức số học thuần tuý —
 *  đó là việc của các hàm dưới đây.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { gcd } = require('./chung');

/**
 * Dựng biểu thức Simpson ghép cho ∫ từ a đến b của f.
 * f nhận vào CHUỖI biểu thức của x và trả về CHUỖI — nhờ vậy cận được viết
 * dưới dạng phân số, không có sai số làm tròn khi dựng chuỗi.
 * n phải chẵn. Với đa thức bậc ≤ 3, kết quả chính xác tuyệt đối.
 */
function simpson(f, a, b, n = 2) {
  const diem = [];
  for (let i = 0; i <= n; i++) {
    const w = i === 0 || i === n ? 1 : (i % 2 ? 4 : 2);
    const x = `(${a} + ${i}*((${b}) - (${a}))/${n})`;
    diem.push(`${w}*(${f(x)})`);
  }
  return `((${b}) - (${a}))/(3*${n})*(${diem.join(' + ')})`;
}

/**
 * Dựng biểu thức cầu phương GAUSS–LEGENDRE 5 ĐIỂM cho ∫ từ a đến b của f.
 * Simpson chỉ chính xác với đa thức bậc ≤ 3; hàm mũ và lôgarit thì không.
 * Gauss–Legendre 5 điểm chính xác tuyệt đối tới bậc 9 và sai số với hàm trơn
 * nhỏ hơn ngưỡng so khớp của bộ kiểm chứng nhiều bậc. Chia thành `manh` đoạn
 * con thì sai số còn giảm theo luỹ thừa bậc mười của độ dài đoạn.
 * Nút và trọng số viết dưới dạng CĂN THỨC, không phải số thập phân làm tròn.
 */
const GL_NUT = ['0', '(1/3)*sqrt(5 - 2*sqrt(10/7))', '-(1/3)*sqrt(5 - 2*sqrt(10/7))', '(1/3)*sqrt(5 + 2*sqrt(10/7))', '-(1/3)*sqrt(5 + 2*sqrt(10/7))'];
const GL_TRONG = ['128/225', '(322 + 13*sqrt(70))/900', '(322 + 13*sqrt(70))/900', '(322 - 13*sqrt(70))/900', '(322 - 13*sqrt(70))/900'];

function gauss(f, a, b, manh = 2) {
  const doan = [];
  for (let k = 0; k < manh; k++) {
    const lo = `((${a}) + ${k}*((${b}) - (${a}))/${manh})`;
    const hi = `((${a}) + ${k + 1}*((${b}) - (${a}))/${manh})`;
    const giua = `((${lo}) + (${hi}))/2`;
    const nua = `((${hi}) - (${lo}))/2`;
    const tong = GL_NUT.map((x, i) => `(${GL_TRONG[i]})*(${f(`((${giua}) + (${nua})*(${x}))`)})`).join(' + ');
    doan.push(`(${nua})*(${tong})`);
  }
  return doan.join(' + ');
}

/** Rút gọn phân số thành chuỗi "p/q" hoặc "p" — dùng cho vế đối chiếu. */
function tiSo(p, q) {
  let n = p; let d = q;
  if (d < 0) { n = -n; d = -d; }
  const g = gcd(n, d) || 1;
  n /= g; d /= g;
  return d === 1 ? `${n}` : `${n}/${d}`;
}

const chinhPhuong = (n) => n >= 0 && Number.isInteger(Math.sqrt(n));

/** Các cặp cạnh góc vuông cho cạnh huyền nguyên — dùng nhiều ở hình học. */
function* capPytago(tran = 65) {
  for (let m = 2; m <= 8; m++) {
    for (let n = 1; n < m; n++) {
      if (gcd(m, n) !== 1 || (m - n) % 2 === 0) continue;
      const a = m * m - n * n; const b = 2 * m * n; const c = m * m + n * n;
      for (let k = 1; c * k <= tran; k++) { yield [a * k, b * k, c * k]; yield [b * k, a * k, c * k]; }
    }
  }
}


module.exports = { simpson, gauss, tiSo, chinhPhuong, capPytago, GL_NUT, GL_TRONG };
