'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN THIẾT KẾ BÀI — TIỂU HỌC (lớp 1 đến lớp 5)
 * ═══════════════════════════════════════════════════════════════════════════
 *  Mỗi bản nhằm vào ĐÚNG MỘT bẫy đã khai trong danh mục dạng bài, và không
 *  gian tham số được ràng buộc sao cho bài sinh ra thực sự chạm vào bẫy đó.
 *
 *  Ví dụ: bản M2.SO.DEM100.SOSANH chỉ sinh những cặp số mà hàng đơn vị nói
 *  NGƯỢC với hàng chục (47 và 52: đơn vị 7 > 2 nhưng 47 < 52). Học viên so
 *  sánh theo hàng đơn vị trước sẽ sai ngay, và đó chính là mục đích.
 *
 *  Lời văn viết theo đúng lối sách giáo khoa tiểu học: câu ngắn, từ quen
 *  thuộc, có đơn vị đo. Toàn bộ đi qua bộ soát tiếng Việt bốn cấp.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { frac, thap, docSo, gioPhut, TEN, DO_VAT, gcd } = require('./chung');

const BP_TIEU_HOC = [

  // ══ LỚP 1 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M1.DEM20.DOC',
    formCode: 'M1.SO.DEM20',
    intent: 'Đọc đúng số có hai chữ số trong phạm vi 20 — chặn thói quen đọc máy móc theo từng chữ số.',
    targetTrap: 'đọc "mười một" thành "một mươi một"',
    context: 'số học thuần',
    shape: { steps: 2, cases: 1 },
    stars: 1,
    levels: [0, 1],
    space: function* () {
      // Chỉ lấy các số mà cách đọc KHÁC hẳn cách ghép chữ số: 11..19 và 15.
      for (let n = 11; n <= 19; n++) yield { n };
    },
    render: ({ n }) => ({
      stem: `Viết cách đọc của số $${n}$.`,
      solutionSteps: [
          {
            viec: `Số $${n}$ gồm $1$ chục và $${n - 10}$ đơn vị.`,
            canCu: 'Số có hai chữ số gồm số chục và số đơn vị; đọc số phải theo cấu tạo đó.',
          },
          {
            viec: `Số có một chục đứng đầu thì đọc là "mười", không đọc là "một mươi".`,
            canCu: 'Một chục đứng đầu thì đọc là "mười", đây là quy ước riêng của tiếng Việt, không suy ra từ chữ số.',
          },
          {
            viec: `Vậy $${n}$ đọc là "${docSo(n)}".`,
            canCu: 'Ghép cách đọc của hàng chục với cách đọc của hàng đơn vị.',
          },
        ],
      hints: [
        'Số có đúng một chục thì phần chục đọc là "mười".',
        n % 10 === 5 ? 'Chữ số 5 ở hàng đơn vị sau "mười" đọc là "lăm".' : 'Đọc phần chục trước, phần đơn vị sau.',
      ],
      answer: docSo(n),
      check: { expression: `${n}`, equals: `10 + ${n - 10}` },
    }),
  },
  {
    id: 'BP.M1.DEM20.VIET',
    formCode: 'M1.SO.DEM20',
    intent: 'Viết số từ cách đọc — kiểm tra học viên đặt đúng chữ số hàng chục và hàng đơn vị.',
    targetTrap: 'viết ngược chữ số hàng chục',
    context: 'số học thuần',
    shape: { steps: 2, cases: 1 },
    stars: 1,
    levels: [0, 1],
    space: function* () {
      // Chọn số mà viết ngược lại vẫn là số hợp lệ trong phạm vi 20 hoặc gần đó:
      // đó là chỗ lỗi viết ngược dễ lọt mà không ai phát hiện.
      for (const n of [12, 13, 14, 15, 16, 17, 18, 19]) yield { n };
    },
    render: ({ n }) => ({
      stem: `Viết số có $1$ chục và $${n % 10}$ đơn vị.`,
      solutionSteps: [
          {
            viec: 'Chữ số hàng chục viết trước, chữ số hàng đơn vị viết sau.',
            canCu: 'Viết số thì chữ số hàng chục đứng trước, chữ số hàng đơn vị đứng sau — vị trí quyết định giá trị.',
          },
          {
            viec: `Hàng chục là $1$, hàng đơn vị là $${n % 10}$.`,
            canCu: 'Tách lời đọc thành phần chục và phần đơn vị để biết viết chữ số nào.',
          },
          {
            viec: `Vậy số đó là $${n}$, đọc là "${docSo(n)}".`,
            canCu: 'Ghép hai chữ số theo đúng thứ tự vừa xác định.',
          },
        ],
      hints: ['Hàng chục đứng bên trái, hàng đơn vị đứng bên phải.'],
      answer: `${n}`,
      check: { expression: `1*10 + ${n % 10}`, equals: `${n}` },
    }),
  },

  {
    id: 'BP.M1.HINH.DEM',
    formCode: 'M1.HINH.NHANDANG',
    intent: 'Phân biệt hình vuông với hình chữ nhật bằng SỐ ĐO cạnh, không bằng cảm nhận mắt.',
    targetTrap: 'gọi hình vuông là chữ nhật và ngược lại',
    context: 'hình học trực quan',
    shape: { steps: 2, cases: 2 },
    stars: 1,
    levels: [0, 1],
    space: function* () {
      for (let dai = 3; dai <= 8; dai++) {
        for (let rong = 3; rong <= dai; rong++) yield { dai, rong };
      }
    },
    render: ({ dai, rong }) => {
      const vuong = dai === rong;
      return {
        stem: `Một hình có bốn góc vuông. Chiều dài $${dai}$ cm, chiều rộng $${rong}$ cm. `
          + 'Hình đó là hình gì?',
        solutionSteps: [
          {
            viec: 'Hình có bốn góc vuông là hình chữ nhật.',
            canCu: 'Nhận dạng hình theo DẤU HIỆU của nó, không theo cảm giác nhìn.',
          },
          {
            viec: `So sánh hai cạnh: $${dai}$ cm và $${rong}$ cm — ${vuong ? 'hai cạnh bằng nhau' : 'hai cạnh khác nhau'}.`,
            canCu: 'Hình vuông khác hình chữ nhật ở chỗ bốn cạnh bằng nhau, nên phải so cạnh.',
          },
          {
            viec: vuong
            ? 'Hình chữ nhật có bốn cạnh bằng nhau là hình vuông. Vậy đây là hình vuông.'
            : 'Bốn cạnh không bằng nhau nên đây là hình chữ nhật, không phải hình vuông.',
            canCu: 'Hình vuông là trường hợp riêng của hình chữ nhật, nên gọi tên chính xác nhất là hình vuông.',
          },
        ],
        hints: [
          'Hình vuông là trường hợp đặc biệt của hình chữ nhật.',
          'Phải nhìn số đo cạnh, không đoán bằng mắt.',
        ],
        answer: vuong ? 'hình vuông' : 'hình chữ nhật',
        check: { expression: `${dai} - ${rong}`, equals: `${dai - rong}` },
      };
    },
  },

  {
    id: 'BP.M1.DODAI.VACH0',
    formCode: 'M1.DO.DODAI',
    intent: 'Đo độ dài khi vật KHÔNG đặt từ vạch 0 — buộc học viên lấy hiệu hai vạch thay vì đọc vạch cuối.',
    targetTrap: 'đặt thước không khớp vạch 0',
    context: 'thực tế',
    shape: { steps: 2, cases: 1 },
    stars: 2,
    levels: [1, 2],
    space: function* () {
      for (let dau = 1; dau <= 5; dau++) {
        for (let dai = 3; dai <= 12; dai++) {
          if (dau + dai <= 20) yield { dau, dai };
        }
      }
    },
    render: ({ dau, dai }) => ({
      stem: `Bút chì đặt trên thước. Đầu bút ở vạch $${dau}$ cm. Đuôi bút ở vạch $${dau + dai}$ cm. `
        + 'Bút chì dài mấy xăng-ti-mét?',
      solutionSteps: [
          {
            viec: 'Bút không đặt từ vạch 0 nên không đọc thẳng vạch cuối được.',
            canCu: 'Chỉ đọc thẳng vạch cuối khi vật đặt từ vạch $0$; không thì con số đọc được là vị trí, không phải độ dài.',
          },
          {
            viec: `Độ dài bằng hiệu hai vạch: $${dau + dai} - ${dau} = ${dai}$ (cm).`,
            canCu: 'Độ dài bằng hiệu của hai vạch ở hai đầu vật.',
          },
          {
            viec: `Vậy bút chì dài $${dai}$ cm.`,
            canCu: 'Ghi kết quả kèm đơn vị đo.',
          },
        ],
      hints: [
        'Nhìn cả hai đầu của vật, không chỉ nhìn một đầu.',
        'Độ dài là khoảng cách giữa hai vạch, tức là hiệu của chúng.',
      ],
      answer: `${dai} cm`,
      check: { expression: `${dau + dai} - ${dau}`, equals: `${dai}` },
    }),
  },

  // ══ LỚP 2 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M2.DEM100.SOSANH',
    formCode: 'M2.SO.DEM100',
    intent: 'So sánh hai số có hai chữ số khi hàng đơn vị nói ngược với hàng chục — chặn thói quen so đơn vị trước.',
    targetTrap: 'so sánh theo hàng đơn vị trước',
    context: 'số học thuần',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [1, 2],
    space: function* () {
      for (let a = 21; a <= 89; a++) {
        for (let b = a + 1; b <= 99; b++) {
          // Bẫy chỉ bật khi số NHỎ HƠN lại có hàng đơn vị LỚN HƠN.
          if (Math.floor(a / 10) >= Math.floor(b / 10)) continue;
          if (a % 10 <= b % 10) continue;
          if (b - a > 30) continue;
          yield { a, b };
        }
      }
    },
    render: ({ a, b }) => ({
      stem: `Điền dấu thích hợp vào chỗ chấm: $${a} \\ldots ${b}$.`,
      solutionSteps: [
          {
            viec: `So hàng chục trước: $${a}$ có $${Math.floor(a / 10)}$ chục, $${b}$ có $${Math.floor(b / 10)}$ chục.`,
            canCu: 'So sánh hai số có hai chữ số thì xét hàng chục trước, vì một chục bằng mười đơn vị.',
          },
          {
            viec: `$${Math.floor(a / 10)} < ${Math.floor(b / 10)}$ nên $${a} < ${b}$.`,
            canCu: 'Hàng chục đã khác nhau thì kết luận được ngay.',
          },
          {
            viec: `Hàng đơn vị $${a % 10} > ${b % 10}$ nhưng KHÔNG dùng để so, vì hàng chục đã quyết định.`,
            canCu: 'Hàng đơn vị chỉ dùng khi hàng chục bằng nhau — ở đây nó không đổi được kết quả.',
          },
        ],
      hints: [
        'So sánh số có hai chữ số thì xét hàng chục trước.',
        'Chỉ khi hai số cùng số chục mới xét đến hàng đơn vị.',
      ],
      answer: '<',
      check: { expression: `${b} - ${a}`, equals: `${b - a}` },
    }),
  },

  {
    id: 'BP.M2.NHAN.CONGNHIEULAN',
    formCode: 'M2.NHAN.BANG25',
    intent: 'Nối phép nhân với phép cộng nhiều lần — học viên phải viết được tổng tương ứng chứ không chỉ đọc thuộc bảng.',
    targetTrap: 'đọc thuộc nhưng không hiểu nhân là cộng nhiều lần',
    context: 'số học thuần',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      for (const a of [2, 3, 4, 5]) {
        for (let b = 3; b <= 9; b++) yield { a, b };
      }
    },
    render: ({ a, b }) => ({
      stem: `Viết $${a} \\times ${b}$ thành tổng các số bằng nhau. Sau đó tính kết quả.`,
      solutionSteps: [
          {
            viec: `$${a} \\times ${b}$ nghĩa là lấy $${a}$ cộng với chính nó $${b}$ lần.`,
            canCu: 'Phép nhân là cách viết gọn của phép cộng nhiều số hạng bằng nhau.',
          },
          {
            viec: `$${Array(b).fill(a).join(' + ')} = ${a * b}$.`,
            canCu: 'Cộng lần lượt các số hạng bằng nhau.',
          },
          {
            viec: `Vậy $${a} \\times ${b} = ${a * b}$.`,
            canCu: 'Tổng vừa tính chính là tích cần tìm.',
          },
        ],
      hints: [
        `Thừa số thứ hai cho biết cộng bao nhiêu lần.`,
        'Đếm lại số số hạng trước khi cộng.',
      ],
      answer: `${a * b}`,
      check: { expression: `${a}*${b}`, equals: `${a * b}` },
    }),
  },

  {
    id: 'BP.M2.DONVI.BAC10',
    formCode: 'M2.DO.DONVI',
    intent: 'Đổi đơn vị độ dài giữa các bậc liền kề — buộc nhân hoặc chia đúng bậc 10, không đoán.',
    targetTrap: 'đổi sai bậc 10 giữa các đơn vị',
    context: 'thực tế',
    shape: { steps: 2, cases: 1 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      const cap = [['dm', 'cm', 10], ['m', 'dm', 10], ['m', 'cm', 100], ['km', 'm', 1000]];
      for (const [lon, nho, he] of cap) {
        for (const n of [2, 3, 4, 5, 6, 7, 8, 9, 12, 15, 25]) yield { lon, nho, he, n };
      }
    },
    render: ({ lon, nho, he, n }) => ({
      stem: `Đổi: $${n}$ ${lon} $= \\ldots$ ${nho}.`,
      solutionSteps: [
          {
            viec: `$1$ ${lon} $= ${he}$ ${nho}.`,
            canCu: 'Hai đơn vị đo độ dài liền nhau hơn kém nhau $10$ lần.',
          },
          {
            viec: `Đổi từ đơn vị lớn sang đơn vị nhỏ thì nhân: $${n} \\times ${he} = ${n * he}$.`,
            canCu: 'Đổi từ đơn vị lớn sang đơn vị nhỏ thì NHÂN; đổi ngược lại thì chia.',
          },
          {
            viec: `Vậy $${n}$ ${lon} $= ${n * he}$ ${nho}.`,
            canCu: 'Ghi kết quả kèm đơn vị mới.',
          },
        ],
      hints: [
        'Đơn vị lớn sang đơn vị nhỏ thì số đo tăng lên, nên phải nhân.',
        `Nhớ kỹ: $1$ ${lon} $= ${he}$ ${nho}.`,
      ],
      answer: `${n * he} ${nho}`,
      check: { expression: `${n}*${he}`, equals: `${n * he}` },
    }),
  },

  {
    id: 'BP.M2.LOIVAN.TUKHOA_NGUOC',
    formCode: 'M2.GIAI.CO LOIVAN',
    intent: 'Đề có từ khoá gợi phép tính NGƯỢC với phép tính đúng — chặn thói quen thấy "thêm" là cộng.',
    targetTrap: 'chọn sai phép tính do bám từ khoá máy móc',
    context: 'thực tế',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 3],
    space: function* () {
      for (let i = 0; i < TEN.length; i++) {
        for (let sau = 12; sau <= 40; sau += 4) {
          for (const them of [3, 5, 7, 9]) {
            if (sau - them < 3) continue;
            yield { i, sau, them };
          }
        }
      }
    },
    render: ({ i, sau, them }) => {
      const ten = TEN[i % TEN.length];
      const vat = DO_VAT[i % DO_VAT.length];
      const truoc = sau - them;
      return {
        stem: `${ten} có một số ${vat.ten}. Mẹ cho thêm $${them}$ ${vat.dv}. `
          + `Bây giờ ${ten} có $${sau}$ ${vat.dv}. Hỏi lúc đầu ${ten} có mấy ${vat.dv}?`,
        solutionSteps: [
          {
            viec: `Đề có chữ "thêm" nhưng hỏi số lúc ĐẦU, nên phải làm phép trừ.`,
            canCu: 'Chọn phép tính theo CÂU HỎI của đề, không theo từ khoá xuất hiện trong đề. Từ "thêm" không có nghĩa là phải cộng.',
          },
          {
            viec: `Số ${vat.ten} lúc đầu: $${sau} - ${them} = ${truoc}$ (${vat.dv}).`,
            canCu: 'Biết số lúc sau và phần thêm vào thì tìm số lúc đầu bằng phép trừ.',
          },
          {
            viec: `Đáp số: $${truoc}$ ${vat.dv}.`,
            canCu: 'Ghi đáp số kèm đơn vị.',
          },
        ],
        hints: [
          'Đọc kỹ câu hỏi: hỏi lúc đầu hay lúc sau?',
          'Biết số lúc sau và số được thêm, muốn tìm số lúc đầu thì lấy trừ.',
          'Viết đủ lời giải và đơn vị.',
        ],
        answer: `${truoc} ${vat.dv}`,
        check: { expression: `${sau} - ${them}`, equals: `${truoc}` },
      };
    },
  },

  // ══ LỚP 3 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M3.NHAN.CONHO',
    formCode: 'M3.NHAN.BANG69',
    intent: 'Nhân số có hai chữ số với số có một chữ số, BẮT BUỘC có nhớ ở hàng đơn vị.',
    targetTrap: 'quên cộng phần nhớ',
    context: 'số học thuần',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      for (let a = 13; a <= 98; a++) {
        for (const b of [6, 7, 8, 9]) {
          // Chỉ lấy phép tính CÓ NHỚ: hàng đơn vị nhân ra số từ 10 trở lên.
          if ((a % 10) * b < 10) continue;
          if (a * b > 900) continue;
          yield { a, b };
        }
      }
    },
    render: ({ a, b }) => {
      const dv = a % 10;
      const ch = Math.floor(a / 10);
      const tichDv = dv * b;
      const nho = Math.floor(tichDv / 10);
      return {
        stem: `Đặt tính rồi tính: $${a} \\times ${b}$.`,
        solutionSteps: [
          {
            viec: `Nhân hàng đơn vị: $${dv} \\times ${b} = ${tichDv}$, viết $${tichDv % 10}$ nhớ $${nho}$.`,
            canCu: 'Nhân từ hàng đơn vị trước; tích lớn hơn $9$ thì viết chữ số hàng đơn vị và nhớ phần chục sang hàng sau.',
          },
          {
            viec: `Nhân hàng chục: $${ch} \\times ${b} = ${ch * b}$, thêm $${nho}$ nhớ được $${ch * b + nho}$.`,
            canCu: 'Nhân hàng chục rồi CỘNG phần nhớ vào — quên cộng phần nhớ là lỗi phổ biến nhất.',
          },
          {
            viec: `Vậy $${a} \\times ${b} = ${a * b}$.`,
            canCu: 'Ghép kết quả của các hàng theo đúng vị trí.',
          },
        ],
        hints: [
          'Nhân từ hàng đơn vị trước.',
          `Tích hàng đơn vị là $${tichDv}$, lớn hơn $9$ nên phải nhớ.`,
          'Đừng quên cộng phần nhớ vào tích hàng chục.',
        ],
        answer: `${a * b}`,
        check: { expression: `${a}*${b}`, equals: `${a * b}` },
      };
    },
  },

  {
    id: 'BP.M3.CHUVI.THIEUCAP',
    formCode: 'M3.HINH.CHUVI',
    intent: 'Tính chu vi hình chữ nhật từ chiều dài và chiều rộng — chặn lỗi chỉ cộng một cặp cạnh.',
    targetTrap: 'cộng thiếu một cặp cạnh',
    context: 'hình học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      for (let d = 6; d <= 30; d += 2) {
        for (let r = 3; r < d; r += 2) {
          if (d - r < 2) continue;
          yield { d, r };
        }
      }
    },
    render: ({ d, r }) => ({
      stem: `Mảnh vườn hình chữ nhật có chiều dài $${d}$ m. Chiều rộng mảnh vườn là $${r}$ m. Tính chu vi mảnh vườn.`,
      solutionSteps: [
          {
            viec: 'Chu vi hình chữ nhật bằng tổng hai kích thước nhân với 2.',
            canCu: 'Chu vi hình chữ nhật là tổng độ dài bốn cạnh, mà hai cặp cạnh đối bằng nhau nên viết gọn thành tổng hai kích thước nhân $2$.',
          },
          {
            viec: `$P = (${d} + ${r}) \\times 2 = ${d + r} \\times 2 = ${(d + r) * 2}$ (m).`,
            canCu: 'Thay số vào công thức, cộng trong ngoặc trước rồi mới nhân.',
          },
          {
            viec: `Đáp số: $${(d + r) * 2}$ m.`,
            canCu: 'Ghi đáp số kèm đơn vị độ dài.',
          },
        ],
      hints: [
        'Hình chữ nhật có hai chiều dài và hai chiều rộng.',
        'Cộng một chiều dài với một chiều rộng rồi nhân đôi.',
        'Viết kèm đơn vị đo trong đáp số.',
      ],
      answer: `${(d + r) * 2} m`,
      check: { expression: `(${d} + ${r})*2`, equals: `${(d + r) * 2}` },
    }),
  },

  {
    id: 'BP.M3.GIO.QUATRUA',
    formCode: 'M3.THOIGIAN.XEMGIO',
    intent: 'Tính khoảng thời gian vắt qua mốc 12 giờ — chặn lỗi trừ thẳng hai số giờ.',
    targetTrap: 'tính khoảng thời gian qua mốc 12 giờ',
    context: 'thực tế',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 3],
    space: function* () {
      for (let gd = 8; gd <= 11; gd++) {
        for (const pd of [0, 15, 30, 45]) {
          for (let gc = 13; gc <= 16; gc++) {
            for (const pc of [0, 15, 30, 45]) {
              const phut = (gc * 60 + pc) - (gd * 60 + pd);
              if (phut < 90 || phut > 480) continue;
              yield { gd, pd, gc, pc, phut };
            }
          }
        }
      }
    },
    render: ({ gd, pd, gc, pc, phut }) => {
      const gio = Math.floor(phut / 60);
      const le = phut % 60;
      return {
        stem: `Cửa hàng mở cửa lúc ${gioPhut(gd, pd)} sáng. Cửa hàng đóng cửa lúc ${gioPhut(gc, pc)}. `
          + 'Cửa hàng mở cửa trong bao lâu?',
        solutionSteps: [
          {
            viec: `Đổi cả hai mốc về số phút kể từ 0 giờ: mở lúc $${gd * 60 + pd}$ phút, đóng lúc $${gc * 60 + pc}$ phút.`,
            canCu: 'Quy cả hai mốc về cùng một đơn vị đếm từ một gốc chung thì phép trừ mới đúng khi khoảng thời gian vắt qua trưa.',
          },
          {
            viec: `Khoảng thời gian: $${gc * 60 + pc} - ${gd * 60 + pd} = ${phut}$ (phút).`,
            canCu: 'Khoảng thời gian bằng hiệu hai mốc đã quy đổi.',
          },
          {
            viec: `Đổi lại: $${phut}$ phút $= ${gio}$ giờ${le ? ` ${le} phút` : ''}.`,
            canCu: 'Đổi kết quả về đơn vị mà đề hỏi.',
          },
        ],
        hints: [
          'Giờ chiều phải đổi sang cách đếm 24 giờ trước khi trừ.',
          'Đổi cả hai mốc về phút rồi mới trừ, tránh nhầm khi qua mốc 12 giờ.',
        ],
        answer: le ? `${gio} giờ ${le} phút` : `${gio} giờ`,
        check: { expression: `(${gc}*60 + ${pc}) - (${gd}*60 + ${pd})`, equals: `${phut}` },
      };
    },
  },

  {
    id: 'BP.M3.HAIBUOC.HOICUOI',
    formCode: 'M3.GIAI.HAIPHEPTINH',
    intent: 'Bài hai bước mà kết quả bước một rất dễ bị tưởng là đáp số — chặn lỗi trả lời câu hỏi trung gian.',
    targetTrap: 'trả lời câu hỏi trung gian thay vì câu hỏi cuối',
    context: 'thực tế',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [2, 4],
    space: function* () {
      for (let i = 0; i < TEN.length; i++) {
        for (const hop of [4, 5, 6, 8]) {
          for (const moiHop of [6, 7, 8, 9, 12]) {
            for (const daBan of [10, 15, 20, 25]) {
              const tong = hop * moiHop;
              if (daBan >= tong || tong - daBan < 5) continue;
              yield { i, hop, moiHop, daBan, tong };
            }
          }
        }
      }
    },
    render: ({ i, hop, moiHop, daBan, tong }) => {
      const vat = DO_VAT[i % DO_VAT.length];
      return {
        stem: `Cửa hàng có $${hop}$ hộp ${vat.ten}. Mỗi hộp có $${moiHop}$ ${vat.dv}. `
          + `Cửa hàng đã bán $${daBan}$ ${vat.dv}. Hỏi còn lại mấy ${vat.dv}?`,
        solutionSteps: [
          {
            viec: `Bước 1 — Số ${vat.ten} có tất cả: $${hop} \\times ${moiHop} = ${tong}$ (${vat.dv}).`,
            canCu: 'Bài hai phép tính phải làm theo thứ tự: đại lượng trung gian trước.',
          },
          {
            viec: `Bước 2 — Số ${vat.ten} còn lại: $${tong} - ${daBan} = ${tong - daBan}$ (${vat.dv}).`,
            canCu: 'Dùng kết quả trung gian để tính tiếp đại lượng đề hỏi.',
          },
          {
            viec: `Câu hỏi cuối là số còn lại, không phải số có tất cả.`,
            canCu: 'Đọc lại câu hỏi để chắc chắn đang trả lời đúng đại lượng, không dừng ở kết quả trung gian.',
          },
          {
            viec: `Đáp số: $${tong - daBan}$ ${vat.dv}.`,
            canCu: 'Ghi đáp số kèm đơn vị.',
          },
        ],
        hints: [
          'Đọc lại câu hỏi cuối cùng trước khi ghi đáp số.',
          `$${tong}$ mới là số có tất cả, chưa phải đáp số.`,
        ],
        answer: `${tong - daBan} ${vat.dv}`,
        check: { expression: `${hop}*${moiHop} - ${daBan}`, equals: `${tong - daBan}` },
      };
    },
  },

  // ══ LỚP 4 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M4.LONHON.LAMTRON',
    formCode: 'M4.SO.LONHON',
    intent: 'Làm tròn số lớn đến hàng cho trước — buộc nhìn đúng chữ số quyết định chứ không nhìn chữ số cuối.',
    targetTrap: 'làm tròn nhìn sai chữ số quyết định',
    context: 'số học thuần',
    shape: { steps: 3, cases: 2 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      for (const hang of [100, 1000, 10000]) {
        for (let k = 3; k <= 40; k++) {
          for (const le of [Math.floor(hang * 0.45), Math.floor(hang * 0.5), Math.floor(hang * 0.62)]) {
            const n = k * hang + le;
            if (n < 500 || n > 900000) continue;
            yield { n, hang };
          }
        }
      }
    },
    render: ({ n, hang }) => {
      const ten = { 100: 'trăm', 1000: 'nghìn', 10000: 'chục nghìn' }[hang];
      const duoi = n % hang;
      const len = duoi * 2 >= hang;
      const ra = len ? n - duoi + hang : n - duoi;
      return {
        stem: `Làm tròn số $${n}$ đến hàng ${ten}.`,
        solutionSteps: [
          {
            viec: `Chữ số quyết định là chữ số liền sau hàng ${ten}, ở đây phần đứng sau là $${duoi}$.`,
            canCu: 'Làm tròn đến một hàng thì nhìn vào phần đứng NGAY SAU hàng đó.',
          },
          {
            viec: `So với nửa của $${hang}$ là $${hang / 2}$: $${duoi} ${len ? '\\ge' : '<'} ${hang / 2}$ nên làm tròn ${len ? 'lên' : 'xuống'}.`,
            canCu: 'Phần đó nhỏ hơn nửa đơn vị của hàng đang làm tròn thì làm tròn xuống, ngược lại thì làm tròn lên.',
          },
          {
            viec: `Vậy $${n}$ làm tròn đến hàng ${ten} được $${ra}$.`,
            canCu: 'Viết lại số sau khi làm tròn, các hàng phía sau thành $0$.',
          },
        ],
        hints: [
          `Muốn làm tròn đến hàng ${ten} thì nhìn phần đứng sau hàng đó.`,
          'Không nhìn chữ số cuối cùng của số.',
        ],
        answer: `${ra}`,
        check: { expression: `${n} - ${duoi} + ${len ? hang : 0}`, equals: `${ra}` },
      };
    },
  },

  {
    id: 'BP.M4.CHIAHET.BA_VS_CHIN',
    formCode: 'M4.CHIAHET.DAUHIEU',
    intent: 'Xét chia hết cho 3 và cho 9 trên cùng một số — chặn lỗi coi hai dấu hiệu là một.',
    targetTrap: 'áp dấu hiệu chia 3 cho phép chia 9',
    context: 'số học thuần',
    shape: { steps: 4, cases: 2 },
    stars: 3,
    levels: [2, 4],
    space: function* () {
      for (let n = 102; n <= 999; n++) {
        const tong = String(n).split('').reduce((s, c) => s + Number(c), 0);
        // Chọn số chia hết cho 3 nhưng KHÔNG chia hết cho 9 — đúng chỗ bẫy.
        if (tong % 3 !== 0 || tong % 9 === 0) continue;
        yield { n, tong };
      }
    },
    render: ({ n, tong }) => ({
      stem: `Số $${n}$ có chia hết cho $3$ không? Có chia hết cho $9$ không?`,
      solutionSteps: [
          {
            viec: `Tổng các chữ số: $${String(n).split('').join(' + ')} = ${tong}$.`,
            canCu: 'Dấu hiệu chia hết cho $3$ và cho $9$ đều xét TỔNG các chữ số, không xét chữ số cuối.',
          },
          {
            viec: `$${tong}$ chia hết cho $3$ nên $${n}$ chia hết cho $3$.`,
            canCu: 'Tổng chữ số chia hết cho $3$ thì số đó chia hết cho $3$.',
          },
          {
            viec: `$${tong}$ không chia hết cho $9$ (vì $${tong} : 9$ còn dư $${tong % 9}$) nên $${n}$ không chia hết cho $9$.`,
            canCu: 'Tổng chữ số phải chia hết cho $9$ thì số đó mới chia hết cho $9$ — điều kiện chặt hơn.',
          },
          {
            viec: 'Chia hết cho 3 chưa chắc chia hết cho 9.',
            canCu: 'Mọi số chia hết cho $9$ đều chia hết cho $3$, nhưng chiều ngược lại không đúng.',
          },
        ],
      hints: [
        'Xét tổng các chữ số cho cả hai dấu hiệu.',
        'Dấu hiệu chia 3 và dấu hiệu chia 9 là hai dấu hiệu khác nhau.',
      ],
      answer: 'chia hết cho 3, không chia hết cho 9',
      check: { expression: `${n} - 3*${n / 3}`, equals: '0' },
    }),
  },

  {
    id: 'BP.M4.PHANSO.RUTGON',
    formCode: 'M4.PHANSO.KHAINIEM',
    intent: 'Rút gọn phân số về tối giản — chặn lỗi chia một vế của phân số.',
    targetTrap: 'rút gọn chỉ tử hoặc chỉ mẫu',
    context: 'số học thuần',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [2, 4],
    space: function* () {
      for (let t = 2; t <= 12; t++) {
        for (let m = t + 1; m <= 20; m++) {
          if (gcd(t, m) !== 1) continue;            // phân số tối giản gốc
          for (const k of [2, 3, 4, 5, 6]) {
            if (m * k > 120) continue;
            yield { t: t * k, m: m * k, tg: t, mg: m, k };
          }
        }
      }
    },
    render: ({ t, m, tg, mg, k }) => ({
      stem: `Rút gọn phân số $\\dfrac{${t}}{${m}}$.`,
      solutionSteps: [
          {
            viec: `Tìm số chia chung của tử và mẫu: cả $${t}$ và $${m}$ đều chia hết cho $${k}$.`,
            canCu: 'Rút gọn phân số là chia cả tử và mẫu cho một ước chung khác $1$.',
          },
          {
            viec: `Chia CẢ HAI cho $${k}$: $\\dfrac{${t} : ${k}}{${m} : ${k}} = \\dfrac{${tg}}{${mg}}$.`,
            canCu: 'Phải chia CẢ HAI cho cùng một số thì giá trị phân số mới không đổi.',
          },
          {
            viec: `$\\dfrac{${tg}}{${mg}}$ đã tối giản vì tử và mẫu không còn chia chung số nào khác $1$.`,
            canCu: 'Phân số tối giản khi tử và mẫu không còn ước chung nào khác $1$.',
          },
        ],
      hints: [
        'Rút gọn là chia cả tử và mẫu cho cùng một số.',
        'Chia một mình tử thì giá trị phân số đã đổi.',
      ],
      answer: `\\dfrac{${tg}}{${mg}}`,
      check: { expression: `${t}/${m}`, equals: `${tg}/${mg}` },
    }),
  },

  {
    id: 'BP.M4.TRUNGBINH.SOHANG',
    formCode: 'M4.TRUNGBINH.CONG',
    intent: 'Tính trung bình cộng khi số các số hạng dễ đếm nhầm — chặn lỗi chia cho số sai.',
    targetTrap: 'chia cho số hạng sai',
    context: 'thực tế',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [2, 4],
    space: function* () {
      for (let n = 3; n <= 6; n++) {
        for (let dau = 10; dau <= 40; dau += 5) {
          for (const buoc of [2, 4, 6]) {
            const ds = Array.from({ length: n }, (_, i) => dau + i * buoc);
            const tong = ds.reduce((s, x) => s + x, 0);
            if (tong % n !== 0) continue;           // giữ đáp số là số nguyên
            yield { ds, tong, n };
          }
        }
      }
    },
    render: ({ ds, tong, n }) => ({
      stem: `Tìm số trung bình cộng của các số: $${ds.join('$, $')}$.`,
      solutionSteps: [
          {
            viec: `Đếm số các số hạng: có $${n}$ số.`,
            canCu: 'Muốn tính trung bình cộng thì phải biết có bao nhiêu số hạng — đây là mẫu số của phép chia.',
          },
          {
            viec: `Tính tổng: $${ds.join(' + ')} = ${tong}$.`,
            canCu: 'Tính tổng của tất cả các số hạng.',
          },
          {
            viec: `Trung bình cộng: $${tong} : ${n} = ${tong / n}$.`,
            canCu: 'Trung bình cộng bằng tổng chia cho SỐ CÁC số hạng.',
          },
        ],
      hints: [
        'Đếm lại số các số hạng trước khi chia.',
        'Phải cộng hết rồi mới chia.',
      ],
      answer: `${tong / n}`,
      check: { expression: `(${ds.join(' + ')})/${n}`, equals: `${tong / n}` },
    }),
  },

  {
    id: 'BP.M4.GOC.DOBANGSODO',
    formCode: 'M4.HINH.GOC',
    intent: 'Phân loại góc theo SỐ ĐO cho sẵn — chặn thói quen nhận định bằng mắt.',
    targetTrap: 'nhận định góc bằng mắt thay vì đo',
    context: 'hình học',
    shape: { steps: 2, cases: 3 },
    stars: 2,
    levels: [1, 3],
    space: function* () {
      // Lấy các số đo SÁT ranh giới 90 và 180 — chỗ mắt thường nhìn nhầm nhất.
      for (const d of [82, 85, 88, 89, 91, 92, 95, 98, 175, 178, 179]) yield { d };
    },
    render: ({ d }) => {
      const loai = d < 90 ? 'góc nhọn' : d === 90 ? 'góc vuông' : d < 180 ? 'góc tù' : 'góc bẹt';
      return {
        stem: `Một góc có số đo $${d}^{\\circ}$. Đó là góc nhọn, góc vuông, góc tù hay góc bẹt?`,
        solutionSteps: [
          {
            viec: 'Góc nhọn nhỏ hơn $90^{\\circ}$, góc vuông bằng $90^{\\circ}$, góc tù lớn hơn $90^{\\circ}$ và nhỏ hơn $180^{\\circ}$, góc bẹt bằng $180^{\\circ}$.',
            canCu: 'Phân loại góc theo số đo, lấy $90^{\\circ}$ và $180^{\\circ}$ làm hai mốc.',
          },
          {
            viec: // Mỗi nhánh phải tự đóng cặp $…$ của mình. Viết lồng nhau như trước
          // làm số dấu $ lệch nhau, và lệnh LaTeX rơi ra ngoài chế độ toán —
          // người đọc nhìn thấy nguyên chuỗi "90^{\\circ}" trên màn hình.
          `So sánh: ${d < 90 ? `$${d}^{\\circ} < 90^{\\circ}$`
            : d < 180 ? `$${d}^{\\circ} > 90^{\\circ}$ và $${d}^{\\circ} < 180^{\\circ}$`
              : `$${d}^{\\circ} = 180^{\\circ}$`}.`,
            canCu: 'So số đo đã cho với mốc $90^{\\circ}$.',
          },
          {
            viec: `Vậy đó là ${loai}.`,
            canCu: 'Gọi tên góc theo khoảng mà số đo rơi vào.',
          },
        ],
        hints: [
          `Góc $${d}^{\\circ}$ rất gần $${d < 95 ? 90 : 180}^{\\circ}$ nên nhìn bằng mắt dễ nhầm.`,
          'Luôn so số đo với các mốc 90 độ và 180 độ.',
        ],
        answer: loai,
        check: { expression: `${d} - 90`, equals: `${d - 90}` },
      };
    },
  },

  // ══ LỚP 5 ══════════════════════════════════════════════════════════════
  {
    id: 'BP.M5.THAPPHAN.SOSANH',
    formCode: 'M5.THAPPHAN.KHAINIEM',
    intent: 'So sánh hai số thập phân có số chữ số phần thập phân khác nhau — chặn lỗi so theo độ dài.',
    targetTrap: 'so sánh theo độ dài phần thập phân',
    context: 'số học thuần',
    shape: { steps: 3, cases: 1 },
    stars: 3,
    levels: [2, 4],
    space: function* () {
      for (let a = 1; a <= 9; a++) {
        for (let b = 1; b <= 9; b++) {
          for (let c = 1; c <= 9; c++) {
            // x có 1 chữ số thập phân, y có 3 chữ số thập phân, nhưng x > y.
            const x = a + b / 10;
            const y = a + (b - 1) / 10 + c / 1000;
            if (b === 1 || !(x > y)) continue;
            yield { x, y, a, b, c };
          }
        }
      }
    },
    render: ({ x, y }) => ({
      stem: `So sánh hai số thập phân: $${thap(x, 3)}$ và $${thap(y, 3)}$.`,
      solutionSteps: [
          {
            viec: 'So sánh phần nguyên trước: hai số có phần nguyên bằng nhau.',
            canCu: 'So sánh số thập phân thì so phần nguyên trước; phần nguyên khác nhau là kết luận được ngay.',
          },
          {
            viec: 'So tiếp hàng phần mười, rồi mới đến hàng phần trăm, phần nghìn.',
            canCu: 'Phần nguyên bằng nhau thì so từng hàng thập phân theo thứ tự từ trái sang phải.',
          },
          {
            viec: `Hàng phần mười của số thứ nhất lớn hơn nên $${thap(x, 3)} > ${thap(y, 3)}$.`,
            canCu: 'Hàng nào khác nhau trước thì hàng đó quyết định; số chữ số nhiều hay ít KHÔNG quyết định số nào lớn hơn.',
          },
        ],
      hints: [
        'Số có nhiều chữ số thập phân hơn chưa chắc đã lớn hơn.',
        'So từ trái sang phải, từng hàng một.',
      ],
      answer: '>',
      // Kiểm bằng HIỆU nhân 1000 cho về số nguyên: so sánh bằng biểu thức
      // lô-gic thì bộ xác minh trả về true/false chứ không trả về số.
      check: { expression: `${x}*1000 - ${y}*1000`, equals: `${Math.round((x - y) * 1000)}` },
    }),
  },

  {
    id: 'BP.M5.DIENTICH.TAMGIAC',
    formCode: 'M5.HINH.DIENTICH',
    intent: 'Tính diện tích tam giác từ đáy và chiều cao — chặn lỗi quên chia 2.',
    targetTrap: 'quên chia 2 ở tam giác và hình thang',
    context: 'hình học',
    shape: { steps: 3, cases: 1 },
    stars: 2,
    levels: [2, 4],
    space: function* () {
      for (let a = 6; a <= 40; a += 2) {
        for (let h = 5; h <= 30; h++) {
          if ((a * h) % 2 !== 0) continue;
          if (a * h > 800) continue;
          yield { a, h };
        }
      }
    },
    render: ({ a, h }) => ({
      stem: `Tam giác có đáy dài $${a}$ cm. Chiều cao tam giác là $${h}$ cm. Tính diện tích tam giác.`,
      solutionSteps: [
          {
            viec: 'Diện tích tam giác bằng đáy nhân chiều cao rồi chia cho 2.',
            canCu: 'Diện tích tam giác bằng đáy nhân chiều cao TƯƠNG ỨNG rồi chia $2$; chiều cao phải hạ xuống đúng cạnh lấy làm đáy.',
          },
          {
            viec: `$S = \\dfrac{${a} \\times ${h}}{2} = \\dfrac{${a * h}}{2} = ${(a * h) / 2}$ (cm$^{2}$).`,
            canCu: 'Thay số vào công thức, nhân trước rồi chia sau.',
          },
          {
            viec: `Đáp số: $${(a * h) / 2}$ cm$^{2}$.`,
            canCu: 'Ghi đáp số kèm đơn vị diện tích.',
          },
        ],
      hints: [
        `$${a} \\times ${h} = ${a * h}$ mới là diện tích hình chữ nhật, chưa phải tam giác.`,
        'Công thức tam giác có chia 2.',
      ],
      answer: `${(a * h) / 2} cm^{2}`,
      check: { expression: `${a}*${h}/2`, equals: `${(a * h) / 2}` },
    }),
  },

  {
    id: 'BP.M5.THETICH.XQ_VS_TP',
    formCode: 'M5.HINH.THETICH',
    intent: 'Phân biệt diện tích xung quanh và diện tích toàn phần của hình hộp chữ nhật.',
    targetTrap: 'nhầm diện tích xung quanh với toàn phần',
    context: 'hình học',
    shape: { steps: 4, cases: 1 },
    stars: 3,
    levels: [3, 5],
    space: function* () {
      for (let d = 4; d <= 12; d++) {
        for (let r = 3; r < d; r++) {
          for (let c = 2; c <= 10; c++) yield { d, r, c };
        }
      }
    },
    render: ({ d, r, c }) => {
      const xq = (d + r) * 2 * c;
      const day = d * r;
      const tp = xq + day * 2;
      return {
        stem: `Hình hộp chữ nhật có chiều dài $${d}$ dm, chiều rộng $${r}$ dm. `
          + `Chiều cao hình hộp là $${c}$ dm. Tính diện tích xung quanh và diện tích toàn phần.`,
        solutionSteps: [
          {
            viec: `Chu vi đáy: $(${d} + ${r}) \\times 2 = ${(d + r) * 2}$ (dm).`,
            canCu: 'Diện tích xung quanh tính qua chu vi đáy, nên phải có chu vi đáy trước.',
          },
          {
            viec: `Diện tích xung quanh: $${(d + r) * 2} \\times ${c} = ${xq}$ (dm$^{2}$).`,
            canCu: 'Diện tích xung quanh bằng chu vi đáy nhân chiều cao — đó là bốn mặt bên trải phẳng thành một hình chữ nhật.',
          },
          {
            viec: `Diện tích một mặt đáy: $${d} \\times ${r} = ${day}$ (dm$^{2}$).`,
            canCu: 'Tính riêng diện tích một mặt đáy.',
          },
          {
            viec: `Diện tích toàn phần: $${xq} + ${day} \\times 2 = ${tp}$ (dm$^{2}$).`,
            canCu: 'Diện tích toàn phần bằng diện tích xung quanh cộng HAI mặt đáy; cộng một mặt là thiếu đúng một đáy.',
          },
        ],
        hints: [
          'Diện tích xung quanh chỉ gồm bốn mặt bên.',
          'Toàn phần bằng xung quanh cộng thêm HAI mặt đáy.',
        ],
        answer: `S_{xq} = ${xq} dm^{2}, S_{tp} = ${tp} dm^{2}`,
        check: { expression: `(${d} + ${r})*2*${c} + 2*${d}*${r}`, equals: `${tp}` },
      };
    },
  },

  {
    id: 'BP.M5.CHUYENDONG.DOIPHUT',
    formCode: 'M5.CHUYENDONG.DEU',
    intent: 'Bài chuyển động có thời gian cho bằng giờ và phút — buộc đổi về cùng đơn vị trước khi tính.',
    targetTrap: 'không đổi phút sang giờ',
    context: 'thực tế',
    shape: { steps: 4, cases: 1 },
    stars: 4,
    levels: [3, 5],
    space: function* () {
      for (const v of [12, 15, 18, 24, 30, 36, 40, 45, 48, 60]) {
        for (const gio of [1, 2, 3]) {
          for (const phut of [15, 20, 30, 40, 45]) {
            const t = gio + phut / 60;
            const s = v * t;
            if (!Number.isInteger(s) || s > 200) continue;
            yield { v, gio, phut, s, t };
          }
        }
      }
    },
    render: ({ v, gio, phut, s }) => ({
      stem: `Một người đi xe đạp với vận tốc $${v}$ km/giờ. `
        + `Người đó đi trong ${gioPhut(gio, phut)}. Hỏi quãng đường dài bao nhiêu ki-lô-mét?`,
      solutionSteps: [
          {
            viec: `Đổi thời gian về giờ: $${phut}$ phút $= \\dfrac{${phut}}{60}$ giờ $= ${frac(phut, 60)}$ giờ.`,
            canCu: 'Vận tốc tính theo ki-lô-mét trên giờ thì thời gian cũng phải tính theo giờ.',
          },
          {
            viec: `Thời gian đi: $${gio} + ${frac(phut, 60)} = ${frac(gio * 60 + phut, 60)}$ (giờ).`,
            canCu: 'Cộng phần giờ nguyên với phần vừa đổi để ra tổng thời gian.',
          },
          {
            viec: `Quãng đường: $s = v \\times t = ${v} \\times ${frac(gio * 60 + phut, 60)} = ${s}$ (km).`,
            canCu: 'Công thức quãng đường bằng vận tốc nhân thời gian.',
          },
          {
            viec: `Đáp số: $${s}$ km.`,
            canCu: 'Ghi đáp số kèm đơn vị.',
          },
        ],
      hints: [
        'Vận tốc tính theo giờ thì thời gian cũng phải tính theo giờ.',
        `$${phut}$ phút không phải là $0{,}${phut}$ giờ.`,
      ],
      answer: `${s} km`,
      check: { expression: `${v}*(${gio} + ${phut}/60)`, equals: `${s}` },
    }),
  },
];

module.exports = { BP_TIEU_HOC };
