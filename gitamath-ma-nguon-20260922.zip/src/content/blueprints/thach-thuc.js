'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  BẢN THIẾT KẾ BÀI — BẬC THÁCH THỨC (NĂM SAO)
 * ═══════════════════════════════════════════════════════════════════════════
 *  VÌ SAO CÓ TỆP NÀY
 *
 *  Ma trận đề công bố có một dải "Thách thức", nhưng kho bài trước đây KHÔNG
 *  CÓ MỘT BÀI NĂM SAO NÀO — bậc cao nhất thực có là bốn sao. Nghĩa là mọi đề
 *  ở tầng 4 trở lên đều thiếu đúng phần dùng để phân loại học viên giỏi.
 *
 *  BÀI NĂM SAO KHÁC BÀI BỐN SAO Ở CHỖ NÀO
 *  Không phải ở chỗ số to hơn hay phép tính dài hơn. Một bài năm sao phải có
 *  ÍT NHẤT MỘT trong ba đặc điểm sau, và bản thiết kế nào cũng ghi rõ nó có
 *  đặc điểm nào:
 *
 *    (a) HAI RÀNG BUỘC PHẢI THOẢ ĐỒNG THỜI — giải xong một điều kiện rồi mà
 *        quên đối chiếu điều kiện kia thì ra đáp án sai, không phải thiếu ý.
 *    (b) PHẢI ĐỔI BÀI TOÁN SANG DẠNG KHÁC mới giải được — đặt ẩn phụ, đổi
 *        biến, bù trừ. Đi thẳng thì bế tắc chứ không phải chỉ lâu hơn.
 *    (c) PHẢI XÉT HẾT CÁC TRƯỜNG HỢP rồi loại, không có đường tắt.
 *
 *  Bài nào chỉ dài hơn mà không có đặc điểm nào ở trên thì đó là bài bốn sao
 *  viết dài, và nó không nằm trong tệp này.
 *
 *  MÁY VẪN PHẢI KIỂM ĐƯỢC
 *  Khó không phải là cớ để bỏ kiểm chứng. Mỗi bài dưới đây đều gắn một phép
 *  kiểm độc lập với đường lối trình bày trong lời giải.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { frac, poly, TEN } = require('./chung');
const { gauss, tiSo } = require('./kiem-so');

const BP_THACH_THUC = [

  {
    id: 'BP.TT.HPT.BAAN.VEXE',
    formCode: 'M9.HPT.BACNHAT',
    intent: 'Ba ẩn, ba ràng buộc, trong đó một ràng buộc là quan hệ tỉ lệ chứ không phải tổng. Phải khử ẩn đúng thứ tự mới ra, và nghiệm còn phải là số nguyên dương.',
    targetTrap: 'bỏ sót ràng buộc nghiệm phải là số nguyên dương',
    context: 'thực tế',
    shape: { steps: 6, cases: 1 },
    stars: 5,
    levels: [2, 5],
    space: function* () {
      // Dựng ngược từ nghiệm để bảo đảm bài luôn có nghiệm nguyên dương duy nhất.
      for (const k of [2, 3]) {
        for (let z = 2; z <= 6; z++) {
          for (let y = 3; y <= 9; y += 2) {
            const x = k * z;
            for (const [p, q, r] of [[50, 30, 20], [60, 40, 25], [80, 50, 30]]) {
              if (x + y + z > 40) continue;
              yield { k, x, y, z, p, q, r };
            }
          }
        }
      }
    },
    render: ({ k, x, y, z, p, q, r }) => {
      const n = x + y + z;
      const T = p * x + q * y + r * z;
      // Khử x = kz rồi khử y = n − (k+1)z, còn lại một phương trình bậc nhất theo z.
      const heSoZ = p * k + r - q * (k + 1);
      const vePhai = T - q * n;
      return {
        stem: `Một rạp chiếu phim bán ba loại vé: vé người lớn $${p}$ nghìn đồng, vé học sinh $${q}$ nghìn đồng `
          + `và vé trẻ em $${r}$ nghìn đồng. Trong một suất chiếu, rạp bán được tất cả $${n}$ vé và thu về $${T}$ nghìn đồng. `
          + `Biết số vé người lớn gấp $${k}$ lần số vé trẻ em. Tính số vé mỗi loại.`,
        solutionSteps: [
          {
            viec: `Gọi số vé người lớn, học sinh, trẻ em lần lượt là $x$, $y$, $z$ (vé), điều kiện $x$, $y$, $z$ là số nguyên dương.`,
            canCu: 'Số vé là số đếm được nên bắt buộc nguyên và dương; điều kiện này sẽ dùng để loại nghiệm ở bước cuối.',
          },
          {
            viec: `Tổng số vé: $x + y + z = ${n}$. Tổng tiền: $${p}x + ${q}y + ${r}z = ${T}$. Quan hệ tỉ lệ: $x = ${k}z$.`,
            canCu: 'Mỗi câu dữ kiện cho đúng một phương trình. Ba ẩn thì cần đủ ba phương trình độc lập.',
          },
          {
            viec: `Thay $x = ${k}z$ vào phương trình tổng số vé: $${k}z + y + z = ${n}$, suy ra $y = ${n} - ${k + 1}z$.`,
            canCu: 'Thế ẩn đã biểu diễn được vào trước, số ẩn giảm từ ba xuống hai.',
          },
          {
            viec: `Thay cả $x$ và $y$ vào phương trình tổng tiền: $${p} \\cdot ${k}z + ${q}\\left(${n} - ${k + 1}z\\right) + ${r}z = ${T}$.`,
            canCu: 'Thế tiếp lần hai, số ẩn giảm xuống còn một.',
          },
          {
            viec: `Rút gọn: $${heSoZ}z = ${vePhai}$, suy ra $z = ${z}$.`,
            canCu: 'Gom hệ số của $z$ rồi chuyển hằng số sang vế phải.',
          },
          {
            viec: `Suy ra $x = ${k} \\cdot ${z} = ${x}$ và $y = ${n} - ${k + 1} \\cdot ${z} = ${y}$. `
              + `Cả ba đều là số nguyên dương nên thoả điều kiện. Thử lại: $${x} + ${y} + ${z} = ${n}$ và $${p} \\cdot ${x} + ${q} \\cdot ${y} + ${r} \\cdot ${z} = ${T}$.`,
            canCu: 'Phải thử lại vào CẢ HAI phương trình gốc và đối chiếu điều kiện nguyên dương trước khi kết luận.',
          },
        ],
        hints: [
          'Quan hệ "gấp mấy lần" cho ngay một ẩn theo ẩn khác — dùng nó để thế trước.',
          'Sau hai lần thế thì chỉ còn một ẩn, bài trở thành phương trình bậc nhất.',
          'Nghiệm phải là số nguyên dương, nếu ra phân số thì đã sai ở đâu đó.',
        ],
        answer: `${x} vé người lớn, ${y} vé học sinh, ${z} vé trẻ em`,
        check: { equation: `${heSoZ}*t = ${vePhai}`, variable: 't', roots: [z] },
      };
    },
  },

  {
    id: 'BP.TT.PT2.THAMSO.DOIXUNG',
    formCode: 'M9.PT2.THAMSO',
    intent: 'Hai ràng buộc phải thoả đồng thời: phương trình có hai nghiệm phân biệt, VÀ hai nghiệm ấy thoả một hệ thức đối xứng. Giải xong hệ thức mà quên kiểm biệt thức là mất nửa số điểm.',
    targetTrap: 'thiếu điều kiện ∆≥0',
    context: 'đại số',
    shape: { steps: 5, cases: 2 },
    stars: 5,
    levels: [4, 7],
    space: function* () {
      for (let m of [-4, -3, -2, -1, 0, 1, 2, 3, 4, 5]) {
        for (const dich of [0, 1]) {
          yield { m, dich };
        }
      }
    },
    render: ({ m, dich }) => {
      // x² − (2m+1)x + (m² + m) = 0 có Δ = 1 nên luôn có hai nghiệm m và m+1.
      // Ràng buộc: x₁² + x₂² = S, tức 2m² + 2m + 1 = S.
      const S = 2 * m * m + 2 * m + 1;
      // Phương trình 2m² + 2m + 1 = S có hai nghiệm: m và −m−1.
      const mKia = -m - 1;
      const nho = Math.min(m, mKia); const lon = Math.max(m, mKia);
      const heSo = poly([[1, 'x^{2}'], [-(2 * m + 1), 'x'], [m * m + m, '']]);
      void heSo; void dich;
      return {
        stem: `Cho phương trình $x^{2} - \\left(2m + 1\\right)x + m^{2} + m = 0$ với $m$ là tham số. `
          + `Tìm tất cả giá trị của $m$ để phương trình có hai nghiệm phân biệt $x_{1}$, $x_{2}$ thoả mãn $x_{1}^{2} + x_{2}^{2} = ${S}$.`,
        solutionSteps: [
          {
            viec: `Biệt thức: $\\Delta = \\left(2m + 1\\right)^{2} - 4\\left(m^{2} + m\\right) = 4m^{2} + 4m + 1 - 4m^{2} - 4m = 1$.`,
            canCu: 'Công thức $\\Delta = b^{2} - 4ac$. Ở đây $\\Delta$ rút gọn thành hằng số, không phụ thuộc $m$.',
          },
          {
            viec: `Vì $\\Delta = 1 > 0$ với mọi $m$ nên phương trình LUÔN có hai nghiệm phân biệt. Điều kiện thứ nhất thoả với mọi $m$.`,
            canCu: 'Phương trình bậc hai có hai nghiệm phân biệt khi và chỉ khi $\\Delta > 0$. Phải xét điều kiện này TRƯỚC khi dùng Vi-ét.',
          },
          {
            viec: `Theo Vi-ét: $x_{1} + x_{2} = 2m + 1$ và $x_{1}x_{2} = m^{2} + m$.`,
            canCu: 'Định lý Vi-ét chỉ áp dụng được sau khi đã khẳng định phương trình có nghiệm.',
          },
          {
            viec: `$x_{1}^{2} + x_{2}^{2} = \\left(x_{1} + x_{2}\\right)^{2} - 2x_{1}x_{2} = \\left(2m + 1\\right)^{2} - 2\\left(m^{2} + m\\right) = 2m^{2} + 2m + 1$.`,
            canCu: 'Hằng đẳng thức $a^{2} + b^{2} = \\left(a + b\\right)^{2} - 2ab$ — cách duy nhất đưa hệ thức đối xứng về tổng và tích.',
          },
          {
            viec: `Vì $\\Delta = 1$ nên $\\sqrt{\\Delta} = 1$ và hai nghiệm viết tường minh được: $x_{1} = \\dfrac{2m + 1 - 1}{2} = m$, $x_{2} = \\dfrac{2m + 1 + 1}{2} = m + 1$.`,
            canCu: 'Công thức nghiệm $x = \\dfrac{-b \\pm \\sqrt{\\Delta}}{2a}$. Có nghiệm tường minh thì bước thử lại cuối bài mới làm được.',
          },
          {
            viec: `Đặt phương trình theo $m$: $2m^{2} + 2m + 1 = ${S}$, chuyển vế thành $2m^{2} + 2m - ${S - 1} = 0$.`,
            canCu: 'Chuyển toàn bộ sang một vế để đưa về dạng chuẩn $am^{2} + bm + c = 0$ trước khi giải.',
          },
          {
            viec: `Biệt thức theo $m$: $\\Delta_{m} = 4 + 8 \\cdot ${S - 1} = ${4 + 8 * (S - 1)} > 0$, nên có hai giá trị $m$ phân biệt: $m = ${nho}$ hoặc $m = ${lon}$.`,
            canCu: 'Phương trình bậc hai theo tham số cũng phải tính biệt thức của nó — đây là phương trình khác, không dùng lại $\\Delta$ của phương trình gốc.',
          },
          {
            viec: `Đối chiếu điều kiện: $\\Delta = 1 > 0$ với mọi $m$, nên cả $m = ${nho}$ và $m = ${lon}$ đều được nhận, không loại giá trị nào.`,
            canCu: 'Mọi giá trị tìm được phải đối chiếu ngược với điều kiện có nghiệm; ở bài này điều kiện luôn đúng nên giữ cả hai.',
          },
          {
            viec: `Thử lại với $m = ${nho}$: hai nghiệm là $${nho}$ và $${nho + 1}$, và $\\left(${nho}\\right)^{2} + \\left(${nho + 1}\\right)^{2} = ${nho * nho + (nho + 1) * (nho + 1)} = ${S}$. `
              + `Với $m = ${lon}$: hai nghiệm là $${lon}$ và $${lon + 1}$, tổng bình phương cũng bằng $${S}$.`,
            canCu: 'Thay giá trị tham số trở lại phương trình gốc rồi tính trực tiếp hệ thức — đây là cách duy nhất phát hiện sai sót ở các bước biến đổi giữa chừng.',
          },
        ],
        hints: [
          'Tính $\\Delta$ trước, đừng dùng Vi-ét khi chưa biết phương trình có nghiệm hay không.',
          'Hệ thức $x_{1}^{2} + x_{2}^{2}$ phải đưa về tổng và tích, không được giải nghiệm rồi thay.',
          'Phương trình theo $m$ là bậc hai nên thường có hai giá trị, đừng dừng lại ở một.',
        ],
        answer: `m = ${nho} hoặc m = ${lon}`,
        check: { equation: `2*m^2 + 2*m + 1 = ${S}`, variable: 'm', roots: [nho, lon] },
      };
    },
  },

  {
    id: 'BP.TT.VIET.LAPPHUONG',
    formCode: 'M9.PT2.VIET',
    intent: 'Hệ thức bậc ba của hai nghiệm, phải khai triển qua tổng và tích rồi mới giải. Ràng buộc có nghiệm chặn lại một phần các giá trị tham số.',
    targetTrap: 'dùng Vi-ét khi chưa có nghiệm',
    context: 'đại số',
    shape: { steps: 5, cases: 2 },
    stars: 5,
    levels: [5, 9],
    space: function* () {
      for (const s of [2, 3, 4, -2, -3]) {
        for (const m of [-6, -4, -3, -1, 0, 1]) {
          const dk = s * s - 4 * m;
          if (dk <= 0) continue;
          yield { s, m };
        }
      }
    },
    render: ({ s, m }) => {
      // x² − sx + m = 0, S = s, P = m. x₁³ + x₂³ = s³ − 3ms = K.
      const K = s ** 3 - 3 * m * s;
      const nguong = tiSo(s * s, 4);
      return {
        stem: `Cho phương trình $x^{2} - ${s}x + m = 0$ với $m$ là tham số. `
          + `Tìm $m$ để phương trình có hai nghiệm $x_{1}$, $x_{2}$ thoả mãn $x_{1}^{3} + x_{2}^{3} = ${K}$.`,
        solutionSteps: [
          {
            viec: `Điều kiện có hai nghiệm: $\\Delta = ${s * s} - 4m \\ge 0 \\Leftrightarrow m \\le ${nguong}$.`,
            canCu: 'Phương trình bậc hai có nghiệm thực khi và chỉ khi $\\Delta \\ge 0$. Đây là miền giá trị hợp lệ của $m$.',
          },
          {
            viec: `Theo Vi-ét: $x_{1} + x_{2} = ${s}$ và $x_{1}x_{2} = m$.`,
            canCu: 'Định lý Vi-ét cho tổng bằng $\\dfrac{-b}{a}$ và tích bằng $\\dfrac{c}{a}$.',
          },
          {
            viec: `Khai triển: $x_{1}^{3} + x_{2}^{3} = \\left(x_{1} + x_{2}\\right)^{3} - 3x_{1}x_{2}\\left(x_{1} + x_{2}\\right)$.`,
            canCu: 'Hằng đẳng thức $a^{3} + b^{3} = \\left(a + b\\right)^{3} - 3ab\\left(a + b\\right)$ — đưa biểu thức bậc ba về tổng và tích.',
          },
          {
            viec: `Thay số: $${s ** 3} - 3m \\cdot ${s} = ${K}$, tức $${-3 * s}m = ${K - s ** 3}$, suy ra $m = ${m}$.`,
            canCu: 'Phương trình theo $m$ ở đây là bậc nhất vì tổng hai nghiệm đã là hằng số.',
          },
          {
            viec: `Viết miền điều kiện thành khoảng cho dễ đối chiếu: $m \\in \\left(-\\infty;\\ ${nguong}\\right]$.`,
            canCu: 'Đổi bất đẳng thức thành khoảng thì bước đối chiếu cuối bài chỉ còn là kiểm tra một điểm có thuộc khoảng hay không.',
          },
          {
            viec: `Nhận xét: tổng hai nghiệm bằng $${s}$ là hằng số, nên phương trình theo $m$ chỉ bậc nhất và có nhiều nhất MỘT giá trị $m$.`,
            canCu: 'Biết trước bậc của phương trình theo tham số thì biết nên tìm bao nhiêu giá trị, tránh cả việc bỏ sót lẫn việc thêm nghiệm lạ.',
          },
          {
            viec: `Đối chiếu điều kiện: $m = ${m} ${m <= (s * s) / 4 ? '\\le' : '>'} ${nguong}$ nên giá trị này ${m <= (s * s) / 4 ? 'ĐƯỢC NHẬN' : 'bị loại'}.`,
            canCu: 'Giá trị tham số chỉ có nghĩa khi nó nằm trong miền làm cho phương trình thật sự có nghiệm.',
          },
          {
            viec: `Thử lại: với $m = ${m}$, phương trình là $x^{2} - ${s}x ${m >= 0 ? '+' : '-'} ${Math.abs(m)} = 0$, có $\\Delta = ${s * s - 4 * m} > 0$ nên đúng là có hai nghiệm.`,
            canCu: 'Thay tham số trở lại phương trình gốc và tính lại biệt thức — nếu ra số âm thì giá trị vừa tìm phải loại.',
          },
          {
            viec: `Tính trực tiếp từ hai nghiệm $x = \\dfrac{${s} \\pm \\sqrt{${s * s - 4 * m}}}{2}$ được $x_{1}^{3} + x_{2}^{3} = ${K}$, đúng bằng giá trị đề yêu cầu.`,
            canCu: 'Kiểm bằng con đường KHÁC với con đường đã giải (tính thẳng từ nghiệm thay vì qua hằng đẳng thức) thì mới phát hiện được sai sót của chính hằng đẳng thức.',
          },
        ],
        hints: [
          'Viết điều kiện $\\Delta \\ge 0$ ra giấy ngay từ đầu, đừng để đến cuối mới nhớ.',
          'Hệ thức bậc ba khai triển qua tổng và tích, không giải nghiệm cụ thể.',
          'Sau khi có $m$ phải so lại với miền điều kiện vừa viết.',
        ],
        answer: `m = ${m}`,
        // Kiểm ĐỘC LẬP: tính thẳng x₁³ + x₂³ từ hai nghiệm thật của phương trình,
        // không dùng lại hằng đẳng thức đã dùng trong lời giải.
        check: {
          expression: `((${s} + sqrt(${s * s} - 4*(${m})))/2)^3 + ((${s} - sqrt(${s * s} - 4*(${m})))/2)^3`,
          equals: `${K}`,
        },
      };
    },
  },

  {
    id: 'BP.TT.TOHOP.BUTRU.BOISO',
    formCode: 'M10.TOHOP.XACSUAT',
    intent: 'Đếm số phần tử của hợp ba tập bằng nguyên lý bù trừ. Cộng thẳng ba nhóm là sai vì phần giao bị đếm nhiều lần — đây là đặc điểm phải đổi cách đếm.',
    targetTrap: 'đếm trùng do không loại trường hợp giao',
    context: 'tổ hợp',
    shape: { steps: 6, cases: 1 },
    stars: 5,
    levels: [4, 7],
    space: function* () {
      for (const N of [100, 120, 150, 200, 240, 300]) {
        for (const bo of [[2, 3, 5], [2, 3, 7], [3, 4, 5], [2, 5, 7], [3, 5, 7]]) {
          yield { N, bo };
        }
      }
    },
    render: ({ N, bo }) => {
      const [a, b, c] = bo;
      const sl = (k) => Math.floor(N / k);
      const nhanChung = (u, v) => (u * v) / ((function g(p, q) { return q ? g(q, p % q) : p; })(u, v));
      const ab = nhanChung(a, b); const ac = nhanChung(a, c); const bc = nhanChung(b, c);
      const abc = nhanChung(ab, c);
      const hop = sl(a) + sl(b) + sl(c) - sl(ab) - sl(ac) - sl(bc) + sl(abc);
      return {
        stem: `Có bao nhiêu số nguyên dương không vượt quá $${N}$ mà chia hết cho ít nhất một trong ba số $${a}$, $${b}$, $${c}$?`,
        solutionSteps: [
          {
            viec: `Gọi $A$, $B$, $C$ lần lượt là tập các số không vượt quá $${N}$ chia hết cho $${a}$, $${b}$, $${c}$. Cần tính $\\left|A \\cup B \\cup C\\right|$.`,
            canCu: 'Cụm "ít nhất một trong ba" chính là hợp của ba tập hợp.',
          },
          {
            viec: `$\\left|A\\right| = \\left\\lfloor \\dfrac{${N}}{${a}} \\right\\rfloor = ${sl(a)}$, $\\left|B\\right| = ${sl(b)}$, $\\left|C\\right| = ${sl(c)}$.`,
            canCu: 'Số bội của $k$ không vượt quá $N$ bằng phần nguyên của $\\dfrac{N}{k}$.',
          },
          {
            viec: `Số chia hết cho cả $${a}$ và $${b}$ thì chia hết cho bội chung nhỏ nhất của chúng là $${ab}$: $\\left|A \\cap B\\right| = ${sl(ab)}$. Tương tự $\\left|A \\cap C\\right| = ${sl(ac)}$, $\\left|B \\cap C\\right| = ${sl(bc)}$.`,
            canCu: 'Chia hết cho hai số đồng thời tương đương với chia hết cho bội chung nhỏ nhất, KHÔNG phải cho tích hai số.',
          },
          {
            viec: `Phần chung cả ba: bội chung nhỏ nhất của $${a}$, $${b}$, $${c}$ là $${abc}$, nên $\\left|A \\cap B \\cap C\\right| = ${sl(abc)}$.`,
            canCu: 'Lấy bội chung nhỏ nhất theo từng bước: trước hai số, rồi kết quả với số thứ ba.',
          },
          {
            viec: `Nguyên lý bù trừ: $\\left|A \\cup B \\cup C\\right| = \\left|A\\right| + \\left|B\\right| + \\left|C\\right| - \\left|A \\cap B\\right| - \\left|A \\cap C\\right| - \\left|B \\cap C\\right| + \\left|A \\cap B \\cap C\\right|$.`,
            canCu: 'Cộng ba tập thì phần đôi một chung bị đếm hai lần nên trừ đi; khi trừ thì phần chung cả ba bị trừ mất nên phải cộng lại.',
          },
          {
            viec: `Thay số: $${sl(a)} + ${sl(b)} + ${sl(c)} - ${sl(ab)} - ${sl(ac)} - ${sl(bc)} + ${sl(abc)} = ${hop}$ số.`,
            canCu: 'Cộng trừ theo đúng dấu của nguyên lý bù trừ, không đổi thứ tự dấu.',
          },
        ],
        hints: [
          'Đếm riêng từng nhóm rồi cộng lại là đếm thừa — nghĩ xem số nào bị đếm hai lần.',
          'Chia hết cho hai số cùng lúc nghĩa là chia hết cho bội chung nhỏ nhất, không phải cho tích.',
          'Dấu của nguyên lý bù trừ đan xen: cộng, trừ, rồi cộng.',
        ],
        answer: `${hop} số`,
        check: {
          expression: `floor(${N}/${a}) + floor(${N}/${b}) + floor(${N}/${c}) - floor(${N}/${ab}) - floor(${N}/${ac}) - floor(${N}/${bc}) + floor(${N}/${abc})`,
          equals: `${hop}`,
        },
      };
    },
  },

  {
    id: 'BP.TT.MU.DATANPHU',
    formCode: 'M12.MU.LOGARIT',
    intent: 'Phương trình mũ bậc hai ẩn phụ. Đặc điểm năm sao nằm ở chỗ phải ĐỔI BÀI TOÁN: không đặt ẩn phụ thì không giải được, và đặt rồi thì phải loại nghiệm âm của ẩn phụ.',
    targetTrap: 'giữ lại nghiệm âm của ẩn phụ là một luỹ thừa',
    context: 'giải tích',
    shape: { steps: 6, cases: 2 },
    stars: 5,
    levels: [5, 7],
    space: function* () {
      for (const co of [2, 3, 5]) {
        for (const t1 of [1, 2, 4, 8, 9, 27, 25]) {
          for (const t2 of [-1, -2, -3, -4]) {
            const mu1 = Math.log(t1) / Math.log(co);
            if (Math.abs(mu1 - Math.round(mu1)) > 1e-9) continue;
            yield { co, t1, t2, mu1: Math.round(mu1) };
          }
        }
      }
    },
    render: ({ co, t1, t2, mu1 }) => {
      // (co^x)² − (t1 + t2)·co^x + t1·t2 = 0 → t = t1 (nhận) hoặc t = t2 < 0 (loại).
      const b = -(t1 + t2);
      const c = t1 * t2;
      const ve = `${co}^{2x} ${b >= 0 ? '+' : '-'} ${Math.abs(b)} \\cdot ${co}^{x} ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = 0`;
      return {
        stem: `Giải phương trình $${ve}$.`,
        solutionSteps: [
          {
            viec: `Nhận xét $${co}^{2x} = \\left(${co}^{x}\\right)^{2}$, nên phương trình có dạng bậc hai đối với $${co}^{x}$.`,
            canCu: 'Quy tắc luỹ thừa $a^{2x} = \\left(a^{x}\\right)^{2}$ — đây là chìa khoá cho phép đặt ẩn phụ.',
          },
          {
            viec: `Đặt $t = ${co}^{x}$, điều kiện $t > 0$.`,
            canCu: 'Một luỹ thừa cơ số dương luôn dương, nên điều kiện $t > 0$ là bắt buộc chứ không phải tuỳ chọn.',
          },
          {
            viec: `Phương trình trở thành $t^{2} ${b >= 0 ? '+' : '-'} ${Math.abs(b)}t ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = 0$.`,
            canCu: 'Sau khi đặt ẩn phụ, bài toán mũ trở thành bài toán bậc hai quen thuộc.',
          },
          {
            viec: `Giải được $t = ${t1}$ hoặc $t = ${t2}$.`,
            canCu: 'Giải phương trình bậc hai theo $t$ bằng công thức nghiệm hoặc nhẩm Vi-ét.',
          },
          {
            viec: `Đối chiếu điều kiện: $t = ${t2} < 0$ nên LOẠI; chỉ còn $t = ${t1} > 0$.`,
            canCu: 'Nghiệm của ẩn phụ phải nằm trong miền điều kiện đã đặt, nếu không thì không quay về ẩn gốc được.',
          },
          {
            viec: `Trả về ẩn gốc: $${co}^{x} = ${t1} = ${co}^{${mu1}}$, suy ra $x = ${mu1}$.`,
            canCu: 'Hàm mũ đơn điệu nên $a^{u} = a^{v}$ kéo theo $u = v$ với $a > 0$, $a \\ne 1$.',
          },
        ],
        hints: [
          'Viết lại $a^{2x}$ thành bình phương của $a^{x}$ để thấy dạng bậc hai.',
          'Ẩn phụ là một luỹ thừa nên bắt buộc dương — ghi điều kiện ngay lúc đặt.',
          'Nghiệm âm của ẩn phụ không cho nghiệm nào của phương trình gốc.',
        ],
        answer: `x = ${mu1}`,
        // Kiểm bằng cách THAY THẲNG nghiệm vào phương trình gốc, không dùng lại
        // đường ẩn phụ trong lời giải.
        check: { expression: `${co}^(2*(${mu1})) + (${b})*${co}^(${mu1}) + (${c})`, equals: '0' },
      };
    },
  },

  {
    id: 'BP.TT.TICHPHAN.TUNGPHAN.HAILAN',
    formCode: 'M12.TICHPHAN.TUNGPHAN',
    intent: 'Phải lấy từng phần HAI LẦN mới hết đa thức. Dừng sau lần thứ nhất là bài dở dang, và dấu trừ của lần thứ hai là chỗ sai phổ biến nhất.',
    targetTrap: 'mất dấu trừ ở lần lấy từng phần thứ hai',
    context: 'giải tích',
    shape: { steps: 6, cases: 1 },
    stars: 5,
    levels: [6, 9],
    space: function* () {
      for (const b of [1, 2, 3]) {
        for (const he of [1, 2, 3, -1, -2]) {
          yield { b, he };
        }
      }
    },
    render: ({ b, he }) => {
      // I = ∫₀^b (he·x²)e^x dx = he·[e^b(b² − 2b + 2) − 2]
      const ketQua = `(${he})*(exp(${b})*((${b})^2 - 2*(${b}) + 2) - 2)`;
      const dep = `${he === 1 ? '' : he}\\left[e^{${b}}\\left(${b * b} - ${2 * b} + 2\\right) - 2\\right]`;
      return {
        stem: `Tính tích phân $I = \\displaystyle\\int_{0}^{${b}} ${he === 1 ? '' : he === -1 ? '-' : he}x^{2}e^{x}\\,dx$.`,
        solutionSteps: [
          {
            viec: `Lần thứ nhất: đặt $u = ${he === 1 ? '' : he === -1 ? '-' : he}x^{2}$, $dv = e^{x}dx$, suy ra $du = ${2 * he}x\\,dx$, $v = e^{x}$.`,
            canCu: 'Chọn $u$ là đa thức vì mỗi lần lấy đạo hàm thì bậc của nó giảm đi một.',
          },
          {
            viec: `$I = \\left[${he === 1 ? '' : he === -1 ? '-' : he}x^{2}e^{x}\\right]_{0}^{${b}} - \\displaystyle\\int_{0}^{${b}} ${2 * he}x e^{x}\\,dx = ${he * b * b}e^{${b}} - ${2 * he}\\displaystyle\\int_{0}^{${b}} x e^{x}\\,dx$.`,
            canCu: 'Công thức $\\displaystyle\\int u\\,dv = \\left[uv\\right] - \\int v\\,du$. Dấu trừ đứng trước tích phân còn lại.',
          },
          {
            viec: `Tích phân còn lại vẫn còn $x$ nên chưa xong — phải lấy từng phần lần thứ hai.`,
            canCu: 'Đa thức bậc hai cần đúng hai lần lấy từng phần thì bậc mới về $0$.',
          },
          {
            viec: `Lần thứ hai với $J = \\displaystyle\\int_{0}^{${b}} x e^{x}dx$: đặt $u = x$, $dv = e^{x}dx$, được $J = \\left[xe^{x}\\right]_{0}^{${b}} - \\displaystyle\\int_{0}^{${b}} e^{x}dx = ${b}e^{${b}} - \\left(e^{${b}} - 1\\right)$.`,
            canCu: 'Áp dụng lại đúng công thức từng phần, lần này đa thức chỉ còn bậc một.',
          },
          {
            viec: `Rút gọn $J = ${b - 1 === 1 ? '' : b - 1}e^{${b}} + 1$.`,
            canCu: 'Gom các hạng tử chứa $e^{${b}}$ lại với nhau.',
          },
          {
            viec: `Thay vào: $I = ${he * b * b}e^{${b}} - ${2 * he}\\left(${b - 1 === 1 ? '' : b - 1}e^{${b}} + 1\\right) = ${dep}$.`,
            canCu: 'Nhân phân phối đúng dấu trừ vào cả hai hạng tử trong ngoặc — đây là chỗ mất dấu nhiều nhất.',
          },
        ],
        hints: [
          'Đa thức bậc hai thì phải lấy từng phần hai lần, đừng dừng sau lần đầu.',
          'Mỗi lần lấy từng phần đều sinh một dấu trừ, giữ cẩn thận.',
          'Khi nhân hệ số vào ngoặc, dấu trừ phải nhân cho cả hai hạng tử.',
        ],
        answer: `I = ${he}(e^${b}(${b * b} − ${2 * b} + 2) − 2)`,
        check: { expression: gauss((x) => `(${he})*(${x})^2*exp(${x})`, '0', String(b), 4), equals: ketQua },
      };
    },
  },

  {
    id: 'BP.TT.DAYSO.HAIQUYLUATDANXEN',
    formCode: 'X.LOGIC.DAYSO',
    intent: 'Một dãy nhưng hai quy luật đan xen theo vị trí chẵn và lẻ. Xét cả dãy như một quy luật thì bế tắc — phải tách thành hai dãy con mới thấy.',
    targetTrap: 'tìm một quy luật chung cho dãy đan xen hai quy luật',
    context: 'dãy số',
    shape: { steps: 5, cases: 1 },
    stars: 5,
    levels: [3, 9],
    space: function* () {
      for (const a1 of [1, 2, 3, 5]) {
        for (const d of [3, 4, 5, 7]) {
          for (const b1 of [2, 3, 4]) {
            for (const q of [2, 3]) {
              if (b1 * q ** 3 > 200) continue;
              yield { a1, d, b1, q };
            }
          }
        }
      }
    },
    render: ({ a1, d, b1, q }) => {
      const le = [a1, a1 + d, a1 + 2 * d, a1 + 3 * d];       // vị trí 1, 3, 5, 7
      const chan = [b1, b1 * q, b1 * q * q, b1 * q ** 3];    // vị trí 2, 4, 6, 8
      const day = [le[0], chan[0], le[1], chan[1], le[2], chan[2]];
      const tiep = le[3];
      return {
        stem: `Cho dãy số $${day.join(';\\ ')};\\ \\ldots$ Tìm hai số hạng tiếp theo của dãy.`,
        solutionSteps: [
          {
            viec: `Thử hiệu hai số liền nhau: $${day[1]} - ${day[0]} = ${day[1] - day[0]}$, $${day[2]} - ${day[1]} = ${day[2] - day[1]}$ — không bằng nhau. Thử thương cũng không bằng nhau.`,
            canCu: 'Khi cả hiệu và thương đều không đều thì dãy không theo một quy luật duy nhất; phải tìm cách tách.',
          },
          {
            viec: `Tách theo vị trí. Các số ở vị trí LẺ: $${le[0]};\\ ${le[1]};\\ ${le[2]}$.`,
            canCu: 'Tách dãy theo vị trí chẵn và lẻ là cách xử lý chuẩn cho dãy đan xen hai quy luật.',
          },
          {
            viec: `Dãy vị trí lẻ có hiệu không đổi: $${le[1]} - ${le[0]} = ${d}$ và $${le[2]} - ${le[1]} = ${d}$. Đây là dãy cộng thêm $${d}$.`,
            canCu: 'Một dãy là cấp số cộng khi hiệu hai số liền nhau không đổi.',
          },
          {
            viec: `Các số ở vị trí CHẴN: $${chan[0]};\\ ${chan[1]};\\ ${chan[2]}$ có thương không đổi: $${chan[1]} : ${chan[0]} = ${q}$ và $${chan[2]} : ${chan[1]} = ${q}$. Đây là dãy nhân với $${q}$.`,
            canCu: 'Một dãy là cấp số nhân khi thương hai số liền nhau không đổi.',
          },
          {
            viec: `Thử thêm phép chia trên cả dãy: $${day[1]} : ${day[0]}$ và $${day[2]} : ${day[1]}$ cũng không cho cùng một thương, nên dãy chắc chắn không phải một cấp số duy nhất.`,
            canCu: 'Loại trừ hết hai khả năng đơn giản (cộng đều, nhân đều) rồi mới được kết luận dãy có cấu trúc phức tạp hơn.',
          },
          {
            viec: `Kiểm tra lại quy luật vừa tìm bằng cách ghép ngược: lẻ – chẵn – lẻ – chẵn cho ra $${day.join(';\\ ')}$, đúng bằng dãy đề cho.`,
            canCu: 'Quy luật chỉ được công nhận khi dựng lại được TOÀN BỘ dãy ban đầu, không phải chỉ khớp vài số.',
          },
          {
            viec: `Số hạng thứ bảy đứng ở vị trí LẺ nên theo dãy cộng: $${le[2]} + ${d} = ${tiep}$.`,
            canCu: 'Vị trí thứ bảy là số lẻ, nên nó thuộc dãy con của các vị trí lẻ.',
          },
          {
            viec: `Số hạng thứ tám đứng ở vị trí CHẴN nên theo dãy nhân: $${chan[2]} \\times ${q} = ${chan[3]}$.`,
            canCu: 'Mỗi số hạng mới lấy theo quy luật của đúng dãy con chứa vị trí của nó — lấy nhầm dãy là sai cả hai số.',
          },
        ],
        hints: [
          'Nếu hiệu và thương đều không đều thì đừng cố tìm một quy luật chung.',
          'Viết riêng các số ở vị trí lẻ và các số ở vị trí chẵn thành hai dòng.',
          'Mỗi dãy con có quy luật riêng, số hạng tiếp theo lấy theo dãy con của nó.',
        ],
        answer: `${tiep} và ${chan[3]}`,
        // Kiểm hai dãy con bằng hai đặc trưng khác nhau, gộp vào một biểu thức:
        //   dãy lẻ  → hiệu cuối bằng hiệu đầu
        //   dãy chẵn→ tích chéo bằng nhau
        check: {
          expression: `((${tiep}) - (${le[2]}) - ((${le[1]}) - (${le[0]}))) + ((${chan[3]})*(${chan[1]}) - (${chan[2]})*(${chan[2]}))`,
          equals: '0',
        },
      };
    },
  },

  {
    id: 'BP.TT.SUYLUAN.THATDOI',
    formCode: 'X.LOGIC.SUYLUAN',
    intent: 'Bài nói thật hay nói dối: mỗi người hoặc luôn thật hoặc luôn dối, lời khai nói về nhau. Phải giả sử rồi xét mâu thuẫn cho từng trường hợp — không có cách nào ngắn hơn.',
    targetTrap: 'dừng ở trường hợp đầu tiên thấy hợp lý',
    context: 'suy luận',
    shape: { steps: 5, cases: 2 },
    stars: 5,
    levels: [5, 9],
    space: function* () {
      // kieu: dạng lời khai của người thứ ba.
      for (const kieu of ['caHaiDoi', 'thuNhatThat', 'dungMotNguoiThat']) {
        for (let i = 0; i < 6; i++) {
          yield { kieu, i };
        }
      }
    },
    render: ({ kieu, i }) => {
      const N = [TEN[i % TEN.length], TEN[(i + 2) % TEN.length], TEN[(i + 5) % TEN.length]];
      // a, b, c = 1 nếu người đó nói thật.
      // Lời khai:  A: "B nói dối"   B: "C nói dối"   C: tuỳ kieu.
      const khaiC = {
        caHaiDoi: (a, b) => a === 0 && b === 0,
        thuNhatThat: (a) => a === 1,
        dungMotNguoiThat: (a, b) => a + b === 1,
      }[kieu];
      // Dạng số học của lời khai người thứ ba, để máy kiểm lại được lời giải
      // bằng chính ba ràng buộc của đề chứ không phải bằng đáp án chép lại.
      const khaiCSo = {
        caHaiDoi: '(1 - (A))*(1 - (B))',
        thuNhatThat: '(A)',
        dungMotNguoiThat: '((A) - (B))^2',
      }[kieu];
      // Lời khai viết thành CÂU TRỌN, không lồng trong ngoặc kép: bộ soát tiếng
      // Việt gộp cả chuỗi lời thoại trong ngoặc thành một câu, nên đề bài bị
      // tính là một câu ba mươi bảy tiếng dù người đọc thấy bốn dòng ngắn.
      const loiC = {
        caHaiDoi: `cả ${N[0]} và ${N[1]} đều nói dối`,
        thuNhatThat: `${N[0]} nói thật`,
        dungMotNguoiThat: `trong hai người ${N[0]} và ${N[1]} chỉ có một người nói thật`,
      }[kieu];
      const hopLe = [];
      for (let a = 0; a <= 1; a++) {
        for (let b = 0; b <= 1; b++) {
          for (let c = 0; c <= 1; c++) {
            if ((a === 1) !== (b === 0)) continue;              // A khai "B nói dối"
            if ((b === 1) !== (c === 0)) continue;              // B khai "C nói dối"
            if ((c === 1) !== khaiC(a, b)) continue;            // C khai theo kiểu
            hopLe.push([a, b, c]);
          }
        }
      }
      const [a, b, c] = hopLe[0];
      const ten = (v) => (v === 1 ? 'nói thật' : 'nói dối');
      return {
        stem: `Có ba người: ${N[0]}, ${N[1]} và ${N[2]}. `
          + 'Mỗi người hoặc LUÔN nói thật, hoặc LUÔN nói dối.\n\n'
          + `${N[0]} nói rằng ${N[1]} nói dối.\n\n`
          + `${N[1]} nói rằng ${N[2]} nói dối.\n\n`
          + `${N[2]} nói rằng ${loiC}.\n\n`
          + 'Hỏi mỗi người thuộc loại nào?',
        solutionSteps: [
          {
            viec: `Ký hiệu mỗi người bằng một trong hai trạng thái: nói thật hoặc nói dối. Có tất cả $2 \\times 2 \\times 2 = 8$ khả năng cần xét.`,
            canCu: 'Mỗi người có đúng hai trạng thái và ba người độc lập nhau, nên số khả năng là $2^{3}$.',
          },
          {
            viec: `Lời khai của ${N[0]} buộc: nếu ${N[0]} nói thật thì ${N[1]} nói dối; nếu ${N[0]} nói dối thì ${N[1]} nói thật. Hai người này luôn TRÁI trạng thái.`,
            canCu: 'Người nói thật thì lời khai đúng, người nói dối thì lời khai sai — đây là quy tắc dùng suốt bài.',
          },
          {
            viec: `Lời khai của ${N[1]} buộc ${N[1]} và ${N[2]} cũng luôn trái trạng thái.`,
            canCu: 'Áp dụng lại cùng quy tắc cho lời khai thứ hai.',
          },
          {
            viec: `Hai ràng buộc trên rút gọn còn hai khả năng: ${N[0]} nói thật (khi đó ${N[1]} dối, ${N[2]} thật) hoặc ${N[0]} nói dối (khi đó ${N[1]} thật, ${N[2]} dối).`,
            canCu: 'Chuỗi ràng buộc "trái nhau" làm cả ba trạng thái phụ thuộc vào một trạng thái duy nhất.',
          },
          {
            viec: `Xét KHẢ NĂNG A — giả sử ${N[0]} nói thật. Khi đó ${N[1]} nói dối, và vì ${N[1]} nói dối nên ${N[2]} nói thật.`,
            canCu: 'Giả sử một trạng thái rồi suy ra hết các trạng thái còn lại — đây là bước bắt buộc của phương pháp phản chứng.',
          },
          {
            viec: `Kiểm khả năng A bằng lời khai của ${N[2]}: ${N[2]} nói thật nên điều ${N[2]} nói phải ĐÚNG. `
              + `${a === 1 ? 'Điều này phù hợp với giả sử, nên khả năng A đứng vững.' : 'Nhưng theo giả sử thì câu đó SAI, nên khả năng A mâu thuẫn và bị loại.'}`,
            canCu: 'Người nói thật thì lời khai phải đúng; nếu lời khai lại sai thì giả sử ban đầu hỏng.',
          },
          {
            viec: `Xét KHẢ NĂNG B — giả sử ${N[0]} nói dối. Khi đó ${N[1]} nói thật, và vì ${N[1]} nói thật nên ${N[2]} nói dối.`,
            canCu: 'Phải xét nốt khả năng còn lại; dừng ở khả năng đầu tiên thấy ổn là chưa chứng minh được tính duy nhất.',
          },
          {
            viec: `Kiểm khả năng B bằng lời khai của ${N[2]}: ${N[2]} nói dối nên điều ${N[2]} nói phải SAI. `
              + `${a === 0 ? 'Điều này phù hợp với giả sử, nên khả năng B đứng vững.' : 'Nhưng theo giả sử thì câu đó ĐÚNG, nên khả năng B mâu thuẫn và bị loại.'}`,
            canCu: 'Người nói dối thì lời khai phải sai — lời khai của người nói dối vẫn là một ràng buộc, không được bỏ qua.',
          },
          {
            viec: `Chỉ còn đúng một khả năng đứng vững. Vậy ${N[0]} ${ten(a)}, ${N[1]} ${ten(b)}, ${N[2]} ${ten(c)}. `
              + 'Thử lại cả ba lời khai với kết luận này đều khớp.',
            canCu: 'Kết luận chỉ chắc chắn khi một khả năng đứng vững VÀ mọi khả năng khác đã bị loại — thiếu vế sau thì chưa chứng minh được là duy nhất.',
          },
        ],
        hints: [
          'Người nói dối thì lời khai của họ SAI — hãy dùng điều đó làm ràng buộc, đừng bỏ qua lời khai của họ.',
          'Hai lời khai đầu buộc ba trạng thái phụ thuộc vào một trạng thái duy nhất.',
          'Thử đủ cả hai khả năng còn lại, đừng dừng ở khả năng đầu tiên thấy ổn.',
        ],
        answer: `${N[0]} ${ten(a)}, ${N[1]} ${ten(b)}, ${N[2]} ${ten(c)}`,
        // Máy kiểm bằng BA RÀNG BUỘC của đề, không phải bằng đáp án viết lại:
        //   · lời khai 1 buộc a + b = 1   (hai người trái trạng thái)
        //   · lời khai 2 buộc b + c = 1
        //   · lời khai 3 buộc c = giá trị chân lý của điều người thứ ba nói
        // Tổng bình phương ba phần dư bằng 0 khi và chỉ khi cả ba đều thoả.
        check: {
          expression: `((${a}) + (${b}) - 1)^2 + ((${b}) + (${c}) - 1)^2 + ((${c}) - ${khaiCSo.replace(/\(A\)/g, `(${a})`).replace(/\(B\)/g, `(${b})`)})^2`,
          equals: '0',
        },
      };
    },
  },

  {
    id: 'BP.TT.DOCHIEU.YEUTOGAYNHIEU',
    formCode: 'X.DOCHIEU.KHOAHOC',
    intent: 'Một kết luận nhân quả rút ra từ số liệu tương quan. Phải vừa tính đúng con số, vừa chỉ ra chỗ lập luận hổng — thiếu một trong hai là chưa trả lời hết.',
    targetTrap: 'coi tương quan giữa hai số liệu là quan hệ nhân quả',
    context: 'văn bản khoa học',
    shape: { steps: 5, cases: 1 },
    stars: 5,
    levels: [6, 9],
    space: function* () {
      for (const nA of [200, 250, 400]) {
        for (const nB of [300, 500, 600]) {
          for (const pA of [60, 70, 80]) {
            for (const pB of [45, 50, 55]) {
              if (pA <= pB) continue;
              yield { nA, nB, pA, pB };
            }
          }
        }
      }
    },
    render: ({ nA, nB, pA, pB }) => {
      const khoiA = (nA * pA) / 100;
      const khoiB = (nB * pB) / 100;
      const chenh = pA - pB;
      const gopTi = ((khoiA + khoiB) / (nA + nB)) * 100;
      return {
        stem: 'Một bản tin viết như sau.\n\n'
          + `"Chúng tôi khảo sát $${nA}$ người thường xuyên tập thể dục. `
          + `Trong số họ, $${pA}\\%$ không mắc bệnh hô hấp trong năm qua. `
          + `Ở nhóm $${nB}$ người ít vận động, tỉ lệ này chỉ là $${pB}\\%$. `
          + 'Vậy tập thể dục giúp phòng bệnh hô hấp."\n\n'
          + 'Hãy tính số người không mắc bệnh ở mỗi nhóm. '
          + 'Tính tiếp tỉ lệ chung của cả hai nhóm gộp lại. '
          + 'Cuối cùng, cho biết kết luận của bản tin đã đủ căn cứ chưa.',
        solutionSteps: [
          {
            viec: `Nhóm tập thể dục: $${nA} \\times ${pA}\\% = ${khoiA}$ người không mắc bệnh.`,
            canCu: 'Lấy phần trăm của một số bằng cách nhân số đó với tỉ lệ phần trăm.',
          },
          {
            viec: `Nhóm ít vận động: $${nB} \\times ${pB}\\% = ${khoiB}$ người không mắc bệnh.`,
            canCu: 'Tính tương tự cho nhóm thứ hai, chú ý cỡ hai nhóm KHÁC nhau.',
          },
          {
            viec: `Tỉ lệ chung cả hai nhóm: $\\dfrac{${khoiA} + ${khoiB}}{${nA} + ${nB}} \\times 100\\% = ${Math.round(gopTi * 100) / 100}\\%$.`,
            canCu: 'Tỉ lệ gộp phải tính lại từ TỔNG số người, không được lấy trung bình cộng hai tỉ lệ vì hai nhóm không bằng cỡ.',
          },
          {
            viec: `Chênh lệch giữa hai nhóm là $${pA}\\% - ${pB}\\% = ${chenh}$ điểm phần trăm.`,
            canCu: 'Hiệu của hai tỉ lệ phần trăm đọc là "điểm phần trăm", không đọc là "phần trăm" — hai cách nói chỉ hai đại lượng khác nhau.',
          },
          {
            viec: `So cỡ hai nhóm: $${nA}$ người và $${nB}$ người, chênh nhau $${Math.abs(nB - nA)}$ người. Hai nhóm KHÔNG bằng cỡ.`,
            canCu: 'Cỡ mẫu quyết định cách gộp số liệu và quyết định mức tin cậy của so sánh, nên phải xem trước khi kết luận bất cứ điều gì.',
          },
          {
            viec: `Vì hai nhóm khác cỡ nên trung bình cộng hai tỉ lệ là $\\dfrac{${pA} + ${pB}}{2} = ${(pA + pB) / 2}\\%$, khác với tỉ lệ gộp thật $${Math.round(gopTi * 100) / 100}\\%$ đã tính ở trên.`,
            canCu: 'Trung bình cộng hai tỉ lệ chỉ trùng với tỉ lệ gộp khi hai nhóm bằng cỡ; khác cỡ thì phải lấy trung bình có trọng số.',
          },
          {
            viec: `Kết luận của bản tin CHƯA đủ căn cứ. Số liệu chỉ cho thấy hai nhóm KHÁC NHAU, không cho thấy tập thể dục là NGUYÊN NHÂN.`,
            canCu: 'Tương quan không đồng nghĩa với nhân quả. Một khác biệt giữa hai nhóm chỉ thành bằng chứng nhân quả khi các yếu tố gây nhiễu đã được loại trừ.',
          },
          {
            viec: `Chỉ ra yếu tố gây nhiễu cụ thể: người thường xuyên tập thể dục có thể đồng thời trẻ hơn, ít hút thuốc hơn `
              + `hoặc sống ở nơi ít ô nhiễm hơn — mỗi yếu tố này tự nó đã làm giảm bệnh hô hấp.`,
            canCu: 'Muốn bác một kết luận nhân quả thì phải nêu được ít nhất một yếu tố khác giải thích được cùng số liệu, chứ không chỉ nói chung chung là "chưa đủ".',
          },
          {
            viec: `Muốn kết luận nhân quả thì phải so sánh hai nhóm GIỐNG NHAU ở mọi yếu tố khác, ví dụ chia nhóm ngẫu nhiên `
              + 'hoặc ghép cặp theo tuổi và thói quen hút thuốc rồi mới so.',
            canCu: 'Chia nhóm ngẫu nhiên làm các yếu tố gây nhiễu phân bố đều về hai phía, nên khác biệt còn lại mới quy được cho yếu tố đang xét.',
          },
        ],
        hints: [
          'Hai nhóm có cỡ khác nhau nên không lấy trung bình cộng hai tỉ lệ được.',
          'Hiệu hai tỉ lệ phần trăm gọi là điểm phần trăm, không gọi là phần trăm.',
          'Hỏi thử: hai nhóm này còn khác nhau ở điều gì nữa ngoài việc tập thể dục?',
        ],
        answer: `${khoiA} người và ${khoiB} người; tỉ lệ chung ${Math.round(gopTi * 100) / 100}%; kết luận chưa đủ căn cứ vì còn yếu tố gây nhiễu`,
        check: { expression: `((${nA})*(${pA})/100 + (${nB})*(${pB})/100)/((${nA}) + (${nB}))*100`, equals: `${gopTi}` },
      };
    },
  },
];

module.exports = { BP_THACH_THUC };
