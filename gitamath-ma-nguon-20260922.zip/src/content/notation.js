'use strict';
/**
 * CHUẨN KÝ HIỆU TOÁN — cưỡng chế điều A02 Hiến pháp.
 * Cấm  /  ^  sqrt()  thô trong nội dung hiển thị. Bắt buộc \dfrac, ^{}, \sqrt{}.
 * normalize() tự chuyển; validate() từ chối phần còn sai.
 */

// Vùng được phép chứa ký tự thô: \text{...}, \operatorname{...}, và lệnh LaTeX
const PROTECT = [
  /\\text\{[^{}]*\}/g,
  /\\operatorname\{[^{}]*\}/g,
  /\\begin\{[^{}]*\}/g,
  /\\end\{[^{}]*\}/g,
];

function protect(s) {
  const store = [];
  let out = s;
  for (const re of PROTECT) {
    out = out.replace(re, (m) => {
      store.push(m);
      return `\u0000${store.length - 1}\u0000`;
    });
  }
  return { out, store };
}

function restore(s, store) {
  return s.replace(/\u0000(\d+)\u0000/g, (_, i) => store[Number(i)]);
}

function normalize(expr) {
  if (typeof expr !== 'string') return expr;
  const { out: protectedStr, store } = protect(expr);
  let s = protectedStr;

  // sqrt(x) → \sqrt{x}  (lồng nhau: lặp tới khi hết)
  for (let i = 0; i < 5; i++) {
    const before = s;
    s = s.replace(/(?<!\\)\bsqrt\s*\(([^()]*)\)/g, '\\sqrt{$1}');
    if (s === before) break;
  }

  // a/b → \dfrac{a}{b} với a,b là số hoặc biến có chỉ số
  const TERM = String.raw`-?\d+(?:\.\d+)?|[a-zA-Z](?:_\{?\w+\}?)?`;
  s = s.replace(
    new RegExp(String.raw`(?<![\w\\}])(${TERM})\s*\/\s*(${TERM})(?![\w])`, 'g'),
    (_, a, b) => `\\dfrac{${a}}{${b}}`
  );

  // x^2 → x^{2} ; x ^ 2 → x^{2} ; x^-1 → x^{-1}
  s = s.replace(/([a-zA-Z0-9)\]}])\s*\^\s*(-?\d+|[a-zA-Z])(?![\w{])/g, '$1^{$2}');

  // Tập số
  s = s.replace(/(?<![\\\w])\bR\b/g, '\\mathbb{R}')
    .replace(/(?<![\\\w])\bN\b/g, '\\mathbb{N}')
    .replace(/(?<![\\\w])\bZ\b/g, '\\mathbb{Z}')
    .replace(/(?<![\\\w])\bQ\b/g, '\\mathbb{Q}');

  // Toán tử so sánh và mũi tên
  s = s.replace(/<=/g, '\\le ').replace(/>=/g, '\\ge ')
    .replace(/!=/g, '\\ne ').replace(/\+-/g, '\\pm ')
    .replace(/->/g, '\\to ').replace(/=>/g, '\\Rightarrow ')
    .replace(/(?<!\\)\binf\b/g, '\\infty');

  s = s.replace(/[ \t]{2,}/g, ' ').trim();
  return restore(s, store);
}

const RULES = [
  { id: 'N1', re: /(?<![\w\\}])\d+\s*\/\s*\d+/, msg: 'Dùng / cho phân số — phải dùng \\dfrac{a}{b}' },
  { id: 'N2', re: /(?<![\\a-zA-Z])\^\s*-?\d{2,}/, msg: 'Số mũ nhiều chữ số phải đặt trong ngoặc: ^{12}' },
  { id: 'N3', re: /(?<!\\)\bsqrt\s*\(/, msg: 'Dùng sqrt() — phải dùng \\sqrt{}' },
  { id: 'N4', re: /(?<!\\)\b(sin|cos|tan|log|ln|lim|max|min)\s*\(/, msg: 'Hàm toán phải có dấu gạch chéo: \\sin, \\log …' },
  // Dấu sao ở chỉ số trên là ký hiệu chuẩn (\mathbb{N}^{*} — tập số tự nhiên khác 0),
  // không phải phép nhân, nên không tính là lỗi.
  { id: 'N5', re: /(?<!\^\{)\*(?!\})/, msg: 'Dùng * cho phép nhân — phải dùng \\cdot hoặc \\times' },
];

function validate(expr) {
  if (typeof expr !== 'string') return { ok: false, errors: [{ id: 'N0', msg: 'Không phải chuỗi' }] };
  const { out } = protect(expr);
  const errors = [];
  for (const r of RULES) if (r.re.test(out)) errors.push({ id: r.id, msg: r.msg });

  // Cân bằng ngoặc nhọn
  let depth = 0;
  for (let i = 0; i < out.length; i++) {
    if (out[i] === '{' && out[i - 1] !== '\\') depth++;
    if (out[i] === '}' && out[i - 1] !== '\\') depth--;
    if (depth < 0) break;
  }
  if (depth !== 0) errors.push({ id: 'N6', msg: 'Ngoặc nhọn { } không cân bằng' });

  return { ok: errors.length === 0, errors };
}

/** Chuẩn hoá rồi kiểm tra — dùng trong pipeline biên soạn. */
function enforce(expr) {
  const normalized = normalize(expr);
  const v = validate(normalized);
  return { ok: v.ok, normalized, errors: v.errors, changed: normalized !== expr };
}

/** Dạng chính tắc để so trùng: bỏ khoảng trắng, thống nhất lệnh tương đương. */
function canonical(expr) {
  return normalize(String(expr))
    .replace(/\\dfrac/g, '\\frac')
    .replace(/\\left|\\right/g, '')
    .replace(/\s+/g, '')
    .toLowerCase();
}

module.exports = { normalize, validate, enforce, canonical, RULES };
