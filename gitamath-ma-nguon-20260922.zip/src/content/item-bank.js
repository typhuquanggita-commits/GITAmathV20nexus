'use strict';
/**
 * KHO HỌC LIỆU — lưu trữ, vòng đời trạng thái, truy vấn, hiệu chỉnh độ khó.
 *
 *  Vòng đời:  DRAFT → VERIFIED → REVIEWED → PUBLISHED → (RETIRED)
 *                 ↘ REJECTED
 *
 *  Chỉ item PUBLISHED mới được đưa cho học viên (điều A06: kiểm duyệt 2 lớp).
 *  Độ khó khai báo sẽ bị HIỆU CHỈNH bằng dữ liệu thật (p-value) sau ≥30 lượt làm.
 */

const bus = require('../kernel/eventbus');
const { id: newId, round, percentile } = require('../utils');
const { FORM_INDEX } = require('../curriculum/hierarchy');
const { DedupeIndex, answerShape } = require('./dedupe');

const STATUS = {
  DRAFT: 'DRAFT',
  VERIFIED: 'VERIFIED',
  REVIEWED: 'REVIEWED',
  PUBLISHED: 'PUBLISHED',
  REJECTED: 'REJECTED',
  RETIRED: 'RETIRED',
};

const CALIBRATION_MIN_ATTEMPTS = 30;

class ItemBank {
  constructor() {
    this.items = new Map();
    this.byForm = new Map();
    this.dedupe = new DedupeIndex();
    this.stats = { created: 0, published: 0, rejected: 0, retired: 0, duplicatesBlocked: 0 };
  }

  /** Nhận bản nháp. Chống trùng chạy NGAY tại cửa, trước khi tốn công thẩm định. */
  draft({ formCode, level, stars, stem, solutionSteps = [], hints = [], traps = [], answer, authorId, source = 'agent', servesLevels = null, blueprintId = null, intent = null, context = null, check = null, params = null }) {
    const form = FORM_INDEX.get(formCode);
    if (!form) return { ok: false, error: 'UNKNOWN_FORM', formCode };
    if (level < form.levelRange[0] || level > form.levelRange[1]) {
      return { ok: false, error: 'LEVEL_OUT_OF_RANGE', formCode, level, allowed: form.levelRange };
    }
    if (!stem || !String(stem).trim()) return { ok: false, error: 'EMPTY_STEM' };

    const shape = answerShape({ answer });
    const dup = this.dedupe.check(formCode, stem, shape);
    if (!dup.ok) {
      this.stats.duplicatesBlocked++;
      bus.safeEmit('item:duplicate_blocked', { formCode, reason: dup.reason });
      return { ok: false, error: dup.reason, conflictWith: dup.conflictWith, detail: dup.detail, distance: dup.distance };
    }

    const item = {
      id: newId('IT'),
      formCode,
      formName: form.name,
      subject: formCode[0] === 'M' ? 'math' : formCode[0] === 'E' ? 'english' : 'aptitude',
      level,
      stars,
      stem: String(stem),
      solutionSteps,
      hints,
      traps: traps.length ? traps : form.traps,
      answer,
      authorId,
      source,
      status: STATUS.DRAFT,
      // Chỉ giữ phần tuần tự hoá được: BigInt của SimHash không đi qua JSON,
      // mà bản ghi này còn phải ghi xuống đĩa và trả qua API.
      fingerprint: dup.fingerprint ? {
        contentHash: dup.fingerprint.contentHash,
        simhash: dup.fingerprint.simhashHex,
        structural: dup.fingerprint.structural,
        shape,
      } : null,
      // Dải tầng bài này dùng được; mặc định là đúng tầng danh nghĩa.
      servesLevels: Array.isArray(servesLevels) ? servesLevels : [level, level],
      blueprintId, intent, context, check, params,
      normSeconds: form.norm,
      quality: null,
      verification: null,
      review: null,
      attempts: 0,
      correct: 0,
      timeMs: [],
      pValue: null,
      discrimination: null,
      createdAt: Date.now(),
      history: [{ at: Date.now(), status: STATUS.DRAFT, by: authorId }],
    };

    this.items.set(item.id, item);
    if (!this.byForm.has(formCode)) this.byForm.set(formCode, []);
    this.byForm.get(formCode).push(item.id);
    this.dedupe.add(item.id, formCode, stem, dup.fingerprint);
    this.stats.created++;
    bus.safeEmit('item:drafted', { itemId: item.id, formCode, level });
    return { ok: true, item };
  }

  _transition(itemId, status, by, extra = {}) {
    const it = this.items.get(itemId);
    if (!it) return { ok: false, error: 'ITEM_NOT_FOUND' };
    it.status = status;
    Object.assign(it, extra);
    it.history.push({ at: Date.now(), status, by });
    return { ok: true, item: it };
  }

  /** Bước 2: một agent KHÁC giải lại độc lập, đáp án phải khớp. */
  markVerified(itemId, verification, by) {
    if (!verification || verification.match !== true) {
      this.stats.rejected++;
      return this._transition(itemId, STATUS.REJECTED, by, { verification, rejectReason: 'VERIFICATION_MISMATCH' });
    }
    return this._transition(itemId, STATUS.VERIFIED, by, { verification });
  }

  /** Bước 3: Critic chấm rubric 5★. */
  markReviewed(itemId, quality, review, by) {
    if (!quality.publishable) {
      this.stats.rejected++;
      return this._transition(itemId, STATUS.REJECTED, by, { quality, review, rejectReason: 'QUALITY_GATE' });
    }
    return this._transition(itemId, STATUS.REVIEWED, by, { quality, review });
  }

  /** Bước 4: Guardian duyệt Hiến pháp → phát hành. */
  publish(itemId, by) {
    const it = this.items.get(itemId);
    if (!it) return { ok: false, error: 'ITEM_NOT_FOUND' };
    if (it.status !== STATUS.REVIEWED) return { ok: false, error: 'NOT_REVIEWED', status: it.status };
    this.stats.published++;
    bus.safeEmit('item:published', { itemId, formCode: it.formCode, stars: it.stars });
    return this._transition(itemId, STATUS.PUBLISHED, by, { publishedAt: Date.now() });
  }

  reject(itemId, reason, by) {
    this.stats.rejected++;
    this.dedupe.remove(itemId); // trả lại chỗ trong chỉ mục cho bài khác
    return this._transition(itemId, STATUS.REJECTED, by, { rejectReason: reason });
  }

  retire(itemId, reason, by) {
    this.stats.retired++;
    return this._transition(itemId, STATUS.RETIRED, by, { retireReason: reason });
  }

  /** Ghi nhận một lượt làm bài để hiệu chỉnh độ khó bằng dữ liệu thật. */
  recordAttempt(itemId, { correct, ms }) {
    const it = this.items.get(itemId);
    if (!it) return { ok: false, error: 'ITEM_NOT_FOUND' };
    it.attempts++;
    if (correct) it.correct++;
    // Bài khôi phục từ ảnh chụp cũ có thể thiếu mảng này. Một buổi học của
    // học viên không được phép đổ vì một trường thiếu trong bản ghi.
    if (!Array.isArray(it.timeMs)) it.timeMs = [];
    it.timeMs.push(ms);
    if (it.timeMs.length > 500) it.timeMs.shift();

    if (it.attempts >= CALIBRATION_MIN_ATTEMPTS) {
      it.pValue = round(it.correct / it.attempts, 3);
      const expected = { 1: 0.90, 2: 0.80, 3: 0.65, 4: 0.45, 5: 0.25 }[it.stars];
      it.calibrationDrift = round(it.pValue - expected, 3);
      // Lệch quá 0.25 so với kỳ vọng của bậc sao → đề nghị gắn lại sao
      if (Math.abs(it.calibrationDrift) > 0.25) {
        const suggested = it.pValue >= 0.85 ? 1 : it.pValue >= 0.72 ? 2 : it.pValue >= 0.55 ? 3 : it.pValue >= 0.35 ? 4 : 5;
        it.suggestedStars = suggested;
        bus.safeEmit('item:miscalibrated', { itemId, stars: it.stars, suggested, pValue: it.pValue });
      }
    }
    return { ok: true, attempts: it.attempts, pValue: it.pValue };
  }

  get(itemId) { return this.items.get(itemId) || null; }

  /** Lấy bài đã phát hành theo dạng/tầng/độ khó, loại trừ bài học viên đã gặp. */
  query({ formCode = null, level = null, stars = null, subject = null, status = STATUS.PUBLISHED, exclude = [], limit = 20 } = {}) {
    const ex = new Set(exclude);
    const out = [];
    const source = formCode ? (this.byForm.get(formCode) || []).map((id) => this.items.get(id)) : [...this.items.values()];
    for (const it of source) {
      if (!it || ex.has(it.id)) continue;
      if (status && it.status !== status) continue;
      // Bài phục vụ cả một dải tầng: chọn theo dải, không chỉ theo tầng danh nghĩa.
      if (level != null) {
        const [lo, hi] = it.servesLevels || [it.level, it.level];
        if (level < lo || level > hi) continue;
      }
      if (stars != null && it.stars !== stars) continue;
      if (subject && it.subject !== subject) continue;
      out.push(it);
      if (out.length >= limit) break;
    }
    return out;
  }

  /** Độ phủ kho theo dạng — biết chỗ nào còn thiếu bài để giao việc biên soạn. */
  coverage({ minPerCell = 5 } = {}) {
    const cells = [];
    for (const [code, form] of FORM_INDEX) {
      const ids = this.byForm.get(code) || [];
      const items = ids.map((i) => this.items.get(i)).filter((x) => x && x.status === STATUS.PUBLISHED);
      for (let lv = form.levelRange[0]; lv <= form.levelRange[1]; lv++) {
        for (let st = 1; st <= 5; st++) {
          const n = items.filter((x) => x.level === lv && x.stars === st).length;
          if (n < minPerCell) cells.push({ formCode: code, level: lv, stars: st, have: n, need: minPerCell - n });
        }
      }
    }
    const totalPublished = [...this.items.values()].filter((x) => x.status === STATUS.PUBLISHED).length;
    return {
      publishedItems: totalPublished,
      forms: FORM_INDEX.size,
      gapCells: cells.length,
      missingItems: cells.reduce((s, c) => s + c.need, 0),
      topGaps: cells.sort((a, b) => b.need - a.need).slice(0, 50),
    };
  }

  status() {
    const byStatus = Object.create(null);
    for (const it of this.items.values()) byStatus[it.status] = (byStatus[it.status] || 0) + 1;
    const published = [...this.items.values()].filter((x) => x.status === STATUS.PUBLISHED);
    const qualities = published.map((x) => x.quality?.weighted).filter(Boolean);
    const diversity = [...this.byForm.keys()].map((c) => this.dedupe.diversity(c));
    return {
      total: this.items.size,
      byStatus,
      ...this.stats,
      avgQuality: qualities.length ? round(qualities.reduce((a, b) => a + b, 0) / qualities.length, 3) : 0,
      p50Quality: qualities.length ? percentile(qualities, 50) : 0,
      formsCovered: this.byForm.size,
      avgDiversity: diversity.length ? round(diversity.reduce((s, d) => s + d.diversity, 0) / diversity.length, 3) : 0,
      dedupe: this.dedupe.status(),
    };
  }
}

module.exports = ItemBank;
module.exports.STATUS = STATUS;
module.exports.CALIBRATION_MIN_ATTEMPTS = CALIBRATION_MIN_ATTEMPTS;
