'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  GIEO KHO HỌC LIỆU — dựng kho bài thật, có chứng cứ đúng sai
 * ═══════════════════════════════════════════════════════════════════════════
 *  Chính sách phát hành (bám điều A06 — kiểm duyệt hai lớp):
 *
 *   · Lớp 1: bộ sinh biên soạn theo bản thiết kế có ràng buộc toán học.
 *   · Lớp 2: BỘ KIỂM TRA TOÁN HỌC tự giải lại và thay nghiệm ngược.
 *            Đây là một lớp kiểm ĐỘC LẬP với bên soạn, có chứng cứ lưu lại.
 *
 *   Bài từ 1★ đến 3★: hai lớp trên là đủ để phát hành — lời giải ngắn, máy
 *   kiểm được trọn vẹn từng bước.
 *   Bài từ 4★ trở lên: máy chỉ xác nhận ĐÁP SỐ, còn lập luận và mức độ phù
 *   hợp sư phạm thì phải người thật duyệt. Những bài này dừng ở REVIEWED và
 *   chờ giáo viên, KHÔNG tự phát hành.
 *
 *  Kho được ghi xuống cơ sở dữ liệu bền vững nên chỉ gieo một lần.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { BLUEPRINTS } = require('./blueprint');
const quality = require('./quality');
const { round } = require('../utils');
const L = require('../logger');

/**
 * CỔNG PHÁT HÀNH — ĐỔI TRỤC CHẶN.
 *
 * Trước đây cổng này chặn theo BẬC SAO: bài từ bốn sao trở lên dừng ở trạng
 * thái đã soát, chờ người duyệt. Hệ quả đo được: kho không có lấy một bài bốn
 * sao hay năm sao nào ở trạng thái phát hành, nên MỌI đề dựng ra đều thiếu
 * đúng phần dùng để phân loại — dải "Vận dụng cao" và "Thách thức" của ma trận
 * công bố luôn bằng không. Đề hứa một đằng, dựng ra một nẻo.
 *
 * Chặn theo bậc sao là chặn nhầm trục. Bậc sao nói bài KHÓ đến đâu, mà phần
 * khó ấy chính là phần máy kiểm được chắc nhất: máy tự giải lại rồi thay nghiệm
 * ngược. Thứ máy KHÔNG kiểm được là câu chữ và cách dẫn dắt, mà điều đó không
 * liên quan gì đến số sao — bài một sao viết sai chính tả cũng hỏng y như bài
 * năm sao.
 *
 * Nên cổng chuyển sang chặn theo ĐIỀU MÁY THẬT SỰ BIẾT:
 *   · Bài đã được máy giải lại và khớp  → phát hành.
 *   · Bài máy không kiểm được, dù dễ hay khó → dừng lại, chờ người thật.
 * Cách này chặt hơn ở đúng chỗ đáng chặn, và không còn nói dối về cấu trúc đề.
 */
function mayDaChungMinh(item) {
  const v = item && item.verification;
  return !!(v && v.verified === true);
}

class BankSeeder {
  /**
   * @param {object} o
   * @param {import('./item-bank')} o.bank
   * @param {import('./generator')} o.generator
   * @param {import('../data/repository').Repository} [o.items]  kho bền vững
   */
  constructor({ bank, generator, items = null, audit = null }) {
    this.bank = bank;
    this.generator = generator;
    this.items = items;
    this.audit = audit;
    this.stats = { seeded: 0, published: 0, awaitingHuman: 0, rejected: 0, runs: 0 };
  }

  /** Kế hoạch gieo: mỗi bản thiết kế × mỗi tầng nó phục vụ. */
  plan({ perBlueprintLevel = 3 } = {}) {
    const tasks = [];
    for (const bp of [...BLUEPRINTS].sort((a, b) => a.id.localeCompare(b.id))) {
      for (let lv = bp.levels[0]; lv <= bp.levels[1]; lv++) {
        tasks.push({ formCode: bp.formCode, level: lv, blueprint: bp.id, count: perBlueprintLevel });
      }
    }
    // Gộp theo (dạng, tầng) — bộ sinh tự xoay vòng qua các bản thiết kế bên trong.
    const merged = new Map();
    for (const t of tasks) {
      const k = `${t.formCode}|${t.level}`;
      const cur = merged.get(k) || { formCode: t.formCode, level: t.level, count: 0, blueprints: [] };
      cur.count += t.count;
      cur.blueprints.push(t.blueprint);
      merged.set(k, cur);
    }
    return [...merged.values()].sort((a, b) => a.formCode.localeCompare(b.formCode) || a.level - b.level);
  }

  /**
   * Gieo kho.
   * @param {object} o {perBlueprintLevel, seed, dryRun}
   */
  seed({ perBlueprintLevel = 3, seed = 'gita-seed-v20', dryRun = false, quiet = true } = {}) {
    const t0 = Date.now();
    this.stats.runs++;
    const tasks = this.plan({ perBlueprintLevel });
    const results = [];
    let published = 0;
    let awaiting = 0;
    let rejected = 0;

    for (const t of tasks) {
      const g = this.generator.generate({
        formCode: t.formCode, level: t.level, count: t.count,
        seed: `${seed}|${t.formCode}|${t.level}`, authorId: 'SEEDER', dryRun,
      });
      if (!g.ok) { results.push({ ...t, produced: 0, error: g.error }); continue; }

      let pub = 0;
      let wait = 0;
      if (!dryRun) {
        for (const it of g.items) {
          const q = quality.score(it, { correctness: 5 });
          const rv = this.bank.markReviewed(it.id, q, {
            criticId: 'MATH-ENGINE',
            kind: 'MACHINE_PROOF',
            evidence: it.verification?.checks || [],
            note: 'Đáp số được máy tự giải lại và thay nghiệm ngược để đối chiếu.',
          }, 'MATH-ENGINE');
          if (!rv.ok) { rejected++; continue; }

          if (mayDaChungMinh(it)) {
            const p = this.bank.publish(it.id, 'MATH-ENGINE');
            if (p.ok) { pub++; this._persist(this.bank.get(it.id)); } else rejected++;
          } else {
            // Máy không tự giải lại được bài này, dù nó dễ hay khó.
            // Dừng ở trạng thái đã soát, chờ người thật. Không tự phát hành.
            wait++;
            this._persist(this.bank.get(it.id), { needsHumanReview: true });
          }
        }
      }

      published += pub;
      awaiting += wait;
      results.push({
        formCode: t.formCode, level: t.level,
        produced: g.produced, published: pub, awaitingHuman: wait,
        blueprintsUsed: g.blueprintsUsed, blueprintsAvailable: g.blueprintsAvailable,
      });
    }

    const seeded = results.reduce((s, r) => s + (r.produced || 0), 0);
    this.stats.seeded += seeded;
    this.stats.published += published;
    this.stats.awaitingHuman += awaiting;
    this.stats.rejected += rejected;

    const summary = {
      ok: true,
      dryRun,
      ms: Date.now() - t0,
      tasks: tasks.length,
      seeded,
      published,
      awaitingHuman: awaiting,
      rejected,
      coverage: this.coverage(),
      byForm: results.reduce((m, r) => { m[r.formCode] = (m[r.formCode] || 0) + (r.produced || 0); return m; }, {}),
      details: results,
      policy: 'Bài được máy tự giải lại và khớp thì phát hành; '
        + 'bài máy không kiểm được thì dừng ở REVIEWED chờ giáo viên duyệt, bất kể bậc sao.',
    };

    if (!quiet) {
      L.ok(`Gieo kho: ${seeded} bài · phát hành ${published} · chờ người duyệt ${awaiting} · ${summary.ms}ms`);
    }
    this.audit?.record({
      actor: 'SEEDER', action: 'bank.seed', verdict: 'ALLOW', severity: 0,
      detail: { seeded, published, awaitingHuman: awaiting, ms: summary.ms },
    });
    return summary;
  }

  /**
   * BỔ SUNG KHO ĐÃ CÓ — không gieo lại từ đầu.
   *
   * Lỗi cũ: máy chủ chỉ gieo kho khi kho RỖNG. Gieo xong một lần rồi thì dù
   * sau này biên soạn thêm bao nhiêu bản thiết kế, kho trên đĩa cũng không bao
   * giờ nhận được bài mới — một hệ thống nội dung mà không nạp được nội dung
   * mới sau lần chạy đầu. Cài đặt đang chạy sẽ mãi phục vụ kho cũ, còn bản
   * thiết kế mới nằm trong mã nguồn mà không ai thấy.
   *
   * Hàm này lấp đúng hai chỗ hổng đó, và chỉ hai chỗ:
   *   1. Ô (dạng × tầng) có bản thiết kế nhưng chưa có bài nào  → sinh thêm.
   *   2. Bài đang dừng chờ người duyệt mà nay đã đạt cổng phát hành → phát hành.
   *
   * Không đụng tới bài đã phát hành, không xoá gì. Chạy được nhiều lần, lần
   * sau không sinh trùng vì bộ chống trùng vẫn gác ở cửa kho.
   */
  boSung({ perSlot = 3, seed = 'gita-bo-sung-v20', quiet = true } = {}) {
    const t0 = Date.now();
    const c = this.coverage();
    let sinhThem = 0;
    let phatHanhThem = 0;

    // ── 1. Lấp ô trống VÀ ô mỏng ───────────────────────────────────────────
    // Ô mỏng cũng phải lấp, không chỉ ô trống: một ô có đúng một bài thì đề
    // nào ở tầng ấy cũng gặp lại đúng bài đó, và bộ loại bài vừa luyện 30 ngày
    // sẽ không còn gì để lấy. Ngưỡng lấy bằng chính số bài mỗi ô của lần gieo
    // đầu, để kho bổ sung và kho gieo mới cùng một mật độ.
    const oCanLap = [...c.empty.map((o) => String(o.slot || o)),
      ...c.thin.filter((o) => (o.items || 0) < perSlot).map((o) => String(o.slot))];
    for (const oKey of oCanLap) {
      const [formCode, lv] = oKey.split('|');
      const level = Number(lv);
      if (!formCode || !Number.isInteger(level)) continue;
      const g = this.generator.generate({
        formCode, level, count: perSlot, seed: `${seed}|${formCode}|${level}`, authorId: 'SEEDER',
      });
      if (!g.ok) continue;
      for (const it of g.items) {
        const q = quality.score(it, { correctness: 5 });
        const rv = this.bank.markReviewed(it.id, q, {
          criticId: 'MATH-ENGINE', kind: 'MACHINE_PROOF',
          evidence: it.verification?.checks || [],
          note: 'Đáp số được máy tự giải lại và thay nghiệm ngược để đối chiếu.',
        }, 'MATH-ENGINE');
        if (!rv.ok) continue;
        sinhThem++;
        if (mayDaChungMinh(it)) {
          const pub = this.bank.publish(it.id, 'MATH-ENGINE');
          if (pub.ok) { phatHanhThem++; this._persist(this.bank.get(it.id)); }
        } else {
          this._persist(this.bank.get(it.id), { needsHumanReview: true });
        }
      }
    }

    // ── 1b. Bản thiết kế MỚI mà chưa có bài nào ────────────────────────────
    // Lấp ô trống chưa đủ: một bản thiết kế mới soạn có thể rơi vào ô đã đầy
    // sẵn nhờ bản thiết kế khác, nên ô không trống mà bài của bản mới vẫn
    // không bao giờ được sinh. Phải rà theo BẢN THIẾT KẾ, không chỉ theo ô.
    const coBai = new Set();
    for (const it of this.bank.items.values()) if (it.blueprintId) coBai.add(it.blueprintId);
    for (const bp of BLUEPRINTS) {
      if (coBai.has(bp.id)) continue;
      for (let lv = bp.levels[0]; lv <= bp.levels[1]; lv++) {
        const g = this.generator.generate({
          formCode: bp.formCode, level: lv, stars: bp.stars, count: perSlot,
          seed: `${seed}|moi|${bp.id}|${lv}`, authorId: 'SEEDER',
        });
        if (!g.ok) continue;
        for (const it of g.items) {
          const q = quality.score(it, { correctness: 5 });
          const rv = this.bank.markReviewed(it.id, q, {
            criticId: 'MATH-ENGINE', kind: 'MACHINE_PROOF',
            evidence: it.verification?.checks || [],
            note: 'Đáp số được máy tự giải lại và thay nghiệm ngược để đối chiếu.',
          }, 'MATH-ENGINE');
          if (!rv.ok) continue;
          sinhThem++;
          if (mayDaChungMinh(it)) {
            const pub = this.bank.publish(it.id, 'MATH-ENGINE');
            if (pub.ok) { phatHanhThem++; this._persist(this.bank.get(it.id)); }
          } else {
            this._persist(this.bank.get(it.id), { needsHumanReview: true });
          }
        }
      }
    }

    // ── 2. Cập nhật dải tầng của bài cũ theo bản thiết kế hiện hành ────────
    // `servesLevels` là thuộc tính của BẢN THIẾT KẾ, không phải của lần sinh.
    // Khi một dạng được nối lên tầng cao hơn thì bài cũ của nó vẫn giữ dải cũ
    // trong kho, nên bộ dựng đề không nhìn thấy chúng ở tầng mới — kho trông
    // như thiếu bài trong khi bài vẫn nằm đó. Đây là bước đồng bộ lại.
    let capNhatDaiTang = 0;
    for (const it of this.bank.items.values()) {
      if (!it.blueprintId) continue;
      const bp = BLUEPRINTS.find((b) => b.id === it.blueprintId);
      if (!bp) continue;
      const [lo, hi] = it.servesLevels || [it.level, it.level];
      if (lo === bp.levels[0] && hi === bp.levels[1]) continue;
      it.servesLevels = [bp.levels[0], bp.levels[1]];
      this._persist(it);
      capNhatDaiTang++;
    }

    // ── 2b. Dựng lại nội dung bài khi bản thiết kế đã sửa ──────────────────
    // Đề bài và lời giải là KẾT QUẢ của bản thiết kế cộng với bộ tham số, mà cả
    // hai đều được lưu. Khi bản thiết kế được sửa — câu văn viết lại cho ngắn,
    // bước giải được bổ sung căn cứ — thì bài đã nằm trong kho vẫn giữ nguyên
    // chữ cũ. Người học sẽ đọc bản cũ mãi mãi, còn bản sửa chỉ nằm trong mã
    // nguồn. Bước này dựng lại nội dung từ chính bản thiết kế hiện hành.
    let dungLaiNoiDung = 0;
    for (const it of this.bank.items.values()) {
      if (!it.blueprintId || !it.params) continue;
      const bp = BLUEPRINTS.find((b) => b.id === it.blueprintId);
      if (!bp) continue;
      let moi;
      try { moi = bp.render(it.params); } catch { continue; }
      const cuBuoc = JSON.stringify(it.solutionSteps || []);
      const moiBuoc = JSON.stringify(moi.solutionSteps || []);
      if (it.stem === moi.stem && cuBuoc === moiBuoc && it.answer === moi.answer) continue;
      it.stem = moi.stem;
      it.solutionSteps = moi.solutionSteps;
      it.hints = moi.hints;
      it.answer = moi.answer;
      it.check = moi.check;
      this._persist(it);
      dungLaiNoiDung++;
    }

    // ── 3. Phát hành bài đã đạt cổng nhưng còn nằm chờ ─────────────────────
    // Khi cổng phát hành đổi (ví dụ thôi chặn theo bậc sao), những bài đang
    // chờ cần được xét lại — nếu không thì chỉ bài sinh SAU lần đổi mới được
    // hưởng, còn kho cũ vẫn thiếu đúng dải mà lần đổi định lấp.
    for (const it of this.bank.items.values()) {
      if (it.status !== 'REVIEWED') continue;
      if (it.verification?.match !== true) continue;
      const pub = this.bank.publish(it.id, 'MATH-ENGINE');
      if (pub.ok) { phatHanhThem++; this._persist(this.bank.get(it.id)); }
    }

    const tomTat = {
      ok: true,
      ms: Date.now() - t0,
      oTrongTruoc: c.empty.length,
      oMongTruoc: c.thin.length,
      capNhatDaiTang,
      dungLaiNoiDung,
      sinhThem,
      phatHanhThem,
      coverage: this.coverage(),
    };
    if (!quiet && (sinhThem || phatHanhThem || capNhatDaiTang || dungLaiNoiDung)) {
      L.ok(`Bổ sung kho: sinh thêm ${sinhThem} bài · phát hành thêm ${phatHanhThem} bài · `
        + `đồng bộ dải tầng ${capNhatDaiTang} bài · dựng lại nội dung ${dungLaiNoiDung} bài · ${tomTat.ms}ms`);
    }
    if (sinhThem || phatHanhThem || capNhatDaiTang || dungLaiNoiDung) {
      this.audit?.record({
        actor: 'SEEDER', action: 'bank.topup', verdict: 'ALLOW', severity: 0,
        detail: { sinhThem, phatHanhThem, capNhatDaiTang, dungLaiNoiDung, oTrongTruoc: c.empty.length, ms: tomTat.ms },
      });
    }
    return tomTat;
  }

  /** Ghi bài xuống cơ sở dữ liệu bền vững. */
  _persist(item, extra = {}) {
    if (!this.items || !item) return;
    this.items.put({
      id: item.id,
      formCode: item.formCode,
      formName: item.formName,
      subject: item.subject,
      level: item.level,
      stars: item.stars,
      status: item.status,
      stem: item.stem,
      solutionSteps: item.solutionSteps,
      hints: item.hints,
      traps: item.traps,
      answer: item.answer,
      normSeconds: item.normSeconds,
      servesLevels: item.servesLevels,
      quality: item.quality,
      verification: item.verification,
      blueprintId: item.blueprintId,
      intent: item.intent,
      context: item.context,
      params: item.params,
      check: item.check,
      fingerprint: item.fingerprint,
      ...extra,
    });
  }

  /** Nạp lại kho trong bộ nhớ từ cơ sở dữ liệu (sau khi khởi động lại). */
  restore() {
    if (!this.items) return { ok: false, error: 'NO_STORE' };
    let n = 0;
    for (const doc of this.items.all()) {
      if (this.bank.items.has(doc.id)) continue;
      // Dựng lại ĐỦ các trường động. Thiếu một mảng ở đây thì bài khôi phục
      // từ đĩa sẽ làm đổ phiên luyện của học viên ngay lượt chấm đầu tiên —
      // lỗi chỉ hiện ra sau khi khởi động lại, nên rất khó truy.
      this.bank.items.set(doc.id, {
        ...doc,
        history: doc.history || [],
        attempts: doc.attempts || 0,
        correct: doc.correct || 0,
        timeMs: doc.timeMs || [],
      });
      const list = this.bank.byForm.get(doc.formCode) || [];
      list.push(doc.id);
      this.bank.byForm.set(doc.formCode, list);
      // Dựng lại chỉ mục chống trùng để không nhận bài trùng sau khi khởi động lại.
      this.bank.dedupe.add(doc.id, doc.formCode, doc.stem, null, doc.fingerprint?.shape || '');
      n++;
    }
    return { ok: true, restored: n, total: this.bank.items.size };
  }

  /** Độ phủ kho: mỗi (dạng, tầng) có bản thiết kế thì đã có bao nhiêu bài dùng được. */
  coverage() {
    const need = new Map();
    for (const bp of BLUEPRINTS) {
      for (let lv = bp.levels[0]; lv <= bp.levels[1]; lv++) need.set(`${bp.formCode}|${lv}`, 0);
    }
    for (const it of this.bank.items.values()) {
      if (it.status !== 'PUBLISHED' && it.status !== 'REVIEWED') continue;
      const [lo, hi] = it.servesLevels || [it.level, it.level];
      for (let lv = lo; lv <= hi; lv++) {
        const k = `${it.formCode}|${lv}`;
        if (need.has(k)) need.set(k, need.get(k) + 1);
      }
    }
    const slots = [...need.entries()];
    const filled = slots.filter(([, n]) => n > 0).length;
    const thin = slots.filter(([, n]) => n > 0 && n < 3).map(([k, n]) => ({ slot: k, items: n }));
    return {
      slots: slots.length,
      filled,
      empty: slots.filter(([, n]) => n === 0).map(([k]) => k),
      thin,
      ratio: slots.length ? round(filled / slots.length, 3) : 0,
    };
  }

  status() {
    const byStatus = {};
    for (const it of this.bank.items.values()) byStatus[it.status] = (byStatus[it.status] || 0) + 1;
    return {
      ...this.stats,
      bankSize: this.bank.items.size,
      byStatus,
      persisted: this.items ? this.items.count() : 0,
      congPhatHanh: "MAY_DA_CHUNG_MINH",
      coverage: this.coverage(),
    };
  }
}

module.exports = BankSeeder;
module.exports.mayDaChungMinh = mayDaChungMinh;
