'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DÂY CHUYỀN BIÊN SOẠN — 6 chốt, không có đường tắt
 * ═══════════════════════════════════════════════════════════════════════════
 *   1. BRIEF      Lấy đề bài biên soạn từ DẠNG + TẦNG + độ khó + khung đã dùng
 *   2. DRAFT      Agent biên soạn viết đề + lời giải + gợi ý + bẫy
 *   3. NORMALIZE  Cưỡng chế chuẩn LaTeX (A02); sai không sửa được thì loại
 *   4. VERIFY     Agent KHÁC giải lại ĐỘC LẬP; đáp án phải khớp
 *   5. REVIEW     Critic chấm rubric 5★; correctness phải 5★
 *   6. APPROVE    Guardian kiểm Hiến pháp rồi phát hành
 *
 *  Chống máy móc:
 *   · Brief nêu rõ các khung cấu trúc ĐÃ dùng và yêu cầu tránh
 *   · Kho từ chối bài trùng khung quá quota (dedupe tầng 3)
 *   · Người biên soạn và người thẩm định BẮT BUỘC là hai agent khác nhau
 * ═══════════════════════════════════════════════════════════════════════════
 */

const bus = require('../kernel/eventbus');
const L = require('../logger');
const { round, id: newId } = require('../utils');
const { FORM_INDEX, LEVELS, DIFFICULTY } = require('../curriculum/hierarchy');
const notation = require('./notation');
const quality = require('./quality');
const { STATUS } = require('./item-bank');

const STAGES = ['brief', 'draft', 'normalize', 'verify', 'review', 'approve'];

class AuthoringPipeline {
  constructor({ bank, scheduler, runtime, constitution }) {
    this.bank = bank;
    this.scheduler = scheduler;
    this.runtime = runtime;
    this.constitution = constitution;
    this.stats = { runs: 0, published: 0, rejected: 0, byStage: Object.fromEntries(STAGES.map((s) => [s, 0])) };
  }

  /** CHỐT 1 — đề bài biên soạn, nêu rõ ràng buộc và những khung đã dùng. */
  brief(formCode, level, stars) {
    const form = FORM_INDEX.get(formCode);
    if (!form) return { ok: false, error: 'UNKNOWN_FORM' };
    const lv = LEVELS[level];
    const diff = DIFFICULTY[stars - 1];
    const existing = (this.bank.byForm.get(formCode) || [])
      .map((id) => this.bank.get(id))
      .filter((x) => x && x.status === STATUS.PUBLISHED)
      .slice(-6)
      .map((x) => x.stem.slice(0, 120));

    const text = [
      `Biên soạn MỘT bài tập mới.`,
      ``,
      `DẠNG    : ${form.code} — ${form.name}`,
      `TẦNG    : ${lv.code} ${lv.name} — ${lv.desc}`,
      `ĐỘ KHÓ  : ${diff.stars}★ ${diff.name} — khoảng ${diff.steps} bước giải`,
      `THỜI GIAN CHUẨN: ${form.norm} giây`,
      `BẪY CẦN CÀI: ${form.traps.join(' · ')}`,
      ``,
      `YÊU CẦU BẮT BUỘC:`,
      `1. Ký hiệu LaTeX chuẩn: \\dfrac{a}{b}, \\sqrt{x}, x^{2}. CẤM dùng /, ^, sqrt() thô.`,
      `2. Lời giải chia thành ${diff.steps} bước rõ ràng, mỗi bước một dòng.`,
      `3. Ba mức gợi ý: gợi ý 1 chỉ hướng, gợi ý 2 nêu công thức, gợi ý 3 làm mẫu một bước.`,
      `4. Nêu ít nhất một bẫy sai mà học sinh hay mắc ở bài này.`,
      `5. Đáp án cuối cùng viết riêng một dòng, bắt đầu bằng "ĐÁP ÁN:".`,
      ``,
      existing.length
        ? `TRÁNH TRÙNG — đã có các bài sau trong kho, KHÔNG được chỉ đổi số của chúng:\n${existing.map((s, i) => `  (${i + 1}) ${s}`).join('\n')}`
        : `Kho chưa có bài nào của dạng này.`,
      ``,
      `TRẢ VỀ ĐÚNG ĐỊNH DẠNG:`,
      `ĐỀ: <đề bài>`,
      `BƯỚC 1: <...>`,
      `BƯỚC 2: <...>`,
      `GỢI Ý 1: <...>`,
      `GỢI Ý 2: <...>`,
      `GỢI Ý 3: <...>`,
      `BẪY: <...>`,
      `ĐÁP ÁN: <...>`,
    ].join('\n');

    this.stats.byStage.brief++;
    return { ok: true, brief: text, form, level: lv, difficulty: diff, existingCount: existing.length };
  }

  /** Bóc tách phản hồi của agent thành cấu trúc bài tập. */
  parse(text) {
    const s = String(text);
    const pick = (re) => { const m = s.match(re); return m ? m[1].trim() : null; };
    const pickAll = (re) => [...s.matchAll(re)].map((m) => m[1].trim()).filter(Boolean);

    return {
      stem: pick(/^\s*ĐỀ\s*:\s*([\s\S]*?)(?=\n\s*(?:BƯỚC|GỢI Ý|BẪY|ĐÁP ÁN)\s*\d*\s*:|$)/mi),
      solutionSteps: pickAll(/^\s*BƯỚC\s*\d+\s*:\s*(.+)$/gmi),
      hints: pickAll(/^\s*GỢI Ý\s*\d+\s*:\s*(.+)$/gmi),
      traps: pickAll(/^\s*BẪY\s*:\s*(.+)$/gmi),
      answer: pick(/^\s*ĐÁP ÁN\s*:\s*(.+)$/mi),
    };
  }

  /** CHỐT 3 — chuẩn hoá ký hiệu trên mọi trường văn bản. */
  normalizeItem(parsed) {
    const fix = (t) => (t == null ? t : notation.enforce(String(t)));
    const stem = fix(parsed.stem);
    const steps = parsed.solutionSteps.map(fix);
    const hints = parsed.hints.map(fix);
    const answer = fix(parsed.answer);

    const errors = [];
    if (stem && !stem.ok) errors.push({ field: 'stem', errors: stem.errors });
    steps.forEach((x, i) => { if (!x.ok) errors.push({ field: `step${i + 1}`, errors: x.errors }); });
    if (answer && !answer.ok) errors.push({ field: 'answer', errors: answer.errors });

    return {
      ok: errors.length === 0,
      errors,
      item: {
        stem: stem ? stem.normalized : null,
        solutionSteps: steps.map((x) => x.normalized),
        hints: hints.map((x) => x.normalized),
        traps: parsed.traps,
        answer: answer ? answer.normalized : null,
      },
    };
  }

  /**
   * Chạy toàn bộ dây chuyền cho một ô (dạng × tầng × độ khó).
   * Trả về item đã phát hành, hoặc lý do bị chặn ở chốt nào.
   */
  async produce({ formCode, level, stars }) {
    this.stats.runs++;
    const runId = newId('AUTH');
    const t0 = Date.now();
    const trail = [];
    const subjectTask = formCode[0] === 'M' ? 'item_authoring' : formCode[0] === 'E' ? 'vietnamese' : 'long_context';

    const stop = (stage, reason, detail) => {
      this.stats.rejected++;
      trail.push({ stage, ok: false, reason, detail });
      bus.safeEmit('authoring:rejected', { runId, formCode, stage, reason });
      return { ok: false, runId, formCode, level, stars, stage, reason, detail, trail, ms: Date.now() - t0 };
    };

    // ── 1. BRIEF ──
    const b = this.brief(formCode, level, stars);
    if (!b.ok) return stop('brief', b.error);
    trail.push({ stage: 'brief', ok: true, existingCount: b.existingCount });

    // ── 2. DRAFT ──
    const drafted = await this.scheduler.dispatch({
      type: subjectTask, input: b.brief, maxTokens: 1400, allowCache: false, temperature: 0.7,
    });
    this.stats.byStage.draft++;
    if (!drafted.ok) return stop('draft', drafted.error, drafted.detail);
    trail.push({ stage: 'draft', ok: true, agentId: drafted.agentId, ms: drafted.ms });

    const parsed = this.parse(drafted.output);
    if (!parsed.stem) return stop('draft', 'PARSE_FAILED', 'Phản hồi không có dòng "ĐỀ:"');
    if (!parsed.answer) return stop('draft', 'NO_ANSWER', 'Phản hồi không có dòng "ĐÁP ÁN:"');

    // ── 3. NORMALIZE ──
    const norm = this.normalizeItem(parsed);
    this.stats.byStage.normalize++;
    if (!norm.ok) return stop('normalize', 'NOTATION_INVALID', norm.errors);
    trail.push({ stage: 'normalize', ok: true });

    // Nhận vào kho ở trạng thái DRAFT — chống trùng chạy tại đây
    const created = this.bank.draft({
      formCode, level, stars,
      stem: norm.item.stem,
      solutionSteps: norm.item.solutionSteps,
      hints: norm.item.hints,
      traps: norm.item.traps,
      answer: norm.item.answer,
      authorId: drafted.agentId,
      source: 'pipeline',
    });
    if (!created.ok) return stop('normalize', created.error, created.detail || created.conflictWith);
    const item = created.item;

    // ── 4. VERIFY — agent KHÁC giải lại độc lập ──
    const verifier = this.scheduler.select(subjectTask, { rank: 'WORKER', exclude: [drafted.agentId] });
    if (!verifier) { this.bank.reject(item.id, 'NO_VERIFIER', 'system'); return stop('verify', 'NO_VERIFIER'); }

    const solved = await this.runtime.run(verifier.id, {
      type: subjectTask, allowCache: false, maxTokens: 900, temperature: 0.2,
      input:
        `Giải bài toán sau một cách độc lập. KHÔNG tham khảo lời giải nào khác.\n` +
        `Dòng cuối cùng PHẢI có dạng "ĐÁP ÁN: <kết quả>".\n\n${item.stem}`,
    });
    this.stats.byStage.verify++;
    if (!solved.ok) { this.bank.reject(item.id, 'VERIFY_FAILED', verifier.id); return stop('verify', solved.error); }

    const vAnswer = (String(solved.output).match(/ĐÁP ÁN\s*:\s*(.+)$/mi) || [])[1];
    const match = !!vAnswer && notation.canonical(vAnswer) === notation.canonical(item.answer);
    this.bank.markVerified(item.id, { verifierId: verifier.id, answer: vAnswer, match }, verifier.id);
    trail.push({ stage: 'verify', ok: match, agentId: verifier.id, answer: vAnswer });
    if (!match) {
      return stop('verify', 'ANSWER_MISMATCH', { author: item.answer, verifier: vAnswer });
    }

    // ── 5. REVIEW — Critic chấm rubric 5★ ──
    const critic = this.scheduler.select(subjectTask, { rank: 'CRITIC' });
    let criticScores = {};
    let reviewText = null;
    if (critic) {
      const rv = await this.runtime.run(critic.id, {
        type: subjectTask, allowCache: false, maxTokens: 700, temperature: 0.2,
        input:
          `Chấm bài tập dưới đây theo rubric. Trả về MỖI DÒNG một chiều, đúng định dạng "TÊN: số".\n\n` +
          `RUBRIC:\n${quality.rubricPrompt()}\n\n` +
          `BÀI:\nĐỀ: ${item.stem}\n${item.solutionSteps.map((s, i) => `BƯỚC ${i + 1}: ${s}`).join('\n')}\nĐÁP ÁN: ${item.answer}\n\n` +
          `Định dạng bắt buộc:\ncorrectness: <1-5>\nnotation: <1-5>\npedagogy: <1-5>\noriginality: <1-5>\ncalibration: <1-5>\nNHẬN XÉT: <ngắn gọn>`,
      });
      this.stats.byStage.review++;
      if (rv.ok) {
        reviewText = rv.output;
        for (const k of quality.DIM_KEYS) {
          const m = String(rv.output).match(new RegExp(`${k}\\s*:\\s*([1-5])`, 'i'));
          if (m) criticScores[k] = Number(m[1]);
        }
      }
    }

    // Không có điểm correctness từ Critic thì lấy kết quả thẩm định chéo làm bằng chứng.
    if (criticScores.correctness == null) criticScores.correctness = match ? 5 : 1;
    // Độc bản: lấy từ độ đa dạng khung của dạng
    if (criticScores.originality == null) {
      const div = this.bank.dedupe.diversity(formCode);
      criticScores.originality = div.diversity >= 0.9 ? 5 : div.diversity >= 0.7 ? 4 : div.diversity >= 0.5 ? 3 : 2;
    }

    const q = quality.score(item, criticScores);
    this.bank.markReviewed(item.id, q, { criticId: critic?.id, notes: reviewText }, critic?.id || 'auto');
    trail.push({ stage: 'review', ok: q.publishable, criticId: critic?.id, weighted: q.weighted, blockers: q.blockers });
    if (!q.publishable) return stop('review', 'QUALITY_GATE', q.verdict);

    // ── 6. APPROVE — Guardian kiểm Hiến pháp ──
    const verdict = this.constitution.validate('publish', { audited: true, latex: item.stem });
    this.stats.byStage.approve++;
    if (!verdict.ok) {
      this.bank.reject(item.id, 'CONSTITUTION_BLOCK', 'guardian');
      return stop('approve', 'CONSTITUTION_BLOCK', verdict.violations);
    }
    const guardian = this.scheduler.select(subjectTask, { rank: 'GUARDIAN' });
    this.bank.publish(item.id, guardian?.id || 'guardian');
    trail.push({ stage: 'approve', ok: true, guardianId: guardian?.id, sanction: verdict.sanction });

    this.stats.published++;
    bus.safeEmit('authoring:published', { runId, itemId: item.id, formCode, weighted: q.weighted });

    return {
      ok: true, runId, itemId: item.id, formCode, level, stars,
      quality: q, stars5: q.stars,
      author: drafted.agentId, verifier: verifier.id, critic: critic?.id, guardian: guardian?.id,
      trail, ms: Date.now() - t0,
    };
  }

  /** Sản xuất hàng loạt theo danh sách ô còn thiếu (từ bank.coverage()). */
  async produceBatch(cells, { concurrency = 4, maxItems = 20 } = {}) {
    const targets = cells.slice(0, maxItems);
    const results = [];
    for (let i = 0; i < targets.length; i += concurrency) {
      const chunk = targets.slice(i, i + concurrency);
      results.push(...await Promise.all(chunk.map((c) => this.produce(c))));
    }
    const ok = results.filter((r) => r.ok);
    return {
      ok: true,
      attempted: results.length,
      published: ok.length,
      rejected: results.length - ok.length,
      yieldRate: results.length ? round(ok.length / results.length, 3) : 0,
      byStage: results.filter((r) => !r.ok).reduce((m, r) => { m[r.stage] = (m[r.stage] || 0) + 1; return m; }, {}),
      results,
    };
  }

  status() {
    return {
      ...this.stats,
      yieldRate: this.stats.runs ? round(this.stats.published / this.stats.runs, 3) : 0,
      stages: STAGES,
    };
  }
}

module.exports = AuthoringPipeline;
module.exports.STAGES = STAGES;
