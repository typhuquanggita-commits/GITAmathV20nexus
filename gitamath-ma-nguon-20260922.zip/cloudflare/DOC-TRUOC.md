# Đưa GITAmath lên Cloudflare

Dựng: `node scripts/dung-ban-cloudflare.js`
Đẩy:  `npx wrangler pages deploy cloudflare/dist --project-name gitamath`

## Cái gì lên được Cloudflare, cái gì không

Nói thẳng trước khi làm, vì đây là chỗ dễ hứa quá tay nhất.

**Lên được** (Cloudflare Pages phục vụ tệp tĩnh):

- Trang giới thiệu — dựng sẵn thành HTML, số liệu đóng băng tại ngày dựng
- Sơ đồ chương trình dạng ảnh SVG
- 40 kịch bản lời đọc của bộ video hướng dẫn

**Không lên được** — cần một máy chủ Node chạy thật:

- Đăng nhập, tài khoản, phiên làm việc
- Trợ lý trò chuyện (đọc dữ liệu học viên thật)
- Dựng video, dựng bài giảng, chụp ảnh hệ thống
- Mọi thứ ghi xuống đĩa

Lý do không phải thiếu sót của ai: Pages không chạy tiến trình lâu dài, không
có hệ tệp ghi được, và không giữ trạng thái giữa hai yêu cầu.

## Nối hai phần

1. Chạy máy chủ Node ở đâu cũng được — kể cả một máy trong văn phòng.
2. `cloudflared tunnel --url http://localhost:9999` đưa nó ra ngoài, không
   phải mở cổng nào trên tường lửa.
3. Trỏ một tên miền con (ví dụ `app.gitamath.vn`) vào đường hầm ấy.
4. Mở ba dòng trong `dist/_redirects`, đổi tên miền cho đúng.

Từ đó: tên miền chính phục vụ trang tĩnh từ Cloudflare (nhanh, chịu tải, miễn
phí), còn `/ui/*` và `/api/*` đi tiếp về máy chủ Node.

## Số liệu đóng băng

Trang tĩnh mang số liệu của **ngày dựng**, và mỗi trang in rõ ngày ấy. Số
liệu đổi thì dựng lại và đẩy lại — một lệnh.

## Không có bí mật nào trong bản này

`wrangler.toml` không khai biến môi trường nào. Kịch bản dựng soi lại sản
phẩm và **từ chối hoàn tất** nếu tìm thấy chuỗi trông giống khoá.
