'use strict';
/** Lưu trữ bền vững: sống sót restart, sống sót mất điện, ghi nguyên tử. */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { Repository, Database } = require('../src/data/repository');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'gita-db-'));

test('dữ liệu sống sót qua tắt/mở lại', () => {
  const dir = tmp();
  let db = new Database({ dir });
  const r = db.collection('learners', { indexes: ['grade', 'classId'] });
  for (let i = 1; i <= 100; i++) r.put({ id: `HV${i}`, fullName: `Học viên ${i}`, grade: (i % 12) + 1, classId: `L${i % 5}` });
  r.delete('HV7');
  r.patch('HV8', { grade: 12 });
  db.close();

  db = new Database({ dir });
  const r2 = db.collection('learners', { indexes: ['grade', 'classId'] });
  assert.equal(r2.count(), 99);
  assert.equal(r2.has('HV7'), false);
  assert.equal(r2.get('HV8').grade, 12);
  assert.equal(r2.get('HV1').fullName, 'Học viên 1');
  db.close();
});

test('mất điện giữa chừng: nhật ký chưa gộp vẫn phát lại được', () => {
  const dir = tmp();
  // Không gọi close() — mô phỏng tiến trình bị giết.
  const r = new Repository({ name: 'items', dir, compactEvery: 10_000 });
  for (let i = 1; i <= 25; i++) r.put({ id: `IT${i}`, stem: `Đề ${i}` });
  r.delete('IT3');
  // (không close, không compact)

  const r2 = new Repository({ name: 'items', dir });
  assert.equal(r2.count(), 24);
  assert.equal(r2.has('IT3'), false);
  assert.equal(r2.stats.replayed, 26, 'phải phát lại đủ 25 ghi + 1 xoá');
});

test('dòng nhật ký cụt không làm hỏng cả bộ sưu tập', () => {
  const dir = tmp();
  const r = new Repository({ name: 'x', dir, compactEvery: 10_000 });
  r.put({ id: 'A', v: 1 });
  r.put({ id: 'B', v: 2 });
  r.close();
  // Sau khi gộp, thêm một dòng hợp lệ rồi một dòng bị cắt giữa chừng.
  fs.appendFileSync(path.join(dir, 'x.log'), JSON.stringify({ o: 'p', d: { id: 'C', v: 3 } }) + '\n');
  fs.appendFileSync(path.join(dir, 'x.log'), '{"o":"p","d":{"id":"D","v":');

  const r2 = new Repository({ name: 'x', dir });
  assert.equal(r2.count(), 3, 'A, B, C còn; D cụt thì bỏ');
  assert.equal(r2.stats.corruptLines, 1);
  assert.equal(r2.get('C').v, 3);
});

test('ảnh chụp hỏng vẫn cứu được dữ liệu từ nhật ký', () => {
  const dir = tmp();
  const r = new Repository({ name: 'y', dir, compactEvery: 10_000 });
  r.put({ id: 'A', v: 1 });
  r.put({ id: 'B', v: 2 });
  fs.writeFileSync(path.join(dir, 'y.snap.json'), '{ đây không phải JSON');

  const r2 = new Repository({ name: 'y', dir });
  assert.equal(r2.count(), 2, 'phát lại nhật ký bù cho ảnh chụp hỏng');
});

test('ghi ảnh chụp là nguyên tử — không để lại tệp tạm', () => {
  const dir = tmp();
  const r = new Repository({ name: 'z', dir });
  for (let i = 0; i < 30; i++) r.put({ id: `k${i}`, v: i });
  r.compact();
  const files = fs.readdirSync(dir);
  assert.ok(!files.some((f) => f.endsWith('.tmp')), `còn tệp tạm: ${files.join(',')}`);
  assert.ok(files.includes('z.snap.json'));
  assert.equal(fs.readFileSync(path.join(dir, 'z.log'), 'utf8'), '', 'nhật ký phải rỗng sau khi gộp');
});

test('gộp tự động khi nhật ký vượt ngưỡng', () => {
  const dir = tmp();
  const r = new Repository({ name: 'auto', dir, compactEvery: 20 });
  for (let i = 0; i < 100; i++) r.put({ id: `k${i}`, v: i });
  assert.ok(r.stats.compactions >= 5, `chỉ gộp ${r.stats.compactions} lần`);
  assert.ok(r.status().pendingLog < 20);
});

test('chỉ mục tra cứu đúng và tự cập nhật khi sửa', () => {
  const dir = tmp();
  const r = new Repository({ name: 'idx', dir, indexes: ['classId'] });
  r.put({ id: 'A', classId: 'L1' });
  r.put({ id: 'B', classId: 'L1' });
  r.put({ id: 'C', classId: 'L2' });
  assert.equal(r.by('classId', 'L1').length, 2);

  r.patch('B', { classId: 'L2' });        // chuyển lớp
  assert.equal(r.by('classId', 'L1').length, 1);
  assert.equal(r.by('classId', 'L2').length, 2);

  r.delete('C');
  assert.equal(r.by('classId', 'L2').length, 1);
});

test('phân trang có thứ tự tất định', () => {
  const dir = tmp();
  const r = new Repository({ name: 'pg', dir });
  for (let i = 1; i <= 30; i++) r.put({ id: `k${String(i).padStart(2, '0')}`, score: (i * 7) % 11 });
  const a = r.page({ offset: 0, limit: 10, sort: 'score' });
  const b = r.page({ offset: 0, limit: 10, sort: 'score' });
  assert.deepEqual(a.items.map((x) => x.id), b.items.map((x) => x.id), 'hai lần gọi phải cùng thứ tự');
  assert.equal(a.total, 30);
  assert.ok(a.items[0].score <= a.items[9].score);
});

test('thiếu khoá chính thì từ chối, không âm thầm tạo rác', () => {
  const dir = tmp();
  const r = new Repository({ name: 'k', dir });
  assert.equal(r.put({ fullName: 'Không có mã' }).ok, false);
  assert.equal(r.put({ id: '', v: 1 }).ok, false);
  assert.equal(r.patch('KHONG-CO', { v: 1 }).ok, false);
  assert.equal(r.count(), 0);
});

test('xuất/nhập toàn bộ cơ sở dữ liệu cho khôi phục hệ thống', () => {
  const dir = tmp();
  const db = new Database({ dir });
  const learners = db.collection('learners');
  const items = db.collection('items');
  learners.put({ id: 'HV1', fullName: 'A' });
  items.put({ id: 'IT1', stem: 'Đề 1' });

  const dump = db.export();
  assert.equal(dump.learners.length, 1);

  learners.put({ id: 'HV2', fullName: 'B' });
  items.delete('IT1');
  assert.equal(learners.count(), 2);
  assert.equal(items.count(), 0);

  const back = db.import(dump);                 // quay về đúng thời điểm đã chụp
  assert.equal(back.ok, true);
  assert.equal(learners.count(), 1);
  assert.equal(items.count(), 1);
  assert.equal(learners.has('HV2'), false);
  db.close();
});

test('tên bộ sưu tập bậy bị chặn (không cho thoát ra ngoài thư mục)', () => {
  const dir = tmp();
  assert.throws(() => new Repository({ name: '../../etc/passwd', dir }));
  assert.throws(() => new Repository({ name: 'a/b', dir }));
});
