'use strict';
/** Bộ kiểm tra toán học: tự giải, tự đối chiếu, bắt được đáp án sai. */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { parse, evaluate, latexToPlain, variables, stringify } = require('../src/math/expression');
const MathVerifier = require('../src/math/verifier');

const ev = (s, v = {}) => evaluate(parse(s), v);

// ── Đọc biểu thức ───────────────────────────────────────────────────────────

test('thứ tự phép tính và luỹ thừa phải chuẩn', () => {
  assert.equal(ev('2+3*4'), 14);
  assert.equal(ev('(2+3)*4'), 20);
  assert.equal(ev('2^3^2'), 512, 'luỹ thừa kết hợp từ phải sang');
  assert.equal(ev('-2^2'), -4, 'trừ đứng trước bám lỏng hơn luỹ thừa');
  assert.equal(ev('(-2)^2'), 4);
  assert.equal(ev('8/4/2'), 1);
  assert.equal(ev('2^-2'), 0.25);
});

test('nhân ngầm hiểu đúng như người viết tay', () => {
  assert.equal(ev('3x', { x: 4 }), 12);
  assert.equal(ev('2(x+1)', { x: 3 }), 8);
  assert.equal(ev('xy', { x: 3, y: 5 }), 15);
  assert.equal(ev('(x+1)(x-1)', { x: 3 }), 8);
  assert.equal(ev('2x^2', { x: 3 }), 18, 'phải là 2·x², không phải (2x)²');
});

test('LaTeX chuẩn GITAmath đọc được', () => {
  assert.equal(ev('\\dfrac{x+1}{x-1}', { x: 3 }), 2);
  assert.equal(ev('\\sqrt{x^{2}+9}', { x: 4 }), 5);
  assert.equal(ev('\\sqrt[3]{27}'), 3);
  assert.equal(ev('2 \\cdot 3'), 6);
  assert.equal(ev('|x-5|', { x: 2 }), 3);
  assert.equal(ev('\\left( x+1 \\right)^{2}', { x: 2 }), 9);
  assert.match(latexToPlain('\\dfrac{-b+\\sqrt{b^{2}-4ac}}{2a}'), /sqrt/);
});

test('miền xác định được tôn trọng, không trả bừa một con số', () => {
  assert.ok(Number.isNaN(ev('sqrt(x)', { x: -4 })), 'căn số âm không có nghiệm thực');
  assert.ok(Number.isNaN(ev('1/x', { x: 0 })));
  assert.ok(Number.isNaN(ev('ln(x)', { x: -1 })));
  assert.ok(Number.isNaN(ev('x^(0.5)', { x: -4 })));
});

test('chuỗi hỏng bị từ chối chứ không đoán mò', () => {
  for (const bad of ['2+', '(3+4', '3 @ 4', 'sqrt(', '1..2']) {
    assert.throws(() => parse(bad), new RegExp('.'), `"${bad}" phải báo lỗi`);
  }
  assert.throws(() => ev('x+1'), /Chưa gán giá trị/);
});

test('nội dung mô hình sinh ra là dữ liệu, không phải mã chạy', () => {
  // Nếu lỡ dùng eval thì những chuỗi này sẽ chạy được. Ở đây phải ném lỗi.
  for (const evil of ['process.exit(1)', 'require("fs")', 'globalThis', '[].constructor']) {
    assert.throws(() => parse(evil).k === 'x' || evaluate(parse(evil), {}));
  }
});

test('liệt kê biến và in lại biểu thức', () => {
  assert.deepEqual([...variables(parse('a x^{2} + b x + c'))].sort(), ['a', 'b', 'c', 'x']);
  assert.match(stringify(parse('x+1')), /x \+ 1/);
});

// ── Thẩm định ───────────────────────────────────────────────────────────────

const V = () => new MathVerifier();

test('hằng đẳng thức đúng thì công nhận, sai thì chỉ ra điểm phản ví dụ', () => {
  const v = V();
  assert.equal(v.equivalent('(a+b)^2', 'a^2+2ab+b^2').equal, true);
  assert.equal(v.equivalent('(a-b)^2', 'a^2-2ab+b^2').equal, true);
  assert.equal(v.equivalent('a^2-b^2', '(a-b)(a+b)').equal, true);

  const wrong = v.equivalent('(a-b)^2', 'a^2-2ab-b^2');
  assert.equal(wrong.equal, false);
  assert.ok(wrong.mismatch, 'phải kèm điểm phản ví dụ');
  assert.match(wrong.reason, /Khác nhau tại/);
});

test('miền xác định khác nhau cũng là không tương đương', () => {
  const v = V();
  const r = v.equivalent('sqrt(x)*sqrt(x)', 'x');
  assert.equal(r.equal, false, 'x < 0 thì vế trái không xác định');
  assert.match(r.reason, /miền xác định/);
});

test('kết luận lặp lại y hệt giữa hai lần chạy', () => {
  const a = V().equivalent('(a+b)^3', 'a^3+3a^2b+3ab^2+b^3');
  const b = V().equivalent('(a+b)^3', 'a^3+3a^2b+3ab^2+b^3');
  assert.deepEqual(a.evidence, b.evidence, 'điểm lấy mẫu phải tất định');
});

test('giải phương trình bậc nhất và bậc hai chính xác', () => {
  const v = V();
  assert.deepEqual(v.solve('2x+6=0').roots, [-3]);
  assert.equal(v.solve('2x+6=0').kind, 'LINEAR');
  assert.deepEqual(v.solve('x^2-5x+6=0').roots, [2, 3]);
  assert.deepEqual(v.solve('x^2-4x+4=0').roots, [2]);
  assert.equal(v.solve('x^2-4x+4=0').delta, 0);
  assert.deepEqual(v.solve('x^2+1=0').roots, []);
  assert.ok(v.solve('x^2+1=0').delta < 0);
  assert.equal(v.solve('x^2 = 5x - 6').roots.length, 2, 'vế phải có ẩn vẫn giải được');
});

test('phương trình luôn đúng / luôn sai được gọi đúng tên', () => {
  const v = V();
  assert.equal(v.solve('2(x+1) = 2x+2').kind, 'IDENTITY');
  assert.equal(v.solve('2x+1 = 2x+3').kind, 'NO_SOLUTION');
});

test('từ chối cái vượt khả năng thay vì trả lời bừa', () => {
  const v = V();
  assert.equal(v.solve('x+y=1').error, 'MULTIVARIATE');
  assert.equal(v.solve('x+1').error, 'NOT_AN_EQUATION');
});

test('ngoài đa thức bậc hai thì chuyển sang dò số, và nói rõ đã dò', () => {
  const v = V();
  const r = v.solve('x^3 - 8 = 0');
  assert.equal(r.method, 'NUMERIC');
  assert.deepEqual(r.roots, [2]);
  assert.ok(r.caveat.includes('ngoài đoạn'), 'phải nêu giới hạn của cách dò số');
  assert.ok(r.scanned.from < 0 && r.scanned.to > 0);
});

test('phương trình chứa ẩn ở mẫu giải được, và điểm cực không bị nhận nhầm là nghiệm', () => {
  const v = V();
  assert.deepEqual(v.solve('4/(x - 1) = 2').roots, [3]);
  assert.equal(v.checkRoots('4/(x - 1) = 2', 'x = 3').correct, true);
  assert.deepEqual(v.solve('1/(x-2) = 0').roots, [], 'x=2 là điểm cực, không phải nghiệm');
  assert.equal(v.checkRoots('1/(x-2) = 0', 'x = 2').correct, false);
});

test('lượng giác dò được nghiệm trong đoạn đã quét', () => {
  const v = V();
  const r = v.solve('sin(x) = 0');
  assert.equal(r.method, 'NUMERIC');
  assert.ok(r.roots.some((x) => Math.abs(x) < 1e-6), 'phải có nghiệm x = 0');
  assert.ok(r.roots.length > 10, 'sin có vô số nghiệm, trong đoạn quét phải thấy nhiều');
});

test('bắt được đáp án thiếu nghiệm — lỗi kinh điển của học viên và của máy', () => {
  const v = V();
  const r = v.checkRoots('x^2-5x+6=0', 'x = 2');
  assert.equal(r.correct, false);
  assert.deepEqual(r.missing, [3]);
  assert.match(r.reason, /thiếu nghiệm 3/);
});

test('bắt được nghiệm bịa, kèm chứng cứ thay vào không thoả', () => {
  const v = V();
  const r = v.checkRoots('x^2-5x+6=0', 'x = 2 hoặc x = 3 hoặc x = 4');
  assert.equal(r.correct, false);
  assert.deepEqual(r.extra, [4]);
  assert.equal(r.extraProof[0].satisfied, false);
  assert.match(r.extraProof[0].reason, /2 ≠ 0|≠/);
});

test('đọc được tập nghiệm viết kiểu nào cũng được', () => {
  const v = V();
  for (const form of ['x = 2 hoặc x = 3', 'S = {2; 3}', '{2, 3}', 'x=2; x=3', '2; 3']) {
    assert.equal(v.checkRoots('x^2-5x+6=0', form).correct, true, form);
  }
  assert.deepEqual(v.checkRoots('x^2-5x+6=0', [3, 2]).correct, true, 'nhận cả mảng số');
});

test('đáp án không đọc được thì báo rõ, không im lặng cho qua', () => {
  const v = V();
  const r = v.checkRoots('x^2-5x+6=0', 'hai nghiệm dương');
  assert.equal(r.correct, false);
  assert.ok(r.unparsed.length > 0);
  assert.match(r.reason, /không đọc được/);
});

test('thay nghiệm ngược vào phương trình gốc', () => {
  const v = V();
  assert.equal(v.substitute('x^2-5x+6=0', 2).satisfied, true);
  assert.equal(v.substitute('x^2-5x+6=0', 5).satisfied, false);
  assert.equal(v.substitute('sqrt(x-3)=0', 1).satisfied, false, 'ngoài miền xác định thì không thoả');
});

test('bất phương trình: so tập nghiệm chứ không so chữ', () => {
  const v = V();
  assert.equal(v.sameSolutionSet('x-3 >= 0', 'x >= 3').same, true);
  assert.equal(v.sameSolutionSet('2x > 6', 'x > 3').same, true);
  assert.equal(v.sameSolutionSet('-2x > 6', 'x > -3').same, false, 'nhân số âm phải đổi chiều');
  assert.ok(v.sameSolutionSet('-2x > 6', 'x > -3').counterExamples.length > 0);
});

// ── Soát trọn một bài ───────────────────────────────────────────────────────

test('bài đúng được máy xác nhận, có nêu đã kiểm những gì', () => {
  const v = V();
  const r = v.verifyItem({
    stem: 'Giải phương trình x^{2}-5x+6=0',
    answer: 'x = 2 hoặc x = 3',
    check: { equation: 'x^2-5x+6=0' },
  });
  assert.equal(r.verified, true);
  assert.equal(r.verdict, 'ĐẠT');
  assert.ok(r.checks.length >= 3, 'phải có cả bước thay nghiệm ngược');
});

test('bài sai đáp án bị chặn ngay ở cửa, không vào được kho', () => {
  const v = V();
  const r = v.verifyItem({
    stem: 'Giải phương trình x^{2}-5x+6=0',
    answer: 'x = 1 hoặc x = 6',
    check: { equation: 'x^2-5x+6=0' },
  });
  assert.equal(r.verified, false);
  assert.equal(r.verdict, 'SAI');
  assert.match(r.reason, /tập nghiệm/);
});

test('bài rút gọn thiếu điều kiện xác định bị bắt, nêu đúng điều kiện còn thiếu', () => {
  const v = V();
  const thieu = v.verifyItem({ check: { expression: '\\dfrac{x^2-1}{x-1}', equals: 'x+1' } });
  assert.equal(thieu.verified, false, '(x²−1)/(x−1) không xác định tại x=1 nên chưa thể bằng x+1');
  assert.match(thieu.reason, /điều kiện|miền xác định/);
  assert.match(thieu.checks[0].detail, /x != 1/);

  const du = v.verifyItem({ check: { expression: '\\dfrac{x^2-1}{x-1}', equals: 'x+1', domain: 'x != 1' } });
  assert.equal(du.verified, true, 'nêu đủ điều kiện thì bài hợp lệ');

  const sai = v.verifyItem({ check: { expression: '\\dfrac{x^2-1}{x-1}', equals: 'x-1', domain: 'x != 1' } });
  assert.equal(sai.verified, false);
});

test('điều kiện xác định lọc đúng điểm lấy mẫu', () => {
  const v = V();
  const r = v.equivalent('1/(x-2)', '1/(x-2)', { domain: 'x != 2' });
  assert.equal(r.equal, true);
  const bad = v.equivalent('sqrt(x)*sqrt(x)', 'x', { domain: 'x >= 0' });
  assert.equal(bad.equal, true, 'nêu x ≥ 0 thì hai vế bằng nhau thật');
});

test('bài chưa khai báo phần kiểm máy thì nói thẳng là chưa kiểm được', () => {
  const v = V();
  const r = v.verifyItem({ stem: 'Chứng minh tứ giác nội tiếp', answer: 'chứng minh' });
  assert.equal(r.verified, false);
  assert.equal(r.verdict, 'KHÔNG_KIỂM_ĐƯỢC');
  assert.match(r.reason, /chưa khai báo/);
});
