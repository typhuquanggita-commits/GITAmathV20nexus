'use strict';
/**
 * TRANG CÔNG KHAI — kiểm bằng chính trang HTML sinh ra.
 *
 * Mọi mục ở đây đều là thứ công cụ tìm kiếm hoặc người đọc thật sự nhìn thấy:
 * thẻ tiêu đề dài bao nhiêu ký tự, có mấy thẻ h1, chữ trên trang có đạt chuẩn
 * tiếng Việt của chính hệ thống không. Không mục nào kiểm "hàm có chạy không".
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const web = require('../src/web/site');
const SEO = require('../src/web/seo');
const { soatChinhTa } = require('../src/lang/chinhta');
const { kiemVanPhong } = require('../src/math/vanphong');
const { FORM_INDEX } = require('../src/curriculum/hierarchy');
const { PHUONG_PHAP } = require('../src/math/scientist');

/** Bộ dữ liệu tối thiểu để dựng trang, không cần khởi động cả hệ thống. */
const N_GIA = { bank: null, agents: { length: 500 } };
const NONCE = 'nonce-kiem-dinh';
const dungTrang = (d) => {
  const [duong, truy] = d.split('?');
  const r = web.dinhTuyen(N_GIA, duong, Object.fromEntries(new URLSearchParams(truy || '')), NONCE);
  assert.ok(r && r.html, `không dựng được trang ${d}`);
  return r.html;
};

test('Mọi trang công khai đều dựng được và đạt danh mục SEO kiểm được', () => {
  const dd = web.moiDuongDan();
  assert.ok(dd.length >= 140, `mới có ${dd.length} trang`);
  const hong = [];
  for (const d of dd) {
    const s = SEO.soat(dungTrang(d), { duongDan: d });
    if (!s.ok) hong.push(`${d}: ${s.hong.map((m) => `${m.ma} (${m.moTa})`).join('; ')}`);
  }
  assert.deepEqual(hong.slice(0, 5), [], `${hong.length}/${dd.length} trang không đạt`);
});

test('Tiêu đề và thẻ mô tả của mỗi trang là duy nhất', () => {
  // Trùng tiêu đề là lỗi SEO nặng: công cụ tìm kiếm coi hai trang là một và
  // bỏ bớt một trang khỏi kết quả.
  const dd = web.moiDuongDan();
  const tieuDe = new Map();
  const moTa = new Map();
  for (const d of dd) {
    const html = dungTrang(d);
    const t = (html.match(/<title>([^<]*)<\/title>/) || [])[1];
    const m = (html.match(/name="description" content="([^"]*)"/) || [])[1];
    tieuDe.set(t, [...(tieuDe.get(t) || []), d]);
    moTa.set(m, [...(moTa.get(m) || []), d]);
  }
  const trungT = [...tieuDe.entries()].filter(([, v]) => v.length > 1);
  const trungM = [...moTa.entries()].filter(([, v]) => v.length > 1);
  assert.deepEqual(trungT.map(([k, v]) => `${k} ← ${v.join(', ')}`), []);
  assert.deepEqual(trungM.map(([, v]) => v.join(', ')), []);
});

test('Chữ trên trang đạt chuẩn tiếng Việt của chính hệ thống', () => {
  // Đây là chỗ hệ thống tự áp chuẩn lên mình: trang bán hàng của một sản phẩm
  // soát chính tả mà lại sai chính tả thì không còn gì để nói.
  const hong = [];
  for (const d of web.moiDuongDan()) {
    const van = web.vanXuoi(dungTrang(d));
    const ct = soatChinhTa(van);
    const vp = kiemVanPhong(van);
    const loi = [...ct.loi.filter((l) => l.muc === 'LOI'), ...vp.loi.filter((l) => l.muc === 'LOI')];
    if (loi.length) hong.push(`${d}: ${loi.map((l) => `${l.ma} — ${l.moTa}`).join('; ')}`);
  }
  assert.deepEqual(hong.slice(0, 5), [], `${hong.length} trang có lỗi ngôn ngữ`);
});

test('Trang đọc được khi tắt JavaScript và không gọi ra tên miền khác', () => {
  for (const d of ['/', '/chuong-trinh', '/chuong-trinh/M9.PT2.GIAI', '/lo-trinh', '/phuong-phap', '/cong-cu']) {
    const html = dungTrang(d);
    const chu = html.replace(/<script[\s\S]*?<\/script>/g, '').replace(/<style[\s\S]*?<\/style>/g, '')
      .replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    assert.ok(chu.length > 500, `${d} chỉ có ${chu.length} ký tự chữ khi bỏ hết thẻ`);
    const ngoai = (html.match(/(?:src|href)="https?:\/\/[^"]+"/g) || [])
      .filter((u) => !u.includes('schema.org') && !u.includes('gitamath.vn'));
    assert.deepEqual(ngoai, [], `${d} tải tài nguyên từ tên miền khác`);
  }
});

test('Dữ liệu có cấu trúc khai đúng loại và hợp lệ JSON', () => {
  const html = dungTrang('/chuong-trinh/M9.PT2.GIAI');
  const khoi = [...html.matchAll(/<script type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)]
    .map((m) => JSON.parse(m[1]));
  const loai = khoi.map((k) => k['@type']);
  assert.ok(loai.includes('EducationalOrganization'));
  assert.ok(loai.includes('BreadcrumbList'));
  assert.ok(loai.includes('Course'), `trang dạng bài phải khai Course, đang có ${loai.join(', ')}`);
  const course = khoi.find((k) => k['@type'] === 'Course');
  assert.equal(course.courseCode, 'M9.PT2.GIAI');
  assert.ok(course.url.startsWith('https://'));
  // Trang chủ khai ô tìm kiếm và khối hỏi đáp.
  const goc = [...dungTrang('/').matchAll(/<script type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)]
    .map((m) => JSON.parse(m[1]));
  assert.ok(goc.some((k) => k['@type'] === 'WebSite'));
  assert.ok(goc.some((k) => k['@type'] === 'FAQPage'));
});

test('Sơ đồ trang liệt kê đủ mọi đường dẫn, robots trỏ đúng sơ đồ', () => {
  const sm = web.sitemap();
  const dd = web.moiDuongDan();
  assert.equal((sm.match(/<url>/g) || []).length, dd.length);
  assert.ok(sm.startsWith('<?xml'));
  for (const f of [...FORM_INDEX.values()].slice(0, 5)) {
    assert.ok(sm.includes(`/chuong-trinh/${f.code}`), `sơ đồ trang thiếu ${f.code}`);
  }
  const rb = web.robots();
  assert.match(rb, /^User-agent: \*/m);
  assert.match(rb, /Sitemap: https?:\/\/.+\/sitemap\.xml/);
});

test('Mỗi dạng bài và mỗi phương pháp đều có một trang riêng', () => {
  // Trang riêng cho từng dạng là chiều sâu thật: 104 trang có nội dung khác
  // nhau, chứ không phải một trang lọc bằng JavaScript.
  for (const f of FORM_INDEX.values()) {
    const html = web.trangDang(N_GIA, f.code);
    assert.ok(html, `thiếu trang cho ${f.code}`);
    assert.ok(html.includes(f.name), `trang ${f.code} không nhắc tên dạng`);
    for (const t of f.traps || []) {
      const hoa = t[0].toLocaleUpperCase('vi') + t.slice(1);
      assert.ok(html.includes(SEO.esc(hoa)) || html.includes(SEO.esc(t)), `trang ${f.code} thiếu bẫy "${t}"`);
    }
  }
  for (const id of Object.keys(PHUONG_PHAP)) {
    assert.ok(web.trangMotPhuongPhap(id), `thiếu trang phương pháp ${id}`);
  }
  assert.equal(web.trangDang(N_GIA, 'KHONG_CO_MA_NAY'), null);
  assert.equal(web.trangMotPhuongPhap('khong-co'), null);
});

test('Tiêu đề và thẻ mô tả tự cắt cho vừa khung hiển thị', () => {
  const dai = 'Giải phương trình bậc hai một ẩn bằng công thức nghiệm tổng quát và định lý Vi-ét';
  const t = SEO.tieuDeVua(dai);
  assert.ok([...t].length <= SEO.NGUONG.tieuDeMax, `tiêu đề dài ${[...t].length}`);
  assert.ok(t.endsWith('| GITAmath'));
  assert.ok(!t.includes('  '), 'cắt xong không được để lại khoảng trắng thừa');
  const m = SEO.moTaVua(`${dai}. `.repeat(5));
  assert.ok([...m].length <= SEO.NGUONG.moTaMax);
  assert.ok([...m].length >= SEO.NGUONG.moTaMin);
});

test('Mọi khối mã trong trang đều mang nonce, không mở unsafe-inline', () => {
  // Mở 'unsafe-inline' là vô hiệu hoá gần hết tác dụng chặn mã lạ của chính
  // sách bảo mật nội dung. Nonce là cách giữ được cả hai: mã nội tuyến vẫn
  // chạy, mã lạ chèn vào thì không.
  for (const d of ['/', '/chuong-trinh/M9.PT2.GIAI', '/phuong-phap/feynman']) {
    const html = dungTrang(d);
    const khoi = html.match(/<(script|style)\b[^>]*>/gi) || [];
    assert.ok(khoi.length >= 2, `${d} chỉ có ${khoi.length} khối mã`);
    for (const t of khoi) assert.match(t, new RegExp(`nonce="${NONCE}"`), `${d}: khối thiếu nonce — ${t}`);
  }
});

test('Tệp mô tả ứng dụng hợp lệ và khai đúng lối vào', () => {
  const m = JSON.parse(web.manifest());
  assert.equal(m.lang, 'vi');
  assert.equal(m.start_url, '/');
  assert.equal(m.display, 'standalone');
  assert.ok(m.icons.length >= 1);
  assert.ok(m.shortcuts.length >= 2, 'nên có lối tắt tới các màn hình hay dùng');
  for (const s of m.shortcuts) assert.match(s.url, /^\//);
});

test('Bộ soát SEO thật sự bắt được trang hỏng', () => {
  // Một bộ soát không bao giờ báo lỗi là một bộ soát vô dụng.
  const hong = `<!DOCTYPE html><html lang="en"><head><title>Ngắn</title></head>
    <body><h1>A</h1><h1>B</h1><img src="https://cdn.ngoai/a.png"></body></html>`;
  const r = SEO.soat(hong, { duongDan: '/thu' });
  assert.equal(r.ok, false);
  const ma = new Set(r.hong.map((m) => m.ma));
  for (const m of ['TIEU_DE', 'MO_TA', 'MOT_H1', 'CANONICAL', 'NGON_NGU', 'ANH_CO_ALT', 'KHONG_GOI_RA_NGOAI']) {
    assert.ok(ma.has(m), `bộ soát bỏ lọt ${m}`);
  }
  assert.ok(r.diem < 60);
});

test('Giao diện: không chỗ nào gọi API xong dùng thẳng dữ liệu', () => {
  // LỖI NÀY BẮT ĐƯỢC KHI LÁI TÁM TRANG BẰNG TRÌNH DUYỆT THẬT, không phải khi
  // chạy mục kiểm. Hàm api() trả {ok:false} chứ không ném, nên chỗ gọi nào
  // dùng thẳng dữ liệu sẽ ném TypeError khi máy chủ trả 401 — và lỗi ấy giết
  // luôn phần còn lại của hàm.
  //
  // Hậu quả người dùng thấy: trang mở lên trông như bình thường, thiếu một
  // nửa nội dung, không một lời giải thích. Lỗi nằm trong bảng điều khiển
  // trình duyệt, nơi họ không bao giờ mở ra xem.
  //
  // Lần đầu chạy bộ soi này: 15 chỗ chưa canh, tất cả ở trung tâm chỉ huy.
  const { soiThuMuc } = require('../src/web/soi-giao-dien');
  const r = soiThuMuc(require('node:path').join(__dirname, '..', 'ui'));
  assert.ok(r.soTep >= 10, `mới soi ${r.soTep} tệp giao diện — quá ít, bộ soi có thể đang tìm sai chỗ`);
  assert.deepEqual(
    r.phat.map((p) => `${p.tep}:${p.dong} ${p.bien}.${p.thuocTinh}`), [],
    `${r.phat.length} chỗ gọi API xong dùng thẳng dữ liệu, chưa hỏi ok`,
  );
});

test('Giao diện: bộ soi bắt được đúng cái nó sinh ra để bắt', () => {
  // Mục kiểm tự soi chính bộ soi. Một bộ soi luôn báo ĐẠT thì vô dụng, và
  // không ai biết cho tới ngày có lỗi thật lọt qua.
  const { soiMotTep } = require('../src/web/soi-giao-dien');

  const hong = soiMotTep('thu.js', `
    async function x() {
      const r = await api('/duong/dan');
      el.innerHTML = r.items.map((i) => i.ten).join('');
    }`);
  assert.equal(hong.length, 1, 'bộ soi bỏ sót mẫu lỗi kinh điển');
  assert.equal(hong[0].bien, 'r');
  assert.equal(hong[0].thuocTinh, 'items');

  // Và không báo oan những cách viết đã an toàn.
  for (const an of [
    `const r = await api('/a'); if (!r.ok) return; el.innerHTML = r.items.length;`,
    `const r = await api('/a'); if (!G.can(r, 'x')) return; el.innerHTML = r.items.length;`,
    `const r = await api('/a'); el.innerHTML = (r.items || []).length;`,
    `const r = await api('/a'); el.innerHTML = r && r.items ? r.items.length : 0;`,
    `const r = await api('/a'); el.innerHTML = r?.items?.length;`,
    `const r = await api('/a'); if (Array.isArray(r.items)) el.innerHTML = r.items.length;`,
    `const r = await api('/a'); if (r.ok) el.innerHTML = r.items.length;`,
    `const r = await api('/a'); el.textContent = r.error || r.message;`,
  ]) {
    assert.deepEqual(soiMotTep('an.js', an), [], `báo oan cách viết đã an toàn: ${an.slice(0, 70)}`);
  }
});

test('Giao diện: không trang nào ghi cứng màu nền tối', () => {
  // LỖI NÀY CHỈ THẤY BẰNG MẮT. Bốn trang tự viết kiểu riêng và ghi cứng
  // background:#0d1117 cho ô nhập. Chế độ tối trông bình thường; chế độ sáng
  // thì nền trang sáng, chữ kế thừa màu tối của chủ đề sáng, còn ô nhập vẫn
  // tối cứng — CHỮ TỐI TRÊN NỀN TỐI, gõ mà không đọc được mình gõ gì.
  //
  // Bắt được khi chụp màn hình xưởng bài giảng rồi nhìn. Mười bảy chỗ, bốn
  // trang. Không mục kiểm nào trước đó thấy, vì tất cả đọc HTML chứ không
  // đọc MÀU.
  const { soiMauThuMuc } = require('../src/web/soi-giao-dien');
  const r = soiMauThuMuc(require('node:path').join(__dirname, '..', 'ui'));
  assert.deepEqual(
    r.phat.map((p) => `${p.tep}:${p.dong} ${p.mau}`), [],
    `${r.phat.length} chỗ ghi cứng màu tối — chế độ sáng sẽ thành chữ tối trên nền tối`,
  );
});

test('Giao diện: bộ soi màu bắt đúng và không báo oan', () => {
  const { soiMauMotTep } = require('../src/web/soi-giao-dien');
  assert.equal(soiMauMotTep('t.html', 'input{background:#0d1117}').length, 1, 'bỏ sót màu tối ghi cứng');
  assert.equal(soiMauMotTep('t.html', '.o{background:#161f3d;padding:4px}').length, 1, 'bỏ sót màu tối ghi cứng');
  for (const an of [
    'input{background:var(--bg2)}',
    '.x{background:var(--panel);color:var(--txt)}',
    '.y{background:#ffffff}',      // màu sáng: không phải lỗi này
    '.z{background:#f4f7fc}',
    '.w{border:1px solid #25335c}', // viền không nuốt chữ
  ]) {
    assert.deepEqual(soiMauMotTep('an.html', an), [], `báo oan: ${an}`);
  }
});
