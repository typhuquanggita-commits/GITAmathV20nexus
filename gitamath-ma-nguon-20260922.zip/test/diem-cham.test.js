'use strict';
/**
 * CHUỖI GIÁ TRỊ VÀ ĐIỂM CHẠM
 *
 * Mục đích của bộ kiểm này là chặn đúng một kiểu sai: báo cáo đẹp dựng trên
 * mẫu quá nhỏ. Nên phần lớn các mục dưới đây kiểm PHÍA TỪ CHỐI — khi thiếu
 * người, thiếu bài, hoặc chỉ có một nhóm, hệ thống phải nói "chưa đủ căn cứ"
 * chứ không được trả về một tỉ lệ nghe có vẻ chắc chắn.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const Telemetry = require('../src/learner/telemetry');
const { CHANG, chuoiGiaTri, doDiemCham, bienBanDiemCham, MAU_TOI_THIEU } = require('../src/nexus/diem-cham');
const { DIVISIONS } = require('../src/agents/taxonomy');

/** Dựng một bộ quan sát giả lập TẤT ĐỊNH: không random, cùng đầu vào cùng kết quả. */
function dungDuLieu({ soCo = 12, soKhong = 12, soBai = 12, dungCo = 9, dungKhong = 6, chang = 'xem-lai-bai-sai' } = {}) {
  const t = new Telemetry();
  const dauVet = CHANG.find((c) => c.id === chang).dauVet[0];
  const lam = (u, dung) => {
    t.action(u, 'SESSION_START');
    for (let i = 0; i < soBai; i++) {
      t.action(u, 'ITEM_OPEN', { itemId: `IT-${i}` });
      t.attempt(u, { itemId: `IT-${i}`, formCode: 'M9.PT2.GIAI', level: 4, stars: 3, correct: i < dung, ms: 90000 });
    }
  };
  for (let k = 0; k < soCo; k++) { const u = `CO-${k}`; lam(u, dungCo); t.action(u, dauVet, { itemId: 'IT-0' }); }
  for (let k = 0; k < soKhong; k++) { const u = `KHONG-${k}`; lam(u, dungKhong); }
  return t;
}

test('Chuỗi giá trị nào cũng gắn với một tổ có thật trong 500 trợ lý', () => {
  const c = chuoiGiaTri();
  assert.ok(c.length >= 8, `mới có ${c.length} chặng`);
  for (const x of c) {
    const khoi = DIVISIONS[x.khoi];
    assert.ok(khoi, `chặng ${x.id} gắn khối không có thật: ${x.khoi}`);
    assert.ok(khoi.squads.includes(x.to), `khối ${x.khoi} không có tổ "${x.to}"`);
    assert.ok(x.viec && x.hong, `chặng ${x.id} phải nói rõ tổ làm gì và hỏng thì mất gì`);
  }
});

test('Chặng nào cũng phải có dấu vết đo được, không có chặng nói suông', () => {
  const ACTIONS = require('../src/learner/telemetry').ACTIONS || null;
  for (const c of CHANG) {
    assert.ok(c.dauVet.length > 0, `chặng ${c.id} không có dấu vết nào`);
    for (const d of c.dauVet) {
      const t = new Telemetry();
      assert.equal(t.action('U', d).ok, true, `dấu vết "${d}" không phải thao tác hệ thống ghi được`);
    }
  }
  assert.ok(ACTIONS === null || true);
});

test('Đủ hai nhóm thì chấm được, và hiệu số đi kèm cỡ mẫu hai bên', () => {
  const t = dungDuLieu();
  const r = doDiemCham(t, 'xem-lai-bai-sai');
  assert.equal(r.duCanCu, true, r.ghiChu);
  assert.equal(r.soNguoiCo, 12);
  assert.equal(r.soNguoiKhong, 12);
  assert.equal(r.doChinhXacCo, 0.75);
  assert.equal(r.doChinhXacKhong, 0.5);
  assert.equal(r.hieu, 0.25);
  assert.match(r.ghiChu, /n=12/);
  assert.match(r.ghiChu, /không phải quan hệ nhân quả/);
});

test('Thiếu người ở MỘT nhóm là chưa đủ căn cứ, dù nhóm kia rất đông', () => {
  const t = dungDuLieu({ soCo: 200, soKhong: MAU_TOI_THIEU - 1 });
  const r = doDiemCham(t, 'xem-lai-bai-sai');
  assert.equal(r.duCanCu, false);
  assert.equal(r.hieu, null, 'chưa đủ căn cứ thì không được trả hiệu số');
  assert.match(r.ghiChu, /Chưa đủ căn cứ/);
  assert.match(r.ghiChu, /200 người chạm/);
});

test('Học viên làm ít bài không được tính vào mẫu', () => {
  const t = dungDuLieu({ soBai: 3 });
  const r = doDiemCham(t, 'xem-lai-bai-sai');
  assert.equal(r.duCanCu, false);
  assert.equal(r.soNguoiCo, 0, 'người làm 3 bài phải bị loại khỏi mẫu');
});

test('Hiệu số âm được nêu ra chứ không giấu đi', () => {
  const t = dungDuLieu({ dungCo: 4, dungKhong: 9 });
  const r = doDiemCham(t, 'xem-lai-bai-sai');
  assert.equal(r.duCanCu, true);
  assert.ok(r.hieu < 0);
  assert.equal(r.huong, 'thấp hơn');
  const bb = bienBanDiemCham(t);
  assert.equal(bb.canXemLai.changId, 'xem-lai-bai-sai');
});

test('Chặng xấu không bao giờ được gọi là điểm chạm tốt nhất', () => {
  const t = dungDuLieu({ chang: 'bo-bai', dungCo: 11, dungKhong: 3 });
  const r = doDiemCham(t, 'bo-bai');
  assert.equal(r.duCanCu, true);
  assert.ok(r.hieu > 0, 'dữ liệu dựng ra cố tình cho bỏ bài hiệu số dương');
  const bb = bienBanDiemCham(t);
  assert.notEqual(bb.totNhat && bb.totNhat.changId, 'bo-bai', 'bỏ bài không được nhận là điểm chạm tốt');
});

test('Không có dữ liệu thì nói thẳng là chưa chấm được, không trả số 0', () => {
  const bb = bienBanDiemCham(new Telemetry());
  assert.equal(bb.soChangDoDuoc, 0);
  assert.equal(bb.totNhat, null);
  assert.equal(bb.thieuCanCu.length, CHANG.length);
  assert.match(bb.ketLuan, /Chưa chặng nào đủ căn cứ/);
});

test('Hỏi một chặng không có thật thì báo lỗi, không đoán', () => {
  const r = doDiemCham(new Telemetry(), 'chang-khong-co-that');
  assert.equal(r.ok, false);
  assert.equal(r.error, 'KHÔNG_CÓ_CHẶNG_NÀY');
});
