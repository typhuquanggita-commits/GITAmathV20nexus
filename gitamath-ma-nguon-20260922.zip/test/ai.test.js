'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');

const LLMRouter = require('../src/ai/llm-router');
const AdaptiveRouter = require('../src/ai/adaptive-router');
const CategoryCache = require('../src/ai/category-cache');
const EntropyMoE = require('../src/ai/entropy-moe');
const Queue = require('../src/kernel/queue');
const { MemoryStore } = require('../src/kernel/store');

test('LLM router: chạy được không cần API key (provider mock)', async () => {
  const llm = new LLMRouter();
  assert.deepEqual(llm.available(), ['mock']);
  const r = await llm.call({ task: 'simple_chat', prompt: 'xin chao' });
  assert.equal(r.ok, true);
  assert.equal(r.provider, 'mock');
  assert.ok(r.tokensIn > 0 && r.tokensOut > 0);
});

test('LLM router: mock TẤT ĐỊNH — cùng prompt cho cùng số token', async () => {
  const llm = new LLMRouter();
  const a = await llm.call({ task: 'simple_chat', prompt: 'cau hoi giong nhau' });
  const b = await llm.call({ task: 'simple_chat', prompt: 'cau hoi giong nhau' });
  assert.equal(a.text, b.text);
  assert.equal(a.tokensOut, b.tokensOut);
});

test('LLM router: circuit breaker mở sau ngưỡng lỗi', () => {
  const llm = new LLMRouter();
  for (let i = 0; i < 5; i++) llm.breaker.fail('groq');
  assert.equal(llm.breaker.isOpen('groq'), true);
  llm.breaker.ok('groq');
  assert.equal(llm.breaker.isOpen('groq'), false);
});

test('Adaptive router: phân tích truy vấn đúng lĩnh vực', () => {
  const ar = new AdaptiveRouter({ store: new MemoryStore(), llmRouter: new LLMRouter() });
  assert.equal(ar.analyzeQuery('giai phuong trinh bac hai').domain, 'math');
  assert.equal(ar.analyzeQuery('viet function python doc file').domain, 'code');
  assert.equal(ar.analyzeQuery('viet bai tho ve mua thu').domain, 'creative');
  assert.equal(ar.analyzeQuery('hom nay the nao').domain, 'general');
});

test('Adaptive router: cập nhật hậu nghiệm Thompson Sampling', async () => {
  const store = new MemoryStore();
  const ar = new AdaptiveRouter({ store, llmRouter: new LLMRouter() });
  for (let i = 0; i < 12; i++) {
    await ar.updateReward('groq-fast', { quality: 0.95, cost: 0.1, latencyMs: 300 });
  }
  for (let i = 0; i < 12; i++) {
    await ar.updateReward('openai-strong', { quality: 0.2, cost: 1.0, latencyMs: 25000 });
  }
  const arms = await ar.armStats();
  const good = arms.find((a) => a.id === 'groq-fast');
  const bad = arms.find((a) => a.id === 'openai-strong');
  assert.ok(good.posteriorMean > bad.posteriorMean, `${good.posteriorMean} phải > ${bad.posteriorMean}`);
  assert.equal(good.trials, 12);
});

test('Adaptive router: reward luôn nằm trong [0,1]', async () => {
  const ar = new AdaptiveRouter({ store: new MemoryStore(), llmRouter: new LLMRouter() });
  const hi = await ar.updateReward('a', { quality: 1, cost: 0, latencyMs: 0 });
  const lo = await ar.updateReward('b', { quality: 0, cost: 1, latencyMs: 60000 });
  assert.ok(hi.reward >= 0 && hi.reward <= 1);
  assert.ok(lo.reward >= 0 && lo.reward <= 1);
});

test('Category cache: phân loại đúng và TẮT cache cho PII/tài chính', async () => {
  const cache = new CategoryCache({ store: new MemoryStore() });
  assert.equal(cache.classify('viet function python'), 'code');
  assert.equal(cache.classify('chung minh dinh ly Pythagoras'), 'math');
  assert.equal(cache.classify('so cccd 012345678901'), 'pii');
  assert.equal(cache.classify('chuyen khoan ngan hang'), 'financial');
  assert.equal(cache.classify('hi'), 'chat');

  assert.equal(await cache.set('so cccd 012345678901', 'x'), false, 'PII không được cache');
  assert.equal(await cache.get('so cccd 012345678901'), null);

  assert.equal(await cache.set('chung minh dinh ly Pythagoras', { a: 1 }), true);
  const hit = await cache.get('chung minh dinh ly Pythagoras');
  assert.equal(hit.category, 'math');
  assert.deepEqual(hit.value, { a: 1 });
});

test('Category cache: tôn trọng quota', async () => {
  const cache = new CategoryCache({ store: new MemoryStore() });
  cache.counts.math = 3000; // chạm quota
  assert.equal(await cache.set('dinh ly toan hoc moi', 'v'), false);
});

test('Entropy MoE: entropy thấp → K=1, entropy cao → K lớn', () => {
  const moe = new EntropyMoE({ llmRouter: new LLMRouter() });
  const focused = moe.routingDistribution('toán chứng minh định lý phương trình tích phân đạo hàm');
  const vague = moe.routingDistribution('abcdef');
  const hFocused = moe.entropy(focused);
  const hVague = moe.entropy(vague);
  assert.ok(hFocused < hVague, `${hFocused} phải < ${hVague}`);
  assert.equal(moe.selectK(0.1), 1);
  assert.equal(moe.selectK(0.4), 2);
  assert.equal(moe.selectK(0.6), 3);
  assert.equal(moe.selectK(0.95), 4);
});

test('Entropy MoE: chạy thật và tiết kiệm compute', async () => {
  const moe = new EntropyMoE({ llmRouter: new LLMRouter() });
  const r = await moe.route('toán chứng minh định lý phương trình');
  assert.equal(r.ok, true);
  assert.ok(r.k >= 1 && r.k <= 4);
  assert.ok(r.output.length > 0);
  assert.ok(moe.status().computeSavedPct > 0);
});

test('Queue: ưu tiên critical chạy trước low', async () => {
  const q = new Queue({ concurrency: 1 });
  const order = [];
  q.registerWorker('t', async (job) => { order.push(job.data.tag); }, { concurrency: 1 });
  q.enqueue('t', { tag: 'low' }, { priority: 'low' });
  q.enqueue('t', { tag: 'critical' }, { priority: 'critical' });
  q.enqueue('t', { tag: 'normal' }, { priority: 'normal' });
  await q.drainAll(3000);
  q.stop();
  assert.equal(order[0], 'critical');
  assert.ok(order.indexOf('normal') < order.indexOf('low'));
});

test('Queue: retry rồi đánh dấu thất bại', async () => {
  const q = new Queue({ concurrency: 2 });
  let attempts = 0;
  q.registerWorker('fail', async () => { attempts++; throw new Error('boom'); }, { concurrency: 1 });
  q.enqueue('fail', {}, { maxAttempts: 3 });
  await q.drainAll(6000);
  await new Promise((r) => setTimeout(r, 1200));
  await q.drainAll(3000);
  q.stop();
  assert.ok(attempts >= 2, `đã thử ${attempts} lần`);
});
