'use strict';
/**
 * BỘ KHẢO SÁT VÀ LỘ TRÌNH CÁ NHÂN HOÁ
 *
 * Bộ kiểm này canh một điều: sáu công cụ có sức nặng bằng chứng rất khác nhau
 * không được trộn lẫn. Chỗ dễ hỏng nhất không phải phép tính — mà là việc một
 * kết quả tự khai lặng lẽ trôi vào quyết định học viên học gì. Nên phần lớn
 * các mục dưới đây kiểm PHÍA CHẶN, và mục nào cũng đòi luật đo chứng minh
 * mình có răng.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const luat = require('../src/khao-sat/hien-phap-do');
const D = require('../src/khao-sat/disc');
const M = require('../src/khao-sat/mbti');
const TS = require('../src/khao-sat/than-so');
const TL = require('../src/khao-sat/tam-ly-hoc-duong');
const PP = require('../src/khao-sat/phuong-phap-hoc');
const NH = require('../src/khao-sat/nam-hoc');
const HS = require('../src/khao-sat/ho-so');
const LT = require('../src/khao-sat/lo-trinh-ca-nhan');
const { FORM_INDEX, gradeOf, subjectOf } = require('../src/curriculum/hierarchy');

const day = (de, f) => de.map(f);

// ═══ LUẬT ĐO — ranh giới quan trọng nhất ═══════════════════════════════════

test('Chỉ ĐÚNG HAI công cụ được phép quyết định nội dung học', () => {
  const duoc = luat.CONG_CU.filter((c) => c.anhHuong.includes('noi-dung')).map((c) => c.ma).sort();
  assert.deepEqual(duoc, ['NANG_LUC_MON', 'PHUONG_PHAP_HOC']);
  // Và cả hai đều phải là công cụ đối chiếu được, không phải tự khai thuần tuý.
  for (const ma of duoc) {
    const c = luat.CONG_CU_INDEX.get(ma);
    assert.ok(c.loai === 'do-luong' || ma === 'PHUONG_PHAP_HOC', `${ma} không đủ tư cách quyết định nội dung`);
  }
});

test('Tính cách KHÔNG được quyết định học viên học dạng bài nào', () => {
  for (const ma of ['DISC', 'MBTI', 'THAN_SO']) {
    const g = luat.duocAnhHuong(ma, 'noi-dung');
    assert.equal(g.ok, false, `${ma} đang được phép chạm nội dung`);
    assert.match(g.reason, /không đo|không dự đoán|không phải/i);
  }
});

test('Thần số học có danh sách miền ảnh hưởng RỖNG — kể cả cách nói', () => {
  const c = luat.CONG_CU_INDEX.get('THAN_SO');
  assert.equal(c.anhHuong.length, 0);
  for (const mien of luat.MIEN) assert.equal(luat.duocAnhHuong('THAN_SO', mien).ok, false, `lọt ở miền ${mien}`);
});

test('Công cụ hoặc miền không có thật thì báo lỗi, không đoán', () => {
  assert.equal(luat.duocAnhHuong('TU_VI', 'noi-dung').error, 'KHÔNG_CÓ_CÔNG_CỤ_NÀY');
  assert.equal(luat.duocAnhHuong('MBTI', 'so-phan').error, 'KHÔNG_CÓ_MIỀN_NÀY');
});

test('Công cụ nào cũng phải khai rõ mình KHÔNG đo được gì', () => {
  for (const c of luat.CONG_CU) {
    assert.ok(c.khongDoDuoc && c.khongDoDuoc.length > 25, `${c.ma} chưa nói rõ mình không đo được gì`);
    assert.ok(c.ghiChu && c.ghiChu.length > 25, `${c.ma} thiếu cảnh báo đi kèm`);
  }
});

// ═══ DISC ══════════════════════════════════════════════════════════════════

test('DISC: thiếu câu thì KHÔNG chấm, không trả bốn con số vô nghĩa', () => {
  const r = D.cham(day(D.deBai().slice(0, 5), (c) => ({ so: c.so, dungNhat: 'D', itDungNhat: 'S' })));
  assert.equal(r.duCanCu, false);
  assert.equal(r.diem, undefined, 'chưa đủ căn cứ thì không được trả điểm');
  assert.match(r.ghiChu, /không nói lên điều gì/);
});

test('DISC: bốn nhóm ngang nhau thì KHÔNG ép ra nhãn', () => {
  const de = D.deBai();
  const r = D.cham(de.map((c, i) => ({ so: c.so, dungNhat: D.MA_NHOM[i % 4], itDungNhat: D.MA_NHOM[(i + 2) % 4] })));
  assert.equal(r.duCanCu, true);
  assert.equal(r.nhomTroi, null);
  assert.match(r.ghiChu, /hoàn toàn bình thường/);
});

test('DISC: có nhóm trội thì nói rõ đây là thang ipsative', () => {
  const r = D.cham(day(D.deBai(), (c) => ({ so: c.so, dungNhat: 'S', itDungNhat: 'D' })));
  assert.equal(r.nhomTroi, 'S');
  assert.match(r.ghiChu, /TRONG CHÍNH EM NÀY/);
  assert.match(r.ghiChu, /không nói gì về năng lực/);
});

test('DISC: vị trí bốn lựa chọn xoay vòng, không để một nhóm nằm lì đầu bảng', () => {
  const dau = D.deBai().map((c) => c.luaChon[0].ma);
  assert.equal(new Set(dau).size, 4, 'vị trí đầu phải đủ cả bốn nhóm');
});

test('DISC: chọn cùng một ý cho cả hai ô là lỗi, không lặng lẽ bỏ qua', () => {
  const r = D.cham(day(D.deBai(), (c) => ({ so: c.so, dungNhat: 'D', itDungNhat: 'D' })));
  assert.equal(r.duCanCu, false);
  assert.ok(r.loi.length >= 20);
});

// ═══ MBTI ══════════════════════════════════════════════════════════════════

test('MBTI: thiếu câu ở MỘT cặp là không chấm, dù tổng vẫn nhiều', () => {
  const de = M.deBai().filter((c) => c.cap !== 'JP');
  const r = M.cham(day(de, (c) => ({ so: c.so, chon: M.CAP[c.cap].trai })));
  assert.equal(r.duCanCu, false);
  assert.match(r.ghiChu, /JP: 0\/8/);
  assert.match(r.ghiChu, /là bịa/);
});

test('MBTI: cặp sát ranh giới được đánh dấu, không in bốn chữ trơn tru', () => {
  const de = M.deBai();
  const r = M.cham(de.map((c, i) => ({
    so: c.so,
    chon: c.cap === 'TF' ? (i % 2 ? M.CAP.TF.trai : M.CAP.TF.phai) : M.CAP[c.cap].trai,
  })));
  assert.equal(r.duCanCu, true);
  assert.ok(r.loai.includes('?'), `loại "${r.loai}" phải có dấu hỏi ở cặp sát ranh`);
  assert.equal(r.soSatRanh, 1);
  assert.match(r.ghiChu, /điểm yếu đã biết của công cụ/);
});

test('MBTI: luôn kèm câu chặn — không dùng loại để quyết định học gì', () => {
  const r = M.cham(day(M.deBai(), (c) => ({ so: c.so, chon: M.CAP[c.cap].trai })));
  assert.match(r.canhBao, /KHÔNG được dùng để quyết định/);
});

// ═══ THẦN SỐ HỌC ═══════════════════════════════════════════════════════════

test('Thần số học: phép rút số đúng quy ước, giữ số bậc thầy', () => {
  assert.equal(TS.rutSo(29).so, 11);
  assert.equal(TS.rutSo(38).so, 11);
  assert.equal(TS.rutSo(22).so, 22);
  assert.equal(TS.rutSo(33).so, 33);
  assert.equal(TS.rutSo(2011).so, 4);
  assert.equal(TS.rutSo(9).so, 9);
});

test('Thần số học: bảng chữ Pythagore đúng A=1 … I=9, J=1 … R=9, S=1 … Z=8', () => {
  assert.equal(TS.giaTriChu('A'), 1);
  assert.equal(TS.giaTriChu('I'), 9);
  assert.equal(TS.giaTriChu('J'), 1);
  assert.equal(TS.giaTriChu('R'), 9);
  assert.equal(TS.giaTriChu('S'), 1);
  assert.equal(TS.giaTriChu('Z'), 8);
});

test('Thần số học: NÓI RA rằng bỏ dấu làm hai tên khác nhau ra cùng số', () => {
  assert.equal(TS.suMenh('Tuấn').so, TS.suMenh('Tuân').so);
  const r = TS.tinh({ hoTen: 'Lê Minh Tuấn', ngaySinh: '2010-03-15' });
  assert.match(r.quyUoc, /thô tới mức đó/);
});

test('Thần số học: kết quả LUÔN mang theo cảnh báo và "dùng vào việc: không"', () => {
  const r = TS.tinh({ hoTen: 'Trần Bảo Ngọc', ngaySinh: '2012-11-02' });
  assert.equal(r.ok, true);
  assert.equal(r.dungVaoViec, 'không');
  assert.match(r.canhBao, /không có bằng chứng khoa học/i);
  assert.match(r.canhBao, /KHÔNG dùng nó vào bất kỳ quyết định nào/);
});

test('Thần số học: mô tả viết ở thì "người ta thường nói", không khẳng định', () => {
  for (const [so, chu] of Object.entries(TS.MO_TA)) {
    assert.match(chu, /người ta thường|được coi là/i, `số ${so} đang viết ở thì khẳng định`);
  }
});

// ═══ TÂM LÝ HỌC ĐƯỜNG ══════════════════════════════════════════════════════

test('Sàng lọc tâm lý: miền an toàn vượt ngưỡng là báo NGAY cho người lớn', () => {
  const r = TL.cham(day(TL.deBai(), (c) => ({ so: c.so, diem: c.mien === 'AN_TOAN' ? 2 : 0 })));
  assert.equal(r.canNguoiLonNgay, true);
  assert.ok(r.aiCanBiet.includes('giáo viên chủ nhiệm'));
  assert.match(r.ketLuan, /không phải việc em tự xoay/);
});

test('Sàng lọc tâm lý: KHÔNG bao giờ in ra một cái tên bệnh', () => {
  const r = TL.cham(day(TL.deBai(), (c) => ({ so: c.so, diem: 4 })));
  const chu = JSON.stringify(r).toLowerCase();
  for (const ten of ['trầm cảm', 'rối loạn', 'chẩn đoán mắc', 'bệnh lý', 'adhd', 'tự kỷ']) {
    assert.equal(chu.includes(ten), false, `kết quả đang in ra "${ten}"`);
  }
  assert.match(r.khongPhaiChanDoan, /SÀNG LỌC, không phải chẩn đoán/);
});

test('Sàng lọc tâm lý: nói thẳng là KHÔNG sàng lọc ý định tự hại, và vì sao', () => {
  const r = TL.cham(day(TL.deBai(), (c) => ({ so: c.so, diem: 0 })));
  assert.match(r.khongLam, /KHÔNG hỏi về ý định tự hại/);
  assert.match(r.khongLam, /người được đào tạo/);
  assert.match(r.khongLam, /chuyên viên tâm lý học đường|cơ sở y tế/);
  // Và bộ câu hỏi thật sự không có câu nào về tự hại.
  const chu = TL.CAU.map((c) => c[1]).join(' ').toLowerCase();
  for (const tu of ['tự hại', 'tự tử', 'kết thúc cuộc sống', 'biến mất khỏi']) {
    assert.equal(chu.includes(tu), false, `đề đang hỏi về "${tu}"`);
  }
});

test('Sàng lọc tâm lý: điểm ngoài thang 0–4 bị từ chối', () => {
  const r = TL.cham([{ so: 1, diem: 7 }, { so: 2, diem: -1 }]);
  assert.equal(r.loi.length, 2);
});

// ═══ PHƯƠNG PHÁP HỌC ═══════════════════════════════════════════════════════

test('Phương pháp học: bắt được chỗ LỆCH giữa lời tự khai và dấu vết thật', () => {
  const de = PP.deBai();
  const r = PP.cham(
    de.map((c) => ({ so: c.so, diem: c.mien === 'TU_KIEM' ? 4 : 2 })),
    { metrics: { items: 60, sessions: 12, carelessRate: 0.5, fastWrongRate: 0.1, medianSpeedRatio: 1.0, avgSessionMinutes: 22 } },
  );
  const lech = r.choLech.find((x) => x.ma === 'TU_KIEM');
  assert.ok(lech, 'phải bắt được chỗ lệch ở miền Tự kiểm tra lại bài');
  assert.match(lech.chu, /tin mình làm việc này tốt hơn thực tế/);
  assert.match(r.ketLuan, /Chỗ lệch đáng nói hơn/);
});

test('Phương pháp học: không có dấu vết thì NÓI RÕ là chưa đối chiếu được', () => {
  const r = PP.cham(day(PP.deBai(), (c) => ({ so: c.so, diem: 4 })));
  assert.match(r.ghiChu, /CHƯA đối chiếu được/);
  assert.match(r.ghiChu, /điều em tự nói về mình/);
});

test('Phương pháp học: miền chưa đo được bằng dấu vết thì khai thẳng, không suy bừa', () => {
  const r = PP.cham(
    day(PP.deBai(), (c) => ({ so: c.so, diem: 3 })),
    { metrics: { items: 60, sessions: 12, carelessRate: 0.1, fastWrongRate: 0.1, medianSpeedRatio: 1, avgSessionMinutes: 30 } },
  );
  const chua = r.mien.filter((m) => m.duCanCu && m.chuaDoiChieu);
  assert.ok(chua.length >= 1);
  for (const m of chua) assert.ok(m.viSaoChuaDoiChieu && m.viSaoChuaDoiChieu.length > 20, `${m.ma} không nói vì sao`);
});

test('Phương pháp học: mọi câu đều thuộc một miền có thật', () => {
  for (const [mien, hoi] of PP.CAU) {
    assert.ok(PP.MIEN[mien], `câu "${hoi}" gắn miền không có thật: ${mien}`);
  }
});

// ═══ ĐỀ NĂNG LỰC THEO NĂM HỌC ══════════════════════════════════════════════

test('Đề KHÔNG hỏi phần chưa dạy tới mốc đó', () => {
  for (const m of NH.MOC) {
    const pv = NH.phamVi({ lop: 9, mocMa: m.ma });
    assert.equal(pv.ok, true);
    const hoi = new Set(pv.dangCungLop);
    for (const ma of pv.dangChuaDay) assert.equal(hoi.has(ma), false, `${m.ten} đang hỏi dạng chưa dạy ${ma}`);
    // Dạng của lớp dưới thì luôn được hỏi — thực lực không quên phần nền.
    for (const ma of pv.dangLopTruoc) assert.ok(gradeOf(ma) < 9, `${ma} không phải dạng lớp dưới`);
  }
});

test('Phạm vi lớn dần theo mốc, và cuối năm phủ hết chương trình', () => {
  const soDang = NH.MOC.map((m) => NH.phamVi({ lop: 9, mocMa: m.ma }).dangCungLop.length);
  for (let i = 1; i < soDang.length; i++) assert.ok(soDang[i] >= soDang[i - 1], `mốc ${i} hẹp hơn mốc trước`);
  assert.equal(NH.phamVi({ lop: 9, mocMa: 'CUOI_HK2' }).dangChuaDay.length, 0, 'cuối năm phải phủ hết');
});

test('Ma trận đề dồn trọng số vào vận dụng và vận dụng cao', () => {
  const cao = NH.MA_TRAN_GIOI.filter((m) => m.sao >= 4).reduce((s, m) => s + m.share, 0);
  const caoTruong = NH.MA_TRAN_TRUONG.filter((m) => m.sao >= 4).reduce((s, m) => s + m.share, 0);
  assert.ok(cao >= 0.6, `mới ${cao} ở mức 4★–5★`);
  assert.ok(cao > caoTruong * 3, 'phải nặng hơn hẳn đề trường ở phần phân loại');
  const tong = NH.MA_TRAN_GIOI.reduce((s, m) => s + m.share, 0);
  assert.ok(Math.abs(tong - 1) < 1e-9, `tổng tỉ trọng là ${tong}`);
});

test('Phân bổ câu luôn cộng đúng tổng, không rơi rớt câu nào', () => {
  for (const n of [8, 12, 20, 25, 30, 40, 60]) {
    const pb = NH.phanBo(n);
    assert.equal(pb.theoMuc.reduce((s, x) => s + x.soCau, 0), pb.tongCau, `lệch ở đề ${n} câu`);
  }
});

test('Quy đổi học lực LUÔN tự gọi mình là ước lượng, không in điểm trường cụ thể', () => {
  for (const t of [0, 0.25, 0.45, 0.6, 0.72, 0.95]) {
    const q = NH.quyDoiHocLuc(t);
    assert.equal(q.ok, true);
    assert.equal(q.laUocLuong, true);
    assert.match(q.ghiChu, /ƯỚC LƯỢNG, không phải điểm trường/);
    assert.match(q.uocLuongTruong, /thường|chưa ước lượng/, 'không được khẳng định một con số');
  }
  assert.equal(NH.quyDoiHocLuc(1.5).ok, false);
});

test('Đề luôn nhắc rằng 60% ở đây KHÔNG phải học lực trung bình', () => {
  const d = NH.moTaDe({ lop: 9, mocMa: 'GIUA_HK1' });
  assert.match(d.nhac, /KHÔNG phải đề trường/);
  assert.match(d.nhac, /55–70%/);
});

// ═══ HỒ SƠ ═════════════════════════════════════════════════════════════════

test('Hồ sơ chia ba tầng, thần số học nằm ở tầng "không dùng vào việc gì"', () => {
  const h = HS.dungHoSo({ hocVienId: 'HV01', lop: 9, ketQua: {} });
  assert.equal(h.ok, true);
  assert.equal(HS.tangCua('THAN_SO'), 3);
  assert.equal(HS.tangCua('MBTI'), 2);
  assert.equal(HS.tangCua('NANG_LUC_MON'), 1);
  const than = h.phan.find((p) => p.ma === 'THAN_SO');
  assert.deepEqual(than.duocDungDe, []);
});

test('Hồ sơ thiếu công cụ tầng 1 thì nói thẳng là chưa dựng được lộ trình', () => {
  const h = HS.dungHoSo({ hocVienId: 'HV01', lop: 9, ketQua: { THAN_SO: TS.tinh({ hoTen: 'A B', ngaySinh: '2010-01-01' }) } });
  assert.equal(h.duDeDungLoTrinh, false);
  assert.match(h.ketLuan, /Chưa dựng được lộ trình/);
});

// ═══ LỘ TRÌNH CÁ NHÂN HOÁ ══════════════════════════════════════════════════

function hoSoDu({ anToan = 0, tapTrung = 3 } = {}) {
  return HS.dungHoSo({
    hocVienId: 'HV-THU', hoTen: 'Học Viên Thử', lop: 9,
    ketQua: {
      DISC: D.cham(day(D.deBai(), (c) => ({ so: c.so, dungNhat: 'C', itDungNhat: 'I' }))),
      MBTI: M.cham(day(M.deBai(), (c) => ({ so: c.so, chon: M.CAP[c.cap].phai }))),
      THAN_SO: TS.tinh({ hoTen: 'Học Viên Thử', ngaySinh: '2011-07-29' }),
      PHUONG_PHAP_HOC: PP.cham(day(PP.deBai(), (c) => ({ so: c.so, diem: c.mien === 'TAP_TRUNG' ? tapTrung : 3 }))),
      TAM_LY_HOC_DUONG: TL.cham(day(TL.deBai(), (c) => ({ so: c.so, diem: c.mien === 'AN_TOAN' ? anToan : 0 }))),
    },
  });
}

test('Lộ trình có đủ sáu chặng, chặng cuối là THI TỔNG KẾT mức vận dụng cao', () => {
  const lt = LT.dungLoTrinh({ hoSo: hoSoDu(), lop: 9 });
  assert.equal(lt.ok, true, lt.reason);
  assert.equal(lt.soChang, 6);
  lt.chang.forEach((c, i) => {
    assert.equal(c.thu, i + 1);
    assert.ok(c.baiTestCua, `chặng ${c.thu} thiếu bài test cửa`);
    assert.ok(c.baiTestCua.dieuKienQua.includes('4★–5★'), 'điều kiện qua phải soi phần vận dụng cao');
  });
  const cuoi = lt.chang[5];
  assert.equal(cuoi.baiTestCua.laThiTongKet, true);
  assert.match(cuoi.baiTestCua.tenDe, /Thi tổng kết/);
  assert.ok(cuoi.baiTestCua.tongCau > lt.chang[0].baiTestCua.tongCau, 'đề tổng kết phải dài hơn test cửa');
});

test('Thần số học bị luật chặn NGAY TRONG lộ trình, và chỗ chặn để lại vết', () => {
  const lt = LT.dungLoTrinh({ hoSo: hoSoDu(), lop: 9 });
  const chan = lt.daTuChoi.find((x) => x.congCu === 'THAN_SO');
  assert.ok(chan, 'phải có vết luật đo chặn thần số học');
  assert.match(chan.lyDo, /không được phép/);
  // Và không trường nào của lộ trình có nguồn là thần số học.
  assert.equal(lt.vetNguon.some((v) => v.congCu === 'THAN_SO'), false);
});

test('Mọi lần dùng kết quả khảo sát đều tra ngược được về công cụ và miền', () => {
  const lt = LT.dungLoTrinh({ hoSo: hoSoDu(), lop: 9 });
  assert.ok(lt.vetNguon.length >= 3);
  for (const v of lt.vetNguon) {
    assert.ok(luat.CONG_CU_INDEX.has(v.congCu), `vết trỏ tới công cụ không có thật: ${v.congCu}`);
    assert.ok(luat.MIEN.includes(v.mien), `vết trỏ tới miền không có thật: ${v.mien}`);
    // Vết nào cũng phải là một phép dùng ĐƯỢC LUẬT CHO PHÉP.
    assert.equal(luat.duocAnhHuong(v.congCu, v.mien).ok, true, `${v.congCu} không được phép chạm ${v.mien}`);
    assert.ok(v.truong && v.viec, 'vết phải nói rõ ảnh hưởng tới trường nào và để làm gì');
  }
});

test('Cửa an toàn: chưa có người lớn nói chuyện thì KHÔNG dựng lộ trình', () => {
  const lt = LT.dungLoTrinh({ hoSo: hoSoDu({ anToan: 2 }), lop: 9 });
  assert.equal(lt.ok, false);
  assert.equal(lt.error, 'CẦN_NGƯỜI_LỚN_TRƯỚC');
  assert.match(lt.reason, /làm hỏng thêm/);
  assert.match(lt.canGi, /ten, vai, luc/);
});

test('Cửa an toàn mở được, nhưng GHI TÊN người đã nói chuyện vào lộ trình', () => {
  const lt = LT.dungLoTrinh({
    hoSo: hoSoDu({ anToan: 2 }), lop: 9,
    nguoiLonDaNoiChuyen: { ten: 'Cô Lan', vai: 'giáo viên chủ nhiệm', luc: Date.now() },
  });
  assert.equal(lt.ok, true);
  assert.equal(lt.cuaAnToan.daMo, true);
  assert.equal(lt.cuaAnToan.boi.ten, 'Cô Lan');
});

test('Cửa an toàn KHÔNG mở bằng một giá trị qua loa', () => {
  for (const xn of [true, 'xong rồi', {}, { ten: 'X' }, { ten: 'X', vai: 'Y' }]) {
    const lt = LT.dungLoTrinh({ hoSo: hoSoDu({ anToan: 2 }), lop: 9, nguoiLonDaNoiChuyen: xn });
    assert.equal(lt.ok, false, `mở được bằng ${JSON.stringify(xn)}`);
  }
});

test('Áp lực học tập cao thì GIẢM tải, và nói rõ đó là quyết định học tập', () => {
  const hs = HS.dungHoSo({
    hocVienId: 'HV-AL', lop: 9,
    ketQua: {
      PHUONG_PHAP_HOC: PP.cham(day(PP.deBai(), (c) => ({ so: c.so, diem: 3 }))),
      TAM_LY_HOC_DUONG: TL.cham(day(TL.deBai(), (c) => ({ so: c.so, diem: c.mien === 'AP_LUC' ? 3 : 0 }))),
    },
  });
  const lt = LT.dungLoTrinh({ hoSo: hs, lop: 9 });
  assert.equal(lt.ok, true);
  assert.ok(lt.nhip.buoiMoiTuan < LT.NHIP_CHUAN.buoiMoiTuan);
  assert.match(lt.nhip.ghiChu, /không phải một sự nhân nhượng/);
});

test('Chưa qua cửa nghĩa là KÉO DÀI chặng, không phải trượt', () => {
  const lt = LT.dungLoTrinh({ hoSo: hoSoDu(), lop: 9 });
  for (const c of lt.chang.slice(0, 5)) {
    assert.match(c.khongQuaThiSao, /KÉO DÀI/);
    assert.match(c.khongQuaThiSao, /xây trên nền rỗng/);
  }
  assert.match(lt.chang[5].khongQuaThiSao, /Không hạ chuẩn đề/);
});

test('Chấm cửa: đủ tổng nhưng hụt phần khó thì KHÔNG qua', () => {
  const r = LT.chamCua({ soDung: 13, tongCau: 20, dungVanDungCao: 3, tongVanDungCao: 13 });
  assert.equal(r.quaTong, true);
  assert.equal(r.quaCao, false);
  assert.equal(r.qua, false);
  assert.match(r.viSao, /gom điểm ở phần dễ/);
});

test('Chấm cửa: đạt cả hai điều kiện mới qua, và kèm ước lượng học lực', () => {
  const r = LT.chamCua({ soDung: 15, tongCau: 20, dungVanDungCao: 8, tongVanDungCao: 13 });
  assert.equal(r.qua, true);
  assert.ok(r.uocLuongHocLuc);
  assert.match(r.nhac, /KHÔNG phải đề trường/);
});
