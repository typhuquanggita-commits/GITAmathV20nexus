'use strict';
// Kho dữ liệu RIÊNG cho lần chạy này. Bộ kiểm mà ghi thẳng vào data/db thì nó
// vừa làm bẩn dữ liệu thật (tài khoản kiểm thử ở lại, cửa khởi tạo đóng luôn
// cho lần sau), vừa có quyền xoá và nén ảnh chụp của dữ liệu thật. Đặt biến
// môi trường TRƯỚC khi require('../src/index'), vì tầng dữ liệu đọc chúng ngay
// lúc nạp mô-đun.
const _tmpKho = require('node:fs').mkdtempSync(require('node:path').join(require('node:os').tmpdir(), 'gita-test-'));
process.env.DB_DIR = require('node:path').join(_tmpKho, 'db');
process.env.SNAPSHOT_DIR = require('node:path').join(_tmpKho, 'snap');

/**
 * CHUẨN TIẾNG VIỆT CHO HỌC LIỆU
 *
 * Bộ soát này quyết định học liệu nào được phép đến tay học sinh, nên nó phải
 * đúng ở CẢ HAI PHÍA: bắt được lỗi thật, và không bắt oan chữ đúng. Phần lớn
 * các mục dưới đây kiểm phía thứ hai — đó mới là chỗ một bộ soát chính tả
 * thường làm hỏng việc.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const C = require('../src/lang/chinhta');
const D = require('../src/lang/docde');
const { TuVung } = require('../src/lang/tuvung');
const { LanguageScientist } = require('../src/lang/scientist');
const { parseSyllable } = require('../src/voice/phonemizer');

// ═══ ĐẶT DẤU THANH ═════════════════════════════════════════════════════════

test('Dấu thanh đặt đúng âm chính theo luật, hai kiểu viết đều dựng được', () => {
  // Kiểu mới (sách giáo khoa hiện hành) đặt dấu trên âm chính; kiểu cũ lùi về
  // âm đệm cho cân mắt. Cả hai đều đọc đúng, hệ thống dựng được cả hai.
  const ca = [
    ['hoa', 'hoà', 'hòa'], ['thuy', 'thuỷ', 'thủy'], ['khoe', 'khoẻ', 'khỏe'],
  ];
  for (const [, moi, cu] of ca) {
    assert.equal(C.datLaiDauThanh(cu), moi, `${cu} → kiểu mới phải là ${moi}`);
    assert.equal(C.datLaiDauThanh(moi, { kieu: 'cu' }), cu, `${moi} → kiểu cũ phải là ${cu}`);
  }
  // Không có âm đệm thì hai kiểu trùng nhau.
  for (const t of ['của', 'mía', 'nghiêng', 'cuộc', 'tiếng', 'giữa']) {
    assert.equal(C.datLaiDauThanh(t), t, t);
    assert.equal(C.datLaiDauThanh(t, { kieu: 'cu' }), t, t);
  }
  // Gõ sai vị trí thì sửa được về đúng.
  assert.equal(C.datLaiDauThanh('trứơc'), 'trước');
  assert.equal(C.datLaiDauThanh('qùy'), 'quỳ');
});

test('"của" là nguyên âm đôi, không phải âm đệm — dấu rơi vào chữ u', () => {
  // Đây là lỗi đã thật sự xảy ra: coi "ua" như âm đệm + âm chính thì máy viết
  // ra "cuả", và bộ đọc giọng nói cũng đọc sai luôn.
  const p = parseSyllable('cua');
  assert.equal(p.glide, null, 'trong "cua" thì u KHÔNG phải âm đệm');
  assert.equal(p.nucleus.text, 'ua');
  // Còn "tuân", "tuy", "tuế" thì u đúng là âm đệm.
  for (const [tu, dem] of [['tuân', 'u'], ['tuy', 'u'], ['tuế', 'u'], ['hoa', 'o']]) {
    assert.equal(parseSyllable(tu).glide, dem, tu);
  }
});

// ═══ SOÁT CHÍNH TẢ ═════════════════════════════════════════════════════════

test('Bắt được lỗi gõ, teencode và cách trình bày sai', () => {
  const r = C.soatChinhTa('Bai nay kho qua, em ko lam dc bn oi . Chúng ta cùng hoc nhé');
  const ma = new Set(r.loi.map((l) => l.ma));
  assert.ok(ma.has('TEENCODE'), 'phải bắt được "ko", "dc", "bn"');
  assert.ok(ma.has('DAU_CACH_TRUOC_DAU_CAU'));
  assert.equal(r.ok, false);
  for (const l of r.loi) assert.ok(l.cach && l.cach.length > 3, `lỗi ${l.ma} thiếu cách sửa`);
  assert.equal(C.soatChinhTa('Ta có ∆ = 1 > 0. Suy ra phương trình có hai nghiệm phân biệt.').ok, true);
});

test('KHÔNG bắt oan: từ mượn, chữ viết tắt, ký hiệu và đơn vị đo', () => {
  // Mỗi chuỗi dưới đây đều từng bị một phiên bản trước của bộ soát báo sai.
  const sach = [
    'Hàm lôgarit và vectơ trong không gian.',
    'Tìm ƯCLN và BCNN của hai số.',
    'Quả cân nặng 5 kg, thanh gỗ dài 2 m.',
    'Tính Δ theo công thức b² − 4ac.',
    'Dạng M9.PT2.GIAI thuộc chương trình lớp 9.',
    'Đo tiến bộ, không đo lượt bấm.',
  ];
  for (const s of sach) {
    const r = C.soatChinhTa(s);
    assert.deepEqual(r.loi.filter((l) => l.muc === 'LOI').map((l) => `${l.ma}: ${l.moTa}`), [], `bắt oan: "${s}"`);
  }
});

test('Chữ Đ hoa không bị nhầm thành chữ thường', () => {
  // Dải Unicode "à-ỹ" chứa cả Đ hoa; lấy dải đó làm lớp chữ thường thì câu mở
  // đầu bằng "Đo tiến bộ…" bị báo là không viết hoa.
  const r = C.soatChinhTa('Đo tiến bộ theo tuần. Đúng hay sai đều ghi lại.');
  assert.equal(r.loi.filter((l) => l.ma === 'KHONG_VIET_HOA').length, 0);
  assert.equal(C.soatChinhTa('đo tiến bộ theo tuần rồi ghi lại kết quả.').loi.some((l) => l.ma === 'KHONG_VIET_HOA'), true);
});

test('Công thức toán không bị đem đi soát chính tả tiếng Việt', () => {
  const r = C.soatChinhTa('Tìm $\\text{ƯCLN}(36, 88)$ và $\\text{BCNN}(36, 88)$.');
  assert.deepEqual(r.loi.filter((l) => l.ma === 'AM_TIET_SAI'), []);
});

test('Chuẩn hoá chỉ sửa cách trình bày, không đụng vào nghĩa', () => {
  const vao = 'Bài  toán này rất hay . Em làm  được rồi...Chúng ta cùng học';
  const ra = C.chuanHoaChinhTa(vao);
  assert.equal(ra, 'Bài toán này rất hay. Em làm được rồi…Chúng ta cùng học');
  // Không được tự ý đổi từ: máy không biết người viết định nói "bàn" hay "bàng".
  assert.equal(C.chuanHoaChinhTa('Cái bàng gỗ'), 'Cái bàng gỗ');
  assert.equal(C.chuanHoaChinhTa('hòa bình', { kieuDau: 'moi' }), 'hoà bình');
  assert.equal(C.chuanHoaChinhTa('hoà bình', { kieuDau: 'cu' }), 'hòa bình');
});

// ═══ ĐỘ ĐỌC ════════════════════════════════════════════════════════════════

test('Đo được câu dài quá sức lớp, và nói rõ câu nào', () => {
  const dai = 'Cho tam giác ABC vuông tại A, biết rằng độ dài cạnh AB bằng 3 cm và độ dài '
    + 'cạnh AC bằng 4 cm, hãy tính độ dài cạnh huyền BC và diện tích của tam giác đó, '
    + 'đồng thời cho biết tam giác này có phải là tam giác đặc biệt hay không.';
  const r = D.hopVoiLop(dai, 3);
  assert.equal(r.ok, false);
  assert.ok(r.loi.some((l) => l.ma === 'CAU_VUOT_TRAN'));
  assert.ok(r.doDo.cauDaiNhat > 40, `câu dài ${r.doDo.cauDaiNhat} tiếng`);
  // Câu ngắn thì vừa sức.
  const ngan = 'Lan có 3 quả cam. Lan cho Bình 1 quả. Hỏi Lan còn mấy quả?';
  assert.equal(D.hopVoiLop(ngan, 3).ok, true);
  assert.equal(D.hopVoiLop(ngan, 1).ok, true);
});

test('Công thức không bị đếm thành lời văn khi đo độ dài câu', () => {
  const a = D.doDoc('Tính: $2 + 7 = ?$');
  const b = D.doDoc('Tính: $x^{2} + 5x + 6 = 0$');
  assert.equal(a.tiengMoiCau, b.tiengMoiCau, 'độ dài câu không được phụ thuộc độ dài công thức');
});

test('Vần khó đo bằng cấu tạo âm tiết, không đoán', () => {
  assert.equal(D.vanKho('nghiêng'), true, 'nguyên âm đôi kèm âm cuối');
  assert.equal(D.vanKho('chuyện'), true);
  assert.equal(D.vanKho('ba'), false);
  assert.equal(D.vanKho('cam'), false);
});

test('Bảng ngưỡng theo lớp được khai báo rõ là quy ước, kèm số đo thật để đối chiếu', () => {
  // Không được phép trình bày một con số phỏng đoán như thể là số đo.
  assert.equal(Object.keys(D.NGUONG_LOP).length, 12);
  for (let l = 2; l <= 12; l++) {
    assert.ok(D.NGUONG_LOP[l].trungBinh >= D.NGUONG_LOP[l - 1].trungBinh, `ngưỡng lớp ${l} phải không nhỏ hơn lớp trước`);
  }
  const { LanguageScientist: LS } = require('../src/lang/scientist');
  const st = new LS({}).status();
  assert.equal(st.nguongLaQuyUoc, true, 'phải ghi rõ đây là quy ước biên tập');
});

// ═══ TỪ VỰNG THEO LỚP ══════════════════════════════════════════════════════

test('Tra được thuật ngữ nào chương trình dạy ở lớp nào', () => {
  const tv = new TuVung({});
  assert.equal(tv.capDo('phương trình bậc hai').lop, 9);
  assert.equal(tv.capDo('cạnh huyền').lop, 8);
  assert.ok(tv.status().tongThuatNgu > 1000);
});

test('Khớp thuật ngữ theo TIẾNG, không theo chuỗi con', () => {
  // "giá" nằm trong "giác"; khớp kiểu chuỗi con thì "tam giác" bị báo là dùng
  // từ "giá" của lớp trên.
  const tv = new TuVung({});
  const r = tv.tuVuotLop('Cho tam giác vuông, tính cạnh huyền rồi tìm đạo hàm.', 3);
  const tu = r.items.map((x) => x.tu);
  assert.ok(tu.includes('đạo hàm'), 'phải bắt được "đạo hàm" của lớp 11');
  assert.ok(tu.includes('cạnh huyền'));
  assert.ok(!tu.includes('giá'), 'không được khớp "giá" trong "giác"');
  // Động từ một tiếng dùng ở mọi lớp thì không tính là vượt lớp.
  assert.equal(tv.tuVuotLop('Đếm số từ 1 đến 10.', 1).tong, 0);
  // Cụm hai tiếng có từ chỉ dạy ở lớp trên thì VẪN báo, và báo kèm nguồn tra
  // ngược được — đây là nhắc nhở cho người biên tập, không phải lỗi chặn.
  const nhac = tv.tuVuotLop('Tính tổng hai số.', 1);
  assert.equal(nhac.tong, 1);
  assert.equal(nhac.items[0].tu, 'tính tổng');
  assert.ok(nhac.items[0].nguon.startsWith('M4.'), 'phải chỉ ra dạng bài nào dạy từ đó');
  const soat = new LanguageScientist({}).soat('Tính tổng hai số.', { lop: 1 });
  assert.equal(soat.dat, true, 'từ vượt lớp là lời nhắc, không phải lỗi chặn');
  assert.equal(soat.cap4TuVung.loi[0].muc, 'CANH_BAO');
});

// ═══ BỐN CẤP VÀ BÀI HỌC BỐN KỸ NĂNG ════════════════════════════════════════

test('Bốn cấp soát bốn thứ khác nhau và nói rõ cấp nào bỏ qua', () => {
  const L = new LanguageScientist({});
  const khongLop = L.soat('Bai nay kho qua em ko lam dc');
  assert.equal(khongLop.cap3DoDoc, null, 'chưa cho biết lớp thì không được đoán ngưỡng');
  assert.equal(khongLop.cap4TuVung, null);
  assert.match(khongLop.tomTat, /bỏ qua/);

  const coLop = L.soat('Bai nay kho qua em ko lam dc', { lop: 5 });
  assert.ok(coLop.cap3DoDoc);
  assert.equal(coLop.dat, false);
  assert.ok(coLop.cap1ChinhTa.soLoi > 0);
});

test('Tách âm tiết đúng năm thành phần', () => {
  const L = new LanguageScientist({});
  const r = L.amTiet('nghiêng quỳ cua');
  const b = Object.fromEntries(r.bang.map((x) => [x.tieng, x]));
  assert.deepEqual([b.nghiêng.amDau, b.nghiêng.amChinh, b.nghiêng.amCuoi, b.nghiêng.thanh], ['ngh', 'iê', 'ng', 'ngang']);
  assert.deepEqual([b.quỳ.amDau, b.quỳ.amDem, b.quỳ.amChinh, b.quỳ.thanh], ['q', 'u', 'y', 'huyền']);
  assert.deepEqual([b.cua.amDau, b.cua.amDem, b.cua.amChinh], ['c', '∅', 'ua']);
  assert.equal(r.docDuoc, 3);
});

test('Bài học bốn kỹ năng lấy nguyên liệu từ kho đã thẩm định', async () => {
  const { boot } = require('../src/index');
  const N = await boot({ quiet: true });
  try {
    const b = N.linguist.baiHoc4KyNang('M9.PT2.GIAI', { soBai: 2 });
    assert.equal(b.ok, true, b.error);
    assert.equal(b.lop, 9);
    assert.equal(b.nguon, 'kho học liệu đã thẩm định');
    for (const ky of ['nghe', 'noi', 'doc', 'viet']) assert.ok(b[ky], `thiếu kỹ năng ${ky}`);
    assert.ok(b.nghe.kichBan.length >= 3, 'kịch bản nghe phải lấy từ lời giải thật');
    assert.ok(b.doc.baiDoc.length >= 1);
    assert.ok(b.viet.khung.length === 5, 'khung viết đủ năm phần');
    // Tiếng luyện nói phải lấy từ chính bài, không phải danh sách chung.
    for (const t of b.noi.luyenTieng) assert.ok(t.thanh && t.amChinh, 'tiếng luyện nói phải có phân tích âm tiết');
    assert.ok(b.tuSoat.diem >= 70, `bài học tự soát chỉ được ${b.tuSoat.diem}`);
    const chu = N.linguist.baiHocRaChu(b);
    assert.match(chu, /## 1\. NGHE/);
    assert.match(chu, /## 4\. VIẾT/);
  } finally {
    await N.shutdown();
  }
});

test('Soi cả kho học liệu, chấm theo đúng lớp của từng dạng', async () => {
  const { boot } = require('../src/index');
  const N = await boot({ quiet: true });
  try {
    const r = N.linguist.auditKho();
    assert.equal(r.ok, true);
    assert.ok(r.soBai > 50, `mới soi ${r.soBai} bài`);
    assert.equal(r.khongDat, 0, `${r.khongDat} bài có lỗi chặn: ${JSON.stringify(r.items.slice(0, 2))}`);
    for (const h of r.items) assert.ok(h.lop >= 1 && h.lop <= 12, 'bài nào cũng phải biết thuộc lớp mấy');
  } finally {
    await N.shutdown();
  }
});

test('Không chẩn đoán học viên chưa có dữ liệu học', () => {
  const L = new LanguageScientist({});
  assert.equal(L.chanDoan().error, 'THIẾU_MÃ_HỌC_VIÊN');
  assert.equal(L.chanDoan('HV-KHONG-CO').error, 'CHƯA_GẮN_DỮ_LIỆU_HỌC');
});
