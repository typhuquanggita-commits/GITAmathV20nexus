'use strict';
/**
 * Ngôi nhà thịnh vượng: một trục thẳng, không xem trước, bốn vai cùng một chỗ.
 *
 * Ba điều kiểm ở đây là ba lời hứa của hệ thống với người dùng. Chúng dễ vỡ
 * khi sửa mã về sau mà không ai nhận ra — vì trang vẫn hiện ra bình thường,
 * chỉ là hiện thừa. Nên phải có kiểm thử chạy ở MỌI bước của MỌI trục.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const truc = require('../src/nha/truc');
const nhiemVu = require('../src/nha/nhiem-vu');
const NgoiNha = require('../src/nha/dong-bo');
const { TRUC, TRUC_INDEX } = require('../src/nha/truc-noi-dung');
const { PHONG, VE_TINH, moDuoc } = require('../src/nha/ban-do');
const trang = require('../src/web/nha-trang');

const NGUOI = { ten: 'Người Thử', vaiTen: 'Phụ huynh', nhaTen: '' };

/**
 * Chọn phòng để thử NGAY LÚC CHẠY, không viết cứng mã phòng.
 * Mã viết cứng mục ngay lần đầu bản đồ đổi, và kiểm thử trượt vì lý do không
 * liên quan gì tới điều nó định bảo vệ.
 */
const PHONG_THU = PHONG.find((p) => p.viTri === 'phong' && moDuoc('phu-huynh', p.id)).id;
const PHONG_NEN = PHONG.find((p) => p.viTri === 'nen').id;

/** Đầu ra hợp lệ cho một bước, dựng theo đúng ràng buộc mà bước ấy khai. */
function dauRaHopLe(d) {
  if (d.kieu === 'so') return 7;
  if (d.kieu === 'dau-tich') return true;
  if (d.kieu === 'anh') return '/anh/thu.jpg';
  if (d.kieu === 'danh-sach') {
    const n = d.toiDa || d.toiThieu || 3;
    return Array.from({ length: n }, (_, i) => `dòng ${i + 1}`);
  }
  const s = 'Câu trả lời thử của nhà mình';
  return d.toiDa ? s.split(/\s+/).slice(0, d.toiDa).join(' ') : s;
}

// ── Cấu trúc ────────────────────────────────────────────────────────────────

test('mỗi phòng có đúng một trục, và trục nào cũng thẳng', () => {
  assert.equal(TRUC.length, PHONG.length, 'số trục phải bằng số phòng');
  for (const p of PHONG) assert.ok(TRUC_INDEX.has(p.id), `phòng ${p.id} chưa có trục`);
  for (const t of TRUC) {
    assert.ok(t.chang.length >= 3, `trục ${t.id} quá ngắn để gọi là một chặng đường`);
    const ids = new Set(t.chang.map((c) => c.id));
    assert.equal(ids.size, t.chang.length, `trục ${t.id} có bước trùng mã`);
    for (const c of t.chang) {
      // Bước không có đầu ra thì người đi không biết mình đã qua hay chưa,
      // và trợ lý AI không có gì để bám vào mà nói chuyện.
      assert.ok(c.nhiemVu && c.viSao && c.xongKhi && c.dauRa, `bước ${t.id}/${c.id} thiếu phần bắt buộc`);
      assert.ok(Number.isFinite(c.phut) && c.phut > 0, `bước ${t.id}/${c.id} chưa khai thời lượng`);
    }
  }
});

test('mỗi năng lực quanh bản đồ đều có phòng nuôi nó — không có huy hiệu treo không', () => {
  for (const v of VE_TINH) {
    const nuoi = PHONG.filter((p) => p.nuoi.includes(v.id));
    assert.ok(nuoi.length > 0, `vệ tinh ${v.id} không phòng nào nuôi, nên không bao giờ sáng`);
  }
});

// ── Luật không xem trước ────────────────────────────────────────────────────

test('không bước nào lộ bước sau — soi ở mọi vị trí của mọi trục', () => {
  for (const t of TRUC) {
    let st = truc.batDau(t.id, 0).trangThai;
    for (let k = 0; k < t.chang.length; k++) {
      const v = truc.hienThi(st);
      const ro = truc.soiRoRi(v, t.id, k);
      assert.equal(ro.ro, false,
        `trục ${t.id} ở bước ${k + 1} làm lộ bước ${ro.buoc}: "${ro.dauVet}"`);
      // Chiều ngược lại: che bước sau mà che luôn bước hiện tại thì người đi
      // không biết phải làm gì.
      const thieu = truc.soiThieu(v, t.id, k);
      assert.equal(thieu.thieu, false, `trục ${t.id} bước ${k + 1} thiếu ${thieu.phan}`);
      st = truc.nop(st, dauRaHopLe(t.chang[k].dauRa), k + 1).trangThai;
    }
  }
});

test('trang dựng ra cũng không lộ bước sau', () => {
  const nha = new NgoiNha();
  for (const t of TRUC) {
    const vai = PHONG.find((p) => p.id === t.id).vai[0];
    nha.moPhong('N', 'TV', vai, t.id, 0);
    for (let k = 0; k < t.chang.length; k++) {
      const bc = nha.boiCanh('N', 'TV', vai, t.id);
      const html = trang.trangTruc(bc, NGUOI, 'n');
      const ro = truc.soiRoRi(html, t.id, k);
      assert.equal(ro.ro, false, `trang ${t.id} bước ${k + 1} lộ bước ${ro.buoc}: "${ro.dauVet}"`);
      assert.equal(truc.soiThieu(html, t.id, k).thieu, false, `trang ${t.id} bước ${k + 1} thiếu nội dung`);
      nha.nopBuoc('N', 'TV', vai, t.id, dauRaHopLe(t.chang[k].dauRa), k + 1);
    }
  }
});

test('bản đồ nhà chỉ có tiến độ, không có nội dung bước nào', () => {
  const nha = new NgoiNha();
  for (const p of PHONG) if (moDuoc('phu-huynh', p.id)) nha.moPhong('N', 'TV', 'phu-huynh', p.id, 0);
  const bd = nha.banDo('N', 'TV', 'phu-huynh');
  const html = trang.trangBanDo(bd, NGUOI, 'n');
  for (const t of TRUC) {
    // viTri = -1 nghĩa là soi TẤT CẢ các bước: bản đồ không được lộ bước nào.
    assert.equal(truc.soiRoRi(bd, t.id, -1).ro, false, `bản đồ lộ nội dung của ${t.id}`);
    assert.equal(truc.soiRoRi(html, t.id, -1).ro, false, `trang bản đồ lộ nội dung của ${t.id}`);
  }
});

test('phòng của vai khác thì khoá, và ổ khoá không hé một chữ nào', () => {
  const nha = new NgoiNha();
  const khoaVoiHocVien = PHONG.filter((p) => !moDuoc('hoc-vien', p.id));
  assert.ok(khoaVoiHocVien.length > 0, 'phải có phòng dành riêng cho vai khác');
  for (const p of khoaVoiHocVien) {
    const r = nha.moPhong('N', 'BE', 'hoc-vien', p.id, 0);
    assert.equal(r.ok, false, `phòng ${p.id} lẽ ra phải khoá với học viên`);
    assert.equal(truc.soiRoRi(r, p.id, -1).ro, false, 'lời từ chối không được hé nội dung phòng');
    assert.equal(nha.boiCanh('N', 'BE', 'hoc-vien', p.id), null, 'sai vai thì không có bối cảnh');
  }
  const bd = nha.banDo('N', 'BE', 'hoc-vien');
  for (const p of khoaVoiHocVien) {
    assert.equal(truc.soiRoRi(bd, p.id, -1).ro, false, `bản đồ của học viên lộ nội dung ${p.id}`);
  }
});

// ── Một đường, không nhảy ───────────────────────────────────────────────────

test('không có đường nào tiến mà không nộp đầu ra hợp lệ', () => {
  // Cố ý kiểm cả mặt API: không được có hàm nhảy tới bước bất kỳ. Có hàm đó
  // thì sớm muộn sẽ có chỗ gọi, và trục thẳng biến thành mục lục.
  for (const ten of Object.keys(truc)) {
    assert.ok(!/^(diToi|nhay|datBuoc|setBuoc)$/.test(ten), `động cơ không được có hàm ${ten}`);
  }
  for (const t of TRUC) {
    let st = truc.batDau(t.id, 0).trangThai;
    for (let k = 0; k < t.chang.length; k++) {
      const c = t.chang[k];
      assert.equal(truc.nop(st, null, 1).ok, false, `bước ${t.id}/${c.id} nhận cả đầu ra rỗng`);
      if (c.dauRa.kieu === 'danh-sach' && c.dauRa.toiThieu > 1) {
        const thieu = truc.nop(st, ['một dòng'], 1);
        assert.equal(thieu.ok, false, `bước ${t.id}/${c.id} nhận danh sách thiếu dòng`);
        assert.match(thieu.vi, /dòng/);
      }
      const r = truc.nop(st, dauRaHopLe(c.dauRa), k + 1);
      assert.equal(r.ok, true, `nộp đúng mà vẫn không qua được ${t.id}/${c.id}`);
      assert.equal(r.trangThai.buoc, k + 1, 'mỗi lần nộp chỉ được tiến đúng một bước');
      st = r.trangThai;
    }
    assert.equal(st.xong, true);
    assert.equal(truc.nop(st, 'thêm nữa', 1).ok, false, 'đi hết rồi thì không nộp thêm được');
  }
});

test('tiến độ hiện đúng chỗ đang đứng, không làm tròn cho đẹp', () => {
  const t = TRUC[1];
  let st = truc.batDau(t.id, 0).trangThai;
  for (let k = 0; k < t.chang.length; k++) {
    const v = truc.hienThi(st);
    assert.equal(v.viTri, k + 1);
    assert.equal(v.tong, t.chang.length);
    assert.equal(v.daQua.length, k);
    assert.equal(v.conLai, t.chang.length - k - 1);
    st = truc.nop(st, dauRaHopLe(t.chang[k].dauRa), k + 1).trangThai;
  }
  const cuoi = truc.hienThi(st);
  assert.equal(cuoi.xong, true);
  assert.equal(cuoi.conLai, 0);
  assert.equal(truc.tienDo(st).tiLe, 100);
});

// ── Bốn vai ăn khớp ─────────────────────────────────────────────────────────

test('khách hàng, trợ lý AI, người tư vấn và giáo viên AI luôn đứng cùng một bước', () => {
  for (const t of TRUC) {
    let st = truc.batDau(t.id, 0).trangThai;
    for (let k = 0; k < t.chang.length; k++) {
      const v = truc.hienThi(st);
      const bon = nhiemVu.caBonVai(v);
      const dungBuoc = t.chang[k].id;
      for (const [vai, ban] of Object.entries(bon)) {
        assert.equal(truc.soiRoRi(ban, t.id, k).ro, false, `bản của ${vai} lộ bước sau ở ${t.id}/${dungBuoc}`);
      }
      for (const vai of ['troLy', 'tuVan', 'giaoVien']) {
        assert.equal(bon[vai].buocId, dungBuoc, `${vai} đang nói chuyện bước khác ở ${t.id}`);
      }
      // Hàng rào cho mô hình sinh văn bản phải có mặt trong mọi bản giao việc
      // gửi tới mô hình, nếu không thì mô hình tự kể trước cả lộ trình.
      for (const vai of ['troLy', 'tuVan', 'giaoVien']) {
        const chuoi = truc.gomChuoi(bon[vai]);
        assert.ok(chuoi.includes('bước sau'), `${vai} thiếu hàng rào không xem trước ở ${t.id}`);
      }
      st = truc.nop(st, dauRaHopLe(t.chang[k].dauRa), k + 1).trangThai;
    }
  }
});

test('người tư vấn thấy chỗ nhà mình đang đứng, không thấy chỗ chưa tới', () => {
  const nha = new NgoiNha();
  nha.moPhong('N', 'TV', 'phu-huynh', PHONG_THU, 0);
  nha.nopBuoc('N', 'TV', 'phu-huynh', PHONG_THU, dauRaHopLe(TRUC_INDEX.get(PHONG_THU).chang[0].dauRa), 1);
  const o = nha.dangODau('N', 'TV');
  assert.equal(o.ganNhat.phongId, PHONG_THU);
  assert.equal(o.ganNhat.viTri, 2);
  assert.equal(truc.soiRoRi(o, PHONG_THU, 1).ro, false, 'bảng cho người tư vấn lộ bước chưa tới');
});

// ── Khu riêng ───────────────────────────────────────────────────────────────

test('trang mặt trong không cho công cụ tìm kiếm vào và không nằm trong sitemap', () => {
  const nha = new NgoiNha();
  nha.moPhong('N', 'TV', 'phu-huynh', PHONG_THU, 0);
  const html = trang.trangTruc(nha.boiCanh('N', 'TV', 'phu-huynh', PHONG_THU), NGUOI, 'n');
  assert.match(html, /name="robots" content="noindex,nofollow"/);
  // Lọt vào sitemap thì luật không xem trước bị phá từ bên ngoài mà hệ thống
  // không hề biết.
  const web = require('../src/web/site');
  for (const d of web.moiDuongDan()) {
    assert.ok(!d.startsWith('/nha'), `đường dẫn riêng ${d} lọt vào sitemap công khai`);
  }
});

test('trang mặt trong không dùng thuộc tính style nội tuyến', () => {
  const nha = new NgoiNha();
  for (const p of PHONG) if (moDuoc('phu-huynh', p.id)) nha.moPhong('N', 'TV', 'phu-huynh', p.id, 0);
  const cac = [
    trang.trangBanDo(nha.banDo('N', 'TV', 'phu-huynh'), NGUOI, 'n'),
    trang.trangTruc(nha.boiCanh('N', 'TV', 'phu-huynh', PHONG_THU), NGUOI, 'n'),
    trang.trangChangDuong(nha.banDo('N', 'TV', 'phu-huynh'), nha.dangODau('N', 'TV'), NGUOI, 'n'),
  ];
  for (const html of cac) {
    const co = html.match(/<[^>]+\sstyle="/g) || [];
    assert.equal(co.length, 0, `còn ${co.length} thuộc tính style nội tuyến — chính sách bảo mật sẽ chặn`);
  }
});

test('trạng thái ghi xuống kho rồi nạp lại vẫn đúng chỗ đang đứng', () => {
  const luu = new Map();
  const kho = {
    put: (doc) => luu.set(doc.id, doc),
    all: () => [...luu.values()],
  };
  const a = new NgoiNha({ kho });
  a.moPhong('N', 'TV', 'phu-huynh', PHONG_NEN, 0);
  a.nopBuoc('N', 'TV', 'phu-huynh', PHONG_NEN, dauRaHopLe(TRUC_INDEX.get(PHONG_NEN).chang[0].dauRa), 1);
  const b = new NgoiNha({ kho });
  const bc = b.boiCanh('N', 'TV', 'phu-huynh', PHONG_NEN);
  assert.ok(bc, 'nạp lại mà mất trạng thái thì người dùng phải làm lại từ đầu');
  assert.equal(bc.chang.viTri, 2);
  assert.equal(bc.chang.daQua.length, 1);
});
