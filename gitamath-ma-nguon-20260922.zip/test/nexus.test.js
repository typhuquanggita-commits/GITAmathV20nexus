'use strict';
/**
 * BÀI GIẢNG MỘT LỆNH — kiểm bằng tệp thật.
 *
 * Nguyên tắc của tệp kiểm này: không có mục nào chỉ hỏi "hàm có trả về object
 * không". Video dựng ra thì phải mở lại được, từng khung phải giải nén ra
 * JPEG, đường tiếng phải đủ số giây, chữ có dấu phải thật sự đổi điểm ảnh.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const AVI = require('../src/film/avi');
const CHU = require('../src/photo/chu');
const SLIDE = require('../src/nexus/slide');
const JPG = require('../src/photo/jpeg');
const { BaiGiangPipeline, KHO } = require('../src/nexus/bai-giang');

/** Ảnh RGBA đặc một màu, dùng làm nền kiểm chữ. */
function anhDac(W, H, mau = [0, 0, 0]) {
  const data = Buffer.alloc(W * H * 4);
  for (let i = 0; i < W * H; i++) {
    data[i * 4] = mau[0]; data[i * 4 + 1] = mau[1]; data[i * 4 + 2] = mau[2]; data[i * 4 + 3] = 255;
  }
  return { width: W, height: H, data };
}
const demSang = (a) => {
  let n = 0;
  for (let i = 0; i < a.width * a.height; i++) if (a.data[i * 4] > 20 || a.data[i * 4 + 1] > 20 || a.data[i * 4 + 2] > 20) n++;
  return n;
};

// ═══ ĐÓNG GÓI VIDEO ════════════════════════════════════════════════════════

test('AVI ghi ra mở lại được: đúng số khung, đúng độ phân giải, có bảng tra', () => {
  const rong = 160; const cao = 120; const fps = 10; const soKhung = 25; const tanSo = 22050;
  const khungJPEG = [];
  for (let i = 0; i < soKhung; i++) {
    const a = anhDac(rong, cao, [i * 8 % 256, 40, 200 - i * 4]);
    khungJPEG.push(JPG.ghiJPEG(a, { chatLuong: 80 }));
  }
  const giay = soKhung / fps;
  const tieng = new Float32Array(Math.round(giay * tanSo));
  for (let i = 0; i < tieng.length; i++) tieng[i] = Math.sin(2 * Math.PI * 440 * i / tanSo) * 0.3;

  const r = AVI.ghiAVI({ khungJPEG, tieng, fps, rong, cao, tanSo });
  assert.equal(r.ok, true);
  assert.equal(r.soKhung, soKhung);

  const d = AVI.docAVI(r.tep, { layKhoi: true });
  assert.equal(d.ok, true, d.error);
  assert.equal(d.rong, rong);
  assert.equal(d.cao, cao);
  assert.equal(d.soKhung, soKhung);
  assert.equal(d.fps, fps);
  assert.equal(d.soLuong, 2, 'phải có đúng hai luồng: hình và tiếng');
  assert.equal(d.coBangTra, true, 'thiếu idx1 thì nhiều trình phát không tua được');
  assert.equal(d.kichThuocKhaiDung, true, 'kích thước khai trong RIFF phải khớp độ dài tệp thật');

  // Nội dung, không chỉ tiêu đề: từng khung phải giải nén ra đúng khổ ảnh.
  assert.equal(d.khoiHinh.length, soKhung);
  for (const k of d.khoiHinh) {
    const j = JPG.docJPEG(k);
    assert.equal(j.ok, true);
    assert.equal(j.width, rong);
    assert.equal(j.height, cao);
  }
  // Đường tiếng phải dài đúng bằng phần hình, sai số dưới 0,1 giây.
  assert.ok(Math.abs(d.byteTieng / 2 / tanSo - giay) < 0.1, `tiếng ${d.byteTieng / 2 / tanSo}s ≠ hình ${giay}s`);
});

test('AVI từ chối đầu vào sai thay vì ghi ra tệp hỏng', () => {
  assert.equal(AVI.ghiAVI({ khungJPEG: [], fps: 10, rong: 64, cao: 64 }).error, 'KHÔNG_CÓ_KHUNG_HÌNH');
  assert.equal(AVI.tuAnh({ anhList: [] }).error, 'KHÔNG_CÓ_ẢNH');
  assert.equal(
    AVI.tuAnh({ anhList: [anhDac(32, 32), anhDac(48, 32)] }).error,
    'CÁC_KHUNG_KHÔNG_CÙNG_KÍCH_THƯỚC',
  );
  assert.equal(AVI.docAVI(Buffer.alloc(8)).error, 'TỆP_QUÁ_NGẮN');
  assert.equal(AVI.docAVI(Buffer.alloc(64)).error, 'KHÔNG_PHẢI_TỆP_AVI');
});

test('AVI không tiếng vẫn hợp lệ — chỉ còn một luồng', () => {
  const k = [JPG.ghiJPEG(anhDac(64, 48, [200, 10, 10]), { chatLuong: 70 })];
  const r = AVI.ghiAVI({ khungJPEG: k, fps: 5, rong: 64, cao: 48 });
  const d = AVI.docAVI(r.tep);
  assert.equal(d.ok, true);
  assert.equal(d.soLuong, 1);
  assert.equal(r.coTieng, false);
});

// ═══ CHỮ TIẾNG VIỆT TRÊN ẢNH ═══════════════════════════════════════════════

test('Dấu tiếng Việt được vẽ thật: bỏ dấu thì số điểm ảnh sáng giảm', () => {
  const a = anhDac(300, 40);
  const b = anhDac(300, 40);
  const ra = CHU.veChu(a, 'Định lý Pythagore', 4, 6, { co: 2 });
  const rb = CHU.veChu(b, 'Dinh ly Pythagore', 4, 6, { co: 2 });
  assert.equal(ra.boQua, 0, 'không ký tự nào được phép bị bỏ qua');
  assert.equal(rb.boQua, 0);
  assert.ok(demSang(a) > demSang(b), 'bản có dấu phải nhiều điểm ảnh hơn bản không dấu');
  // đ có gạch ngang: phải khác d trần.
  const c = anhDac(40, 30); const e = anhDac(40, 30);
  CHU.veChu(c, 'đ', 2, 2, { co: 2 });
  CHU.veChu(e, 'd', 2, 2, { co: 2 });
  assert.ok(demSang(c) > demSang(e), 'đ phải có gạch ngang nên sáng hơn d');
});

test('Chữ không tràn ra ngoài ảnh và đo được bề rộng trước khi vẽ', () => {
  const text = 'Giải phương trình bậc hai';
  const co = 2;
  const rong = CHU.rongChuoi(text, co);
  const a = anhDac(rong + 20, CHU.caoDong(co) + 20);
  const r = CHU.veChu(a, text, 5, 5, { co });
  assert.equal(r.rong, rong, 'bề rộng đo trước phải khớp bề rộng vẽ ra');
  assert.ok(demSang(a) > 0);
  // Vẽ lệch ra ngoài mép phải không được ném lỗi, chỉ bị cắt.
  assert.doesNotThrow(() => CHU.veChu(a, text, a.width - 5, 5, { co }));
});

test('Ngắt dòng cắt theo từ, không cắt giữa từ', () => {
  const dong = CHU.ngatDong('Giải phương trình bậc hai một ẩn bằng công thức nghiệm', 200, 2);
  assert.ok(dong.length >= 2);
  for (const d of dong) assert.ok(CHU.rongChuoi(d, 2) <= 200, `dòng "${d}" quá rộng`);
  assert.equal(dong.join(' ').replace(/\s+/g, ' '), 'Giải phương trình bậc hai một ẩn bằng công thức nghiệm');
});

// ═══ KHUNG HÌNH BÀI GIẢNG ══════════════════════════════════════════════════

test('Ba loại khung hình ra đúng khổ và không phải ảnh trống', () => {
  const dims = { rong: 640, cao: 360 };
  const khung = [
    SLIDE.khungTieuDe({ ...dims, tieuDe: 'Định lý Pythagore', phuDe: 'Tầng 2–5' }),
    SLIDE.khungNoiDung({ ...dims, tieuDe: 'Bẫy hay mắc', cacY: ['nhận nhầm cạnh huyền', 'dùng cho tam giác không vuông'], trang: 2, tongTrang: 4, tienDo: 0.5 }),
    SLIDE.khungKet({ ...dims, cauChot: 'Hết bài.' }),
  ];
  for (const a of khung) {
    assert.equal(a.width, dims.rong);
    assert.equal(a.height, dims.cao);
    const sang = demSang(a);
    assert.ok(sang > 1000, `khung gần như trống (${sang} điểm sáng)`);
    assert.ok(JPG.ghiJPEG(a, { chatLuong: 80 }).length > 1000, 'khung phải nén được thành JPEG');
  }
});

test('Thanh tiến độ phản ánh đúng vị trí bài — đo ngay trên hàng điểm ảnh', () => {
  const o = { rong: 640, cao: 360, tieuDe: 'A', cacY: ['x'], tongTrang: 10 };
  // Đo đúng hàng vẽ thanh tiến độ, không đo tổng độ sáng cả khung: nền
  // chuyển sắc vốn đã sáng khắp nơi nên tổng độ sáng không nói lên điều gì.
  const doDai = (tienDo) => {
    const a = SLIDE.khungNoiDung({ ...o, trang: 1, tienDo });
    const y = a.height - 2;
    let n = 0;
    for (let x = 0; x < a.width; x++) {
      const i = (y * a.width + x) * 4;
      const p = [a.data[i], a.data[i + 1], a.data[i + 2]];
      if (p[0] === SLIDE.MAU.nhan[0] && p[1] === SLIDE.MAU.nhan[1] && p[2] === SLIDE.MAU.nhan[2]) n++;
    }
    return n / a.width;
  };
  assert.ok(Math.abs(doDai(0.1) - 0.1) < 0.02, `tiến độ 10% vẽ ra ${doDai(0.1)}`);
  assert.ok(Math.abs(doDai(0.9) - 0.9) < 0.02, `tiến độ 90% vẽ ra ${doDai(0.9)}`);
  assert.equal(doDai(0), 0);
});

// ═══ ĐƯỜNG ỐNG BÀI GIẢNG ═══════════════════════════════════════════════════

test('Khớp chủ đề gõ tự do → dạng bài: tất định và biết nói "không khớp"', () => {
  const p = new BaiGiangPipeline({});
  const a = p.timDang('phương trình bậc hai');
  assert.equal(a.khop.ma, 'M9.PT2.GIAI');
  // Chạy lại 50 lần phải ra y hệt — không bốc thăm, không phụ thuộc thứ tự Map.
  for (let i = 0; i < 50; i++) assert.deepEqual(p.timDang('phương trình bậc hai'), a);
  assert.equal(p.timDang('M9.PT2.GIAI').khop.diem, 100, 'gõ thẳng mã dạng phải khớp tuyệt đối');
  assert.equal(p.timDang('pytago').khop.ma, 'M8.PYTAGO.UNGDUNG', 'viết tắt quen dùng phải tìm ra');
  assert.equal(p.timDang('công thức nấu phở bò').khop, null, 'chủ đề ngoài chương trình phải báo không khớp');
  assert.equal(p.timDang('').khop, null);
});

test('Soạn từ kịch bản: mỗi khối một đoạn, dòng ngắn đầu tiên làm tiêu đề', () => {
  const p = new BaiGiangPipeline({});
  const kb = [
    'Bài mở đầu',
    'Hôm nay ta học về tam giác vuông. Cạnh đối diện góc vuông gọi là cạnh huyền.',
    'Định lý\nBình phương cạnh huyền bằng tổng bình phương hai cạnh góc vuông.',
  ].join('\n\n');
  const d = p.soanTuKichBan(kb);
  assert.equal(d.ok, true);
  assert.equal(d.daThamDinh, false, 'kịch bản người dùng chưa qua thẩm định thì phải ghi rõ');
  assert.equal(d.doan[0].loai, 'tieu-de');
  assert.equal(d.doan[d.doan.length - 1].loai, 'ket');
  assert.ok(d.doan.length >= 3);
  assert.equal(p.soanTuKichBan('   ').error, 'KỊCH_BẢN_RỖNG');
});

test('Thiếu nguồn nội dung thì nói thẳng, không dựng bài rỗng', async () => {
  const p = new BaiGiangPipeline({});
  const r = await p.tao({});
  assert.equal(r.ok, false);
  assert.equal(r.error, 'THIẾU_NGUỒN_NỘI_DUNG');
  assert.ok(r.goi, 'lỗi phải kèm cách sửa');
  assert.equal(p.soanTuKho('KHÔNG_CÓ_MÃ_NÀY').error, 'KHÔNG_CÓ_DẠNG_BÀI');
  assert.equal(p.lay('BG-KHONG-CO').error, 'KHÔNG_TÌM_THẤY_BÀI_GIẢNG');
});

test('Dựng trọn một bài giảng thật: video mở lại được, khung khớp tiếng', async () => {
  // Dịch vụ giọng thật (bộ formant nội bộ) — không giả lập, vì thời lượng mỗi
  // khung được tính từ độ dài tiếng đọc thật.
  const { VoiceService } = require('../src/voice/service');
  const { buildRoster } = require('../src/agents/roster');
  const { agents } = buildRoster();
  const voice = new VoiceService({ agents });
  const p = new BaiGiangPipeline({ voice });

  const kb = 'Tam giác vuông\n\nCạnh huyền là cạnh dài nhất.\n\nBình phương cạnh huyền bằng tổng bình phương hai cạnh kia.';
  const r = await p.tao({ kichBan: kb, kho: 'nhap', chatLuongJpeg: 70 });
  assert.equal(r.ok, true, r.error);
  assert.equal(r.rong, KHO.nhap.rong);
  assert.equal(r.fps, KHO.nhap.fps);
  assert.equal(r.tiengHong, 0, 'mọi đoạn phải đọc được tiếng');
  assert.equal(r.soKhung, r.mocThoiGian.reduce((s, m) => s + m.soKhung, 0), 'tổng khung phải khớp mốc thời gian');
  assert.ok(r.giay > 3, `bài quá ngắn: ${r.giay}s`);

  const d = AVI.docAVI(r.video, { layKhoi: true });
  assert.equal(d.ok, true, d.error);
  assert.equal(d.soKhung, r.soKhung);
  assert.equal(d.khoiHinh.length, r.soKhung);
  assert.equal(JPG.docJPEG(d.khoiHinh[0]).width, KHO.nhap.rong);
  assert.ok(Math.abs(d.byteTieng / 2 / 22050 - r.giay) < 0.2, 'đường tiếng phải phủ hết thời lượng hình');

  // Mốc thời gian phải liên tục, không chồng, không hở.
  let t = 0;
  for (const m of r.mocThoiGian) {
    assert.ok(Math.abs(m.batDau - t) < 0.02, `đoạn ${m.doan} bắt đầu sai: ${m.batDau} ≠ ${t}`);
    t += m.giay;
  }

  // Lưu được và tra lại được.
  assert.equal(p.lay(r.id).ok, true);
  assert.equal(p.danhSach().tong, 1);
  assert.equal(p.status().baiGiang, 1);
});

test('Dựng từ kho học liệu đã thẩm định thì đánh dấu là đã thẩm định', async () => {
  const { VoiceService } = require('../src/voice/service');
  const { buildRoster } = require('../src/agents/roster');
  const ItemBank = require('../src/content/item-bank');
  const Bank = ItemBank.ItemBank || ItemBank;
  const p = new BaiGiangPipeline({
    voice: new VoiceService({ agents: buildRoster().agents }),
    bank: new Bank(),
  });
  const d = p.soanTuKho('M8.PYTAGO.UNGDUNG');
  assert.equal(d.ok, true);
  assert.equal(d.daThamDinh, true);
  assert.equal(d.canDuyet, false, 'nội dung đã thẩm định thì không bắt duyệt lại');
  assert.equal(d.maDang, 'M8.PYTAGO.UNGDUNG');
  // Kho rỗng: vẫn ra được bài lý thuyết, nhưng phải nói rõ là thiếu bài mẫu.
  assert.ok(d.luuY && /bài mẫu/i.test(d.luuY));
  assert.ok(d.doan.some((x) => x.tieuDe === 'Bẫy hay mắc'), 'phải đưa được bẫy thường gặp của dạng vào bài');
});

// ═══ GIỌNG NƠ-RON MIỄN PHÍ ═════════════════════════════════════════════════

test('edge-tts có mặt trong sổ nhà cung cấp và báo đúng cách cài khi chưa có', () => {
  const { ProviderRegistry } = require('../src/voice/providers');
  const r = new ProviderRegistry({});
  const e = r.status().providers.find((x) => x.id === 'edge-tts');
  assert.ok(e, 'chưa đăng ký edge-tts');
  assert.equal(e.needsKey, false, 'edge-tts không cần khoá — đó là lý do chọn nó');
  assert.equal(e.needsNetwork, true);
  if (!e.available) {
    assert.equal(e.reason, 'CHƯA_CÀI');
    assert.match(e.fix, /pip3 install edge-tts/);
  }
});

test('Không bộ nào cài thì vẫn đọc được — mọi mục đích đều tụt về bộ nội bộ', () => {
  const { ProviderRegistry } = require('../src/voice/providers');
  const { PURPOSE } = require('../src/voice/pipelines/speech');
  const r = new ProviderRegistry({});
  for (const [ten, m] of Object.entries(PURPOSE)) {
    assert.ok(m.order.includes('offline'), `mục đích "${ten}" không có đường lui về bộ nội bộ`);
    const chay = m.order.filter((id) => r.providers.get(id)?.available().ok);
    assert.ok(chay.length >= 1, `mục đích "${ten}" không còn bộ nào chạy được`);
  }
  // edge-tts xuất MP3 nên không nhúng được dấu chìm và không ghép thẳng vào
  // video — không được đứng đầu hàng cho việc giảng bài.
  assert.notEqual(PURPOSE['giang-bai'].order[0], 'edge-tts');
});
