'use strict';
/**
 * Xưởng ảnh — kiểm bằng phép đo trên chính điểm ảnh, không kiểm bằng
 * "hàm có trả về object không".
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const PNG = require('../src/photo/png');
const JPG = require('../src/photo/jpeg');
const I = require('../src/photo/image');
const QC = require('../src/photo/qc');
const P = require('../src/photo/profiles');
const { dungPrompt, CAM } = require('../src/photo/prompt');
const { chonBoCuc, boCucCho, BO_CUC } = require('../src/photo/composition');
const { CongTaoAnh } = require('../src/photo/providers');
const { PhotoService, MUC } = require('../src/photo/service');

/** Ảnh thử giống ảnh chụp: gradient lớn + kết cấu nhỏ + vài cạnh sắc. */
function anhThu(W = 320, H = 240) {
  const a = PNG.taoAnh(W, H);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      const nen = 78 + 45 * Math.sin(x / 48) + 28 * Math.cos(y / 33);
      const ct = ((x * 7 + y * 13) % 21 < 6) ? 24 : 0;
      const canh = (Math.abs(x - W * 0.38) < 2 || Math.abs(y - H * 0.42) < 2) ? 58 : 0;
      a.data[i] = Math.min(255, nen + ct + canh);
      a.data[i + 1] = Math.min(255, nen * 0.95 + ct);
      a.data[i + 2] = Math.min(255, nen * 1.09 + ct * 0.5);
      a.data[i + 3] = 255;
    }
  }
  return a;
}

// ── 1. PNG ─────────────────────────────────────────────────────────────────

test('PNG ghi rồi đọc lại khớp từng byte, kể cả kích thước lẻ', () => {
  for (const [W, H] of [[137, 91], [1, 1], [64, 3], [7, 200]]) {
    const a = PNG.taoAnh(W, H);
    for (let i = 0; i < a.data.length; i += 4) {
      a.data[i] = (i * 7) & 255; a.data[i + 1] = (i * 13) & 255;
      a.data[i + 2] = (i ^ 0x5a) & 255; a.data[i + 3] = 255;
    }
    const buf = PNG.ghiPNG(a);
    assert.equal(PNG.nhanDang(buf), 'png');
    const b = PNG.docPNG(buf);
    assert.equal(b.ok, true, `${W}×${H}: ${b.error}`);
    assert.equal(b.width, W); assert.equal(b.height, H);
    assert.ok(a.data.equals(b.data), `${W}×${H} không khớp từng byte`);
  }
});

test('PNG nén thật sự, và từ chối tệp hỏng thay vì trả ảnh rác', () => {
  const a = anhThu(200, 150);
  const buf = PNG.ghiPNG(a);
  assert.ok(buf.length < a.data.length * 0.6, `nén kém: ${buf.length}/${a.data.length}`);
  assert.equal(PNG.docPNG(Buffer.from('không phải png')).error, 'KHÔNG_PHẢI_TỆP_PNG');
  const cut = buf.subarray(0, 40);
  assert.equal(PNG.docPNG(cut).ok, false);
});

// ── 2. JPEG ────────────────────────────────────────────────────────────────

test('JPEG mã hoá rồi giải mã lại, sai lệch trong ngưỡng của nén mất dữ liệu', () => {
  const a = anhThu(96, 72);
  const jp = JPG.ghiJPEG(a, { chatLuong: 95 });
  assert.equal(PNG.nhanDang(jp), 'jpeg');
  const b = JPG.docJPEG(jp);
  assert.equal(b.ok, true, b.error);
  assert.equal(b.width, 96); assert.equal(b.height, 72);

  let tong = 0; let max = 0;
  for (let i = 0; i < a.data.length; i++) {
    if (i % 4 === 3) continue;
    const d = Math.abs(a.data[i] - b.data[i]);
    tong += d; if (d > max) max = d;
  }
  const tb = tong / (a.data.length * 0.75);
  assert.ok(tb < 6, `sai lệch trung bình quá cao: ${tb.toFixed(2)}`);
  assert.ok(max < 90, `có điểm lệch quá xa: ${max}`);
});

test('chất lượng JPEG cao hơn cho tệp lớn hơn và sai lệch nhỏ hơn', () => {
  const a = anhThu(96, 72);
  const thap = JPG.ghiJPEG(a, { chatLuong: 40 });
  const cao = JPG.ghiJPEG(a, { chatLuong: 95 });
  assert.ok(cao.length > thap.length, `q95 (${cao.length}) phải lớn hơn q40 (${thap.length})`);
  const lech = (buf) => {
    const b = JPG.docJPEG(buf);
    let t = 0;
    for (let i = 0; i < a.data.length; i++) { if (i % 4 === 3) continue; t += Math.abs(a.data[i] - b.data[i]); }
    return t / (a.data.length * 0.75);
  };
  assert.ok(lech(cao) < lech(thap), 'q95 phải sát bản gốc hơn q40');
  assert.equal(JPG.docJPEG(Buffer.from('xyz')).error, 'KHÔNG_PHẢI_TỆP_JPEG');
});

// ── 3. XỬ LÝ ẢNH ───────────────────────────────────────────────────────────

test('phóng to Lanczos giữ đúng tỉ lệ khung và không sinh giá trị hỏng', () => {
  const a = anhThu(160, 120);
  const b = I.doiKichThuoc(a, 480, 360);
  assert.equal(b.width, 480); assert.equal(b.height, 360);
  assert.equal(b.data.length, 480 * 360 * 4);
  for (let i = 0; i < b.data.length; i++) assert.ok(b.data[i] >= 0 && b.data[i] <= 255);
  const c = I.doiKichThuoc(a, 160, 120);
  assert.ok(c.data.equals(a.data), 'đổi về đúng kích thước cũ phải trả lại ảnh y nguyên');
});

test('độ nét đo được không phụ thuộc kích thước ảnh', () => {
  const a = anhThu(320, 240);
  const cac = [1, 2, 3].map((k) => I.doNet(k === 1 ? a : I.doiKichThuoc(a, 320 * k, 240 * k)));
  const tb = cac.reduce((s, v) => s + v, 0) / cac.length;
  for (const v of cac) {
    assert.ok(Math.abs(v - tb) / tb < 0.12, `độ nét lệch theo kích thước: ${cac.join(', ')}`);
  }
  // và vẫn phải tụt khi ảnh bị làm mờ
  assert.ok(I.doNet(I.lamMo(a, 2)) < tb * 0.2, 'làm mờ mà độ nét không giảm');
});

test('làm sắc có ngưỡng: lấy lại chi tiết nhưng không đụng vùng phẳng', () => {
  const a = anhThu(200, 150);
  const mo = I.lamMo(a, 1);
  const r = I.lamSac(mo, { banKinh: 1.2, cuongDo: 1.5, nguong: 2 });
  assert.ok(I.doNet(r.anh) > I.doNet(mo) * 2.5, `làm sắc không tăng được độ nét: ${I.doNet(mo)} → ${I.doNet(r.anh)}`);
  assert.ok(I.doNet(r.anh) <= I.doNet(a) * 1.1, 'làm sắc không được vượt quá độ nét của bản gốc');
  assert.ok(r.diemDaSua > 0);

  // GIỚI HẠN THẬT, cần ghi rõ: mờ nặng thì không cứu được. Chênh lệch cục bộ
  // tụt xuống dưới ngưỡng nên mặt nạ làm sắc không có gì để khuếch đại —
  // đúng như vậy, và tốt hơn là khuếch đại nhiễu rồi gọi đó là "nét".
  const moNang = I.lamMo(a, 4);
  const cuu = I.lamSac(moNang, { banKinh: 1.6, cuongDo: 2.5, nguong: 2 });
  assert.ok(I.doNet(cuu.anh) < I.doNet(a) * 0.3, 'không được giả vờ cứu lại được ảnh mờ nặng');

  // Ảnh phẳng tuyệt đối thì ngưỡng phải chặn hết
  const phang = PNG.taoAnh(64, 64, [120, 120, 120, 255]);
  const rp = I.lamSac(phang, { banKinh: 2, cuongDo: 1.5, nguong: 3 });
  assert.equal(rp.diemDaSua, 0, 'vùng phẳng không được bị đụng tới');
  assert.ok(rp.anh.data.equals(phang.data));
});

test('chỉnh màu: tương phản không kéo lệch độ sáng, bão hoà không đổi sắc', () => {
  const a = anhThu(160, 120);
  const g = I.doAnh(a);
  const tp = I.doAnh(I.chinhMau(a, { tuongPhan: 1.4 }));
  assert.ok(tp.doLechChuan > g.doLechChuan * 1.2, 'tương phản không tăng');
  assert.ok(Math.abs(tp.doSang - g.doSang) < 10, `tương phản kéo lệch độ sáng: ${g.doSang} → ${tp.doSang}`);

  const bh = I.doAnh(I.chinhMau(a, { baoHoa: 1.6 }));
  assert.ok(bh.doBaoHoa > g.doBaoHoa * 1.15, 'bão hoà không tăng');
  assert.ok(Math.abs(bh.doSang - g.doSang) < 6, 'bão hoà không được làm đổi độ sáng');

  const xam = I.doAnh(I.chinhMau(a, { baoHoa: 0 }));
  assert.ok(xam.doBaoHoa < 2, `bão hoà 0 phải ra xám, còn ${xam.doBaoHoa}%`);
});

test('nhiệt độ màu chỉnh đúng hướng ấm và lạnh', () => {
  const a = anhThu(160, 120);
  const g = I.doAnh(a).canBangTrang.lechRB;
  const am = I.doAnh(I.chinhMau(a, { kelvin: 3200 })).canBangTrang.lechRB;
  const lanh = I.doAnh(I.chinhMau(a, { kelvin: 9500 })).canBangTrang.lechRB;
  assert.ok(am > g + 10, `3200K phải ấm hơn: ${g} → ${am}`);
  assert.ok(lanh < g, `9500K phải lạnh hơn: ${g} → ${lanh}`);
});

test('hạt phim tất định theo hạt giống', () => {
  const a = anhThu(80, 60);
  const x = I.themHat(a, { cuongDo: 0.05, seed: 'abc' });
  const y = I.themHat(a, { cuongDo: 0.05, seed: 'abc' });
  const z = I.themHat(a, { cuongDo: 0.05, seed: 'khac' });
  assert.ok(x.data.equals(y.data), 'cùng hạt giống phải ra cùng một ảnh');
  assert.ok(!x.data.equals(z.data), 'khác hạt giống phải ra ảnh khác');
  assert.ok(!x.data.equals(a.data), 'hạt phải thật sự thay đổi ảnh');
});

test('tối góc làm tối mép mà giữ nguyên tâm ảnh', () => {
  const a = PNG.taoAnh(200, 200, [180, 180, 180, 255]);
  const b = I.toiGoc(a, { cuongDo: 0.5, banKinh: 0.4 });
  const lay = (img, x, y) => img.data[(y * 200 + x) * 4];
  assert.equal(lay(b, 100, 100), 180, 'tâm ảnh phải nguyên vẹn');
  assert.ok(lay(b, 2, 2) < 150, `góc phải tối đi, đang là ${lay(b, 2, 2)}`);
});

// ── 4. HỒ SƠ MÁY ẢNH & PHIM ────────────────────────────────────────────────

test('mỗi hồ sơ máy ảnh cho ra chất màu khác nhau, đo được', () => {
  const a = anhThu(160, 120);
  const ket = {};
  for (const m of ['Fujifilm', 'Canon', 'Sony', 'Leica', 'Hasselblad', 'ARRI', 'RED', 'iPhone']) {
    const r = I.doAnh(I.chinhMau(a, P.layMayAnh(m).mau));
    ket[m] = `${r.doLechChuan}|${r.doBaoHoa}|${r.canBangTrang.lechRB}`;
  }
  assert.equal(new Set(Object.values(ket)).size, 8, 'có hai hồ sơ cho ra chất màu giống hệt nhau');

  // ARRI phải tương phản cao hơn và lạnh hơn Hasselblad
  const arri = I.doAnh(I.chinhMau(a, P.layMayAnh('ARRI').mau));
  const hass = I.doAnh(I.chinhMau(a, P.layMayAnh('Hasselblad').mau));
  assert.ok(arri.doLechChuan > hass.doLechChuan, 'ARRI phải tương phản hơn');
  assert.ok(arri.canBangTrang.lechRB < hass.canBangTrang.lechRB, 'ARRI phải lạnh hơn');

  // Bão hoà phải đo TÁCH RIÊNG khỏi tương phản. Nâng tương phản đẩy ba kênh
  // xa nhau nên chỉ số (max−min)/max tăng theo, dù hệ số bão hoà đã giảm —
  // so thẳng hai hồ sơ là so nhầm hai thứ.
  const chiBaoHoa = (m) => I.doAnh(I.chinhMau(a, { baoHoa: P.layMayAnh(m).mau.baoHoa })).doBaoHoa;
  assert.ok(chiBaoHoa('ARRI') < chiBaoHoa('Hasselblad'),
    `ARRI phải bão hoà thấp hơn khi đo riêng: ${chiBaoHoa('ARRI')} vs ${chiBaoHoa('Hasselblad')}`);
});

test('đường tông phim nâng vai tối và mỗi loại phim một đường riêng', () => {
  const a = anhThu(160, 120);
  const g = I.doAnh(a);
  for (const f of ['KodakPortra400', 'KodakEktar100', 'FujiVelvia50', 'IlfordHP5', 'Cinestill800T']) {
    const d = P.duongPhim(f);
    assert.ok(d, `${f} không dựng được đường tông`);
    assert.equal(d.r.length, 256);
    const r = I.doAnh(I.apDuongTong(a, d));
    assert.ok(r.p1 >= g.p1, `${f}: vai tối phải được nâng (${g.p1} → ${r.p1})`);
  }
  assert.equal(P.duongPhim('Khong'), null);
  const so = P.soSanh('Hasselblad', 'ARRI');
  assert.ok(so.tuongPhan && so.baoHoa, 'so sánh hồ sơ phải nói rõ khác nhau ở đâu');
});

// ── 5. BỐ CỤC & PROMPT ─────────────────────────────────────────────────────

test('chọn bố cục TẤT ĐỊNH — chạy trăm lần vẫn một kết quả', () => {
  const a = chonBoCuc('chan-dung', 'mô tả nào đó', 0).id;
  for (let i = 0; i < 100; i++) assert.equal(chonBoCuc('chan-dung', 'mô tả nào đó', 0).id, a);
  // nhưng đổi số hiệu tấm thì phải ra bố cục khác nhau
  const bien = new Set([0, 1, 2, 3, 4, 5, 6, 7].map((b) => chonBoCuc('chan-dung', 'mô tả nào đó', b).id));
  assert.ok(bien.size >= 3, `đổi số hiệu tấm mà chỉ ra ${bien.size} bố cục`);
  // mỗi kiểu ảnh chỉ nhận bố cục hợp với nó
  for (const k of ['chan-dung', 'phong-canh', 'kien-truc', 'san-pham']) {
    const b = chonBoCuc(k, 'x', 0);
    assert.ok(b.hop.includes(k), `${k} nhận bố cục ${b.id} không hợp`);
    assert.ok(boCucCho(k).length >= 2);
  }
});

test('mỗi bố cục có toạ độ chủ thể thật, không chỉ là câu chữ', () => {
  for (const [id, b] of Object.entries(BO_CUC)) {
    assert.ok(b.chuThe && b.chuThe.x > 0 && b.chuThe.x < 1, `${id} thiếu toạ độ x`);
    assert.ok(b.chuThe.y > 0 && b.chuThe.y < 1, `${id} thiếu toạ độ y`);
    assert.ok(b.prompt.length > 20);
  }
});

test('prompt ghép đủ phần và liệt kê rõ hệ thống đã thêm gì', () => {
  const p = dungPrompt('Chân dung phụ nữ áo dài đỏ', { kieuAnh: 'chan-dung', mayAnh: 'Fujifilm', phim: 'KodakPortra400' });
  assert.ok(p.prompt.startsWith('Chân dung phụ nữ áo dài đỏ'), 'mô tả người dùng phải đứng đầu');
  assert.ok(p.prompt.includes('85mm'), 'chân dung phải tự chọn 85mm');
  assert.ok(p.prompt.includes('Fujifilm'));
  assert.ok(p.soTu > 60);
  assert.ok(p.daThem.length >= 5, 'phải liệt kê mọi thứ tự thêm');
  for (const d of p.daThem) assert.ok(d.phan && d.gia);
  assert.ok(p.promptCam.includes('plastic skin'), 'phải chặn da nhựa');
  assert.ok(p.promptCam.includes('extra fingers'));
  assert.ok(CAM.length >= 30);
  // ống kính và ánh sáng đổi theo kiểu ảnh
  assert.equal(dungPrompt('x', { kieuAnh: 'phong-canh' }).ongKinh, '24mm');
  assert.equal(dungPrompt('x', { kieuAnh: 'san-pham' }).ongKinh, '105mm');
});

// ── 6. SOÁT CHẤT LƯỢNG ─────────────────────────────────────────────────────

test('soát bắt được ảnh mờ, ảnh cháy sáng và ảnh bẹt', () => {
  const a = anhThu(240, 180);
  const tot = QC.soat(a);
  assert.ok(tot.chiTiet.length === 7, 'phải đủ bảy phép đo');

  const mo = QC.soat(I.lamMo(a, 3));
  assert.ok(mo.loi.some((l) => l.truc === 'doNet'), 'không bắt được ảnh mờ');
  assert.ok(mo.diem < tot.diem, 'ảnh mờ phải bị trừ điểm');

  const chay = QC.soat(I.chinhMau(a, { doSang: 0.55 }));
  assert.ok(chay.loi.some((l) => l.truc === 'chaySang' || l.truc === 'phoiSang'), 'không bắt được cháy sáng');

  const bet = QC.soat(I.chinhMau(a, { tuongPhan: 0.25 }));
  assert.ok(bet.loi.some((l) => l.truc === 'tuongPhan'), 'không bắt được ảnh bẹt');
  for (const l of bet.loi) assert.ok(l.sua && l.sua.length > 10, 'mỗi lỗi phải kèm cách sửa');
});

test('cân bằng trắng chấm theo CHỦ Ý của hồ sơ, không theo trung tính', () => {
  const a = anhThu(200, 150);
  const am = I.chinhMau(a, P.layMayAnh('Canon').mau);     // Canon cố ý ngả ấm
  const trungTinh = QC.soat(am);
  const theoHoSo = QC.soat(am, { mayAnh: 'Canon', phim: 'Khong' });
  const truc = (r) => r.chiTiet.find((x) => x.id === 'canBangTrang');
  assert.ok(truc(theoHoSo).diem >= truc(trungTinh).diem,
    'chấm theo hồ sơ phải không thiệt hơn chấm theo trung tính');
  assert.ok(QC.lechDuKien('Canon', 'Khong') > QC.lechDuKien('Hasselblad', 'Khong'),
    'Canon phải ngả ấm hơn Hasselblad');
});

// ── 7. CỔNG TẠO ẢNH ────────────────────────────────────────────────────────

test('khung dựng luôn vẽ được, và nói rõ nó không phải ảnh chụp', () => {
  const c = new CongTaoAnh();
  assert.equal(c.khungDung.sanSang().ok, true);
  const ke = dungPrompt('x', { kieuAnh: 'chan-dung' });
  const svg = c.khungDung.ve(ke);
  assert.ok(svg.startsWith('<svg') && svg.trim().endsWith('</svg>'));
  assert.ok(!/NaN|undefined/.test(svg), 'SVG có giá trị hỏng');
  assert.ok(svg.includes('không phải ảnh chụp'), 'phải nói rõ đây là khung dựng');
  assert.ok(svg.includes('chủ thể'));
});

test('đường đi cổng nói rõ chọn cổng nào và bỏ qua cổng nào vì sao', () => {
  const c = new CongTaoAnh();
  const dd = c.duongDi('mien-phi');
  assert.equal(dd.chon, 'pollinations');
  const st = c.trangThai();
  assert.equal(st.khungDung.sanSang, true);
  const hf = st.cong.find((x) => x.id === 'huggingface');
  assert.equal(hf.sanSang, false);
  assert.ok(hf.sua.includes('HF_TOKEN'), 'phải chỉ ra cách bật');
  for (const c2 of st.cong) assert.equal(c2.tinhTien, false, 'các cổng mặc định đều không tính tiền');
  assert.equal(c.duongDi('co-khoa').chuoi[0].id, 'huggingface');
});

// ── 8. TRỌN VÒNG QUA DỊCH VỤ ───────────────────────────────────────────────

test('hậu kỳ tám tầng chạy trọn vòng trên ảnh có sẵn, không cần mạng', () => {
  const s = new PhotoService({});
  const vao = PNG.ghiPNG(anhThu(320, 240));
  const r = s.hauKy(vao, { mayAnh: 'Fujifilm', phim: 'KodakPortra400', chatLuong: 'hd' });
  assert.equal(r.ok, true);
  assert.equal(r.rong, 1280);
  assert.equal(r.cao, 960, 'phải giữ đúng tỉ lệ 4:3');
  assert.ok(r.buoc.length >= 6, `mới có ${r.buoc.length} bước`);
  const ten = r.buoc.map((b) => b.buoc);
  for (const b of ['đọc ảnh', 'phóng to', 'chất màu máy ảnh', 'giả lập phim', 'làm sắc', 'hạt phim', 'tối góc']) {
    assert.ok(ten.includes(b), `thiếu bước ${b}`);
  }
  assert.ok(r.cham.diem > 0);
  assert.equal(r.soSanh.bang.length, 7, 'phải so đủ bảy trục trước và sau');
  assert.ok(r.exif.Make, 'phải gắn siêu dữ liệu máy ảnh');

  const x = s.xuat(r.anh, { mayAnh: 'Fujifilm' });
  assert.equal(PNG.nhanDang(x.png), 'png');
  assert.equal(PNG.nhanDang(x.jpeg), 'jpeg');
  assert.ok(x.byteJpeg < x.bytePng, 'JPEG phải nhỏ hơn PNG');
  assert.equal(PNG.docPNG(x.png).width, 1280);
  assert.equal(JPG.docJPEG(x.jpeg).width, 1280);
});

test('hậu kỳ đọc được cả ảnh JPEG đầu vào', () => {
  const s = new PhotoService({});
  const vao = JPG.ghiJPEG(anhThu(200, 150), { chatLuong: 90 });
  const r = s.hauKy(vao, { chatLuong: 'hd' });
  assert.equal(r.ok, true);
  assert.ok(r.buoc[0].chiTiet.startsWith('JPEG'), r.buoc[0].chiTiet);
});

test('mọi mức chất lượng đều giữ đúng tỉ lệ khung hình và đúng cạnh dài', () => {
  const s = new PhotoService({});
  // Ảnh vào cố tình nhỏ: phép kiểm ở đây là TỈ LỆ và CẠNH DÀI, không phải
  // tốc độ. Hai mức nhỏ chạy trọn chuỗi thật; hai mức lớn chỉ kiểm phần số
  // học của đích đến — nấu 14 triệu điểm ảnh không nói thêm được điều gì mà
  // làm bộ kiểm thử chậm gấp năm lần.
  const vao = PNG.ghiPNG(anhThu(120, 80));            // 3:2
  for (const q of ['hd', '2k']) {
    const r = s.hauKy(vao, { chatLuong: q });
    assert.equal(r.ok, true);
    assert.equal(Math.max(r.rong, r.cao), MUC[q].canh, `${q}: cạnh dài sai`);
    assert.ok(Math.abs(r.rong / r.cao - 1.5) < 0.002, `${q}: tỉ lệ lệch — ${r.rong}×${r.cao}`);
  }
  for (const q of ['4k', '8k']) {
    const canh = MUC[q].canh;
    const w = Math.round(120 * (canh / 120));
    const h = Math.round(80 * (canh / 120));
    assert.equal(Math.max(w, h), canh);
    assert.ok(Math.abs(w / h - 1.5) < 0.002, `${q}: đích đến lệch tỉ lệ`);
    assert.ok(MUC[q].lanPhong >= 2, `${q} phải phóng nhiều lần`);
  }
  assert.equal(Object.keys(MUC).length, 4);
});

test('tệp lạ và ảnh quá lớn bị chặn với lý do rõ ràng', () => {
  const s = new PhotoService({});
  assert.equal(s.hauKy(Buffer.from('không phải ảnh')).error, 'CHƯA_HỖ_TRỢ_ĐỊNH_DẠNG');
  assert.equal(s.doc(Buffer.alloc(0)).error, 'THIẾU_TỆP_ẢNH');
  const qua = s.doc(Buffer.alloc(30 * 1024 * 1024));
  assert.equal(qua.error, 'TỆP_QUÁ_LỚN');
  assert.equal(s.chuanBi('').error, 'THIẾU_MÔ_TẢ');
});

test('chuẩn bị không cần mạng và trả đủ thứ để duyệt trước khi chụp', () => {
  const s = new PhotoService({});
  const r = s.chuanBi('Chân dung phụ nữ áo dài đỏ bên hồ sen', { kieuAnh: 'chan-dung', mayAnh: 'Fujifilm', phim: 'KodakPortra400' });
  assert.equal(r.ok, true);
  assert.ok(r.khungDung.startsWith('<svg'));
  assert.ok(r.prompt.length > 100);
  assert.ok(r.boCucKhac.length >= 2, 'phải gợi ý bố cục thay thế');
  assert.equal(r.duongDi.chon, 'pollinations');
  assert.ok(r.muc.canh > 0);
  const st = s.status();
  assert.equal(st.mayAnh.length, 9);
  assert.equal(st.phim.length, 7);
  assert.deepEqual(st.dinhDangDocDuoc, ['png', 'jpeg (baseline)']);
});

test('hậu kỳ tất định: cùng đầu vào, cùng cài đặt → cùng từng byte', () => {
  const s = new PhotoService({});
  const vao = PNG.ghiPNG(anhThu(160, 120));
  const a = s.hauKy(vao, { mayAnh: 'Leica', phim: 'FujiVelvia50', chatLuong: 'hd' });
  const b = s.hauKy(vao, { mayAnh: 'Leica', phim: 'FujiVelvia50', chatLuong: 'hd' });
  assert.ok(a.anh.data.equals(b.anh.data), 'chạy hai lần ra hai ảnh khác nhau');
  assert.equal(a.cham.diem, b.cham.diem);
});
