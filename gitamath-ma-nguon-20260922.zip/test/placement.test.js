'use strict';
/** Chẩn đoán đầu vào: đo rồi mới xếp tầng, không hỏi cảm tính. */
const { test, before } = require('node:test');
const assert = require('node:assert/strict');

const ItemBank = require('../src/content/item-bank');
const ItemGenerator = require('../src/content/generator');
const BankSeeder = require('../src/content/seeder');
const PlacementService = require('../src/learner/placement');
const ProfileStore = require('../src/learner/profile');
const Telemetry = require('../src/learner/telemetry');
const Mastery = require('../src/learner/mastery');
const { seedLevelForGrade, MIN_ITEMS, MAX_ITEMS } = PlacementService;

let bank;

before(() => {
  bank = new ItemBank();
  new BankSeeder({ bank, generator: new ItemGenerator({ bank }) }).seed({ perBlueprintLevel: 3 });
});

const svc = (extra = {}) => new PlacementService({ bank, ...extra });

/**
 * Học viên mô phỏng có năng lực thật cố định. Trả lời TẤT ĐỊNH:
 * dưới ngưỡng thì đúng, trên ngưỡng thì sai, đúng ngưỡng thì xen kẽ.
 */
function runSim(p, { learnerId, grade, trueLevel, maxItems }) {
  const st = p.start({ learnerId, grade, maxItems });
  assert.equal(st.ok, true, JSON.stringify(st));
  let cur = st.item;
  let n = 0;
  let last = null;
  while (n < MAX_ITEMS + 5) {
    const correct = cur.level < trueLevel ? true : cur.level > trueLevel ? false : (n % 2 === 0);
    const r = p.answer({ sessionId: st.sessionId, itemId: cur.id, correct, ms: 100_000, hintsUsed: 0 });
    assert.equal(r.ok, true, JSON.stringify(r));
    n++;
    if (r.done) { last = r; break; }
    cur = r.item;
  }
  assert.ok(last, 'phiên đo phải kết thúc');
  return { start: st, result: last, answered: n };
}

test('tầng khởi điểm suy từ lớp, không bắt lớp 9 làm lại bài lớp 3', () => {
  assert.equal(seedLevelForGrade(1), 0);
  assert.equal(seedLevelForGrade(5), 2);
  assert.equal(seedLevelForGrade(9), 3);
  assert.equal(seedLevelForGrade(12), 5);
  // Mốc dò phải tăng đơn điệu theo lớp, không nhảy cóc, không tụt.
  for (let g = 2; g <= 12; g++) {
    const prev = seedLevelForGrade(g - 1);
    const cur = seedLevelForGrade(g);
    assert.ok(cur >= prev && cur - prev <= 1, `lớp ${g - 1}→${g}: L${prev}→L${cur}`);
  }
  const st = svc().start({ learnerId: 'HV-SEED', grade: 9 });
  assert.equal(st.seedLevel, 3);
  assert.match(st.seedReason, /Lớp 9/);
  assert.ok(st.item.level >= 1, 'bài đầu không được rơi về tầng 0');
});

test('chưa biết lớp thì không đoán bừa', () => {
  const r = svc().start({ learnerId: 'HV-X' });
  assert.equal(r.ok, false);
  assert.equal(r.error, 'MISSING_INPUT');
  assert.match(r.hint, /chưa biết bắt đầu đo từ đâu/);
});

test('không gửi đáp án và lời giải xuống máy học viên', () => {
  const st = svc().start({ learnerId: 'HV-SEC', grade: 9 });
  assert.equal(st.item.answer, undefined);
  assert.equal(st.item.solutionSteps, undefined);
  assert.ok(st.item.stem, 'nhưng phải có đề bài');
  assert.ok(Array.isArray(st.item.hints), 'gợi ý thì được gửi, có đếm số lần dùng');
});

test('năng lực khác nhau cho kết quả xếp tầng khác nhau, đúng thứ tự', () => {
  const p = svc();
  const low = runSim(p, { learnerId: 'HV-L', grade: 9, trueLevel: 1 }).result;
  const mid = runSim(p, { learnerId: 'HV-M', grade: 9, trueLevel: 4 }).result;
  const high = runSim(p, { learnerId: 'HV-H', grade: 9, trueLevel: 6 }).result;
  assert.ok(low.placedLevel < mid.placedLevel, `${low.placedLevel} phải < ${mid.placedLevel}`);
  assert.ok(mid.placedLevel <= high.placedLevel, `${mid.placedLevel} phải ≤ ${high.placedLevel}`);
  assert.ok(Math.abs(mid.placedLevel - 4) <= 1, `đo L4 ra ${mid.placedLevel}, lệch quá xa`);
});

test('không xếp cao hơn tầng cao nhất mà học viên thật sự làm đúng', () => {
  const p = svc();
  const { result } = runSim(p, { learnerId: 'HV-CAP', grade: 12, trueLevel: 2 });
  assert.ok(result.placedLevel <= result.highestCorrectLevel + 1,
    `xếp L${result.placedLevel} nhưng cao nhất làm đúng chỉ L${result.highestCorrectLevel}`);
});

test('làm sai hết thì xếp tầng thấp nhất, không xếp theo lớp', () => {
  const p = svc();
  const st = p.start({ learnerId: 'HV-ZERO', grade: 12 });
  let cur = st.item; let r = null;
  for (let i = 0; i < MAX_ITEMS; i++) {
    r = p.answer({ sessionId: st.sessionId, itemId: cur.id, correct: false, ms: 60_000 });
    if (r.done) break;
    cur = r.item;
  }
  assert.equal(r.done, true);
  assert.equal(r.placedLevel, 0);
  assert.equal(r.accuracy, 0);
});

test('mỗi bài chỉ hỏi một lần trong cùng một phiên', () => {
  const p = svc();
  const st = p.start({ learnerId: 'HV-DUP', grade: 9 });
  const seen = [st.item.id];
  let cur = st.item;
  for (let i = 0; i < MAX_ITEMS; i++) {
    const r = p.answer({ sessionId: st.sessionId, itemId: cur.id, correct: i % 2 === 0, ms: 90_000 });
    if (r.done) break;
    seen.push(r.item.id);
    cur = r.item;
  }
  assert.equal(new Set(seen).size, seen.length, 'có bài bị hỏi lại');
});

test('phép đo phủ nhiều dạng, không hỏi mãi một chủ đề', () => {
  const p = svc();
  const { result } = runSim(p, { learnerId: 'HV-COV', grade: 9, trueLevel: 4 });
  assert.ok(result.byForm.length >= 5, `chỉ đo ${result.byForm.length} dạng`);
});

test('kết quả nêu rõ điểm mạnh, điểm yếu và lỗ hổng tiên quyết', () => {
  const p = svc();
  const { result } = runSim(p, { learnerId: 'HV-DIAG', grade: 9, trueLevel: 3 });
  assert.ok(Array.isArray(result.strengths));
  assert.ok(Array.isArray(result.weaknesses));
  assert.ok(Array.isArray(result.prerequisiteGaps));
  for (const f of result.byForm) {
    assert.ok(['vững', 'lung lay', 'yếu', 'chưa nắm'].includes(f.verdict), f.verdict);
  }
  assert.ok(result.recommendation.length >= 1);
  assert.match(result.recommendation[0], /Bắt đầu lộ trình ở tầng/);
});

test('sai số chuẩn và mức tin cậy được báo thật, không tô hồng', () => {
  const p = svc();
  const { result } = runSim(p, { learnerId: 'HV-SE', grade: 9, trueLevel: 4 });
  assert.ok(result.standardError > 0);
  assert.ok(['cao', 'vừa', 'thấp'].includes(result.confidence));
  assert.ok(['ĐỦ_TIN_CẬY', 'ĐỦ_SỐ_BÀI', 'HẾT_BÀI_PHÙ_HỢP'].includes(result.reason));
  assert.ok(result.itemsAsked >= MIN_ITEMS);
});

test('kết quả đo ghi thẳng vào hồ sơ học viên', () => {
  const profiles = new ProfileStore({ telemetry: new Telemetry(), mastery: new Mastery() });
  profiles.register('HV-REC', { fullName: 'Ghi hồ sơ', grade: 9 });
  const p = svc({ profiles });
  const { result } = runSim(p, { learnerId: 'HV-REC', grade: 9, trueLevel: 4 });
  const rec = profiles.get('HV-REC');
  assert.equal(rec.currentLevel, result.placedLevel);
  assert.equal(rec.placement.level, result.placedLevel);
  assert.ok(rec.levelHistory.some((h) => h.by === 'PLACEMENT'));
});

test('phiên đo cập nhật cả mức thạo và nhật ký thao tác', () => {
  const telemetry = new Telemetry();
  const mastery = new Mastery();
  const p = svc({ telemetry, mastery });
  runSim(p, { learnerId: 'HV-TEL', grade: 9, trueLevel: 4 });
  assert.ok(mastery.summary('HV-TEL').formsTouched > 0, 'phải có dữ liệu mức thạo');
  assert.ok(mastery.summary('HV-TEL').totalAttempts >= MIN_ITEMS);
});

test('phiên sai, bài sai, trả lời thiếu đều bị từ chối rõ ràng', () => {
  const p = svc();
  const st = p.start({ learnerId: 'HV-ERR', grade: 9 });
  assert.equal(p.answer({ sessionId: 'KHONG-CO', itemId: st.item.id, correct: true }).error, 'SESSION_NOT_FOUND');
  assert.equal(p.answer({ sessionId: st.sessionId, itemId: 'KHONG-CO', correct: true }).error, 'ITEM_NOT_FOUND');
  assert.equal(p.answer({ sessionId: st.sessionId, itemId: st.item.id }).error, 'MISSING_INPUT');
  p.abandon(st.sessionId);
  assert.equal(p.answer({ sessionId: st.sessionId, itemId: st.item.id, correct: true }).error, 'SESSION_FINISHED');
});

test('hai học viên trả lời y hệt nhau thì ra đúng cùng kết quả', () => {
  const a = runSim(svc(), { learnerId: 'HV-1', grade: 9, trueLevel: 4 }).result;
  const b = runSim(svc(), { learnerId: 'HV-2', grade: 9, trueLevel: 4 }).result;
  assert.equal(a.placedLevel, b.placedLevel);
  assert.equal(a.theta, b.theta);
  assert.deepEqual(a.byForm.map((f) => f.formCode), b.byForm.map((f) => f.formCode));
});
