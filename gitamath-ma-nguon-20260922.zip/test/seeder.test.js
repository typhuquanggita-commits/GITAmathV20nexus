'use strict';
/** Gieo kho: bài thật, có chứng cứ, phủ đủ, và sống sót khởi động lại. */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ItemBank = require('../src/content/item-bank');
const ItemGenerator = require('../src/content/generator');
const BankSeeder = require('../src/content/seeder');
const MathVerifier = require('../src/math/verifier');
const { Database } = require('../src/data/repository');
const { mayDaChungMinh } = BankSeeder;

function rig({ withStore = false } = {}) {
  const bank = new ItemBank();
  const gen = new ItemGenerator({ bank });
  let db = null, items = null;
  if (withStore) {
    db = new Database({ dir: fs.mkdtempSync(path.join(os.tmpdir(), 'gita-seed-')) });
    items = db.collection('items', { indexes: ['formCode', 'status'] });
  }
  return { bank, gen, db, items, seeder: new BankSeeder({ bank, generator: gen, items }) };
}

test('gieo xong thì kho phủ kín mọi ô (dạng × tầng) có bản thiết kế', () => {
  const { seeder } = rig();
  const r = seeder.seed({ perBlueprintLevel: 3 });
  assert.equal(r.ok, true);
  assert.ok(r.seeded >= 50, `mới gieo được ${r.seeded} bài`);
  assert.equal(r.coverage.empty.length, 0, `còn ô trống: ${r.coverage.empty.join(', ')}`);
  assert.equal(r.coverage.ratio, 1);
});

test('mọi bài phát hành đều có chứng cứ máy tự giải lại', () => {
  const { bank, seeder } = rig();
  seeder.seed({ perBlueprintLevel: 2 });
  const v = new MathVerifier();
  let n = 0;
  for (const it of bank.items.values()) {
    if (it.status !== 'PUBLISHED') continue;
    assert.equal(it.verification.verifierId, 'MATH-ENGINE');
    assert.equal(it.verification.match, true);
    assert.ok(it.verification.checks.length >= 1);
    // Kiểm lại độc lập một lần nữa bằng bộ kiểm tra mới tinh.
    assert.equal(v.verifyItem(it).verified, true, `${it.id} (${it.blueprintId}) không qua được lần kiểm lại`);
    n++;
  }
  assert.ok(n >= 30, `mới kiểm được ${n} bài đã phát hành`);
});

test('bài máy không tự giải lại được thì không phát hành, dù dễ hay khó', () => {
  const { bank, seeder } = rig();
  const r = seeder.seed({ perBlueprintLevel: 3 });
  // Bản ghi trong kho lưu kết luận của bộ kiểm chứng dưới khoá `match`
  // (còn bản do bộ sinh trả ra dùng khoá `verified`) — cổng phát hành đọc bản
  // của bộ sinh, còn kiểm thử này soi lại bản đã nằm trong kho.
  let daPhat = 0;
  for (const it of bank.items.values()) {
    if (it.status !== 'PUBLISHED') continue;
    daPhat++;
    assert.equal(it.verification?.match, true,
      `bài phát hành mà máy chưa giải lại khớp: ${it.id}`);
  }
  assert.ok(daPhat > 0, 'kho phải có bài đã phát hành');
  assert.equal(typeof mayDaChungMinh, 'function');
  assert.equal(mayDaChungMinh({ verification: { verified: true } }), true);
  assert.equal(mayDaChungMinh({ verification: { verified: false } }), false);
  assert.equal(mayDaChungMinh({}), false);
  assert.match(r.policy, /máy tự giải lại/);
});

test('bài khó có chứng minh máy thì VẪN được phát hành — cổng chặn theo chứng minh, không theo bậc sao', () => {
  const { bank, seeder } = rig();
  seeder.seed({ perBlueprintLevel: 3 });
  const kho = [...bank.items.values()].filter((i) => i.stars >= 4);
  assert.ok(kho.length > 0, 'kho phải có bài từ bốn sao trở lên');
  const daPhat = kho.filter((i) => i.status === 'PUBLISHED');
  // Chặn theo bậc sao là chặn nhầm trục: phần khó của bài khó chính là phần
  // máy kiểm chắc nhất. Chặn như cũ thì mọi đề đều thiếu đúng dải dùng để
  // phân loại học viên giỏi, tức là đề hứa một đằng dựng ra một nẻo.
  assert.ok(daPhat.length > 0, 'bài khó đã được máy chứng minh thì phải phát hành được');
  const namSao = [...bank.items.values()].filter((i) => i.stars === 5 && i.status === 'PUBLISHED');
  assert.ok(namSao.length > 0, 'kho phải có bài năm sao đã phát hành, nếu không thì không dựng nổi dải Thách thức');
});

test('gieo hai lần với cùng seed cho đúng cùng một kho', () => {
  const a = rig(); const b = rig();
  const ra = a.seeder.seed({ perBlueprintLevel: 3, seed: 'co-dinh' });
  const rb = b.seeder.seed({ perBlueprintLevel: 3, seed: 'co-dinh' });
  assert.equal(ra.seeded, rb.seeded);
  const stemsA = [...a.bank.items.values()].map((i) => i.stem).sort();
  const stemsB = [...b.bank.items.values()].map((i) => i.stem).sort();
  assert.deepEqual(stemsA, stemsB);
});

test('không có hai bài trùng nhau trong cả kho', () => {
  const { bank, seeder } = rig();
  seeder.seed({ perBlueprintLevel: 3 });
  const stems = [...bank.items.values()].map((i) => i.stem);
  assert.equal(new Set(stems).size, stems.length, 'có bài trùng y hệt lọt vào kho');
});

test('bài mang dải tầng phục vụ, không chỉ một tầng danh nghĩa', () => {
  const { bank, seeder } = rig();
  seeder.seed({ perBlueprintLevel: 2 });
  for (const it of bank.items.values()) {
    assert.ok(Array.isArray(it.servesLevels), `${it.id} thiếu dải tầng`);
    assert.ok(it.servesLevels[0] <= it.level && it.level <= it.servesLevels[1]);
  }
});

test('kho ghi xuống đĩa và nạp lại được sau khởi động lại', () => {
  const { bank, items, seeder, db } = rig({ withStore: true });
  const r = seeder.seed({ perBlueprintLevel: 2 });
  assert.ok(items.count() > 0);
  assert.equal(items.count(), r.published + r.awaitingHuman);

  // Dựng lại từ đầu, chỉ có cơ sở dữ liệu trong tay.
  const bank2 = new ItemBank();
  const seeder2 = new BankSeeder({ bank: bank2, generator: new ItemGenerator({ bank: bank2 }), items });
  const back = seeder2.restore();
  assert.equal(back.restored, items.count());
  assert.equal(bank2.items.size, items.count());

  // Chỉ mục chống trùng cũng phải được dựng lại, nếu không sẽ nhận bài trùng.
  const any = [...bank2.items.values()][0];
  const dup = bank2.draft({
    formCode: any.formCode, level: any.level, stars: any.stars,
    stem: any.stem, answer: any.answer, authorId: 'TEST',
  });
  assert.equal(dup.ok, false, 'sau khi nạp lại vẫn phải chặn được bài trùng');
  db.close();
});

test('bản ghi bài trong cơ sở dữ liệu đi qua được JSON', () => {
  const { items, seeder, db } = rig({ withStore: true });
  seeder.seed({ perBlueprintLevel: 2 });
  for (const doc of items.all().slice(0, 5)) {
    const s = JSON.stringify(doc);
    assert.ok(s.length > 100);
    assert.ok(JSON.parse(s).stem);
  }
  db.close();
});

test('báo cáo độ phủ chỉ đích danh ô mỏng và ô trống', () => {
  const { seeder } = rig();
  seeder.seed({ perBlueprintLevel: 1 });
  const c = seeder.coverage();
  assert.ok(c.slots > 20);
  assert.ok(Array.isArray(c.thin));
  for (const t of c.thin) assert.ok(t.items > 0 && t.items < 3);
});

test('chạy thử không đụng vào kho', () => {
  const { bank, seeder } = rig();
  const r = seeder.seed({ perBlueprintLevel: 2, dryRun: true });
  assert.equal(r.dryRun, true);
  assert.ok(r.seeded > 0);
  assert.equal(r.published, 0);
  assert.equal(bank.items.size, 0);
});
