'use strict';
/**
 * KIỂM SOÁT HỆ THỐNG: độ bền dữ liệu · dòng tiền · tổ thanh tra · lưới 50 ô ·
 * phân tích khảo sát
 *
 * Phần lớn các mục ở đây canh những thứ chỉ lộ ra khi đã quá muộn: dữ liệu mất
 * lúc cúp điện, ngân sách cháy trong một đêm, một phép soi báo đạt trong khi
 * nó chưa từng soi gì. Nên mục nào cũng phải chứng minh cơ chế CÓ RĂNG, chứ
 * không chỉ chứng minh nó chạy.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { Database } = require('../src/data/repository');
const SoCai = require('../src/dong-tien/so-cai');
const TT = require('../src/thanh-tra/to-thanh-tra');
const C50 = require('../src/matran/cay-50');
const PT = require('../src/khao-sat/phan-tich');
const ks = require('../src/khao-sat/mat-trong-nha');
const KhoKhaoSat = require('../src/khao-sat/kho');

const tmpDir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'gita-ks-'));

// ═══ ĐỘ BỀN DỮ LIỆU ════════════════════════════════════════════════════════

test('Gộp nhật ký giữ đúng thứ tự chống mất dữ liệu', () => {
  const d = tmpDir();
  const db = new Database({ dir: d });
  const c = db.collection('thu');
  for (let i = 0; i < 20; i++) c.put({ id: `X${i}`, v: i });
  const r = c.compact();
  assert.equal(r.ok, true);
  // Ảnh chụp phải đọc được NGAY và đủ bản ghi — nghĩa là đã xuống đĩa thật.
  const snap = JSON.parse(fs.readFileSync(path.join(d, 'thu.snap.json'), 'utf8'));
  assert.equal(snap.count, 20);
  assert.equal(snap.docs.length, 20);
  // Và không để sót tệp tạm — tệp tạm sót nghĩa là một lần gộp đứt giữa chừng.
  assert.equal(fs.existsSync(path.join(d, 'thu.snap.json.tmp')), false);
  db.close();
});

test('Gộp hỏng thì GIỮ NGUYÊN nhật ký — còn nhật ký là còn dựng lại được', () => {
  const d = tmpDir();
  const db = new Database({ dir: d });
  const c = db.collection('thu');
  for (let i = 0; i < 5; i++) c.put({ id: `X${i}`, v: i });
  const truoc = fs.readFileSync(path.join(d, 'thu.log'), 'utf8');
  assert.ok(truoc.length > 0, 'phải có nhật ký trước khi thử');
  // Ép gộp hỏng bằng cách khoá đường ghi.
  const that = c.snapFile;
  c.snapFile = path.join(d, 'khong-co-thu-muc-nay', 'x.snap.json');
  const r = c.compact();
  c.snapFile = that;
  assert.equal(r.ok, false);
  assert.equal(fs.readFileSync(path.join(d, 'thu.log'), 'utf8'), truoc, 'gộp hỏng mà vẫn xoá nhật ký');
  db.close();
});

test('Dữ liệu sống qua lần khởi động lại', () => {
  const d = tmpDir();
  const db = new Database({ dir: d });
  db.collection('thu').put({ id: 'A', v: 1 });
  db.close();
  const db2 = new Database({ dir: d });
  assert.equal(db2.collection('thu').get('A').v, 1);
  db2.close();
});

test('Kho khảo sát TỪ CHỐI kho bền vững sai hình dạng, không âm thầm rơi về bộ nhớ', () => {
  assert.throws(() => new KhoKhaoSat({ repo: { insert() {}, find() {}, remove() {} } }), /thiếu phương thức/);
  const d = tmpDir();
  const db = new Database({ dir: d });
  const kho = new KhoKhaoSat({ repo: db.collection('ks') });
  const de = ks.deBai('disc');
  const f = {};
  for (const c of de.cau) { f[`dung_${c.so}`] = 'C'; f[`it_${c.so}`] = 'D'; }
  const doc = ks.docBieuMau('disc', f);
  kho.luu({ hocVienId: 'H', congCu: 'DISC', ketQua: ks.cham('disc', doc.traLoi), cauTraLoi: doc.traLoi });
  // status phải nói THẬT: có bao nhiêu bản ghi nằm trên đĩa.
  assert.equal(kho.status().banGhiTrenDia, 1);
  db.close();
  const db2 = new Database({ dir: d });
  const kho2 = new KhoKhaoSat({ repo: db2.collection('ks') });
  assert.equal(kho2.moiNhat('H', { laChinhChu: true }).soCo, 1, 'kết quả không sống qua khởi động lại');
  db2.close();
});

// ═══ DÒNG TIỀN ═════════════════════════════════════════════════════════════

test('Sổ cái TỪ CHỐI ghi khoản chưa có nguồn — không bịa sổ', () => {
  const s = new SoCai({});
  for (const k of ['DOANH_THU', 'NHAN_SU', 'HA_TANG']) {
    const r = s.ghi({ khoan: k, usd: 1000 });
    assert.equal(r.ok, false, `${k} ghi được, nghĩa là sổ đang bịa`);
    assert.equal(r.error, 'KHOẢN_CHƯA_CÓ_NGUỒN');
  }
  assert.equal(s.ghi({ khoan: 'MO_HINH', usd: 0.5 }).ok, true);
});

test('Ngân sách CHẶN thật, không chỉ cảnh báo', () => {
  const s = new SoCai({ nganSach: { ngay: 1, thang: 10, nguongCanhBao: 0.8 } });
  assert.equal(s.xinTieu({ usd: 0.5 }).ok, true);
  s.ghi({ khoan: 'MO_HINH', usd: 0.9 });
  const chan = s.xinTieu({ usd: 0.5 });
  assert.equal(chan.ok, false);
  assert.equal(chan.error, 'VƯỢT_NGÂN_SÁCH_NGÀY');
  assert.match(chan.reason, /vượt trần ngày/);
  assert.equal(s.stats.chan, 1);
});

test('Trần THÁNG chặn được cả khi trần ngày còn chỗ', () => {
  const s = new SoCai({ nganSach: { ngay: 100, thang: 2, nguongCanhBao: 0.8 } });
  s.ghi({ khoan: 'MO_HINH', usd: 1.9, luc: Date.now() - 86400000 * 3 });
  const r = s.xinTieu({ usd: 0.5 });
  assert.equal(r.ok, false);
  assert.equal(r.error, 'VƯỢT_NGÂN_SÁCH_THÁNG');
});

test('Cảnh báo bật trước khi chạm trần', () => {
  const s = new SoCai({ nganSach: { ngay: 10, thang: 100, nguongCanhBao: 0.8 } });
  s.ghi({ khoan: 'MO_HINH', usd: 7.5 });
  const r = s.xinTieu({ usd: 1 });
  assert.equal(r.ok, true);
  assert.ok(r.canhBao.includes('ngày'), 'phải cảnh báo khi qua 80% trần ngày');
});

test('Biên bản dòng tiền nêu chỗ MÙ trước, con số sau', () => {
  const s = new SoCai({});
  const bb = s.bienBan();
  assert.ok(bb.chuaCoNguon.length >= 3);
  assert.match(bb.ketLuan, /KHÔNG dựng được báo cáo lợi nhuận/);
  for (const k of bb.chuaCoNguon) assert.ok(k.thieu && k.thieu.length > 20, `${k.ma} không nói thiếu gì`);
  // Bảng giá phải nói ngày cập nhật — giá cũ là ngân sách sai.
  assert.match(bb.bangGia.capNhat, /^\d{4}-\d{2}-\d{2}$/);
});

test('Quy token ra tiền luôn tự gọi là ước lượng', () => {
  const s = new SoCai({});
  const q = s.quyRaTien({ bac: 'strong', tokenVao: 1e6, tokenRa: 1e6 });
  assert.equal(q.tinCay, 'uoc-luong');
  assert.match(q.ghiChu, /Không phải hoá đơn/);
  assert.ok(q.usd > 0);
});

// ═══ TỔ THANH TRA ══════════════════════════════════════════════════════════

test('Mười thanh tra viên, mười việc KHÁC NHAU, không ai trùng ai', () => {
  assert.equal(TT.THANH_TRA_VIEN.length, 10);
  const soi = TT.THANH_TRA_VIEN.map((v) => v.soi);
  assert.equal(new Set(soi).size, 10, 'có hai người soi cùng một thứ');
  for (const v of TT.THANH_TRA_VIEN) {
    assert.ok(v.hong && v.hong.length > 15, `${v.ma} không nói hỏng ở đây thì mất gì`);
    assert.ok(['chan', 'bao'].includes(v.mucNang));
  }
});

test('Mười lượt mỗi ngày, rải đều, không dồn một chỗ', () => {
  assert.equal(TT.LICH.length, 10);
  const gio = TT.LICH.map((l) => l.gio);
  for (let i = 1; i < gio.length; i++) assert.ok(gio[i] > gio[i - 1], 'lịch phải tăng dần theo giờ');
  assert.ok(gio[0] <= 7, 'lượt đầu phải trước giờ học sáng');
  assert.ok(gio[gio.length - 1] >= 22, 'lượt cuối phải sau khi học viên nghỉ');
  for (const c of TT.cron()) assert.match(c.cron, /^\d{1,2} \d{1,2} \* \* \*$/);
});

test('Việc mức CHẶN được soi ở MỌI lượt', () => {
  const chan = TT.THANH_TRA_VIEN.filter((v) => v.mucNang === 'chan').map((v) => v.ma);
  for (let l = 1; l <= 10; l++) {
    const pc = TT.phanCong(l);
    for (const ma of chan) assert.ok(pc.tatCa.includes(ma), `lượt ${l} bỏ sót ${ma}`);
  }
});

test('Việc mức BÁO xoay vòng đều, ai cũng được soi trong một ngày', () => {
  const bao = TT.THANH_TRA_VIEN.filter((v) => v.mucNang === 'bao').map((v) => v.ma);
  const dem = {};
  for (let l = 1; l <= 10; l++) for (const ma of TT.phanCong(l).xoayVong) dem[ma] = (dem[ma] || 0) + 1;
  for (const ma of bao) assert.ok(dem[ma] >= 3, `${ma} chỉ được soi ${dem[ma] || 0} lần trong ngày`);
});

test('Phép soi thiếu, ném lỗi, hay trả rác đều tính KHÔNG ĐẠT', async () => {
  const r = await TT.chayLuot({
    luot: 1,
    viec: {
      TT01: () => ({ dat: true, chiTiet: 'ok' }),
      TT02: () => { throw new Error('hỏng máy'); },
      TT03: () => null,
      // TT04, TT05, TT09… cố tình thiếu
    },
  });
  const map = Object.fromEntries(r.ket.map((x) => [x.ma, x]));
  assert.equal(map.TT01.dat, true);
  assert.equal(map.TT02.dat, false);
  assert.match(map.TT02.chiTiet, /ném lỗi/);
  assert.equal(map.TT03.dat, false);
  assert.equal(map.TT04.dat, false);
  assert.match(map.TT04.chiTiet, /CHƯA CÓ phép soi/);
  assert.equal(r.phaiDungViec, true, 'phát hiện mức chặn phải dừng việc');
});

test('Thanh tra KHÔNG tự sửa, và biên bản nói rõ điều đó', async () => {
  const r = await TT.chayLuot({ luot: 3, viec: {} });
  assert.match(r.khongTuSua, /không tự vá/);
});

test('Thiếu lượt KHÔNG được tính là đạt', () => {
  const bb = TT.bienBanNgay([{ soVien: 8, soKhongDat: 0, phaiDungViec: false }]);
  assert.equal(bb.soLuotChuaChay, 9);
  assert.match(bb.ketLuan, /CHƯA ĐỦ LƯỢT/);
  assert.match(bb.ketLuan, /giống hệt lượt sạch/);
});

// ═══ LƯỚI 50 Ô ═════════════════════════════════════════════════════════════

test('Lưới đúng 5 tầng × 10 cấp, không ô nào thiếu', () => {
  const l = C50.luoi();
  assert.equal(l.soO, 50);
  for (let t = 1; t <= 5; t++) {
    for (let c = 1; c <= 10; c++) {
      const o = C50.o(t, c);
      assert.ok(o, `thiếu ô T${t}C${c}`);
      assert.ok(o.lamDuocGi && o.lamDuocGi.length > 15, `${o.ma} không nói làm được gì`);
      assert.ok(o.bangChung && o.bangChung.chung, `${o.ma} không có bằng chứng`);
    }
  }
});

test('Ô nào cũng phân biệt rõ mốc CỨNG với mốc MỀM', () => {
  const l = C50.luoi();
  assert.equal(l.soMocCung + l.soMocMem, 50);
  assert.equal(l.soMocCung, 15, 'ba mốc cứng mỗi tầng × năm tầng');
  for (const o of l.o) {
    if (o.bangChung.loai === 'moc-cung') assert.ok(o.bangChung.do, `${o.ma} là mốc cứng mà không nói đo bằng gì`);
    else assert.match(o.bangChung.canDo, /KHÔNG dùng để báo cáo đã đạt/);
  }
});

test('Cấp 10 của tầng k nối thẳng sang tầng k+1, không có khoảng trống', () => {
  for (let t = 1; t <= 4; t++) {
    const o = C50.o(t, 10);
    assert.equal(o.laChoNoi, true);
    assert.deepEqual(o.keTiep, { tang: t + 1, cap: 1 });
  }
  assert.equal(C50.o(5, 10).keTiep, null, 'ô cuối cùng không có bước kế tiếp');
});

test('Tiến độ quy ra đúng số ô đã đi', () => {
  assert.deepEqual(C50.tienDo(1, 1), { daDi: 1, tong: 50, tiLe: 0.02, o: 'T1C1' });
  assert.deepEqual(C50.tienDo(5, 10), { daDi: 50, tong: 50, tiLe: 1, o: 'T5C10' });
  assert.equal(C50.tienDo(6, 1), null);
  assert.equal(C50.tienDo(1, 11), null);
});

// ═══ PHÂN TÍCH KHẢO SÁT ════════════════════════════════════════════════════

function kqThat({ tapTrung = 3, thoiGian = 3, giacNgu = 1 } = {}) {
  const f = {};
  for (const c of ks.deBai('phuong-phap').cau) {
    f[`c_${c.so}`] = String(c.mien === 'TAP_TRUNG' ? tapTrung : c.mien === 'THOI_GIAN' ? thoiGian : 3);
  }
  const g = {};
  for (const c of ks.deBai('tam-ly').cau) g[`c_${c.so}`] = String(c.mien === 'GIAC_NGU' ? giacNgu : 1);
  return {
    PHUONG_PHAP_HOC: ks.cham('phuong-phap', ks.docBieuMau('phuong-phap', f).traLoi),
    TAM_LY_HOC_DUONG: ks.cham('tam-ly', ks.docBieuMau('tam-ly', g).traLoi),
  };
}

test('KHÔNG gộp sáu mặt thành một chỉ số tổng hợp', () => {
  const r = PT.phanTich({ ketQua: kqThat() });
  assert.equal(r.chiSoTongHop, undefined);
  assert.match(r.khongCoChiSoTongHop, /KHÔNG gộp/);
});

test('Miền tâm lý nặng KHÔNG bị trung bình làm chìm', () => {
  const on = PT.phanTich({ ketQua: kqThat({ giacNgu: 1 }) }).sauMat.find((m) => m.ma === 'TAM_LY');
  const mat = PT.phanTich({ ketQua: kqThat({ giacNgu: 4 }) }).sauMat.find((m) => m.ma === 'TAM_LY');
  assert.ok(mat.diem < on.diem, 'mất ngủ nặng mà điểm tâm lý không tụt');
  assert.ok(mat.diem < 40, `điểm tâm lý ${mat.diem} vẫn trên ngưỡng dù mất ngủ 4/4`);
  assert.equal(mat.mienNangNhat.ma, 'GIAC_NGU');
});

test('Chuỗi vấn đề xếp theo CĂN NGUYÊN, không theo điểm thấp nhất', () => {
  const r = PT.phanTich({ ketQua: kqThat({ giacNgu: 4, tapTrung: 1, thoiGian: 1 }) });
  const thu = r.chuoiVanDe.map((c) => c.ma);
  assert.equal(thu[0], 'TAM_LY', `tâm lý phải đứng đầu, đang là ${thu.join(' → ')}`);
  assert.ok(thu.indexOf('NHIP') < thu.indexOf('TOC_DO'), 'nhịp phải gỡ trước tốc độ');
  const nhip = r.chuoiVanDe.find((c) => c.ma === 'NHIP');
  assert.match(nhip.viSaoThuTuNay, /Đứng sau/);
});

test('Nguyện vọng khác nhau cho thứ tự khác nhau', () => {
  const kq = kqThat({ tapTrung: 1, thoiGian: 1 });
  const a = PT.phanTich({ ketQua: kq, nguyenVong: 'THI_CHUYEN_CAP' }).chuoiVanDe.map((c) => c.ma);
  const b = PT.phanTich({ ketQua: kq, nguyenVong: 'BOT_SO_HOC' }).chuoiVanDe.map((c) => c.ma);
  assert.ok(a.length && b.length);
  const nv = PT.NGUYEN_VONG.THI_CHUYEN_CAP;
  assert.ok(nv.doiGi && nv.doiGi.length > 30, 'nguyện vọng phải nói rõ chọn nó thì đổi gì');
  for (const k of Object.values(PT.NGUYEN_VONG)) {
    assert.ok(k.uuTien.length >= 2, `${k.ma} không khai ưu tiên`);
    assert.ok(k.doiGi.length > 30, `${k.ma} không nói chọn nó thì đổi gì`);
  }
});

test('Mỗi mặt nói rõ TIN TỚI ĐÂU — số đo hay lời tự khai', () => {
  const r = PT.phanTich({ ketQua: kqThat({ tapTrung: 1, thoiGian: 1 }) });
  for (const c of r.chuoiVanDe) {
    assert.ok(['do-luong', 'tu-khai-doi-chieu', 'tu-khai'].includes(c.suckNang));
    assert.ok(c.tinToiDau && c.tinToiDau.length > 10, `${c.ma} không nói tin tới đâu`);
  }
});

test('DISC KHÔNG bị cho điểm — thang ipsative không so được giữa người', () => {
  const de = ks.deBai('disc');
  const f = {};
  for (const c of de.cau) { f[`dung_${c.so}`] = 'C'; f[`it_${c.so}`] = 'D'; }
  const r = PT.phanTich({ ketQua: { DISC: ks.cham('disc', ks.docBieuMau('disc', f).traLoi) } });
  const m = r.sauMat.find((x) => x.ma === 'CACH_LAM_VIEC');
  assert.equal(m.diem, null);
  assert.match(m.khongChamDiem, /ipsative/);
});

test('Thiếu bộ khảo sát thì nói thẳng thiếu gì, không đoán điểm', () => {
  const r = PT.phanTich({ ketQua: {} });
  assert.ok(r.soMatThieuCanCu >= 5);
  for (const m of r.matThieuCanCu) assert.ok(m.thieu && m.thieu.length > 10);
  assert.match(r.ketLuan, /Chưa đủ căn cứ/);
});

// ── SỔ TAY QUY TRÌNH ────────────────────────────────────────────────────────
// Sổ tay là thứ người ta mở lúc cuống. Ba tính chất phải đúng, nếu không thì
// lúc cần nhất nó phản tác dụng: đủ bốn mục, đường dẫn có thật, và mọi thanh
// tra viên đều tra được ra kịch bản của mình.
const SoTay = require('../src/quy-trinh/so-tay');

test('Mỗi kịch bản trực sự cố trả lời đủ bốn câu, kể cả câu CẤM LÀM', () => {
  for (const k of SoTay.KICH_BAN) {
    assert.ok(k.dauHieu.length > 0, `${k.ma} không có dấu hiệu nào để nhận ra`);
    assert.ok(k.lamNgay.length > 0, `${k.ma} không nói làm gì ngay`);
    assert.ok(k.aiQuyet && k.aiQuyet.length >= 12, `${k.ma} không nói ai quyết`);
    // Mục hay bị bỏ nhất, nên canh riêng: kịch bản không có CẤM LÀM là kịch bản
    // để người trực tự nghĩ ra cách "cứu chữa" — và đó là cách sự cố nhỏ thành lớn.
    assert.ok(k.camLam.length > 0, `${k.ma} không có mục CẤM LÀM`);
    assert.ok(SoTay.MUC[k.muc], `${k.ma} có mức khẩn lạ: ${k.muc}`);
  }
});

test('Mọi đường dẫn tệp khai trong sổ tay đều tồn tại thật', () => {
  // Tài liệu trỏ vào tệp không còn thì tệ hơn không có tài liệu: người trực
  // mất thêm mấy phút đi tìm một thứ đã bị xoá, đúng lúc không có phút nào để mất.
  const goc = path.join(__dirname, '..');
  const thieu = [];
  for (const k of SoTay.KICH_BAN) {
    for (const d of (k.lienQuan || [])) {
      if (!fs.existsSync(path.join(goc, d))) thieu.push(`${k.ma} → ${d}`);
    }
  }
  assert.deepEqual(thieu, [], `sổ tay trỏ vào tệp không có: ${thieu.join(', ')}`);
});

test('Mọi thanh tra viên đều tra ra được kịch bản của mình', () => {
  // Thanh tra viên báo động mà không có sổ để mở thì báo động ấy dừng ở màn hình.
  const khongCoSo = TT.THANH_TRA_VIEN
    .filter((v) => SoTay.theoThanhTra(v.ma).length === 0)
    .map((v) => v.ma);
  assert.deepEqual(khongCoSo, [], `thanh tra viên không có kịch bản: ${khongCoSo.join(', ')}`);
  // Và tra phải ra đúng kịch bản, không phải ra bừa cho đủ.
  const tt09 = SoTay.theoThanhTra('TT09').map((k) => k.ma);
  assert.deepEqual(tt09.sort(), ['KB02', 'KB04']);
  assert.deepEqual(SoTay.theoThanhTra('TT-KHONG-CO'), []);
});

test('Sổ tay xếp kịch bản ĐỎ lên trước, không xếp theo mã', () => {
  // Người mở sổ lúc cuống đọc từ trên xuống. Thứ tự đọc là thứ tự ưu tiên.
  const ds = SoTay.soTay().kichBan;
  const thuTu = { DO: 0, CAM: 1, VANG: 2 };
  for (let i = 1; i < ds.length; i++) {
    assert.ok(thuTu[ds[i - 1].muc] <= thuTu[ds[i].muc],
      `${ds[i - 1].ma} (${ds[i - 1].muc}) đứng trước ${ds[i].ma} (${ds[i].muc})`);
  }
  assert.equal(ds[0].muc, 'DO');
});

// ── VÉ CHỐNG GIẢ MẠO BIỂU MẪU (CSRF) ────────────────────────────────────────
// Khu riêng xác thực bằng cookie, nên trình duyệt gửi cookie kèm cả biểu mẫu
// nằm trên trang lạ. Lớp vé phải hỏng theo cách khác với lớp Sec-Fetch-Site,
// nếu không thì có hai lớp cũng như một.
const CGM = require('../src/web/chong-gia-mao');

test('Vé gắn với phiên: mỗi phiên một vé, và vé của phiên khác bị từ chối', () => {
  const a = CGM.veCua('phien-cua-an');
  const b = CGM.veCua('phien-cua-binh');
  assert.notEqual(a, b, 'hai phiên khác nhau mà cùng một vé thì vé không bảo vệ được gì');
  assert.equal(CGM.veCua('phien-cua-an'), a, 'cùng một phiên phải ra cùng một vé, nếu không biểu mẫu hỏng sau mỗi lần tải lại');
  assert.ok(CGM.kiemVe('phien-cua-an', a));
  assert.equal(CGM.kiemVe('phien-cua-an', b), false, 'vé của phiên khác phải bị từ chối');
});

test('Không có phiên thì không có vé, và vé rỗng không lọt', () => {
  // Chưa đăng nhập thì không có gì để giả mạo hộ — nhưng cũng không được phát
  // ra một vé nào, vì một vé phát cho "không ai" là vé ai cũng dùng được.
  assert.equal(CGM.veCua(null), null);
  assert.equal(CGM.veCua(''), null);
  assert.equal(CGM.kiemVe('phien', ''), false);
  assert.equal(CGM.kiemVe('phien', null), false);
  assert.equal(CGM.kiemVe('phien', undefined), false);
  assert.equal(CGM.kiemVe(null, 've-bat-ky'), false);
});

test('Vé không lần ngược ra được token phiên', () => {
  // Vé nằm trong HTML. Nếu từ vé suy ra được token phiên thì nhúng vé vào
  // trang chính là nhúng phiên vào trang.
  const token = 'token-phien-rat-bi-mat-0123456789';
  const ve = CGM.veCua(token);
  assert.ok(!ve.includes(token));
  assert.ok(!Buffer.from(ve, 'base64url').toString('utf8').includes('token-phien'));
  assert.equal(ve.length, 43, 'vé phải là HMAC-SHA256 base64url, dài cố định');
});

test('Ô ẩn nhúng được thẳng vào HTML và không mở đường tiêm mã', () => {
  const ve = CGM.veCua('phien-x');
  const o = CGM.oAn(ve);
  assert.match(o, /^<input type="hidden" name="ve" value="[A-Za-z0-9_-]+">$/);
  // Không có vé thì KHÔNG nhúng ô rỗng: một ô rỗng trông như đã có bảo vệ.
  assert.equal(CGM.oAn(null), '');
  assert.equal(CGM.oAn(''), '');
  // Vé bẩn (không bao giờ xảy ra với cách sinh hiện tại, nhưng cách sinh có
  // thể đổi, còn chỗ nhúng này thì không ai nhớ ra để sửa theo).
  assert.equal(CGM.oAn('abc"><script>x</script>'), '<input type="hidden" name="ve" value="abcscriptxscript">');
});

test('Mọi biểu mẫu POST của khu riêng đều mang ô vé', () => {
  // Cùng một luật với mục kiểm trong npm run verify, đặt cả ở đây để lỗi hiện
  // ra ngay trong vòng chạy test nhanh chứ không đợi tới lượt kiểm định đầy đủ.
  const thuMuc = path.join(__dirname, '..', 'src', 'web');
  const thieu = [];
  let soForm = 0;
  for (const f of fs.readdirSync(thuMuc).filter((x) => x.endsWith('.js'))) {
    const ma = fs.readFileSync(path.join(thuMuc, f), 'utf8');
    if (!/\/nha\b/.test(ma)) continue;
    for (const than of ma.match(/<form\b[\s\S]*?<\/form>/g) || []) {
      if (!/method\s*=\s*["']post["']/i.test(than)) continue;
      soForm++;
      if (!/oAn\(/.test(than)) thieu.push(`${f}: ${than.slice(0, 60)}…`);
    }
  }
  assert.deepEqual(thieu, [], `biểu mẫu POST thiếu ô vé: ${thieu.join(' | ')}`);
  assert.ok(soForm >= 3, `chỉ tìm thấy ${soForm} biểu mẫu POST — mục kiểm này đang soi nhầm chỗ`);
});

// ── BỘ KIỂM KHÔNG ĐƯỢC GHI VÀO DỮ LIỆU THẬT ────────────────────────────────
test('Mọi tệp kiểm dựng hệ thống đều dùng kho dữ liệu riêng', () => {
  // Bốn tệp kiểm từng gọi boot() mà không đặt DB_DIR, nên chúng ghi thẳng vào
  // data/db: tài khoản kiểm thử ở lại sau mỗi lần chạy, cửa khởi tạo vì thế
  // đóng luôn cho lần sau, và cả bộ kiểm hỏng theo kiểu rất khó lần ra. Tệ hơn
  // nữa: bộ kiểm có quyền xoá bản ghi và nén ảnh chụp — của dữ liệu THẬT.
  const thuMuc = __dirname;
  const hong = [];
  for (const f of fs.readdirSync(thuMuc).filter((x) => x.endsWith('.test.js'))) {
    const ma = fs.readFileSync(path.join(thuMuc, f), 'utf8');
    if (!/require\(['"]\.\.\/src\/index['"]\)/.test(ma)) continue;
    if (!/process\.env\.DB_DIR\s*=/.test(ma)) hong.push(`${f} dựng hệ thống mà không đặt DB_DIR riêng`);
    else if (!/process\.env\.SNAPSHOT_DIR\s*=/.test(ma)) hong.push(`${f} đặt DB_DIR riêng nhưng vẫn ghi ảnh chụp vào chỗ thật`);
  }
  assert.deepEqual(hong, [], hong.join(' · '));
});

// ── HÌNH CÂY GIÁ TRỊ ────────────────────────────────────────────────────────
// Hình vẽ là chỗ dễ nói dối nhất trong cả hệ thống: người xem tin vào cái mình
// nhìn thấy trước khi đọc chữ. Nên hình này phải đọc từ ĐÚNG lưới 50 ô, và
// không được vẽ thêm một quả nào mà lưới không có.
const CayHinh = require('../src/web/cay-hinh');

test('Hình cây có đúng 50 quả, và số quả chín khớp số mốc cứng của lưới', () => {
  const l = C50.luoi();
  const { svg } = CayHinh.veCay({ luoi: l });
  const dem = (re) => (svg.match(re) || []).length;
  assert.equal(dem(/class="qua"/g), 50, 'hình phải có đúng 50 quả — mỗi cấp một quả');
  assert.equal(dem(/qua-chin/g), l.soMocCung, 'số quả chín phải bằng số mốc CỨNG của lưới');
  assert.equal(dem(/qua-non/g), l.soMocMem, 'số quả non phải bằng số mốc MỀM của lưới');
  assert.equal(l.soMocCung + l.soMocMem, 50);
  // Quả chín và quả non phải khác nhau về hình, không chỉ khác màu trên giấy.
  assert.ok(svg.includes('qua-loi'), 'quả chín thiếu nét phân biệt với quả non');
});

test('Vẽ hai lần ra hai hình giống hệt nhau', () => {
  // Hình có một số ngẫu nhiên nào thì mỗi lần tải trang cây lại khác một chút,
  // và không ai đối chiếu được hình hôm nay với hình tuần trước.
  const a = CayHinh.veCay({ luoi: C50.luoi() }).svg;
  const b = CayHinh.veCay({ luoi: C50.luoi() }).svg;
  assert.equal(a, b);
  assert.ok(!/NaN|undefined|Infinity/.test(a), 'hình có toạ độ hỏng');
});

test('Mọi nét của hình nằm trong khung, không tràn ra ngoài', () => {
  // Chữ tràn ra ngoài viewBox thì trình duyệt cắt cụt — và bản trước đúng là
  // đã cắt mất chữ đầu của nhãn một tầng.
  const { svg } = CayHinh.veCay({ luoi: C50.luoi() });
  const x = [...svg.matchAll(/\s(?:cx|x|x1|x2)="(-?[\d.]+)"/g)].map((m) => Number(m[1]));
  const y = [...svg.matchAll(/\s(?:cy|y|y1|y2)="(-?[\d.]+)"/g)].map((m) => Number(m[1]));
  assert.ok(x.length > 100 && y.length > 100, 'không đọc được toạ độ nào — phép kiểm đang soi nhầm chỗ');
  assert.ok(Math.min(...x) >= 0 && Math.max(...x) <= CayHinh.W, `x ra ngoài khung: ${Math.min(...x)}..${Math.max(...x)}`);
  assert.ok(Math.min(...y) >= 0 && Math.max(...y) <= CayHinh.H, `y ra ngoài khung: ${Math.min(...y)}..${Math.max(...y)}`);
});

test('Năm mươi cấp có năm mươi lá và năm mươi quả KHÁC NHAU', () => {
  // Một cái cây mà lá nào cũng giống lá nào thì nhìn là biết không ai trồng nó
  // thật. Đây là phép chặn việc dập khuôn: lấy một câu mẫu rồi thay tên tầng.
  const l = C50.luoi();
  assert.equal(l.o.filter((x) => !x.la).length, 0, 'có ô thiếu lá');
  assert.equal(l.o.filter((x) => !x.qua).length, 0, 'có ô thiếu quả');
  assert.equal(new Set(l.o.map((x) => x.la)).size, 50, 'có lá trùng nhau');
  assert.equal(new Set(l.o.map((x) => x.qua)).size, 50, 'có quả trùng nhau');
  // Quả viết cho GIA ĐÌNH nên không được hứa điểm số.
  const hua = l.o.filter((x) => /\b\d+\s*(điểm|đ)\b|điểm 9|điểm 10|\bHSA\b|\bIELTS\s*\d/.test(x.qua));
  assert.deepEqual(hua.map((x) => x.ma), [], 'có quả hứa bằng điểm số — cây này hứa năng lực, không hứa điểm');
});

test('Chưa đủ căn cứ thì KHÔNG quả nào được tô như đã hái', () => {
  const l = C50.luoi();
  const chua = CayHinh.veCay({ luoi: l, dangO: { duCanCu: false } }).svg;
  assert.equal((chua.match(/o-chua-biet/g) || []).length, 50);
  assert.equal((chua.match(/o-da-qua/g) || []).length, 0, 'chưa có căn cứ mà đã tô quả đã hái');
  // Có căn cứ thì tô đúng số ô đã qua, không tô thừa một ô nào.
  const co = CayHinh.veCay({ luoi: l, dangO: { duCanCu: true, tang: 3, cap: 4 } }).svg;
  assert.equal((co.match(/o-da-qua/g) || []).length, (3 - 1) * 10 + 4 - 1);
  assert.equal((co.match(/o-dang-o/g) || []).length, 1);
});

test('Hình cây từ chối vẽ khi lưới không đủ 50 ô', () => {
  // Vẽ một cái cây không khớp lưới là vẽ một lời nói dối, nên thà nổ.
  const l = C50.luoi();
  assert.throws(() => CayHinh.veCay({ luoi: { ...l, o: l.o.slice(0, 40) } }), /50 ô/);
  assert.throws(() => CayHinh.veCay({}), /50 ô/);
});

test('Hình cây không mang một chữ nào của bảng phân loại nội bộ', () => {
  // Cây giá trị là mặt KHÁCH HÀNG. Hình cũng phải qua bức tường như mọi trang.
  const tuong = require('../src/cay-tien/buc-tuong');
  const { svg, moTa } = CayHinh.veCay({ luoi: C50.luoi() });
  assert.equal(tuong.soiRoRi(svg).sach, true, JSON.stringify(tuong.soiRoRi(svg).roRi));
  assert.equal(tuong.soiRoRi(moTa).sach, true);
  // Và không tải gì từ bên ngoài: khu riêng chạy với script-src 'none'.
  assert.ok(!/<script|href="http|xlink:href|<image/i.test(svg), 'hình kéo thứ gì đó từ ngoài vào');
});

// ── CHIỀU SÂU LUI VỀ CỦA ẢNH CHỤP ──────────────────────────────────────────
test('Chính sách giữ ảnh cho đúng chiều sâu đã cam kết, không chỉ đúng tên', () => {
  // Bản trước mang đúng cái tên "ông–cha–con" mà không làm đúng việc ấy, và
  // lượt thanh tra tìm ra bằng mô phỏng: chụp 2.881 ảnh trong 30 ngày, dọn
  // xong còn 30 ảnh, ảnh cũ nhất 7,3 GIỜ trước — trong khi sổ tay hứa 30 ngày.
  //
  // Nguyên nhân: mỗi tầng giữ N ảnh MỚI NHẤT trong cửa sổ của nó, mà ba cửa
  // sổ lồng nhau, nên hợp của chúng chỉ còn "30 ảnh mới nhất".
  //
  // Hậu quả không nằm ở con số: hỏng dữ liệu phát hiện sau hai ngày thì KHÔNG
  // CÒN GÌ để lui về, còn người vận hành đọc sổ tay và tin mình có 30 ngày.
  const S = require('../src/security/snapshot');
  const thu = (ngayCo) => {
    const s = new S({ dir: path.join(os.tmpdir(), `gfs-${ngayCo}-${Date.now()}`), collect: () => ({}), apply: () => ({}) });
    const now = Date.now();
    s.snapshots = [];
    let n = 0;
    for (let t = ngayCo * 24 * 60; t >= 0; t -= 15) {
      s.snapshots.push({ id: `S${n++}`, version: `v${n}`, at: now - t * 60_000, auto: true });
    }
    const truoc = s.snapshots.length;
    s.prune();
    const at = s.snapshots.map((x) => x.at).sort((a, b) => a - b);
    return { truoc, giu: s.snapshots.length, sauNgay: (now - at[0]) / 86_400_000 };
  };

  // Có dư dữ liệu thì phải đạt trọn chiều sâu cam kết.
  const r35 = thu(35);
  assert.ok(r35.sauNgay >= S.CHIEU_SAU_CAM_KET_NGAY,
    `có 35 ngày dữ liệu mà chiều sâu chỉ ${r35.sauNgay.toFixed(1)} ngày, cam kết ${S.CHIEU_SAU_CAM_KET_NGAY}`);
  // Và phải dọn thật, không giữ hết 3.361 ảnh.
  assert.ok(r35.giu < 100, `giữ ${r35.giu} ảnh — chính sách dọn không chạy`);
  assert.ok(r35.giu > 40, `chỉ giữ ${r35.giu} ảnh — quá thưa để lui về`);

  // Có ít dữ liệu thì chiều sâu bằng đúng lượng dữ liệu có, không hơn.
  const r7 = thu(7);
  assert.ok(r7.sauNgay >= 6 && r7.sauNgay <= 7.1, `7 ngày dữ liệu ra chiều sâu ${r7.sauNgay.toFixed(1)}`);

  // Ảnh trong 24 giờ gần nhất phải DÀY hơn ảnh của tháng trước — đó chính là
  // ý nghĩa của ông–cha–con.
  const s = new S({ dir: path.join(os.tmpdir(), `gfs-day-${Date.now()}`), collect: () => ({}), apply: () => ({}) });
  const now = Date.now();
  s.snapshots = [];
  let n = 0;
  for (let t = 35 * 24 * 60; t >= 0; t -= 15) s.snapshots.push({ id: `S${n++}`, version: `v${n}`, at: now - t * 60_000, auto: true });
  s.prune();
  const at = s.snapshots.map((x) => x.at);
  const trong24h = at.filter((a) => now - a <= 24 * 3_600_000).length;
  const cuHon = at.filter((a) => now - a > 24 * 3_600_000).length;
  assert.ok(trong24h >= 20, `chỉ ${trong24h} ảnh trong 24 giờ gần nhất — tầng "con" và "cha" quá thưa`);
  assert.ok(cuHon >= 25, `chỉ ${cuHon} ảnh cũ hơn 24 giờ — tầng "ông" không giữ được chiều sâu`);
});

// ── BẬT BỘ HẸN GIỜ KHÔNG BẰNG CÓ ĐƯỜNG LUI ────────────────────────────────
test('Bật tự chụp là chụp ngay một ảnh, không chờ hết chu kỳ đầu', async () => {
  // Tổ thanh tra bắt được lỗ này sau khi lỗ trước vừa vá xong: bộ hẹn giờ đã
  // chạy, nhật ký đã in "tự động mỗi 15 phút", mà TT01 vẫn báo CHẶN vì số ảnh
  // trên đĩa là 0. setInterval chỉ chạy lần đầu SAU một chu kỳ.
  //
  // Hai cảnh thật bị lỗ này ăn:
  //   · Ngay sau khi đổi mã và dựng lại máy chủ — đúng lúc dễ hỏng nhất — hệ
  //     không có gì để lui về suốt 15 phút.
  //   · Máy chủ nào dựng lại dày hơn chu kỳ (triển khai liên tục, tiến trình
  //     bị giám sát khởi động lại) thì bộ hẹn giờ KHÔNG BAO GIỜ tới lượt, số
  //     ảnh đứng yên ở 0 vĩnh viễn mà nhật ký vẫn báo đang tự chụp.
  const S = require('../src/security/snapshot');
  const cho = (ms) => new Promise((r) => setTimeout(r, ms));

  // Chưa có ảnh nào → bật là phải có ngay.
  const a = new S({
    dir: path.join(os.tmpdir(), `gfs-start-${Date.now()}`),
    collect: () => ({ x: 1 }), apply: () => ({}), intervalMs: 60 * 60_000,
  });
  a.snapshots = [];
  a.start();
  await cho(60);
  a.stop();
  assert.equal(a.snapshots.length, 1, 'bật tự chụp mà vẫn không có ảnh nào để lui về');
  assert.equal(a.snapshots[0].label, 'khoi-dong', 'ảnh đầu tiên phải ghi rõ là ảnh lúc khởi động');

  // Đã có ảnh mới trong chu kỳ → KHÔNG chụp thêm. Máy chủ dựng lại năm lần
  // trong một phút không được đẻ ra năm ảnh gần như giống hệt nhau.
  const b = new S({
    dir: path.join(os.tmpdir(), `gfs-start2-${Date.now()}`),
    collect: () => ({ x: 1 }), apply: () => ({}), intervalMs: 60 * 60_000,
  });
  b.snapshots = [{ id: 'S0', version: 'v1', at: Date.now() - 60_000, auto: true }];
  b.start();
  await cho(60);
  b.stop();
  assert.equal(b.snapshots.length, 1, 'ảnh mới nhất mới 1 phút tuổi mà vẫn chụp thêm — mỗi lần dựng lại là một ảnh thừa');
});
