'use strict';
/** Hiển thị công thức: đúng, an toàn, không phụ thuộc thư viện ngoài. */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const TeX = require('../ui/tex.js');
const ItemBank = require('../src/content/item-bank');
const ItemGenerator = require('../src/content/generator');
const BankSeeder = require('../src/content/seeder');

test('phân số, căn, mũ, chỉ số dựng đúng cấu trúc', () => {
  const frac = TeX.render('\\dfrac{a}{b}');
  assert.match(frac, /tex-frac/);
  assert.match(frac, /tex-num.*a.*tex-den.*b/s);

  const root = TeX.render('\\sqrt{x+1}');
  assert.match(root, /tex-radical/);
  assert.match(root, /tex-radicand/);

  const nth = TeX.render('\\sqrt[3]{27}');
  assert.match(nth, /tex-rootidx">3</);

  assert.match(TeX.render('x^{2}'), /<sup class="tex-script">2<\/sup>/);
  assert.match(TeX.render('x_{1}'), /<sub class="tex-script">1<\/sub>/);
});

test('phân số lồng nhau dựng đủ tầng', () => {
  const html = TeX.render('\\dfrac{\\dfrac{1}{2}}{3}');
  assert.equal((html.match(/tex-frac/g) || []).length, 2);
});

test('ký hiệu toán đổi sang chữ Unicode đúng', () => {
  const pairs = [['\\le', '≤'], ['\\ge', '≥'], ['\\ne', '≠'], ['\\pm', '±'], ['\\cdot', '·'],
    ['\\Delta', 'Δ'], ['\\infty', '∞'], ['\\in', '∈'], ['\\Rightarrow', '⇒'], ['\\pi', 'π']];
  for (const [cmd, sym] of pairs) assert.ok(TeX.render(cmd).includes(sym), `${cmd} → ${sym}`);
  assert.match(TeX.render('\\mathbb{R}'), /ℝ/);
  assert.match(TeX.render('\\mathbb{N}'), /ℕ/);
});

test('hệ phương trình dựng thành nhiều dòng có dấu ngoặc nhọn', () => {
  const html = TeX.render('\\begin{cases} x + y = 3 \\\\ x - y = 1 \\end{cases}');
  assert.match(html, /tex-cases/);
  assert.equal((html.match(/tex-row/g) || []).length, 3, 'hai dòng phương trình');
});

test('văn bản lẫn công thức: phần ngoài giữ nguyên, phần trong dựng lại', () => {
  const html = TeX.renderText('Giải phương trình $x^{2} = 4$ rồi kết luận.');
  assert.match(html, /^Giải phương trình /);
  assert.match(html, /tex-inline/);
  assert.match(html, /rồi kết luận\.$/);
});

test('công thức khối $$…$$ hiển thị riêng một dòng', () => {
  const html = TeX.renderText('Công thức: $$\\dfrac{a}{b}$$');
  assert.match(html, /tex-display/);
});

// Thẻ duy nhất mà bộ dựng được phép sinh ra. Mọi thẻ khác trong kết quả
// nghĩa là đầu vào đã chui được vào trang dưới dạng mã.
const ALLOWED_TAGS = new Set(['span', '/span', 'sup', '/sup', 'sub', '/sub', 'br']);

function foreignTags(html) {
  return [...html.matchAll(/<\/?([a-zA-Z][a-zA-Z0-9]*)/g)]
    .map((m) => (m[0][1] === '/' ? `/${m[1]}` : m[1]))
    .filter((t) => !ALLOWED_TAGS.has(t));
}

test('đề bài là DỮ LIỆU, không chèn được thẻ vào trang', () => {
  const evil = [
    '<script>alert(1)</script>',
    '<img src=x onerror=alert(1)>',
    '$x < y$ <b>đậm</b>',
    '$\\text{<script>xss</script>}$',
    '<svg/onload=alert(1)>',
    '$\\dfrac{<iframe src=//evil>}{2}$',
    "'; DROP TABLE items; --",
  ];
  for (const e of evil) {
    const html = TeX.renderText(e);
    assert.deepEqual(foreignTags(html), [], `lọt thẻ lạ: ${e} → ${html}`);
    // Dấu < của người dùng phải thành &lt;, nghĩa là nó hiện ra như chữ chứ không chạy.
    if (e.includes('<')) assert.ok(html.includes('&lt;'), `chưa thoát dấu <: ${e}`);
  }
});

test('lệnh chưa hỗ trợ hiện nguyên văn để người soạn sửa, không nuốt mất', () => {
  const html = TeX.render('\\chualenhnay{x}');
  assert.match(html, /tex-unknown/);
  assert.match(html, /chualenhnay/);
});

test('dấu $ lẻ không làm vỡ cả đoạn', () => {
  const html = TeX.renderText('Giá 100$ và $x=1$');
  assert.ok(html.length > 0);
  assert.ok(!html.includes('undefined'));
});

test('toàn bộ kho học liệu dựng được, không còn lệnh lạ, không lọt thẻ', () => {
  const bank = new ItemBank();
  new BankSeeder({ bank, generator: new ItemGenerator({ bank }) }).seed({ perBlueprintLevel: 2 });
  const items = [...bank.items.values()];
  assert.ok(items.length >= 40);

  let unknown = 0;
  for (const it of items) {
    const html = [it.stem, ...it.solutionSteps, ...it.hints, it.answer].map((t) => TeX.renderText(String(t))).join('');
    if (html.includes('tex-unknown')) unknown++;
    assert.deepEqual(foreignTags(html), [], `${it.id} sinh ra thẻ lạ`);
  }
  assert.equal(unknown, 0, `${unknown} bài dùng lệnh LaTeX mà bộ dựng chưa hỗ trợ`);
});

test('giao diện nạp bộ dựng và không nhúng mã từ ngoài', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'ui', 'index.html'), 'utf8');
  assert.match(html, /src="\/ui\/tex\.js"/);
  assert.ok(!/src\s*=\s*["']https?:/i.test(html), 'không được nhúng mã từ CDN ngoài');
  const css = fs.readFileSync(path.join(__dirname, '..', 'ui', 'styles.css'), 'utf8');
  for (const cls of ['tex-frac', 'tex-root', 'tex-cases', 'tex-script']) {
    assert.ok(css.includes(cls), `thiếu kiểu cho .${cls}`);
  }
});

test('không bài nào để lọt lệnh LaTeX ra ngoài chế độ toán', () => {
  // Dấu $ lệch nhau một cái là học viên nhìn thấy nguyên chuỗi "90^{\\circ}"
  // trên màn hình. Lỗi này không làm chương trình đổ nên không có phép thử thì
  // không ai phát hiện, cho tới khi phụ huynh nhìn thấy.
  const { BLUEPRINTS } = require('../src/content/blueprint');
  const hong = [];
  for (const b of BLUEPRINTS) {
    let n = 0;
    for (const p of b.space()) {
      if (++n > 20) break;
      const it = b.render(p);
      for (const t of [it.stem, ...(it.solutionSteps || []), ...(it.hints || [])]) {
        const s = String(t);
        if (((s.match(/\$/g) || []).length) % 2 !== 0) { hong.push(`${b.id}: lẻ dấu $ — ${s.slice(0, 70)}`); n = 1e9; break; }
        if (/\\[a-zA-Z]/.test(s.replace(/\$[^$]*\$/g, ''))) { hong.push(`${b.id}: lệnh LaTeX ngoài $…$ — ${s.slice(0, 70)}`); n = 1e9; break; }
      }
    }
  }
  assert.deepEqual(hong.slice(0, 5), [], `${hong.length} bản thiết kế để lọt LaTeX`);
});

test('đáp án chỉ có lệnh LaTeX mà không có dấu $ vẫn dựng thành công thức', () => {
  const html = TeX.renderText('\\dfrac{5}{6}');
  assert.match(html, /tex-frac/);
  assert.ok(!html.includes('dfrac'), 'không được hiện nguyên chữ lệnh');
  // Chuỗi thường không có lệnh nào thì vẫn là chữ thường, không bị bọc thành công thức.
  assert.ok(!TeX.renderText('5 cm').includes('tex-inline'));
});
