'use strict';
/** Tài khoản 5 vai, phân quyền có phạm vi, và tổ chức trường–lớp–nhóm. */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { Database } = require('../src/data/repository');
const AccountService = require('../src/security/accounts');
const Organization = require('../src/school/organization');
const { passwordCheck, ROLES } = AccountService;

let db, acc, org, U = {}, C = {};

const PW = { ADMIN: 'Qu4n-Tri#Nexus2026', TEACHER: 'Gi4oVien#2026', PARENT: 'PhuHuynh#2026a', LEARNER: 'HocVien#2026a' };

before(() => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-acc-'));
  db = new Database({ dir });
  const users = db.collection('users', { indexes: ['role', 'username'] });
  const learners = db.collection('learners', { indexes: ['classId'] });
  const classes = db.collection('classes', { indexes: ['teacherId'] });
  const schools = db.collection('schools');
  acc = new AccountService({ users, learners, classes });
  org = new Organization({ schools, classes, learners, users });

  for (const role of ['ADMIN', 'TEACHER', 'PARENT', 'LEARNER']) {
    const r = acc.create({ username: role.toLowerCase() + '1', password: PW[role], role, fullName: ROLES[role].name });
    assert.equal(r.ok, true, `${role}: ${JSON.stringify(r)}`);
    U[role] = r.user.id;
  }
  // Giáo viên thứ hai, để kiểm tra cách ly phạm vi.
  U.TEACHER2 = acc.create({ username: 'teacher2', password: PW.TEACHER, role: 'TEACHER' }).user.id;

  org.createSchool({ id: 'SCH-001', name: 'GITAmath Hà Nội' });
  C.A = org.createClass({ id: 'CL-9A', name: '9A', grade: 9, schoolId: 'SCH-001', teacherId: U.TEACHER }).class.id;
  C.B = org.createClass({ id: 'CL-9B', name: '9B', grade: 9, schoolId: 'SCH-001', teacherId: U.TEACHER2 }).class.id;

  for (let i = 1; i <= 12; i++) {
    learners.put({ id: `HV${i}`, fullName: `Học viên ${i}`, grade: 9, level: i % 4 });
  }
  for (let i = 1; i <= 8; i++) org.enroll(C.A, `HV${i}`);
  for (let i = 9; i <= 12; i++) org.enroll(C.B, `HV${i}`);
  acc.linkLearner(U.PARENT, 'HV1');
  db.collection('learners').patch('HV3', { userId: U.LEARNER });
});

after(() => db.close());

// ── Mật khẩu ────────────────────────────────────────────────────────────────

test('mật khẩu: vai càng cao yêu cầu càng ngặt', () => {
  assert.equal(passwordCheck('abc12345', 'LEARNER').ok, true);
  assert.equal(passwordCheck('abc12345', 'ADMIN').ok, false, 'admin không được dùng mật khẩu học viên');
  assert.equal(passwordCheck('gitamath2026A!', 'TEACHER').ok, false, 'chứa "gita" phải bị chặn');
  assert.equal(passwordCheck('aaaaaaaaaaaa', 'LEARNER').ok, false);
  assert.equal(passwordCheck('Qu4n-Tri#Nexus2026', 'ADMIN').ok, true);
});

test('tạo tài khoản: chặn tên trùng, tên bậy, mật khẩu yếu', () => {
  assert.equal(acc.create({ username: 'admin1', password: PW.ADMIN, role: 'ADMIN' }).error, 'USERNAME_TAKEN');
  assert.equal(acc.create({ username: 'a b', password: PW.ADMIN, role: 'ADMIN' }).error, 'INVALID_USERNAME');
  assert.equal(acc.create({ username: 'moi1', password: '123', role: 'ADMIN' }).error, 'WEAK_PASSWORD');
  assert.equal(acc.create({ username: 'moi2', password: PW.ADMIN, role: 'KHONG_CO' }).error, 'INVALID_ROLE');
});

test('băm mật khẩu không bao giờ lọt ra ngoài', () => {
  const u = acc.get(U.ADMIN);
  assert.equal(u.passwordHash, undefined);
  const list = acc.list({ role: 'ADMIN' });
  for (const x of list.items) assert.equal(x.passwordHash, undefined);
  assert.equal(JSON.stringify(acc.login({ username: 'admin1', password: PW.ADMIN })).includes('scrypt$'), false);
});

// ── Đăng nhập ───────────────────────────────────────────────────────────────

test('đăng nhập đúng cấp phiên, sai thì đếm và khoá', () => {
  const ok = acc.login({ username: 'teacher1', password: PW.TEACHER, ip: '10.0.0.1' });
  assert.equal(ok.ok, true);
  assert.ok(ok.token.length >= 32);
  assert.equal(ok.user.role, 'TEACHER');
  assert.ok(acc.session(ok.token));

  const r = acc.create({ username: 'thubeo', password: PW.LEARNER, role: 'LEARNER' });
  assert.equal(r.ok, true);
  for (let i = 0; i < 5; i++) assert.equal(acc.login({ username: 'thubeo', password: 'sai-be-bet' }).error, 'INVALID_CREDENTIALS');
  const locked = acc.login({ username: 'thubeo', password: PW.LEARNER });
  assert.equal(locked.error, 'LOCKED_OUT', 'đúng mật khẩu nhưng đang bị khoá thì vẫn phải từ chối');
  assert.ok(locked.remainMin >= 1);
});

test('đăng xuất huỷ phiên ngay', () => {
  const s = acc.login({ username: 'admin1', password: PW.ADMIN });
  assert.equal(acc.logout(s.token).ok, true);
  assert.equal(acc.session(s.token), null);
  assert.equal(acc.authorize(s.token, 'user.read').error, 'INVALID_SESSION');
});

test('khoá tài khoản thì mọi phiên đang mở bị cắt', () => {
  const r = acc.create({ username: 'sebikhoa', password: PW.TEACHER, role: 'TEACHER' });
  const s = acc.login({ username: 'sebikhoa', password: PW.TEACHER });
  assert.ok(acc.session(s.token));
  acc.setActive(r.user.id, false);
  assert.equal(acc.session(s.token), null);
  assert.equal(acc.login({ username: 'sebikhoa', password: PW.TEACHER }).error, 'ACCOUNT_DISABLED');
});

test('đổi mật khẩu: cần mật khẩu cũ, không cho dùng lại, cắt hết phiên', () => {
  const r = acc.create({ username: 'doimk', password: PW.TEACHER, role: 'TEACHER' });
  const s = acc.login({ username: 'doimk', password: PW.TEACHER });
  assert.equal(acc.changePassword(r.user.id, 'sai', 'M4tKhau#Moi2026').error, 'INVALID_CREDENTIALS');
  assert.equal(acc.changePassword(r.user.id, PW.TEACHER, PW.TEACHER).error, 'PASSWORD_REUSED');
  assert.equal(acc.changePassword(r.user.id, PW.TEACHER, 'yeu').error, 'WEAK_PASSWORD');
  assert.equal(acc.changePassword(r.user.id, PW.TEACHER, 'M4tKhau#Moi2026').ok, true);
  assert.equal(acc.session(s.token), null, 'đổi mật khẩu phải cắt phiên cũ');
  assert.equal(acc.login({ username: 'doimk', password: 'M4tKhau#Moi2026' }).ok, true);
});

test('quản trị đặt lại mật khẩu: sinh mật khẩu tạm, buộc đổi', () => {
  const r = acc.create({ username: 'quenmk', password: PW.LEARNER, role: 'LEARNER' });
  const reset = acc.resetPassword(r.user.id, U.ADMIN);
  assert.equal(reset.ok, true);
  const s = acc.login({ username: 'quenmk', password: reset.temporaryPassword });
  assert.equal(s.ok, true);
  assert.equal(s.mustChangePassword, true);
});

// ── Phân quyền có phạm vi ───────────────────────────────────────────────────

test('quản trị làm được mọi việc trong phạm vi hệ thống', () => {
  const s = acc.login({ username: 'admin1', password: PW.ADMIN });
  for (const p of ['user.create', 'class.create', 'learner.read', 'item.create', 'report.read']) {
    assert.equal(acc.authorize(s.token, p).ok, true, p);
  }
});

test('giáo viên chỉ chạm được lớp mình dạy', () => {
  const s = acc.login({ username: 'teacher1', password: PW.TEACHER });
  assert.equal(acc.authorize(s.token, 'class.read', { classId: 'CL-9A' }).ok, true);
  const deny = acc.authorize(s.token, 'class.read', { classId: 'CL-9B' });
  assert.equal(deny.ok, false);
  assert.equal(deny.error, 'OUT_OF_SCOPE');
  assert.equal(acc.authorize(s.token, 'learner.read', { learnerId: 'HV1' }).ok, true);
  assert.equal(acc.authorize(s.token, 'learner.read', { learnerId: 'HV10' }).error, 'OUT_OF_SCOPE');
  assert.equal(acc.authorize(s.token, 'user.create').error, 'PERMISSION_DENIED');
});

test('phụ huynh chỉ xem đúng con mình, không xem cả lớp', () => {
  const s = acc.login({ username: 'parent1', password: PW.PARENT });
  assert.equal(acc.authorize(s.token, 'learner.read', { learnerId: 'HV1' }).ok, true);
  assert.equal(acc.authorize(s.token, 'learner.read', { learnerId: 'HV2' }).error, 'OUT_OF_SCOPE');
  assert.equal(acc.authorize(s.token, 'class.read', { classId: 'CL-9A' }).error, 'PERMISSION_DENIED');
  assert.equal(acc.authorize(s.token, 'learner.update', { learnerId: 'HV1' }).error, 'PERMISSION_DENIED');
});

test('học viên chỉ chạm hồ sơ của chính mình', () => {
  const s = acc.login({ username: 'learner1', password: PW.LEARNER });
  assert.equal(acc.authorize(s.token, 'learner.read', { learnerId: 'HV3' }).ok, true, 'HV3 gắn với tài khoản này');
  assert.equal(acc.authorize(s.token, 'learner.read', { learnerId: 'HV4' }).error, 'OUT_OF_SCOPE');
  assert.equal(acc.authorize(s.token, 'practice.start', { learnerId: 'HV3' }).ok, true);
  assert.equal(acc.authorize(s.token, 'item.create').error, 'PERMISSION_DENIED');
  assert.equal(acc.authorize(s.token, 'report.read', { learnerId: 'HV4' }).error, 'OUT_OF_SCOPE');
});

test('phạm vi giáo viên tự cập nhật khi được phân công lớp mới', () => {
  const s = acc.login({ username: 'teacher1', password: PW.TEACHER });
  assert.equal(acc.authorize(s.token, 'class.read', { classId: 'CL-9B' }).ok, false);
  org.assignTeacher('CL-9B', U.TEACHER, U.ADMIN);
  assert.equal(acc.authorize(s.token, 'class.read', { classId: 'CL-9B' }).ok, true);
  org.assignTeacher('CL-9B', U.TEACHER2, U.ADMIN); // trả lại
});

test('gắn học viên sai vai thì từ chối', () => {
  assert.equal(acc.linkLearner(U.TEACHER, 'HV1').error, 'WRONG_ROLE');
  assert.equal(acc.linkLearner(U.PARENT, 'KHONG-CO').error, 'LEARNER_NOT_FOUND');
});

// ── Tổ chức trường – lớp – nhóm ─────────────────────────────────────────────

test('tạo lớp: chặn lớp sai, năm học sai, giáo viên sai vai', () => {
  assert.equal(org.createClass({ name: 'X', grade: 13 }).error, 'INVALID_GRADE');
  assert.equal(org.createClass({ name: 'X', grade: 9, schoolYear: '2026' }).error, 'INVALID_SCHOOL_YEAR');
  assert.equal(org.createClass({ name: 'X', grade: 9, teacherId: U.PARENT }).error, 'WRONG_ROLE');
  assert.equal(org.createClass({ name: 'X', grade: 9, schoolId: 'KHONG-CO' }).error, 'SCHOOL_NOT_FOUND');
});

test('lớp đầy thì không nhận thêm', () => {
  const c = org.createClass({ id: 'CL-NHO', name: 'Lớp nhỏ', grade: 6, capacity: 2 }).class.id;
  const l = db.collection('learners');
  l.put({ id: 'HVA', fullName: 'A', grade: 6 });
  l.put({ id: 'HVB', fullName: 'B', grade: 6 });
  l.put({ id: 'HVC', fullName: 'C', grade: 6 });
  assert.equal(org.enroll(c, 'HVA').ok, true);
  assert.equal(org.enroll(c, 'HVB').ok, true);
  assert.equal(org.enroll(c, 'HVC').error, 'CLASS_FULL');
  assert.equal(org.enroll(c, 'HVA').error, 'ALREADY_ENROLLED');
});

test('chuyển lớp: rời lớp cũ, vào lớp mới, có ghi lịch sử hai đầu', () => {
  assert.equal(org.getClass('CL-9A').size, 8);
  const r = org.enroll('CL-9B', 'HV1', 'admin', 'phụ huynh xin chuyển');
  assert.equal(r.ok, true);
  assert.equal(r.transferredFrom, 'CL-9A');
  assert.equal(org.getClass('CL-9A').size, 7);
  assert.equal(org.getClass('CL-9B').size, 5);
  assert.equal(db.collection('learners').get('HV1').classId, 'CL-9B');

  const outHist = org.getClass('CL-9A').history.filter((h) => h.action === 'transfer_out');
  const inHist = org.getClass('CL-9B').history.filter((h) => h.action === 'transfer_in');
  assert.equal(outHist.at(-1).learnerId, 'HV1');
  assert.equal(inHist.at(-1).reason, 'phụ huynh xin chuyển');

  org.enroll('CL-9A', 'HV1'); // trả về chỗ cũ
});

test('danh sách lớp sắp theo tên, có tên giáo viên và phổ tầng', () => {
  const r = org.roster('CL-9A');
  assert.equal(r.ok, true);
  assert.equal(r.size, 8);
  const names = r.items.map((x) => x.fullName);
  assert.deepEqual(names, [...names].sort((a, b) => a.localeCompare(b, 'vi')));
  const c = org.getClass('CL-9A');
  assert.equal(c.teacherName, 'Giáo viên');
  assert.ok(c.levelSpread.max >= c.levelSpread.min);
});

test('chia nhóm theo tầng — cùng tầng vào cùng nhóm, tất định', () => {
  const a = org.autoGroupByLevel('CL-9A', { maxPerGroup: 3 });
  assert.equal(a.ok, true);
  const b = org.autoGroupByLevel('CL-9A', { maxPerGroup: 3 });
  assert.deepEqual(a.groups, b.groups, 'chạy hai lần phải ra cùng một cách chia');

  const cls = org.getClass('CL-9A');
  for (const g of cls.groups) {
    const levels = new Set(g.learnerIds.map((id) => db.collection('learners').get(id).level));
    assert.equal(levels.size, 1, `nhóm ${g.id} lẫn nhiều tầng: ${[...levels]}`);
    assert.ok(g.learnerIds.length <= 3);
  }
  assert.equal(cls.groups.reduce((n, g) => n + g.learnerIds.length, 0), 8);
});

test('nhóm không nhận học viên ngoài lớp', () => {
  const r = org.createGroup('CL-9A', { name: 'Nhóm lạ', learnerIds: ['HV10'] });
  assert.equal(r.error, 'LEARNER_NOT_IN_CLASS');
});

test('rời lớp thì cũng rời mọi nhóm trong lớp đó', () => {
  org.autoGroupByLevel('CL-9A', { maxPerGroup: 3 });
  assert.ok(org.getClass('CL-9A').groups.some((g) => g.learnerIds.includes('HV2')));
  org.remove('CL-9A', 'HV2', 'admin', 'nghỉ học');
  assert.ok(!org.getClass('CL-9A').groups.some((g) => g.learnerIds.includes('HV2')));
  assert.equal(db.collection('learners').get('HV2').classId, null);
  org.enroll('CL-9A', 'HV2');
});
