'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');

const h = require('../src/curriculum/hierarchy');
const st = require('../src/curriculum/standards');
const notation = require('../src/content/notation');
const quality = require('../src/content/quality');
const { DedupeIndex, simhash, hamming } = require('../src/content/dedupe');
const ItemBank = require('../src/content/item-bank');

// ══════════════════ PHÂN CẤP ══════════════════
test('hệ phân cấp hợp lệ: 5 tầng phân loại, không trùng mã, không chu trình', () => {
  const c = h.validateHierarchy();
  assert.equal(c.ok, true, c.errors.join(' | '));
  assert.equal(c.levels, 10);
  assert.ok(c.forms >= 30);
  assert.equal(Object.keys(h.BLOCKS).length, 5);
  assert.equal(h.DIFFICULTY.length, 5);
});

test('mã dạng là duy nhất và đúng quy ước MÔN.LỚP.CHỦĐỀ.DẠNG', () => {
  const codes = h.FORMS.map((f) => f.code);
  assert.equal(new Set(codes).size, codes.length);
  for (const f of h.FORMS) {
    assert.match(f.code, /^(M\d{1,2}|E|X)\./, f.code);
    assert.ok(f.traps.length >= 1, `${f.code} phải nêu bẫy`);
    assert.ok(f.norm > 0, `${f.code} phải có thời gian chuẩn`);
  }
});

test('tiền đề: thứ tự học tô-pô, không có chu trình', () => {
  const { order, cycles } = h.learningOrder();
  assert.equal(cycles.length, 0);
  assert.equal(order.length, h.FORMS.length);
  // Tiền đề phải xuất hiện trước
  const pos = new Map(order.map((c, i) => [c, i]));
  for (const f of h.FORMS) {
    for (const p of f.prereq) assert.ok(pos.get(p) < pos.get(f.code), `${p} phải học trước ${f.code}`);
  }
});

test('mọi tầng đều có dạng, lọc theo tầng và môn hoạt động', () => {
  for (const lv of h.LEVELS) assert.ok(h.formsForLevel(lv.id).length > 0, `tầng ${lv.code}`);
  assert.ok(h.formsForLevel(5, { subject: 'math' }).every((f) => f.code[0] === 'M'));
  assert.equal(h.gradeOf('M9.PT2.VIET'), 9);
  assert.equal(h.blockOfGrade(9), 'THCS');
  assert.equal(h.blockOfGrade(11), 'THPT');
});

// ══════════════════ CHUẨN TẦNG KHẮT KHE ══════════════════
test('chuẩn tầng siết dần và có đủ 7 tiêu chí', () => {
  const c = st.validateStandards();
  assert.equal(c.ok, true, c.errors.join(' | '));
  assert.equal(st.CRITERIA.length, 7);
  assert.equal(st.LEVEL_STANDARDS.length, 10);
  assert.ok(st.standardFor(9).mastery > st.standardFor(0).mastery);
  assert.ok(st.standardFor(9).speedFactor < st.standardFor(0).speedFactor);
});

test('thiếu một tiêu chí là KHÔNG được lên tầng', () => {
  const forms = h.formsForLevel(0).map((f) => f.code);
  const std = st.standardFor(0);
  const masteryByForm = Object.fromEntries(forms.map((c) => [c, 0.99]));
  const attempts = [];
  for (let i = 0; i < std.window; i++) {
    attempts.push({ formCode: forms[i % forms.length], correct: true, ms: 1000, at: Date.now() });
  }
  const full = {
    masteryByForm, attempts,
    sessionsPassed: std.consistency,
    exitExamScore: std.exitExam,
    lowerLevelStatus: [],
  };
  assert.equal(st.evaluate(0, full).ok, true, JSON.stringify(st.evaluate(0, full).failed));

  // Bỏ bài thi chốt tầng → trượt
  const noExam = st.evaluate(0, { ...full, exitExamScore: 0 });
  assert.equal(noExam.ok, false);
  assert.deepEqual(noExam.failed, ['exitExam']);

  // Chưa đủ số phiên liên tiếp → trượt
  const noStreak = st.evaluate(0, { ...full, sessionsPassed: 0 });
  assert.equal(noStreak.ok, false);
  assert.ok(noStreak.failed.includes('consistency'));

  // Tụt tầng dưới → trượt
  const regressed = st.evaluate(1, { ...full, lowerLevelStatus: [{ level: 0, meets: false }] });
  assert.ok(regressed.failed.includes('noRegression'));
});

test('cửa sổ mẫu chưa đủ thì không được tính là đạt', () => {
  const forms = h.formsForLevel(0).map((f) => f.code);
  const std = st.standardFor(0);
  const r = st.evaluate(0, {
    masteryByForm: Object.fromEntries(forms.map((c) => [c, 0.99])),
    attempts: [{ formCode: forms[0], correct: true, ms: 1000, at: Date.now() }], // chỉ 1 bài
    sessionsPassed: 9, exitExamScore: 1, lowerLevelStatus: [],
  });
  assert.equal(r.criteria.accuracy.pass, false);
  assert.ok(r.criteria.accuracy.samples < std.window);
});

test('khoảng cách tới chuẩn sinh được việc cần làm', () => {
  const g = st.gaps(3, { masteryByForm: {}, attempts: [], sessionsPassed: 0, exitExamScore: 0, lowerLevelStatus: [] });
  assert.ok(g.gaps.length > 0);
  for (const x of g.gaps) assert.ok(x.action && x.action.length > 5);
});

// ══════════════════ CHUẨN KÝ HIỆU (A02) ══════════════════
test('chuẩn hoá LaTeX: phân số, căn, số mũ, tập số', () => {
  assert.equal(notation.normalize('3/4'), '\\dfrac{3}{4}');
  assert.equal(notation.normalize('sqrt(x+1)'), '\\sqrt{x+1}');
  assert.equal(notation.normalize('x^2'), 'x^{2}');
  assert.ok(notation.normalize('x thuoc R').includes('\\mathbb{R}'));
  assert.ok(notation.normalize('a <= b').includes('\\le'));
});

test('kiểm ký hiệu: bắt lỗi thô, chấp nhận LaTeX chuẩn', () => {
  assert.equal(notation.validate('\\dfrac{3}{4} + \\sqrt{2}').ok, true);
  assert.equal(notation.validate('3/4').ok, false);
  assert.equal(notation.validate('sqrt(2)').ok, false);
  assert.equal(notation.validate('\\dfrac{1}{2').ok, false, 'ngoặc lệch');
  assert.equal(notation.validate('\\text{Tính 3/4 của số}').ok, true, 'trong \\text thì bỏ qua');
});

test('enforce: tự sửa rồi báo còn lỗi hay không', () => {
  const r = notation.enforce('Giai pt: x^2 - 5/2 = sqrt(9)');
  assert.equal(r.ok, true);
  assert.equal(r.changed, true);
  assert.ok(r.normalized.includes('\\dfrac{5}{2}'));
  assert.ok(r.normalized.includes('\\sqrt{9}'));
  assert.ok(r.normalized.includes('x^{2}'));
});

test('dạng chính tắc dùng để so trùng', () => {
  assert.equal(notation.canonical('\\dfrac{1}{2}'), notation.canonical('\\frac{1}{2}'));
  assert.equal(notation.canonical('x ^ 2'), notation.canonical('x^{2}'));
});

// ══════════════════ CHỐNG TRÙNG LẶP ══════════════════
test('SimHash: bài giống nhau cho khoảng cách nhỏ, khác nhau cho lớn', () => {
  const a = simhash('Giai phuong trinh bac hai 3x^2-5x+2=0');
  const b = simhash('Giai phuong trinh bac hai 3x^2-5x+3=0');
  const c = simhash('Chung minh tu giac ABCD noi tiep duong tron');
  assert.ok(hamming(a, b) < hamming(a, c));
});

test('chống trùng 3 tầng: y hệt, gần giống, và cùng khuôn đổi số', () => {
  const d = new DedupeIndex();
  const F = 'M9.PT2.GIAI';
  const s1 = 'Giải phương trình \\dfrac{3}{1}x^{2} - 5x + 2 = 0';

  assert.equal(d.check(F, s1).ok, true);
  d.add('IT-1', F, s1);

  // Tầng 1: y hệt
  assert.equal(d.check(F, s1).reason, 'EXACT_DUPLICATE');

  // Tầng 2: đổi một ký tự
  const s2 = 'Giải phương trình \\dfrac{3}{1}x^{2} - 5x + 3 = 0';
  const near = d.check(F, s2);
  assert.equal(near.reason, 'NEAR_DUPLICATE');
  // Với đề bài ngắn, Jaccard trên shingle bắt được trong khi SimHash có thể vượt ngưỡng.
  assert.ok(near.similarity >= 0.75, `similarity=${near.similarity} hamming=${near.distance}`);

  // Tầng 3: cùng khuôn, đổi số nhiều → sau khi đủ quota thì chặn
  const variants = [
    'Giải phương trình \\dfrac{71}{13}x^{2} - 402x + 917 = 0',
    'Giải phương trình \\dfrac{58}{27}x^{2} - 836x + 145 = 0',
    'Giải phương trình \\dfrac{93}{46}x^{2} - 271x + 638 = 0',
  ];
  let blocked = null;
  variants.forEach((v, i) => {
    const r = d.check(F, v);
    if (r.ok) d.add(`IT-v${i}`, F, v, r.fingerprint);
    else blocked = r;
  });
  assert.equal(blocked?.reason, 'TEMPLATE_OVERUSE', 'phải chặn khi quá quota cùng khuôn');
  assert.ok(blocked.detail.includes('máy móc'));
});

test('độ đa dạng khung bài đo được', () => {
  const d = new DedupeIndex();
  const F = 'M9.CAN.RUTGON';
  d.add('A', F, 'Rút gọn \\sqrt{12} + \\sqrt{27}');
  d.add('B', F, 'Chứng minh \\dfrac{a+b}{2} \\ge \\sqrt{ab} với a,b dương');
  const div = d.diversity(F);
  assert.equal(div.items, 2);
  assert.ok(div.diversity > 0);
});

// ══════════════════ CHẤT LƯỢNG 5★ ══════════════════
test('rubric 5★: đủ 5 chiều, correctness bắt buộc 5★', () => {
  assert.equal(quality.DIM_KEYS.length, 5);
  assert.equal(quality.DIMENSIONS.correctness.min, 5);
  const sum = quality.DIM_KEYS.reduce((s, k) => s + quality.DIMENSIONS[k].weight, 0);
  assert.equal(Math.round(sum * 100) / 100, 1);
});

test('cổng phát hành chặn bài correctness dưới 5★', () => {
  const item = {
    stem: '\\dfrac{1}{2} + \\dfrac{1}{3}',
    solutionSteps: ['Quy đồng mẫu', 'Cộng tử', 'Rút gọn'],
    hints: ['Tìm mẫu chung', 'MSC = 6', '3/6 + 2/6'],
    traps: ['quên quy đồng'], stars: 2,
  };
  const good = quality.score(item, { correctness: 5, notation: 5, pedagogy: 5, originality: 5, calibration: 5 });
  assert.equal(good.publishable, true);
  assert.equal(good.weighted, 5);

  const bad = quality.score(item, { correctness: 4, notation: 5, pedagogy: 5, originality: 5, calibration: 5 });
  assert.equal(bad.publishable, false);
  assert.ok(bad.blockers.some((b) => b.dimension === 'correctness'));
});

test('chấm tự động phát hiện ký hiệu sai và lời giải sơ sài', () => {
  const sloppy = { stem: 'Tinh 3/4 + 1/2', solutionSteps: [], hints: [], traps: [], stars: 3 };
  const a = quality.autoScore(sloppy);
  assert.ok(a.notation < 5, 'ký hiệu thô phải bị trừ');
  assert.equal(a.pedagogy, 1, 'không có bước giải');
});

// ══════════════════ KHO HỌC LIỆU ══════════════════
test('kho: nhận bản nháp, chặn trùng ngay tại cửa', () => {
  const bank = new ItemBank();
  const base = {
    formCode: 'M9.PT2.GIAI', level: 2, stars: 2,
    stem: 'Giải phương trình \\dfrac{3}{1}x^{2} - 5x + 2 = 0',
    solutionSteps: ['Tính \\Delta', 'Áp dụng công thức nghiệm', 'Kết luận'],
    hints: ['Dùng \\Delta', '\\Delta = b^{2}-4ac', '\\Delta = 1'],
    answer: 'x=1; x=\\dfrac{2}{3}', authorId: 'MTH-005',
  };
  const a = bank.draft(base);
  assert.equal(a.ok, true);
  assert.equal(a.item.status, 'DRAFT');

  const dup = bank.draft(base);
  assert.equal(dup.ok, false);
  assert.equal(dup.error, 'EXACT_DUPLICATE');
});

test('kho: chặn tầng ngoài khoảng cho phép của dạng', () => {
  const bank = new ItemBank();
  const r = bank.draft({ formCode: 'M9.PT2.GIAI', level: 9, stars: 3, stem: 'x', authorId: 'A' });
  assert.equal(r.error, 'LEVEL_OUT_OF_RANGE');
  assert.equal(bank.draft({ formCode: 'KHONG.CO', level: 1, stars: 1, stem: 'x', authorId: 'A' }).error, 'UNKNOWN_FORM');
});

test('kho: vòng đời DRAFT → VERIFIED → REVIEWED → PUBLISHED', () => {
  const bank = new ItemBank();
  const r = bank.draft({
    formCode: 'M9.CAN.DKXD', level: 3, stars: 2,
    stem: 'Tìm điều kiện xác định của \\sqrt{x-3}',
    solutionSteps: ['Biểu thức dưới căn không âm', 'x-3 \\ge 0', 'x \\ge 3'],
    hints: ['Căn bậc hai cần gì', 'Dưới căn \\ge 0', 'Giải bất phương trình'],
    answer: 'x \\ge 3', authorId: 'MTH-006',
  });
  const id = r.item.id;

  assert.equal(bank.publish(id, 'G').error, 'NOT_REVIEWED');
  bank.markVerified(id, { verifierId: 'MTH-007', answer: 'x \\ge 3', match: true }, 'MTH-007');
  assert.equal(bank.get(id).status, 'VERIFIED');

  const q = quality.score(bank.get(id), { correctness: 5, notation: 5, pedagogy: 5, originality: 4, calibration: 5 });
  bank.markReviewed(id, q, { criticId: 'MTH-010' }, 'MTH-010');
  assert.equal(bank.get(id).status, 'REVIEWED');

  assert.equal(bank.publish(id, 'MTH-020').ok, true);
  assert.equal(bank.get(id).status, 'PUBLISHED');
  assert.equal(bank.query({ formCode: 'M9.CAN.DKXD' }).length, 1);
});

test('kho: thẩm định chéo sai đáp án thì bị loại', () => {
  const bank = new ItemBank();
  const r = bank.draft({ formCode: 'M9.PT2.GIAI', level: 2, stars: 2, stem: 'Giải x^{2}=4', answer: 'x=2', authorId: 'A' });
  bank.markVerified(r.item.id, { verifierId: 'B', answer: 'x=\\pm 2', match: false }, 'B');
  assert.equal(bank.get(r.item.id).status, 'REJECTED');
  assert.equal(bank.get(r.item.id).rejectReason, 'VERIFICATION_MISMATCH');
});

test('kho: hiệu chỉnh độ khó bằng dữ liệu thật', () => {
  const bank = new ItemBank();
  const r = bank.draft({ formCode: 'M9.PT2.GIAI', level: 2, stars: 5, stem: 'Giải x^{2}=9', answer: 'x=\\pm 3', authorId: 'A' });
  const id = r.item.id;
  for (let i = 0; i < 40; i++) bank.recordAttempt(id, { correct: true, ms: 5000 }); // ai cũng làm được
  const it = bank.get(id);
  assert.equal(it.pValue, 1);
  assert.ok(it.suggestedStars <= 2, `đề gắn 5★ nhưng ai cũng làm được → phải hạ sao, got ${it.suggestedStars}`);
});

test('kho: báo cáo độ phủ chỉ ra ô còn thiếu bài', () => {
  const bank = new ItemBank();
  const cov = bank.coverage({ minPerCell: 3 });
  assert.equal(cov.publishedItems, 0);
  assert.ok(cov.gapCells > 0);
  assert.ok(cov.missingItems > 0);
  assert.ok(cov.topGaps[0].formCode);
});
