'use strict';
/**
 * AN TOÀN — BA CỔNG DỰNG SAU KHI SOI MỘT BẢN THIẾT KẾ 47 MÔ-ĐUN BẰNG MÁY
 *
 * Mỗi mục ở đây canh đúng một chỗ hỏng CÓ THẬT, tìm được bằng cách đếm và
 * đối chiếu chứ không bằng linh cảm. Ghi rõ chỗ hỏng gốc trong chú thích, vì
 * mục kiểm không nói vì sao nó tồn tại thì sớm muộn có người gỡ nó đi.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const CT = require('../src/an-toan/cong-tuoi');
const NM = require('../src/an-toan/nen-mong');
const KR = require('../src/an-toan/khoa-rieng');
const ST = require('../src/an-toan/soi-thiet-ke');

// ── CỔNG TUỔI ──────────────────────────────────────────────────────────────

test('Tính năng chưa khai mức tiếp xúc thì cổng tuổi TỪ CHỐI', () => {
  // Mặc định là ĐÓNG, cùng luật với bảng phân quyền API.
  const r = CT.choVao({ maTinhNang: 'MOT_TINH_NANG_AI_DO_VUA_THEM', tuoi: 30, cachBiet: 'TRUONG_XAC_NHAN' });
  assert.equal(r.ok, false);
  assert.ok(/chưa khai mức tiếp xúc/.test(r.lyDo));
  assert.ok(/ĐÓNG/.test(r.canGi), 'từ chối mà không nói rõ mặc định là đóng');
});

test('Chưa biết tuổi là một câu trả lời, và câu ấy là KHÔNG', () => {
  // Đúng với tính năng CHẠM NGƯỜI LẠ trở lên. Không có chỗ nào đoán tuổi từ
  // lớp học, cách viết, hay giọng nói.
  const r = CT.choVao({ maTinhNang: 'GHEP_BAN_HOC', coNguoiPhuTrach: true });
  assert.equal(r.ok, false);
  assert.ok(/Chưa biết tuổi/.test(r.lyDo));
  assert.ok(/KHÔNG được đoán tuổi/.test(r.canGi));
  // Tính năng không tiếp xúc ai thì không cần tuổi — cổng không cản vô cớ.
  assert.equal(CT.choVao({ maTinhNang: 'HOC_MOT_MINH' }).ok, true);
});

test('Mức TRONG NHÀ đòi NGƯỜI PHỤ TRÁCH, không đòi tuổi', () => {
  // Bản đầu của cổng đòi tuổi cho cả mức này, và hậu quả lộ ra trong lượt
  // thanh tra đầu tiên: KHÔNG luồng nào trong hệ thống gọi nổi cổng, vì hệ
  // thống chưa có trường tuổi. Một cái cổng không ai gọi được là cổng trang
  // trí — đúng thứ bệnh mà chính tầng này được viết ra để bắt ở nơi khác.
  //
  // Thứ bảo vệ đứa trẻ ở mức này KHÔNG phải con số tuổi, mà là một người lớn
  // xác định danh tính đứng cùng.
  const thieu = CT.choVao({ maTinhNang: 'KHAO_SAT' });
  assert.equal(thieu.ok, false);
  assert.ok(/người phụ trách/i.test(thieu.lyDo));
  assert.ok(/KHÔNG đòi tuổi/.test(thieu.canGi));
  const du = CT.choVao({ maTinhNang: 'KHAO_SAT', coNguoiPhuTrach: true });
  assert.equal(du.ok, true);
  assert.equal(du.dua, 'nguoi-phu-trach');
  // Nhưng người phụ trách KHÔNG mở được tính năng chạm người lạ.
  assert.equal(CT.choVao({ maTinhNang: 'GHEP_BAN_HOC', coNguoiPhuTrach: true }).ok, false);
});

test('Cổng tuổi được gọi từ luồng nghiệp vụ thật, không chỉ từ API của chính nó', () => {
  // Lượt thanh tra đầu tiên tìm ra cả cong-tuoi lẫn khoa-rieng chỉ được gọi
  // từ CHÍNH cổng API của chúng — không luồng nghiệp vụ nào đi qua.
  const goc = path.join(__dirname, '..');
  const nha = fs.readFileSync(path.join(goc, 'src/web/nha.js'), 'utf8');
  assert.ok(/require\([^)]*an-toan\/cong-tuoi['"]\)/.test(nha),
    'đường nộp khảo sát không gọi cổng tuổi');
  assert.ok(/maTinhNang:\s*'KHAO_SAT'/.test(nha), 'gọi cổng mà không nói tính năng nào');
  const cgm = fs.readFileSync(path.join(goc, 'src/web/chong-gia-mao.js'), 'utf8');
  assert.ok(/require\([^)]*an-toan\/khoa-rieng['"]\)/.test(cgm),
    'vé chống giả mạo vẫn dùng thẳng bí mật gốc thay vì khoá dẫn xuất');
  assert.ok(/khoaCho\('VE_BIEU_MAU'/.test(cgm), 'không dẫn xuất khoá theo nhãn việc');
});

test('Lời khai tuổi KHÔNG mở được tính năng chạm người lạ', () => {
  // Mở cổng bằng lời khai là mở cho bất kỳ ai khai bất kỳ tuổi nào.
  const khai = CT.choVao({ maTinhNang: 'GHEP_BAN_HOC', tuoi: 25, cachBiet: 'TU_KHAI' });
  assert.equal(khai.ok, false);
  assert.ok(/lời khai, không phải bằng chứng/.test(khai.lyDo));
  const giamHoKhai = CT.choVao({ maTinhNang: 'GHEP_BAN_HOC', tuoi: 25, cachBiet: 'NGUOI_GIAM_HO_KHAI' });
  assert.equal(giamHoKhai.ok, false, 'người giám hộ khai vẫn là lời khai');
  // Chỉ nguồn được đánh dấu laBangChung mới qua.
  assert.equal(CT.choVao({ maTinhNang: 'GHEP_BAN_HOC', tuoi: 25, cachBiet: 'TRUONG_XAC_NHAN' }).ok, true);
});

test('Trẻ em chạm người lạ phải có đồng ý CÓ TÊN, CÓ LÚC, CÓ ĐƯỜNG RÚT LẠI', () => {
  const nen = { maTinhNang: 'GHEP_BAN_HOC', tuoi: 14, cachBiet: 'TRUONG_XAC_NHAN' };
  assert.equal(CT.choVao(nen).ok, false, 'trẻ 14 tuổi ghép bạn học mà không cần đồng ý');
  // Một ô tích không tên không phải sự đồng ý; nó là một ô tích.
  assert.equal(CT.choVao({ ...nen, dongYGiamHo: { coTheRutLai: true } }).ok, false);
  assert.equal(CT.choVao({ ...nen, dongYGiamHo: { ten: 'A', quanHe: 'mẹ', luc: 1, coTheRutLai: true } }).ok, false,
    'tên một ký tự vẫn qua');
  assert.equal(CT.choVao({ ...nen, dongYGiamHo: { ten: 'Lê Thị Minh Hà', quanHe: 'mẹ', luc: Date.now() } }).ok, false,
    'thiếu đường rút lại mà vẫn qua');
  const du = CT.choVao({ ...nen, dongYGiamHo: { ten: 'Lê Thị Minh Hà', quanHe: 'mẹ', luc: Date.now(), coTheRutLai: true } });
  assert.equal(du.ok, true);
  assert.equal(du.laTreEm, true);
});

test('Chưa thành niên đưa nội dung ra công khai vẫn cần người giám hộ biết', () => {
  const v = { maTinhNang: 'NOI_DUNG_HOC_VIEN_DANG', tuoi: 17, cachBiet: 'TRUONG_XAC_NHAN' };
  assert.equal(CT.choVao(v).ok, false, '17 tuổi đăng công khai mà không ai biết');
  assert.equal(CT.choVao({ ...v, dongYGiamHo: { ten: 'Trần Quốc Bảo', quanHe: 'bố', luc: Date.now(), coTheRutLai: true } }).ok, true);
  // Từ 18 thì tự quyết.
  assert.equal(CT.choVao({ maTinhNang: 'NOI_DUNG_HOC_VIEN_DANG', tuoi: 18, cachBiet: 'TRUONG_XAC_NHAN' }).ok, true);
});

test('Tính năng chạm người lạ CHƯA DỰNG vẫn phải có cổng đứng sẵn', () => {
  // Cổng dựng trước, không dựng sau khi đã có một đứa trẻ đi qua.
  const chuaDung = CT.TINH_NANG.filter((t) => t.chuaDung);
  assert.ok(chuaDung.length >= 5, 'không khai sẵn tính năng rủi ro nào');
  for (const t of chuaDung) {
    assert.ok(CT.MUC_TIEP_XUC[t.mucTiepXuc], `${t.ma} khai mức tiếp xúc lạ`);
    const r = CT.choVao({ maTinhNang: t.ma, tuoi: 14, cachBiet: 'TU_KHAI' });
    if (CT.MUC_TIEP_XUC[t.mucTiepXuc].thu >= 2) {
      assert.equal(r.ok, false, `${t.ma} cho trẻ 14 tuổi qua bằng lời khai`);
    }
  }
});

test('Cổng tuổi KHÔNG tự nhận là đã tuân thủ pháp luật', () => {
  const b = CT.bang();
  assert.ok(/CHÍNH SÁCH/.test(b.canXacNhanPhapLy));
  assert.ok(/KHÔNG tự kết luận/.test(b.canXacNhanPhapLy));
  assert.equal(typeof b.nguongTreEm, 'number');
});

// ── SOI NỀN MÓNG ───────────────────────────────────────────────────────────

test('Mọi lời gọi mô-đun trong kho đều trỏ vào tệp có thật', () => {
  // Bệnh gốc: 7 mô-đun được gọi 163 chỗ mà không tệp nào định nghĩa — đúng
  // bảy thứ gánh an toàn. Đây là loại lỗi đọc từng tệp không bắt được.
  const s = NM.soiNenMong();
  assert.deepEqual(s.thieu, [], `mô-đun được gọi mà không tồn tại: ${JSON.stringify(s.thieu)}`);
  assert.ok(s.soTep > 100, 'bộ soi chỉ thấy vài tệp — đang soi nhầm chỗ');
  assert.ok(s.soRequireTuongDoi > 500);
});

test('Bộ soi đọc MÃ, không đọc văn trong chú thích', () => {
  // Bản quét đầu tiên báo ba mô-đun thiếu, cả ba nằm trong chính chú thích
  // của bộ soi. Một bộ soi tự báo động vì lời mình viết thì lần sau không ai
  // tin nó nữa.
  const ma = `
    /* require('./khong-co-that') trong khối chú thích */
    // require('./cung-khong-co-that') trong dòng chú thích
    const that = require('node:path');
  `;
  const sach = NM.boChuThich(ma);
  assert.ok(!sach.includes('khong-co-that'));
  assert.ok(!sach.includes('cung-khong-co-that'));
  assert.ok(sach.includes("require('node:path')"), 'bỏ nhầm cả mã thật');
});

test('Không có tệp cô độc trong src/', () => {
  // Mặt trái của bệnh trên: mã chết nằm lại, rồi có người đọc và tưởng nó
  // đang chạy.
  const c = NM.soiCoDoc();
  assert.deepEqual(c.coDoc, [], `tệp không ai gọi tới: ${c.coDoc.join(', ')}`);
});

// ── KHOÁ RIÊNG TỪNG VIỆC ───────────────────────────────────────────────────

test('Bí mật ngắn bị TỪ CHỐI, không được đệm cho đủ dài', () => {
  // Lỗi gốc: JWT_SECRET.slice(0,32).padEnd(32,'0') — đệm biến một lỗi cấu
  // hình thành một khoá yếu mà trông vẫn bình thường.
  const ngan = KR.kiemBiMatGoc('ngan-qua');
  assert.equal(ngan.ok, false);
  assert.ok(/CẤM đệm/.test(ngan.camLam));
  assert.throws(() => KR.khoaCho('VE_BIEU_MAU', 'ngan-qua'), /tối thiểu/);
});

test('Bí mật dài mà nghèo biến thiên cũng bị TỪ CHỐI', () => {
  // Một chuỗi 40 số không cũng dài 40. Phép đo độ dài cho qua, phép đếm ký
  // tự riêng thì không.
  const ngheo = KR.kiemBiMatGoc('0'.repeat(40));
  assert.equal(ngheo.ok, false);
  assert.ok(/biến thiên/.test(ngheo.lyDo));
});

test('Mỗi việc một khoá, và khoá việc này không suy ra khoá việc kia', () => {
  const goc = 'Vuon9Xanh-Khuon7Dao-MotChuoiNgauNhienDuDai-2026';
  const ma = Object.keys(KR.VIEC);
  const khoa = ma.map((m) => KR.khoaCho(m, goc).toString('hex'));
  assert.equal(new Set(khoa).size, ma.length, 'có hai việc ra cùng một khoá');
  // Dẫn xuất phải TẤT ĐỊNH, nếu không thì không giải mã lại được gì.
  assert.equal(KR.khoaCho(ma[0], goc).toString('hex'), khoa[0]);
  // Và khoá không được chứa nguyên đoạn của bí mật gốc — đó là dấu hiệu
  // đang CẮT chứ không DẪN XUẤT.
  for (const k of khoa) {
    assert.ok(!Buffer.from(k, 'hex').toString('latin1').includes(goc.slice(0, 8)));
  }
  assert.equal(KR.tuKiem(goc).ok, true);
});

test('Việc chưa khai thì không có khoá — cấm dùng ké', () => {
  const goc = 'Vuon9Xanh-Khuon7Dao-MotChuoiNgauNhienDuDai-2026';
  assert.throws(() => KR.khoaCho('VIEC_CHUA_KHAI', goc), /chưa khai trong bảng VIEC/);
  assert.throws(() => KR.khoaCho('VIEC_CHUA_KHAI', goc), /KHÔNG dùng ké/);
});

// ── BẢY CÂU HỎI ────────────────────────────────────────────────────────────

test('Bảy câu hỏi thiết kế đều nói rõ tìm ra từ đâu và vì sao không tự lộ', () => {
  // Mục kiểm không nói vì sao nó tồn tại thì sớm muộn có người gỡ nó đi.
  const b = ST.bang();
  assert.equal(b.soCauHoi, 7);
  for (const c of ST.CAU_HOI) {
    assert.ok(c.timRaTuDau && c.timRaTuDau.length > 60, `${c.ma} không nói tìm ra từ đâu`);
    assert.ok(c.viSaoKhongTuLo && c.viSaoKhongTuLo.length > 40, `${c.ma} không nói vì sao không tự lộ`);
    assert.ok(c.traLoiBang && c.traLoiBang.length > 10, `${c.ma} không nói trả lời bằng cách nào`);
  }
  assert.equal(new Set(ST.CAU_HOI.map((c) => c.ma)).size, 7);
});

test('Câu chưa trả lời KHÔNG mặc định là "không áp dụng"', () => {
  const r = ST.soi({ daTraLoi: ['SOI-NEN'] });
  assert.equal(r.daTraLoi, 1);
  assert.equal(r.chuaTraLoi.length, 6);
  assert.equal(r.ok, false);
  assert.ok(/không mặc định/i.test(r.nhac));
  assert.equal(ST.soi({ daTraLoi: ST.CAU_HOI.map((c) => c.ma) }).ok, true);
});

test('Tầng an toàn không lọt chữ của bảng phân loại nội bộ', () => {
  const tuong = require('../src/cay-tien/buc-tuong');
  const chu = JSON.stringify([CT.bang(), KR.bang(), ST.bang()]);
  const r = tuong.soiRoRi(chu);
  assert.equal(r.sach, true, JSON.stringify(r.roRi));
});

test('Bức tường không báo động nhầm khi cụm cấm cắt ngang thân từ', () => {
  // Chính mô-đun cổng tuổi làm lộ ra lỗi này: câu "Nhóm được bảo vệ chặt
  // nhất. Mọi tiếp xúc…" sau khi bỏ dấu thành "…chat nhat moi tiep xuc…",
  // trong đó có chuỗi con "hat moi" — đúng bằng tên một nhóm.
  //
  // Một bộ soi an ninh báo động nhầm không phải chuyện nhỏ: người trực gặp
  // vài lần là thôi đọc, và lần nó báo đúng thì cũng không ai nhìn.
  const tuong = require('../src/cay-tien/buc-tuong');
  assert.equal(tuong.soiRoRi('Nhóm được bảo vệ chặt nhất. Mọi tiếp xúc với người ngoài').sach, true,
    'vẫn báo nhầm khi cụm cấm cắt ngang thân từ');
  // Và siết ranh giới từ KHÔNG được làm lọt rò rỉ thật.
  for (const that of ['Nhà này thuộc nhóm hạt mới', 'bảng cây tiền của gia đình', 'xem module cay-tien']) {
    assert.equal(tuong.soiRoRi(that).sach, false, `lọt rò rỉ thật: ${that}`);
  }
  assert.equal(tuong.soiRoRi('Cây giá trị năm tầng').sach, true, 'bắt oan cây giá trị');
  assert.equal(tuong.viTriCum('chat nhat moi tiep xuc', 'hat moi'), -1);
  assert.ok(tuong.viTriCum('nhom hat moi', 'hat moi') >= 0);
});
