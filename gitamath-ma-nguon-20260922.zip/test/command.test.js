'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');

// Kho dữ liệu RIÊNG cho lần chạy này. Bộ kiểm mà ghi thẳng vào data/db thì nó
// vừa làm bẩn dữ liệu thật (tài khoản kiểm thử ở lại, cửa khởi tạo đóng luôn
// cho lần sau), vừa có quyền xoá và nén ảnh chụp của dữ liệu thật. Đặt biến
// môi trường TRƯỚC khi require('../src/index'), vì tầng dữ liệu đọc chúng ngay
// lúc nạp mô-đun.
const _tmpKho = require('node:fs').mkdtempSync(require('node:path').join(require('node:os').tmpdir(), 'gita-test-'));
process.env.DB_DIR = require('node:path').join(_tmpKho, 'db');
process.env.SNAPSHOT_DIR = require('node:path').join(_tmpKho, 'snap');

const { boot } = require('../src/index');
const { ShardLedger, PLAYBOOKS } = require('../src/command/mobilization');
const { STATE } = require('../src/command/handoff');
const { PHASES, STRATEGY_RULES } = require('../src/learner/cycle90');
const { ACTIONS } = require('../src/learner/telemetry');
const { taskTypeForDivision, DIVISION_TASK } = require('../src/agents/taxonomy');

let N;
before(async () => { N = await boot({ quiet: true }); });
after(async () => { await N.shutdown(); });

// ══════════════════ CHỐNG CHỒNG CHÉO ══════════════════
test('sổ giành mảnh: một mảnh chỉ thuộc về một agent', () => {
  const l = new ShardLedger();
  assert.equal(l.claim('S1', 'A').ok, true);
  const second = l.claim('S1', 'B');
  assert.equal(second.ok, false);
  assert.equal(second.owner, 'A');
  assert.equal(l.rejected, 1);
  assert.equal(l.owner('S1'), 'A');
});

test('ánh xạ khối → loại việc là toàn ánh, tránh vi phạm điều A13', () => {
  assert.equal(Object.keys(DIVISION_TASK).length, 6);
  for (const d of Object.keys(DIVISION_TASK)) assert.ok(taskTypeForDivision(d));
  assert.equal(taskTypeForDivision('MATH'), 'math_reasoning');
  assert.equal(taskTypeForDivision('KHONG-CO'), 'vietnamese');
});

// ══════════════════ TỔNG ĐỘNG VIÊN ══════════════════
test('6 kịch bản nhiệm vụ, mỗi kịch bản nêu rõ nhiệm vụ từng cấp bậc', () => {
  const pbs = N.mobilization.playbooks();
  assert.equal(pbs.length, 6);
  for (const p of pbs) {
    assert.equal(p.divisions.length, 6, `${p.id} phải huy động cả 6 khối`);
    assert.equal(Object.keys(p.rankDuties).length, 6, `${p.id} phải giao việc cho cả 6 cấp bậc`);
    for (const d of Object.values(p.rankDuties)) assert.ok(d.length > 10);
  }
});

test('lập kế hoạch huy động đủ 500 agent theo vai trò', () => {
  const p = N.mobilization.plan({ kind: 'CONTENT_PRODUCTION', objective: 'Biên soạn học liệu', scope: { count: 30 } });
  assert.equal(p.ok, true);
  assert.equal(p.agentsEngaged, 500);
  assert.equal(p.workersAvailable, 400);
  assert.equal(p.unitsPlanned, 30);
  // Mỗi dòng đội hình phải có nhiệm vụ cụ thể
  for (const r of p.roster) assert.ok(r.duty && r.duty.length > 10, `${r.division}/${r.rank}`);
  assert.equal(new Set(p.roster.map((r) => r.division)).size, 6);
  assert.equal(new Set(p.roster.map((r) => r.rank)).size, 6);
});

test('một lệnh → toàn đội vào việc, không chồng chéo, trải đều 6 khối', async () => {
  const r = await N.mobilization.execute({
    kind: 'CONTENT_PRODUCTION', objective: 'Rà soát và biên soạn học liệu',
    scope: { count: 60 }, maxConcurrent: 24, issuedBy: 'superadmin',
  });
  assert.equal(r.ok, true);
  assert.equal(r.agentsEngaged, 500);
  assert.equal(r.unitsDone, 60);
  assert.equal(r.unitsFailed, 0);
  assert.equal(r.noOverlap, true, 'không được có hai agent làm cùng một mảnh');
  assert.equal(r.uniqueShards, 60);
  assert.ok(r.overlapsPrevented > 0, 'sổ giành mảnh phải từ chối lần giành thứ hai');

  // Việc phải trải qua cả 6 khối, không dồn vào một khối
  assert.equal(r.byDivision.length, 6);
  for (const d of r.byDivision) assert.ok(d.ok > 0, `khối ${d.division} phải có việc`);

  // Đủ 6 giai đoạn
  const phases = r.phases.map((p) => p.phase);
  assert.deepEqual(phases, ['plan', 'shard', 'execute', 'review', 'guard', 'coach']);

  // Thanh tra chấm được, hộ pháp kiểm Hiến pháp
  assert.ok(r.criticScore > 0, 'phải có điểm nghiệm thu');
  assert.equal(r.batchesUnreviewed, 0, 'mọi lô đều phải được chấm');
  assert.equal(typeof r.constitutionViolations, 'number');
});

test('người nhận việc cạn hạn mức thì đồng đội CÙNG KHỐI nhận thay', async () => {
  // Dựng đúng tình huống đã từng làm một đợt huy động báo "xong 9/12": ba agent
  // đầu tiên bị vét sạch hạn mức token của phút trước khi nhiệm vụ bắt đầu.
  // Cửa sổ hạn mức dài 60 giây nên thử lại trong lòng nhiệm vụ là vô ích; thứ
  // cứu được mảnh việc là chuyển cho người khác cùng khối.
  const roster = N.mobilization.plan({ kind: 'QUALITY_AUDIT', objective: 'Thử hạn mức', scope: { count: 6 } });
  const worker = roster.roster.filter((x) => x.rank === 'WORKER');
  const nanNhan = worker.map((r) => r.agents[0]).filter(Boolean).slice(0, 3);
  for (const id of nanNhan) {
    const a = N.capacity.agents.get(id);
    assert.ok(a, `không tìm thấy agent ${id}`);
    N.capacity.tokenWindow.set(id, [{ t: Date.now(), n: a.capacity.tokensPerMin }]);
  }

  const r = await N.mobilization.execute({
    kind: 'QUALITY_AUDIT', objective: 'Thử hạn mức', scope: { count: 6 },
    maxConcurrent: 6, issuedBy: 'superadmin',
  });
  assert.equal(r.ok, true);
  assert.equal(r.unitsFailed, 0, `còn ${r.unitsFailed} mảnh chưa làm: ${JSON.stringify(r.chuaLam)}`);
  assert.ok(r.luotChuyenNguoi >= 1, 'phải có ít nhất một mảnh được chuyển cho người khác');

  // Chuyển người KHÔNG được chuyển sang khối khác — điều A13 buộc loại việc
  // khớp chuyên môn, nên đủ chỉ tiêu bằng cách đẩy bài toán sang khối ngôn ngữ
  // là vi phạm, không phải là thành tích.
  const m = N.mobilization.get(r.missionId);
  for (const x of m.results.filter((y) => y.nguoiNhanDau)) {
    const moi = N.agents.find((a) => a.id === x.agentId);
    const dau = N.agents.find((a) => a.id === x.nguoiNhanDau);
    assert.ok(moi && dau, 'phải tra được cả người nhận đầu lẫn người nhận thay');
    assert.equal(moi.division, dau.division, 'người thay phải cùng khối với người nhận đầu');
    assert.notEqual(moi.id, dau.id, 'người thay phải là người khác');
  }
});

test('không agent nào bị treo vì giao sai chuyên môn sau tổng động viên', () => {
  assert.equal(N.agents.filter((a) => a.state === 'SUSPENDED').length, 0);
  assert.equal(N.shield.fleetReadiness().readiness, 1);
});

test('nhiệm vụ được ghi vào nhật ký bất biến và tra cứu lại được', async () => {
  const r = await N.mobilization.execute({ kind: 'QUALITY_AUDIT', objective: 'Rà soát chất lượng', scope: { count: 12 }, maxConcurrent: 12 });
  const m = N.mobilization.get(r.missionId);
  assert.ok(m);
  assert.equal(m.state, 'COMPLETED');
  assert.equal(N.audit.verify().ok, true);
  const q = N.audit.query({ action: 'mission.completed', limit: 10 });
  assert.ok(q.items.length >= 1);
  assert.ok(N.mobilization.list({ limit: 5 }).length >= 1);
});

// ══════════════════ HỢP ĐỒNG GIAO VIỆC ══════════════════
test('hợp đồng thiếu điều khoản thì bị từ chối', () => {
  const r = N.handoff.offer({ fromAgentId: 'MTH-001', toAgentId: 'MTH-005', goal: 'làm gì đó' });
  assert.equal(r.ok, false);
  assert.equal(r.error, 'INCOMPLETE_CONTRACT');
  assert.deepEqual(r.need, ['goal', 'outputFormat', 'acceptance[]']);
});

test('chưa xác nhận hiểu thì không được thực thi', async () => {
  const o = N.handoff.offer({
    fromAgentId: 'MTH-001', toAgentId: 'MTH-006',
    goal: 'Soạn một bài tập về phương trình bậc hai',
    outputFormat: 'Văn bản bắt đầu bằng "KẾT QUẢ:"',
    acceptance: ['Đúng định dạng', 'Không bịa dữ liệu'],
  });
  assert.equal(o.ok, true);
  assert.equal(o.contract.state, STATE.OFFERED);
  const d = await N.handoff.deliver(o.contract.id);
  assert.equal(d.ok, false);
  assert.equal(d.error, 'NOT_ACKED');
});

test('vòng đời hợp đồng chạy đủ 5 bước và đo được mức hiểu', async () => {
  const r = await N.handoff.run({
    fromAgentId: 'MTH-001', toAgentId: 'MTH-007',
    goal: 'Tóm tắt cách giải phương trình bậc hai bằng công thức nghiệm',
    outputFormat: 'Văn bản bắt đầu bằng "KẾT QUẢ:"',
    acceptance: ['Bám đúng mục tiêu', 'Đúng định dạng'],
  });
  assert.ok(['ack', 'deliver', 'accept'].includes(r.stage));
  assert.equal(typeof r.contractId, 'string');
  const st = N.handoff.status();
  assert.ok(st.offered >= 2);
  assert.ok(st.contracts >= 2);
});

// ══════════════════ CHẤT VẤN CHÉO ══════════════════
test('chất vấn chéo: nhiều agent, không ai tự chất vấn mình, có hội tụ', async () => {
  const r = await N.debate.run({ topic: 'Cách tốt nhất để dạy hệ thức Vi-ét cho học sinh lớp 9', taskType: 'math_reasoning', participants: 3, rounds: 2 });
  assert.equal(r.ok, true, r.error);
  assert.ok(r.participants.length >= 2);
  assert.equal(new Set(r.participants).size, r.participants.length, 'người tham gia phải khác nhau');
  assert.ok(r.finalVersion && r.finalVersion.length > 0);
  assert.ok(r.log.some((l) => l.phase === 'propose'));
  assert.equal(typeof r.converged, 'boolean');
  assert.ok(r.rounds >= 0 && r.rounds <= 2);
});

test('chất vấn: thiếu người tham gia thì từ chối chạy', async () => {
  const r = await N.debate.run({ topic: 'x', taskType: 'math_reasoning', participants: 1 });
  assert.equal(r.ok, false);
  assert.equal(r.error, 'NOT_ENOUGH_AGENTS');
});

// ══════════════════ HỌC VIÊN & CHU KỲ 90 NGÀY ══════════════════
test('đăng ký học viên và dựng chân dung đầy đủ', () => {
  N.profiles.register('HV001', { fullName: 'Nguyễn Văn A', grade: 9, targetTrack: 'math', targetLevel: 6 });
  const p = N.profiles.portrait('HV001');
  assert.equal(p.ok, true);
  assert.equal(p.grade, 9);
  assert.equal(p.block, 'THCS');
  assert.equal(p.level.id, 0);
  assert.equal(Object.keys(p.axes).length, 6, 'sáu trục năng lực');
  assert.ok(p.grade5Star >= 1 && p.grade5Star <= 5);
  assert.equal(p.promotion.ready, false, 'chưa học gì thì chưa đủ điều kiện');
  assert.equal(p.promotion.failed.length > 0, true);
});

test('quan sát 4 lớp: thao tác, hành vi, suy nghĩ, kết quả', () => {
  N.telemetry.action('HV001', ACTIONS.SESSION_START);
  assert.equal(N.telemetry.action('HV001', 'KHONG_CO_LOAI_NAY').ok, false);

  for (let i = 0; i < 15; i++) {
    N.telemetry.attempt('HV001', {
      itemId: `IT-${i}`, formCode: 'M9.PT2.GIAI', level: 0, stars: 2,
      correct: i % 3 !== 0, ms: 30000, hintsUsed: 2, retries: 0,
      studentWork: 'Tinh delta roi ap dung cong thuc nghiem',
    });
  }
  N.telemetry.action('HV001', ACTIONS.SESSION_END);

  const b = N.telemetry.behaviors('HV001');
  assert.equal(b.metrics.items, 15);
  assert.ok(b.metrics.accuracy > 0 && b.metrics.accuracy < 1);
  assert.ok(b.metrics.hintRate > 0.5);
  assert.ok(b.behaviors.some((x) => x.id === 'HINT_DEPENDENT'), 'phải phát hiện phụ thuộc gợi ý');
  for (const x of b.behaviors) assert.ok(x.advice.length > 10);

  // Lớp suy nghĩ: bẫy nào chưa được xử lý
  const mis = N.telemetry.topMisconceptions('HV001');
  assert.ok(Array.isArray(mis));
});

test('mức thạo BKT tăng khi làm đúng, giảm khi làm sai', () => {
  const up = [];
  for (let i = 0; i < 8; i++) {
    up.push(N.mastery.update('HV002', { formCode: 'M9.CAN.DKXD', stars: 2, correct: true, hintsUsed: 0 }));
  }
  assert.ok(up[7].p > up[0].p, 'làm đúng liên tục thì mức thạo phải tăng');
  const before = up[7].p;
  const down = N.mastery.update('HV002', { formCode: 'M9.CAN.DKXD', stars: 2, correct: false, hintsUsed: 0 });
  assert.ok(down.p < before, 'làm sai thì mức thạo phải giảm');
  assert.ok(down.nextDueAt > Date.now(), 'SM-2 phải đặt lịch ôn');
});

test('lên tầng bị chặn khi chưa đủ 7 tiêu chí, không có ngoại lệ', () => {
  const r = N.profiles.promote('HV001');
  assert.equal(r.ok, false);
  assert.equal(r.error, 'STANDARDS_NOT_MET');
  assert.ok(r.evaluation.failed.length > 0);
  assert.equal(N.profiles.get('HV001').currentLevel, 0, 'vẫn ở tầng cũ');
});

test('chu kỳ 90 ngày: 3 chặng, 8 luật dịch chuyển chiến lược', () => {
  assert.equal(PHASES.length, 3);
  assert.deepEqual(PHASES.map((p) => p.days), [[1, 30], [31, 60], [61, 90]]);
  assert.equal(STRATEGY_RULES.length, 8);
  for (const p of PHASES) {
    const sum = p.mix.review + p.mix.weak + p.mix.new;
    assert.ok(Math.abs(sum - 1) < 0.001, `${p.name}: tỉ lệ trộn phải cộng bằng 1`);
  }
});

test('mở chu kỳ, lấy kế hoạch hôm nay, đóng chu kỳ và chọn chiến lược mới', () => {
  const s = N.cycle90.start('HV001');
  assert.equal(s.ok, true);
  assert.equal(N.cycle90.start('HV001').error, 'CYCLE_ALREADY_OPEN');

  const plan = N.cycle90.todayPlan('HV001', { itemsPerSession: 20 });
  assert.equal(plan.ok, true);
  assert.equal(plan.day, 1);
  assert.equal(plan.phase.id, 1);
  const total = plan.composition.review.count + plan.composition.weak.count + plan.composition.new.count;
  assert.equal(total, 20);
  assert.ok(Object.values(plan.starMix).reduce((a, b) => a + b, 0) > 0.99);

  N.cycle90.logPhase('HV001');
  const d = N.cycle90.decideStrategy('HV001');
  assert.ok(d.rule.id.startsWith('S'));
  assert.equal(d.allRulesEvaluated.length, 8);

  const c = N.cycle90.close('HV001');
  assert.equal(c.ok, true);
  assert.equal(Object.keys(c.delta).length, 7);
  assert.ok(['XUẤT SẮC', 'ĐẠT', 'CẦN ĐIỀU CHỈNH', 'KHÔNG TIẾN BỘ'].includes(c.verdict));
  assert.ok(c.nextStrategy.id && c.nextStrategy.reason);
  assert.equal(c.outOfAxes, 6);
});

test('luật chiến lược khớp đúng tình huống', () => {
  const find = (d) => STRATEGY_RULES.find((r) => r.when(d)).id;
  assert.equal(find({ accuracy: 0.4, misconceptionRate: 0, hintRate: 0, speedRatio: 1, coverage: 1, promotionReady: false }), 'S1_SUA_NEN');
  assert.equal(find({ accuracy: 0.8, misconceptionRate: 0.5, hintRate: 0, speedRatio: 1, coverage: 1, promotionReady: false }), 'S2_DONG_BAY');
  assert.equal(find({ accuracy: 0.8, misconceptionRate: 0, hintRate: 0.7, speedRatio: 1, coverage: 1, promotionReady: false }), 'S3_TU_LUC');
  assert.equal(find({ accuracy: 0.85, misconceptionRate: 0, hintRate: 0, speedRatio: 1.5, coverage: 1, promotionReady: false }), 'S4_TOC_DO');
  assert.equal(find({ accuracy: 0.85, misconceptionRate: 0, hintRate: 0, speedRatio: 1, coverage: 0.5, promotionReady: false }), 'S5_MO_RONG');
  assert.equal(find({ accuracy: 0.85, misconceptionRate: 0, hintRate: 0, speedRatio: 1, coverage: 1, promotionReady: true }), 'S6_LEN_TANG');
  assert.equal(find({ accuracy: 0.95, misconceptionRate: 0, hintRate: 0, speedRatio: 0.9, coverage: 1, promotionReady: false }), 'S7_NANG_DO_KHO');
  assert.equal(find({ accuracy: 0.75, misconceptionRate: 0, hintRate: 0, speedRatio: 1, coverage: 1, promotionReady: false }), 'S8_GIU_NHIP');
});

// ══════════════════ DÂY CHUYỀN BIÊN SOẠN ══════════════════
test('dây chuyền biên soạn có 6 chốt và người soạn khác người thẩm định', async () => {
  const b = N.authoring.brief('M9.PT2.GIAI', 2, 2);
  assert.equal(b.ok, true);
  assert.ok(b.brief.includes('CẤM dùng /'));
  assert.ok(b.brief.includes('TRÁNH TRÙNG') || b.brief.includes('chưa có bài nào'));

  const r = await N.authoring.produce({ formCode: 'M9.PT2.GIAI', level: 2, stars: 2 });
  // Với provider mock, bản nháp không đúng định dạng nên phải dừng ở chốt "draft".
  assert.equal(typeof r.ok, 'boolean');
  if (!r.ok) {
    assert.ok(['brief', 'draft', 'normalize', 'verify', 'review', 'approve'].includes(r.stage));
  } else {
    assert.notEqual(r.author, r.verifier, 'người soạn và người thẩm định phải khác nhau');
    assert.equal(r.quality.publishable, true);
  }
  assert.ok(N.authoring.status().runs >= 1);
});

test('dây chuyền bóc tách đúng định dạng biên soạn', () => {
  const parsed = N.authoring.parse([
    'ĐỀ: Giải phương trình \\dfrac{3}{1}x^{2} - 5x + 2 = 0',
    'BƯỚC 1: Tính \\Delta = 25 - 24 = 1',
    'BƯỚC 2: Áp dụng công thức nghiệm',
    'GỢI Ý 1: Nhớ công thức \\Delta',
    'GỢI Ý 2: \\Delta = b^{2} - 4ac',
    'GỢI Ý 3: Thay a=3, b=-5, c=2',
    'BẪY: Quên xét trường hợp a = 0',
    'ĐÁP ÁN: x = 1 hoặc x = \\dfrac{2}{3}',
  ].join('\n'));
  assert.ok(parsed.stem.includes('Giải phương trình'));
  assert.equal(parsed.solutionSteps.length, 2);
  assert.equal(parsed.hints.length, 3);
  assert.equal(parsed.traps.length, 1);
  assert.ok(parsed.answer.includes('x = 1'));

  const norm = N.authoring.normalizeItem(parsed);
  assert.equal(norm.ok, true, JSON.stringify(norm.errors));
});
