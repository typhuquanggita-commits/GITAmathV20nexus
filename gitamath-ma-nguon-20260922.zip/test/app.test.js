'use strict';
/**
 * Ứng dụng: giao diện web phục vụ tĩnh, mã HTTP đúng nghĩa,
 * cấu hình đóng gói bản cài Windows 64-bit, và các script vận hành.
 */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { execFileSync } = require('node:child_process');

const { boot, createServer } = require('../src/index');

const ROOT = path.join(__dirname, '..');
let N, server, base;

before(async () => {
  // Kho riêng cho mỗi lần chạy: nếu dùng chung thư mục dữ liệu thật thì lần
  // chạy thứ hai sẽ đụng tài khoản của lần trước và báo trùng tên.
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gita-app-'));
  process.env.DB_DIR = path.join(tmp, 'db');
  process.env.SNAPSHOT_DIR = path.join(tmp, 'snap');
  N = await boot({ quiet: true });
  server = createServer(N);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
  await dangNhapQuanTri(base);
});

/** Phiên quản trị dùng chung cho cả tệp — đăng nhập THẬT như một client thật. */
let token = null;
const hd = (them = {}) => (token ? { ...them, authorization: `Bearer ${token}` } : them);
async function dangNhapQuanTri(base) {
  await fetch(`${base}/accounts`, {
    method: 'POST', headers: hd({ 'content-type': 'application/json' }),
    body: JSON.stringify({ username: 'kiem_thu_admin', password: 'Khuon7Dao-Vuon9Xanh!', role: 'ADMIN', fullName: 'Kiểm thử' }),
  });
  const dn = await (await fetch(`${base}/accounts/login`, {
    method: 'POST', headers: hd({ 'content-type': 'application/json' }),
    body: JSON.stringify({ username: 'kiem_thu_admin', password: 'Khuon7Dao-Vuon9Xanh!' }),
  })).json();
  token = dn.token || null;
}


after(async () => {
  server.close();
  await N.shutdown();
});

// ── GIAO DIỆN WEB ───────────────────────────────────────────────────────────

const UI_PAGES = [
  { html: 'index.html', js: 'app.js', name: 'Super Admin' },
  { html: 'hoc-vien.html', js: 'hoc-vien.js', name: 'Học viên' },
  { html: 'giao-vien.html', js: 'giao-vien.js', name: 'Giáo viên' },
];

test('giao diện: mọi tệp gốc được phục vụ đúng kiểu nội dung', async () => {
  const want = [
    ['/ui/index.html', 'text/html'],
    ['/ui/hoc-vien.html', 'text/html'],
    ['/ui/giao-vien.html', 'text/html'],
    ['/ui/app.js', 'javascript'],
    ['/ui/hoc-vien.js', 'javascript'],
    ['/ui/giao-vien.js', 'javascript'],
    ['/ui/common.js', 'javascript'],
    ['/ui/tex.js', 'javascript'],
    ['/ui/styles.css', 'text/css'],
  ];
  for (const [p, type] of want) {
    const r = await fetch(base + p, { headers: hd() });
    assert.equal(r.status, 200, p);
    assert.match(r.headers.get('content-type') || '', new RegExp(type), p);
    assert.ok((await r.text()).length > 500, `${p} quá ngắn`);
  }
});

test('giao diện: không đi ngược ra ngoài thư mục ui/', async () => {
  const attacks = [
    '/ui/../src/config.js',
    '/ui/%2e%2e/src/config.js',
    '/ui/../../etc/passwd',
    '/ui/....//src/config.js',
    '/ui/..%2f..%2fpackage.json',
  ];
  for (const a of attacks) {
    const r = await fetch(base + a, { headers: hd() });
    assert.ok(r.status === 404 || r.status === 403, `${a} trả ${r.status}`);
    const body = await r.text();
    assert.ok(!body.includes('AGENT_TOTAL'), `${a} làm lộ nội dung config`);
  }
});

test('giao diện: mọi tab trong HTML đều có mã xử lý', () => {
  for (const page of UI_PAGES) {
    const html = fs.readFileSync(path.join(ROOT, 'ui', page.html), 'utf8');
    const js = fs.readFileSync(path.join(ROOT, 'ui', page.js), 'utf8');
    const tabs = [...html.matchAll(/data-tab="([a-z]+)"/g)].map((m) => m[1]);
    assert.ok(tabs.length >= 5, `${page.name}: chỉ có ${tabs.length} tab`);
    for (const t of tabs) {
      assert.ok(html.includes(`id="tab-${t}"`), `${page.name}: thiếu khung nội dung tab ${t}`);
      const handled = new RegExp(`(['"]${t}['"])|([{,]\\s*${t}\\s*[,:}])`).test(js);
      assert.ok(handled, `${page.name}: chưa xử lý tab ${t}`);
    }
  }
});

test('giao diện: mọi hàm App.* được gọi đều tồn tại — kể cả trong HTML sinh động', () => {
  for (const page of UI_PAGES) {
    const html = fs.readFileSync(path.join(ROOT, 'ui', page.html), 'utf8');
    const js = fs.readFileSync(path.join(ROOT, 'ui', page.js), 'utf8');
    // Nút bấm sinh từ chuỗi trong JS cũng phải được soát, nếu không sẽ có nút chết.
    const called = [...new Set([...(html + js).matchAll(/App\.([a-zA-Z0-9_]+)\(/g)].map((m) => m[1]))];
    assert.ok(called.length >= 5, `${page.name}: chỉ tìm thấy ${called.length} lời gọi`);
    const exported = js.slice(js.lastIndexOf('return {'));
    for (const fn of called) {
      assert.ok(new RegExp(`\\b${fn}\\b`).test(exported), `${page.name}: App.${fn} là nút chết, chưa được export`);
    }
  }
});

test('giao diện: không nhúng script ngoài, không gọi mạng ngoài', () => {
  for (const page of [...UI_PAGES, { html: null, js: 'common.js', name: 'Chung' }, { html: null, js: 'tex.js', name: 'TeX' }]) {
    if (page.html) {
      const html = fs.readFileSync(path.join(ROOT, 'ui', page.html), 'utf8');
      assert.ok(!/src\s*=\s*["']https?:/i.test(html), `${page.name}: HTML nhúng script từ CDN ngoài`);
    }
    const js = fs.readFileSync(path.join(ROOT, 'ui', page.js), 'utf8');
    const code = js.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
    assert.ok(!/https?:\/\/(?!127\.0\.0\.1|localhost)/i.test(code), `${page.name}: gọi ra mạng ngoài`);
  }
});

test('giao diện: mọi trang đều nạp bộ dựng công thức và hạ tầng chung', () => {
  for (const page of UI_PAGES) {
    const html = fs.readFileSync(path.join(ROOT, 'ui', page.html), 'utf8');
    assert.match(html, /src="\/ui\/tex\.js"/, `${page.name}: thiếu bộ dựng công thức`);
    assert.match(html, /src="\/ui\/common\.js"/, `${page.name}: thiếu hạ tầng chung`);
    assert.match(html, /<html lang="vi">/, `${page.name}: thiếu khai báo ngôn ngữ`);
    assert.match(html, /name="viewport"/, `${page.name}: không dùng được trên màn hình hẹp`);
  }
});

test('giao diện: không trang nào để lọt đáp án vào màn hình làm bài', () => {
  // Học viên đang làm bài không được thấy đáp án trước khi nộp.
  const js = fs.readFileSync(path.join(ROOT, 'ui', 'hoc-vien.js'), 'utf8');
  const renderItem = js.slice(js.indexOf('function renderItem'), js.indexOf('function showHint'));
  assert.ok(!/\bit\.answer\b/.test(renderItem), 'màn hình làm bài đang hiện đáp án');
  assert.ok(!/solutionSteps/.test(renderItem), 'màn hình làm bài đang hiện lời giải');
  const examPaper = js.slice(js.indexOf('function renderExamPaper'), js.indexOf('async function submitExam'));
  assert.ok(!/\.answer\b/.test(examPaper) || /placeholder/.test(examPaper), 'đề thi đang hiện đáp án');
});

// ── MÃ HTTP ĐÚNG NGHĨA ──────────────────────────────────────────────────────

test('HTTP: đăng nhập sai trả 401, không phải 200', async () => {
  const r = await fetch(`${base}/superadmin/login`, {
    method: 'POST', headers: hd({ 'content-type': 'application/json' }),
    body: JSON.stringify({ username: 'superadmin', password: 'sai-be-bet', totp: '000000' }),
  });
  assert.equal(r.status, 401);
  assert.equal((await r.json()).ok, false);
});

test('HTTP: không tìm thấy trả 404, thiếu dữ liệu trả 400', async () => {
  assert.equal((await fetch(`${base}/agents/KHONG-CO-AGENT-NAY`, { headers: hd() })).status, 404);
  assert.equal((await fetch(`${base}/learner/KHONG-CO/portrait`, { headers: hd() })).status, 404);
  const r = await fetch(`${base}/learner/register`, {
    method: 'POST', headers: hd({ 'content-type': 'application/json' }), body: JSON.stringify({ fullName: 'Thiếu mã' }),
  });
  assert.equal(r.status, 400);
});

test('HTTP: thân yêu cầu hỏng trả 400, đường dẫn lạ trả 404', async () => {
  const r = await fetch(`${base}/mission/plan`, {
    method: 'POST', headers: hd({ 'content-type': 'application/json' }), body: '{khong-phai-json',
  });
  assert.equal(r.status, 400);
  assert.equal((await fetch(`${base}/duong-dan-khong-ton-tai`, { headers: hd() })).status, 404);
});

// ── BẢN CÀI ĐẶT WINDOWS 64-BIT ──────────────────────────────────────────────

test('desktop: cấu hình đóng gói nhắm đúng Windows x64, có cả trình cài và bản chạy thẳng', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'desktop', 'package.json'), 'utf8'));
  const targets = pkg.build.win.target;
  assert.deepEqual(targets.map((t) => t.target).sort(), ['nsis', 'portable']);
  for (const t of targets) assert.deepEqual(t.arch, ['x64'], `${t.target} phải là x64`);
  assert.equal(pkg.build.nsis.oneClick, false, 'người dùng phải chọn được thư mục cài');
  assert.equal(pkg.build.nsis.createDesktopShortcut, true);
  assert.equal(pkg.build.nsis.deleteAppDataOnUninstall, false, 'gỡ cài đặt không được xoá dữ liệu học viên');
  assert.equal(pkg.main, 'main.js');
});

test('desktop: mọi tệp mà bản cài cần đều có thật', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'desktop', 'package.json'), 'utf8'));
  for (const f of pkg.build.files) {
    // Dòng bắt đầu bằng "!" là luật LOẠI TRỪ của electron-builder, không phải
    // tên tệp — đòi nó tồn tại là đòi sai. Mục kiểm bản đầu không phân biệt
    // hai loại, nên lúc thêm "!**/*.map" để gói nhẹ bớt thì nó đỏ lên và báo
    // "thiếu !**/*.map". Nó bắt đúng chỗ có thay đổi, chỉ hiểu sai ý nghĩa.
    if (f.startsWith('!')) {
      assert.ok(f.length > 1, 'luật loại trừ rỗng');
      continue;
    }
    assert.ok(fs.existsSync(path.join(ROOT, 'desktop', f)), `thiếu ${f}`);
  }
  for (const r of pkg.build.extraResources) {
    assert.ok(fs.existsSync(path.join(ROOT, 'desktop', r.from)), `thiếu tài nguyên ${r.from}`);
  }
});

test('desktop: đường dẫn trong bản đóng gói khớp với cách main.js nạp Nexus', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'desktop', 'package.json'), 'utf8'));
  // main.js nạp ROOT/src/index.js với ROOT = <thư mục cha của app.asar> = resources/
  // nên extraResources phải đổ src, ui, package.json thẳng vào resources/.
  const map = Object.fromEntries(pkg.build.extraResources.map((r) => [r.from, r.to]));
  assert.equal(map['../src'], 'src');
  assert.equal(map['../ui'], 'ui');
  assert.equal(map['../package.json'], 'package.json');
});

test('desktop: cửa sổ chạy ở chế độ an toàn và chỉ nghe trên máy', () => {
  const main = fs.readFileSync(path.join(ROOT, 'desktop', 'main.js'), 'utf8');
  assert.match(main, /contextIsolation:\s*true/);
  assert.match(main, /nodeIntegration:\s*false/);
  assert.match(main, /sandbox:\s*true/);
  assert.match(main, /process\.env\.HOST\s*=\s*'127\.0\.0\.1'/);
  assert.match(main, /requestSingleInstanceLock/);
  assert.match(main, /will-navigate/, 'phải chặn điều hướng ra ngoài');
  assert.match(main, /app-exit/, 'phải chụp ảnh hệ thống khi thoát');
});

test('desktop: cầu nối preload chỉ mở đúng những gì cần, không lộ Node', () => {
  const pre = fs.readFileSync(path.join(ROOT, 'desktop', 'preload.js'), 'utf8');
  const main = fs.readFileSync(path.join(ROOT, 'desktop', 'main.js'), 'utf8');
  assert.match(pre, /contextBridge\.exposeInMainWorld/);
  assert.ok(!/require\(['"]node:/.test(pre), 'preload không được mở module Node cho giao diện');
  const channels = [...new Set([...pre.matchAll(/ipcRenderer\.invoke\('([^']+)'\)/g)].map((m) => m[1]))];
  assert.ok(channels.length >= 4);
  for (const c of channels) {
    assert.ok(main.includes(`ipcMain.handle('${c}'`), `main.js chưa xử lý kênh ${c}`);
  }
});

test('desktop: biểu tượng là tệp .ico Windows thật, nhiều kích cỡ', () => {
  const ico = fs.readFileSync(path.join(ROOT, 'desktop', 'build', 'icon.ico'));
  assert.equal(ico.readUInt16LE(0), 0, 'sai phần đầu ICO');
  assert.equal(ico.readUInt16LE(2), 1, 'không phải kiểu icon');
  const count = ico.readUInt16LE(4);
  assert.ok(count >= 5, `chỉ có ${count} kích cỡ`);
  assert.ok(ico.length > 4000);
});

test('desktop: SNAPSHOT_DIR do ứng dụng đặt được hệ thống tôn trọng', () => {
  const main = fs.readFileSync(path.join(ROOT, 'desktop', 'main.js'), 'utf8');
  const index = fs.readFileSync(path.join(ROOT, 'src', 'index.js'), 'utf8');
  assert.match(main, /process\.env\.SNAPSHOT_DIR\s*=/);
  assert.match(index, /dir:\s*process\.env\.SNAPSHOT_DIR/);
});

// ── SCRIPT VẬN HÀNH ─────────────────────────────────────────────────────────

test('script: bảng phân công in ra đủ 500 dòng CSV', () => {
  const out = execFileSync(process.execPath, [path.join(ROOT, 'scripts', 'roster-table.js'), '--csv'],
    { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
  const lines = out.trim().split('\n');
  assert.equal(lines.length, 501, 'phải có 1 dòng tiêu đề + 500 agent');
  assert.match(lines[0], /ma_agent/);
  assert.match(lines[1], /^1,MTH-001,MATH/);
  assert.match(lines[500], /^500,BIZ-500,BUSINESS/);
});

// Việc soát script đã chuyển sang test/packaging.test.js với bộ lọc đúng hơn
// (bỏ qua `node -e` và lệnh npm lồng nhau, vốn không trỏ tới tệp nào cả).

// ── HÀNH TRÌNH THẬT QUA GIAO DIỆN ───────────────────────────────────────────

test('cổng /ui đưa về trang chọn vai', async () => {
  const r = await fetch(`${base}/ui/`, { redirect: 'manual' });
  assert.equal(r.status, 302);
  assert.equal(r.headers.get('location'), '/ui/cong.html');
  const portal = await fetch(`${base}/ui/cong.html`, { headers: hd() });
  assert.equal(portal.status, 200);
  const html = await portal.text();
  for (const href of ['/ui/hoc-vien.html', '/ui/giao-vien.html', '/ui/index.html']) {
    assert.ok(html.includes(href), `cổng thiếu lối vào ${href}`);
  }
});

test('hành trình học viên chạy được trọn vẹn đúng như giao diện gọi', async () => {
  const post = async (p, b) => {
    const r = await fetch(base + p, { method: 'POST', headers: hd({ 'content-type': 'application/json' }), body: JSON.stringify(b) });
    return r.json();
  };
  const get = async (p) => (await fetch(base + p, { headers: hd() })).json();

  // 1. Quản trị tạo tài khoản học viên và hồ sơ
  const acc = await post('/accounts', { username: 'hv_ui', password: 'HocVien#Ui2026', role: 'LEARNER', fullName: 'Học viên UI' });
  assert.equal(acc.ok, true, JSON.stringify(acc));
  await post('/learner/register', { userId: 'HV-UI', fullName: 'Học viên UI', grade: 9 });
  await post(`/accounts/${acc.user.id}/link-learner`, { learnerId: 'HV-UI' }).catch(() => null);

  // 2. Học viên đăng nhập
  const login = await post('/accounts/login', { username: 'hv_ui', password: 'HocVien#Ui2026' });
  assert.equal(login.ok, true);
  assert.equal(login.user.role, 'LEARNER');

  // 3. Làm bài xếp tầng
  const pl = await post('/placement/start', { learnerId: 'HV-UI', grade: 9 });
  assert.equal(pl.ok, true);
  assert.equal(pl.item.answer, undefined, 'không được gửi đáp án xuống máy học viên');
  let cur = pl.item;
  let placed = null;
  for (let i = 0; i < 25 && cur; i++) {
    const r = await post('/placement/answer', { sessionId: pl.sessionId, itemId: cur.id, correct: i % 3 !== 2, ms: 90_000 });
    if (r.done) { placed = r; break; }
    cur = r.item;
  }
  assert.ok(placed, 'phiên xếp tầng phải kết thúc');

  // 4. Sinh lộ trình rồi xem việc tuần này
  assert.equal((await post('/roadmap/generate', { learnerId: 'HV-UI' })).ok, true);
  const wk = await get('/roadmap/HV-UI/this-week');
  assert.equal(wk.ok, true);
  assert.ok(wk.focusForms.length >= 1);

  // 5. Vào luyện tập, chấm bằng đáp án viết tay
  const pr = await post('/practice/start', { learnerId: 'HV-UI', size: 5 });
  assert.equal(pr.ok, true);
  const first = pr.item;
  assert.ok(first.hints, 'luyện tập thì được phát gợi ý');
  const item = await get(`/bank/items/${encodeURIComponent(first.itemId)}`);
  const ans = await post('/practice/answer', {
    sessionId: pr.sessionId, itemId: first.itemId, answer: item.item.answer, ms: 80_000, hintsUsed: 1,
  });
  assert.equal(ans.ok, true);
  if (ans.graded) assert.equal(ans.correct, true, 'nộp đúng đáp án chuẩn mà bị chấm sai');

  // 6. Xem chân dung — phải đủ dữ liệu cho giao diện vẽ
  const portrait = await get('/learner/HV-UI/portrait');
  assert.equal(portrait.ok, true);
  assert.ok(portrait.axes && Object.keys(portrait.axes).length >= 6, 'thiếu trục chân dung');
  assert.ok(portrait.masteryByForm, 'thiếu mức thạo theo dạng');
  assert.ok(portrait.formNames, 'thiếu tên dạng để hiển thị');
  assert.ok(portrait.levelName, 'thiếu tên tầng');
});

test('hành trình giáo viên: lớp, học viên, duyệt học liệu', async () => {
  const post = async (p, b) => {
    const r = await fetch(base + p, { method: 'POST', headers: hd({ 'content-type': 'application/json' }), body: JSON.stringify(b) });
    return r.json();
  };
  const get = async (p) => (await fetch(base + p, { headers: hd() })).json();

  const gv = await post('/accounts', { username: 'gv_ui', password: 'Gi4oVien#Ui2026', role: 'TEACHER', fullName: 'Cô Giáo UI' });
  assert.equal(gv.ok, true);
  await post('/org/schools', { id: 'SCH-UI', name: 'Trường UI' });
  await post('/org/classes', { id: 'CL-UI', name: '9U', grade: 9, schoolId: 'SCH-UI', teacherId: gv.user.id });
  await post('/org/classes/CL-UI/enroll', { learnerId: 'HV-UI' });

  const list = await get(`/org/classes?teacherId=${encodeURIComponent(gv.user.id)}`);
  assert.equal(list.items.length, 1, 'giáo viên phải thấy đúng lớp mình dạy');
  const roster = await get('/org/classes/CL-UI/roster');
  assert.ok(roster.items.length >= 1);
  assert.ok(roster.items[0].fullName, 'danh sách lớp phải có tên để hiển thị');

  const pending = await get('/bank/items?status=REVIEWED&limit=5');
  if (pending.items.length) {
    const r = await post(`/bank/items/${encodeURIComponent(pending.items[0].id)}/publish`, { by: gv.user.id });
    assert.equal(r.ok, true, 'giáo viên phải duyệt được bài chờ');
  }

  const cov = await get('/authoring/coverage');
  assert.equal(cov.ok, true);
  assert.ok(cov.slots > 0);
});

test('Mọi tệp mã nguồn đều được git theo dõi — clone sạch phải chạy được', () => {
  // MỤC KIỂM NÀY RA ĐỜI TỪ MỘT LỖ THỦNG CÓ THẬT.
  //
  // Tệp .gitignore có dòng "data/" — không dấu gạch đầu. Git hiểu dòng ấy là
  // "mọi thư mục tên data ở mọi độ sâu", nên nó nuốt luôn src/data/, nơi đặt
  // tầng lưu trữ bền vững của cả hệ thống. Kết quả: src/data/repository.js và
  // src/data/portability.js chưa bao giờ được commit.
  //
  // Trên máy đang làm việc không ai thấy gì, vì hai tệp ấy vẫn nằm trên đĩa.
  // Lỗi chỉ lộ khi clone sạch ra một chỗ khác: hệ thống chết ngay khi bật với
  // đúng một dòng "Cannot find module './data/repository'".
  //
  // Mục kiểm cũ "Mọi lời gọi mô-đun trong kho đều trỏ vào tệp có thật" KHÔNG
  // bắt được, vì nó hỏi đĩa chứ không hỏi git. Mục này hỏi git.
  const { execFileSync } = require('node:child_process');
  let theoDoi;
  try {
    theoDoi = new Set(
      execFileSync('git', ['ls-files'], { cwd: ROOT, encoding: 'utf8' })
        .split('\n').filter(Boolean),
    );
  } catch {
    return; // không phải kho git (ví dụ chạy từ bản giải nén) thì bỏ qua
  }

  const boQua = /^(node_modules|data|desktop[/\\](node_modules|dist))[/\\]/;
  const canThiet = [];
  const di = (thuMuc, tienTo) => {
    for (const m of fs.readdirSync(thuMuc, { withFileTypes: true })) {
      const rel = tienTo ? `${tienTo}/${m.name}` : m.name;
      if (boQua.test(rel) || m.name === '.git') continue;
      if (m.isDirectory()) di(path.join(thuMuc, m.name), rel);
      else if (/\.(js|json|html|css|md)$/.test(m.name) && !/\.log$/.test(m.name)) canThiet.push(rel);
    }
  };
  for (const g of ['src', 'test', 'scripts', 'bin', 'ui']) {
    const d = path.join(ROOT, g);
    if (fs.existsSync(d)) di(d, g);
  }

  const soT = canThiet.filter((f) => !theoDoi.has(f));
  assert.deepEqual(
    soT, [],
    `${soT.length} tệp mã nguồn KHÔNG được git theo dõi — clone sạch sẽ thiếu chúng: ${soT.slice(0, 5).join(', ')}`,
  );
});
