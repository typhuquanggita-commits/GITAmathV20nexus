'use strict';
/** Phân tích hành vi sâu: mỗi kết luận có bằng chứng đếm được, thiếu dữ liệu thì nói thiếu. */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const Telemetry = require('../src/learner/telemetry');
const Mastery = require('../src/learner/mastery');
const BehaviorAnalyzer = require('../src/learner/behavior');
const { MIN_SAMPLES, GUESS_FAST_RATIO } = BehaviorAnalyzer;

function rig() {
  const telemetry = new Telemetry();
  const mastery = new Mastery();
  return { telemetry, mastery, analyzer: new BehaviorAnalyzer({ telemetry, mastery }) };
}

/** Bơm lượt làm bài. norm mặc định của M9.PT2.GIAI là 150 giây. */
function feed(t, userId, rows) {
  rows.forEach((r, i) => t.attempt(userId, {
    itemId: `IT-${userId}-${i}`,
    formCode: r.formCode || 'M9.PT2.GIAI',
    correct: r.correct,
    ms: r.ms ?? 150_000,
    hintsUsed: r.hints ?? 0,
    stars: r.stars ?? 3,
  }));
}

test('thiếu dữ liệu thì nói thiếu, không suy diễn', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'ÍT', Array.from({ length: 5 }, () => ({ correct: true })));
  for (const fn of ['guessing', 'attentionSpan', 'anomalies', 'rhythm']) {
    const r = analyzer[fn]('ÍT');
    assert.equal(r.enough, false, fn);
    assert.ok(r.samples < MIN_SAMPLES || r.verdict);
  }
  const full = analyzer.fullReport('ÍT');
  assert.equal(full.enoughData, false);
  assert.match(full.summary, /chưa đủ/i);
});

test('bắt được đoán mò: nhanh thì sai, chậm thì đúng', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'ĐM', Array.from({ length: 40 }, (_, i) => (
    i % 2 === 0 ? { correct: false, ms: 20_000 } : { correct: true, ms: 200_000 }
  )));
  const g = analyzer.guessing('ĐM');
  assert.equal(g.enough, true);
  assert.match(g.verdict, /CÓ DẤU HIỆU ĐOÁN MÒ/);
  assert.ok(g.accuracyGap >= 0.2);
  assert.match(g.evidence, /thời gian chuẩn/);
  assert.ok(g.advice.length >= 2, 'phải nói làm gì tiếp, không chỉ gắn nhãn');
});

test('không gắn nhãn đoán mò cho người làm ổn định', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'ỔN', Array.from({ length: 30 }, (_, i) => ({ correct: i % 5 !== 0, ms: 140_000 })));
  const g = analyzer.guessing('ỔN');
  assert.match(g.verdict, /KHÔNG THẤY/);
  assert.equal(g.advice.length, 0);
});

test('đo được ngưỡng chú ý và điểm bắt đầu sa sút', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'ĐUỐI', Array.from({ length: 20 }, (_, i) => ({ correct: i < 10, ms: 150_000 })));
  const a = analyzer.attentionSpan('ĐUỐI');
  assert.equal(a.enough, true);
  assert.match(a.verdict, /ĐUỐI/);
  assert.ok(a.accuracyDrop >= 0.2);
  assert.ok(a.dropAtItem > 0, 'phải chỉ ra bài thứ mấy bắt đầu sa sút');
  assert.ok(a.recommendedSessionItems >= 5 && a.recommendedSessionItems <= 25);
  assert.ok(a.advice.length >= 1);
});

test('người giữ được phong độ không bị khuyên rút ngắn buổi học', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'BỀN', Array.from({ length: 20 }, () => ({ correct: true, ms: 140_000 })));
  const a = analyzer.attentionSpan('BỀN');
  assert.match(a.verdict, /GIỮ ĐƯỢC PHONG ĐỘ/);
  assert.equal(a.advice.length, 0);
});

test('nêu dấu hiệu bất thường nhưng KHÔNG kết tội', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'NGHI', Array.from({ length: 20 }, () => ({ correct: true, ms: 15_000, stars: 5 })));
  const r = analyzer.anomalies('NGHI');
  assert.equal(r.enough, true);
  assert.ok(r.flags.some((f) => f.kind === 'TỐC_ĐỘ_PHI_THỰC_TẾ'));
  assert.match(r.disclaimer, /không kết tội/);
  for (const f of r.flags) {
    assert.ok(f.detail && f.note, 'mỗi dấu hiệu phải có số liệu và lời dặn cho giáo viên');
    assert.ok(!/gian lận|chép bài|ăn cắp/i.test(f.kind + f.detail), 'không dùng từ kết tội');
  }
});

test('người làm bài bình thường không bị gắn cờ bất thường', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'THƯỜNG', Array.from({ length: 25 }, (_, i) => ({ correct: i % 4 !== 0, ms: 160_000, stars: 3 })));
  const r = analyzer.anomalies('THƯỜNG');
  assert.equal(r.flags.length, 0);
  assert.match(r.verdict, /KHÔNG THẤY BẤT THƯỜNG/);
});

test('phát hiện nhảy vọt bất thường kèm tốc độ tăng đột ngột', () => {
  const { analyzer, telemetry } = rig();
  const rows = [
    ...Array.from({ length: 10 }, () => ({ correct: false, ms: 200_000 })),
    ...Array.from({ length: 10 }, () => ({ correct: true, ms: 20_000 })),
  ];
  feed(telemetry, 'VỌT', rows);
  const r = analyzer.anomalies('VỌT');
  assert.ok(r.flags.some((f) => f.kind === 'NHẢY_VỌT_BẤT_THƯỜNG'), JSON.stringify(r.flags.map((f) => f.kind)));
});

test('xu hướng nói được đang lên hay đang xuống, kèm số liệu', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'LÊN', [
    ...Array.from({ length: 20 }, () => ({ correct: false })),
    ...Array.from({ length: 20 }, () => ({ correct: true })),
  ]);
  const up = analyzer.trend('LÊN');
  assert.equal(up.direction, 'ĐANG LÊN');
  assert.ok(up.delta > 0);
  assert.match(up.evidence, /bài gần nhất/);

  const { analyzer: a2, telemetry: t2 } = rig();
  feed(t2, 'XUỐNG', [
    ...Array.from({ length: 20 }, () => ({ correct: true })),
    ...Array.from({ length: 20 }, () => ({ correct: false })),
  ]);
  const down = a2.trend('XUỐNG');
  assert.equal(down.direction, 'ĐANG XUỐNG');
  assert.ok(down.advice.some((x) => /Dừng đẩy độ khó/.test(x)));
});

test('nhịp học: chỉ ra khung giờ tốt và khoảng nghỉ giữa các buổi', () => {
  const { analyzer, telemetry } = rig();
  const base = new Date('2026-03-02T08:00:00Z').getTime();
  for (let i = 0; i < 30; i++) {
    telemetry.attempt('NHỊP', {
      itemId: `N${i}`, formCode: 'M9.PT2.GIAI', correct: i % 3 !== 0,
      ms: 150_000, hintsUsed: 0, stars: 3,
    });
    // Ghi đè mốc thời gian để mô phỏng lịch học thật.
    const arr = telemetry.attemptsOf('NHỊP');
    arr[arr.length - 1].at = base + i * 12 * 3600_000;
  }
  const r = analyzer.rhythm('NHỊP');
  assert.equal(r.enough, true);
  assert.ok(Array.isArray(r.bestHours));
  assert.ok(r.medianGapDays === null || r.medianGapDays > 0);
  assert.ok(['đều', 'thất thường', 'gián đoạn dài', null].includes(r.consistency));
});

test('báo cáo đầy đủ gộp mọi góc nhìn và đưa việc cần làm', () => {
  const { analyzer, telemetry } = rig();
  feed(telemetry, 'ĐẦY', Array.from({ length: 40 }, (_, i) => (
    i % 2 === 0 ? { correct: false, ms: 20_000 } : { correct: true, ms: 200_000 }
  )));
  const r = analyzer.fullReport('ĐẦY');
  assert.equal(r.enoughData, true);
  for (const k of ['guessing', 'attentionSpan', 'anomalies', 'rhythm', 'trend', 'misconceptions', 'patterns']) {
    assert.ok(k in r, `thiếu mục ${k}`);
  }
  assert.ok(r.actions.length >= 1, 'phải có việc cần làm, không chỉ mô tả');
  assert.equal(new Set(r.actions).size, r.actions.length, 'việc cần làm không được lặp');
  assert.ok(r.summary.length > 40);
});
