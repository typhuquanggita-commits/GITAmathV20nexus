'use strict';
/**
 * BỘ KHẢO SÁT — CHẠY TỪ ĐẦU ĐẾN CUỐI
 *
 * Bản dựng đầu có đủ bộ chấm, đủ luật đo, đủ trang lộ trình — mà KHÔNG dùng
 * được: không có biểu mẫu để làm bài, không có chỗ lưu kết quả, và khu riêng
 * không bao giờ ghi lớp vào hồ sơ học viên. Ba lỗ ấy cộng lại thành một trang
 * lộ trình vĩnh viễn hiện "chưa đủ căn cứ" cho mọi tài khoản thật.
 *
 * Bộ kiểm này đi trọn chuỗi: dựng đề → đọc biểu mẫu → chấm → lưu → đọc lại →
 * dựng lộ trình. Một mắt xích đứt là cả chuỗi trượt, đúng như người dùng gặp.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const ks = require('../src/khao-sat/mat-trong-nha');
const KhoKhaoSat = require('../src/khao-sat/kho');
const { RIENG_TU } = require('../src/khao-sat/kho');
const { dungHoSo } = require('../src/khao-sat/ho-so');
const { dungLoTrinh } = require('../src/khao-sat/lo-trinh-ca-nhan');
const { CONG_CU_INDEX } = require('../src/khao-sat/hien-phap-do');

/** Điền đủ một biểu mẫu đúng kiểu của bộ ấy. */
function dienDu(boId, chon = {}) {
  const de = ks.deBai(boId);
  const form = {};
  for (const c of de.cau) {
    if (de.kieu === 'tu-bo') { form[`dung_${c.so}`] = chon.dung || 'C'; form[`it_${c.so}`] = chon.it || 'D'; }
    else if (de.kieu === 'hai-lua') form[`c_${c.so}`] = c.luaChon[0].ma;
    else form[`c_${c.so}`] = String(chon.diem != null ? chon.diem : 3);
  }
  return form;
}

test('Bốn bộ đều dựng được đề và đọc lại được biểu mẫu của chính nó', () => {
  for (const boId of Object.keys(ks.BO)) {
    const de = ks.deBai(boId);
    assert.ok(de && de.cau.length > 0, `${boId} không dựng được đề`);
    const doc = ks.docBieuMau(boId, dienDu(boId));
    assert.equal(doc.thieu.length, 0, `${boId} điền đủ mà vẫn báo thiếu`);
    assert.equal(doc.traLoi.length, de.cau.length);
    const kq = ks.cham(boId, doc.traLoi);
    assert.notEqual(kq.ok, false, `${boId} chấm hỏng`);
    const tt = ks.tomTat(boId, kq);
    assert.ok(tt.motCau && tt.motCau.length > 5, `${boId} không tóm tắt được`);
  }
});

test('Thiếu câu thì KHÔNG chấm, và nói rõ thiếu câu nào', () => {
  const de = ks.deBai('mbti');
  const form = {};
  for (const c of de.cau.slice(0, 10)) form[`c_${c.so}`] = c.luaChon[0].ma;
  const doc = ks.docBieuMau('mbti', form);
  assert.equal(doc.traLoi.length, 10);
  assert.equal(doc.thieu.length, de.cau.length - 10);
  assert.ok(doc.thieu.every((x) => Number.isInteger(x)), 'phải nói rõ số thứ tự câu thiếu');
});

test('Biểu mẫu gửi giá trị rác thì bị loại, không đoán', () => {
  const de = ks.deBai('tam-ly');
  const form = {};
  for (const c of de.cau) form[`c_${c.so}`] = 'rất nhiều';
  const doc = ks.docBieuMau('tam-ly', form);
  assert.equal(doc.traLoi.length, 0);
  assert.equal(doc.thieu.length, de.cau.length);
});

test('Hai bộ không làm ở khu riêng đều nói rõ VÌ SAO', () => {
  for (const c of ks.danhSach()) {
    if (c.lamDuoc) { assert.ok(c.soCau > 0, `${c.ma} bảo làm được mà không có câu nào`); continue; }
    assert.ok(c.viSaoChuaLamDuoc && c.viSaoChuaLamDuoc.length > 20, `${c.ma} không nói vì sao chưa làm được`);
  }
});

// ═══ KHO LƯU ═══════════════════════════════════════════════════════════════

test('Sàng lọc tâm lý KHÔNG lưu từng câu trả lời', () => {
  const kho = new KhoKhaoSat({});
  const doc = ks.docBieuMau('tam-ly', dienDu('tam-ly', { diem: 2 }));
  const kq = ks.cham('tam-ly', doc.traLoi);
  kho.luu({ hocVienId: 'HV', congCu: 'TAM_LY_HOC_DUONG', ketQua: kq, cauTraLoi: doc.traLoi });
  const ban = kho.lichSu('HV', 'TAM_LY_HOC_DUONG')[0];
  assert.equal(ban.cauTraLoi, null, 'đang lưu câu thô của bài sàng lọc tâm lý');
  assert.equal(ban.khongLuuCauTho, true);
  // Và không còn trường nào lần ra được từng câu.
  const chu = JSON.stringify(ban.ketQua);
  assert.equal(chu.includes('soCauTraLoi'), false);
});

test('Bộ khác thì CÓ lưu câu thô, vì cần chấm lại và đối chiếu', () => {
  const kho = new KhoKhaoSat({});
  const doc = ks.docBieuMau('disc', dienDu('disc'));
  kho.luu({ hocVienId: 'HV', congCu: 'DISC', ketQua: ks.cham('disc', doc.traLoi), cauTraLoi: doc.traLoi });
  assert.equal(kho.lichSu('HV', 'DISC')[0].cauTraLoi.length, doc.traLoi.length);
});

test('Giáo viên KHÔNG đọc được kết quả sàng lọc tâm lý', () => {
  const kho = new KhoKhaoSat({});
  for (const boId of Object.keys(ks.BO)) {
    const doc = ks.docBieuMau(boId, dienDu(boId));
    kho.luu({ hocVienId: 'HV', congCu: ks.BO[boId].ma, ketQua: ks.cham(boId, doc.traLoi), cauTraLoi: doc.traLoi });
  }
  const gv = kho.moiNhat('HV', { vaiNguoiDoc: 'giao-vien' });
  assert.ok(gv.bịChan.includes('TAM_LY_HOC_DUONG'), 'giáo viên đang đọc được dữ liệu tâm lý');
  const cv = kho.moiNhat('HV', { vaiNguoiDoc: 'co-van' });
  assert.equal(cv.bịChan.includes('TAM_LY_HOC_DUONG'), false, 'cố vấn phải đọc được');
  const chinh = kho.moiNhat('HV', { laChinhChu: true });
  assert.equal(chinh.bịChan.length, 0, 'chính chủ phải đọc được hết');
});

test('Luật riêng tư khai đủ cho MỌI công cụ, kèm lý do', () => {
  for (const [ma] of CONG_CU_INDEX) {
    const lt = RIENG_TU[ma];
    assert.ok(lt, `${ma} chưa có luật riêng tư`);
    assert.ok(Array.isArray(lt.aiDoc), `${ma} chưa khai ai đọc được`);
    assert.equal(typeof lt.luuCauTho, 'boolean');
    assert.ok(lt.viSao && lt.viSao.length > 20, `${ma} không nói lý do`);
  }
});

test('Mỗi lần làm là một bản ghi mới — không ghi đè, giữ được xu hướng', () => {
  const kho = new KhoKhaoSat({});
  const doc = ks.docBieuMau('disc', dienDu('disc'));
  for (let i = 0; i < 3; i++) kho.luu({ hocVienId: 'HV', congCu: 'DISC', ketQua: ks.cham('disc', doc.traLoi), cauTraLoi: doc.traLoi });
  assert.equal(kho.lichSu('HV', 'DISC').length, 3);
  assert.equal(kho.moiNhat('HV', { laChinhChu: true }).soCo, 1, 'moiNhat chỉ trả bản mới nhất');
});

test('Xoá theo yêu cầu thì xoá thật', () => {
  const kho = new KhoKhaoSat({});
  const doc = ks.docBieuMau('disc', dienDu('disc'));
  kho.luu({ hocVienId: 'HV', congCu: 'DISC', ketQua: ks.cham('disc', doc.traLoi), cauTraLoi: doc.traLoi });
  kho.luu({ hocVienId: 'KHAC', congCu: 'DISC', ketQua: ks.cham('disc', doc.traLoi), cauTraLoi: doc.traLoi });
  const r = kho.xoa('HV');
  assert.equal(r.daXoa, 1);
  assert.equal(kho.lichSu('HV', 'DISC').length, 0);
  assert.equal(kho.lichSu('KHAC', 'DISC').length, 1, 'không được xoá nhầm nhà khác');
});

test('Công cụ không có thật thì từ chối lưu', () => {
  const kho = new KhoKhaoSat({});
  assert.equal(kho.luu({ hocVienId: 'HV', congCu: 'TU_VI', ketQua: {} }).ok, false);
  assert.equal(kho.luu({ congCu: 'DISC', ketQua: {} }).ok, false);
});

// ═══ TRỌN CHUỖI ════════════════════════════════════════════════════════════

test('Làm bài → lưu → đọc lại → dựng được lộ trình sáu chặng', () => {
  const kho = new KhoKhaoSat({});
  for (const [boId, chon] of [['phuong-phap', { diem: 3 }], ['disc', {}], ['mbti', {}], ['tam-ly', { diem: 0 }]]) {
    const doc = ks.docBieuMau(boId, dienDu(boId, chon));
    assert.equal(doc.thieu.length, 0);
    kho.luu({ hocVienId: 'HV', congCu: ks.BO[boId].ma, ketQua: ks.cham(boId, doc.traLoi), cauTraLoi: doc.traLoi });
  }
  const ban = kho.moiNhat('HV', { laChinhChu: true });
  const ketQua = {};
  for (const [ma, b] of Object.entries(ban.ketQua)) ketQua[ma] = b.ketQua;
  const hoSo = dungHoSo({ hocVienId: 'HV', lop: 9, ketQua });
  assert.equal(hoSo.duDeDungLoTrinh, true, hoSo.ketLuan);
  const lt = dungLoTrinh({ hoSo, lop: 9 });
  assert.equal(lt.ok, true, lt.reason || lt.error);
  assert.equal(lt.soChang, 6);
  assert.equal(lt.chang[5].baiTestCua.laThiTongKet, true);
});

test('Chưa biết lớp thì KHÔNG đoán, và nói rõ phải khai ở đâu', () => {
  const kho = new KhoKhaoSat({});
  const doc = ks.docBieuMau('phuong-phap', dienDu('phuong-phap', { diem: 3 }));
  kho.luu({ hocVienId: 'HV', congCu: 'PHUONG_PHAP_HOC', ketQua: ks.cham('phuong-phap', doc.traLoi), cauTraLoi: doc.traLoi });
  const ban = kho.moiNhat('HV', { laChinhChu: true });
  const ketQua = {};
  for (const [ma, b] of Object.entries(ban.ketQua)) ketQua[ma] = b.ketQua;
  const lt = dungLoTrinh({ hoSo: dungHoSo({ hocVienId: 'HV', lop: null, ketQua }), lop: null });
  assert.equal(lt.ok, false);
  assert.equal(lt.error, 'CHƯA_BIẾT_LỚP');
  assert.match(lt.reason, /không đoán/);
  assert.ok(lt.canGi && lt.canGi.length > 20, 'phải nói khai lớp ở đâu');
});

test('Kết quả khảo sát ĐỔI được nhịp học — không phải bảng trang trí', () => {
  const lam = (tapTrung, apLuc) => {
    const kho = new KhoKhaoSat({});
    const dPP = ks.deBai('phuong-phap');
    const fPP = {};
    for (const c of dPP.cau) fPP[`c_${c.so}`] = String(c.mien === 'TAP_TRUNG' ? tapTrung : 3);
    const docPP = ks.docBieuMau('phuong-phap', fPP);
    kho.luu({ hocVienId: 'H', congCu: 'PHUONG_PHAP_HOC', ketQua: ks.cham('phuong-phap', docPP.traLoi), cauTraLoi: docPP.traLoi });

    const dTL = ks.deBai('tam-ly');
    const fTL = {};
    for (const c of dTL.cau) fTL[`c_${c.so}`] = String(c.mien === 'AP_LUC' ? apLuc : 0);
    const docTL = ks.docBieuMau('tam-ly', fTL);
    kho.luu({ hocVienId: 'H', congCu: 'TAM_LY_HOC_DUONG', ketQua: ks.cham('tam-ly', docTL.traLoi), cauTraLoi: docTL.traLoi });

    const ban = kho.moiNhat('H', { laChinhChu: true });
    const kq = {};
    for (const [ma, b] of Object.entries(ban.ketQua)) kq[ma] = b.ketQua;
    return dungLoTrinh({ hoSo: dungHoSo({ hocVienId: 'H', lop: 9, ketQua: kq }), lop: 9 });
  };
  const binhThuong = lam(3, 0);
  const khoTapTrung = lam(1, 0);
  const apLucCao = lam(3, 4);
  assert.equal(binhThuong.ok && khoTapTrung.ok && apLucCao.ok, true);
  assert.ok(khoTapTrung.nhip.phutMoiBuoi < binhThuong.nhip.phutMoiBuoi, 'khó tập trung phải rút buổi ngắn lại');
  assert.ok(apLucCao.nhip.buoiMoiTuan < binhThuong.nhip.buoiMoiTuan, 'áp lực cao phải giảm buổi');
});
