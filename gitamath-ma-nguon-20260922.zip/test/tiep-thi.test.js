'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  TIẾP THỊ NỘI DUNG VÀ VIDEO HƯỚNG DẪN
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Nội dung tiếp thị của một nơi dạy trẻ con hỏng theo một kiểu rất riêng:
 *  nó KHÔNG hỏng, nó chỉ hơi quá tay. Một con số làm tròn lên, một lời hứa
 *  nghe cho êm, một lời chứng thực không có thật. Không câu nào sai rõ ràng
 *  tới mức ai đó phải đứng lên nói, và cộng lại thì cả trang là một lời hứa.
 *
 *  Nên các mục dưới đây canh đúng chỗ ấy: mọi con số phải truy được về một
 *  tệp mã, và mọi câu phải qua được bộ luật nội dung.
 * ═══════════════════════════════════════════════════════════════════════════
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const luat = require('../src/tiep-thi/luat-noi-dung');
const DoThi = require('../src/tiep-thi/do-thi');
const VongCaiTien = require('../src/tiep-thi/vong-cai-tien');
const xuong = require('../src/tiep-thi/xuong-noi-dung');
const trangTinh = require('../src/tiep-thi/dung-trang-tinh');
const kichBan = require('../src/xuong-video/kich-ban');

// ── Luật nội dung ────────────────────────────────────────────────────────

test('Luật nội dung chặn lời hứa kết quả học tập', () => {
  for (const t of [
    'Chỉ trong 3 tuần con sẽ giỏi toán',
    'Chúng tôi cam kết học viên tiến bộ',
    'Phương pháp 100% hiệu quả',
  ]) {
    const r = luat.soi(t);
    assert.equal(r.dat, false, `lọt: ${t}`);
    assert.ok(r.loi.some((x) => x.ma === 'hua-ket-qua'));
  }
});

test('Luật nội dung chặn giọng máy, và nói rõ vì sao từng cụm là giọng máy', () => {
  const r = luat.soi('Trong thời đại số, đây là giải pháp toàn diện mang tính đột phá.');
  assert.equal(r.dat, false);
  const g = r.loi.filter((x) => x.ma === 'giong-may');
  assert.ok(g.length >= 2);
  for (const x of g) assert.ok(x.vi.length > 15, `cụm "${x.chiTiet}" bị gạch mà không nói vì sao`);
});

test('Phép đo nhồi từ khoá KHÔNG báo oan văn xuôi bình thường', () => {
  // Ba lỗi báo oan CÓ THẬT của bản đầu, cả ba đều là văn sạch:
  //   · tên khoá JSON bị đếm như chữ
  //   · đoạn 40 từ lặp "đúng" ba lần
  //   · lời đọc gọi người xem là "anh/chị" ở mỗi chương
  const doiTuong = { tieu: 'Học thế nào', muc: [{ ten: 'Đúng thứ tự', y: 'Đi đúng đường.' }] };
  assert.equal(luat.soi(doiTuong).dat, true, 'tên khoá bị đếm như chữ');

  const ngan = 'Hệ thống chỉ ra đúng dạng cần quay lại. Làm đúng thứ tự thì không phải học lại từ đầu, '
    + 'và đúng chỗ hổng mới là chỗ cần thời gian.';
  assert.equal(luat.soi(ngan).dat, true, 'đoạn ngắn bị phạt oan');

  // Lời đọc THẬT do bộ soạn kịch bản sinh ra — không phải một vòng lặp dán
  // cùng một câu ba mươi lần. Văn bản bịa kiểu ấy lặp một cách bệnh hoạn mà
  // văn thật không bao giờ lặp, nên nó kiểm nhầm thứ cần kiểm.
  const kb = require('../src/xuong-video/kich-ban');
  for (const vai of Object.keys(kb.VAI)) {
    const k = kb.soan({
      tep: 'x.html', ten: 'Trung tâm chỉ huy', duong: '/ui/x.html',
      de: 'Nơi quản trị điều phối trợ lý chuyên môn, bảo mật và khôi phục hệ thống.',
      viec: ['Xem toàn cảnh hệ thống', 'Tổng động viên', 'Chụp ảnh hệ thống', 'Xem nhật ký'],
      mucQuyen: 'quan-tri', soCongGoi: 64,
    }, vai);
    assert.equal(k.ok, true, `lời đọc thật cho vai ${vai} bị phạt oan: ${JSON.stringify(k.viPham)}`);
  }
});

test('Phép đo nhồi từ khoá VẪN bắt được một trang nhồi thật', () => {
  const nhoi = Array.from({ length: 40 },
    () => 'gia sư toán lớp năm uy tín. Trung tâm gia sư toán lớp năm.').join(' ');
  const r = luat.soi(nhoi);
  assert.equal(r.dat, false, 'nhồi thật mà không bắt được thì phép đo vô dụng');
  assert.ok(r.loi.some((x) => x.ma === 'nhoi-tu-khoa'));
});

test('Phép đo nhồi TẮT ĐƯỢC cho bảng dữ liệu, nhưng ba luật kia vẫn chạy', () => {
  // Bảng đủ dài để phép đo văn xuôi thật sự chạy tới — dưới ngưỡng thì mục
  // kiểm này không kiểm gì cả, chỉ trông như đang kiểm.
  const bang = Array.from({ length: 80 },
    (_, i) => `Màn hình số ${i} · giáo viên xem · học viên thực hiện · phụ huynh xem · quản trị duyệt`).join(' ');
  assert.ok(luat.soi(bang, { doNhoi: true }).doDaiCoNghia > luat.DAI_TOI_THIEU_DO_NHOI,
    'bảng thử quá ngắn nên phép đo không chạy tới — mục kiểm này sẽ xanh giả');
  assert.equal(luat.soi(bang, { doNhoi: true }).dat, false, 'bảng dùng phép đo văn xuôi thì báo oan');
  assert.equal(luat.soi(bang, { doNhoi: false }).dat, true);
  // Nhưng một lời hứa nằm trong ô bảng vẫn là một lời hứa.
  assert.equal(luat.soi(`${bang} Chỉ 2 tuần là con giỏi toán.`, { doNhoi: false }).dat, false);
});

// ── Đồ thị tri thức ──────────────────────────────────────────────────────

test('Đồ thị từ chối nút và cạnh sai loại — không lặng lẽ nhận', () => {
  const d = new DoThi();
  assert.throws(() => d.themNut('loai-la', {}), /chưa khai/);
  const y = d.themNut('y-dinh', { id: 'y1' });
  const n = d.themNut('nhom', { id: 'n1' });
  assert.throws(() => d.themCanh('thuoc-nhom', 'n1', 'y1'), /phải nối/);
  assert.throws(() => d.themCanh('thuoc-nhom', 'y1', 'khong-co'), /không có/);
  assert.ok(d.themCanh('thuoc-nhom', y.id, n.id));
});

test('Đồ thị nói ra mảng nội dung chưa gắn với câu hỏi nào', () => {
  const d = new DoThi();
  d.themNut('mang-noi-dung', { id: 'm1', ten: 'Mảng lạc' });
  const s = d.soi();
  assert.deepEqual(s.mangKhongGanYDinh, ['m1']);
  assert.match(s.ghiChu, /chưa biết để trả lời câu hỏi gì/);
});

// ── Xưởng nội dung ───────────────────────────────────────────────────────

test('Kho rỗng thì mảng KHÔNG được sinh ra — thà trang thưa còn hơn số bịa', () => {
  const t = xuong.soanTrang(null);       // không có hệ thống nào
  for (const m of t.mang) {
    assert.ok(m.nguonSo.every((n) => n.giaTri != null), `mảng ${m.ma} in số không có nguồn`);
  }
  // Mảng cần số liệu từ kho phải bị bỏ, và bỏ có lý do đọc được.
  for (const b of t.boQua) {
    assert.ok(b.vi && b.vi.length > 20, `bỏ mảng ${b.ma} mà không nói vì sao`);
  }
});

test('Mọi con số in ra trang đều truy được về một tệp mã', () => {
  const sl = xuong.docSoLieu(null);
  for (const [k, v] of Object.entries(sl.so)) {
    assert.ok(sl.nguon[k], `số "${k}" = ${v} không có nguồn`);
    assert.match(sl.nguon[k], /src\/|kho |lực lượng/, `nguồn của "${k}" không chỉ tới đâu cả`);
  }
});

test('Mọi mảng nội dung soạn ra đều qua được luật nội dung', () => {
  const sl = xuong.docSoLieu(null);
  for (const ma of Object.keys(xuong.MANG)) {
    const m = xuong.vietMang(ma, sl);
    if (!m.ok) { assert.notEqual(m.loi, 'KHONG_QUA_LUAT_NOI_DUNG', `mảng ${ma} vi phạm luật`); continue; }
    assert.equal(luat.soi(m.chu).dat, true, `mảng ${ma} không qua luật`);
  }
});

test('Câu trả lời cho "con học bao lâu thì giỏi" KHÔNG hứa', () => {
  const sl = xuong.docSoLieu(null);
  const faq = xuong.vietMang('cau-hoi-thuong-gap', sl);
  if (!faq.ok) return;
  const h = faq.chu.hoi.find((x) => /bao lâu thì giỏi/i.test(x.h));
  assert.ok(h, 'thiếu hẳn câu hỏi khó nhất');
  assert.match(h.d, /không ai trả lời được|không hứa/i);
});

// ── Vòng cải tiến ────────────────────────────────────────────────────────

test('Vòng cải tiến KHÔNG tự sửa trang, và nói rõ vì sao không', () => {
  const v = new VongCaiTien({ doThi: new DoThi() });
  const r = v.chay({ nhatKyChat: [] });
  assert.equal(r.tuApDung, 0);
  assert.equal(v.status().tuSuaDuoc, false);
  assert.match(r.vi, /tối ưu theo lượt bấm sẽ tự đi tới chỗ hứa hẹn/);
});

test('Vòng cải tiến khai rõ chỉ số nào CHƯA nối nguồn', () => {
  const v = new VongCaiTien({ doThi: new DoThi() });
  const c = v.chay({ nhatKyChat: [] }).chuaNoiNguon;
  assert.ok(Object.keys(c).length >= 3);
  for (const [k, vi] of Object.entries(c)) assert.ok(vi.length > 25, `"${k}" khai chưa nối nguồn mà không nói vì sao`);
});

test('Vòng cải tiến tìm được chỗ lệch thật, và mỗi chỗ có bằng chứng', () => {
  const d = new DoThi();
  const v = new VongCaiTien({ doThi: d });
  const nk = Array.from({ length: 6 }, () => ({ viec: 'hoi-tien-do-con', biChan: false, soCongCuCoDuLieu: 0 }));
  const r = v.chay({ nhatKyChat: nk });
  assert.ok(r.lech.length >= 1);
  for (const l of r.lech) {
    assert.ok(l.bangChung && l.bangChung.length > 10, `chỗ lệch "${l.loai}" không có bằng chứng`);
    assert.equal(l.tuSuaDuoc, false);
  }
});

// ── Trang tĩnh cho Cloudflare ────────────────────────────────────────────

test('Trang tĩnh không mang kịch bản và không gọi ra ngoài', () => {
  const t = xuong.soanTrang(null);
  t.soLieu.phienBan = 'test';
  const html = trangTinh.trangChu(t, { ngayDung: '2026-09-22' });
  const loi = trangTinh.soiTrangTinh(html, { tenTep: 'index.html' });
  assert.deepEqual(loi, [], loi.join(' · '));
  assert.equal(/<script/i.test(html), false);
  assert.match(html, /lang="vi"/);
  assert.match(html, /2026-09-22/, 'trang tĩnh phải in ngày đóng băng số liệu');
});

test('Chính sách nội dung của trang tĩnh cấm kịch bản và khung nhúng', () => {
  assert.match(trangTinh.CSP, /script-src 'none'/);
  assert.match(trangTinh.CSP, /frame-ancestors 'none'/);
  assert.match(trangTinh.CSP, /object-src 'none'/);
});

// ── Kịch bản video ───────────────────────────────────────────────────────

const manGia = {
  tep: 'thu.html', ten: 'Màn thử', duong: '/ui/thu.html',
  de: 'Màn này để thử bộ soạn kịch bản, và mô tả phải đủ dài.',
  viec: ['Việc một', 'Việc hai'],
  mucQuyen: 'giao-vien', soCongGoi: 4,
};

test('Kịch bản soạn đủ tám chương cho cả bốn vai', () => {
  for (const vai of Object.keys(kichBan.VAI)) {
    const k = kichBan.soan(manGia, vai);
    assert.equal(k.ok, true, `vai ${vai}: ${JSON.stringify(k.viPham || k.loi)}`);
    assert.equal(k.chuong.length, 8);
    for (const c of k.chuong) assert.ok(c.loi.length > 30, `chương "${c.ten}" quá ngắn`);
  }
});

test('Chương QUYỀN nói đúng sự thật cho từng vai, không nói chung chung', () => {
  const hv = kichBan.soan(manGia, 'LEARNER');
  const gv = kichBan.soan(manGia, 'TEACHER');
  assert.equal(hv.duQuyen, false, 'học viên không đủ quyền cho màn giáo viên');
  assert.equal(gv.duQuyen, true);
  assert.match(hv.chuong[2].loi, /chưa đủ quyền/);
  assert.match(hv.chuong[2].loi, /cố ý, không phải lỗi/);
  assert.match(gv.chuong[2].loi, /mở được đầy đủ/);
});

test('Lời đọc của MỌI kịch bản đều qua luật nội dung', () => {
  for (const vai of Object.keys(kichBan.VAI)) {
    for (const muc of ['cong-khai', 'hoc-vien', 'giao-vien', 'quan-tri']) {
      const k = kichBan.soan({ ...manGia, mucQuyen: muc }, vai);
      assert.equal(k.ok, true, `${vai}/${muc}: ${JSON.stringify(k.viPham)}`);
      assert.equal(luat.soi(k.loiDoc).dat, true, `${vai}/${muc} lời đọc không qua luật`);
    }
  }
});

test('Ước tính thời lượng khớp với nhịp đọc đã khai', () => {
  const k = kichBan.soan(manGia, 'PARENT');
  const theoTu = Math.round((k.tomTat.soTu / 150) * 60);
  assert.equal(k.tomTat.giayUocTinh, theoTu);
  assert.ok(k.tomTat.giayUocTinh > 30 && k.tomTat.giayUocTinh < 400,
    `video ${k.tomTat.giayUocTinh}s — quá ngắn hoặc quá dài để là một video hướng dẫn`);
});
