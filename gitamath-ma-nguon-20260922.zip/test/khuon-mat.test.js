'use strict';
/**
 * ĐĂNG NHẬP BẰNG KHUÔN MẶT THẬT
 *
 * Bộ kiểm này dựng một BỘ XÁC THỰC GIẢ ký bằng khoá elliptic THẬT, rồi bắt
 * máy chủ kiểm. Ký giả mà toán thật: nếu luồng mật mã sai một chỗ thì chữ ký
 * không khớp và mọi mục dưới đây đỏ.
 *
 * Nó canh đúng những chỗ một hệ đăng nhập sinh trắc học hỏng:
 *   · nhận đăng nhập không có cờ xác minh người dùng — tức là nhận cả mã PIN
 *   · nhận khoá cắm rời thay vì sinh trắc học gắn trong máy
 *   · cho dùng lại một thách thức — mở đường cho gói tin phát lại
 *   · bỏ qua bộ đếm không tăng — bỏ qua dấu hiệu có bản sao khoá
 *   · nhận gốc lạ — mở đường cho trang giả mạo
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const KhuonMat = require('../src/an-toan/khuon-mat');
const { doc: docCbor } = require('../src/an-toan/cbor');

const TEN_MAY = 'localhost';
const GOC = 'http://localhost:9999';
const b64 = (b) => Buffer.from(b).toString('base64url');

/** Mã một số nguyên không âm theo CBOR. */
function cborUInt(n) {
  if (n < 24) return Buffer.from([n]);
  if (n < 256) return Buffer.from([0x18, n]);
  const b = Buffer.alloc(3); b[0] = 0x19; b.writeUInt16BE(n, 1); return b;
}
function cborByte(b) {
  const len = b.length;
  const dau = len < 24 ? Buffer.from([0x40 | len])
    : len < 256 ? Buffer.from([0x58, len])
      : (() => { const x = Buffer.alloc(3); x[0] = 0x59; x.writeUInt16BE(len, 1); return x; })();
  return Buffer.concat([dau, b]);
}
function cborChu(s) {
  const b = Buffer.from(s, 'utf8');
  return Buffer.concat([Buffer.from([0x60 | b.length]), b]);
}
function cborNeg(n) {            // n âm
  const m = -1 - n;
  return m < 24 ? Buffer.from([0x20 | m]) : Buffer.from([0x38, m]);
}

/**
 * BỘ XÁC THỰC GIẢ. Sinh một cặp khoá P-256 thật và ký thật; chỉ có phần vỏ
 * dữ liệu là dựng bằng tay.
 */
function boXacThucGia({ maKhoa = crypto.randomBytes(32) } = {}) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const jwk = publicKey.export({ format: 'jwk' });
  const x = Buffer.from(jwk.x, 'base64url');
  const y = Buffer.from(jwk.y, 'base64url');

  // Khoá COSE: {1:2, 3:-7, -1:1, -2:x, -3:y}
  const cose = Buffer.concat([
    Buffer.from([0xa5]),
    cborUInt(1), cborUInt(2),
    cborUInt(3), cborNeg(-7),
    cborNeg(-1), cborUInt(1),
    cborNeg(-2), cborByte(x),
    cborNeg(-3), cborByte(y),
  ]);

  const rpIdHash = crypto.createHash('sha256').update(TEN_MAY).digest();

  const authData = ({ co, boDem, kemKhoa }) => {
    const dau = Buffer.concat([rpIdHash, Buffer.from([co]), (() => {
      const b = Buffer.alloc(4); b.writeUInt32BE(boDem); return b;
    })()]);
    if (!kemKhoa) return dau;
    const dai = Buffer.alloc(2); dai.writeUInt16BE(maKhoa.length);
    return Buffer.concat([dau, Buffer.alloc(16), dai, maKhoa, cose]);
  };

  const clientData = (kieu, thachThuc, goc = GOC) =>
    b64(Buffer.from(JSON.stringify({ type: kieu, challenge: thachThuc, origin: goc }), 'utf8'));

  return {
    maKhoa,
    /** Gói đăng ký. co mặc định: có mặt + đã xác minh + có khoá. */
    dangKy(thachThuc, { co = 0x01 | 0x04 | 0x40, boDem = 0, goc = GOC } = {}) {
      const ad = authData({ co, boDem, kemKhoa: !!(co & 0x40) });
      const att = Buffer.concat([
        Buffer.from([0xa3]),
        cborChu('fmt'), cborChu('none'),
        cborChu('attStmt'), Buffer.from([0xa0]),
        cborChu('authData'), cborByte(ad),
      ]);
      return {
        thachThuc,
        id: b64(maKhoa),
        clientDataJSON: clientData('webauthn.create', thachThuc, goc),
        attestationObject: b64(att),
        gan: 'platform',
      };
    },
    /** Gói đăng nhập, ký thật bằng khoá riêng. */
    dangNhap(thachThuc, { co = 0x01 | 0x04, boDem = 1, goc = GOC, hongChuKy = false } = {}) {
      const ad = authData({ co, boDem, kemKhoa: false });
      const cdj = clientData('webauthn.get', thachThuc, goc);
      const duLieu = Buffer.concat([ad, crypto.createHash('sha256').update(Buffer.from(cdj, 'base64url')).digest()]);
      const s = crypto.createSign('sha256');
      s.update(hongChuKy ? Buffer.concat([duLieu, Buffer.from('x')]) : duLieu);
      s.end();
      return {
        thachThuc,
        clientDataJSON: cdj,
        authenticatorData: b64(ad),
        signature: b64(s.sign(privateKey)),
        gan: 'platform',
      };
    },
  };
}

function moMay() {
  return new KhuonMat({ tenMay: TEN_MAY, cacGoc: [GOC], tenHienThi: 'GITAmath' });
}

/** Đăng ký một khoá rồi trả về (máy, bộ xác thực, khoá đã lưu). */
function daDangKy() {
  const may = moMay();
  const bxt = boXacThucGia();
  const { thachThuc } = may.tuyChonDangKy({ nguoiDungId: 'U1', tenDangNhap: 'co_lan' });
  const r = may.kiemDangKy(bxt.dangKy(thachThuc));
  assert.equal(r.ok, true, `đăng ký phải đạt: ${r.loi || ''}`);
  return { may, bxt, khoa: r.khoa };
}

// ── ĐƯỜNG ĐI ĐÚNG ─────────────────────────────────────────────────────────

test('Khuôn mặt: đăng ký rồi đăng nhập trọn vòng, chữ ký kiểm được bằng toán thật', () => {
  const { may, bxt, khoa } = daDangKy();
  assert.equal(khoa.thuatToan, 'ES256');
  assert.ok(khoa.khoaCong.includes('BEGIN PUBLIC KEY'), 'phải lưu khoá công khai ở dạng PEM');
  assert.equal(khoa.ganTrongMay, true);

  const { thachThuc } = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] });
  const r = may.kiemDangNhap({ ...bxt.dangNhap(thachThuc), khoaDaLuu: khoa });
  assert.equal(r.ok, true, `đăng nhập phải đạt: ${r.loi || ''}`);
  assert.equal(r.boDemMoi, 1);
});

test('Khuôn mặt: máy chủ KHÔNG giữ ảnh và KHÔNG giữ đặc trưng khuôn mặt', () => {
  // Đây là lời hứa trung tâm của cách làm này. Nếu một ngày ai đó thêm trường
  // ảnh vào bản ghi khoá, mục kiểm này phải đỏ ngay.
  const { khoa } = daDangKy();
  const truong = Object.keys(khoa).sort();
  assert.deepEqual(truong, [
    'aaguid', 'boDem', 'dangKyLuc', 'dungLanCuoi', 'ganTrongMay', 'khoaCong', 'maKhoa', 'thuatToan',
  ], 'bản ghi khoá có trường lạ — kiểm xem có phải dữ liệu sinh trắc học không');
  const chuoi = JSON.stringify(khoa).toLowerCase();
  for (const cam of ['anh', 'image', 'photo', 'face', 'embedding', 'dactrung', 'template', 'biometric']) {
    assert.ok(!chuoi.includes(cam), `bản ghi khoá chứa "${cam}" — nghi có dữ liệu sinh trắc học`);
  }
});

// ── NHỮNG CỬA PHẢI ĐÓNG ───────────────────────────────────────────────────

test('Khuôn mặt: không có cờ xác minh người dùng thì TỪ CHỐI — đây là chỗ phân biệt sinh trắc học với mã PIN', () => {
  const may = moMay();
  const bxt = boXacThucGia();
  const { thachThuc } = may.tuyChonDangKy({ nguoiDungId: 'U1', tenDangNhap: 'x' });
  // cờ: có mặt + có khoá, nhưng KHÔNG có đã-xác-minh
  const r = may.kiemDangKy(bxt.dangKy(thachThuc, { co: 0x01 | 0x40 }));
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'CHUA_XAC_MINH_SINH_TRAC_HOC');
});

test('Khuôn mặt: đăng nhập không có cờ xác minh cũng bị từ chối', () => {
  const { may, bxt, khoa } = daDangKy();
  const { thachThuc } = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] });
  const r = may.kiemDangNhap({ ...bxt.dangNhap(thachThuc, { co: 0x01 }), khoaDaLuu: khoa });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'CHUA_XAC_MINH_SINH_TRAC_HOC');
});

test('Khuôn mặt: khoá cắm rời bị từ chối — yêu cầu là sinh trắc học gắn trong máy', () => {
  const may = moMay();
  const bxt = boXacThucGia();
  const { thachThuc } = may.tuyChonDangKy({ nguoiDungId: 'U1', tenDangNhap: 'x' });
  const r = may.kiemDangKy({ ...bxt.dangKy(thachThuc), gan: 'cross-platform' });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'KHONG_PHAI_BO_XAC_THUC_GAN_TRONG_MAY');
});

test('Khuôn mặt: thách thức dùng một lần — gói tin phát lại bị chặn', () => {
  const { may, bxt, khoa } = daDangKy();
  const { thachThuc } = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] });
  const goi = bxt.dangNhap(thachThuc);
  assert.equal(may.kiemDangNhap({ ...goi, khoaDaLuu: khoa }).ok, true);
  // Gửi lại y nguyên gói vừa rồi — đây đúng là hình dạng của tấn công phát lại.
  const lai = may.kiemDangNhap({ ...goi, khoaDaLuu: khoa });
  assert.equal(lai.ok, false);
  assert.equal(lai.loi, 'THACH_THUC_HET_HAN_HOAC_DA_DUNG');
});

test('Khuôn mặt: thách thức đăng ký không dùng được để đăng nhập', () => {
  const { may, bxt, khoa } = daDangKy();
  const { thachThuc } = may.tuyChonDangKy({ nguoiDungId: 'U1', tenDangNhap: 'x' });
  const r = may.kiemDangNhap({ ...bxt.dangNhap(thachThuc), khoaDaLuu: khoa });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'THACH_THUC_SAI_VIEC');
});

test('Khuôn mặt: gốc lạ bị từ chối — chặn trang giả mạo', () => {
  const { may, bxt, khoa } = daDangKy();
  const { thachThuc } = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] });
  const r = may.kiemDangNhap({ ...bxt.dangNhap(thachThuc, { goc: 'http://gitamath-that.com' }), khoaDaLuu: khoa });
  assert.equal(r.ok, false);
  assert.ok(r.loi.startsWith('CLIENT_DATA_SAI'), r.loi);
});

test('Khuôn mặt: chữ ký sai bị từ chối', () => {
  const { may, bxt, khoa } = daDangKy();
  const { thachThuc } = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] });
  const r = may.kiemDangNhap({ ...bxt.dangNhap(thachThuc, { hongChuKy: true }), khoaDaLuu: khoa });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'CHU_KY_SAI');
});

test('Khuôn mặt: khoá của người khác không mở được tài khoản này', () => {
  const { may, khoa } = daDangKy();
  const nguoiKhac = boXacThucGia();
  const { thachThuc } = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] });
  const r = may.kiemDangNhap({ ...nguoiKhac.dangNhap(thachThuc), khoaDaLuu: khoa });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'CHU_KY_SAI');
});

test('Khuôn mặt: bộ đếm không tăng là nghi có bản sao khoá', () => {
  const { may, bxt, khoa } = daDangKy();
  const t1 = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] }).thachThuc;
  const r1 = may.kiemDangNhap({ ...bxt.dangNhap(t1, { boDem: 5 }), khoaDaLuu: khoa });
  assert.equal(r1.ok, true);
  khoa.boDem = r1.boDemMoi;

  const t2 = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] }).thachThuc;
  const r2 = may.kiemDangNhap({ ...bxt.dangNhap(t2, { boDem: 5 }), khoaDaLuu: khoa });
  assert.equal(r2.ok, false);
  assert.equal(r2.loi, 'BO_DEM_KHONG_TANG_NGHI_CO_BAN_SAO');
});

test('Khuôn mặt: bộ xác thực không đếm (luôn báo 0) vẫn dùng được — chuẩn cho phép', () => {
  // Một số bộ xác thực gắn trong máy không đếm và luôn báo 0. Chặn chúng là
  // chặn nhầm người dùng thật, nên chỉ chặn khi CẢ HAI lần đều khác 0.
  const { may, bxt, khoa } = daDangKy();
  for (let i = 0; i < 3; i++) {
    const t = may.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] }).thachThuc;
    const r = may.kiemDangNhap({ ...bxt.dangNhap(t, { boDem: 0 }), khoaDaLuu: khoa });
    assert.equal(r.ok, true, `lần ${i + 1} phải đạt: ${r.loi || ''}`);
  }
});

test('Khuôn mặt: sai định danh máy chủ bị từ chối', () => {
  const { bxt, khoa } = daDangKy();
  const mayKhac = new KhuonMat({ tenMay: 'gitamath-gia.vn', cacGoc: [GOC] });
  const { thachThuc } = mayKhac.tuyChonDangNhap({ maKhoaChoPhep: [khoa.maKhoa] });
  const r = mayKhac.kiemDangNhap({ ...bxt.dangNhap(thachThuc), khoaDaLuu: khoa });
  assert.equal(r.ok, false);
  assert.equal(r.loi, 'SAI_MAY_CHU');
});

test('Khuôn mặt: tuỳ chọn gửi cho trình duyệt đòi đúng ba điều kiện', () => {
  const may = moMay();
  const { tuyChon } = may.tuyChonDangKy({ nguoiDungId: 'U1', tenDangNhap: 'x' });
  assert.equal(tuyChon.authenticatorSelection.authenticatorAttachment, 'platform',
    'không đòi bộ xác thực gắn trong máy thì khoá cắm rời cũng vào được');
  assert.equal(tuyChon.authenticatorSelection.userVerification, 'required',
    'không đòi xác minh người dùng thì một cú chạm cũng qua');
  assert.equal(tuyChon.rp.id, TEN_MAY);
  assert.equal(may.tuyChonDangNhap().tuyChon.userVerification, 'required');
});

test('Khuôn mặt: bộ đọc CBOR từ chối dữ liệu dựng để đánh lừa', () => {
  // Đây là mã đọc dữ liệu từ bên ngoài, nằm trong đường đăng nhập. Nó phải
  // từ chối sớm chứ không cố hiểu.
  const thu = (hex, vi) => {
    assert.throws(() => docCbor(Buffer.from(hex, 'hex')), undefined, vi);
  };
  thu('a2010201020101', 'khoá trùng trong bảng');
  thu('a10102ff', 'byte thừa phía sau');
  thu('5fff', 'độ dài bất định');
  thu('fb3ff0000000000000', 'số thực');
  thu('c074323031332d30332d32315432303a30343a30305a', 'thẻ ngữ nghĩa');
  thu('5affffffff', 'độ dài khai vượt dữ liệu thật');
});

// ── NỐI VÀO HỆ TÀI KHOẢN ──────────────────────────────────────────────────

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { Database } = require('../src/data/repository');
const AccountService = require('../src/security/accounts');

function moHe() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'km-acc-'));
  const db = new Database({ dir });
  const acc = new AccountService({
    users: db.collection('users', { indexes: ['role', 'username'] }),
    learners: db.collection('learners', { indexes: [] }),
    classes: db.collection('classes', { indexes: [] }),
    khuonMat: moMay(),
  });
  return { db, acc };
}

function vaoBang(acc, vai) {
  const ten = `nguoi_${vai.toLowerCase()}`;
  const mk = 'Trung6Chim9Bay2Xa!';
  acc.create({ username: ten, password: mk, role: vai, fullName: 'Người thử' });
  return acc.login({ username: ten, password: mk }).token;
}

const DONG_Y_DU = { ten: 'Trần Quốc Bảo', quanHe: 'bố', luc: Date.now(), coTheRutLai: true };

test('Tài khoản: gắn khuôn mặt cho học viên PHẢI có người giám hộ đồng ý', () => {
  // Đặc trưng khuôn mặt là dữ liệu sinh trắc học; của trẻ em thì nhạy cảm gấp
  // đôi. Dù cách làm này không giữ đặc trưng ấy ở máy chủ, việc gắn thân thể
  // một đứa trẻ vào một tài khoản vẫn là quyết định của người lớn chịu trách
  // nhiệm cho em.
  const { db, acc } = moHe();
  const tok = vaoBang(acc, 'LEARNER');
  const x = acc.xinDangKyKhuonMat(tok);
  assert.equal(x.ok, true);
  const bxt = boXacThucGia();

  const khong = acc.ghiKhuonMat(tok, bxt.dangKy(x.thachThuc));
  assert.equal(khong.ok, false);
  assert.equal(khong.error, 'THIEU_DONG_Y_NGUOI_GIAM_HO');
  assert.ok(khong.canGi.includes('rút lại'), 'phải nói rõ đồng ý này rút lại được');
  db.close();
});

test('Tài khoản: đồng ý thiếu một vế cũng không nhận', () => {
  const { db, acc } = moHe();
  const tok = vaoBang(acc, 'LEARNER');
  const bxt = boXacThucGia();
  for (const thieu of ['ten', 'quanHe', 'luc', 'coTheRutLai']) {
    const d = { ...DONG_Y_DU };
    delete d[thieu];
    const x = acc.xinDangKyKhuonMat(tok);
    const r = acc.ghiKhuonMat(tok, bxt.dangKy(x.thachThuc), { dongYGiamHo: d });
    assert.equal(r.ok, false, `thiếu "${thieu}" mà vẫn nhận`);
    assert.equal(r.error, 'THIEU_DONG_Y_NGUOI_GIAM_HO');
  }
  db.close();
});

test('Tài khoản: có đồng ý đầy đủ thì học viên gắn được, và gỡ ra được bất cứ lúc nào', () => {
  const { db, acc } = moHe();
  const tok = vaoBang(acc, 'LEARNER');
  const bxt = boXacThucGia();
  const x = acc.xinDangKyKhuonMat(tok);
  const r = acc.ghiKhuonMat(tok, bxt.dangKy(x.thachThuc), { dongYGiamHo: DONG_Y_DU });
  assert.equal(r.ok, true, r.error || '');

  const ds = acc.dsKhuonMat(tok);
  assert.equal(ds.soMay, 1);
  assert.equal(ds.may[0].coDongYGiamHo, true);
  // Danh sách trả ra KHÔNG được mang khoá công khai hay dữ liệu nhạy cảm.
  assert.ok(!('khoaCong' in ds.may[0]), 'không đưa khoá công khai ra ngoài');

  // Rút lại đồng ý = gỡ máy. Một đồng ý không rút lại được thì không phải đồng ý.
  assert.equal(acc.goKhuonMat(tok, r.maKhoa).ok, true);
  assert.equal(acc.dsKhuonMat(tok).soMay, 0);
  db.close();
});

test('Tài khoản: giáo viên và quản trị không cần đồng ý giám hộ', () => {
  for (const vai of ['TEACHER', 'ADMIN']) {
    const { db, acc } = moHe();
    const tok = vaoBang(acc, vai);
    const bxt = boXacThucGia();
    const x = acc.xinDangKyKhuonMat(tok);
    const r = acc.ghiKhuonMat(tok, bxt.dangKy(x.thachThuc));
    assert.equal(r.ok, true, `${vai}: ${r.error || ''}`);
    db.close();
  }
});

test('Tài khoản: không đăng nhập thì KHÔNG gắn được khuôn mặt', () => {
  // Tin cậy phải bắt nguồn từ một lần xác thực đã có. Không có lối nào gắn
  // khuôn mặt từ con số không — nếu có thì ai cũng gắn mặt mình vào tài khoản
  // của người khác.
  const { db, acc } = moHe();
  assert.equal(acc.xinDangKyKhuonMat(null).error, 'INVALID_SESSION');
  assert.equal(acc.xinDangKyKhuonMat('vé-bịa-ra').error, 'INVALID_SESSION');
  db.close();
});

test('Tài khoản: đăng nhập bằng khuôn mặt vẫn qua hàng rào khoá tài khoản', () => {
  // Một lối vào mới mà bỏ qua hàng rào cũ thì chính nó là lỗ thủng.
  const { db, acc } = moHe();
  const tok = vaoBang(acc, 'TEACHER');
  const bxt = boXacThucGia();
  const x = acc.xinDangKyKhuonMat(tok);
  const dk = acc.ghiKhuonMat(tok, bxt.dangKy(x.thachThuc));
  assert.equal(dk.ok, true);

  // Sai nhiều lần liên tiếp thì phải bị khoá, y như sai mật khẩu.
  let daKhoa = false;
  for (let i = 0; i < 12; i++) {
    const xv = acc.xinDangNhapKhuonMat({ username: 'nguoi_teacher' });
    const goi = bxt.dangNhap(xv.thachThuc);
    const r = acc.dangNhapKhuonMat({ ...goi, maKhoa: dk.maKhoa, signature: 'AAAA' });
    if (r.error === 'LOCKED_OUT') { daKhoa = true; break; }
  }
  assert.equal(daKhoa, true, 'sai liên tiếp mà không bị khoá — lối vào này đang bỏ qua hàng rào');
  db.close();
});

test('Tài khoản: khoá lạ không lộ ra tài khoản nào tồn tại', () => {
  const { db, acc } = moHe();
  vaoBang(acc, 'TEACHER');
  const r = acc.dangNhapKhuonMat({ maKhoa: 'ma-khoa-khong-co-that' });
  assert.equal(r.error, 'INVALID_CREDENTIALS', 'phải trả lỗi chung, không nói rõ khoá không tồn tại');
  db.close();
});

test('Tài khoản: trần năm máy cho mỗi người', () => {
  const { db, acc } = moHe();
  const tok = vaoBang(acc, 'TEACHER');
  for (let i = 0; i < 5; i++) {
    const x = acc.xinDangKyKhuonMat(tok);
    assert.equal(acc.ghiKhuonMat(tok, boXacThucGia().dangKy(x.thachThuc)).ok, true, `máy thứ ${i + 1}`);
  }
  const x = acc.xinDangKyKhuonMat(tok);
  const r = acc.ghiKhuonMat(tok, boXacThucGia().dangKy(x.thachThuc));
  assert.equal(r.ok, false);
  assert.equal(r.error, 'QUA_NAM_MAY_DA_DANG_KY');
  db.close();
});

test('Tài khoản: mật khẩu vẫn dùng được sau khi gắn khuôn mặt', () => {
  // Đây là lối vào THÊM, không thay lối cũ. Mất camera, hỏng cảm biến, đổi
  // máy — vẫn phải vào được. Một hệ chỉ có đúng một cách vào là một hệ khoá
  // được người dùng ra ngoài.
  const { db, acc } = moHe();
  const tok = vaoBang(acc, 'TEACHER');
  const x = acc.xinDangKyKhuonMat(tok);
  assert.equal(acc.ghiKhuonMat(tok, boXacThucGia().dangKy(x.thachThuc)).ok, true);
  const lai = acc.login({ username: 'nguoi_teacher', password: 'Trung6Chim9Bay2Xa!' });
  assert.equal(lai.ok, true, 'gắn khuôn mặt xong mà mật khẩu hết dùng được');
  db.close();
});
