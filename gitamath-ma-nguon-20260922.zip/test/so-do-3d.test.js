'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  SƠ ĐỒ TƯ DUY BA CHIỀU
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Một sơ đồ kiến thức hỏng theo những kiểu rất riêng, và chúng đều IM LẶNG —
 *  hình vẫn vẽ ra, vẫn đẹp, chỉ là sai:
 *
 *      · Nối tới một dạng không có trong hình  → đường đi mất một đầu
 *      · Chú thích đếm thiếu                   → người xem đếm chấm ra một số,
 *                                                đọc chú thích ra số khác
 *      · Vị trí đổi theo mỗi lần dựng          → in hai lần ra hai tờ khác nhau
 *      · Nhãn chồng lên nhãn                   → vùng giữa không đọc được chữ nào
 *      · Lọt mã kịch bản vào tệp SVG           → một tệp ảnh gửi đi thành một
 *                                                cái bẫy chạy được
 *
 *  Hai lỗi giữa danh sách trên là lỗi CÓ THẬT của bản đầu, bắt được bằng cách
 *  dựng hình ra rồi NHÌN. Các mục dưới đây canh cả năm, để lần sau máy bắt.
 * ═══════════════════════════════════════════════════════════════════════════
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const H = require('../src/curriculum/hierarchy');
const KG = require('../src/so-do-tu-duy/khong-gian');
const SD = require('../src/so-do-tu-duy/so-do');
const VE = require('../src/so-do-tu-duy/ve');

// ── Không gian ba chiều ────────────────────────────────────────────────────

test('Xoay không góc nào thì điểm đứng yên', () => {
  const p = { x: 3, y: -4, z: 12 };
  const q = KG.xoay(p, 0, 0);
  assert.equal(q.x, 3);
  assert.equal(q.y, -4);
  assert.equal(q.z, 12);
});

test('Xoay giữ nguyên khoảng cách tới gốc — nếu không thì hình bị kéo méo', () => {
  const p = { x: 120, y: -75, z: 40 };
  const dai = (v) => Math.hypot(v.x, v.y, v.z);
  for (const [a, b] of [[0.4, 0.2], [1.7, -0.9], [Math.PI, Math.PI / 3]]) {
    assert.ok(Math.abs(dai(KG.xoay(p, a, b)) - dai(p)) < 1e-9, `xoay ${a}/${b} làm đổi độ dài`);
  }
});

test('Điểm ở SAU mắt thì không chiếu, trả về null', () => {
  // Chia cho một số âm ra một điểm lật ngược — trên màn hình là một vệt bay
  // ngang qua giữa hình mà không ai hiểu nó từ đâu ra.
  assert.equal(KG.chieu({ x: 10, y: 10, z: -KG.TIEU_CU }), null);
  assert.equal(KG.chieu({ x: 10, y: 10, z: -KG.TIEU_CU - 500 }), null);
  assert.ok(KG.chieu({ x: 10, y: 10, z: 0 }));
});

test('Xa thì nhỏ lại — đúng chiều, không ngược', () => {
  const gan = KG.chieu({ x: 100, y: 0, z: -300 });
  const xa = KG.chieu({ x: 100, y: 0, z: 300 });
  assert.ok(gan.k > xa.k, 'điểm gần phải có tỉ lệ lớn hơn điểm xa');
  assert.ok(Math.abs(gan.x) > Math.abs(xa.x), 'điểm gần phải lệch ra xa tâm hơn');
});

test('Chiếu cả danh sách thì xếp XA TRƯỚC — thứ tự vẽ chính là thứ tự che khuất', () => {
  const ds = KG.chieuDanhSach(
    [{ ma: 'a', x: 0, y: 0, z: -200 }, { ma: 'b', x: 0, y: 0, z: 300 }, { ma: 'c', x: 0, y: 0, z: 0 }],
    {},
  );
  assert.deepEqual(ds.map((d) => d.ma), ['b', 'c', 'a']);
  for (let i = 1; i < ds.length; i += 1) assert.ok(ds[i - 1].sau >= ds[i].sau);
});

test('Độ mờ theo xa: có sàn, và không bao giờ vượt 1', () => {
  assert.equal(KG.moTheoSau(-9999), 1);
  assert.equal(KG.moTheoSau(9999), 0.25);
  const giua = KG.moTheoSau(0);
  assert.ok(giua > 0.25 && giua < 1, `độ mờ giữa khoảng ra ${giua}`);
  // Sàn phải đủ sáng để còn đọc được chữ. Một sơ đồ kiến thức mà chữ mờ tới
  // mức không đọc được thì không còn là sơ đồ kiến thức.
  assert.ok(KG.moTheoSau(9999) >= 0.2);
});

test('Vị trí trên trụ xoắn: tầng cao thì nằm CAO trên màn hình', () => {
  const duoi = KG.viTriTruXoan(0, 6, 0, 5);
  const tren = KG.viTriTruXoan(0, 6, 4, 5);
  // Trục y của màn hình hướng xuống, nên tầng cao có y NHỎ hơn.
  assert.ok(tren.y < duoi.y, `tầng cao (${tren.y}) phải nằm trên tầng thấp (${duoi.y})`);
});

// ── Dựng sơ đồ ─────────────────────────────────────────────────────────────

test('Toàn cảnh lấy ĐỦ mọi dạng có thật, không thêm không bớt', () => {
  const s = SD.dung({ kieu: 'toan-canh' });
  assert.equal(s.ok, true);
  assert.equal(s.nut.length, H.FORMS.length);
  const co = new Set(s.nut.map((n) => n.ma));
  for (const f of H.FORMS) assert.ok(co.has(f.code), `thiếu dạng ${f.code}`);
});

test('Mọi nút là một dạng CÓ THẬT — không bịa nút cho đẹp hình', () => {
  const that = new Set(H.FORMS.map((f) => f.code));
  for (const n of SD.dung({ kieu: 'toan-canh' }).nut) {
    assert.ok(that.has(n.ma), `nút "${n.ma}" không có trong chương trình`);
  }
});

test('Mọi cạnh là một quan hệ tiên quyết ĐÃ KHAI — không nối cho đỡ trống', () => {
  const khai = new Set();
  for (const f of H.FORMS) for (const p of f.prereq || []) khai.add(`${p}→${f.code}`);
  const s = SD.dung({ kieu: 'toan-canh' });
  assert.ok(s.canh.length > 0, 'sơ đồ không có cạnh nào thì không phải sơ đồ');
  for (const c of s.canh) assert.ok(khai.has(`${c.tu}→${c.den}`), `cạnh bịa: ${c.tu} → ${c.den}`);
});

test('Bộ tự soi của sơ đồ ĐẠT, và nó soi đúng những thứ đáng soi', () => {
  const r = SD.soi();
  assert.equal(r.dat, true, `soi không đạt: ${r.loi.join(' · ')}`);
  assert.equal(r.soNut, H.FORMS.length);
  assert.ok(r.soCanh > 0);
});

test('Mọi dạng đều xếp được nhóm — chú thích thiếu còn tệ hơn không có', () => {
  // Lỗi có thật: 18 dạng tiếng Anh và liên môn rơi ngoài bảng màu, nên chú
  // thích cộng ra 86 trong khi hình có 104 chấm.
  const s = SD.dung({ kieu: 'toan-canh' });
  const khongNhom = s.nut.filter((n) => !n.khoi);
  assert.equal(khongNhom.length, 0, `dạng chưa có nhóm: ${khongNhom.map((n) => n.ma).join(', ')}`);
  const tong = Object.values(s.thongKe.theoKhoi).reduce((a, b) => a + b, 0);
  assert.equal(tong, s.nut.length, 'chú thích cộng không ra đúng số nút');
  for (const f of H.FORMS) assert.ok(SD.khoiCua(f.code), `dạng ${f.code} không suy ra nhóm nào`);
});

test('Mỗi nhóm trong chú thích đều có tên đọc được và màu riêng', () => {
  const mau = new Set();
  for (const k of Object.keys(SD.MAU_KHOI)) {
    assert.ok(SD.TEN_KHOI[k], `nhóm ${k} không có tên đọc được`);
    assert.match(SD.MAU_KHOI[k], /^#[0-9a-f]{6}$/i);
    assert.ok(!mau.has(SD.MAU_KHOI[k]), `hai nhóm dùng chung một màu: ${SD.MAU_KHOI[k]}`);
    mau.add(SD.MAU_KHOI[k]);
  }
});

test('Dựng hai lần ra y hệt tới từng chữ số — in hai lần phải ra hai tờ giống nhau', () => {
  const a = SD.dung({ kieu: 'toan-canh' });
  const b = SD.dung({ kieu: 'toan-canh' });
  assert.equal(JSON.stringify(a.nut), JSON.stringify(b.nut));
  assert.equal(JSON.stringify(a.canh), JSON.stringify(b.canh));
});

test('Đường đi: lấy ĐỦ mọi dạng phải biết trước, và chỉ những dạng ấy', () => {
  const chiMuc = new Map(H.FORMS.map((f) => [f.code, f]));
  // Chọn dạng có đường đi dài nhất — chỗ nào dễ sót thì soi đúng chỗ ấy.
  let goc = null;
  let lonNhat = 0;
  for (const f of H.FORMS) {
    const n = SD.dung({ kieu: 'duong-di', goc: f.code }).nut.length;
    if (n > lonNhat) { lonNhat = n; goc = f.code; }
  }
  assert.ok(lonNhat >= 3, `đường đi dài nhất chỉ có ${lonNhat} nút — chương trình chưa khai đủ`);

  const s = SD.dung({ kieu: 'duong-di', goc });
  const co = new Set(s.nut.map((n) => n.ma));
  assert.ok(co.has(goc), 'đường đi thiếu chính dạng gốc');

  // Đóng kín ngược: mỗi nút trong hình phải kéo theo mọi dạng nó cần trước.
  for (const ma of co) {
    for (const p of (chiMuc.get(ma).prereq || [])) {
      if (chiMuc.has(p)) assert.ok(co.has(p), `${ma} cần ${p} mà ${p} vắng mặt`);
    }
  }
  // Và không thừa: mọi nút phải với tới được gốc bằng cách đi xuôi.
  const toi = new Set([goc]);
  let doi = true;
  while (doi) {
    doi = false;
    for (const f of H.FORMS) {
      if (!toi.has(f.code)) continue;
      for (const p of f.prereq || []) if (chiMuc.has(p) && !toi.has(p)) { toi.add(p); doi = true; }
    }
  }
  for (const ma of co) assert.ok(toi.has(ma), `${ma} không nằm trên đường đi tới ${goc}`);
  assert.ok(s.nut.every((n) => (n.ma === goc) === n.laGoc), 'đánh dấu gốc sai');
});

test('Quanh một dạng: bán kính 1 chỉ lấy hàng xóm sát, bán kính 2 lấy nhiều hơn', () => {
  const goc = H.FORMS.find((f) => (f.prereq || []).length)?.code;
  const mot = SD.dung({ kieu: 'quanh-mot', goc, banKinhQuanh: 1 });
  const hai = SD.dung({ kieu: 'quanh-mot', goc, banKinhQuanh: 2 });
  assert.ok(mot.nut.length >= 2, 'quanh một dạng mà chỉ ra một nút thì không thành sơ đồ');
  assert.ok(hai.nut.length >= mot.nut.length, 'đi xa hơn mà ra ít nút hơn');
  const co1 = new Set(mot.nut.map((n) => n.ma));
  for (const m of co1) assert.ok(hai.nut.some((n) => n.ma === m), `bán kính 2 làm mất ${m}`);
});

test('Thiếu gốc hoặc gốc không có thật thì TỪ CHỐI, không lặng lẽ vẽ hình rỗng', () => {
  const a = SD.dung({ kieu: 'duong-di' });
  assert.equal(a.ok, false);
  assert.equal(a.loi, 'THIEU_DANG_GOC');
  const b = SD.dung({ kieu: 'quanh-mot', goc: 'M9.KHONG.CO.DANG.NAY' });
  assert.equal(b.ok, false);
  assert.equal(b.loi, 'KHONG_CO_DANG');
  assert.ok(b.lyDo && b.lyDo.length > 10, 'từ chối mà không nói vì sao');
});

test('Chỗ chương trình còn THƯA được nói ra, không che đi', () => {
  const s = SD.dung({ kieu: 'toan-canh' });
  assert.equal(typeof s.thongKe.soNutLacLoi, 'number');
  if (s.thongKe.soNutLacLoi > 0) {
    assert.ok(s.ghiChu && s.ghiChu.includes(String(s.thongKe.soNutLacLoi)),
      'có nút đứng rời mà ghi chú không nhắc tới');
  }
});

test('Danh sách dạng để chọn gốc khớp đúng chương trình', () => {
  const ds = SD.dsDang();
  assert.equal(ds.length, H.FORMS.length);
  for (const d of ds) {
    assert.ok(d.ma && d.ten, `mục thiếu mã hoặc tên: ${JSON.stringify(d)}`);
    assert.ok(d.khoi, `mục ${d.ma} không có nhóm`);
  }
});

// ── Vẽ ra SVG ──────────────────────────────────────────────────────────────

const svgToanCanh = (o = {}) => VE.ve(SD.dung({ kieu: 'toan-canh' }), { rong: 1100, cao: 720, ...o });

test('Tệp SVG KHÔNG mang theo mã chạy được và KHÔNG gọi ra mạng', () => {
  // Một tệp ảnh gửi qua lại giữa thầy và trò; nếu nó chạy được mã thì nó
  // không còn là ảnh, nó là một cái bẫy.
  const svg = svgToanCanh();
  assert.equal(/<script/i.test(svg), false, 'SVG có thẻ script');
  assert.equal(/\son\w+\s*=/i.test(svg), false, 'SVG có thuộc tính bắt sự kiện');
  assert.equal(/javascript:/i.test(svg), false);
  assert.equal(/<foreignObject/i.test(svg), false);
  assert.equal(/<(image|use)\b/i.test(svg), false, 'SVG nhúng tài nguyên ngoài');
  assert.equal(/@import|<\?xml-stylesheet/i.test(svg), false);
  // Đường dẫn ra ngoài duy nhất được phép là tên không gian XML của SVG.
  const ngoai = (svg.match(/https?:\/\/[^"' ]+/g) || []).filter((u) => u !== 'http://www.w3.org/2000/svg');
  assert.deepEqual(ngoai, [], `SVG trỏ ra ngoài: ${ngoai.join(', ')}`);
});

test('Mọi ký tự đặc biệt trong tên dạng đều đã thoát', () => {
  const svg = svgToanCanh();
  const hong = svg.match(/&(?!amp;|lt;|gt;|quot;|#39;)/g) || [];
  assert.deepEqual(hong, [], `còn ${hong.length} dấu & chưa thoát`);
});

test('Vẽ hai lần ra một tệp y hệt — ảnh trên màn và ảnh in ra phải trùng nhau', () => {
  assert.equal(svgToanCanh(), svgToanCanh());
  assert.equal(svgToanCanh({ gocDoc: 1.2 }), svgToanCanh({ gocDoc: 1.2 }));
  assert.notEqual(svgToanCanh({ gocDoc: 0.6 }), svgToanCanh({ gocDoc: 1.2 }),
    'xoay mà hình không đổi thì phép xoay không tới được chỗ vẽ');
});

test('Vẽ đủ chấm và đủ đường, đúng bằng số nút và số cạnh dựng được', () => {
  const s = SD.dung({ kieu: 'toan-canh' });
  const svg = VE.ve(s, { rong: 1100, cao: 720 });
  const soChamTrongChuThich = Object.keys(s.thongKe.theoKhoi).length;
  const cham = (svg.match(/<circle /g) || []).length;
  assert.equal(cham, s.nut.length + soChamTrongChuThich, 'số chấm không khớp số nút');
  assert.equal((svg.match(/<line /g) || []).length, s.canh.length, 'số đường không khớp số cạnh');
  // Mỗi chấm nút phải có lời chú khi rê chuột — đó là cách duy nhất đọc được
  // tên đầy đủ của nút không hiện nhãn.
  assert.equal((svg.match(/<title>/g) || []).length, s.nut.length);
});

test('Chú thích in đủ mọi nhóm và đúng số đếm', () => {
  const s = SD.dung({ kieu: 'toan-canh' });
  const svg = VE.ve(s, { rong: 1100, cao: 720 });
  for (const [k, v] of Object.entries(s.thongKe.theoKhoi)) {
    assert.ok(svg.includes(`${k} · ${v}`), `chú thích thiếu nhóm ${k}`);
  }
});

/** Đọc lại các nhãn đã vẽ, dựng lại đúng ô chữ nhật mà bộ vẽ đã cấp. */
function oChuTrongSvg(svg) {
  const ra = [];
  const re = /<text x="([-\d.]+)" y="([-\d.]+)" font-size="([\d.]+)"[^>]*>([^<]*)<\/text>/g;
  let m;
  while ((m = re.exec(svg))) {
    const [x, y, co] = [+m[1], +m[2], +m[3]];
    const chu = m[4];
    if (co < 7) continue;                         // chữ chú thích, cỡ 11 nhưng nằm ngoài vùng nút
    ra.push({ chu, t: x, p: x + chu.length * co * 0.58, tr: y - co * 1.25 / 2, d: y + co * 1.25 / 2 });
  }
  return ra;
}

test('Nhãn KHÔNG đè lên nhãn — lỗi có thật, bắt được bằng cách nhìn vào hình', () => {
  // Bản đầu chỉ lọc nhãn theo chiều sâu, và vùng giữa hình dày đặc chữ chồng
  // chữ: hai mươi nhãn đè nhau cho ít thông tin hơn năm nhãn rời.
  const svg = svgToanCanh();
  const o = oChuTrongSvg(svg).filter((z) => !/·/.test(z.chu));
  assert.ok(o.length >= 10, `chỉ vẽ được ${o.length} nhãn — ít tới mức vô dụng`);
  for (let i = 0; i < o.length; i += 1) {
    for (let j = i + 1; j < o.length; j += 1) {
      const a = o[i];
      const b = o[j];
      const dung = a.t < b.p && a.p > b.t && a.tr < b.d && a.d > b.tr;
      assert.equal(dung, false, `nhãn "${a.chu}" đè lên "${b.chu}"`);
    }
  }
});

test('Không phải nút nào cũng có nhãn — hiện hết thì không đọc được cái nào', () => {
  const s = SD.dung({ kieu: 'toan-canh' });
  const svg = VE.ve(s, { rong: 1100, cao: 720 });
  const soNhan = oChuTrongSvg(svg).length;
  assert.ok(soNhan < s.nut.length, 'vẽ nhãn cho mọi nút — vùng giữa chắc chắn chồng chữ');
});

test('Nút gốc được đánh dấu rõ và LUÔN có nhãn — ở MỌI đồ thị và MỌI góc xoay', () => {
  // Lỗi có thật, chỉ lộ ra khi mở trang bằng trình duyệt: ở kiểu "đường đi",
  // nút gốc nằm sát một hàng xóm GẦN HƠN, nên hàng xóm giành mất ô chữ và gốc
  // đứng đó không tên. Người học nhìn vào hình không biết mình đang tra dạng
  // nào — đúng thứ duy nhất họ cần biết ở màn hình ấy.
  //
  // Một đồ thị may mắn không chứng minh được gì, nên soi hàng loạt.
  const coPrereq = H.FORMS.filter((f) => (f.prereq || []).length).map((f) => f.code);
  assert.ok(coPrereq.length >= 20);
  const mat = [];
  for (const goc of coPrereq) {
    for (const [kieu, o] of [['duong-di', {}], ['quanh-mot', { banKinhQuanh: 2 }]]) {
      for (const gocDoc of [0.6, 2.2]) {
        const svg = VE.ve(SD.dung({ kieu, goc, ...o }), { gocDoc, rong: 1100, cao: 720 });
        if (!/stroke="#ffffff" stroke-width="2"/.test(svg)) mat.push(`${goc}/${kieu}: không viền`);
        if (!svg.includes(`>${goc}</text>`)) mat.push(`${goc}/${kieu}/góc ${gocDoc}: mất nhãn`);
      }
    }
  }
  assert.deepEqual(mat.slice(0, 5), [], `${mat.length} lượt nút gốc không nhận ra được`);
});

test('Mọi nét vẽ nằm trong khung hình, không tràn ra ngoài', () => {
  const rong = 1100;
  const cao = 720;
  const svg = svgToanCanh({ rong, cao });
  for (const m of svg.matchAll(/<circle cx="([-\d.]+)" cy="([-\d.]+)"/g)) {
    assert.ok(+m[1] >= -20 && +m[1] <= rong + 20, `chấm tràn ngang: ${m[1]}`);
    assert.ok(+m[2] >= -20 && +m[2] <= cao + 20, `chấm tràn dọc: ${m[2]}`);
  }
  assert.ok(svg.includes(`viewBox="0 0 ${rong} ${cao}"`));
});

test('Sơ đồ hỏng thì trả về ảnh rỗng, không ném lỗi giữa trang', () => {
  for (const x of [null, undefined, { ok: false, loi: 'KHONG_CO_DANG' }]) {
    const svg = VE.ve(x);
    assert.match(svg, /^<svg[^>]*><\/svg>$/, 'ảnh cho sơ đồ hỏng phải rỗng');
  }
});

test('Tắt nền thì không vẽ nền — để nhúng được vào trang sáng', () => {
  assert.equal(/<rect width=/.test(svgToanCanh({ nen: false })), false);
  assert.equal(/<rect width=/.test(svgToanCanh({ nen: true })), true);
});

test('Ảnh có lời mô tả cho người đọc bằng máy đọc màn hình', () => {
  const svg = svgToanCanh();
  assert.match(svg, /role="img"/);
  assert.match(svg, /aria-label="[^"]{20,}"/);
});
