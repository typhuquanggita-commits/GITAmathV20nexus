'use strict';
/**
 * HỆ THỐNG TRẢI NGHIỆM KHÁCH HÀNG
 *
 * Phần lớn mục ở đây canh đúng một thứ: hệ thống này không được PHÓNG ĐẠI về
 * chính nó. Một khung quản trị dịch vụ rất dễ trở thành tài liệu đẹp mà rỗng —
 * và cách nó rỗng luôn giống nhau: con số to, chỗ mù không nói, việc cấm không
 * ghi, và "wow" dán lên trên những lời hứa chưa giữ.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const TH = require('../src/trai-nghiem/tinh-huong');
const KE = require('../src/trai-nghiem/kenh');
const LC = require('../src/trai-nghiem/luoi-cham');
const TQ = require('../src/trai-nghiem/trao-quyen');
const PH = require('../src/trai-nghiem/phuc-hoi');
const DL = require('../src/trai-nghiem/do-luong');
const KH = require('../src/trai-nghiem/khung');

test('Bốn mươi tình huống: mã riêng, và tình huống nào cũng có mục CẤM LÀM', () => {
  assert.equal(TH.TINH_HUONG.length, 40);
  assert.equal(new Set(TH.TINH_HUONG.map((t) => t.ma)).size, 40, 'có mã trùng');
  assert.equal(new Set(TH.TINH_HUONG.map((t) => t.ten)).size, 40, 'có tên trùng — dấu hiệu dập khuôn');
  for (const t of TH.TINH_HUONG) {
    assert.ok(t.lamNgay.length > 0, `${t.ma} không nói làm gì`);
    // Mục hay bị bỏ nhất: phần lớn khách mất không phải vì sự cố, mà vì cách
    // người trực xử lý sự cố.
    assert.ok(t.camLam.length > 0, `${t.ma} thiếu mục CẤM LÀM`);
    assert.ok(t.aiXuLy && t.aiXuLy.length >= 8, `${t.ma} không nói ai xử`);
    assert.ok(t.doBang && t.doBang.length >= 10, `${t.ma} không nói đo bằng gì`);
    assert.ok(TH.NHOM[t.nhom], `${t.ma} có nhóm lạ`);
    assert.ok(TH.MUC[t.muc], `${t.ma} có mức lạ`);
    assert.equal(typeof t.dauHieu.doDuoc, 'boolean', `${t.ma} không khai máy có đo được dấu hiệu không`);
  }
});

test('Hệ thống nói THẲNG tình huống nào máy không tự thấy', () => {
  // Đây là mục quan trọng nhất của tệp này. Để người trực tưởng máy đang canh
  // cả bốn mươi là cách tạo ra một đêm không ai trông.
  const bd = TH.banDoPhatHien();
  assert.equal(bd.tong, 40);
  assert.ok(bd.phaiChoNguoiBao > 0, 'khai rằng máy thấy hết 40 tình huống — không đúng');
  assert.equal(bd.mayTuThay + bd.phaiChoNguoiBao, 40);
  assert.equal(bd.danhSachChoNguoi.length, bd.phaiChoNguoiBao);
  for (const t of TH.TINH_HUONG.filter((x) => !x.dauHieu.doDuoc)) {
    assert.ok(/nguoi-bao/.test(t.dauHieu.nguon), `${t.ma} nói máy không đo được nhưng nguồn lại là ${t.dauHieu.nguon}`);
  }
});

test('Kênh sai bị CHẶN, không phải bị nhắc nhở', () => {
  // Báo kết quả sàng lọc tâm lý qua báo cáo định kỳ là sai, dù nội dung đúng.
  const chan = KE.dungDuoc('K5', 'DO');
  assert.equal(chan.ok, false);
  assert.ok(chan.dungKenhNao.length > 0, 'chặn mà không nói dùng kênh nào thay thế');
  assert.equal(KE.dungDuoc('K3', 'DO').ok, true);
  assert.equal(KE.dungDuoc('K9', 'DO').ok, false);
  for (const k of KE.KENH) {
    assert.ok(k.camLam.length > 0, `kênh ${k.ma} thiếu mục cấm`);
    assert.ok(k.yeu && k.yeu.length > 10, `kênh ${k.ma} không tự khai điểm yếu`);
  }
});

test('Lưới đúng 10.000 ô, và tự khai số mục viết tay là 95', () => {
  const l = LC.luoi();
  assert.equal(l.tong, 10000);
  assert.equal(l.soViTri * l.soTinhHuong * l.soKenh, 10000);
  // Con số trung thực: 50 + 40 + 5. Khai 10.000 mục viết tay là nói dối, và
  // người đọc phát hiện ra ở ô thứ mười.
  assert.equal(l.mucVietTay, 95);
  assert.ok(/không phải/.test(l.ghiChu), 'lưới không tự đính chính về con số 10.000');
  assert.ok(l.biChan > 0, 'không ô nào bị chặn — cổng kênh đang không làm việc');
  assert.equal(l.dungDuoc + l.biChan, 10000);
});

test('Ô bị chặn vẫn trả lời, bằng cách chỉ ra kênh đúng', () => {
  // "Đừng làm thế, hãy làm thế này" cũng là một câu trả lời, và là câu hay
  // bị thiếu nhất trong mọi tài liệu quy trình.
  const d = LC.diemCham(3, 5, 'TH14', 'K5');   // tâm lý mức đỏ qua báo cáo định kỳ
  assert.equal(d.hopLe, false);
  assert.ok(d.lyDo.length > 20);
  assert.ok(Array.isArray(d.dungKenhNao) && d.dungKenhNao.length > 0);
  assert.ok(/2 giờ/.test(d.nhac), 'ô bị chặn không nhắc hạn chót');
});

test('Wow bị TỪ CHỐI khi mức nền chưa xong', () => {
  // Một bất ngờ dễ thương đặt trên một lời hứa chưa giữ là trò đánh lạc hướng.
  const chua = LC.xinWow(2, 6, 'TH02', 'K3', { nenDaXong: false });
  assert.equal(chua.ok, false);
  assert.ok(Array.isArray(chua.phaiLamTruoc) && chua.phaiLamTruoc.length > 0,
    'từ chối mà không nói phải làm gì trước');
  const duoc = LC.xinWow(2, 6, 'TH02', 'K3', { nenDaXong: true });
  assert.equal(duoc.ok, true);
  assert.ok(duoc.wow.viec.length > 20);
});

test('Nhóm cảm xúc và an toàn KHÔNG có mức wow, kể cả khi nền đã xong', () => {
  // Sáng tạo ở nhóm này là đem một đứa trẻ ra thử nghiệm.
  assert.equal(LC.CACH_WOW.CAM_XUC, null);
  const x = LC.xinWow(3, 4, 'TH14', 'K3', { nenDaXong: true });
  assert.equal(x.ok, false);
  assert.ok(/không có mức wow/i.test(x.lyDo));
  for (const t of TH.theoNhom('CAM_XUC')) {
    const d = LC.diemCham(1, 1, t.ma, 'K3');
    if (d.hopLe) assert.equal(d.kichBan.wow.viec, undefined, `${t.ma} lại có mức wow`);
  }
});

test('Không ô nào của lưới có hai dòng kịch bản y hệt nhau', () => {
  // Kịch bản có hai dòng trùng là kịch bản chưa ai đọc lại. Soi cả lưới.
  let lap = 0;
  let viDu = null;
  for (let t = 1; t <= 5; t++) {
    for (let c = 1; c <= 10; c++) {
      for (const th of TH.TINH_HUONG) {
        for (const k of KE.KENH) {
          const d = LC.diemCham(t, c, th.ma, k.ma);
          if (!d.hopLe) continue;
          const dong = [...d.kichBan.nen.viec, ...d.kichBan.tot.viec];
          if (new Set(dong).size !== dong.length) { lap++; viDu = viDu || d.ma; }
          if (new Set(d.camLam).size !== d.camLam.length) { lap++; viDu = viDu || `${d.ma} (cấm làm)`; }
        }
      }
    }
  }
  assert.equal(lap, 0, `${lap} ô có dòng lặp, ví dụ ${viDu}`);
});

test('Cùng một tình huống ở hai cấp khác nhau ra hai kịch bản khác nhau', () => {
  // Nếu vị trí không làm đổi nội dung thì trục 50 vị trí là trục giả, và lưới
  // 10.000 ô thật ra chỉ là 200 ô nhân lên cho to.
  const a = LC.diemCham(1, 2, 'TH02', 'K3');
  const b = LC.diemCham(4, 6, 'TH02', 'K3');
  assert.notDeepEqual(a.kichBan.tot.viec, b.kichBan.tot.viec);
  assert.notEqual(a.kichBan.wow.viec, b.kichBan.wow.viec);
  assert.notEqual(a.la, b.la);
});

test('Không kịch bản nào hứa điểm số', () => {
  // Cây giá trị hứa năng lực. Một con số điểm lọt vào kịch bản dịch vụ là một
  // lời hứa không ai giữ được, và nó quay lại làm chứng chống chính mình.
  const xau = [];
  for (const t of TH.TINH_HUONG) {
    const chu = [t.ten, ...t.lamNgay, ...t.camLam, t.doBang].join(' ');
    if (/\bđiểm\s*(9|10|8)\b|\bđạt\s*\d+\s*điểm|\bcam kết\s*\d/.test(chu)) xau.push(t.ma);
  }
  assert.deepEqual(xau, []);
});

test('Trao quyền: mọi quyền có trần, và quyền chưa dùng được phải tự khai', () => {
  assert.equal(TQ.QUYEN.length, 10);
  for (const q of TQ.QUYEN) {
    assert.ok(q.tran && q.tran.length > 5, `${q.ma} không có trần`);
    assert.ok(q.camLam && q.camLam.length > 10, `${q.ma} thiếu mục cấm`);
    assert.ok(q.viSao && q.viSao.length > 20, `${q.ma} không nói vì sao`);
  }
  const tt = TQ.trangThai();
  // Q08 (hoàn tiền) phải còn treo, vì sổ cái dòng tiền khai doanh thu là khoản
  // CHƯA CÓ NGUỒN. Hai chỗ trong hệ thống phải nói cùng một điều.
  assert.ok(tt.conTreo.some((q) => q.ma === 'Q08'),
    'quyền hoàn tiền không còn treo, trong khi sổ cái vẫn chưa nối dữ liệu thanh toán');
  const soCai = require('../src/dong-tien/so-cai');
  const chuaCo = Object.values(soCai.KHOAN).filter((k) => k.tinCay === 'chua-co').map((k) => k.ten);
  assert.ok(chuaCo.length > 0, 'sổ cái không còn khoản nào chưa nối nguồn — cập nhật lại quyền Q08');
});

test('Thang phục hồi từ chối nhảy bước', () => {
  assert.equal(PH.BUOC.length, 10);
  const nhay = PH.buocKeTiep([1, 2, 6]);
  assert.equal(nhay.xongHet, false);
  assert.ok(nhay.canhBao, 'nhảy từ bước 2 sang bước 6 mà không cảnh báo gì');
  assert.equal(nhay.buoc.thu, 3);
  const deu = PH.buocKeTiep([1, 2, 3]);
  assert.equal(deu.canhBao, null);
  assert.equal(PH.buocKeTiep([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).xongHet, true);
  for (const b of PH.BUOC) {
    assert.ok(b.camLam && b.camLam.length > 10, `bước ${b.thu} thiếu mục cấm`);
    assert.ok(b.xongKhi && b.xongKhi.length > 5, `bước ${b.thu} không nói khi nào là xong`);
  }
});

test('Bảng đo in chỗ mù TRƯỚC con số, và không tự nhận đo được cả chuỗi', () => {
  const b = DL.bangDo();
  const khoa = Object.keys(b);
  assert.ok(khoa.indexOf('chuaDoDuoc') < khoa.indexOf('doDuoc'),
    'bảng đo đặt phần đo được trước phần chưa đo được — ngược với luật của sổ cái dòng tiền');
  assert.ok(b.chuaDoDuoc.length > 0);
  for (const c of b.chuaDoDuoc) {
    assert.ok(c.thieu && c.thieu.length > 20, `${c.ma} không nói thiếu gì`);
    assert.ok(c.lamGiDeCo && c.lamGiDeCo.length > 10, `${c.ma} không nói làm gì để có`);
  }
  // CLV và giữ chân PHẢI nằm ở phần chưa đo được, chừng nào chưa nối thanh toán.
  const ma = b.chuaDoDuoc.map((c) => c.ma);
  assert.ok(ma.includes('clv') && ma.includes('giu-chan') && ma.includes('gioi-thieu'));
  assert.ok(b.tiLeDoDuoc < 1, 'khai đo được 100% — không đúng với dữ liệu đang có');
});

test('Khung mười tầng trỏ vào tệp mã có thật', () => {
  // Một khung quản trị mà tầng nào cũng "đã có" thì là khung vẽ trên giấy.
  const k = KH.khung();
  assert.equal(k.soTang, 10);
  assert.equal(k.baiHoc.length, 10);
  const goc = path.join(__dirname, '..');
  const thieu = k.tang.filter((t) => t.moduleFile && !fs.existsSync(path.join(goc, t.moduleFile)));
  assert.deepEqual(thieu.map((t) => t.moduleFile), [], 'khung trỏ vào tệp không tồn tại');
  for (const t of k.tang) {
    assert.ok(t.doBang && t.doBang.length > 10, `tầng ${t.thu} không nói đo bằng gì`);
  }
});

test('Chữ đi tới khách hàng sạch; chữ điều hành ở lại sau bức tường', () => {
  // Bộ soi của bức tường đã bắt đúng một lần khi bảng đo suýt bị xếp sang mặt
  // khách hàng — bảng ấy nói bằng ngôn ngữ thương mại (giá trị vòng đời, chi
  // phí phục vụ), và đó không phải ngôn ngữ để một gia đình đọc về con mình.
  const tuong = require('../src/cay-tien/buc-tuong');

  // Phần đi tới khách: kịch bản điểm chạm, tình huống, kênh, quyền, thang
  // phục hồi, khung. Đây là chữ nhân viên nói ra với gia đình.
  const toiKhach = JSON.stringify([
    TH.TINH_HUONG, KE.KENH, TQ.QUYEN, PH.BUOC, KH.khung(), LC.luoi({ mau: 5 }).mau,
  ]);
  const r = tuong.soiRoRi(toiKhach);
  assert.equal(r.sach, true, JSON.stringify(r.roRi));

  // Bảng đo tự khai là nội bộ, và cổng API của nó phải ở mức quản trị.
  assert.equal(DL.NOI_BO, true, 'bảng đo không tự khai là nội bộ');
  const cq = require('../src/api/cong-quyen');
  assert.equal(cq.MUC_THEO_NHOM.TRAINGHIEM, 'quan-tri');
});
