#!/usr/bin/env node
'use strict';
/**
 * BẢNG PHÂN CÔNG 500 AGENT — in ra đúng những gì hệ thống đang chạy.
 *
 *   node scripts/roster-table.js            bảng tổng hợp (khối × cấp bậc, quyền, KPI, công suất)
 *   node scripts/roster-table.js --full     thêm danh sách 25 tổ
 *   node scripts/roster-table.js --csv      xuất toàn bộ 500 dòng ra CSV (stdout)
 *   node scripts/roster-table.js --json     xuất JSON
 *   node scripts/roster-table.js --csv > phan-cong-500-agent.csv
 */

const { buildRoster, assignmentTable } = require('../src/agents/roster');
const { DIVISIONS, RANKS, ALLOCATION } = require('../src/agents/taxonomy');

const argv = process.argv.slice(2);
const has = (f) => argv.includes(f);
const { agents, squads } = buildRoster();
const vn = (n) => n.toLocaleString('vi-VN');

// ── CSV: một dòng một agent, đủ mọi trường điều hành ────────────────────────
if (has('--csv')) {
  const cols = [
    'stt', 'ma_agent', 'khoi', 'ten_khoi', 'to', 'ten_to', 'cho_ngoi', 'cap_bac', 'ten_cap_bac',
    'chuc_nang', 'chuyen_mon', 'pham_vi', 'hang_mo_hinh', 'quyen_han',
    'dong_thoi_toi_da', 'token_moi_phut', 'task_moi_gio',
    'kpi_ti_le_thanh_cong', 'kpi_chat_luong', 'kpi_p95_ms', 'kpi_chi_phi_usd',
  ];
  const esc = (v) => {
    const s = String(v ?? '');
    return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const out = [cols.join(',')];
  for (const a of agents) {
    out.push([
      a.seq, a.id, a.division, a.divisionName, a.squad, a.squadName, a.seat, a.rank, a.rankName,
      a.duty, a.specialty, a.scope, a.tier, a.permissions.join(' | '),
      a.capacity.maxConcurrent, a.capacity.tokensPerMin, a.capacity.tasksPerHour,
      a.kpiTargets.successRate, a.kpiTargets.qualityScore, a.kpiTargets.p95LatencyMs, a.kpiTargets.costPerTaskUsd,
    ].map(esc).join(','));
  }
  process.stdout.write('﻿' + out.join('\n') + '\n'); // BOM để Excel đọc đúng tiếng Việt
  process.exit(0);
}

if (has('--json')) {
  process.stdout.write(JSON.stringify({ agents, squads, table: assignmentTable(agents) }, null, 2) + '\n');
  process.exit(0);
}

// ── Bảng cho người đọc ──────────────────────────────────────────────────────
const tbl = assignmentTable(agents);
const rankIds = Object.keys(RANKS);
const pad = (s, n) => String(s).padEnd(n);
const padL = (s, n) => String(s).padStart(n);
const rule = (n = 112, c = '─') => console.log(c.repeat(n));

console.log('');
console.log('  GITAmath NEXUS V20 — BẢNG PHÂN CÔNG LỰC LƯỢNG');
console.log(`  ${agents.length} agent · ${squads.length} tổ · ${Object.keys(DIVISIONS).length} khối · ${rankIds.length} cấp bậc`);
console.log('');

// 1) Ma trận khối × cấp bậc
console.log('  ▸ MA TRẬN PHÂN BỔ  (hàng = khối, cột = cấp bậc)');
rule(112, '═');
console.log('  ' + pad('KHỐI', 34) + rankIds.map((r) => padL(r, 12)).join('') + padL('TỔNG', 8));
rule(112);
for (const d of Object.keys(DIVISIONS)) {
  const row = ALLOCATION[d];
  const sum = Object.values(row).reduce((a, b) => a + b, 0);
  console.log('  ' + pad(`${d} · ${DIVISIONS[d].name}`, 34)
    + rankIds.map((r) => padL(row[r] || 0, 12)).join('') + padL(sum, 8));
}
rule(112);
console.log('  ' + pad('TỔNG', 34)
  + rankIds.map((r) => padL(RANKS[r].total, 12)).join('')
  + padL(agents.length, 8));
console.log('');

// 2) Khối: nhiệm vụ, công suất
console.log('  ▸ KHỐI — NHIỆM VỤ VÀ CÔNG SUẤT');
rule(112, '═');
for (const d of tbl.byDivision) {
  console.log(`  ${d.division} · ${d.name}  —  ${d.total} agent · ${Object.keys(d.squads).length} tổ · chuyên môn: ${d.specialty}`);
  console.log(`      Nhiệm vụ : ${d.mission}`);
  console.log(`      Công suất: ${d.capacity.concurrent} slot đồng thời · ${vn(d.capacity.tokensPerMin)} token/phút · ${vn(d.capacity.tasksPerHour)} task/giờ`);
  console.log(`      Tổ       : ${Object.keys(d.squads).join(', ')}`);
  console.log('');
}

// 3) Cấp bậc: chức năng, quyền hạn, KPI
console.log('  ▸ CẤP BẬC — CHỨC NĂNG · QUYỀN HẠN · KPI · CÔNG SUẤT MỖI NGƯỜI');
rule(112, '═');
for (const r of tbl.byRank) {
  console.log(`  ${r.rank} · ${r.name}  —  ${r.total} người`);
  console.log(`      Chức năng : ${r.duty}`);
  console.log(`      Quyền hạn : ${r.permissions.join(', ')}`);
  console.log(`      Công suất : ${r.capacity.maxConcurrent} việc song song · ${vn(r.capacity.tokensPerMin)} token/phút · ${r.capacity.tasksPerHour} task/giờ`);
  console.log(`      KPI       : thành công ≥ ${r.kpiTargets.successRate} · chất lượng ≥ ${r.kpiTargets.qualityScore} · `
    + `p95 ≤ ${vn(r.kpiTargets.p95LatencyMs)}ms · chi phí ≤ ${r.kpiTargets.costPerTaskUsd} USD/task`);
  console.log(`      Rải khối  : ${Object.entries(r.divisions).map(([k, v]) => `${k} ${v}`).join(' · ')}`);
  console.log('');
}

// 4) Tổ (tuỳ chọn)
if (has('--full')) {
  console.log('  ▸ 25 TỔ — MỖI TỔ 20 NGƯỜI, CÓ CHỈ HUY');
  rule(112, '═');
  console.log('  ' + pad('TỔ', 12) + pad('TÊN TỔ', 24) + pad('KHỐI', 14) + pad('CHỈ HUY', 12) + 'THÀNH PHẦN');
  rule(112);
  for (const s of squads) {
    console.log('  ' + pad(s.id, 12) + pad(s.name, 24) + pad(s.division, 14) + pad(s.lead, 12)
      + Object.entries(s.composition).map(([k, v]) => `${k}:${v}`).join(' '));
  }
  console.log('');
}

// 5) Tổng công suất
console.log('  ▸ TỔNG CÔNG SUẤT DANH ĐỊNH');
rule(112, '═');
console.log(`  Đồng thời   : ${vn(tbl.capacityTotals.concurrent)} việc cùng lúc (trần toàn cục do cấu hình siết lại)`);
console.log(`  Token       : ${vn(tbl.capacityTotals.tokensPerMin)} token/phút`);
console.log(`  Thông lượng : ${vn(tbl.capacityTotals.tasksPerHour)} task/giờ · ${vn(tbl.capacityTotals.tasksPerHour * 24)} task/ngày`);
console.log('');
console.log('  Xuất CSV: node scripts/roster-table.js --csv > phan-cong-500-agent.csv');
console.log('');
