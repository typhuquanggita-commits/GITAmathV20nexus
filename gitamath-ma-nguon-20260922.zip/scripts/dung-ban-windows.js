#!/usr/bin/env node
'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỰNG BẢN CÀI WINDOWS 64-BIT — chạy được cả trên máy Linux
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Tệp này tồn tại vì lần dựng đầu tiên mất bốn vòng mò mẫm, và nếu không ghi
 *  lại thì lần sau mò lại từ đầu. Ba trở ngại thật, đều ở máy dựng chứ không
 *  ở sản phẩm:
 *
 *  1. electron-builder cần WINE để sửa biểu tượng và thông tin phiên bản vào
 *     tệp exe. Không có wine thì dừng ngay ở bước đóng gói.
 *
 *  2. Nó gọi rcedit BẢN 32-BIT, nên wine 64-bit một mình không đủ. Trên máy
 *     chỉ có wine64, lệnh trả về "could not exec the wine loader" — một câu
 *     không nói gì về nguyên nhân thật.
 *
 *  3. Trình cài đặt NSIS là tệp 32-bit, và electron-builder CHẠY nó dưới wine
 *     để sinh ra bộ gỡ cài đặt. Vậy nên phải có wine 32-bit, không thể thay
 *     bằng wine 64-bit.
 *
 *  Bộ dựng này soi trước cả ba, và khi thiếu thì nói rõ thiếu gì kèm lệnh cài
 *  — thay vì để người dựng đọc một thông báo lỗi của wine rồi tự đoán.
 *
 *  KHÔNG TỰ CÀI GÌ. Cài gói hệ thống là việc của người có quyền trên máy ấy,
 *  và một bộ dựng tự ý cài đặt là một bộ dựng không ai dám chạy.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const { execFileSync, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const GOC = path.join(__dirname, '..');
const DESKTOP = path.join(GOC, 'desktop');

const mau = {
  dam: (s) => `\x1b[1m${s}\x1b[0m`,
  mo: (s) => `\x1b[2m${s}\x1b[0m`,
  xanh: (s) => `\x1b[32m${s}\x1b[0m`,
  do: (s) => `\x1b[31m${s}\x1b[0m`,
  vang: (s) => `\x1b[33m${s}\x1b[0m`,
};

const noi = (...a) => console.log(...a);
const dat = (t, chiTiet = '') => noi(`  [${mau.xanh(' ĐẠT ')}] ${t}${chiTiet ? mau.mo(` · ${chiTiet}`) : ''}`);
const thieu = (t, cach) => { noi(`  [${mau.do('THIẾU')}] ${t}`); if (cach) noi(mau.mo(`          ${cach}`)); };

function co(lenh) {
  const r = spawnSync('sh', ['-c', `command -v ${lenh}`], { encoding: 'utf8' });
  return r.status === 0 && r.stdout.trim();
}

function wineChay(duong, thamSo) {
  const r = spawnSync(duong, thamSo, {
    encoding: 'utf8',
    env: { ...process.env, WINEDEBUG: '-all', WINEPREFIX: process.env.WINEPREFIX || path.join(os.tmpdir(), 'wine-gita') },
  });
  return { ok: r.status === 0, ra: `${r.stdout || ''}${r.stderr || ''}` };
}

// ── 1. SOI MÁY DỰNG ────────────────────────────────────────────────────────

function soiMayDung() {
  noi(mau.dam('\n  ▸ SOI MÁY DỰNG\n'));
  const hong = [];

  const nv = process.versions.node.split('.').map(Number);
  if (nv[0] >= 22) dat('Node.js', `v${process.versions.node}`);
  else { thieu(`Node.js quá cũ (v${process.versions.node}), cần từ v22`); hong.push('node'); }

  if (fs.existsSync(path.join(DESKTOP, 'node_modules', 'electron-builder'))) {
    dat('electron-builder đã cài');
  } else {
    thieu('Chưa cài electron-builder', 'npm --prefix desktop install');
    hong.push('electron-builder');
  }

  const laWindows = process.platform === 'win32';
  if (laWindows) {
    dat('Đang dựng trên chính Windows', 'không cần wine');
    return { hong, laWindows };
  }

  // wine — bắt buộc khi dựng từ Linux hoặc macOS
  const duongWine = co('wine');
  if (!duongWine) {
    thieu('Không có wine', 'apt-get install -y --no-install-recommends wine64 wine32:i386');
    hong.push('wine');
    return { hong, laWindows };
  }
  const phienBan = wineChay(duongWine, ['--version']);
  if (!phienBan.ok) {
    thieu('wine có trên đường dẫn nhưng không chạy được', phienBan.ra.trim().slice(0, 160));
    hong.push('wine');
    return { hong, laWindows };
  }
  dat('wine', phienBan.ra.trim());

  // wine 32-bit: bắt buộc, vì trình cài đặt NSIS là tệp 32-bit và
  // electron-builder phải CHẠY nó để sinh bộ gỡ cài đặt.
  const co32 = ['/usr/lib/wine/wine', '/usr/lib/i386-linux-gnu/wine/wine']
    .some((d) => fs.existsSync(d));
  if (co32) {
    dat('wine 32-bit', 'cần cho bước sinh bộ gỡ cài đặt');
  } else {
    thieu('Thiếu wine 32-bit — dựng được bản chạy thẳng nhưng KHÔNG dựng được trình cài đặt',
      'apt-get install -y --no-install-recommends wine32:i386  (nhớ dpkg --add-architecture i386 trước)');
    hong.push('wine32');
  }

  return { hong, laWindows };
}

// ── 2. VÁ rcedit ───────────────────────────────────────────────────────────

/**
 * electron-builder gọi rcedit BẢN 32-BIT để ghi biểu tượng và thông tin phiên
 * bản vào tệp exe. Trên máy chỉ có wine 64-bit, lệnh ấy chết với một thông báo
 * không nói gì về nguyên nhân. Bản 64-bit làm ĐÚNG việc ấy và nằm sẵn cùng
 * thư mục, nên đổi chỗ là xong.
 *
 * Chỉ đổi khi máy KHÔNG có wine 32-bit. Có đủ hai bản thì để nguyên, vì bản
 * gốc là thứ electron-builder tự kiểm tra băm.
 */
function vaRcedit(coWine32) {
  if (coWine32) return { daVa: false, vi: 'máy có wine 32-bit nên dùng nguyên bản' };
  const thuMuc = path.join(os.homedir(), '.cache', 'electron-builder', 'winCodeSign');
  if (!fs.existsSync(thuMuc)) return { daVa: false, vi: 'chưa tải winCodeSign, sẽ tải ở bước dựng' };
  for (const ten of fs.readdirSync(thuMuc)) {
    const d = path.join(thuMuc, ten);
    const ia32 = path.join(d, 'rcedit-ia32.exe');
    const x64 = path.join(d, 'rcedit-x64.exe');
    if (!fs.existsSync(ia32) || !fs.existsSync(x64)) continue;
    const goc = `${ia32}.goc`;
    if (!fs.existsSync(goc)) fs.copyFileSync(ia32, goc);
    fs.copyFileSync(x64, ia32);
    return { daVa: true, vi: 'đã thay rcedit 32-bit bằng bản 64-bit (giữ bản gốc ở tệp .goc)' };
  }
  return { daVa: false, vi: 'không thấy rcedit trong bộ nhớ đệm' };
}

// ── 3. DỰNG ────────────────────────────────────────────────────────────────

function dung(muc) {
  noi(mau.dam(`\n  ▸ DỰNG: ${muc.join(' · ')}\n`));
  const r = spawnSync(
    process.platform === 'win32' ? 'npx.cmd' : 'npx',
    ['electron-builder', '--win', ...muc, '--x64'],
    {
      cwd: DESKTOP,
      stdio: 'inherit',
      env: {
        ...process.env,
        WINEDEBUG: '-all',
        WINEPREFIX: process.env.WINEPREFIX || path.join(os.tmpdir(), 'wine-gita'),
      },
    },
  );
  return r.status === 0;
}

// ── 4. SOI SẢN PHẨM ────────────────────────────────────────────────────────

/**
 * Dựng xong không bằng dựng đúng. Ba câu hỏi phải trả lời được TRƯỚC KHI đưa
 * tệp cho người dùng, vì người dùng chỉ biết "bấm vào không chạy".
 */
function soiSanPham() {
  noi(mau.dam('\n  ▸ SOI SẢN PHẨM\n'));
  const thuMuc = path.join(DESKTOP, 'dist');
  if (!fs.existsSync(thuMuc)) { thieu('Không có thư mục dist'); return false; }

  const exe = fs.readdirSync(thuMuc).filter((f) => f.endsWith('.exe'));
  if (!exe.length) { thieu('Không dựng ra tệp exe nào'); return false; }

  let ok = true;

  for (const f of exe) {
    const d = path.join(thuMuc, f);
    const kt = fs.statSync(d);
    const dau = Buffer.alloc(2);
    const fd = fs.openSync(d, 'r');
    fs.readSync(fd, dau, 0, 2, 0);
    fs.closeSync(fd);
    const laPE = dau.toString('latin1') === 'MZ';
    // Dưới 20 MB thì gần như chắc chắn là vỏ rỗng: riêng Electron đã hơn 100 MB
    // trước khi nén, nên một tệp 200 KB là trình cài đặt chưa có ruột.
    const duNang = kt.size > 20 * 1024 * 1024;
    if (laPE && duNang) dat(f, `${(kt.size / 1048576).toFixed(0)} MB · tệp Windows hợp lệ`);
    else { thieu(`${f} — ${laPE ? 'quá nhẹ, nhiều khả năng thiếu phần ruột' : 'không phải tệp Windows hợp lệ'}`); ok = false; }
  }

  // Ruột gói: thiếu một thư mục là ứng dụng bật lên rồi chết.
  const res = path.join(thuMuc, 'win-unpacked', 'resources');
  if (!fs.existsSync(res)) { thieu('Không có win-unpacked/resources'); return false; }
  for (const can of ['src', 'ui', 'package.json', 'app.asar']) {
    if (fs.existsSync(path.join(res, can))) dat(`Gói có ${can}`);
    else { thieu(`Gói THIẾU ${can}`); ok = false; }
  }

  // ĐỐI CHIẾU TỪNG TỆP với kho mã, không đếm ước chừng.
  //
  // Bản đầu chỉ đếm xem src/crm có đủ mười bốn tệp không. Đếm kiểu ấy canh
  // được đúng một thư mục: thêm một mô-đun MỚI ở chỗ khác mà danh sách đóng
  // gói không nhắc tới thì nó vắng mặt trong bản cài, ứng dụng vẫn bật lên,
  // và tính năng ấy chỉ hỏng khi có người bấm vào. Nên nay so từng tệp.
  const liet = (goc, thuMucCon) => {
    const ra = [];
    const di = (d, tien) => {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
        const q = tien ? `${tien}/${e.name}` : e.name;
        if (e.isDirectory()) di(path.join(d, e.name), q);
        else ra.push(q);
      }
    };
    const d = path.join(goc, thuMucCon);
    if (fs.existsSync(d)) di(d, '');
    return ra;
  };
  const gocKho = path.join(__dirname, '..');
  for (const thuMucCon of ['src', 'ui']) {
    const trongKho = liet(gocKho, thuMucCon).filter((f) => !f.startsWith('data/'));
    const trongGoi = new Set(liet(res, thuMucCon));
    const vang = trongKho.filter((f) => !trongGoi.has(f));
    if (vang.length === 0) dat(`Gói mang đủ ${thuMucCon}/`, `${trongKho.length} tệp, không sót tệp nào`);
    else {
      thieu(`Gói THIẾU ${vang.length} tệp trong ${thuMucCon}/: ${vang.slice(0, 5).join(', ')}`);
      ok = false;
    }
  }

  // Tệp exe của chính ứng dụng phải là 64-bit. Trình cài đặt NSIS luôn là
  // 32-bit — đó là chuyện bình thường và không phải lỗi.
  const ungDung = fs.readdirSync(path.join(thuMuc, 'win-unpacked')).find((f) => f.endsWith('.exe'));
  if (ungDung) {
    const d = path.join(thuMuc, 'win-unpacked', ungDung);
    const b = fs.readFileSync(d, { encoding: null, flag: 'r' }).subarray(0, 512);
    const peOff = b.readUInt32LE(0x3c);
    const may = b.readUInt16LE(peOff + 4);
    if (may === 0x8664) dat(`Ứng dụng "${ungDung}"`, 'x86-64');
    else { thieu(`Ứng dụng "${ungDung}" không phải 64-bit (mã máy 0x${may.toString(16)})`); ok = false; }
  }

  return ok;
}

// ── CHẠY ───────────────────────────────────────────────────────────────────

function main() {
  noi(mau.dam('\n  DỰNG BẢN CÀI WINDOWS 64-BIT — GITAmath Nexus V20'));
  noi(mau.mo('  ────────────────────────────────────────────────────────────'));

  const { hong, laWindows } = soiMayDung();
  const thieuNang = hong.filter((h) => h !== 'wine32');

  if (thieuNang.length) {
    noi(mau.do(`\n  DỪNG: thiếu ${thieuNang.join(', ')}. Cài xong rồi chạy lại.\n`));
    process.exit(1);
  }

  const coWine32 = !hong.includes('wine32');
  if (!laWindows) {
    const va = vaRcedit(coWine32);
    noi(mau.mo(`\n  rcedit: ${va.vi}`));
  }

  // Thiếu wine 32-bit thì vẫn dựng được bản CHẠY THẲNG — thứ người dùng tải về
  // bấm đúp là chạy. Chỉ trình cài đặt là không dựng được.
  const muc = coWine32 || laWindows ? ['nsis', 'portable'] : ['portable'];
  if (!coWine32 && !laWindows) {
    noi(mau.vang('\n  Thiếu wine 32-bit: chỉ dựng bản CHẠY THẲNG, bỏ trình cài đặt.'));
  }

  if (!dung(muc)) {
    noi(mau.do('\n  DỪNG: electron-builder báo lỗi.\n'));
    process.exit(1);
  }

  if (!soiSanPham()) {
    noi(mau.do('\n  DỰNG XONG NHƯNG SẢN PHẨM KHÔNG ĐẠT — đừng đưa cho người dùng.\n'));
    process.exit(1);
  }

  noi(mau.dam('\n  ════════════════════════════════════════════════════════════'));
  noi(`  XONG. Tệp nằm ở ${mau.dam('desktop/dist/')}\n`);
  for (const f of fs.readdirSync(path.join(DESKTOP, 'dist')).filter((x) => x.endsWith('.exe'))) {
    const kb = fs.statSync(path.join(DESKTOP, 'dist', f)).size / 1048576;
    const loai = /portable/.test(f) ? 'chạy thẳng, không cần cài' : 'trình cài đặt';
    noi(`    ${f}  ${mau.mo(`${kb.toFixed(0)} MB · ${loai}`)}`);
  }
  noi('');
}

main();
