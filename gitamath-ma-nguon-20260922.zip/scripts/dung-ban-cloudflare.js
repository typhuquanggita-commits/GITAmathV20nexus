#!/usr/bin/env node
'use strict';
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DỰNG BẢN CLOUDFLARE PAGES — và soi lại sản phẩm trước khi nói xong
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   node scripts/dung-ban-cloudflare.js
 *
 *  Ra thư mục cloudflare/dist/, đẩy lên bằng:
 *      npx wrangler pages deploy cloudflare/dist --project-name gitamath
 *
 *  Kịch bản này KHÔNG chỉ sinh tệp rồi báo xong. Nó soi lại chính thứ vừa
 *  sinh ra: có kịch bản lọt vào không, có đường nào gọi ra ngoài không, có
 *  câu nào không qua được luật nội dung không, và có tệp nào rỗng không.
 *
 *  Vì một trang tĩnh hỏng thì hỏng IM LẶNG — nó vẫn trả về 200.
 * ═══════════════════════════════════════════════════════════════════════════
 */

const fs = require('node:fs');
const path = require('node:path');

const GOC = path.join(__dirname, '..');
const RA = path.join(GOC, 'cloudflare', 'dist');

const mau = { xanh: (s) => `\x1b[32m${s}\x1b[0m`, do: (s) => `\x1b[31m${s}\x1b[0m`, nhat: (s) => `\x1b[2m${s}\x1b[0m`, dam: (s) => `\x1b[1m${s}\x1b[0m` };
let hong = 0;
const dat = (t, p = '') => console.log(`  [${mau.xanh(' ĐẠT ')}] ${t}${p ? mau.nhat(` · ${p}`) : ''}`);
const truot = (t) => { hong += 1; console.log(`  [${mau.do('KHÔNG')}] ${t}`); };

(async function main() {
  console.log(mau.dam('\n  ▸ DỰNG BẢN CLOUDFLARE PAGES\n'));

  const { boot } = require('../src/index');
  const N = await boot({ quiet: true });
  const T = require('../src/tiep-thi/dung-trang-tinh');
  const ngayDung = new Date().toISOString().slice(0, 10);

  fs.rmSync(RA, { recursive: true, force: true });
  fs.mkdirSync(RA, { recursive: true });

  // ── 1. Trang giới thiệu, dựng từ số liệu THẬT ──
  const trang = N.hopNhat.soanTrang();
  trang.soLieu.phienBan = N.cfg.VERSION;
  if (!trang.mang.length) truot('Không mảng nội dung nào dựng được — kho rỗng hoàn toàn');
  else dat('Nội dung trang chủ', `${trang.mang.length} mảng · bỏ qua ${trang.boQua.length}`);

  // ── 2. Sơ đồ chương trình, dạng ảnh tĩnh ──
  const SD = require('../src/so-do-tu-duy/so-do');
  const VE = require('../src/so-do-tu-duy/ve');
  const soDo = SD.dung({ kieu: 'toan-canh' });
  const svg = VE.ve(soDo, { rong: 820, cao: 560, nen: false })
    .replace(/^<svg /, '<svg style="max-width:100%;height:auto" ');
  dat('Sơ đồ chương trình', `${soDo.thongKe.soNut} dạng · ${soDo.thongKe.soCanh} quan hệ`);

  // ── 3. Danh mục kịch bản video ──
  const danhMuc = N.xuongVideo.danhMuc();
  if (!danhMuc.ok) truot(`Danh mục video có ${danhMuc.hong.length} kịch bản hỏng`);
  else dat('Danh mục video hướng dẫn', `${danhMuc.soMan} màn × ${danhMuc.soVai} vai = ${danhMuc.soVideo}`);

  // ── 4. Viết tệp ──
  const tep = {
    'index.html': T.trangChu(trang, { ngayDung, banSvg: null }),
    'so-do.html': T.trangSoDo(svg, { ngayDung }),
    'video-huong-dan.html': T.trangKichBan(danhMuc, { ngayDung }),
    'so-do-chuong-trinh.svg': VE.ve(soDo, { rong: 1100, cao: 720 }),
  };

  // Kịch bản lời đọc từng video — tải về được, gửi phát thanh viên thu.
  fs.mkdirSync(path.join(RA, 'kich-ban'), { recursive: true });
  let soKichBan = 0;
  for (const m of danhMuc.muc) {
    const k = N.xuongVideo.xuatKichBanChu(m.man, m.vai);
    if (k.ok) { fs.writeFileSync(path.join(RA, 'kich-ban', `${m.ma}.txt`), k.chu); soKichBan += 1; }
  }
  dat('Kịch bản lời đọc', `${soKichBan} tệp .txt`);

  for (const [ten, chu] of Object.entries(tep)) fs.writeFileSync(path.join(RA, ten), chu);

  // ── Toàn bộ giao diện ứng dụng ──
  //
  // Mười màn hình của ứng dụng là tệp tĩnh thuần: HTML, JS, CSS, không một
  // đường dẫn nào ra ngoài. Cloudflare phục vụ được hết. Phần ĐỘNG mà chúng
  // gọi tới (/accounts, /practice, /tro-chuyen…) đi tiếp về máy chủ Node qua
  // ba dòng trong _redirects.
  //
  // Để chúng ở đây chứ không bỏ đi, vì bỏ đi thì bản trên Cloudflare chỉ là
  // một tờ rơi; để vào thì nó là cả phần nhìn thấy được của hệ thống, và chỉ
  // còn thiếu đúng phần phải có máy chủ.
  const UI = path.join(GOC, 'ui');
  fs.mkdirSync(path.join(RA, 'ui'), { recursive: true });
  let soUi = 0;
  for (const f of fs.readdirSync(UI)) {
    const q = path.join(UI, f);
    if (!fs.statSync(q).isFile()) continue;
    fs.copyFileSync(q, path.join(RA, 'ui', f));
    soUi += 1;
  }
  dat('Giao diện ứng dụng', `${soUi} tệp trong ui/`);

  // ── Sơ đồ ở nhiều góc nhìn, để in và để nhúng ──
  fs.mkdirSync(path.join(RA, 'so-do'), { recursive: true });
  const GOC_NHIN = [
    ['thang', 0.0, 0.0], ['mac-dinh', 0.6, 0.28], ['nghieng', 1.4, 0.45], ['ben-canh', 2.6, 0.1],
  ];
  for (const [ten, doc, ngang] of GOC_NHIN) {
    fs.writeFileSync(path.join(RA, 'so-do', `toan-canh-${ten}.svg`),
      VE.ve(soDo, { gocDoc: doc, gocNgang: ngang, rong: 1100, cao: 720 }));
  }
  fs.writeFileSync(path.join(RA, 'so-do', 'toan-canh-nen-sang.svg'),
    VE.ve(soDo, { rong: 1100, cao: 720, nen: false }));
  dat('Sơ đồ nhiều góc nhìn', `${GOC_NHIN.length + 1} tệp SVG`);

  // ── Trang hướng dẫn, đọc được NGAY TRÊN Cloudflare sau khi tải lên ──
  //
  // Đặt trong gói chứ không chỉ để trong kho mã: người tải gói lên Cloudflare
  // có thể không phải người đọc kho mã.
  tep['huong-dan.html'] = T.trangChu({
    mang: [{
      ma: 'huong-dan', ten: 'Hướng dẫn', nhip: '—', nguonSo: [],
      chu: {
        tieu: 'Gói này chạy được gì trên Cloudflare',
        phu: 'Cloudflare Pages phục vụ tệp tĩnh: không chạy tiến trình lâu dài, '
          + 'không có hệ tệp ghi được, không giữ trạng thái giữa hai yêu cầu.',
        y: [
          'Chạy được ngay: trang giới thiệu, sơ đồ chương trình, kịch bản lời đọc, và toàn bộ mười màn giao diện.',
          'Cần máy chủ Node: đăng nhập, luyện tập, trợ lý trò chuyện, dựng video — mọi thứ đọc hoặc ghi dữ liệu thật.',
          'Nối hai phần: chạy máy chủ Node ở bất kỳ đâu, đưa ra ngoài bằng cloudflared tunnel, rồi mở ba dòng đã dựng sẵn trong tệp _redirects.',
          'Chưa mở ba dòng ấy thì mười màn giao diện vẫn mở ra được, nhưng phần dữ liệu sẽ báo chưa đăng nhập — đó là đúng, không phải lỗi.',
        ],
      },
    }],
    soLieu: { soDang: soDo.thongKe.soNut, soTang: 10, phienBan: N.cfg.VERSION },
    boQua: [],
  }, {
    ngayDung,
    tieuDe: 'GITAmath — Hướng dẫn đưa lên Cloudflare',
    moTa: 'Gói này chạy được gì trên Cloudflare Pages, và phần nào cần một máy chủ Node.',
  });
  fs.writeFileSync(path.join(RA, 'huong-dan.html'), tep['huong-dan.html']);

  // ── 5. Cấu hình Cloudflare ──
  // Chính sách nội dung khác nhau cho hai loại trang, và phải khác:
  //   · trang tĩnh tôi dựng    — KHÔNG có kịch bản nào, nên cấm hẳn
  //   · mười màn giao diện     — CÓ kịch bản của chính mình, nên cho 'self'
  // Dùng chung một chính sách thì hoặc là nới lỏng trang tĩnh vô cớ, hoặc là
  // khoá chết cả mười màn giao diện. Bản đầu đặt script-src 'none' cho /* và
  // đúng là đã khoá chết chúng.
  fs.writeFileSync(path.join(RA, '_headers'), `/*
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), microphone=()
  X-Frame-Options: DENY
  Strict-Transport-Security: max-age=31536000; includeSubDomains

/index.html
  Content-Security-Policy: ${T.CSP}

/so-do.html
  Content-Security-Policy: ${T.CSP}

/video-huong-dan.html
  Content-Security-Policy: ${T.CSP}

/huong-dan.html
  Content-Security-Policy: ${T.CSP}

/ui/*
  Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'

/kich-ban/*
  Content-Type: text/plain; charset=utf-8

/so-do/*
  Cache-Control: public, max-age=3600

/*.svg
  Cache-Control: public, max-age=3600
`);

  fs.writeFileSync(path.join(RA, '_redirects'), `# ═══════════════════════════════════════════════════════════════════════
#  BA DÒNG PHẢI MỞ ĐỂ PHẦN ĐỘNG CHẠY
# ═══════════════════════════════════════════════════════════════════════
#
# Mười màn giao diện trong /ui/ đã nằm sẵn trên Cloudflare và mở ra được
# ngay. Nhưng chúng gọi dữ liệu từ máy chủ Node, và máy chủ ấy KHÔNG chạy
# trên Cloudflare được.
#
# Chưa mở ba dòng dưới đây thì các màn vẫn mở ra, chỉ là phần dữ liệu báo
# chưa đăng nhập. Đó là đúng, không phải lỗi.
#
# Cách mở:
#   1. Chạy máy chủ:  npm start            (ở bất kỳ máy nào)
#   2. Đưa ra ngoài:  cloudflared tunnel --url http://localhost:9999
#   3. Trỏ một tên miền con vào đường hầm, ví dụ app.gitamath.vn
#   4. Đổi app.gitamath.vn dưới đây cho đúng, rồi bỏ dấu thăng ba dòng
#
# /accounts/*      https://app.gitamath.vn/accounts/:splat      200
# /tro-chuyen/*    https://app.gitamath.vn/tro-chuyen/:splat    200
# /api/*           https://app.gitamath.vn/:splat               200

# Lối tắt cho người gõ tay
/chuong-trinh   /so-do.html            301
/video          /video-huong-dan.html  301
/huong-dan      /huong-dan.html        301
/app            /ui/cong.html          302
`);

  fs.writeFileSync(path.join(GOC, 'cloudflare', 'wrangler.toml'), `name = "gitamath"
pages_build_output_dir = "dist"
compatibility_date = "${ngayDung}"

# Bản tĩnh này KHÔNG cần biến môi trường nào, và đó là cố ý: không bí mật nào
# đi lên Cloudflare thì không bí mật nào rò từ Cloudflare.
`);

  fs.writeFileSync(path.join(GOC, 'cloudflare', 'DOC-TRUOC.md'), `# Đưa GITAmath lên Cloudflare

Dựng: \`node scripts/dung-ban-cloudflare.js\`
Đẩy:  \`npx wrangler pages deploy cloudflare/dist --project-name gitamath\`

## Cái gì lên được Cloudflare, cái gì không

Nói thẳng trước khi làm, vì đây là chỗ dễ hứa quá tay nhất.

**Lên được** (Cloudflare Pages phục vụ tệp tĩnh):

- Trang giới thiệu — dựng sẵn thành HTML, số liệu đóng băng tại ngày dựng
- Sơ đồ chương trình dạng ảnh SVG
- ${soKichBan} kịch bản lời đọc của bộ video hướng dẫn

**Không lên được** — cần một máy chủ Node chạy thật:

- Đăng nhập, tài khoản, phiên làm việc
- Trợ lý trò chuyện (đọc dữ liệu học viên thật)
- Dựng video, dựng bài giảng, chụp ảnh hệ thống
- Mọi thứ ghi xuống đĩa

Lý do không phải thiếu sót của ai: Pages không chạy tiến trình lâu dài, không
có hệ tệp ghi được, và không giữ trạng thái giữa hai yêu cầu.

## Nối hai phần

1. Chạy máy chủ Node ở đâu cũng được — kể cả một máy trong văn phòng.
2. \`cloudflared tunnel --url http://localhost:9999\` đưa nó ra ngoài, không
   phải mở cổng nào trên tường lửa.
3. Trỏ một tên miền con (ví dụ \`app.gitamath.vn\`) vào đường hầm ấy.
4. Mở ba dòng trong \`dist/_redirects\`, đổi tên miền cho đúng.

Từ đó: tên miền chính phục vụ trang tĩnh từ Cloudflare (nhanh, chịu tải, miễn
phí), còn \`/ui/*\` và \`/api/*\` đi tiếp về máy chủ Node.

## Số liệu đóng băng

Trang tĩnh mang số liệu của **ngày dựng**, và mỗi trang in rõ ngày ấy. Số
liệu đổi thì dựng lại và đẩy lại — một lệnh.

## Không có bí mật nào trong bản này

\`wrangler.toml\` không khai biến môi trường nào. Kịch bản dựng soi lại sản
phẩm và **từ chối hoàn tất** nếu tìm thấy chuỗi trông giống khoá.
`);
  dat('Cấu hình Cloudflare', '_headers · _redirects · wrangler.toml · DOC-TRUOC.md');

  // ── 6. SOI LẠI SẢN PHẨM ──
  console.log(mau.dam('\n  ▸ SOI SẢN PHẨM\n'));

  for (const [ten, chu] of Object.entries(tep)) {
    if (!ten.endsWith('.html')) continue;
    const loi = T.soiTrangTinh(chu, { tenTep: ten });
    if (loi.length) loi.forEach(truot); else dat(`Trang ${ten}`, `${(chu.length / 1024).toFixed(1)}KB`);
  }

  // ── Đối chiếu TỪNG TỆP giao diện với kho mã ──
  //
  // Đây là phép kiểm trả lời thẳng câu hỏi "có thất lạc tệp nào không". Đếm
  // xấp xỉ hay kiểm vài tệp tiêu biểu đều không trả lời được câu ấy: thiếu
  // một tệp thì trang vẫn mở, vẫn trả 200, chỉ là mất kiểu chữ hoặc chết một
  // nút bấm — và không ai báo lỗi.
  const uiKho = fs.readdirSync(path.join(GOC, 'ui')).filter((f) => fs.statSync(path.join(GOC, 'ui', f)).isFile());
  const uiGoi = new Set(fs.readdirSync(path.join(RA, 'ui')));
  const uiThieu = uiKho.filter((f) => !uiGoi.has(f));
  if (uiThieu.length) truot(`Gói thiếu ${uiThieu.length} tệp giao diện: ${uiThieu.slice(0, 3).join(', ')}`);
  else dat('Gói mang đủ giao diện', `${uiKho.length}/${uiKho.length} tệp, không sót tệp nào`);

  // Không một tệp nào được rỗng.
  const rong = [];
  const diKhap = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) diKhap(q);
      else if (fs.statSync(q).size < 20) rong.push(path.relative(RA, q));
    }
  };
  diKhap(RA);
  if (rong.length) truot(`${rong.length} tệp rỗng: ${rong.slice(0, 3).join(', ')}`);
  else dat('Không tệp nào rỗng');

  // Không một chuỗi nào trông giống khoá.
  const NGHI_KHOA = [/sk-[A-Za-z0-9]{16,}/, /AIza[A-Za-z0-9_-]{20,}/, /gsk_[A-Za-z0-9]{20,}/,
    /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /Bearer\s+[A-Za-z0-9._-]{24,}/];
  const daiDien = [];
  const quet = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) { quet(q); continue; }
      if (!/\.(html|txt|svg|json|toml|md)$/.test(e.name)) continue;
      const c = fs.readFileSync(q, 'utf8');
      for (const re of NGHI_KHOA) if (re.test(c)) daiDien.push(`${path.relative(RA, q)} (${re.source.slice(0, 20)})`);
    }
  };
  quet(RA);
  if (daiDien.length) truot(`Có chuỗi trông giống khoá: ${daiDien.slice(0, 2).join(', ')}`);
  else dat('Không chuỗi nào trông giống khoá bí mật');

  // Mọi liên kết nội bộ phải trỏ tới một tệp có thật.
  const dut = [];
  for (const [ten, chu] of Object.entries(tep)) {
    if (!ten.endsWith('.html')) continue;
    for (const m of chu.matchAll(/href="(\/[^"#]*)"/g)) {
      const d = m[1] === '/' ? 'index.html' : m[1].replace(/^\//, '');
      if (!fs.existsSync(path.join(RA, d))) dut.push(`${ten} → ${m[1]}`);
    }
  }
  // Và mười màn giao diện cũng phải tự đủ: mọi tệp chúng nạp phải nằm trong
  // gói. Đây chính là chỗ "thất lạc một tệp" xảy ra — trang mở ra trắng trơn
  // hoặc mất hẳn kiểu chữ, mà máy chủ vẫn trả 200 nên không ai báo lỗi.
  for (const f of fs.readdirSync(path.join(RA, 'ui'))) {
    if (!f.endsWith('.html')) continue;
    const c = fs.readFileSync(path.join(RA, 'ui', f), 'utf8');
    for (const m of c.matchAll(/(?:href|src)="(\/ui\/[^"#?]+)"/g)) {
      if (!fs.existsSync(path.join(RA, m[1].replace(/^\//, '')))) dut.push(`ui/${f} → ${m[1]}`);
    }
  }
  if (dut.length) truot(`Liên kết đứt: ${dut.slice(0, 3).join(', ')}`);
  else dat('Mọi liên kết nội bộ đều trỏ tới tệp có thật', `kể cả ${fs.readdirSync(path.join(RA, 'ui')).filter((f) => f.endsWith('.html')).length} màn giao diện`);

  // ── Bản kê toàn gói ──
  //
  // Sau khi tải lên Cloudflare, mở /ban-ke.json là đối chiếu được ngay: gói
  // đáng lẽ có bao nhiêu tệp, và mỗi tệp bao nhiêu byte. Không có bản kê thì
  // "đã tải đủ chưa" là một câu hỏi không trả lời được.
  const ke = [];
  const keQuet = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) { keQuet(q); continue; }
      const duong = path.relative(RA, q).split(path.sep).join('/');
      if (duong === 'ban-ke.json') continue;
      ke.push({ duong, byte: fs.statSync(q).size });
    }
  };
  keQuet(RA);
  ke.sort((a, b) => a.duong.localeCompare(b.duong));
  fs.writeFileSync(path.join(RA, 'ban-ke.json'), `${JSON.stringify({
    dungLuc: new Date().toISOString(),
    phienBan: N.cfg.VERSION,
    soTep: ke.length,
    tongByte: ke.reduce((a, x) => a + x.byte, 0),
    tep: ke,
  }, null, 1)}\n`);
  dat('Bản kê toàn gói', `ban-ke.json · ${ke.length} tệp`);

  let tong = 0;
  const demByte = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const q = path.join(d, e.name);
      if (e.isDirectory()) demByte(q); else tong += fs.statSync(q).size;
    }
  };
  demByte(RA);

  await N.shutdown();

  console.log(mau.dam(`\n  ${'═'.repeat(60)}`));
  if (hong) {
    console.log(`  ${mau.do('CHƯA XONG')} — ${hong} mục không đạt. Bản dựng KHÔNG nên đẩy lên.\n`);
    process.exit(1);
  }
  console.log(`  XONG. ${mau.dam('cloudflare/dist/')} · ${(tong / 1024).toFixed(0)}KB\n`);
  console.log(`    npx wrangler pages deploy cloudflare/dist --project-name gitamath\n`);
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
