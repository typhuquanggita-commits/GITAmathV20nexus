'use strict';
/**
 * Khung hỏi đáp.
 *
 * Trang này cố tình HIỆN RA phần thường bị giấu: mỗi câu trả lời đi kèm việc
 * hệ thống đọc được là gì, đã gọi những công cụ nào, và công cụ nào có dữ
 * liệu. Người dùng nhìn thấy đường đi thì mới kiểm lại được câu trả lời —
 * còn một câu trả lời trơn tru không có vết thì tin hay không tin đều là
 * đoán.
 *
 * Lượt bị chặn cũng hiện, kèm tên cửa đã chặn. Chặn mà không nói vì sao thì
 * người bị chặn oan không có đường nào kêu.
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const GOI_Y = [
    'Chương trình có bao nhiêu dạng toán?',
    'Muốn học hàm số bậc hai thì cần biết gì trước?',
    'Học phí thế nào?',
    'Tôi không mở được trang bài tập',
  ];

  let dangGui = false;

  function themLoi(chu, ben, vet) {
    const d = document.createElement('div');
    d.className = `loi-nhan ${ben}`;
    d.innerHTML = esc(chu) + (vet ? `<div class="vet">${vet}</div>` : '');
    $('cuon').appendChild(d);
    $('cuon').scrollTop = $('cuon').scrollHeight;
  }

  async function gui(cauHoi) {
    const q = String(cauHoi || $('oHoi').value || '').trim();
    if (!q || dangGui) return;
    dangGui = true;
    $('nutGui').disabled = true;
    $('oHoi').value = '';
    $('loi').textContent = '';
    themLoi(q, 'cua-toi');

    const r = await G.api('/tro-chuyen/hoi', { cauHoi: q });
    dangGui = false;
    $('nutGui').disabled = false;

    // Cửa bảo vệ: lượt gọi hỏng thì KHÔNG đụng vào thuộc tính của nó.
    if (!G.can(r, 'Trợ lý trò chuyện')) {
      $('loi').textContent = 'Chưa hỏi được. Kiểm tra lại phiên đăng nhập rồi thử lại.';
      return;
    }

    if (r.biChan) {
      themLoi(r.traLoi, 'cua-may chan',
        `Lượt này bị giữ lại ở cửa <b>${esc(r.cua)}</b> — ${esc(r.ma)}.`);
      napTrangThai();
      return;
    }

    const cc = (r.congCuDaGoi || []);
    const vet = [
      `Đọc ý: <b>${esc(r.tenViec || r.viec)}</b>${r.docYChacChan ? '' : ' (chưa chắc chắn)'}`,
      `Công cụ: ${cc.length ? cc.map((c) => esc(c.congCu) + (c.coDuLieu ? ' ✓' : c.hoan ? ' (chờ người)' : ' (rỗng)')).join(', ') : 'không gọi công cụ nào'}`,
      r.daCheSoRieng ? `Đã che ${r.daCheSoRieng} số riêng tư trước khi hiện ra.` : '',
      r.canNguoiDuyet ? 'Có việc ghi vào sổ — đang chờ người duyệt.' : '',
      `Ký sổ: <b>${esc(r.chuKy || '')}</b> · ${r.ms}ms`,
    ].filter(Boolean).join('<br>');
    themLoi(r.traLoi, 'cua-may', vet);
    napTrangThai();
  }

  /**
   * Nạp lại bảng chín cửa.
   *
   * Gọi lại SAU MỖI LƯỢT, không chỉ lúc mở trang. Bản đầu chỉ gọi một lần khi
   * nạp, nên người dùng nhìn thấy một lượt bị chặn ngay trước mắt mà bảng vẫn
   * ghi "đã chặn 0" — con số ấy nói dối về thứ vừa xảy ra trên chính màn hình
   * họ đang nhìn.
   */
  async function napTrangThai() {
    const r = await G.api('/tro-chuyen');
    // Chưa đăng nhập thì cổng này trả lỗi. Nói ra chứ không để trang trống
    // trơn — trang trống làm người dùng tưởng hệ thống hỏng.
    if (!G.can(r, 'Tình trạng trợ lý')) {
      $('nhac').textContent = 'Cần đăng nhập để xem chi tiết các cửa kiểm. Khung hỏi vẫn dùng được.';
      return;
    }
    const L = r.lop || {};
    const ten = {
      'loc-vao': 'Lọc đầu vào', 'hang-rao': 'Hàng rào nhắc lại',
      'khien-viec': 'Khiên việc', 'canh-ra': 'Canh đường ra', 'linh-gac': 'Lính gác',
    };
    $('cua').innerHTML = Object.keys(ten).map((k) => {
      const o = L[k] || {};
      const phu = k === 'hang-rao'
        ? `chế độ ${esc(o.cheDo || '—')}`
        : `đã chặn ${o.soChan || 0}`;
      return `<div><b>${ten[k]}</b>${phu}</div>`;
    }).join('');
    const hr = L['hang-rao'] || {};
    $('nhac').textContent = `${r.cua} cửa mỗi lượt · ${r.soCongCu} công cụ đọc dữ liệu thật · `
      + `sổ công chứng ${(r.soCongChung || {}).thuatToan || ''} đã ký ${(r.soCongChung || {}).tong || 0} dòng.`
      + (hr.cheDo === 'rut-gon' ? ' Hàng rào nhắc lại đang ở chế độ rút gọn vì chưa có mô hình nhỏ — lớp ấy yếu hơn bản đầy đủ.' : '');
  }

  $('nutGui').addEventListener('click', () => { gui(); });
  $('oHoi').addEventListener('keydown', (e) => { if (e.key === 'Enter') gui(); });
  $('goiY').innerHTML = GOI_Y.map((g, i) => `<button type="button" data-i="${i}">${esc(g)}</button>`).join('');
  $('goiY').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (b) gui(GOI_Y[+b.dataset.i]);
  });

  themLoi('Dạ, em là trợ lý của GITAmath. Anh/chị hỏi em về chương trình học, '
    + 'tiến độ, hoặc báo trục trặc giúp em ạ.', 'cua-may');
  napTrangThai();
}());
