'use strict';
/**
 * Hạ tầng dùng chung cho mọi giao diện GITAmath.
 * Không phụ thuộc thư viện ngoài. Không gọi ra mạng ngoài.
 */
(function (global) {
  const TOKEN_KEY = 'gita.token';
  const USER_KEY = 'gita.user';

  // ── Gọi API ──────────────────────────────────────────────────────────────
  async function api(path, body = null, method = null) {
    const opts = {
      method: method || (body ? 'POST' : 'GET'),
      headers: { 'content-type': 'application/json' },
    };
    if (body) opts.body = JSON.stringify(body);
    const token = getToken();
    if (token) opts.headers.authorization = `Bearer ${token}`;
    try {
      const res = await fetch(path, opts);
      const text = await res.text();
      let data;
      try { data = JSON.parse(text); } catch { data = { ok: false, error: 'BAD_RESPONSE', raw: text.slice(0, 200) }; }
      if (!res.ok && data.ok === undefined) data.ok = false;
      data._status = res.status;
      // Đánh dấu rõ lỗi xác thực để lưới an toàn bên dưới nói đúng nguyên nhân
      // thay vì ném ra một câu khó hiểu của trình duyệt.
      if (res.status === 401) data._chuaDangNhap = true;
      if (res.status === 403) data._khongDuQuyen = true;
      return data;
    } catch (e) {
      // Mất mạng hoặc máy chủ chưa lên: nói thẳng, đừng để giao diện đứng im.
      return { ok: false, error: 'KHÔNG_KẾT_NỐI_ĐƯỢC', message: e.message };
    }
  }

  // ── Phiên đăng nhập ──────────────────────────────────────────────────────
  const getToken = () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } };
  const getUser = () => { try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch { return null; } };
  function setSession(token, user) {
    try {
      if (token) localStorage.setItem(TOKEN_KEY, token); else localStorage.removeItem(TOKEN_KEY);
      if (user) localStorage.setItem(USER_KEY, JSON.stringify(user)); else localStorage.removeItem(USER_KEY);
    } catch { /* chế độ riêng tư: vẫn chạy được trong phiên hiện tại */ }
  }
  function clearSession() { setSession(null, null); }

  async function login(username, password) {
    const r = await api('/accounts/login', { username, password });
    if (r.ok) setSession(r.token, r.user);
    return r;
  }
  async function logout() {
    const t = getToken();
    if (t) await api('/accounts/logout', { token: t });
    clearSession();
  }

  // ── Tiện ích DOM ─────────────────────────────────────────────────────────
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const tex = (s) => (global.TeX ? global.TeX.renderText(String(s ?? '')) : esc(s));
  const pct = (x, d = 0) => (x == null ? '—' : `${(x * 100).toFixed(d)}%`);
  const stars = (n) => '★'.repeat(Math.max(0, n || 0)) + '☆'.repeat(Math.max(0, 5 - (n || 0)));
  const vn = (n) => (n == null ? '—' : Number(n).toLocaleString('vi-VN'));

  function toast(msg, kind = '') {
    let box = $('toast');
    if (!box) {
      box = document.createElement('div');
      box.id = 'toast';
      box.className = 'toast';
      document.body.appendChild(box);
    }
    const el = document.createElement('div');
    el.className = kind;
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => el.remove(), 4200);
  }

  /** Bảng đơn giản từ mảng bản ghi. cols: [{key,label,fmt?,cls?}] */
  function table(rows, cols, emptyText = 'Chưa có dữ liệu.') {
    if (!rows || !rows.length) return `<div class="muted">${esc(emptyText)}</div>`;
    const head = cols.map((c) => `<th class="${c.cls || ''}">${esc(c.label)}</th>`).join('');
    const body = rows.map((r) => `<tr>${cols.map((c) => {
      const v = typeof c.get === 'function' ? c.get(r) : r[c.key];
      return `<td class="${c.cls || ''}">${c.html ? v : esc(v ?? '')}</td>`;
    }).join('')}</tr>`).join('');
    return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
  }

  /** Thanh tiến độ. */
  function bar(value, kind = '') {
    const p = Math.max(0, Math.min(1, Number(value) || 0));
    return `<span class="bar ${kind}"><i style="width:${(p * 100).toFixed(1)}%"></i></span>`;
  }

  /** Biểu đồ cột SVG thuần — không thư viện, đọc được cả nền sáng lẫn tối. */
  function barChart(data, { height = 140, format = (v) => v } = {}) {
    if (!data || !data.length) return '<div class="muted">Chưa có dữ liệu.</div>';
    const max = Math.max(...data.map((d) => d.value), 0.0001);
    const w = 100 / data.length;
    const bars = data.map((d, i) => {
      const h = (d.value / max) * 78;
      const x = i * w;
      return `<g>
        <rect x="${(x + w * 0.15).toFixed(2)}" y="${(88 - h).toFixed(2)}" width="${(w * 0.7).toFixed(2)}" height="${h.toFixed(2)}"
              rx="1" fill="var(--brand)" opacity="${0.55 + 0.45 * (d.value / max)}"><title>${esc(d.label)}: ${esc(format(d.value))}</title></rect>
        <text x="${(x + w / 2).toFixed(2)}" y="97" text-anchor="middle" font-size="3.2" fill="currentColor" opacity=".7">${esc(d.short || d.label)}</text>
        <text x="${(x + w / 2).toFixed(2)}" y="${(85 - h).toFixed(2)}" text-anchor="middle" font-size="3.4" fill="currentColor">${esc(format(d.value))}</text>
      </g>`;
    }).join('');
    return `<svg viewBox="0 0 100 100" preserveAspectRatio="none" style="width:100%;height:${height}px" role="img">${bars}</svg>`;
  }

  /** Biểu đồ đường cho chuỗi thời gian. */
  function lineChart(values, { height = 120, label = '' } = {}) {
    if (!values || values.length < 2) return '<div class="muted">Cần ít nhất hai điểm dữ liệu.</div>';
    const max = Math.max(...values, 0.0001);
    const min = Math.min(...values, 0);
    const span = (max - min) || 1;
    const pts = values.map((v, i) => {
      const x = (i / (values.length - 1)) * 96 + 2;
      const y = 92 - ((v - min) / span) * 84;
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    }).join(' ');
    return `<svg viewBox="0 0 100 100" preserveAspectRatio="none" style="width:100%;height:${height}px" role="img">
      <polyline points="${pts}" fill="none" stroke="var(--brand)" stroke-width="1.2" vector-effect="non-scaling-stroke"/>
      <text x="2" y="6" font-size="3.4" fill="currentColor" opacity=".7">${esc(label)}</text>
    </svg>`;
  }

  /** Vòng radar 6 trục cho chân dung năng lực. */
  function radar(axes, { size = 200 } = {}) {
    const keys = Object.keys(axes || {});
    if (keys.length < 3) return '<div class="muted">Chưa đủ dữ liệu để vẽ chân dung.</div>';
    const n = keys.length;
    const cx = 50, cy = 52, r = 38;
    const pt = (i, v) => {
      const a = (Math.PI * 2 * i) / n - Math.PI / 2;
      return [cx + Math.cos(a) * r * v, cy + Math.sin(a) * r * v];
    };
    const grid = [0.25, 0.5, 0.75, 1].map((g) => {
      const p = keys.map((_, i) => pt(i, g).map((x) => x.toFixed(2)).join(',')).join(' ');
      return `<polygon points="${p}" fill="none" stroke="currentColor" opacity=".16" stroke-width=".4"/>`;
    }).join('');
    const shape = keys.map((k, i) => pt(i, Math.max(0.02, Math.min(1, axes[k] ?? 0))).map((x) => x.toFixed(2)).join(',')).join(' ');
    const labels = keys.map((k, i) => {
      const [x, y] = pt(i, 1.24);
      return `<text x="${x.toFixed(2)}" y="${y.toFixed(2)}" font-size="3.6" text-anchor="middle" fill="currentColor" opacity=".8">${esc(k)}</text>`;
    }).join('');
    return `<svg viewBox="0 0 100 100" style="width:100%;max-width:${size}px;height:auto" role="img">
      ${grid}<polygon points="${shape}" fill="var(--brand)" opacity=".28" stroke="var(--brand)" stroke-width=".8"/>${labels}
    </svg>`;
  }

  /**
   * Chuẩn hoá một bước giải về dạng {viec, canCu}.
   * Bản sao thu gọn của src/content/loi-giai.js cho phía trình duyệt: trình
   * duyệt không nạp được mô-đun CommonJS của máy chủ, nên phần dùng chung phải
   * lặp lại ở đây. Hai bản phải cùng quy ước — có kiểm thử giữ ràng buộc này.
   */
  function buocGiai(item) {
    const ds = Array.isArray(item && item.solutionSteps) ? item.solutionSteps : [];
    return ds.map((b) => {
      if (b == null) return { viec: '', canCu: null };
      if (typeof b === 'string') return { viec: b, canCu: null };
      return {
        viec: typeof b.viec === 'string' ? b.viec : String(b.viec == null ? '' : b.viec),
        canCu: typeof b.canCu === 'string' && b.canCu.trim() ? b.canCu : null,
      };
    });
  }

  // ── ĐĂNG NHẬP BẰNG KHUÔN MẶT THẬT ────────────────────────────────────────
  //
  // Gọi thẳng WebAuthn của trình duyệt. Hệ điều hành mở hộp thoại của CHÍNH
  // NÓ — Windows Hello, Touch ID, Face ID — và trang web này không bao giờ
  // thấy khuôn mặt, không chạm được vào camera, không nhận được một điểm ảnh
  // nào. Đó là điều đúng đắn, không phải thiếu sót.

  const coKhuonMat = () => typeof window !== 'undefined'
    && !!(window.PublicKeyCredential && navigator.credentials && navigator.credentials.create);

  /** Máy này có bộ xác thực sinh trắc học gắn trong không. Trả lời thật, có thể là "không". */
  async function mayCoSinhTracHoc() {
    if (!coKhuonMat()) return false;
    try {
      return await window.PublicKeyCredential
        .isUserVerifyingPlatformAuthenticatorAvailable();
    } catch { return false; }
  }

  const _tuB64 = (s) => {
    const t = String(s).replace(/-/g, '+').replace(/_/g, '/');
    const bin = atob(t + '='.repeat((4 - t.length % 4) % 4));
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u.buffer;
  };
  const _raB64 = (b) => {
    const u = new Uint8Array(b);
    let t = '';
    for (let i = 0; i < u.length; i++) t += String.fromCharCode(u[i]);
    return btoa(t).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  };

  /** Dịch tuỳ chọn máy chủ gửi sang kiểu trình duyệt đòi. */
  function _dichTuyChon(o, laDangKy) {
    const r = { ...o, challenge: _tuB64(o.challenge) };
    if (laDangKy) {
      r.user = { ...o.user, id: _tuB64(o.user.id) };
      r.excludeCredentials = (o.excludeCredentials || []).map((c) => ({ ...c, id: _tuB64(c.id) }));
    } else {
      r.allowCredentials = (o.allowCredentials || []).map((c) => ({ ...c, id: _tuB64(c.id) }));
    }
    return r;
  }

  /**
   * Gắn khuôn mặt vào tài khoản đang đăng nhập.
   * @param {object|null} dongYGiamHo bắt buộc với tài khoản học viên
   */
  async function ganKhuonMat(dongYGiamHo = null) {
    if (!coKhuonMat()) return { ok: false, error: 'TRINH_DUYET_KHONG_HO_TRO' };
    const x = await api('/khuon-mat/xin-dang-ky', {});
    if (!x.ok) return x;
    let cred;
    try {
      cred = await navigator.credentials.create({ publicKey: _dichTuyChon(x.tuyChon, true) });
    } catch (e) {
      // Người dùng bấm huỷ là chuyện bình thường, không phải sự cố.
      return { ok: false, error: e && e.name === 'NotAllowedError' ? 'NGUOI_DUNG_HUY' : 'TRINH_DUYET_TU_CHOI', message: e && e.message };
    }
    if (!cred) return { ok: false, error: 'KHONG_NHAN_DUOC_KHOA' };
    return api('/khuon-mat/dang-ky', {
      thachThuc: x.thachThuc,
      id: cred.id,
      clientDataJSON: _raB64(cred.response.clientDataJSON),
      attestationObject: _raB64(cred.response.attestationObject),
      gan: typeof cred.authenticatorAttachment === 'string' ? cred.authenticatorAttachment : null,
      dongYGiamHo,
    });
  }

  /** Đăng nhập bằng khuôn mặt. Đặt phiên luôn khi đạt. */
  async function vaoBangKhuonMat(username = null) {
    if (!coKhuonMat()) return { ok: false, error: 'TRINH_DUYET_KHONG_HO_TRO' };
    const x = await api('/khuon-mat/xin-dang-nhap', { username });
    if (!x.ok) return x;
    let cred;
    try {
      cred = await navigator.credentials.get({ publicKey: _dichTuyChon(x.tuyChon, false) });
    } catch (e) {
      return { ok: false, error: e && e.name === 'NotAllowedError' ? 'NGUOI_DUNG_HUY' : 'TRINH_DUYET_TU_CHOI', message: e && e.message };
    }
    if (!cred) return { ok: false, error: 'KHONG_CHON_KHOA' };
    const r = await api('/khuon-mat/dang-nhap', {
      thachThuc: x.thachThuc,
      maKhoa: cred.id,
      clientDataJSON: _raB64(cred.response.clientDataJSON),
      authenticatorData: _raB64(cred.response.authenticatorData),
      signature: _raB64(cred.response.signature),
      gan: typeof cred.authenticatorAttachment === 'string' ? cred.authenticatorAttachment : null,
    });
    if (r.ok) setSession(r.token, r.user);
    return r;
  }

  /** Câu giải thích cho người dùng, theo đúng lý do thật. */
  function noiLoiKhuonMat(r) {
    const b = {
      NGUOI_DUNG_HUY: 'Bạn đã huỷ. Có thể đăng nhập bằng mật khẩu như thường.',
      TRINH_DUYET_KHONG_HO_TRO: 'Trình duyệt này chưa hỗ trợ đăng nhập bằng khuôn mặt.',
      TRINH_DUYET_TU_CHOI: 'Máy chưa nhận diện được. Thử lại, hoặc đăng nhập bằng mật khẩu.',
      INVALID_CREDENTIALS: 'Không nhận ra khuôn mặt này trên tài khoản nào của hệ thống.',
      LOCKED_OUT: 'Tài khoản đang bị khoá vì thử sai nhiều lần.',
      THIEU_DONG_Y_NGUOI_GIAM_HO: 'Tài khoản học viên cần người giám hộ đồng ý trước khi gắn khuôn mặt.',
      QUA_NAM_MAY_DA_DANG_KY: 'Đã gắn đủ năm máy. Gỡ bớt một máy cũ trước.',
      KHOA_NAY_DA_DANG_KY: 'Máy này đã gắn rồi.',
      CHUA_BAT_DANG_NHAP_KHUON_MAT: 'Hệ thống chưa bật đăng nhập bằng khuôn mặt.',
    };
    return b[r && r.error] || (r && (r.message || r.error)) || 'Không đăng nhập được bằng khuôn mặt.';
  }

  // ── LƯỚI AN TOÀN TOÀN CỤC ────────────────────────────────────────────────
  //
  // VÌ SAO CẦN. Hàm api() ở trên xử lý lỗi đúng: nó KHÔNG ném, mà trả về
  // {ok:false, error:...}. Nhưng năm mươi sáu chỗ gọi nó đều dùng thẳng dữ
  // liệu mà không hỏi ok trước — ví dụ `layers.layers.map(...)`. Khi máy chủ
  // trả 401, `layers.layers` là undefined, `.map` ném lỗi, và lỗi ấy giết
  // luôn phần còn lại của hàm.
  //
  // Hậu quả bắt được khi lái thử bằng trình duyệt thật: trang trung tâm chỉ
  // huy mở lên trông như bình thường, nhưng một nửa nội dung không bao giờ
  // dựng, và người dùng KHÔNG thấy một thông báo nào. Họ tưởng hệ thống hỏng.
  //
  // Lưới này không sửa từng chỗ gọi — nó làm một việc khác và quan trọng hơn:
  // biến một cái chết câm thành một câu nói rõ ràng.
  let _bangLoi = null;
  function baoLoi(chu, kieu) {
    try {
      if (!_bangLoi) {
        _bangLoi = document.createElement('div');
        _bangLoi.className = 'bang-bao-loi';
        _bangLoi.setAttribute('role', 'alert');
        document.body.appendChild(_bangLoi);
      }
      _bangLoi.dataset.kieu = kieu || 'loi';
      _bangLoi.textContent = chu;
      _bangLoi.classList.add('hien');
    } catch { /* chưa có body thì thôi */ }
  }

  function _docLoi(e) {
    const chu = String((e && (e.message || e.reason && e.reason.message || e.reason)) || e || '');
    // Đây đúng là hình dạng của lỗi "gọi API xong dùng thẳng dữ liệu":
    // đọc thuộc tính của undefined ngay sau một lượt gọi hỏng.
    if (/of undefined|of null|is not a function|is not iterable/.test(chu)) {
      return 'Không tải được một phần nội dung. Thường là do chưa đăng nhập '
        + 'hoặc tài khoản không đủ quyền cho mục này. Hãy đăng nhập rồi tải lại trang.';
    }
    return `Có lỗi khi dựng trang: ${chu.slice(0, 180)}`;
  }

  if (typeof window !== 'undefined') {
    window.addEventListener('error', (e) => baoLoi(_docLoi(e), 'loi'));
    window.addEventListener('unhandledrejection', (e) => baoLoi(_docLoi(e), 'loi'));
  }

  /**
   * Kiểm một câu trả lời của API trước khi dùng.
   *
   * Trả về chính dữ liệu khi đạt, và null khi hỏng — kèm một câu nói rõ
   * nguyên nhân hiện lên màn hình. Chỗ gọi chỉ cần:
   *
   *     const r = G.can(await api('/duong/dan'), 'danh sách tầng bảo vệ');
   *     if (!r) return;
   */
  function can(kq, tenViec) {
    if (kq && kq.ok !== false) return kq;
    const viec = tenViec ? `${tenViec}: ` : '';
    if (kq && kq._chuaDangNhap) baoLoi(`${viec}cần đăng nhập để xem mục này.`, 'nhac');
    else if (kq && kq._khongDuQuyen) baoLoi(`${viec}tài khoản hiện tại không đủ quyền cho mục này.`, 'nhac');
    else baoLoi(`${viec}${(kq && (kq.message || kq.error)) || 'không tải được'}.`, 'loi');
    return null;
  }

  const Common = { api, can, baoLoi, login, coKhuonMat, mayCoSinhTracHoc, ganKhuonMat, vaoBangKhuonMat, noiLoiKhuonMat, logout, getToken, getUser, setSession, clearSession, $, esc, tex, buocGiai, pct, stars, vn, toast, table, bar, barChart, lineChart, radar };
  if (typeof module !== 'undefined' && module.exports) module.exports = Common;
  if (global) global.G = Common;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : null));
