'use strict';
/**
 * Nghe giảng — lớp giọng nói dùng chung cho mọi giao diện.
 *
 * Nguyên tắc:
 *   · Không dùng speechSynthesis của trình duyệt. Giọng tiếng Việt của mỗi máy
 *     một khác, có máy không có, và không có cách nào đánh dấu nội dung AI.
 *     Âm thanh do máy chủ dựng thì cả 500 giảng viên đều đúng một giọng đã định.
 *   · Mỗi lần phát đều hiện nhãn "Giọng AI" — đây là yêu cầu pháp lý, không
 *     phải chi tiết trang trí, nên nó nằm trong mã chứ không nằm trong hướng dẫn.
 *   · Một lúc chỉ một luồng tiếng. Bấm bài khác là bài trước dừng.
 */
(function (global) {
  const KEY = 'gita.voice';
  let audio = null;
  let current = null;

  const getVoice = () => { try { return localStorage.getItem(KEY) || ''; } catch { return ''; } };
  const setVoice = (v) => { try { v ? localStorage.setItem(KEY, v) : localStorage.removeItem(KEY); } catch { /* chế độ riêng tư */ } };

  function url(text, opts = {}) {
    const q = new URLSearchParams({ text: String(text || '').slice(0, 3500) });
    const v = opts.voiceId || getVoice();
    if (v) q.set('voiceId', v);
    if (opts.agentId) q.set('agentId', opts.agentId);
    if (opts.level != null) q.set('level', String(opts.level));
    if (opts.rate != null) q.set('rate', String(opts.rate));
    if (opts.learnerId) q.set('learnerId', opts.learnerId);
    return `/voice/say?${q.toString()}`;
  }

  function stop() {
    if (audio) { audio.pause(); audio.currentTime = 0; }
    current = null;
    document.querySelectorAll('.voice-btn.playing').forEach((b) => {
      b.classList.remove('playing');
      b.textContent = b.dataset.idle || '🔊 Nghe';
    });
  }

  /** Phát một đoạn. Trả về Promise kết thúc khi đọc xong hoặc bị dừng. */
  function play(text, opts = {}, btn = null) {
    if (!text || !String(text).trim()) return Promise.resolve({ ok: false, error: 'THIẾU_NỘI_DUNG' });
    stop();
    if (!audio) audio = new Audio();
    current = String(text);
    audio.src = url(text, opts);
    if (btn) {
      btn.dataset.idle = btn.dataset.idle || btn.textContent;
      btn.classList.add('playing');
      btn.textContent = '⏸ Dừng';
    }
    return new Promise((resolve) => {
      audio.onended = () => { stop(); resolve({ ok: true }); };
      audio.onerror = () => {
        stop();
        global.G?.toast?.('Máy chủ chưa đọc được đoạn này.', 'err');
        resolve({ ok: false, error: 'KHÔNG_PHÁT_ĐƯỢC' });
      };
      audio.play().catch(() => {
        stop();
        global.G?.toast?.('Trình duyệt chặn tự phát — bấm lại một lần nữa.', '');
        resolve({ ok: false, error: 'BỊ_CHẶN_TỰ_PHÁT' });
      });
    });
  }

  /** Bấm lần nữa vào chính đoạn đang đọc thì dừng — không chồng tiếng. */
  function toggle(text, opts = {}, btn = null) {
    if (current === String(text)) { stop(); return Promise.resolve({ ok: true, stopped: true }); }
    return play(text, opts, btn);
  }

  /** Nút nghe kèm nhãn công bố giọng AI. Dùng trong template chuỗi. */
  function button(text, opts = {}) {
    const payload = encodeURIComponent(String(text));
    const o = encodeURIComponent(JSON.stringify(opts));
    return `<button class="ghost voice-btn" title="Giọng do máy tổng hợp"
      onclick="Voice.toggle(decodeURIComponent('${payload}'), JSON.parse(decodeURIComponent('${o}')), this)">🔊 Nghe</button>`
      + '<span class="ai-tag" title="Nội dung âm thanh do AI tạo, có đóng dấu">Giọng AI</span>';
  }

  /** Đọc lần lượt nhiều đoạn, có nghỉ giữa các đoạn — dùng cho lời giải từng bước. */
  async function playScript(segments, opts = {}) {
    for (const s of segments) {
      const text = typeof s === 'string' ? s : s.text;
      if (!text) { await new Promise((r) => setTimeout(r, (s.pauseAfterMs || 600))); continue; }
      const r = await play(text, { ...opts, rate: s.rate });
      if (!r.ok) return r;
      await new Promise((r2) => setTimeout(r2, s.pauseAfterMs || 500));
    }
    return { ok: true, segments: segments.length };
  }

  /** Ô chọn giọng: đổ danh sách từ /voice/voices và nhớ lựa chọn. */
  async function mountPicker(selectEl, { division = null, limit = 60 } = {}) {
    if (!selectEl) return;
    const q = new URLSearchParams({ limit: String(limit) });
    if (division) q.set('division', division);
    const r = await (global.G ? global.G.api(`/voice/voices?${q}`) : fetch(`/voice/voices?${q}`).then((x) => x.json()));
    if (!r || !r.ok) { selectEl.innerHTML = '<option value="">(chưa lấy được danh sách giọng)</option>'; return; }
    const cur = getVoice();
    selectEl.innerHTML = '<option value="">Giọng mặc định theo tầng</option>'
      + r.items.map((v) => `<option value="${v.voiceId}"${v.voiceId === cur ? ' selected' : ''}>`
        + `${v.displayName || v.voiceId} — ${v.gender}, ${v.character}</option>`).join('');
    selectEl.onchange = () => {
      setVoice(selectEl.value);
      global.G?.toast?.(selectEl.value ? 'Đã đổi giọng giảng viên.' : 'Dùng lại giọng mặc định.', 'ok');
    };
  }

  const Voice = { play, toggle, stop, button, url, playScript, mountPicker, getVoice, setVoice };
  if (typeof module !== 'undefined' && module.exports) module.exports = Voice;
  if (global) global.Voice = Voice;
})(typeof window !== 'undefined' ? window : globalThis);
